////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.transformation.cashreceiptservice;

import org.apache.camel.Exchange;

import com.sonatacentral.service.v30.common.cashreceipt.CreateReceiptResponseType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.cashreceiptservice.CashReceiptServiceConstants;
import com.suncorp.ssp.service.integration.cashreceiptservice.bean.CreateReceiptResponse;
import com.suncorp.ssp.service.integration.cashreceiptservice.util.CreateReceiptUtil;

/**
 * The class {@code CreateReceiptResponseTransformer} is used to get the response of create receipt and logging the receipt id and number.
 * 
 * @author U383754
 * @since 04/03/2016
 * @version 1.0
 */
public class CreateReceiptResponseTransformer {
    private String className = "CreateReceiptResponseTransformer";

    public void transform(Exchange exchange) throws SILException {
        try {
            SILLogger.debug(CashReceiptServiceConstants.CREATE_RECEIPT_LOG_FORMAT, className, "Entering transform()");
            CreateReceiptResponseType createReceiptResponseType = exchange.getIn().getBody(CreateReceiptResponseType.class);
            CreateReceiptResponse createReceiptResponse = new CreateReceiptResponse();
            CreateReceiptUtil createReceiptUtil = new CreateReceiptUtil(createReceiptResponseType);
            createReceiptUtil.setOutboundResponse(createReceiptResponse);
            String outboundMessage = createReceiptResponse.getId().concat(" AND ").concat(createReceiptResponse.getReceiptNumber());
            SILLogger.debug(CashReceiptServiceConstants.CREATE_RECEIPT_LOG_FORMAT, className, outboundMessage);
            exchange.setProperty(CashReceiptServiceConstants.CASH_RECEIPT_RES_MSG, outboundMessage);
            SILLogger.debug(CashReceiptServiceConstants.CREATE_RECEIPT_LOG_FORMAT, className, "Exiting transform()");
        } catch (Exception ex) {
            SILLogger.error(CashReceiptServiceConstants.CREATE_RECEIPT_LOG_FORMAT, className, ex.getMessage());
            throw new SILException(CashReceiptServiceConstants.CREATE_RECEIPT_GENERIC_MSG);
        }
    }
}
