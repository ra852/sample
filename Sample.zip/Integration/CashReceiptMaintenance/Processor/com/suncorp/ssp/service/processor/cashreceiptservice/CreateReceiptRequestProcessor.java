////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.processor.cashreceiptservice;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.component.cxf.common.message.CxfConstants;

import com.sonatacentral.service.v30.callerdetails.CallerDetails;
import com.sonatacentral.service.v30.common.cashreceipt.CreateReceiptRequestType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CodeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CountryIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CurrencyIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.PaymentType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.ReceiptType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.ReceiptType.DepositDetails;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.ReceiptType.ReceiptDetails;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.ApplicationType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.cashreceiptservice.CashReceiptServiceConstants;
import com.suncorp.ssp.service.integration.cashreceiptservice.bean.CashAppliedFileMessage;
import com.suncorp.ssp.service.integration.cashreceiptservice.bean.Envelope;
import com.suncorp.ssp.service.integration.cashreceiptservice.bean.Payment;
import com.suncorp.ssp.service.integration.cashreceiptservice.util.CAFSaxParser;

public class CreateReceiptRequestProcessor implements Processor {
    private String className = "CreateReceiptRequestProcessor";

    /**
     * This method reads file and process it to construct soap request of create receipt.
     * 
     * @param exchange
     * @throws Exception
     */
    @Override
    public void process(Exchange exchange) throws Exception {
        SILLogger.debug(CashReceiptServiceConstants.CREATE_RECEIPT_LOG_FORMAT, className, "Entering process()");
        try {
            int envelopeLoopIndex = (int) exchange.getProperty(CashReceiptServiceConstants.ENVELOPE_LOOP_INDEX);
            int paymentLoopIndex = (int) exchange.getProperty(CashReceiptServiceConstants.PAYMENT_LOOP_INDEX);
            CashAppliedFileMessage cashAppliedFileMessage =
                    (CashAppliedFileMessage) exchange.getProperty(CashReceiptServiceConstants.CASH_RECEIPT_BEAN);
            CreateReceiptRequestType createReceiptRequestType = new CreateReceiptRequestType();
            CallerDetails callerDetails = SILUtil.createCallerDetails();
            createReceiptRequestType.setCallerDetails(callerDetails);
            ReceiptType receiptType = this.getReceipt(exchange, cashAppliedFileMessage, envelopeLoopIndex, paymentLoopIndex);
            createReceiptRequestType.setReceipt(receiptType);
            this.setHeaderAndBody(exchange, createReceiptRequestType);
            SILLogger.debug(CashReceiptServiceConstants.CREATE_RECEIPT_LOG_FORMAT, className, "Exiting process()");
        } catch (SILException silException) {
            SILLogger.error(CashReceiptServiceConstants.CREATE_RECEIPT_LOG_FORMAT, className, "Exception :" + silException.getMessage());
            throw new SILException(silException.getMessage());
        } catch (Exception ex) {
            SILLogger.error(CashReceiptServiceConstants.CREATE_RECEIPT_LOG_FORMAT, className, "Exception :" + ex.getMessage());
            throw new Exception(CashReceiptServiceConstants.CREATE_RECEIPT_GENERIC_MSG);
        }
    }

    /**
     * This method is used to parse the incoming request.
     * 
     * @param exchange
     * @throws Exception
     */
    public void pasrseRequest(Exchange exchange) throws SILException {
        SILLogger.debug(CashReceiptServiceConstants.CREATE_RECEIPT_LOG_FORMAT, className, "Entering pasrseRequest()");
        try {
            String cafXmlFile = exchange.getIn().getBody(String.class);
            SILLogger.debug(CashReceiptServiceConstants.CREATE_RECEIPT_LOG_FORMAT, className, "File content is :" + cafXmlFile);
            CAFSaxParser cafSaxParser = new CAFSaxParser();
            CashAppliedFileMessage cashAppliedFileMessage = cafSaxParser.parseXml(cafXmlFile);
            SILLogger.debug(CashReceiptServiceConstants.CREATE_RECEIPT_LOG_FORMAT, className, "Values : " + cashAppliedFileMessage);
            exchange.setProperty(CashReceiptServiceConstants.CASH_RECEIPT_BEAN, cashAppliedFileMessage);
            int numOfenvelopes = 0;
            if (cashAppliedFileMessage != null && cashAppliedFileMessage.getEnvelopes() != null && cashAppliedFileMessage.getEnvelopes().size() > 0) {
                numOfenvelopes = cashAppliedFileMessage.getEnvelopes().size();
            }
            exchange.setProperty(CashReceiptServiceConstants.NUM_OF_ENVELOPE, numOfenvelopes);
            SILLogger.debug(CashReceiptServiceConstants.CREATE_RECEIPT_LOG_FORMAT, className, "Exiting pasrseRequest()");
        } catch (Exception ex) {
            SILLogger.error(CashReceiptServiceConstants.CREATE_RECEIPT_LOG_FORMAT, className, "Exception :" + ex.getMessage());
            throw new SILException(ex.getMessage());
        }
    }

    /**
     * This method is used to check number of payments the incoming request.
     * 
     * @param exchange
     * @throws Exception
     */
    public void checkNumberPayments(Exchange exchange) throws SILException {
        SILLogger.debug(CashReceiptServiceConstants.CREATE_RECEIPT_LOG_FORMAT, className, "Entering checkNumberPayments()");
        try {
            int envelopeIndex = (int) exchange.getProperty(CashReceiptServiceConstants.ENVELOPE_LOOP_INDEX);
            CashAppliedFileMessage cashAppliedFileMessage =
                    (CashAppliedFileMessage) exchange.getProperty(CashReceiptServiceConstants.CASH_RECEIPT_BEAN);
            if (cashAppliedFileMessage != null && cashAppliedFileMessage.getEnvelopes() != null && cashAppliedFileMessage.getEnvelopes().size() > 0) {
                Envelope envelope = cashAppliedFileMessage.getEnvelopes().get(envelopeIndex);
                int numOfPayments = 0;
                if (envelope.getPayments() != null && envelope.getPayments().size() > 0) {
                    numOfPayments = envelope.getPayments().size();
                }
                exchange.setProperty(CashReceiptServiceConstants.NUM_OF_PAYMENT, numOfPayments);
            }
            SILLogger.debug(CashReceiptServiceConstants.CREATE_RECEIPT_LOG_FORMAT, className, "Exiting checkNumberPayments()");
        } catch (Exception ex) {
            SILLogger.error(CashReceiptServiceConstants.CREATE_RECEIPT_LOG_FORMAT, className, "Exception :" + ex.getMessage());
            throw new SILException(ex.getMessage());
        }
    }

    /**
     * This method is used to get receipt details.
     * 
     * @param cashAppliedFileMessage
     * @return
     * @throws SILException
     */
    private ReceiptType getReceipt(Exchange exchange, CashAppliedFileMessage cashAppliedFileMessage, int envelopeLoopIndex, int paymentLoopIndex)
            throws SILException {
        SILLogger.debug(CashReceiptServiceConstants.CREATE_RECEIPT_LOG_FORMAT, className, "Entering getReceipt()");
        if (cashAppliedFileMessage != null && cashAppliedFileMessage.getEnvelopes() != null && cashAppliedFileMessage.getEnvelopes().size() > 0) {
            Envelope envelope = cashAppliedFileMessage.getEnvelopes().get(envelopeLoopIndex);
            Payment payment = envelope.getPayments().get(paymentLoopIndex);
            ReceiptType rType = new ReceiptType();
            setReceiptNumberInExchange(exchange, payment);
            ReceiptType.ReceiptDetails receiptDetails = this.getReceiptDetails(envelope, payment);
            List<ReceiptType.DepositDetails> depositDetails = this.getDepositDetails(payment);
            List<ApplicationType> applications = this.getApplications(payment);
            rType.setReceiptDetails(receiptDetails);
            rType.getDepositDetails().addAll(depositDetails);
            rType.getApplications().addAll(applications);
            return rType;
        } else {
            SILLogger.error(CashReceiptServiceConstants.CREATE_RECEIPT_LOG_FORMAT, className, CashReceiptServiceConstants.EMPTY_ENVELOPE);
            throw new SILException(CashReceiptServiceConstants.EMPTY_ENVELOPE);
        }
    }

    /**
     * This method is used to set the receipt number in the Exchange.
     * 
     * @param envelope
     */
    private void setReceiptNumberInExchange(Exchange exchange, Payment payment) {
        SILLogger.debug(CashReceiptServiceConstants.CREATE_RECEIPT_LOG_FORMAT, className, "Entering setReceiptNumberInExchange()");
        exchange.setProperty(CashReceiptServiceConstants.RECEIPT_NUMBER, payment.getUniqueChequeReference());
        SILLogger.debug(CashReceiptServiceConstants.CREATE_RECEIPT_LOG_FORMAT, className, "Entering setReceiptNumberInExchange()");
    }

    /**
     * This method is used to get application details for creating receipt.
     * 
     * @param envelope
     * @return
     */
    private List<ApplicationType> getApplications(Payment payment) {
        SILLogger.debug(CashReceiptServiceConstants.CREATE_RECEIPT_LOG_FORMAT, className, "Entering getApplications()");
        List<ApplicationType> applicationTypes = new ArrayList<ApplicationType>();
        ApplicationType aType = new ApplicationType();
        CurrencyIdentifierType currencyType = this.getCurrencyType();
        aType.setCurrencyType(currencyType);
        aType.setAmount(new BigDecimal(payment.getAmount()));
        applicationTypes.add(aType);
        return applicationTypes;
    }

    /**
     * This method is used to get deposit details.
     * 
     * @param envelope
     * @return
     */
    private List<DepositDetails> getDepositDetails(Payment payment) {
        SILLogger.debug(CashReceiptServiceConstants.CREATE_RECEIPT_LOG_FORMAT, className, "Entering getDepositDetails()");
        List<DepositDetails> depositDetails = new ArrayList<DepositDetails>();
        DepositDetails details = new DepositDetails();
        List<PaymentType> paymentTypes = this.getPaymentTypes(payment);
        CurrencyIdentifierType currencyType = this.getCurrencyType();
        CodeIdentifierType rateTypeCode = this.getRateTypeCode();
        details.getPaymentType().addAll(paymentTypes);
        details.setCurrencyType(currencyType);
        details.setRateTypeCode(rateTypeCode);
        details.setAmount(new BigDecimal(payment.getAmount()));
        depositDetails.add(details);
        return depositDetails;
    }

    /**
     * This method is used to get RateTypeCode.
     * 
     * @param envelope
     * @return
     */
    private CodeIdentifierType getRateTypeCode() {
        SILLogger.debug(CashReceiptServiceConstants.CREATE_RECEIPT_LOG_FORMAT, className, "Entering getRateTypeCode()");
        CodeIdentifierType rateTypeCode = new CodeIdentifierType();
        rateTypeCode.setCode(CashReceiptServiceConstants.RATE_TYPE_CODE);
        rateTypeCode.setCodeType(CashReceiptServiceConstants.RATE_TYPE_CODE_TYPE);
        return rateTypeCode;
    }

    /**
     * This method is used to get currency type.
     * 
     * @param cashAppliedFileMessage
     * @return
     */
    private CurrencyIdentifierType getCurrencyType() {
        SILLogger.debug(CashReceiptServiceConstants.CREATE_RECEIPT_LOG_FORMAT, className, "Entering getCurrencyType()");
        CurrencyIdentifierType currency = new CurrencyIdentifierType();
        currency.setCode(CommonConstants.CURRENCY_CODE);
        return currency;
    }

    /**
     * This method is used to get payment types.
     * 
     * @param envelope
     * @return
     */
    private List<PaymentType> getPaymentTypes(Payment payment) {
        SILLogger.debug(CashReceiptServiceConstants.CREATE_RECEIPT_LOG_FORMAT, className, "Entering getPaymentTypes()");
        List<PaymentType> paymentTypes = new ArrayList<PaymentType>();
        PaymentType pType = new PaymentType();
        CodeIdentifierType depositTypeCode = this.getDepositTypeCode();
        CountryIdentifierType country = this.getCountry();
        pType.setDepositTypeCode(depositTypeCode);
        pType.setCountry(country);
        pType.setBankAccountNumber(payment.getAccount().getBsbNumber().concat(payment.getAccount().getAccountNumber()));
        pType.setChequeNumber(payment.getChequeNumber());
        pType.setChequeAccountName(CashReceiptServiceConstants.CHEQUE_ACCOUNT_NAME);
        paymentTypes.add(pType);
        return paymentTypes;
    }

    /**
     * This method is used to get Country.
     * 
     * @param envelope
     * @return
     */
    private CountryIdentifierType getCountry() {
        SILLogger.debug(CashReceiptServiceConstants.CREATE_RECEIPT_LOG_FORMAT, className, "Entering getCountry()");
        CountryIdentifierType country = new CountryIdentifierType();
        country.setCode(CommonConstants.COUNTRY);
        return country;
    }

    /**
     * This method is used to get Deposit Type Code.
     * 
     * @param envelope
     * @return
     */
    private CodeIdentifierType getDepositTypeCode() {
        SILLogger.debug(CashReceiptServiceConstants.CREATE_RECEIPT_LOG_FORMAT, className, "Entering getDepositTypeCode()");
        CodeIdentifierType depositeTypeCode = new CodeIdentifierType();
        depositeTypeCode.setCode(CashReceiptServiceConstants.DEPOSITE_CODE);
        depositeTypeCode.setCodeType(CashReceiptServiceConstants.DEPOSITE_CODE_TYPE);
        return depositeTypeCode;
    }

    /**
     * This method is used to get receipt details.
     * 
     * @param envelope
     * @return the receipt details
     * @throws SILException
     */
    private ReceiptDetails getReceiptDetails(Envelope envelope, Payment payment) throws SILException {
        SILLogger.debug(CashReceiptServiceConstants.CREATE_RECEIPT_LOG_FORMAT, className, "Entering getReceiptDetails()");
        ReceiptDetails receiptDetails = new ReceiptDetails();
        receiptDetails.setReceiptNumber(payment.getUniqueChequeReference());
        receiptDetails.setReceiptBankAccount(CashReceiptServiceConstants.RECEIPT_BANK_ACCOUNT);
        XMLGregorianCalendar date =
                SILUtil.convertStringToXMLGregorianCalendar(envelope.getProcessedDate(), CashReceiptServiceConstants.DATE_TIME_FORMAT);
        receiptDetails.setEffectiveDate(date);
        receiptDetails.setStatusDate(date);
        receiptDetails.setDateEntered(date);
        return receiptDetails;
    }

    /**
     * This method is used to set header and body in the exchange message.
     * 
     * @param exchange
     * @param getClientRequestType
     */
    private void setHeaderAndBody(Exchange exchange, CreateReceiptRequestType createReceiptRequestType) {
        SILLogger.debug(CashReceiptServiceConstants.CREATE_RECEIPT_LOG_FORMAT, className, "Entering setHeaderAndBody()");
        Map<String, Object> mapHeaders = new HashMap<String, Object>();
        mapHeaders.put(CxfConstants.OPERATION_NAME, CashReceiptServiceConstants.CREATE_RECEIPT_OPERATION_NAME);
        mapHeaders.put(CxfConstants.OPERATION_NAMESPACE, CashReceiptServiceConstants.OPERATION_NAMESPACE);
        exchange.getIn().setHeaders(mapHeaders);
        exchange.getIn().setBody(createReceiptRequestType);
    }
}
