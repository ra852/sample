////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.cashreceiptservice.bean;

import java.util.List;

/**
 * The class {@code Envelope} does this.
 * 
 * @author U383754
 * @since 03/03/2016
 * @version 1.0
 */
public class Envelope {
    private String envelopeId;
    private String processedDate;
    private List<Payment> payments;
    private List<Correspondence> correspondences;

    /**
     * Accessor for property envelopeId.
     * 
     * @return envelopeId of type String
     */
    public String getEnvelopeId() {
        return envelopeId;
    }

    /**
     * Mutator for property envelopeId.
     * 
     * @return envelopeId of type String
     */
    public void setEnvelopeId(String envelopeId) {
        this.envelopeId = envelopeId;
    }

    /**
     * Accessor for property processedDate.
     * 
     * @return processedDate of type String
     */
    public String getProcessedDate() {
        return processedDate;
    }

    /**
     * Mutator for property processedDate.
     * 
     * @return processedDate of type String
     */
    public void setProcessedDate(String processedDate) {
        this.processedDate = processedDate;
    }

    /**
     * Accessor for property payments.
     * 
     * @return payments of type List<Payment>
     */
    public List<Payment> getPayments() {
        return payments;
    }

    /**
     * Mutator for property payments.
     * 
     * @return payments of type List<Payment>
     */
    public void setPayments(List<Payment> payments) {
        this.payments = payments;
    }

    /**
     * Accessor for property correspondences.
     * 
     * @return correspondences of type List<Correspondence>
     */
    public List<Correspondence> getCorrespondences() {
        return correspondences;
    }

    /**
     * Mutator for property correspondences.
     * 
     * @return correspondences of type List<Correspondence>
     */
    public void setCorrespondences(List<Correspondence> correspondences) {
        this.correspondences = correspondences;
    }

    @Override
    public String toString() {
        return this.envelopeId + " : " + this.processedDate + " : " + this.payments + " : " + this.correspondences;
    }
}
