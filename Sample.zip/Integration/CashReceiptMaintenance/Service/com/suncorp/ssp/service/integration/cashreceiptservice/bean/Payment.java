////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.cashreceiptservice.bean;

/**
 * The class {@code Payment} does this.
 * 
 * @author U383754
 * @since 03/03/2016
 * @version 1.0
 */
public class Payment {
    private String paymentType;
    private String paymentImageURL;
    private String amount;
    private String chequeNumber;
    private Account account;
    private String uniqueChequeReference;

    /**
     * Accessor for property paymentType.
     * 
     * @return paymentType of type String
     */
    public String getPaymentType() {
        return paymentType;
    }

    /**
     * Mutator for property paymentType.
     * 
     * @return paymentType of type String
     */
    public void setPaymentType(String paymentType) {
        this.paymentType = paymentType;
    }

    /**
     * Accessor for property paymentImageURL.
     * 
     * @return paymentImageURL of type String
     */
    public String getPaymentImageURL() {
        return paymentImageURL;
    }

    /**
     * Mutator for property paymentImageURL.
     * 
     * @return paymentImageURL of type String
     */
    public void setPaymentImageURL(String paymentImageURL) {
        this.paymentImageURL = paymentImageURL;
    }

    /**
     * Accessor for property amount.
     * 
     * @return amount of type String
     */
    public String getAmount() {
        return amount;
    }

    /**
     * Mutator for property amount.
     * 
     * @return amount of type String
     */
    public void setAmount(String amount) {
        this.amount = amount;
    }

    /**
     * Accessor for property chequeNumber.
     * 
     * @return chequeNumber of type String
     */
    public String getChequeNumber() {
        return chequeNumber;
    }

    /**
     * Mutator for property chequeNumber.
     * 
     * @return chequeNumber of type String
     */
    public void setChequeNumber(String chequeNumber) {
        this.chequeNumber = chequeNumber;
    }

    /**
     * Accessor for property account.
     * 
     * @return account of type String
     */
    public Account getAccount() {
        return account;
    }

    /**
     * Mutator for property account.
     * 
     * @return account of type String
     */
    public void setAccount(Account account) {
        this.account = account;
    }

    /**
     * Accessor for property uniqueChequeReference.
     * 
     * @return uniqueChequeReference of type String
     */
    public String getUniqueChequeReference() {
        return uniqueChequeReference;
    }

    /**
     * Mutator for property uniqueChequeReference.
     * 
     * @return uniqueChequeReference of type String
     */
    public void setUniqueChequeReference(String uniqueChequeReference) {
        this.uniqueChequeReference = uniqueChequeReference;
    }
    
    @Override
    public String toString() {
        return this.paymentType + " : " + this.paymentImageURL + " : " + this.amount + " : " + this.chequeNumber + " : " + this.account + " : " +
                this.uniqueChequeReference;
    }
}
