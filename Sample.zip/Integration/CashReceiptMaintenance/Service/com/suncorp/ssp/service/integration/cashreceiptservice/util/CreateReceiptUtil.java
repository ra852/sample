////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.cashreceiptservice.util;

import java.util.List;

import com.sonatacentral.service.v30.common.cashreceipt.CreateReceiptResponseType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.ReceiptIdentifierType;
import com.sonatacentral.service.v30.service.ValidationMessage;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.service.constants.cashreceiptservice.CashReceiptServiceConstants;
import com.suncorp.ssp.service.integration.cashreceiptservice.bean.CreateReceiptResponse;

/**
 * The class {@code CreateReceiptUtil} is used to fetch receipt details.
 * 
 * @author U383754
 * @since 04/03/2016
 * @version 1.0
 */
public class CreateReceiptUtil {
    private CreateReceiptResponseType createReceiptResponseType;
    private ReceiptIdentifierType receiptIdentifierType;

    /**
     * Default constructor.
     */
    public CreateReceiptUtil(CreateReceiptResponseType createReceiptResponseType) {
        this.createReceiptResponseType = createReceiptResponseType;
    }

    /**
     * 
     * This method is used set Outbound response.
     * 
     * @param createReceiptResponse
     * @throws SILException
     */
    public void setOutboundResponse(final CreateReceiptResponse createReceiptResponse) throws SILException {
        if (this.createReceiptResponseType != null && this.createReceiptResponseType.getReceipt() != null) {
            this.receiptIdentifierType = createReceiptResponseType.getReceipt();
            createReceiptResponse.setId(getId());
            createReceiptResponse.setReceiptNumber(getReceiptNumber());
        } else if (this.createReceiptResponseType.getValidationMessage() != null) {
            this.sendValidationMessages();
        }
    }

    /**
     * This method is used to send validation message to the consumer.
     * 
     * @throws SILException
     */
    private void sendValidationMessages() throws SILException {
        List<ValidationMessage> validationMessageList = this.createReceiptResponseType.getValidationMessage();
        for (ValidationMessage validationMessage : validationMessageList) {
            if (conditionCheck(validationMessage)) {
                throw new SILException(validationMessage.getMessage());
            }
        }
    }

    /**
     * Checks the conditions for validation messages.
     * 
     * @param validationMessage of type ValidationMessage
     * @return boolean
     */
    private boolean conditionCheck(ValidationMessage validationMessage) {
        return validationMessage != null &&
                validationMessage.getSeverity() != null &&
                (validationMessage.getSeverity().equalsIgnoreCase(CashReceiptServiceConstants.SEVERITY_ERROR) ||
                        validationMessage.getSeverity().equalsIgnoreCase(CashReceiptServiceConstants.SEVERITY_DEBUG) || validationMessage
                        .getSeverity().equalsIgnoreCase(CashReceiptServiceConstants.SEVERITY_FATAL));
    }

    /**
     * This method is used to receipt number.
     * 
     * @return
     */
    private String getReceiptNumber() {
        if (this.receiptIdentifierType.getReceiptNumber() != null) {
            return this.receiptIdentifierType.getReceiptNumber();
        }
        return "";
    }

    /**
     * This method is used to get ID.
     * 
     * @return
     */
    private String getId() {
        if (this.receiptIdentifierType != null && this.receiptIdentifierType.getId() != null) {
            return String.valueOf(this.receiptIdentifierType.getId());
        }
        return "";
    }
}
