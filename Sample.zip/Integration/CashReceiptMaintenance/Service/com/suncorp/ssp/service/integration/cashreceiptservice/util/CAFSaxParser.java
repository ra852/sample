////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.cashreceiptservice.util;

import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

import javax.xml.XMLConstants;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.cashreceiptservice.CashReceiptServiceConstants;
import com.suncorp.ssp.service.integration.cashreceiptservice.bean.Account;
import com.suncorp.ssp.service.integration.cashreceiptservice.bean.CashAppliedFileMessage;
import com.suncorp.ssp.service.integration.cashreceiptservice.bean.Correspondence;
import com.suncorp.ssp.service.integration.cashreceiptservice.bean.Envelope;
import com.suncorp.ssp.service.integration.cashreceiptservice.bean.Payment;

/**
 * The class {@code CAFSaxParser} is used for parsing XML.
 * 
 * @author U383754
 * @since 03/03/2016
 * @version 1.0
 */
public class CAFSaxParser extends DefaultHandler {
    private String className = "CAFSaxParser";
    private CashAppliedFileMessage cashAppliedFileMessage;
    private Envelope envelope;
    private List<Envelope> envelopes;
    private Payment payment;
    private List<Payment> payments;
    private Account account;
    private Correspondence correspondence;
    private List<Correspondence> correspondences;
    private String tempValue;

    /**
     * Default constructor.
     */
    public CAFSaxParser() {
    }

    /**
     * This method is used to parse the XML.
     * 
     * @param xml
     * @return
     * @throws SILException
     */
    public CashAppliedFileMessage parseXml(final String xml) throws SILException {
        SAXParserFactory factory = SAXParserFactory.newInstance();
        factory.setValidating(true);
        try {
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            factory.setFeature(CommonConstants.XML_DISALLOW_DOCTYPE_DECL_NS, true);
            factory.setFeature(CommonConstants.XML_EXT_GENERAL_ENTITIES_NS, false);
            factory.setFeature(CommonConstants.XML_EXT_PARAMETER_ENTITIES_NS, false);
            SAXParser parser = factory.newSAXParser();
            parser.parse(new InputSource(new StringReader(xml)), this);
            return this.cashAppliedFileMessage;
        } catch (ParserConfigurationException e) {
            SILLogger.error(CashReceiptServiceConstants.CREATE_RECEIPT_LOG_FORMAT, className, "Exception while poarsing XML :" + e.getMessage());
            throw new SILException("Exception while poarsing XML :" + e.getMessage());
        } catch (SAXException e) {
            SILLogger.error(CashReceiptServiceConstants.CREATE_RECEIPT_LOG_FORMAT, className, "Exception while poarsing XML :" + e.getMessage());
            throw new SILException("Exception while poarsing XML :" + e.getMessage());
        } catch (IOException e) {
            SILLogger.error(CashReceiptServiceConstants.CREATE_RECEIPT_LOG_FORMAT, className, "Exception while poarsing XML :" + e.getMessage());
            throw new SILException("Exception while poarsing XML :" + e.getMessage());
        }
    }

    @Override
    public void startElement(String s, String s1, String elementName, Attributes attributes) throws SAXException {
        initializeCashAppliedFileMessage(elementName);
        initializeEnvelope(elementName);
        initializeAccount(elementName);
        initializePayment(elementName);
        initializeCorrespondence(elementName);
    }

    /**
     * Initializes CashAppliedFileMessage.
     * 
     * @param elementName
     */
    private void initializeCashAppliedFileMessage(String elementName) {
        if (elementName.equalsIgnoreCase(CashReceiptServiceConstants.CASH_APPLIED_FILE_MESSAGE)) {
            this.cashAppliedFileMessage = new CashAppliedFileMessage();
            this.envelopes = new ArrayList<Envelope>();
        }
    }

    /**
     * Initializes Correspondence.
     * 
     * @param elementName
     */
    private void initializeCorrespondence(String elementName) {
        if (elementName.equalsIgnoreCase(CashReceiptServiceConstants.CORRESPONDENCE)) {
            this.correspondence = new Correspondence();
        }
    }

    /**
     * Initializes Payment.
     * 
     * @param elementName
     */
    private void initializePayment(String elementName) {
        if (elementName.equalsIgnoreCase(CashReceiptServiceConstants.PAYMENT)) {
            this.payment = new Payment();
        }
    }

    /**
     * Initializes Account.
     * 
     * @param elementName
     */
    private void initializeAccount(String elementName) {
        if (elementName.equalsIgnoreCase(CashReceiptServiceConstants.ACCOUNT)) {
            this.account = new Account();
        }
    }

    /**
     * Initializes Envelope.
     * 
     * @param elementName
     */
    private void initializeEnvelope(String elementName) {
        if (elementName.equalsIgnoreCase(CashReceiptServiceConstants.ENVELOPE)) {
            this.envelope = new Envelope();
            this.correspondences = new ArrayList<Correspondence>();
            this.payments = new ArrayList<Payment>();
        }
    }

    @Override
    public void endElement(String s, String s1, String element) throws SAXException {
        this.setSupplierBusiness(element);
        this.setMessageDate(element);
        this.setPaymentTotal(element);
        this.setPaymentCount(element);
        this.setMailBagLocation(element);
        this.setEnvelopeId(element);
        this.setProcessedDate(element);
        this.setPaymentType(element);
        this.setAmount(element);
        this.setChequeNumber(element);
        this.setUniqueChequeReference(element);
        this.setBsbNumber(element);
        this.setAccountNumber(element);
        this.setAccount(element);
        this.setPayment(element);
        this.setDocumentReferenceIdentifier(element);
        this.setAccountId(element);
        this.setAccountType(element);
        this.setDocumentId(element);
        this.setCorrespondence(element);

        this.setEnvelope(element);
        this.setEnvelopes(element);
    }

    /**
     * Sets Envelopes.
     * 
     * @param element
     */
    private void setEnvelopes(String element) {
        if (element.equalsIgnoreCase(CashReceiptServiceConstants.CASH_APPLIED_FILE_MESSAGE)) {
            this.cashAppliedFileMessage.setEnvelopes(this.envelopes);
        }
    }

    /**
     * This method is used to set Envelope.
     * 
     * @param element
     */
    private void setEnvelope(String element) {
        if (element.equalsIgnoreCase(CashReceiptServiceConstants.ENVELOPE)) {
            this.envelope.setPayments(this.payments);
            this.envelope.setCorrespondences(this.correspondences);
            this.envelopes.add(this.envelope);
        }
    }

    /**
     * Sets Correspondence.
     * 
     * @param element
     */
    private void setCorrespondence(String element) {
        if (element.equalsIgnoreCase(CashReceiptServiceConstants.CORRESPONDENCE)) {
            this.correspondences.add(this.correspondence);
        }
    }

    /**
     * Sets documentId.
     * 
     * @param element
     */
    private void setDocumentId(String element) {
        if (element.equalsIgnoreCase(CashReceiptServiceConstants.DOCUMENT_ID)) {
            this.correspondence.setDocumentID(tempValue);
        }
    }

    /**
     * Sets AccountType.
     * 
     * @param element
     */
    private void setAccountType(String element) {
        if (element.equalsIgnoreCase(CashReceiptServiceConstants.ACCOUNT_TYPE)) {
            this.correspondence.setAccountType(tempValue);
        }
    }

    /**
     * Sets Account ID.
     * 
     * @param element
     */
    private void setAccountId(String element) {
        if (element.equalsIgnoreCase(CashReceiptServiceConstants.ACCOUNT_ID)) {
            this.correspondence.setAccountId(tempValue);
        }
    }

    /**
     * Sets DocumentReferenceIdentifier.
     * 
     * @param element
     */
    private void setDocumentReferenceIdentifier(String element) {
        if (element.equalsIgnoreCase(CashReceiptServiceConstants.DOCUMNET_REF_IDENTIFIER)) {
            this.correspondence.setDocumentReferenceIdentifier(tempValue);
        }
    }

    /**
     * Sets Payment.
     * 
     * @param element
     */
    private void setPayment(String element) {
        if (element.equalsIgnoreCase(CashReceiptServiceConstants.PAYMENT)) {
            this.payments.add(this.payment);
        }
    }

    /**
     * Sets Account.
     * 
     * @param element
     */
    private void setAccount(String element) {
        if (element.equalsIgnoreCase(CashReceiptServiceConstants.ACCOUNT)) {
            this.payment.setAccount(this.account);
        }
    }

    /**
     * Sets AccountNumber.
     * 
     * @param element
     */
    private void setAccountNumber(String element) {
        if (element.equalsIgnoreCase(CashReceiptServiceConstants.ACCOUNT_NUMBER)) {
            this.account.setAccountNumber(this.tempValue);
        }
    }

    /**
     * Sets BSB number.
     * 
     * @param element
     */
    private void setBsbNumber(String element) {
        if (element.equalsIgnoreCase(CashReceiptServiceConstants.BSB_NUMBER)) {
            this.account.setBsbNumber(this.tempValue);
        }
    }

    /**
     * Sets UniqueChequeRef.
     * 
     * @param element
     */
    private void setUniqueChequeReference(String element) {
        if (element.equalsIgnoreCase(CashReceiptServiceConstants.UNIQUE_CHEQUE_REF)) {
            this.payment.setUniqueChequeReference(this.tempValue);
        }
    }

    /**
     * Sets ChequeNumber.
     * 
     * @param element
     */
    private void setChequeNumber(String element) {
        if (element.equalsIgnoreCase(CashReceiptServiceConstants.CHEQUE_NUMBER)) {
            this.payment.setChequeNumber(this.tempValue);
        }
    }

    /**
     * Sets Amount.
     * 
     * @param element
     */
    private void setAmount(String element) {
        if (element.equalsIgnoreCase(CashReceiptServiceConstants.AMOUNT)) {
            this.payment.setAmount(this.tempValue);
        }
    }

    /**
     * Sets PaymentType.
     * 
     * @param element
     */
    private void setPaymentType(String element) {
        if (element.equalsIgnoreCase(CashReceiptServiceConstants.PAYMENT_TYPE)) {
            this.payment.setPaymentType(this.tempValue);
        }
    }

    /**
     * Sets ProcessedDate.
     * 
     * @param element
     */
    private void setProcessedDate(String element) {
        if (element.equalsIgnoreCase(CashReceiptServiceConstants.PROCESSED_DATE)) {
            this.envelope.setProcessedDate(this.tempValue);
        }
    }

    /**
     * Sets EnvelopeId.
     * 
     * @param element
     */
    private void setEnvelopeId(String element) {
        if (element.equalsIgnoreCase(CashReceiptServiceConstants.ENVELOPE_ID)) {
            this.envelope.setEnvelopeId(this.tempValue);
        }
    }

    /**
     * Sets MailBagLocation.
     * 
     * @param element
     */
    private void setMailBagLocation(String element) {
        if (element.equalsIgnoreCase(CashReceiptServiceConstants.MAIL_BAG_LOCATION)) {
            this.cashAppliedFileMessage.setMailBagLocation(this.tempValue);
        }
    }

    /**
     * Sets PaymentCount.
     * 
     * @param element
     */
    private void setPaymentCount(String element) {
        if (element.equalsIgnoreCase(CashReceiptServiceConstants.PAYMENT_COUNT)) {
            this.cashAppliedFileMessage.setPaymentCount(this.tempValue);
        }

    }

    /**
     * Sets PaymentTotal.
     * 
     * @param element
     */
    private void setPaymentTotal(String element) {
        if (element.equalsIgnoreCase(CashReceiptServiceConstants.PAYMENT_TOTAL)) {
            this.cashAppliedFileMessage.setPaymentTotal(this.tempValue);
        }
    }

    /**
     * Sets messageDate.
     * 
     * @param element
     */
    private void setMessageDate(String element) {
        if (element.equalsIgnoreCase(CashReceiptServiceConstants.MESSAGE_DATE)) {
            this.cashAppliedFileMessage.setMessageDate(this.tempValue);
        }
    }

    /**
     * Sets supplierBusiness.
     * 
     * @param element
     */
    private void setSupplierBusiness(String element) {
        if (element.equalsIgnoreCase(CashReceiptServiceConstants.SUPPLIER_BUSINESS)) {
            this.cashAppliedFileMessage.setSupplierBusiness(this.tempValue);
        }
    }

    @Override
    public void characters(char[] charArray, int start, int length) throws SAXException {
        this.tempValue = new String(charArray, start, length);
    }
}
