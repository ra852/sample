////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.cashreceiptservice.bean;

/**
 * The class {@code CreateReceiptResponse} is used as a holder for storing receipt number.
 * 
 * @author U383754
 * @since 04/03/2016
 * @version 1.0
 */
public class CreateReceiptResponse {
    private String id;
    private String receiptNumber;

    /**
     * Accessor for property id.
     * 
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     * 
     * @return id of type String
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * Accessor for property receiptNumber.
     * 
     * @return receiptNumber of type String
     */
    public String getReceiptNumber() {
        return receiptNumber;
    }

    /**
     * Mutator for property receiptNumber.
     * 
     * @return receiptNumber of type String
     */
    public void setReceiptNumber(String receiptNumber) {
        this.receiptNumber = receiptNumber;
    }
}
