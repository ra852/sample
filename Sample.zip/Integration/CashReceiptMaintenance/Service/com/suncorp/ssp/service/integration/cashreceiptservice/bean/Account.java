////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.cashreceiptservice.bean;

/**
 * The class {@code Account} does this.
 * 
 * @author U383754
 * @since 03/03/2016
 * @version 1.0
 */
public class Account {
    private String bsbNumber;
    private String accountNumber;

    /**
     * Accessor for property bsbNumber.
     * 
     * @return bsbNumber of type String
     */
    public String getBsbNumber() {
        return bsbNumber;
    }

    /**
     * Mutator for property bsbNumber.
     * 
     * @return bsbNumber of type String
     */
    public void setBsbNumber(String bsbNumber) {
        this.bsbNumber = bsbNumber;
    }

    /**
     * Accessor for property accountNumber.
     * 
     * @return accountNumber of type String
     */
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * Mutator for property accountNumber.
     * 
     * @return accountNumber of type String
     */
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }
    
    @Override
    public String toString() {
        return this.bsbNumber + " : " + this.accountNumber;
    }
}
