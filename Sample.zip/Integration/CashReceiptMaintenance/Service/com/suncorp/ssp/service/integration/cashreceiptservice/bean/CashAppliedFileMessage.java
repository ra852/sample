////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.cashreceiptservice.bean;

import java.util.List;

/**
 * The class {@code CashAppliedFileMessage} does this.
 * 
 * @author U383754
 * @since 03/03/2016
 * @version 1.0
 */
public class CashAppliedFileMessage {
    private String supplierBusiness;
    private String messageDate;
    private String paymentTotal;
    private String paymentCount;
    private String mailBagLocation;
    private List<Envelope> envelopes;

    /**
     * Accessor for property supplierBusiness.
     * 
     * @return supplierBusiness of type String
     */
    public String getSupplierBusiness() {
        return supplierBusiness;
    }

    /**
     * Mutator for property supplierBusiness.
     * 
     * @return supplierBusiness of type String
     */
    public void setSupplierBusiness(String supplierBusiness) {
        this.supplierBusiness = supplierBusiness;
    }

    /**
     * Accessor for property messageDate.
     * 
     * @return messageDate of type String
     */
    public String getMessageDate() {
        return messageDate;
    }

    /**
     * Mutator for property messageDate.
     * 
     * @return messageDate of type String
     */
    public void setMessageDate(String messageDate) {
        this.messageDate = messageDate;
    }

    /**
     * Accessor for property paymentTotal.
     * 
     * @return paymentTotal of type String
     */
    public String getPaymentTotal() {
        return paymentTotal;
    }

    /**
     * Mutator for property paymentTotal.
     * 
     * @return paymentTotal of type String
     */
    public void setPaymentTotal(String paymentTotal) {
        this.paymentTotal = paymentTotal;
    }

    /**
     * Accessor for property paymentCount.
     * 
     * @return paymentCount of type String
     */
    public String getPaymentCount() {
        return paymentCount;
    }

    /**
     * Mutator for property paymentCount.
     * 
     * @return paymentCount of type String
     */
    public void setPaymentCount(String paymentCount) {
        this.paymentCount = paymentCount;
    }

    /**
     * Accessor for property mailBagLocation.
     * 
     * @return mailBagLocation of type String
     */
    public String getMailBagLocation() {
        return mailBagLocation;
    }

    /**
     * Mutator for property mailBagLocation.
     * 
     * @return mailBagLocation of type String
     */
    public void setMailBagLocation(String mailBagLocation) {
        this.mailBagLocation = mailBagLocation;
    }

    /**
     * Accessor for property envelopes.
     * 
     * @return envelopes of type List<Envelope>
     */
    public List<Envelope> getEnvelopes() {
        return this.envelopes;
    }

    /**
     * Mutator for property envelopes.
     * 
     * @return envelopes of type List<Envelope>
     */
    public void setEnvelopes(List<Envelope> envelopes) {
        this.envelopes = envelopes;
    }

    @Override
    public String toString() {
        return this.supplierBusiness + " : " + this.messageDate + " : " + this.paymentTotal + " : " + this.paymentCount + " : " +
                this.mailBagLocation + " : " + this.envelopes;
    }
}
