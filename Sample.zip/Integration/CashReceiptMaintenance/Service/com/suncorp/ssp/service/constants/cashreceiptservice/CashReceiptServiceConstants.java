////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.constants.cashreceiptservice;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * The class {@code CashReceiptServiceConstants} is used as common constants class for cash receipt service.
 * 
 * @author U383754
 * @since 02/03/2016
 * @version 1.0
 */
public abstract class CashReceiptServiceConstants {
    // Cash receipt
    public static final String OPERATION_NAMESPACE = "http://www.sonatacentral.com/service/v30/common/cashreceipt";
    public static final String DATE_TIME_FORMAT = "yyyyMMdd";
    public static final String SEVERITY_ERROR = "ERROR";
    public static final String SEVERITY_DEBUG = "DEBUG";
    public static final String SEVERITY_FATAL = "FATAL";
    public static final String SEVERITY_INFO = "INFO";

    // Create receipt
    public static final String CREATE_RECEIPT_LOG_FORMAT = "CashReceiptService_CreateReceipt_{}_".concat(
            new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat("_{}");
    public static final String EMPTY_FILE_MSG = "File is empty;Please provide valid file.";
    public static final Object CREATE_RECEIPT_OPERATION_NAME = "createReceipt";
    public static final String EMPTY_ENVELOPE = "Envelop is empty. Can't process the request for creating cash receipt.";
    public static final String CREATE_RECEIPT_RESPONSE_CLASS_NAME =
            "com.suncorp.ssp.service.integration.cashreceiptservice.bean.CreateReceiptResponse";
    public static final String CREATE_RECEIPT_GENERIC_MSG = "Create receipt functionality couldn't get processed.";

    // CAF SAX parser
    public static final String SUPPLIER_BUSINESS = "SupplierBusiness";
    public static final String MESSAGE_DATE = "MessageDate";
    public static final String PAYMENT_TOTAL = "PaymentTotal";;
    public static final String PAYMENT_COUNT = "PaymentCount";
    public static final String MAIL_BAG_LOCATION = "MailBagLocation";
    public static final String ENVELOPE_ID = "EnvelopeId";
    public static final String PROCESSED_DATE = "ProcessedDate";
    public static final String PAYMENT_TYPE = "PaymentType";
    public static final String AMOUNT = "Amount";
    public static final String CHEQUE_NUMBER = "ChequeNumber";
    public static final String UNIQUE_CHEQUE_REF = "UniqueChequeReference";
    public static final String BSB_NUMBER = "BSBNumber";
    public static final String ACCOUNT_NUMBER = "AccountNumber";
    public static final String ACCOUNT = "Account";
    public static final String PAYMENT = "Payment";
    public static final String DOCUMNET_REF_IDENTIFIER = "DocumentReferenceIdentifier";
    public static final String ACCOUNT_ID = "AccountId";
    public static final String ACCOUNT_TYPE = "AccountType";
    public static final String DOCUMENT_ID = "DocumentID";
    public static final String CORRESPONDENCE = "Correspondence";
    public static final String ENVELOPE = "Envelope";
    public static final String CASH_APPLIED_FILE_MESSAGE = "CashAppliedFileMessage";

    // Hard code values used for create receipt
    public static final String RECEIPT_BANK_ACCOUNT = "032016559980"; // For production use "032016559980" and UAT "966132594562".
    public static final String CHEQUE_ACCOUNT_NAME = "Cheque";
    public static final String DEPOSITE_CODE = "BANK";
    public static final String DEPOSITE_CODE_TYPE = "DPTY";
    public static final String RATE_TYPE_CODE = "BUY";
    public static final String RATE_TYPE_CODE_TYPE = "CURT";
    public static final String CASH_RECEIPT_BEAN = "CASH_RECEIPT_BEAN";
    public static final String NUM_OF_ENVELOPE = "NUM_OF_ENVELOPE";
    public static final String RECEIPT_NUMBER = "RECEIPT_NUMBER";
    public static final String ENVELOPE_LOOP_INDEX = "envelopeLoopIndex";
    public static final String NUM_OF_PAYMENT = "NUM_OF_PAYMENT";
    public static final String PAYMENT_LOOP_INDEX = "paymentLoopIndex";
    public static final String CASH_RECEIPT_RES_MSG = "CASH_RECEIPT_RES_MSG";

}
