////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.cashreceiptservice.bean;

/**
 * The class {@code Correspondence} does this.
 * 
 * @author U383754
 * @since 03/03/2016
 * @version 1.0
 */
public class Correspondence {
    private String documentReferenceIdentifier;
    private String accountId;
    private String accountType;
    private String correspondenceType;
    private String correspondenceImageURL;
    private String partyType;
    private String partyId;
    private String partyName;
    private String fund;
    private String subFund;
    private String product;
    private String documentID;
    private String adviserID;
    private String receivedDate;

    /**
     * Accessor for property documentReferenceIdentifier.
     * 
     * @return documentReferenceIdentifier of type String
     */
    public String getDocumentReferenceIdentifier() {
        return documentReferenceIdentifier;
    }

    /**
     * Mutator for property documentReferenceIdentifier.
     * 
     * @return documentReferenceIdentifier of type String
     */
    public void setDocumentReferenceIdentifier(String documentReferenceIdentifier) {
        this.documentReferenceIdentifier = documentReferenceIdentifier;
    }

    /**
     * Accessor for property accountId.
     * 
     * @return accountId of type String
     */
    public String getAccountId() {
        return accountId;
    }

    /**
     * Mutator for property accountId.
     * 
     * @return accountId of type String
     */
    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    /**
     * Accessor for property accountType.
     * 
     * @return accountType of type String
     */
    public String getAccountType() {
        return accountType;
    }

    /**
     * Mutator for property accountType.
     * 
     * @return accountType of type String
     */
    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }
    
    /**
     * Accessor for property correspondenceType.
     * 
     * @return correspondenceType of type String
     */
    public String getCorrespondenceType() {
        return correspondenceType;
    }

    /**
     * Mutator for property correspondenceType.
     * 
     * @return correspondenceType of type String
     */
    public void setCorrespondenceType(String correspondenceType) {
        this.correspondenceType = correspondenceType;
    }

    /**
     * Accessor for property correspondenceImageURL.
     * 
     * @return correspondenceImageURL of type String
     */
    public String getCorrespondenceImageURL() {
        return correspondenceImageURL;
    }

    /**
     * Mutator for property correspondenceImageURL.
     * 
     * @return correspondenceImageURL of type String
     */
    public void setCorrespondenceImageURL(String correspondenceImageURL) {
        this.correspondenceImageURL = correspondenceImageURL;
    }

    /**
     * Accessor for property partyType.
     * 
     * @return partyType of type String
     */
    public String getPartyType() {
        return partyType;
    }

    /**
     * Mutator for property partyType.
     * 
     * @return partyType of type String
     */
    public void setPartyType(String partyType) {
        this.partyType = partyType;
    }

    /**
     * Accessor for property partyId.
     * 
     * @return partyId of type String
     */
    public String getPartyId() {
        return partyId;
    }

    /**
     * Mutator for property partyId.
     * 
     * @return partyId of type String
     */
    public void setPartyId(String partyId) {
        this.partyId = partyId;
    }

    /**
     * Accessor for property partyName.
     * 
     * @return partyName of type String
     */
    public String getPartyName() {
        return partyName;
    }

    /**
     * Mutator for property partyName.
     * 
     * @return partyName of type String
     */
    public void setPartyName(String partyName) {
        this.partyName = partyName;
    }

    /**
     * Accessor for property fund.
     * 
     * @return fund of type String
     */
    public String getFund() {
        return fund;
    }

    /**
     * Mutator for property fund.
     * 
     * @return fund of type String
     */
    public void setFund(String fund) {
        this.fund = fund;
    }

    /**
     * Accessor for property subFund.
     * 
     * @return subFund of type String
     */
    public String getSubFund() {
        return subFund;
    }

    /**
     * Mutator for property subFund.
     * 
     * @return subFund of type String
     */
    public void setSubFund(String subFund) {
        this.subFund = subFund;
    }

    /**
     * Accessor for property product.
     * 
     * @return product of type String
     */
    public String getProduct() {
        return product;
    }

    /**
     * Mutator for property product.
     * 
     * @return product of type String
     */
    public void setProduct(String product) {
        this.product = product;
    }

    /**
     * Accessor for property documentID.
     * 
     * @return documentID of type String
     */
    public String getDocumentID() {
        return documentID;
    }

    /**
     * Mutator for property documentID.
     * 
     * @return documentID of type String
     */
    public void setDocumentID(String documentID) {
        this.documentID = documentID;
    }

    /**
     * Accessor for property adviserID.
     * 
     * @return adviserID of type String
     */
    public String getAdviserID() {
        return adviserID;
    }

    /**
     * Mutator for property adviserID.
     * 
     * @return adviserID of type String
     */
    public void setAdviserID(String adviserID) {
        this.adviserID = adviserID;
    }

    /**
     * Accessor for property receivedDate.
     * 
     * @return receivedDate of type String
     */
    public String getReceivedDate() {
        return receivedDate;
    }

    /**
     * Mutator for property receivedDate.
     * 
     * @return receivedDate of type String
     */
    public void setReceivedDate(String receivedDate) {
        this.receivedDate = receivedDate;
    }

    @Override
    public String toString() {
        return this.documentReferenceIdentifier + " : " + this.accountId + " : " + this.accountType + this.correspondenceType + " : " +
                this.correspondenceImageURL + " : " + this.partyType + " : " + this.partyId + " : " + this.partyName + " : " + this.fund + " : " +
                this.subFund + " : " + this.product + " : " + this.documentID + " : " + this.adviserID + " : " + this.receivedDate;
    }
}
