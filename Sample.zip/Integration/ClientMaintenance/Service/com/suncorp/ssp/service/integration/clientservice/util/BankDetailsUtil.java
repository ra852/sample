////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.clientservice.util;

import java.util.Iterator;
import java.util.List;

import com.sonatacentral.service.v30.common.client.GetClientResponseType;
import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.BankAccountDetailType;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.clientservice.ClientServiceConstants;
import com.suncorp.ssp.service.integration.clientservice.bean.ClientBankDetailType;

/**
 * The class {@code BankDetailsUtil} does this.
 * 
 * @author U383754
 * @since 28/10/2015
 * @version 1.0
 */
public class BankDetailsUtil {
    private GetClientResponseType getClientResponseType;
    private BankAccountDetailType bankAccountDetailType;

    public BankDetailsUtil(GetClientResponseType getClientResponseType) {
        this.getClientResponseType = getClientResponseType;
    }

    /**
     * 
     * This method is used to get bank details of client.
     * 
     * @param bankDetails
     */
    public void getBankDetails(List<ClientBankDetailType> bankDetails) {
        SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "BankDetailsUtil", "Entering in getBankDetails.");
        if (this.getClientResponseType != null && this.getClientResponseType.getBankAccount() != null &&
                this.getClientResponseType.getBankAccount().size() != 0) {
            List<BankAccountDetailType> bankAccountDetailTypeList = this.getClientResponseType.getBankAccount();
            Iterator<BankAccountDetailType> bankAccountTypeIterator = bankAccountDetailTypeList.iterator();
            while (bankAccountTypeIterator.hasNext()) {
                this.bankAccountDetailType = bankAccountTypeIterator.next();
                ClientBankDetailType clientBankDetailType1Obj = new ClientBankDetailType();
                clientBankDetailType1Obj.setBankId(this.getBankId());
                clientBankDetailType1Obj.setOperation(this.getOperation());
                clientBankDetailType1Obj.setBankAccount(this.getBankAccount());
                clientBankDetailType1Obj.setBankName(this.getBankName());
                clientBankDetailType1Obj.setBranchName(this.getBranchName());
                clientBankDetailType1Obj.setBsbNumber(this.getBsbNumber());
                clientBankDetailType1Obj.setAccountName(this.getAccountName());
                // adding object to list
                bankDetails.add(clientBankDetailType1Obj);
            }
        } else {
            // setting default values
            this.setDefaultValues(bankDetails);
        }
        SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "BankDetailsUtil", "Exiting in getBankDetails.");
    }

    /**
     * This method is used to get Bank account name.
     * 
     * @return the name of Bank account name
     */
    private String getAccountName() {
        if (this.bankAccountDetailType != null) {
            return bankAccountDetailType.getAccountName();
        }
        return "";
    }

    /**
     * Accessor for property bankId.
     * 
     * @return bankId of type String
     */
    private String getBankId() {
        if (this.bankAccountDetailType != null) {
            return Long.toString(bankAccountDetailType.getId());
        }
        return "";
    }

    /**
     * Accessor for property operation.
     * 
     * @return operation of type String
     */
    private String getOperation() {
        return ClientServiceConstants.NONE;
    }

    /**
     * Accessor for property bankAccount.
     * 
     * @return bankAccount of type String
     */
    private String getBankAccount() {
        if (this.bankAccountDetailType != null) {
            return bankAccountDetailType.getAccountNumber();
        }
        return "";
    }

    /**
     * Accessor for property bankName.
     * 
     * @return bankName of type String
     */
    private String getBankName() {
        if (this.bankAccountDetailType != null) {
            return bankAccountDetailType.getBankName();
        }
        return "";
    }

    /**
     * Accessor for property branchName.
     * 
     * @return branchName of type String
     */
    private String getBranchName() {
        if (this.bankAccountDetailType != null) {
            return bankAccountDetailType.getBankBranchName();
        }
        return "";
    }

    /**
     * Accessor for property bsbNumber.
     * 
     * @return bsbNumber of type String
     */
    private String getBsbNumber() {
        if (this.bankAccountDetailType != null) {
            return bankAccountDetailType.getBsbNumber();
        }
        return "";
    }

    /**
     * Does this.
     * 
     * @param bankDetails
     */
    private void setDefaultValues(List<ClientBankDetailType> bankDetails) {
        ClientBankDetailType clientBankDetailType2Obj = new ClientBankDetailType();
        clientBankDetailType2Obj.setBankId("");
        clientBankDetailType2Obj.setOperation("");
        clientBankDetailType2Obj.setBankAccount("");
        clientBankDetailType2Obj.setBankName("");
        clientBankDetailType2Obj.setBranchName("");
        clientBankDetailType2Obj.setBsbNumber("");
        clientBankDetailType2Obj.setAccountName("");
        bankDetails.add(clientBankDetailType2Obj);
    }
}
