////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.clientservice.util;

import java.util.Iterator;
import java.util.List;

import com.sonatacentral.service.v30.common.client.GetClientResponseType;
import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.AddressDetailsType;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.clientservice.ClientServiceConstants;
import com.suncorp.ssp.service.integration.clientservice.bean.ClientAddressType;

/**
 * The class {@code AddressDetailsUtil} does this.
 * 
 * @author U383754
 * @since 28/10/2015
 * @version 1.0
 */
public class AddressDetailsUtil {
    private GetClientResponseType getClientResponseType;
    private AddressDetailsType addressDetailsType;

    public AddressDetailsUtil(AddressDetailsType address) {
        this.addressDetailsType = address;
    }

    public AddressDetailsUtil(GetClientResponseType getClientResponseType) {
        this.getClientResponseType = getClientResponseType;
    }

    /**
     * 
     * This method is used to get address details of client.
     * 
     * @param addressDetails
     */
    public void getAddressDetails(List<ClientAddressType> addressDetails) {
        SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "AddressDetailsUtil", "Entering in getAddressDetails.");
        if (this.getClientResponseType != null && this.getClientResponseType.getAddress() != null &&
                this.getClientResponseType.getAddress().size() != 0) {
            List<AddressDetailsType> addressDetailsTypeList = this.getClientResponseType.getAddress();
            Iterator<AddressDetailsType> addressDetailsTypeIterator = addressDetailsTypeList.iterator();

            while (addressDetailsTypeIterator.hasNext()) {
                this.addressDetailsType = addressDetailsTypeIterator.next();
                boolean isLastKnownAddress = this.isLastKnownAddress();
                if (isLastKnownAddress) {
                    ClientAddressType clientAddressType1Obj = new ClientAddressType();
                    this.constructClientAddressTypeObj(clientAddressType1Obj);
                    addressDetails.add(clientAddressType1Obj);
                }
            }
        } else {
            // setting default values
            this.setDefaultValues(addressDetails);
        }
        SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "AddressDetailsUtil", "Exiting in getAddressDetails.");
    }

    /**
     * This method is used to check whether address is LKA or different, if LKA return false else true.
     * 
     * @return boolean flag, return false if LKA else true
     */
    private boolean isLastKnownAddress() {
        if (this.addressDetailsType != null && this.addressDetailsType.getTypeCode() != null &&
                this.addressDetailsType.getTypeCode().getCode() != null &&
                this.addressDetailsType.getTypeCode().getCode().equalsIgnoreCase(ClientServiceConstants.GET_CLIENT_ADDRESS_CODE)) {
            return false;
        }
        return true;
    }

    /**
     * 
     * This method is used to construct client address object.
     * 
     * @return
     */
    public void constructClientAddressTypeObj(ClientAddressType clientAddressType1Obj) {
        clientAddressType1Obj.setAddressId(this.getAddressId());
        clientAddressType1Obj.setOperation(this.getOperation());
        clientAddressType1Obj.setAddressCodeType(this.getAddressCodeType());
        clientAddressType1Obj.setAddressCode(this.getAddressCode());
        clientAddressType1Obj.setPrimaryType(this.getPrimaryType());
        clientAddressType1Obj.setPrimaryFlag(this.getPrimaryFlag());
        clientAddressType1Obj.setLine1(this.getLine1());
        clientAddressType1Obj.setLine2(this.getLine2());
        clientAddressType1Obj.setLine3(this.getLine3());
        clientAddressType1Obj.setLine4(this.getLine4());
        clientAddressType1Obj.setSuburb(this.getSuburb());
        clientAddressType1Obj.setCity(this.getCity());
        clientAddressType1Obj.setPostcode(this.getPostcode());
        clientAddressType1Obj.setState(this.getState());
        clientAddressType1Obj.setCountry(this.getCountry());
        clientAddressType1Obj.setCareOf(this.addressDetailsType.getCareOf());
    }

    /**
     * Accessor for property addressId.
     * 
     * @return addressId of type String
     */
    private String getAddressId() {
        if (this.addressDetailsType != null) {
            return Long.toString(this.addressDetailsType.getId());
        }
        return "";
    }

    /**
     * Accessor for property operation.
     * 
     * @return operation of type String
     */
    private String getOperation() {
        return ClientServiceConstants.NONE;
    }

    /**
     * Accessor for property addressCodeType.
     * 
     * @return addressCodeType of type String
     */
    private String getAddressCodeType() {
        if (this.addressDetailsType != null && this.addressDetailsType.getTypeCode() != null &&
                this.addressDetailsType.getTypeCode().getCodeType() != null) {
            return this.addressDetailsType.getTypeCode().getCodeType();
        }
        return "";
    }

    /**
     * Accessor for property addressCode.
     * 
     * @return addressCode of type String
     */
    private String getAddressCode() {
        if (this.addressDetailsType != null && this.addressDetailsType.getTypeCode() != null &&
                this.addressDetailsType.getTypeCode().getCode() != null) {
            return this.addressDetailsType.getTypeCode().getCode();
        }
        return "";
    }

    /**
     * Accessor for property primaryType.
     * 
     * @return primaryType of type String
     */
    private String getPrimaryType() {
        if (this.addressDetailsType != null) {
            return Boolean.toString(this.addressDetailsType.isPrimaryType());
        }
        return "";
    }

    /**
     * Accessor for property primaryFlag.
     * 
     * @return primaryFlag of type String
     */
    private String getPrimaryFlag() {
        if (this.addressDetailsType != null) {
            return Boolean.toString(this.addressDetailsType.isPrimary());
        }
        return "";
    }

    /**
     * Accessor for property line1.
     * 
     * @return line1 of type String
     */
    private String getLine1() {
        if (this.addressDetailsType != null) {
            return this.addressDetailsType.getLine1();
        }
        return "";
    }

    /**
     * Accessor for property line2.
     * 
     * @return line2 of type String
     */
    private String getLine2() {
        if (this.addressDetailsType != null) {
            return this.addressDetailsType.getLine2();
        }
        return "";
    }

    /**
     * Accessor for property line3.
     * 
     * @return line3 of type String
     */
    private String getLine3() {
        if (this.addressDetailsType != null) {
            return this.addressDetailsType.getLine3();
        }
        return "";
    }

    /**
     * Accessor for property line4.
     * 
     * @return line4 of type String
     */
    private String getLine4() {
        if (this.addressDetailsType != null) {
            return this.addressDetailsType.getLine4();
        }
        return "";
    }

    /**
     * Accessor for property suburb.
     * 
     * @return suburb of type String
     */
    private String getSuburb() {
        if (this.addressDetailsType != null) {
            return this.addressDetailsType.getSuburb();
        }
        return "";
    }

    /**
     * Accessor for property city.
     * 
     * @return city of type String
     */
    private String getCity() {
        if (this.addressDetailsType != null) {
            return this.addressDetailsType.getCity();
        }
        return "";

    }

    /**
     * Accessor for property postcode.
     * 
     * @return postcode of type String
     */
    private String getPostcode() {
        if (this.addressDetailsType != null) {
            return this.addressDetailsType.getPostcode();
        }
        return "";
    }

    /**
     * Accessor for property state.
     * 
     * @return state of type String
     */
    private String getState() {
        if (this.addressDetailsType != null && this.addressDetailsType.getState() != null && this.addressDetailsType.getState().getCode() != null) {
            return this.addressDetailsType.getState().getCode();
        }
        return "";
    }

    /**
     * Accessor for property country.
     * 
     * @return country of type String
     */
    private String getCountry() {
        if (this.addressDetailsType != null && this.addressDetailsType.getCountry() != null && 
                this.addressDetailsType.getCountry().getCode() != null) {
            return this.addressDetailsType.getCountry().getCode();
        }
        return "";
    }

    /**
     * Setting Address List Default Values.
     * 
     * @param addressDetails
     */
    public void setDefaultValues(List<ClientAddressType> addressDetails) {
        ClientAddressType clientAddressType2Obj = new ClientAddressType();
        addressDetails.add(setDefaultAddressValues(clientAddressType2Obj));
    }

    /**
     * Setting Address Default Values.
     * 
     * @param clientAddressType2Obj
     * @return
     */
    public ClientAddressType setDefaultAddressValues(ClientAddressType clientAddressType2Obj) {
        clientAddressType2Obj.setAddressId("");
        clientAddressType2Obj.setOperation("");
        clientAddressType2Obj.setAddressCodeType("");
        clientAddressType2Obj.setAddressCode("");
        clientAddressType2Obj.setPrimaryType("");
        clientAddressType2Obj.setPrimaryFlag("");
        clientAddressType2Obj.setLine1("");
        clientAddressType2Obj.setLine2("");
        clientAddressType2Obj.setLine3("");
        clientAddressType2Obj.setLine4("");
        clientAddressType2Obj.setSuburb("");
        clientAddressType2Obj.setCity("");
        clientAddressType2Obj.setPostcode("");
        clientAddressType2Obj.setState("");
        clientAddressType2Obj.setCountry("");
        clientAddressType2Obj.setCareOf("");
        return clientAddressType2Obj;
    }
}
