////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package com.suncorp.ssp.service.integration.clientservice.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.suncorp.ssp.common.bean.SILErrorMessage;

/**
 * The class {@code GetClientResponse} is a java bean consisting of all the properties related to client details, to be used for constructing client
 * response.
 * 
 * @author U383754
 * @since 2015-10-01
 * @version 1.0
 */
@XmlRootElement(name = "GetClientResponse")
public class GetClientResponse extends SILErrorMessage {
    private String clientId;
    private String title;
    private String gender;
    private String maritalStatus;
    private String firstName;
    private String middleName;
    private String lastName;
    private String dateOfBirth;
    private OccupationIdentifierBean occupation;
    private String mobileNumber;
    private String homeNumber;
    private String workNumber;
    private List<ClientBankDetailType> bankDetails;
    private List<ClientAddressType> addressDetails;
    private List<ClientAdvisorDetailType> advisorDetails;
    private List<ClientContextDetailType> clientContextDetails;
    private List<ClientWorkDeclarationType> workDeclarationDetails;
    private TfnConsentDetailsType tfnConsentDetails;
    private CountryNameType countryName;
    private String errorCode;
    private List<ExternalReferenceDetailType> externalReferenceTypeDetails;
    private String contactName;
    private CodeIdentifier clientType;
    private List<NoteBean> notes;
    private CodeIdentifier preferredRisk;
    private String clientTfn;
    private AustraliaDetails australia;

    /**
     * Accessor for property clientID.
     * 
     * @return clientID of type String
     */
    public String getClientId() {
        return clientId;
    }

    /**
     * Mutator for property clientID.
     * 
     * @param clientID of type String
     */
    @XmlElement(name = "clientId")
    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    /**
     * Accessor for property title.
     * 
     * @return title of type String
     */
    public String getTitle() {
        return title;
    }

    /**
     * Mutator for property title.
     * 
     * @param title of type String
     */
    @XmlElement(name = "title")
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * Accessor for property gender.
     * 
     * @return gender of type String
     */
    public String getGender() {
        return gender;
    }

    /**
     * Mutator for property gender.
     * 
     * @param gender of type String
     */
    @XmlElement(name = "gender")
    public void setGender(String gender) {
        this.gender = gender;
    }

    /**
     * Accessor for property maritalStatus.
     * 
     * @return maritalStatus of type String
     */
    public String getMaritalStatus() {
        return maritalStatus;
    }

    /**
     * Mutator for property maritalStatus.
     * 
     * @param maritalStatus of type String
     */
    @XmlElement(name = "maritalStatus")
    public void setMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
    }

    /**
     * Accessor for property firstName.
     * 
     * @return firstName of type String
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Mutator for property firstName.
     * 
     * @param firstName of type String
     */
    @XmlElement(name = "firstName")
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * Accessor for property middleName.
     * 
     * @return middleName of type String
     */
    public String getMiddleName() {
        return middleName;
    }

    /**
     * Mutator for property middleName.
     * 
     * @param middleName of type String
     */
    @XmlElement(name = "middleName")
    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    /**
     * Accessor for property lastName.
     * 
     * @return lastName of type String
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Mutator for property lastName.
     * 
     * @param lastName of type String
     */
    @XmlElement(name = "lastName")
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * Accessor for property dateOfBirth.
     * 
     * @return dateOfBirth of type String
     */
    public String getDateOfBirth() {
        return dateOfBirth;
    }

    /**
     * Mutator for property dateOfBirth.
     * 
     * @param dateOfBirth of type String
     */
    @XmlElement(name = "dob")
    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    /**
     * Accessor for property occupation.
     * 
     * @return occupation of type OccupationIdentifierBean
     */
    public OccupationIdentifierBean getOccupation() {
        return occupation;
    }

    /**
     * Mutator for property occupation.
     * 
     * @param occupation of type OccupationIdentifierBean
     */
    @XmlElement(name = "occupation")
    public void setOccupation(OccupationIdentifierBean occupation) {
        this.occupation = occupation;
    }

    /**
     * Accessor for property mobileNumber.
     * 
     * @return mobileNumber of type String
     */
    public String getMobileNumber() {
        return mobileNumber;
    }

    /**
     * Mutator for property mobileNumber.
     * 
     * @param mobileNumber of type String
     */
    @XmlElement(name = "mobileNumber")
    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    /**
     * Accessor for property homeNumber.
     * 
     * @return homeNumber of type String
     */
    public String getHomeNumber() {
        return homeNumber;
    }

    /**
     * Mutator for property homeNumber.
     * 
     * @param homeNumber of type String
     */
    @XmlElement(name = "homeNumber")
    public void setHomeNumber(String homeNumber) {
        this.homeNumber = homeNumber;
    }

    /**
     * Accessor for property workNumber.
     * 
     * @return workNumber of type String
     */
    public String getWorkNumber() {
        return workNumber;
    }

    /**
     * Mutator for property workNumber.
     * 
     * @param workNumber of type String
     */
    @XmlElement(name = "workNumber")
    public void setWorkNumber(String workNumber) {
        this.workNumber = workNumber;
    }

    /**
     * Accessor for property bankDetails.
     * 
     * @return bankDetails of type List<ClientBankDetailType>
     */
    public List<ClientBankDetailType> getBankDetails() {
        return bankDetails;
    }

    /**
     * Mutator for property bankDetails.
     * 
     * @return bankDetails of type List<ClientBankDetailType>
     */
    @XmlElement(name = "bankDetails")
    public void setBankDetails(List<ClientBankDetailType> bankDetails) {
        this.bankDetails = bankDetails;
    }

    /**
     * Accessor for property addressDetails.
     * 
     * @return addressDetails of type List<ClientAddressType>
     */
    public List<ClientAddressType> getAddressDetails() {
        return addressDetails;
    }

    /**
     * Mutator for property addressDetails.
     * 
     * @return addressDetails of type List<ClientAddressType>
     */
    @XmlElement(name = "addressDetails")
    public void setAddressDetails(List<ClientAddressType> addressDetails) {
        this.addressDetails = addressDetails;
    }

    /**
     * Accessor for property advisorDetails.
     * 
     * @return advisorDetails of type List<ClientAdvisorDetailType>
     */
    public List<ClientAdvisorDetailType> getAdvisorDetails() {
        return advisorDetails;
    }

    /**
     * Mutator for property advisorDetails.
     * 
     * @return advisorDetails of type List<ClientAdvisorDetailType>
     */
    @XmlElement(name = "advisorDetails")
    public void setAdvisorDetails(List<ClientAdvisorDetailType> advisorDetails) {
        this.advisorDetails = advisorDetails;
    }

    /**
     * Accessor for property clientContextDetails.
     * 
     * @return clientContextDetails of type List<ClientContextDetailType>
     */
    public List<ClientContextDetailType> getClientContextDetails() {
        return clientContextDetails;
    }

    /**
     * Mutator for property clientContextDetails.
     * 
     * @return clientContextDetails of type List<ClientContextDetailType>
     */
    @XmlElement(name = "clientcontextDetails")
    public void setClientContextDetails(List<ClientContextDetailType> clientContextDetails) {
        this.clientContextDetails = clientContextDetails;
    }

    /**
     * Accessor for property workDeclarationDetails.
     * 
     * @return workDeclarationDetails of type List<ClientWorkDeclarationType>
     */
    public List<ClientWorkDeclarationType> getWorkDeclarationDetails() {
        return workDeclarationDetails;
    }

    /**
     * Mutator for property workDeclarationDetails.
     * 
     * @return workDeclarationDetails of type List<ClientWorkDeclarationType>
     */
    @XmlElement(name = "workdeclarationDetails")
    public void setWorkDeclarationDetails(List<ClientWorkDeclarationType> workDeclarationDetails) {
        this.workDeclarationDetails = workDeclarationDetails;
    }

    /**
     * Accessor for property tfnConsentDeatils.
     * 
     * @return tfnConsentDeatils of type TfnConsentDeatilsType
     */
    public TfnConsentDetailsType getTfnConsentDetails() {
        return tfnConsentDetails;
    }

    /**
     * Mutator for property tfnConsentDeatils.
     * 
     * @param tfnConsentDetails
     * @return tfnConsentDeatils of type TfnConsentDeatilsType
     */
    @XmlElement(name = "tfnConsentDetails")
    public void setTfnConsentDetails(TfnConsentDetailsType tfnConsentDetails) {
        this.tfnConsentDetails = tfnConsentDetails;
    }

    /**
     * Accessor for property countryName.
     * 
     * @return countryName of type CountryNameType
     */
    public CountryNameType getCountryName() {
        return countryName;
    }

    /**
     * Mutator for property countryName.
     * 
     * @return countryName of type AustraliaMarketType
     */
    @XmlElement(name = "country")
    public void setCountryName(CountryNameType countryName) {
        this.countryName = countryName;
    }

    /**
     * Accessor for property errorCode.
     * 
     * @return errorCode of type String
     */
    public String getErrorCode() {
        return errorCode;
    }

    /**
     * Mutator for property errorCode.
     * 
     * @param errorCode of type String
     */
    @XmlElement(name = "errorCode")
    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }

    /**
     * Accessor for property externalReferenceTypeDetails.
     * 
     * @return externalReferenceTypeDetails of type List<ExternalReferenceDetailType>
     */
    public List<ExternalReferenceDetailType> getExternalReferenceTypeDetails() {
        return externalReferenceTypeDetails;
    }

    /**
     * Mutator for property externalReferenceTypeDetails.
     * 
     * @return externalReferenceTypeDetails of type List<ExternalReferenceDetailType>
     */
    @XmlElement(name = "externalReferenceTypeDetails")
    public void setExternalReferenceTypeDetails(List<ExternalReferenceDetailType> externalReferenceTypeDetails) {
        this.externalReferenceTypeDetails = externalReferenceTypeDetails;
    }

    /**
     * Accessor for property contactName.
     * 
     * @return contactName of type String
     */
    public String getContactName() {
        return contactName;
    }

    /**
     * Mutator for property contactName.
     * 
     * @param contactName of type String
     */
    @XmlElement(name = "contactName")
    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    /**
     * Accessor for property clientType.
     * 
     * @return clientType of type CodeIdentifier
     */
    public CodeIdentifier getClientType() {
        return clientType;
    }

    /**
     * Mutator for property clientType.
     * 
     * @return clientType of type CodeIdentifier
     */
    @XmlElement(name = "clientType")
    public void setClientType(CodeIdentifier clientType) {
        this.clientType = clientType;
    }

    /**
     * Accessor for property notes.
     * 
     * @return notes of type List<NoteBean>
     */
    public List<NoteBean> getNotes() {
        return notes;
    }

    /**
     * Mutator for property notes.
     * 
     * @param notes of type List<NoteBean>
     */
    @XmlElement(name = "notes")
    public void setNotes(List<NoteBean> notes) {
        this.notes = notes;
    }

    /**
     * Accessor for property preferredRisk.
     * 
     * @return preferredRisk of type CodeIdentifier
     */
    public CodeIdentifier getPreferredRisk() {
        return preferredRisk;
    }

    /**
     * Mutator for property preferredRisk.
     * 
     * @return preferredRisk of type CodeIdentifier
     */
    @XmlElement(name = "preferredRisk")
    public void setPreferredRisk(CodeIdentifier preferredRisk) {
        this.preferredRisk = preferredRisk;
    }

    /**
     * Accessor for property clientTfn.
     * 
     * @return clientTfn of type String
     */
    public String getClientTfn() {
        return clientTfn;
    }

    /**
     * Mutator for property clientTfn.
     * 
     * @param clientTfn of type String
     */
    @XmlElement(name = "clientTfn")
    public void setClientTfn(String clientTfn) {
        this.clientTfn = clientTfn;
    }

    /**
     * Accessor for property australia.
     * 
     * @return australia of type AustraliaDetails
     */
    public AustraliaDetails getAustralia() {
        return australia;
    }

    /**
     * Mutator for property australia.
     * 
     * @param australia of type AustraliaDetails
     */
    @XmlElement(name = "australia")
    public void setAustralia(AustraliaDetails australia) {
        this.australia = australia;
    }
}
