////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package com.suncorp.ssp.service.integration.clientservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code ClientAddressType} is a java bean consisting of properties related to client address.
 * 
 * @author U383754
 * @since 2015-10-01
 * @version 1.0
 */
public class ClientAddressType {
    private String addressId;
    private String operation;
    private String addressCodeType;
    private String addressCode;
    private String primaryType;
    private String primaryFlag;
    private String line1;
    private String line2;
    private String line3;
    private String line4;
    private String suburb;
    private String city;
    private String postcode;
    private String state;
    private String country;
    private String careOf;

    /**
     * Accessor for property addressId.
     * 
     * @return addressId of type String
     */
    public String getAddressId() {
        return addressId;
    }

    /**
     * Mutator for property addressId.
     * 
     * @param addressId of type String
     */
    @XmlElement(name = "addressId")
    public void setAddressId(String addressId) {
        this.addressId = addressId != null ? addressId : "";
    }

    /**
     * Accessor for property operation.
     * 
     * @return operation of type String
     */
    public String getOperation() {
        return operation;
    }

    /**
     * Mutator for property operation.
     * 
     * @param operation of type String
     */
    @XmlElement(name = "operation")
    public void setOperation(String operation) {
        this.operation = operation;
    }

    /**
     * Accessor for property addressCodeType.
     * 
     * @return addressCodeType of type String
     */
    public String getAddressCodeType() {
        return addressCodeType;
    }

    /**
     * Mutator for property addressCodeType.
     * 
     * @param addressCodeType of type String
     */
    @XmlElement(name = "addressCodeType")
    public void setAddressCodeType(String addressCodeType) {
        this.addressCodeType = addressCodeType != null ? addressCodeType : "";
    }

    /**
     * Accessor for property addressCode.
     * 
     * @return addressCode of type String
     */
    public String getAddressCode() {
        return addressCode;
    }

    /**
     * Mutator for property addressCode.
     * 
     * @param addressCode of type String
     */
    @XmlElement(name = "addressCode")
    public void setAddressCode(String addressCode) {
        this.addressCode = addressCode != null ? addressCode : "";
    }

    /**
     * Accessor for property primaryType.
     * 
     * @return primaryType of type String
     */
    public String getPrimaryType() {
        return primaryType;
    }

    /**
     * Mutator for property primaryType.
     * 
     * @param primaryType of type String
     */
    @XmlElement(name = "primaryType")
    public void setPrimaryType(String primaryType) {
        this.primaryType = primaryType != null ? primaryType : "";
    }

    /**
     * Accessor for property primaryFlag.
     * 
     * @return primaryFlag of type String
     */
    public String getPrimaryFlag() {
        return primaryFlag;
    }

    /**
     * Mutator for property primaryFlag.
     * 
     * @param primaryFlag of type String
     */
    @XmlElement(name = "primaryFlag")
    public void setPrimaryFlag(String primaryFlag) {
        this.primaryFlag = primaryFlag != null ? primaryFlag : "";
    }

    /**
     * Accessor for property line1.
     * 
     * @return line1 of type String
     */
    public String getLine1() {
        return line1;
    }

    /**
     * Mutator for property line1.
     * 
     * @param line1 of type String
     */
    @XmlElement(name = "line1")
    public void setLine1(String line1) {
        this.line1 = line1 != null ? line1 : "";
    }

    /**
     * Accessor for property line2.
     * 
     * @return line2 of type String
     */
    public String getLine2() {
        return line2;
    }

    /**
     * Mutator for property line2.
     * 
     * @param line2 of type String
     */
    @XmlElement(name = "line2")
    public void setLine2(String line2) {
        this.line2 = line2 != null ? line2 : "";
    }

    /**
     * Accessor for property line3.
     * 
     * @return line3 of type String
     */
    public String getLine3() {
        return line3;
    }

    /**
     * Mutator for property line3.
     * 
     * @param line3 of type String
     */
    @XmlElement(name = "line3")
    public void setLine3(String line3) {
        this.line3 = line3 != null ? line3 : "";
    }

    /**
     * Accessor for property line4.
     * 
     * @return line4 of type String
     */
    public String getLine4() {
        return line4;
    }

    /**
     * Mutator for property line4.
     * 
     * @param line4 of type String
     */
    @XmlElement(name = "line4")
    public void setLine4(String line4) {
        this.line4 = line4 != null ? line4 : "";
    }

    /**
     * Accessor for property suburb.
     * 
     * @return suburb of type String
     */
    public String getSuburb() {
        return suburb;
    }

    /**
     * Mutator for property suburb.
     * 
     * @param suburb of type String
     */
    @XmlElement(name = "suburb")
    public void setSuburb(String suburb) {
        this.suburb = suburb != null ? suburb : "";
    }

    /**
     * Accessor for property city.
     * 
     * @return city of type String
     */
    public String getCity() {
        return city;
    }

    /**
     * Mutator for property city.
     * 
     * @param city of type String
     */
    @XmlElement(name = "city")
    public void setCity(String city) {
        this.city = city != null ? city : "";
    }

    /**
     * Accessor for property postcode.
     * 
     * @return postcode of type String
     */
    public String getPostcode() {
        return postcode;
    }

    /**
     * Mutator for property postcode.
     * 
     * @param postcode of type String
     */
    @XmlElement(name = "postcode")
    public void setPostcode(String postcode) {
        this.postcode = postcode != null ? postcode : "";
    }

    /**
     * Accessor for property state.
     * 
     * @return state of type String
     */
    public String getState() {
        return state;
    }

    /**
     * Mutator for property state.
     * 
     * @param state of type String
     */
    @XmlElement(name = "state")
    public void setState(String state) {
        this.state = state != null ? state : "";
    }

    /**
     * Accessor for property country.
     * 
     * @return country of type String
     */
    public String getCountry() {
        return country;
    }

    /**
     * Mutator for property country.
     * 
     * @param country of type String
     */
    @XmlElement(name = "country")
    public void setCountry(String country) {
        this.country = country != null ? country : "";
    }

    /**
     * Accessor for property careOf.
     * 
     * @return careOf of type String
     */
    public String getCareOf() {
        return careOf;
    }

    /**
     * Mutator for property careOf.
     * 
     * @param careOf of type String
     */
    @XmlElement(name = "careOf")
    public void setCareOf(String careOf) {
        this.careOf = careOf != null ? careOf : "";
    }
}
