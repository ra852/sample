////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.clientservice.util;

import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CodeIdentifierType;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.clientservice.ClientServiceConstants;
import com.suncorp.ssp.service.integration.clientservice.bean.CodeIdentifier;

/**
 * The class {@code PreferredRiskUtil} is used to get prefered Risk details of the client.
 * 
 * @author U383754
 * @since 09/11/2016
 * @version 1.0
 */
public class PreferredRiskUtil {
    private String cname = "PreferredRiskUtil";
    private CodeIdentifierType preferredRisk;

    /**
     * Constructor.
     * 
     * @param preferredRisk
     */
    PreferredRiskUtil(CodeIdentifierType preferredRisk) {
        this.preferredRisk = preferredRisk;
    }

    /**
     * Default Constructor.
     */
    public PreferredRiskUtil() {
    }

    /**
     * This method is used to create the Prefferd Risk.
     * 
     * @param pIdentifier
     */
    public void createPrefferedRisk(final CodeIdentifier pIdentifier) {
        SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, cname, "Entering createPrefferedRisk().");
        pIdentifier.setId(getId());
        pIdentifier.setCode(getCode());
        pIdentifier.setCodeType(getCodeType());
        pIdentifier.setCodeDescription(getCodeDescription());
        pIdentifier.setCodeShortDescription(getCodeShortDescription());
        SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, cname, "Exiting createPrefferedRisk().");
    }

    /**
     * Gets CodeShortDescription.
     * 
     * @return
     */
    private String getCodeShortDescription() {
        if (this.preferredRisk.getCodeShortDescription() != null) {
            return String.valueOf(this.preferredRisk.getCodeShortDescription());
        }
        return "";
    }

    /**
     * Gets CodeDescription.
     * 
     * @return
     */
    private String getCodeDescription() {
        if (this.preferredRisk.getCodeDescription() != null) {
            return String.valueOf(this.preferredRisk.getCodeDescription());
        }
        return "";
    }

    /**
     * Gets CodeType.
     * 
     * @return
     */
    private String getCodeType() {
        if (this.preferredRisk.getCodeType() != null) {
            return String.valueOf(this.preferredRisk.getCodeType());
        }
        return "";
    }

    /**
     * Gets Code.
     * 
     * @return
     */
    private String getCode() {
        if (this.preferredRisk.getCode() != null) {
            return String.valueOf(this.preferredRisk.getCode());
        }
        return "";
    }

    /**
     * Gets the id.
     * 
     * @return
     */
    private String getId() {
        if (this.preferredRisk.getId() != null) {
            return String.valueOf(this.preferredRisk.getId());
        }
        return "";
    }

    /**
     * This method is used to set Default Preferred Risk Values.
     * 
     * @param pIdentifier
     */
    public void setDefaultPreferredRisk(final CodeIdentifier pIdentifier) {
        SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, cname, "Entering setDefaultPreferredRisk().");
        pIdentifier.setId("");
        pIdentifier.setCode("");
        pIdentifier.setCodeType("");
        pIdentifier.setCodeShortDescription("");
        pIdentifier.setCodeDescription("");
        SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, cname, "Exiting setDefaultPreferredRisk().");
    }
}
