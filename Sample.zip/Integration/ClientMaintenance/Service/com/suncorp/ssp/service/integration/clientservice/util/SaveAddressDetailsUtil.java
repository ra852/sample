////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.clientservice.util;

import java.util.List;

import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.AddressDetailsType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CodeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CountryIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.StateIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.model.ModelOperationType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.clientservice.ClientServiceConstants;
import com.suncorp.ssp.service.integration.clientservice.bean.ClientAddressType;

/**
 * The class {@code SaveAddressDetailsUtil} is a Utility class with address details related to client, to construct request for saving client external
 * service's request object.
 * 
 * @author U383847
 * @since 08/12/2015
 * @version 1.0
 */
public class SaveAddressDetailsUtil {
    private final String className = "SaveAddressDetailsUtil";

    /**
     * Extracts values from address details of client and set the values to external service's request object.
     * 
     * @param clientEntityType
     * @param addressTypeList
     */
    public void setClientAddressDetails(List<AddressDetailsType> address, List<ClientAddressType> addressTypeList) throws SILException {
        SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Setting Client Address Details");
        for (ClientAddressType clientAddressType : addressTypeList) {
            AddressDetailsType addressDetailsTypeObj = new AddressDetailsType();
            if (clientAddressType.getAddressId() != null) {
                setAddressId(clientAddressType, addressDetailsTypeObj);
            }
            if (checkAddressOperation(clientAddressType, addressDetailsTypeObj, address)) {
                continue;
            }
            setAddressDetailsType(clientAddressType, addressDetailsTypeObj, address);
        }
    }

    /**
     * Set Address Id Details.
     * 
     * @param clientAddressTypeObj
     * @param addressDetailsTypeObj
     */
    private void setAddressId(ClientAddressType clientAddressTypeObj, AddressDetailsType addressDetailsTypeObj) throws SILException {
        SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Setting Address Id");
        Long addressId = null;
        try {
            addressId = Long.parseLong(clientAddressTypeObj.getAddressId());
        } catch (NumberFormatException exception) {
            throw new SILException(ClientServiceConstants.INVALID_ADDRESS_ID_FORMAT);
        }
        addressDetailsTypeObj.setId(addressId);
    }

    /**
     * Check for Address Operation.
     * 
     * @param clientAddressTypeObj
     * @param addressDetailsTypeObj
     * @param address
     * @return type boolean
     */
    private boolean checkAddressOperation(ClientAddressType clientAddressTypeObj, AddressDetailsType addressDetailsTypeObj,
            List<AddressDetailsType> address) {
        SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Checking Address Operation");
        if (clientAddressTypeObj.getOperation() != null &&
                ModelOperationType.DELETE.equals(ModelOperationType.fromValue(clientAddressTypeObj.getOperation()))) {
            addressDetailsTypeObj.setOperation(ModelOperationType.fromValue(clientAddressTypeObj.getOperation()));
            address.add(addressDetailsTypeObj);
            return true;
        } else if (clientAddressTypeObj.getOperation() != null &&
                !ModelOperationType.DELETE.equals(ModelOperationType.fromValue(clientAddressTypeObj.getOperation()))) {
            addressDetailsTypeObj.setOperation(ModelOperationType.fromValue(clientAddressTypeObj.getOperation()));
        }
        return false;
    }

    /**
     * Set Address Type Details.
     * 
     * @param clientAddressTypeObj
     * @param addressDetailsTypeObj
     * @param address
     * @param addressTypeListObj
     */
    private void setAddressDetailsType(ClientAddressType clientAddressTypeObj, AddressDetailsType addressDetailsTypeObj,
            List<AddressDetailsType> address) {
        SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Setting Address Type Details");
        setCommonAddressFields(clientAddressTypeObj, addressDetailsTypeObj);
        if (clientAddressTypeObj.getAddressCode() != null &&
                !clientAddressTypeObj.getAddressCode().equals(ClientServiceConstants.CLIENT_ADDRESS_EMAL_TYPE) &&
                !clientAddressTypeObj.getAddressCode().equals(ClientServiceConstants.CLIENT_ADDRESS_FAX_TYPE)) {
            CountryIdentifierType countryIdentifierTypeObj = setCountryIdentifierType(clientAddressTypeObj);
            StateIdentifierType stateIdentifierTypeObj = setStateIdentifierType(clientAddressTypeObj, countryIdentifierTypeObj);
            setAddressDetails(countryIdentifierTypeObj, stateIdentifierTypeObj, clientAddressTypeObj, addressDetailsTypeObj);
        }
        address.add(addressDetailsTypeObj);
    }

    /**
     * Set Common Address Fields.
     * 
     * @param clientAddressTypeObj
     * @param addressDetailsTypeObj
     */
    private void setCommonAddressFields(ClientAddressType clientAddressTypeObj, AddressDetailsType addressDetailsTypeObj) {
        SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Setting Common Address Fields");
        CodeIdentifierType codeIdentifierTypeObj = new CodeIdentifierType();
        codeIdentifierTypeObj.setCode(clientAddressTypeObj.getAddressCode());
        codeIdentifierTypeObj.setCodeType(clientAddressTypeObj.getAddressCodeType());
        addressDetailsTypeObj.setTypeCode(codeIdentifierTypeObj);
        addressDetailsTypeObj.setPrimaryType(Boolean.parseBoolean(clientAddressTypeObj.getPrimaryType()));
        addressDetailsTypeObj.setPrimary(Boolean.parseBoolean(clientAddressTypeObj.getPrimaryFlag()));
        addressDetailsTypeObj.setLine1(clientAddressTypeObj.getLine1());
        addressDetailsTypeObj.setLine2(clientAddressTypeObj.getLine2());
        addressDetailsTypeObj.setLine3(clientAddressTypeObj.getLine3());
        addressDetailsTypeObj.setLine4(clientAddressTypeObj.getLine4());
    }

    /**
     * Set Address Details.
     * 
     * @param countryIdentifierTypeObj
     * @param stateIdentifierTypeObj
     * @param clientAddressTypeObj
     * @param addressDetailsTypeObj
     */
    private void setAddressDetails(CountryIdentifierType countryIdentifierTypeObj, StateIdentifierType stateIdentifierTypeObj,
            ClientAddressType clientAddressTypeObj, AddressDetailsType addressDetailsTypeObj) {
        SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Setting Address Details");
        if (stateIdentifierTypeObj != null) {
            addressDetailsTypeObj.setState(stateIdentifierTypeObj);
        }
        addressDetailsTypeObj.setCountry(countryIdentifierTypeObj);
        addressDetailsTypeObj.setSuburb(clientAddressTypeObj.getSuburb());
        addressDetailsTypeObj.setPostcode(clientAddressTypeObj.getPostcode());
        addressDetailsTypeObj.setCity(clientAddressTypeObj.getCity());
        if (clientAddressTypeObj.getCareOf() != null) {
            addressDetailsTypeObj.setCareOf(clientAddressTypeObj.getCareOf());
        }
    }

    /**
     * Set Country Identifier Details.
     * 
     * @param clientAddressTypeObj
     * @return object type of CountryIdentifierType
     */
    private CountryIdentifierType setCountryIdentifierType(ClientAddressType clientAddressTypeObj) {
        SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Setting Country Identifier Details");
        CountryIdentifierType countryIdentifierTypeObj = new CountryIdentifierType();
        countryIdentifierTypeObj.setCode(clientAddressTypeObj.getCountry());
        return countryIdentifierTypeObj;
    }

    /**
     * Set State Identifier Details.
     * 
     * @param clientAddressTypeObj
     * @param countryIdentifierTypeObj
     * @return object type of StateIdentifierType
     */
    private StateIdentifierType setStateIdentifierType(ClientAddressType clientAddressTypeObj, CountryIdentifierType countryIdentifierTypeObj) {
        SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Setting State Identifier Details");
        if (clientAddressTypeObj.getState() != null) {
            StateIdentifierType stateIdentifierTypeObj = new StateIdentifierType();
            stateIdentifierTypeObj.setCode(clientAddressTypeObj.getState());
            stateIdentifierTypeObj.setCountry(countryIdentifierTypeObj);
            return stateIdentifierTypeObj;
        }
        return null;
    }
}
