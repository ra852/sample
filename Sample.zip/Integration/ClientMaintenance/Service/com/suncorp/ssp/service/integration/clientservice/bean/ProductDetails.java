////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.clientservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code ProductDetails} is a java bean which is used to hold product details.
 * 
 * @author U385424
 * @since 20/12/2017
 * @version 1.0
 */
public class ProductDetails {
    private String id;
    private String name;
    private String shortName;

    /**
     * Accessor for property id.
     * 
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     * 
     * @return id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id;
    }

    /**
     * Accessor for property name.
     * 
     * @return name of type String
     */
    public String getName() {
        return name;
    }

    /**
     * Mutator for property name.
     * 
     * @return name of type String
     */
    @XmlElement(name = "name")
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Accessor for property shortName.
     * 
     * @return shortName of type String
     */
    public String getShortName() {
        return shortName;
    }

    /**
     * Mutator for property shortName.
     * 
     * @return shortName of type String
     */
    @XmlElement(name = "shortName")
    public void setShortName(String shortName) {
        this.shortName = shortName;
    }
}
