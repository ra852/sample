////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.clientservice.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code ClientSearchResult} does this.
 *
 * @author U383847
 * @since 15/03/2016
 * @version 1.0
 */
public class ClientSearchResult {
    private ClientIdentifier client;
    private String altSurname;
    private String firstName;
    private String middleName;
    private String abnNumber;
    private String wrapIndicator;
    private ClientAddressType address;
    private CodeIdentifier clientType;
    private CodeIdentifier investorType;
    private CodeIdentifier clientStatus;
    private List<ExternalReferenceDetailType> clientExternalReferences;
    
    /**
     * Accessor for property client.
     *
     * @return client of type ClientIdentifier
     */
    public ClientIdentifier getClient() {
        return client;
    }
    
    /**
     * Mutator for property client.
     *
     * @param client of type ClientIdentifier
     */
    @XmlElement(name = "client")
    public void setClient(ClientIdentifier client) {
        this.client = client;
    }
    
    /**
     * Accessor for property altSurname.
     *
     * @return altSurname of type String
     */
    public String getAltSurname() {
        return altSurname;
    }
    
    /**
     * Mutator for property altSurname.
     *
     * @param altSurname of type String
     */
    @XmlElement(name = "altSurname")
    public void setAltSurname(String altSurname) {
        this.altSurname = altSurname != null ? altSurname : "";
    }
    
    /**
     * Accessor for property firstName.
     *
     * @return firstName of type String
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Mutator for property firstName.
     *
     * @param firstName of type String
     */
    @XmlElement(name = "firstName")
    public void setFirstName(String firstName) {
        this.firstName = firstName != null ? firstName : "";
    }

    /**
     * Accessor for property middleName.
     *
     * @return middleName of type String
     */
    public String getMiddleName() {
        return middleName;
    }

    /**
     * Mutator for property middleName.
     *
     * @param middleName of type String
     */
    @XmlElement(name = "middleName")
    public void setMiddleName(String middleName) {
        this.middleName = middleName != null ? middleName : "";
    }

    /**
     * Accessor for property abnNumber.
     *
     * @return abnNumber of type String
     */
    public String getAbnNumber() {
        return abnNumber;
    }
    
    /**
     * Mutator for property abnNumber.
     *
     * @param abnNumber of type String
     */
    @XmlElement(name = "abnNumber")
    public void setAbnNumber(String abnNumber) {
        this.abnNumber = abnNumber != null ? abnNumber : "";
    }
    
    /**
     * Accessor for property wrapIndicator.
     *
     * @return wrapIndicator of type String
     */
    public String getWrapIndicator() {
        return wrapIndicator;
    }
    
    /**
     * Mutator for property wrapIndicator.
     *
     * @param wrapIndicator of type String
     */
    @XmlElement(name = "wrapIndicator")
    public void setWrapIndicator(String wrapIndicator) {
        this.wrapIndicator = wrapIndicator != null ? wrapIndicator : "";
    }
    
    /**
     * Accessor for property address.
     *
     * @return address of type ClientAddressType
     */
    public ClientAddressType getAddress() {
        return address;
    }
    /**
     * Mutator for property address.
     *
     * @param address of type ClientAddressType
     */
    @XmlElement(name = "primaryAddress")
    public void setAddress(ClientAddressType address) {
        this.address = address;
    }
    
    /**
     * Accessor for property clientType.
     *
     * @return clientType of type CodeIdentifier
     */
    public CodeIdentifier getClientType() {
        return clientType;
    }
    
    /**
     * Mutator for property clientType.
     *
     * @param clientType of type CodeIdentifier
     */
    @XmlElement(name = "clientType")
    public void setClientType(CodeIdentifier clientType) {
        this.clientType = clientType;
    }
    
    /**
     * Accessor for property investorType.
     *
     * @return investorType of type CodeIdentifier
     */
    public CodeIdentifier getInvestorType() {
        return investorType;
    }
    
    /**
     * Mutator for property investorType.
     *
     * @param investorType of type CodeIdentifier
     */
    @XmlElement(name = "investorType")
    public void setInvestorType(CodeIdentifier investorType) {
        this.investorType = investorType;
    }
    
    /**
     * Accessor for property clientStatus.
     *
     * @return clientStatus of type CodeIdentifier
     */
    public CodeIdentifier getClientStatus() {
        return clientStatus;
    }
    
    /**
     * Mutator for property clientStatus.
     *
     * @param clientStatus of type CodeIdentifier
     */
    @XmlElement(name = "clientStatus")
    public void setClientStatus(CodeIdentifier clientStatus) {
        this.clientStatus = clientStatus;
    }
    
    /**
     * Accessor for property clientExternalReferences.
     *
     * @return clientExternalReferences of type List<ExternalReferenceDetailType>
     */
    public List<ExternalReferenceDetailType> getClientExternalReferences() {
        return clientExternalReferences;
    }
    
    /**
     * Mutator for property clientExternalReferences.
     *
     * @param clientExternalReferences of type List<ExternalReferenceDetailType>
     */
    @XmlElement(name = "externalReferenceTypeDetails")
    public void setClientExternalReferences(List<ExternalReferenceDetailType> clientExternalReferences) {
        this.clientExternalReferences = clientExternalReferences;
    }
}
