////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.clientservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code ClientIdentifier} does this.
 *
 * @author U383847
 * @since 15/03/2016
 * @version 1.0
 */
public class ClientIdentifier {
    private String clientId;
    private String name;
    private String masterSchemeName;
    private String surname;
    private String firstName;
    private String middleName;
    private String globalIntermediaryIDNumber;
    private AuditDetails audit;
    private ExternalReferenceDetailType externalReferenceType;
    
    /**
     * Accessor for property clientId.
     *
     * @return clientId of type String
     */
    public String getClientId() {
        return clientId;
    }
    
    /**
     * Mutator for property clientId.
     *
     * @param clientId of type String
     */
    @XmlElement(name = "clientId")
    public void setClientId(String clientId) {
        this.clientId = clientId != null ? clientId : "";
    }
    
    /**
     * Accessor for property name.
     *
     * @return name of type String
     */
    public String getName() {
        return name;
    }
    
    /**
     * Mutator for property name.
     *
     * @param name of type String
     */
    @XmlElement(name = "name")
    public void setName(String name) {
        this.name = name != null ? name : "";
    }
    
    /**
     * Accessor for property masterSchemeName.
     *
     * @return masterSchemeName of type String
     */
    public String getMasterSchemeName() {
        return masterSchemeName;
    }
    
    /**
     * Mutator for property masterSchemeName.
     *
     * @param masterSchemeName of type String
     */
    @XmlElement(name = "masterSchemeName")
    public void setMasterSchemeName(String masterSchemeName) {
        this.masterSchemeName = masterSchemeName != null ? masterSchemeName : "";
    }
    
    /**
     * Accessor for property surname.
     *
     * @return surname of type String
     */
    public String getSurname() {
        return surname;
    }
    
    /**
     * Mutator for property surname.
     *
     * @param surname of type String
     */
    @XmlElement(name = "surname")
    public void setSurname(String surname) {
        this.surname = surname != null ? surname : "";
    }
    
    /**
     * Accessor for property firstName.
     *
     * @return firstName of type String
     */
    public String getFirstName() {
        return firstName;
    }
    
    /**
     * Mutator for property firstName.
     *
     * @param firstName of type String
     */
    @XmlElement(name = "firstName")
    public void setFirstName(String firstName) {
        this.firstName = firstName != null ? firstName : "";
    }
    
    /**
     * Accessor for property middleName.
     *
     * @return middleName of type String
     */
    public String getMiddleName() {
        return middleName;
    }
    
    /**
     * Mutator for property middleName.
     *
     * @param middleName of type String
     */
    @XmlElement(name = "middleName")
    public void setMiddleName(String middleName) {
        this.middleName = middleName != null ? middleName : "";
    }
    
    /**
     * Accessor for property globalIntermediaryIDNumber.
     *
     * @return globalIntermediaryIDNumber of type String
     */
    public String getGlobalIntermediaryIDNumber() {
        return globalIntermediaryIDNumber;
    }
    
    /**
     * Mutator for property globalIntermediaryIDNumber.
     *
     * @param globalIntermediaryIDNumber of type String
     */
    @XmlElement(name = "globalIntermediaryIDNumber")
    public void setGlobalIntermediaryIDNumber(String globalIntermediaryIDNumber) {
        this.globalIntermediaryIDNumber = globalIntermediaryIDNumber != null ? globalIntermediaryIDNumber : "";
    }
    
    /**
     * Accessor for property audit.
     *
     * @return audit of type AuditDetails
     */
    public AuditDetails getAudit() {
        return audit;
    }
    
    /**
     * Mutator for property audit.
     *
     * @param audit of type AuditDetails
     */
    @XmlElement(name = "audit")
    public void setAudit(AuditDetails audit) {
        this.audit = audit;
    }
    
    /**
     * Accessor for property externalReferenceType.
     *
     * @return externalReferenceType of type ExternalReferenceDetailType
     */
    public ExternalReferenceDetailType getExternalReferenceType() {
        return externalReferenceType;
    }
    
    /**
     * Mutator for property externalReferenceType.
     *
     * @param externalReferenceType of type ExternalReferenceDetailType
     */
    @XmlElement(name = "externalReferenceType")
    public void setExternalReferenceType(ExternalReferenceDetailType externalReferenceType) {
        this.externalReferenceType = externalReferenceType;
    }
}
