////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.clientservice.util;

import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.List;

import com.sonatacentral.service.v30.common.client.GetClientResponseType;
import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.WorkDeclarationType;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.clientservice.ClientServiceConstants;
import com.suncorp.ssp.service.integration.clientservice.bean.ClientWorkDeclarationType;

/**
 * The class {@code WorkDeclarationDetails} does this.
 * 
 * @author U383754
 * @since 28/10/2015
 * @version 1.0
 */
public class WorkDeclarationDetailsUtil {
    private GetClientResponseType getClientResponseType;
    private WorkDeclarationType.Declaration workDeclarationType;

    public WorkDeclarationDetailsUtil(GetClientResponseType getClientResponseType) {
        this.getClientResponseType = getClientResponseType;
    }

    /**
     * 
     * This method is used to get work declaration details of client.
     * 
     * @param workDeclarationDetails
     */
    public void getWorkDeclarationDetails(List<ClientWorkDeclarationType> workDeclarationDetails) {
        SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "WorkDeclarationDetailsUtil", "Entering in getWorkDeclarationDetails.");
        if (this.getClientResponseType != null && this.getClientResponseType.getWorkDeclaration() != null &&
                this.getClientResponseType.getWorkDeclaration().getDeclaration() != null &&
                this.getClientResponseType.getWorkDeclaration().getDeclaration().size() != 0) {
            List<WorkDeclarationType.Declaration> workDeclarationList = this.getClientResponseType.getWorkDeclaration().getDeclaration();
            Iterator<WorkDeclarationType.Declaration> workDeclarationIterator = workDeclarationList.iterator();
            while (workDeclarationIterator.hasNext()) {
                this.workDeclarationType = workDeclarationIterator.next();
                ClientWorkDeclarationType clientWorkDeclarationType1Obj = new ClientWorkDeclarationType();
                clientWorkDeclarationType1Obj.setDateDeclaredOn(this.getDateDeclaredOn());
                clientWorkDeclarationType1Obj.setDateFinancialYearEnd(this.getDateFinancialYearEnd());

                workDeclarationDetails.add(clientWorkDeclarationType1Obj);
            }
        } else {
            this.setDefaultValues(workDeclarationDetails);
        }
        SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "WorkDeclarationDetailsUtil", "Exiting in getWorkDeclarationDetails.");
    }

    /**
     * Accessor for property effectiveFromDate.
     * 
     * @return effectiveFromDate of type String
     */
    private String getDateDeclaredOn() {
        if (this.workDeclarationType != null && this.workDeclarationType.getDateDeclaredOn() != null &&
                this.workDeclarationType.getDateDeclaredOn().toGregorianCalendar() != null) {
            return new SimpleDateFormat(ClientServiceConstants.DATE_TIME_FORMAT).format(this.workDeclarationType.getDateDeclaredOn()
                    .toGregorianCalendar().getTime());
        }
        return "";
    }

    /**
     * Accessor for property effectiveEndDate.
     * 
     * @return effectiveEndDate of type String
     */
    private String getDateFinancialYearEnd() {
        if (this.workDeclarationType != null && this.workDeclarationType.getDateFinancialYearEnd() != null &&
                this.workDeclarationType.getDateFinancialYearEnd().toGregorianCalendar() != null) {
            return new SimpleDateFormat(ClientServiceConstants.DATE_TIME_FORMAT).format(this.workDeclarationType.getDateFinancialYearEnd()
                    .toGregorianCalendar().getTime());
        }
        return "";
    }

    /**
     * Does this.
     * 
     * @param workDeclarationDetails
     */
    private void setDefaultValues(List<ClientWorkDeclarationType> workDeclarationDetails) {
        ClientWorkDeclarationType clientWorkDeclarationType2Obj = new ClientWorkDeclarationType();
        clientWorkDeclarationType2Obj.setDateDeclaredOn("");
        clientWorkDeclarationType2Obj.setDateFinancialYearEnd("");
        workDeclarationDetails.add(clientWorkDeclarationType2Obj);
    }
}
