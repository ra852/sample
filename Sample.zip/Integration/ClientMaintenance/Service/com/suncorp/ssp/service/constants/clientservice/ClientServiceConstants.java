////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.constants.clientservice;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * The class {@code ClientServiceConstants} is used as common constants class for client service.
 * 
 * @author U383754
 * @since 05/11/2015
 * @version 1.0
 */
public abstract class ClientServiceConstants {
    // Common Client service constants
    public static final String OPERATION_NAMESPACE = "http://www.sonatacentral.com/service/v30/common/client";
    public static final String CLIENT_AU_COUNTRY = "AU";
    public static final String CLIENT_TYPE_CODE_TYPE = "CLTY";
    public static final String CLIENT_TITLE_CODE_TYPE = "TITL";
    public static final String CLIENT_ADDRESS_ADDR_TYPE = "ADDR";
    public static final String CLIENT_ADDRESS_RESI_TYPE = "RESI";
    public static final String CLIENT_ADDRESS_POST_TYPE = "POST";
    public static final String CLIENT_ADDRESS_EMAL_TYPE = "EMAL";
    public static final String CLIENT_ADDRESS_FAX_TYPE = "FAX";
    public static final String CLIENT_BANK_TYPE = "BANK";
    public static final String CLIENT_STATUS_CODE_TYPE = "CLST";
    public static final String CLIENT_ONLINE_STATUS_CODE_TYPE = "OLCS";
    public static final String CLIENT_PREFERRED_RISK_CODE_TYPE = "RISK";
    public static final String CLIENT_INVESTOR_COMPANY_CODE_TYPE = "INTC";
    public static final String CLIENT_PREF_LANG_CODE_TYPE = "LANG";
    public static final String CLIENT_INVESTOR_PERSONAL_CODE_TYPE = "INVT";
    public static final String CLIENT_NATIONALITY_CODE_TYPE = "CNAT";
    public static final String CLIENT_CORRES_VIEW_OPTION_CODE_TYPE = "FONT";
    public static final String CLIENT_CORRES_DELIVERY_PREFER_CODE_TYPE = "CODP";
    public static final String TFN_SUPPLIED = "TFN Supplied";
    public static final String TFN_NOT_SUPPLIED = "TFN Not Supplied";
    public static final String INVALID_REQUEST_MESSAGE = "Invalid Request.Please provide client id as a query parameter.";
    public static final String INVALID_REQUEST_FORMAT = "Invalid Request. Please provide valid request message.";
    public static final String INVALID_ADDRESS_ID_FORMAT = "Invalid Address Id. Please provide valid Address Id.";
    public static final String INVALID_BANK_ID_FORMAT = "Invalid Bank Id. Please provide valid Bank Id.";
    public static final String INVALID_TFNCONSENT_ID_FORMAT = "Invalid Tfn Consent Id. Please provide valid Tfn Consent Id.";
    public static final String INVALID_ADVISOR_GROUP_ID_FORMAT = "Invalid Advisor Group Id. Please provide valid Advisor Group Id.";
    public static final String INVALID_CONTEXT_ID_FORMAT = "Invalid Context Id. Please provide valid Context Id.";
    public static final String DATE_TIME_FORMAT = "dd/MM/yyyy";

    // Get client constants
    public static final String GET_CLIENT_OPERATION_NAME = "getClient";
    public static final String GET_CLIENT_LOGGING_FORMAT = "ClientService_GetClient_{}_".concat(
            new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat("_{}");
    public static final String CLIENT_ID = "clientId";
    public static final String SEX = "SEX";
    public static final String MARITAL_STATUS = "MARI";
    public static final String NONE = "NONE";
    public static final Object GET_CLIENT_RESPONSE_CLASS_NAME = "com.suncorp.ssp.service.integration.clientservice.bean.GetClientResponse";
    public static final String GET_CLIENT_GENERIC_MSG = "Get Client functionality could not get processed";
    public static final String GET_CLIENT_ADDRESS_CODE = "LKA";
    public static final String GET_CLIENT_EMPTY_STRING = "";
    public static final String INCLUDE_CLIENT_DETAILS = "includeClientDetails";
    public static final String INCLUDE_ADDRESS = "includeAddress";
    public static final String INCLUDE_BANK_ACCOUNT = "includeBankAccount";
    public static final String INCLUDE_EXTERNAL_REFERENCE = "includeExternalReference";
    public static final String INCLUDE_GENERIC_VARIABLE = "includeGenericVariable";
    public static final String INCLUDE_NOTE = "includeNote";
    public static final String INCLUDE_CLIENT_CONTEXT = "includeClientContext";
    public static final String INCLUDE_ADVISOR_GROUP = "includeAdvisorGroup";
    public static final String INCLUDE_NEWZEALAND = "includeNewZealand";
    public static final String INCLUDE_SOUTH_AFRICA = "includeSouthAfrica";
    public static final String INCLUDE_AUSTRALIA = "includeAustralia";
    public static final String INCLUDE_UNITED_KINGDOM = "includeUnitedKingdom";
    public static final String INCLUDE_WORK_DECLARATION = "includeWorkDeclaration";
    public static final String INCLUDE_TAX_TREATY_DETAILS = "includeTaxTreatyDetails";
    public static final String INCLUDE_CORRO_DELIVERY_PREFERENCES = "includeCorroDeliveryPreferences";
    public static final String INCLUDE_APS_SUBSCRIPTION = "includeApsSubscription";

    // Save client constants
    public static final String SAVE_CLIENT_OPERATION_NAME = "saveClient";
    public static final String SAVE_CLIENT_LOGGING_FORMAT = "ClientService_SaveClient_{}_".concat(
            new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat("_{}");
    public static final String SAVE_CLIENT_RESPONSE_CLASS_NAME = "com.suncorp.ssp.service.integration.clientservice.bean.SaveClientResponse";
    public static final String SUCCESS_STATUS = "Successful";
    public static final String FAILURE_STATUS = "Failed";
    public static final String SAVE_CLIENT_EXCEPTION_MESSAGE = "Save Client functionality could not get processed.";

    // Get Account List constants
    public static final String GET_ACCOUNT_LIST_OPERATION_NAME = "getAccountList";
    public static final String GET_ACCOUNT_LIST_LOGGING_FORMAT = "ClientService_GetAccountList_{}_".concat(
            new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat("_{}");
    public static final String GET_ACCOUNT_LIST_RESPONSE_CLASS_NAME =
            "com.suncorp.ssp.service.integration.clientservice.bean.GetAccountListResponseBean";
    public static final String TFN_CONSENT_CODE = "TFNC";
    public static final String GET_ACCOUNT_LIST_GENERIC_MSG = "Get Account List functionality could not get processed";
    public static final String GET_ACCOUNT_LIST_ACCOUNT_NOT_EXIST = "No Account Exists for the Given Client";
    public static final Object INCLUDE_EMPLOYER = "includeEmployer";
    public static final Object INCLUDE_PRODUCT = "includeProduct";

    // Search Client constants
    public static final String SERACH_CLIENT_OPERATION_NAME = "searchClient";
    public static final String SEARCH_CLIENT_LOGGING_FORMAT = "ClientService_SearchClient_{}_".concat(
            new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat("_{}");
    public static final String SERACH_CLIENT_RESPONSE_CLASS_NAME = "com.suncorp.ssp.service.integration.clientservice.bean.SearchClientResponse";
    public static final String CLIENT_SURNAME = "clientSurname";
    public static final String INVEST_TYPE_CODE = "investTypeCode";
    public static final String INVEST_TYPE_CODE_TYPE = "investTypeCodeType";
    public static final String INCLUDE_EXTERNAL_REF = "includeExternalReferences";
    public static final String DATE_OF_BIRTH = "dateOfBirth";
    public static final String PERCENT_SYMBOL = "%";
    public static final String SEARCH_CLIENT_GENERIC_MSG = "SearchClient functionality could not get processed.";

    // GetCustomerByProduct
    public static final String GET_CUSTOMER_BY_PRODUCT_LOGGING_FORMAT = "ClientService_GetCustomerByProduct_{}_".concat(
            new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat("_{}");
    public static final Object GET_CUSTOMER_BY_PRODUCT_RESPONSE_CLASS_NAME =
            "com.suncorp.ssp.service.integration.clientservice.bean.GetCustomerByProductDetails";
    public static final String GET_CUSTOMER_BY_PRODUCT_RESPONSE_NOT_PROCESSED = "GetCustomerByProduct response could not be processed.";
    public static final String ACCOUNT_STATUS_INACTIVE = "Customer Account status inactive";
    public static final String CUSTOMER_CLIENT_ID = "Customer_ClientId";
    public static final String GET_CUSTOMER_BY_PRODUCT_RESPONSE = "getCustomerByProductResponse";
    public static final String SONATA_CLIENT_TYPECODE_PERSONAL = "PERS";
    public static final String SONATA_CLIENT_TYPECODE_COMPANY = "COMP";
    public static final Object IDENTITY_TAG = "identity";
    public static final Object ENTITY_TYPE_TAG = "entityType";
    public static final String INVALID_GET_CUSTOMER_REQUEST_MESSAGE = "Invalid Request, Identity is required";
    public static final String INVALID_GET_CUSTOMER_ENTITY_TYPE_REQUEST_MESSAGE = "Invalid Request, EntityType is required";
    public static final String GET_CUSTOMER_BY_PRODUCT_GENERIC_MSG = "GetCustomerByProduct request could not be processed.";
    public static final String GET_EMPLOYER_OPERATION_NAME = "getEmployer";
    public static final String GET_EMPLOYER_OPERATION_NAMESPACE = "http://www.sonatacentral.com/service/v30/scheme";
    public static final String COMPOSER_GET_EMPLOYER_OPERATION_NAME = "GetEmployerDetails";
    public static final String COMPOSER_GET_EMPLOYER_OPERATION_NAMESPACE = "http://www.infocomp.com/cbis/messages/Employer/1.0";
    public static final String COMPOSER_GET_ACCOUNT_DETAILS_OPERATION_NAME = "GetAccountDetails";
    public static final String COMPOSER_GET_ACCOUNT_DETAILS_OPERATION_NAMESPACE = "http://www.infocomp.com/cbis/messages/InvestorAccount/1.0";
    public static final String COMPOSER_GET_INVESTOR_DETAILS_OPERATION_NAME = "GetInvestorDetails";
    public static final String COMPOSER_GET_INVESTOR_DETAILS_OPERATION_NAMESPACE = "http://www.infocomp.com/cbis/messages/Investor/1.0";
    public static final String IDENTITY_PROPERTY_TAG = "identity";
    public static final String ENTITY_TYPE_PROPERTY_TAG = "entityType";
    public static final String ENTITY_TYPE_EMPLOYER = "E";
    public static final String CALL_EMPLOYER_SERVICE = "CallEmployerService";
    public static final String EMPLOYER_NUMBER_TAG = "employerNumber";
    public static final String ENTITY_TYPE_MEMBER = "M";
    public static final String ACCOUNT_NUMBER_TAG = "customer_AccountNumber";
    public static final String CALL_COMPOSER_FOR_MEMBER_SERVICE = "callComposerForMemberService";
    public static final String SONATA_CODE_INACTIVE_ACCOUNT = "ESTO";
    public static final String ACCOUNT_IS_INACTIVE = "ACCOUNT_INACTIVE";
    public static final String SONATA_CODE_ACCOUNT_RELATIONSHIP_OWNER = "OWNR";
    public static final String COMPOSER_ENTITY_ID_TAG = "entityId";
    public static final String CALL_COMPOSER_INVESTOR_SERVICE = "callComposerInvestorService";
    public static final String ERROR_CODE_MEMBER_NOT_FOUND = "2001";
    public static final String ERROR_CODE_ENTITY_TYPE_NOT_SUPPORTED = "2003";
    public static final String ERROR_SEVERITY_SYSTEM_ERROR = "S";
    public static final String SUCCESS_CODE = "00000";
    public static final String ERROR_CODE_GENERIC = "1001";
    public static final String STOP_ROUTE = "stopRoute";
    public static final String ERROR_SEVERITY_BUSINESS_ERROR = "E";
    public static final String COMPOSER_ACCOUNT_STATUS_INACTIVE = "I";
    public static final String DESCRIPTION_MEMBER_NOT_FOUND = "Member was not Found";
    public static final String DESCRIPTION_ENTITY_TYPE_NOT_SUPPORTED = "Entity type not supported";
    public static final String DESCRIPTION_GENERIC_MESSAGE = "Unable to connect to the Database";
}
