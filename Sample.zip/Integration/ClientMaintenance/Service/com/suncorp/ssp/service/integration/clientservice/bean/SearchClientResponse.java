////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.clientservice.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.suncorp.ssp.common.bean.SILErrorMessage;

/**
 * The class {@code SearchClientResponse} does this.
 *
 * @author U383847
 * @since 09/03/2016
 * @version 1.0
 */
@XmlRootElement(name = "SearchClientResponse")
public class SearchClientResponse extends SILErrorMessage {
    private List<ClientSearchResult> clientSearchResult;

    /**
     * Accessor for property clientSearchResult.
     *
     * @return clientSearchResult of type List<ClientSearchResult>
     */
    public List<ClientSearchResult> getClientSearchResult() {
        return clientSearchResult;
    }

    /**
     * Mutator for property clientSearchResult.
     *
     * @param clientSearchResult of type List<ClientSearchResult>
     */
    @XmlElement(name = "clientSearchResult")
    public void setClientSearchResult(List<ClientSearchResult> clientSearchResult) {
        this.clientSearchResult = clientSearchResult;
    }
    
}
