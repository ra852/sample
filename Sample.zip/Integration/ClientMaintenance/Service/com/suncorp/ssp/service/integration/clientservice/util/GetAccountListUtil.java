////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.clientservice.util;

import java.util.ArrayList;
import java.util.List;

import com.sonatacentral.service.v30.common.client.GetAccountListResponseType;
import com.sonatacentral.service.v30.common.client.GetAccountListResponseType.Account;
import com.sonatacentral.service.v30.globaltypes.common.scheme.schemegrouptype.SchemeLocationIdentifierType;
import com.sonatacentral.service.v30.globaltypes.identifiertype.IdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.product.productgrouptype.ProductIdentifierType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.clientservice.ClientServiceConstants;
import com.suncorp.ssp.service.integration.clientservice.bean.AccountNumbers;
import com.suncorp.ssp.service.integration.clientservice.bean.EmployerDetails;
import com.suncorp.ssp.service.integration.clientservice.bean.GetAccountListResponseBean;
import com.suncorp.ssp.service.integration.clientservice.bean.IdentifierDetails;
import com.suncorp.ssp.service.integration.clientservice.bean.ProductDetails;

/**
 * The class {@code GetAccountListUtil} is a Utility class with all the properties related to GetAccountList functionality, to construct response for
 * end-client by extracting values from the external service's response object.
 * 
 * @author U384381
 * @since 17/11/2015
 * @version 1.0
 */
public class GetAccountListUtil {
    private GetAccountListResponseType getAccountListResponseType;
    private Account accountDetails;
    private ClientServiceUtil clientServiceUtil;

    /**
     * Initializes the instance variable getAccountListResponseType with the one passed to the constructor.
     * 
     * @param getAccountListResponseType of type GetAccountListResponseType
     */
    public GetAccountListUtil(GetAccountListResponseType getAccountListResponseType) {
        this.getAccountListResponseType = getAccountListResponseType;
        this.clientServiceUtil = new ClientServiceUtil();
    }

    /**
     * Sets a {@code AccountNumbers} list into the getAccountlistResponseBean.
     * 
     * @param getAccountlistResponseBean of type GetAccountListResponseBean
     * @throws Exception
     */
    public void setGetAccountListResponseType(GetAccountListResponseBean getAccountlistResponseBean) throws SILException {
        SILLogger.debug(ClientServiceConstants.GET_ACCOUNT_LIST_LOGGING_FORMAT, "GetAccountListUtil",
                "Entering setGetAccountListResponseType method.");
        List<AccountNumbers> accountNumbersList = new ArrayList<AccountNumbers>();
        if (null != this.getAccountListResponseType && this.getAccountListResponseType.getAccount() != null &&
                this.getAccountListResponseType.getAccount().size() > 0) {
            addAccountDetailsToList(accountNumbersList);
        } else {
            throw new SILException(ClientServiceConstants.GET_ACCOUNT_LIST_ACCOUNT_NOT_EXIST);
        }
        getAccountlistResponseBean.setAccounts(accountNumbersList);

    }

    /**
     * Adds a {@code AccountNumbers} object with values extracted from external service's response, to a CodeType list passed as a parameter.
     * 
     * @param accountDetailList of type List<AccountNumbers>
     * @throws SILException
     */
    private void addAccountDetailsToList(List<AccountNumbers> accountNumbersList) throws SILException {
        List<Account> accountDetailList = this.getAccountListResponseType.getAccount();
        for (Account account : accountDetailList) {
            this.accountDetails = account;
            if (this.accountDetails != null && this.accountDetails.getAccount() != null) {
                AccountNumbers accountnumber = new AccountNumbers();
                accountnumber.setAccountNumber(getAccountNumber());
                accountnumber.setProductName(getProductName());
                retrieveRemainingAccountDetails(accountnumber);
                accountNumbersList.add(accountnumber);
            }
        }
    }

    /**
     * This method is used to retrieve account details.
     * 
     * @param accountnumber
     * @throws SILException
     */
    private void retrieveRemainingAccountDetails(AccountNumbers accountnumber) throws SILException {
        if (this.accountDetails.getEmployer() != null) {
            EmployerDetails employerDetails = retrieveEmployerDetails();
            accountnumber.setEmployer(employerDetails);
        }
        if (this.accountDetails.getAccountBalance() != null) {
            accountnumber.setAccountBalance(String.valueOf(this.accountDetails.getAccountBalance()));
        }
        if (this.accountDetails.getAccount().getStatusCode() != null) {
            accountnumber.setStatus(this.clientServiceUtil.getCodeIdentifierDetails(this.accountDetails.getAccount().getStatusCode(),
                    ClientServiceConstants.GET_ACCOUNT_LIST_LOGGING_FORMAT));
        }
        if (this.accountDetails.getProduct() != null) {
            accountnumber.setProductDetails(retrieveProductDetails());
        }
    }

    /**
     * Does this.
     * 
     * @param product
     * @param accountnumber
     * @return
     */
    private ProductDetails retrieveProductDetails() {
        ProductIdentifierType product = this.accountDetails.getProduct();
        ProductDetails productDetails = new ProductDetails();
        if (product.getId() != null) {
            productDetails.setId(String.valueOf(product.getId()));
        }
        if (product.getName() != null) {
            productDetails.setName(String.valueOf(product.getName()));
        }
        if (product.getShortName() != null) {
            productDetails.setShortName(String.valueOf(product.getShortName()));
        }
        return productDetails;
    }

    /**
     * Fetches value of AccountNumber from {@code Account} if it exists, else returns a blank string.
     * 
     * @return AccountNumber of type String
     */
    private String getAccountNumber() {
        if (this.accountDetails.getAccount().getAccountNumber() != null && 
                this.accountDetails.getAccount().getAccountNumber().getAccountNo() != null) {
            return this.accountDetails.getAccount().getAccountNumber().getAccountNo();
        }
        return "";
    }

    /**
     * Fetches value of ProductName from {@code Account} if it exists, else returns a blank string.
     * 
     * @return ProductName of type String
     */
    private String getProductName() {
        if (this.accountDetails.getAccount().getAccountNumber() != null &&
                this.accountDetails.getAccount().getAccountNumber().getProductName() != null) {
            return this.accountDetails.getAccount().getAccountNumber().getProductName();
        }
        return "";
    }

    /**
     * Fetches value of Employer from {@code Account} if it exists.
     * 
     * @param clientServiceUtil
     * @param schemeLocationIdentifierType
     * @return accountnumber
     * @throws SILException
     */
    private EmployerDetails retrieveEmployerDetails() throws SILException {
        SchemeLocationIdentifierType employerType = this.accountDetails.getEmployer();
        EmployerDetails employerDetails = new EmployerDetails();
        employerDetails.setId(this.clientServiceUtil.retrieveLongValue(employerType.getId()));
        employerDetails.setName(retrieveString(employerType.getName()));
        employerDetails.setNumber(retrieveString(employerType.getNumber()));
        employerDetails.setParentLocationIdentifier(retrieveIdentifierDetails(employerType.getParentLocationIdentifier()));
        employerDetails.setShortName(retrieveString(employerType.getShortName()));
        employerDetails.setTypeCode(this.clientServiceUtil.getCodeIdentifierDetails(employerType.getTypeCode(),
                ClientServiceConstants.GET_ACCOUNT_LIST_LOGGING_FORMAT));
        return employerDetails;
    }

    /**
     * Fetches value of IdentifierDetails from {@code Account} if it exists, else returns a blank string.
     * 
     * @param parentLocationIdentifier
     * @return identifierDetails
     * @throws SILException
     */
    private IdentifierDetails retrieveIdentifierDetails(IdentifierType idetifierType) throws SILException {
        ClientServiceUtil clientServiceUtil = new ClientServiceUtil();
        IdentifierDetails identifierDetails = new IdentifierDetails();
        if (idetifierType != null) {
            identifierDetails.setId(clientServiceUtil.retrieveLongValue(idetifierType.getId()));
            identifierDetails.setName(retrieveString(idetifierType.getName()));
        } else {
            identifierDetails = retrieveDefaultIdentifierDetails();
        }
        return identifierDetails;
    }

    /**
     * This method is used set default values.
     * 
     * @return identifierDetails
     */
    private IdentifierDetails retrieveDefaultIdentifierDetails() {
        IdentifierDetails identifierDetails = new IdentifierDetails();
        identifierDetails.setId("");
        identifierDetails.setName("");
        return identifierDetails;
    }

    /**
     * This method is used to retrieve string.
     * 
     * @param name
     * @return value
     */
    private String retrieveString(String value) {
        SILLogger.debug(ClientServiceConstants.GET_ACCOUNT_LIST_LOGGING_FORMAT, "GetAccountListUtil",
                "Entering setGetAccountListResponseType method.");
        if (value != null) {
            return String.valueOf(value);
        } else {
            return "";
        }
    }
}
