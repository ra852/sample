////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.clientservice.util;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.core.Response;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.camel.Exchange;

import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.AddressDetailsType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CodeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.ExternalRefType;
import com.sonatacentral.service.v30.globaltypes.identifiertype.IdentifierAuditType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.clientservice.ClientServiceConstants;
import com.suncorp.ssp.service.integration.clientservice.bean.AuditDetails;
import com.suncorp.ssp.service.integration.clientservice.bean.ClientAddressType;
import com.suncorp.ssp.service.integration.clientservice.bean.CodeIdentifier;
import com.suncorp.ssp.service.integration.clientservice.bean.ErrorBean;
import com.suncorp.ssp.service.integration.clientservice.bean.ExternalReferenceDetailType;
import com.suncorp.ssp.service.integration.clientservice.bean.GetCustomerByProductDetails;

/**
 * The class {@code ClientServiceUtil} does this.
 * 
 * @author U383847
 * @since 16/03/2016
 * @version 1.0
 */
public class ClientServiceUtil {
    private final String className = "ClientServiceUtil";

    /**
     * Default Constructor.
     * 
     */
    public ClientServiceUtil() {
    }

    /**
     * Getting External Reference Details.
     * 
     * @param externalRefType
     * @param loggerType
     * @return
     */
    public ExternalReferenceDetailType getExternalReferenceDetails(ExternalRefType externalRefType, String loggerType) {
        if (externalRefType != null) {
            SILLogger.debug(loggerType, className, "Getting External Reference Details");
            ExternalReferenceDetailType externalReferenceDetailType1Obj = new ExternalReferenceDetailType();
            externalReferenceDetailType1Obj.setExternalReferenceType(this.getExternalReferenceType(externalRefType));
            externalReferenceDetailType1Obj.setExternalReferenceCode(this.getExternalReferenceCode(externalRefType));
            externalReferenceDetailType1Obj.setOperation(this.getOperation());
            return externalReferenceDetailType1Obj;
        } else {
            return this.setExternalRefDefaultValues(loggerType);
        }
    }

    /**
     * Accessor for property externalReferenceType.
     * 
     * @return externalReferenceType of type String
     */
    private String getExternalReferenceType(ExternalRefType externalRefType) {
        if (externalRefType != null && externalRefType.getReference() != null) {
            return externalRefType.getReference();
        }
        return "";
    }

    /**
     * Accessor for property externalReferenceCode.
     * 
     * @return externalReferenceCode of type String
     */
    private String getExternalReferenceCode(ExternalRefType externalRefType) {
        if (externalRefType != null && externalRefType.getReferenceCode() != null) {
            return externalRefType.getReferenceCode();
        }
        return "";
    }

    /**
     * Accessor for property operation.
     * 
     * @return operation of type String
     */
    private String getOperation() {
        return ClientServiceConstants.NONE;
    }

    /**
     * This method is used to set default values for external references.
     * 
     * @param externalReferenceDetails
     */
    public ExternalReferenceDetailType setExternalRefDefaultValues(String loggerType) {
        SILLogger.debug(loggerType, className, "Getting External Reference Default Values");
        ExternalReferenceDetailType externalReferenceDetailType = new ExternalReferenceDetailType();
        externalReferenceDetailType.setExternalReferenceCode("");
        externalReferenceDetailType.setExternalReferenceType("");
        externalReferenceDetailType.setOperation("");
        return externalReferenceDetailType;
    }

    /**
     * This method is use to Get Audit Details.
     * 
     * @param identifierAuditType of type IdentifierAuditType
     * @return identifierAudit of type AuditDetails
     */
    public AuditDetails getAuditDetails(IdentifierAuditType identifierAuditType, String loggerType) {
        AuditDetails auditDetails = new AuditDetails();
        if (identifierAuditType != null) {
            SILLogger.debug(loggerType, className, "Getting Fund Audit Details");
            auditDetails.setDataVersion(String.valueOf(identifierAuditType.getDataVersion()));
            auditDetails.setLastUpdated(SILUtil.convertXMLGregorianCalendartoString(identifierAuditType.getLastUpdated(),
                    CommonConstants.DATE_TIME_FORMAT));
            auditDetails.setLastUpdatedBy(identifierAuditType.getLastUpdatedBy());
        } else {
            auditDetails = getDefaultAuditDetails(loggerType);
        }
        return auditDetails;
    }

    /**
     * This method set Default values for Audit Details.
     * 
     * @return identifierAudit of type IdentifierAudit
     */
    public AuditDetails getDefaultAuditDetails(String loggerType) {
        SILLogger.debug(loggerType, className, "Getting Default Fund Audit Details");
        AuditDetails auditDetails = new AuditDetails();
        auditDetails.setDataVersion("");
        auditDetails.setLastUpdated("");
        auditDetails.setLastUpdatedBy("");
        return auditDetails;
    }

    /**
     * Getting Code Identifier Details.
     * 
     * @param codeIdentifierType
     * @param loggerType
     * @return
     */
    public CodeIdentifier getCodeIdentifierDetails(CodeIdentifierType codeIdentifierType, String loggerType) {
        CodeIdentifier codeIdentifier = new CodeIdentifier();
        if (codeIdentifierType != null) {
            SILLogger.debug(loggerType, className, "Getting Code Identifier Details");
            codeIdentifier.setCode(codeIdentifierType.getCode());
            codeIdentifier.setCodeDescription(codeIdentifierType.getCodeDescription());
            codeIdentifier.setCodeShortDescription(codeIdentifierType.getCodeShortDescription());
            codeIdentifier.setCodeType(codeIdentifierType.getCodeType());
            codeIdentifier.setId(codeIdentifierType.getId().toString());
        } else {
            codeIdentifier = getDefaultCodeIdentifierDetails(loggerType);
        }
        return codeIdentifier;
    }

    /**
     * This method sets Default values for Code Identifier.
     * 
     * @return codeIdentifier of type CodeIdentifier.
     */
    public CodeIdentifier getDefaultCodeIdentifierDetails(String loggerType) {
        SILLogger.debug(loggerType, className, "Getting Default Code Identifier Details");
        CodeIdentifier codeIdentifier = new CodeIdentifier();
        codeIdentifier.setCode("");
        codeIdentifier.setCodeDescription("");
        codeIdentifier.setCodeShortDescription("");
        codeIdentifier.setCodeType("");
        codeIdentifier.setId("");
        return codeIdentifier;
    }

    /**
     * This method is used to get list of address of client.
     * 
     * @return the list of client address
     */
    public ClientAddressType getAddressDetails(AddressDetailsType address, String loggerType) {
        ClientAddressType clientAddressTypeObj = new ClientAddressType();
        if (address != null) {
            SILLogger.debug(loggerType, className, "Entering in getAddressDetails.");
            new AddressDetailsUtil(address).constructClientAddressTypeObj(clientAddressTypeObj);
        } else {
            new AddressDetailsUtil(address).setDefaultAddressValues(clientAddressTypeObj);
        }
        return clientAddressTypeObj;
    }

    /**
     * Getting Client External Reference Details.
     * 
     * @param externalRefTypeList
     * @param loggerType
     * @return
     */
    public List<ExternalReferenceDetailType> getClientExternalReferenceDetails(List<ExternalRefType> externalRefTypeList, String loggerType) {
        List<ExternalReferenceDetailType> externalReferenceDetailsList = new ArrayList<ExternalReferenceDetailType>();
        if (externalRefTypeList != null) {
            SILLogger.debug(loggerType, className, "Getting Client External Reference Details");
            for (ExternalRefType externalRefType : externalRefTypeList) {
                externalReferenceDetailsList.add(getExternalReferenceDetails(externalRefType, loggerType));
            }
        } else {
            externalReferenceDetailsList.add(this.setExternalRefDefaultValues(loggerType));
        }
        return externalReferenceDetailsList;
    }

    /**
     * This method constructs the auditinfo object from response.
     * 
     * @param audit,loggerType
     * @return auditIdentifier
     * @throws SILException
     */
    public AuditDetails retrieveAudit(IdentifierAuditType audit, String loggerType) throws SILException {
        AuditDetails auditIdentifier = new AuditDetails();
        if (audit != null) {
            SILLogger.debug(loggerType, className, "Entering in retrieveAudit method");
            auditIdentifier.setLastUpdated(retrieveDateValue(audit.getLastUpdated(), loggerType));
            auditIdentifier.setLastUpdatedBy(audit.getLastUpdatedBy());
            auditIdentifier.setDataVersion(retrieveLongValue(audit.getDataVersion()));
        } else {
            auditIdentifier = retrieveEmptyAudit(loggerType);
        }
        return auditIdentifier;
    }

    /**
     * This method constructs default Audit object.
     * 
     * @param loggerType
     * @return auditIdentifier
     * @throws SILException
     */
    public AuditDetails retrieveEmptyAudit(String loggerType) throws SILException {
        SILLogger.debug(loggerType, className, "Entering in retrieveEmptyAudit method");
        AuditDetails auditIdentifier = new AuditDetails();
        auditIdentifier.setLastUpdated(ClientServiceConstants.GET_CLIENT_EMPTY_STRING);
        auditIdentifier.setLastUpdatedBy(ClientServiceConstants.GET_CLIENT_EMPTY_STRING);
        auditIdentifier.setDataVersion(ClientServiceConstants.GET_CLIENT_EMPTY_STRING);
        return auditIdentifier;
    }

    /**
     * This method convert XMLGregorianCalendar to String.
     * 
     * @return String
     */
    public String retrieveDateValue(XMLGregorianCalendar gregorianCalendar, String loggerType) throws SILException {
        SILLogger.debug(loggerType, className, "Entering in retrieveDateValue method");
        if (gregorianCalendar != null) {
            return SILUtil.convertXMLGregorianCalendartoString(gregorianCalendar, CommonConstants.DATE_TIME_FORMAT);
        } else {
            return ClientServiceConstants.GET_CLIENT_EMPTY_STRING;
        }
    }

    /**
     * This method convert Big decimal value to String object.
     * 
     * @return String
     */
    public String retrieveLongValue(Long value) throws SILException {
        SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "GetClientDetailsUtil", "Entering in retrieveLongValue method");
        if (value != null) {
            return String.valueOf(value);
        } else {
            return ClientServiceConstants.GET_CLIENT_EMPTY_STRING;
        }
    }

    /**
     * This method convert String to XMLGregorianCalendar.
     * 
     * @return String
     */
    public XMLGregorianCalendar retrieveDateValueFromString(String gregorianCalendar, String loggerType) throws SILException {
        SILLogger.debug(loggerType, className, "entrying retrieveDateValueFromString()");
        if (gregorianCalendar != null) {
            return SILUtil.convertStringToXMLGregorianCalendar(gregorianCalendar, CommonConstants.DATE_FORMAT);
        } else {
            return null;
        }
    }

    /**
     * This method convert Big decimal value to String object.
     * 
     * @return String
     */
    public String retrieveStringValue(String value) {
        SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "GetClientDetailsUtil", "Entering in retrieveStringValue method");
        if (value != null) {
            return value;
        } else {
            return CommonConstants.EMPTY_STRING_VALUE;
        }
    }

    /**
     * This method is used to set error details for successful scenarios.
     * 
     * @return errorBean
     */
    public ErrorBean retrieveErrorDetailsSuccessfulScenario(String loggerType) {
        SILLogger.debug(loggerType, className, "entrying retrieveDateValueFromString()");
        ErrorBean errorBean = new ErrorBean();
        errorBean.setCode(ClientServiceConstants.SUCCESS_CODE);
        errorBean.setSeverity("");
        errorBean.setDescription("");
        return errorBean;
    }

    /**
     * This method is used to set error response.
     * 
     * @param exchange
     * 
     */
    public void setErrorResponse(Exchange exchange, String code, String description) {
        GetCustomerByProductDetails getCustomerByProductDetails = new GetCustomerByProductDetails();
        ErrorBean errorBean = new ErrorBean();
        errorBean.setCode(code);
        errorBean.setSeverity(ClientServiceConstants.ERROR_SEVERITY_SYSTEM_ERROR);
        errorBean.setDescription(description);
        getCustomerByProductDetails.setError(errorBean);
        Response response = Response.status(Response.Status.OK).entity(getCustomerByProductDetails).build();
        exchange.getIn().setBody(response);
    }
}
