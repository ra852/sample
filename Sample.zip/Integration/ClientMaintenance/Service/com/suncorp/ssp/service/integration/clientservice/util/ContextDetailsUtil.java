////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.clientservice.util;

import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.List;

import com.sonatacentral.service.v30.common.client.GetClientResponseType;
import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.ClientContextType;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.clientservice.ClientServiceConstants;
import com.suncorp.ssp.service.integration.clientservice.bean.ClientContextDetailType;

/**
 * The class {@code ContextDetailsUtil} does this.
 * 
 * @author U383754
 * @since 28/10/2015
 * @version 1.0
 */
public class ContextDetailsUtil {
    private GetClientResponseType getClientResponseType;
    private ClientContextType clientContextType;

    public ContextDetailsUtil(GetClientResponseType getClientResponseType) {
        this.getClientResponseType = getClientResponseType;
    }

    /**
     * 
     * This method is used to get context details of client.
     * 
     * @param contextDetails
     */
    public void getContextDetails(List<ClientContextDetailType> contextDetails) {
        SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "ContextDetailsUtil", "Entering in getContextDetails.");
        if (this.getClientResponseType != null && this.getClientResponseType.getClientContext() != null &&
                this.getClientResponseType.getClientContext().size() != 0) {
            List<ClientContextType> clientContextTypesList = this.getClientResponseType.getClientContext();
            Iterator<ClientContextType> clientContextIterator = clientContextTypesList.iterator();
            while (clientContextIterator.hasNext()) {
                this.clientContextType = clientContextIterator.next();
                ClientContextDetailType clientContextDetailType1Obj = new ClientContextDetailType();
                clientContextDetailType1Obj.setClientContextId(this.getClientContextId());
                clientContextDetailType1Obj.setOperation(this.getOperation());
                clientContextDetailType1Obj.setRelatedClient(this.getRelatedClient());
                clientContextDetailType1Obj.setCodeIndentifierType(this.getCodeIndentifierType());
                clientContextDetailType1Obj.setEffectiveFromDate(this.getEffectiveFromDate());
                clientContextDetailType1Obj.setEffectiveEndDate(this.getEffectiveEndDate());
                clientContextDetailType1Obj.setIsRelatedClient(this.getIsRelatedClient());
                contextDetails.add(clientContextDetailType1Obj);
            }
        } else {
            this.setDefaultValues(contextDetails);
        }
        SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "ContextDetailsUtil", "Exiting in getContextDetails.");
    }

    /**
     * Accessor for property clientContextId.
     * 
     * @return clientContextId of type String
     */
    private String getClientContextId() {
        if (this.clientContextType != null) {
            return Long.toString(this.clientContextType.getId());
        }
        return "";
    }

    /**
     * Accessor for property operation.
     * 
     * @return operation of type String
     */
    private String getOperation() {
        return ClientServiceConstants.NONE;
    }

    /**
     * Accessor for property relatedClient.
     * 
     * @return relatedClient of type String
     */
    private String getRelatedClient() {
        if (this.clientContextType != null && this.clientContextType.getRelatedClient() != null &&
                this.clientContextType.getRelatedClient().getId() != null) {
            return Long.toString(this.clientContextType.getRelatedClient().getId());
        }
        return "";
    }

    /**
     * Accessor for property codeIndentifierType.
     * 
     * @return codeIndentifierType of type String
     */
    private String getCodeIndentifierType() {
        boolean[] condition =
                { this.clientContextType != null, this.clientContextType.getTypeCode() != null,
                        this.clientContextType.getTypeCode().getCode() != null };
        if (condition[0] && condition[1] && condition[2]) {
            return this.clientContextType.getTypeCode().getCode();
        }
        return "";
    }

    /**
     * Accessor for property effectiveFromDate.
     * 
     * @return effectiveFromDate of type String
     */
    private String getEffectiveFromDate() {
        if (this.clientContextType != null && this.clientContextType.getEffectiveFromDate() != null &&
                this.clientContextType.getEffectiveFromDate().toGregorianCalendar() != null) {
            return new SimpleDateFormat(ClientServiceConstants.DATE_TIME_FORMAT).format(this.clientContextType.getEffectiveFromDate()
                    .toGregorianCalendar().getTime());
        }
        return "";
    }

    /**
     * Accessor for property effectiveEndDate.
     * 
     * @return effectiveEndDate of type String
     */
    private String getEffectiveEndDate() {
        if (this.clientContextType != null && this.clientContextType.getEffectiveEndDate() != null &&
                this.clientContextType.getEffectiveEndDate().toGregorianCalendar() != null) {
            return new SimpleDateFormat(ClientServiceConstants.DATE_TIME_FORMAT).format(this.clientContextType.getEffectiveEndDate()
                    .toGregorianCalendar().getTime());
        }
        return "";
    }

    /**
     * Accessor for property isRelatedClient.
     * 
     * @return isRelatedClient of type String
     */
    private String getIsRelatedClient() {
        if (this.clientContextType != null) {
            return Boolean.toString(this.clientContextType.isIsRelatedClient());
        }
        return "";
    }

    /**
     * Does this.
     * 
     * @param contextDetails
     */
    private void setDefaultValues(List<ClientContextDetailType> contextDetails) {
        ClientContextDetailType clientContextDetailType2Obj = new ClientContextDetailType();
        clientContextDetailType2Obj.setClientContextId("");
        clientContextDetailType2Obj.setOperation("");
        clientContextDetailType2Obj.setRelatedClient("");
        clientContextDetailType2Obj.setCodeIndentifierType("");
        clientContextDetailType2Obj.setEffectiveFromDate("");
        clientContextDetailType2Obj.setEffectiveEndDate("");
        clientContextDetailType2Obj.setIsRelatedClient("");
        contextDetails.add(clientContextDetailType2Obj);
    }
}
