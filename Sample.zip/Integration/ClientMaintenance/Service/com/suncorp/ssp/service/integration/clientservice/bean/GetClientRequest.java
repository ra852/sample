////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package com.suncorp.ssp.service.integration.clientservice.bean;

import javax.xml.bind.annotation.XmlRootElement;

/**
 * The class {@code GetClientRequest} is a java bean consisting of properties
 * related to client ID, to be used for constructing client request.
 * 
 * @author U383754
 * @since 2015-10-01
 * @version 1.0
 */
@XmlRootElement(name = "GetClientRequest")
public class GetClientRequest {
    private Long clientId;

    /**
     * Accessor for property clientId.
     * 
     * @return clientId of type Long
     */
    public Long getClientId() {
        return clientId;
    }

    /**
     * Mutator for property clientId.
     * 
     * @param clientId
     *            of type Long
     */
    public void setClientId(Long clientId) {
        this.clientId = clientId;
    }
}
