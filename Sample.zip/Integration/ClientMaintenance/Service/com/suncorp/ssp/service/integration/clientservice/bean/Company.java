////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.clientservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code Company} does this.
 *
 * @author U383847
 * @since 04/04/2016
 * @version 1.0
 */
public class Company {
    private String abn;
    private String acnArbn;
    private String spin;
    private String regListingCodeType;
    private String regListingCode;
    
    /**
     * Accessor for property abn.
     *
     * @return abn of type String
     */
    public String getAbn() {
        return abn;
    }
    
    /**
     * Mutator for property abn.
     *
     * @param abn of type String
     */
    @XmlElement(name = "abn")
    public void setAbn(String abn) {
        this.abn = abn;
    }
        
    /**
     * Accessor for property acnArbn.
     *
     * @return acnArbn of type String
     */
    public String getAcnArbn() {
        return acnArbn;
    }
    
    /**
     * Mutator for property acnArbn.
     *
     * @param acnArbn of type String
     */
    @XmlElement(name = "acnArbn")
    public void setAcnArbn(String acnArbn) {
        this.acnArbn = acnArbn;
    }
    
    /**
     * Accessor for property spin.
     *
     * @return spin of type String
     */
    public String getSpin() {
        return spin;
    }
    
    /**
     * Mutator for property spin.
     *
     * @param spin of type String
     */
    @XmlElement(name = "spin")
    public void setSpin(String spin) {
        this.spin = spin;
    }
    
    /**
     * Accessor for property regListingCodeType.
     *
     * @return regListingCodeType of type String
     */
    public String getRegListingCodeType() {
        return regListingCodeType;
    }
    
    /**
     * Mutator for property regListingCodeType.
     *
     * @param regListingCodeType of type String
     */
    @XmlElement(name = "regListingCodeType")
    public void setRegListingCodeType(String regListingCodeType) {
        this.regListingCodeType = regListingCodeType;
    }
    
    /**
     * Accessor for property regListingCode.
     *
     * @return regListingCode of type String
     */
    public String getRegListingCode() {
        return regListingCode;
    }
    
    /**
     * Mutator for property regListingCode.
     *
     * @param regListingCode of type String
     */
    @XmlElement(name = "regListingCode")
    public void setRegListingCode(String regListingCode) {
        this.regListingCode = regListingCode;
    }
}
