////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.clientservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code ClientBankDetailType} does this.
 * 
 * @author U383754
 * @since 23/10/2015
 * @version 1.0
 */
public class ClientBankDetailType {
    private String bankId;
    private String operation;
    private String bankCode;
    private String bankCodeType;
    private String bankAccount;
    private String accountName;
    private String bankName;
    private String branchName;
    private String bsbNumber;

    /**
     * Accessor for property bankId.
     * 
     * @return bankId of type String
     */
    public String getBankId() {
        return bankId;
    }

    /**
     * Mutator for property bankId.
     * 
     * @param bankId of type String
     */
    @XmlElement(name = "bankId")
    public void setBankId(String bankId) {
        this.bankId = bankId;
    }

    /**
     * Accessor for property operation.
     * 
     * @return operation of type String
     */
    public String getOperation() {
        return operation;
    }

    /**
     * Mutator for property operation.
     * 
     * @param operation of type String
     */
    @XmlElement(name = "operation")
    public void setOperation(String operation) {
        this.operation = operation;
    }

    /**
     * Accessor for property bankCode.
     * 
     * @return bankCode of type String
     */
    public String getBankCode() {
        return bankCode;
    }

    /**
     * Mutator for property bankCode.
     * 
     * @param bankCode of type String
     */
    @XmlElement(name = "bankCode")
    public void setBankCode(String bankCode) {
        this.bankCode = bankCode;
    }

    /**
     * Accessor for property bankCodeType.
     * 
     * @return bankCodeType of type String
     */
    public String getBankCodeType() {
        return bankCodeType;
    }

    /**
     * Mutator for property bankCodeType.
     * 
     * @param bankCodeType of type String
     */
    @XmlElement(name = "bankCodeType")
    public void setBankCodeType(String bankCodeType) {
        this.bankCodeType = bankCodeType;
    }

    /**
     * Accessor for property bankAccount.
     * 
     * @return bankAccount of type String
     */
    public String getBankAccount() {
        return bankAccount;
    }

    /**
     * Mutator for property bankAccount.
     * 
     * @param bankAccount of type String
     */
    @XmlElement(name = "bankAccount")
    public void setBankAccount(String bankAccount) {
        this.bankAccount = bankAccount;
    }

    /**
     * Accessor for property accountName.
     * 
     * @return accountName of type String
     */
    public String getAccountName() {
        return accountName;
    }

    /**
     * Mutator for property accountName.
     * 
     * @param accountName of type String
     */
    @XmlElement(name = "accountName")
    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    /**
     * Accessor for property bankName.
     * 
     * @return bankName of type String
     */
    public String getBankName() {
        return bankName;
    }

    /**
     * Mutator for property bankName.
     * 
     * @param bankName of type String
     */
    @XmlElement(name = "bankName")
    public void setBankName(String bankName) {
        this.bankName = bankName;
    }

    /**
     * Accessor for property branchName.
     * 
     * @return branchName of type String
     */
    public String getBranchName() {
        return branchName;
    }

    /**
     * Mutator for property branchName.
     * 
     * @param branchName of type String
     */
    @XmlElement(name = "branchName")
    public void setBranchName(String branchName) {
        this.branchName = branchName;
    }

    /**
     * Accessor for property bsbNumber.
     * 
     * @return bsbNumber of type String
     */
    public String getBsbNumber() {
        return bsbNumber;
    }

    /**
     * Mutator for property bsbNumber.
     * 
     * @param bsbNumber of type String
     */
    @XmlElement(name = "bsbNumber")
    public void setBsbNumber(String bsbNumber) {
        this.bsbNumber = bsbNumber;
    }
}
