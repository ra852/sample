////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.clientservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code ClientContextDetailType} does this.
 * 
 * @author U383754
 * @since 23/10/2015
 * @version 1.0
 */
public class ClientContextDetailType {
    private String clientContextId;
    private String operation;
    private String relatedClient;
    private String codeIndentifierType;
    private String codeIndentifierCodeType;
    private String effectiveFromDate;
    private String effectiveEndDate;
    private String isRelatedClient;

    /**
     * Accessor for property clientContextId.
     * 
     * @return clientContextId of type String
     */
    public String getClientContextId() {
        return clientContextId;
    }

    /**
     * Mutator for property clientContextId.
     * 
     * @param clientContextId of type String
     */
    @XmlElement(name = "clientcontextId")
    public void setClientContextId(String clientContextId) {
        this.clientContextId = clientContextId;
    }

    /**
     * Accessor for property operation.
     * 
     * @return operation of type String
     */
    public String getOperation() {
        return operation;
    }

    /**
     * Mutator for property operation.
     * 
     * @param operation of type String
     */
    @XmlElement(name = "operation")
    public void setOperation(String operation) {
        this.operation = operation;
    }

    /**
     * Accessor for property relatedClient.
     * 
     * @return relatedClient of type String
     */
    public String getRelatedClient() {
        return relatedClient;
    }

    /**
     * Mutator for property relatedClient.
     * 
     * @param relatedClient of type String
     */
    @XmlElement(name = "relatedClient")
    public void setRelatedClient(String relatedClient) {
        this.relatedClient = relatedClient;
    }

    /**
     * Accessor for property codeIndentifierType.
     * 
     * @return codeIndentifierType of type String
     */
    public String getCodeIndentifierType() {
        return codeIndentifierType;
    }

    /**
     * Mutator for property codeIndentifierType.
     * 
     * @param codeIndentifierType of type String
     */
    @XmlElement(name = "codeIndentifiertype")
    public void setCodeIndentifierType(String codeIndentifierType) {
        this.codeIndentifierType = codeIndentifierType;
    }

    /**
     * Accessor for property codeIndentifierCodeType.
     * 
     * @return codeIndentifierCodeType of type String
     */
    public String getCodeIndentifierCodeType() {
        return codeIndentifierCodeType;
    }

    /**
     * Mutator for property codeIndentifierCodeType.
     * 
     * @param codeIndentifierCodeType of type String
     */
    @XmlElement(name = "codeIndentifierCodeType")
    public void setCodeIndentifierCodeType(String codeIndentifierCodeType) {
        this.codeIndentifierCodeType = codeIndentifierCodeType;
    }

    /**
     * Accessor for property effectiveFromDate.
     * 
     * @return effectiveFromDate of type String
     */
    public String getEffectiveFromDate() {
        return effectiveFromDate;
    }

    /**
     * Mutator for property effectiveFromDate.
     * 
     * @param effectiveFromDate of type String
     */
    @XmlElement(name = "effectiveFromdate")
    public void setEffectiveFromDate(String effectiveFromDate) {
        this.effectiveFromDate = effectiveFromDate;
    }

    /**
     * Accessor for property effectiveEndDate.
     * 
     * @return effectiveEndDate of type String
     */
    public String getEffectiveEndDate() {
        return effectiveEndDate;
    }

    /**
     * Mutator for property effectiveEndDate.
     * 
     * @param effectiveEndDate of type String
     */
    @XmlElement(name = "effectiveEnddate")
    public void setEffectiveEndDate(String effectiveEndDate) {
        this.effectiveEndDate = effectiveEndDate;
    }

    /**
     * Accessor for property isRelatedClient.
     * 
     * @return isRelatedClient of type String
     */
    public String getIsRelatedClient() {
        return isRelatedClient;
    }

    /**
     * Mutator for property isRelatedClient.
     * 
     * @param isRelatedClient of type String
     */
    @XmlElement(name = "isrelatedClient")
    public void setIsRelatedClient(String isRelatedClient) {
        this.isRelatedClient = isRelatedClient;
    }
}
