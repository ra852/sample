////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.clientservice.util;

import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.List;

import com.sonatacentral.service.v30.common.client.GetClientResponseType;
import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.AdvisorGroupType;
import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.AdvisorSplitType;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.clientservice.ClientServiceConstants;
import com.suncorp.ssp.service.integration.clientservice.bean.ClientAdvisorDetailType;

/**
 * The class {@code AdvisorDetailsUtil} does this.
 * 
 * @author U383754
 * @since 28/10/2015
 * @version 1.0
 */
public class AdvisorDetailsUtil {
    private GetClientResponseType getClientResponseType;
    private AdvisorGroupType advisorGroupType;
    private AdvisorSplitType advisorSplitType;

    public AdvisorDetailsUtil(GetClientResponseType getClientResponseType) {
        this.getClientResponseType = getClientResponseType;
    }

    /**
     * This method is used to get advisor details of client.
     * 
     * @param advisorDetails
     */
    public void getAdvisorDetails(List<ClientAdvisorDetailType> advisorDetails) {
        SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "AdvisorDetailsUtil", "Entering in getAdvisorDetails.");
        if (this.getClientResponseType != null && this.getClientResponseType.getAdvisorGroup() != null &&
                this.getClientResponseType.getAdvisorGroup().size() != 0) {
            List<AdvisorGroupType> advisorGroupTypesList = this.getClientResponseType.getAdvisorGroup();
            Iterator<AdvisorGroupType> advisorGroupIterator = advisorGroupTypesList.iterator();
            while (advisorGroupIterator.hasNext()) {
                this.advisorGroupType = advisorGroupIterator.next();
                ClientAdvisorDetailType clientAdvisorDetailType1Obj = new ClientAdvisorDetailType();
                this.constructClientAdvisorDetailType(advisorGroupTypesList, clientAdvisorDetailType1Obj);
                advisorDetails.add(clientAdvisorDetailType1Obj);
            }
        } else {
            this.setDefaultValues(advisorDetails);
        }
        SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "AdvisorDetailsUtil", "Exiting in getAdvisorDetails.");
    }

    /**
     * 
     * This method is used to construct object of type advisor detail.
     * 
     * @param advisorGroupTypesList
     * @param clientAdvisorDetailType1Obj
     */
    private void constructClientAdvisorDetailType(List<AdvisorGroupType> advisorGroupTypesList, ClientAdvisorDetailType clientAdvisorDetailType1Obj) {
        clientAdvisorDetailType1Obj.setAdvisorgroupId(this.getAdvisorgroupId());
        clientAdvisorDetailType1Obj.setOperation(this.getOperation());
        clientAdvisorDetailType1Obj.setRelationshipId(this.getRelationshipId());
        clientAdvisorDetailType1Obj.setRelationshipCode(this.getRelationshipCode());
        clientAdvisorDetailType1Obj.setEffectiveDate(this.getEffectiveDate());

        List<AdvisorSplitType> advisorSplitTypesList = this.advisorGroupType.getAdvisorSplit();
        if (advisorGroupTypesList != null && advisorGroupTypesList.get(0) != null) {
            this.advisorSplitType = advisorSplitTypesList.get(0);
            clientAdvisorDetailType1Obj.setAdvisorNumber(this.getAdvisorNumber());
            clientAdvisorDetailType1Obj.setAdvisorForename(this.getAdvisorForename());
            clientAdvisorDetailType1Obj.setAdvisorSurname(this.getAdvisorSurname());
            clientAdvisorDetailType1Obj.setAdvisorMaster(this.getAdvisorMaster());
            clientAdvisorDetailType1Obj.setOutletstatusCodetype(this.getOutletstatusCodetype());
            clientAdvisorDetailType1Obj.setOutletypeCodetype(this.getOutletypeCodetype());
            clientAdvisorDetailType1Obj.setOutletType(this.getOutletType());
            clientAdvisorDetailType1Obj.setPercentageSplit(this.getPercentageSplit());
        }
    }

    /**
     * Accessor for property advisorgroupId.
     * 
     * @return advisorgroupId of type String
     */
    private String getAdvisorgroupId() {
        if (this.advisorGroupType != null) {
            return Long.toString(this.advisorGroupType.getId());
        }
        return "";
    }

    /**
     * Accessor for property operation.
     * 
     * @return operation of type String
     */
    private String getOperation() {
        return ClientServiceConstants.NONE;
    }

    /**
     * Accessor for property relationshipId.
     * 
     * @return relationshipId of type String
     */
    private String getRelationshipId() {
        if (this.advisorGroupType != null && this.advisorGroupType.getRelationshipType() != null &&
                this.advisorGroupType.getRelationshipType().getId() != null) {
            return Long.toString(this.advisorGroupType.getRelationshipType().getId());
        }
        return "";
    }

    /**
     * Accessor for property relationshipCode.
     * 
     * @return relationshipCode of type String
     */
    private String getRelationshipCode() {
        if (this.advisorGroupType != null && this.advisorGroupType.getRelationshipType() != null &&
                this.advisorGroupType.getRelationshipType().getCode() != null) {
            return this.advisorGroupType.getRelationshipType().getCode();
        }
        return "";
    }

    /**
     * Accessor for property advisorNumber.
     * 
     * @return advisorNumber of type String
     */
    private String getAdvisorNumber() {
        if (this.advisorSplitType != null && this.advisorSplitType.getAdvisor() != null &&
                this.advisorSplitType.getAdvisor().getAdvisorNumber() != null) {
            return this.advisorSplitType.getAdvisor().getAdvisorNumber();
        }
        return "";
    }

    /**
     * Accessor for property advisorForename.
     * 
     * @return advisorForename of type String
     */
    private String getAdvisorForename() {
        if (this.advisorSplitType != null && this.advisorSplitType.getAdvisor() != null &&
                this.advisorSplitType.getAdvisor().getClientForename() != null) {
            return this.advisorSplitType.getAdvisor().getClientForename();
        }
        return "";
    }

    /**
     * Accessor for property advisorSurname.
     * 
     * @return advisorSurname of type String
     */
    private String getAdvisorSurname() {
        if (this.advisorSplitType != null && this.advisorSplitType.getAdvisor() != null &&
                this.advisorSplitType.getAdvisor().getClientSurname() != null) {
            return this.advisorSplitType.getAdvisor().getClientSurname();
        }
        return "";
    }

    /**
     * Accessor for property advisorMaster.
     * 
     * @return advisorMaster of type String
     */
    private String getAdvisorMaster() {
        if (this.advisorSplitType != null && this.advisorSplitType.getAdvisor() != null &&
                this.advisorSplitType.getAdvisor().getMasterScheme() != null &&
                this.advisorSplitType.getAdvisor().getMasterScheme().getDisplayName() != null) {
            return this.advisorSplitType.getAdvisor().getMasterScheme().getDisplayName();
        }
        return "";
    }

    /**
     * Accessor for property outletstatusCodetype.
     * 
     * @return outletstatusCodetype of type String
     */
    private String getOutletstatusCodetype() {
        if (this.advisorSplitType != null && this.advisorSplitType.getAdvisor() != null && this.advisorSplitType.getAdvisor().getStatus() != null &&
                this.advisorSplitType.getAdvisor().getStatus().getCodeType() != null) {
            return this.advisorSplitType.getAdvisor().getStatus().getCodeType();
        }
        return "";
    }

    /**
     * Accessor for property outletypeCodetype.
     * 
     * @return outletypeCodetype of type String
     */
    private String getOutletypeCodetype() {
        if (this.advisorSplitType != null && this.advisorSplitType.getAdvisor() != null &&
                this.advisorSplitType.getAdvisor().getOutletType() != null &&
                this.advisorSplitType.getAdvisor().getOutletType().getCodeType() != null) {
            return this.advisorSplitType.getAdvisor().getOutletType().getCodeType();
        }
        return "";
    }

    /**
     * Accessor for property outletType.
     * 
     * @return outletType of type String
     */
    private String getOutletType() {
        if (this.advisorSplitType != null && this.advisorSplitType.getAdvisor() != null &&
                this.advisorSplitType.getAdvisor().getOutletType() != null && this.advisorSplitType.getAdvisor().getOutletType().getCode() != null) {
            return this.advisorSplitType.getAdvisor().getOutletType().getCode();
        }
        return "";
    }

    /**
     * Accessor for property effectiveDate.
     * 
     * @return effectiveDate of type String
     */
    private String getEffectiveDate() {
        if (this.advisorGroupType.getEffectiveDate() != null && this.advisorGroupType.getEffectiveDate().toGregorianCalendar() != null) {
            return new SimpleDateFormat(ClientServiceConstants.DATE_TIME_FORMAT).format(this.advisorGroupType.getEffectiveDate()
                    .toGregorianCalendar().getTime());
        }
        return "";
    }

    /**
     * Accessor for property percentageSplit.
     * 
     * @return percentageSplit of type String
     */
    private String getPercentageSplit() {
        if (this.advisorSplitType != null && this.advisorSplitType.getPercentageSplit() != null) {
            return String.valueOf(this.advisorSplitType.getPercentageSplit().doubleValue());
        }
        return "";
    }

    /**
     * Does this.
     * 
     * @param advisorDetails
     */
    private void setDefaultValues(List<ClientAdvisorDetailType> advisorDetails) {
        ClientAdvisorDetailType clientAdvisorDetailType2Obj = new ClientAdvisorDetailType();
        clientAdvisorDetailType2Obj.setAdvisorgroupId("");
        clientAdvisorDetailType2Obj.setOperation("");
        clientAdvisorDetailType2Obj.setRelationshipId("");
        clientAdvisorDetailType2Obj.setRelationshipCode("");
        clientAdvisorDetailType2Obj.setEffectiveDate("");
        clientAdvisorDetailType2Obj.setAdvisorNumber("");
        clientAdvisorDetailType2Obj.setAdvisorForename("");
        clientAdvisorDetailType2Obj.setAdvisorSurname("");
        clientAdvisorDetailType2Obj.setAdvisorMaster("");
        clientAdvisorDetailType2Obj.setOutletstatusCodetype("");
        clientAdvisorDetailType2Obj.setOutletypeCodetype("");
        clientAdvisorDetailType2Obj.setOutletType("");
        clientAdvisorDetailType2Obj.setPercentageSplit("");
        advisorDetails.add(clientAdvisorDetailType2Obj);
    }
}
