////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package com.suncorp.ssp.service.integration.clientservice.util;

import com.sonatacentral.service.v30.common.client.SaveClientResponseType;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.clientservice.ClientServiceConstants;
import com.suncorp.ssp.service.integration.clientservice.bean.SaveClientResponse;

/**
 * The class {@code SaveClientDetailsUtil} is a Utility class with all the properties related to save client details, to construct response for end
 * client by extracting values from the external service's response object.
 * 
 * @author U383847
 * @since 29/10/2015
 * @version 1.0
 */
public class SaveClientDetailsUtil {
    private SaveClientResponseType saveClientResponseType;

    /**
     * Parameterized constructor for properties initialization.
     * 
     * @param saveClientResponseType of type SaveClientResponseType
     */
    public SaveClientDetailsUtil(SaveClientResponseType saveClientResponseType) {
        this.saveClientResponseType = saveClientResponseType;
    }

    /**
     * Extracts values from the external service's response and maps to end client response.
     * 
     * @param saveClientResponse of type SaveClientResponse
     */
    public void saveClientResponse(SaveClientResponse saveClientResponse) {
        if (this.saveClientResponseType != null) {
            saveClientResponse.setClientId(this.getClientId());
            saveClientResponse.setClientName(this.getClientName());
            saveClientResponse.setClientTfn(this.getTfn());
            saveClientResponse.setFirstName(this.getFirstName());
            saveClientResponse.setLastName(this.getLastName());
            saveClientResponse.setStatus(this.getStatus());
        }
    }

    /**
     * Returns client TFN, if exists.
     * 
     * @return object of type String
     */
    private String getTfn() {
        if (this.saveClientResponseType.getClient() != null && this.saveClientResponseType.getClient().getClientTFN() != null) {
            return this.saveClientResponseType.getClient().getClientTFN();
        }
        return "";
    }

    /**
     * Returns Client ID, if exists.
     * 
     * @return object of type String
     */
    private String getClientId() {
        if (this.saveClientResponseType.getClient() != null && this.saveClientResponseType.getClient().getId() != null) {
            return this.saveClientResponseType.getClient().getId().toString();
        }
        return "";
    }

    /**
     * Returns Client Name, if exists.
     * 
     * @return object of type String
     */
    private String getClientName() {
        if (this.saveClientResponseType.getClient() != null && this.saveClientResponseType.getClient().getName() != null) {
            return this.saveClientResponseType.getClient().getName().toString();
        }
        return "";
    }

    /**
     * Returns Client last name, if exists.
     * 
     * @return object of type String
     */
    private String getLastName() {
        if (this.saveClientResponseType.getClient() != null && this.saveClientResponseType.getClient().getClientSurname() != null) {
            return this.saveClientResponseType.getClient().getClientSurname();
        }
        return "";
    }

    /**
     * Returns Client first name, if exists.
     * 
     * @return object of type String
     */
    private String getFirstName() {
        if (this.saveClientResponseType.getClient() != null && this.saveClientResponseType.getClient().getClientForename() != null) {
            return this.saveClientResponseType.getClient().getClientForename();
        }
        return "";
    }

    /**
     * 
     * Does this.
     * 
     * @return
     */
    private String getStatus() {
        SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, "SaveClientDetailsUtil",
                "Inside getStatus" + this.saveClientResponseType.getValidationMessage());
        if (this.saveClientResponseType.getClient() != null && this.saveClientResponseType.getClient().getAudit() != null) {
            return ClientServiceConstants.SUCCESS_STATUS;
        }
        return "";
    }
}
