////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.clientservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code ExternalReferenceDetailType} does this.
 * 
 * @author U383847
 * @since 09/12/2015
 * @version 1.0
 */
public class ExternalReferenceDetailType {
    private String externalReferenceType;
    private String externalReferenceCode;
    private String operation;

    /**
     * Accessor for property externalReferenceType.
     * 
     * @return externalReferenceType of type String
     */
    public String getExternalReferenceType() {
        return externalReferenceType;
    }

    /**
     * Mutator for property externalReferenceType.
     * 
     * @param externalReferenceType of type String
     */
    @XmlElement(name = "externalReferenceType")
    public void setExternalReferenceType(String externalReferenceType) {
        this.externalReferenceType = externalReferenceType;
    }

    /**
     * Accessor for property externalReferenceCode.
     * 
     * @return externalReferenceCode of type String
     */
    public String getExternalReferenceCode() {
        return externalReferenceCode;
    }

    /**
     * Mutator for property externalReferenceCode.
     * 
     * @param externalReferenceCode of type String
     */
    @XmlElement(name = "externalReferenceCode")
    public void setExternalReferenceCode(String externalReferenceCode) {
        this.externalReferenceCode = externalReferenceCode;
    }

    /**
     * Accessor for property operation.
     * 
     * @return operation of type String
     */
    public String getOperation() {
        return operation;
    }

    /**
     * Mutator for property operation.
     * 
     * @param operation of type String
     */
    @XmlElement(name = "operation")
    public void setOperation(String operation) {
        this.operation = operation;
    }

}
