////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.clientservice.util;

import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.ClientEntityType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CodeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.NoteCategoryIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.NoteTemplateIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.NoteType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.clientservice.ClientServiceConstants;
import com.suncorp.ssp.service.integration.clientservice.bean.AustraliaDetails;
import com.suncorp.ssp.service.integration.clientservice.bean.Company;
import com.suncorp.ssp.service.integration.clientservice.bean.CountryNameType;

/**
 * The class {@code SaveCountryDetailsUtil} is a Utility class with Context details related to client, to construct request for saving client external
 * service's request object.
 * 
 * @author U383847
 * @since 11/12/2015
 * @version 1.0
 */
public class SaveCountryDetailsUtil {
    private final String className = "SaveCountryDetailsUtil";

    /**
     * Set Client Country Details.
     * 
     * @param clientEntityType
     * @param countryNameType
     * @param australiaDetails
     * @throws Exception
     */
    public void setCountryDetails(ClientEntityType.Australia australia, CountryNameType countryNameType, AustraliaDetails australiaDetails)
            throws SILException {
        SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Setting Client Country Details");
        this.setTfnDetails(australia, countryNameType);
        this.setTfnExemptionDetails(australia, countryNameType);
        this.setSuperTickDetails(australia, countryNameType);
        this.setAmlDetails(australia, countryNameType);
        this.setCompanyDetails(australia, countryNameType);
    }

    /**
     * Set Australia Details.
     * 
     * @param clientEntityType
     * @param australiaDetails
     * @throws Exception
     */
    public void setAustraliaDetails(ClientEntityType.Australia australia, AustraliaDetails australiaDetails) throws SILException {
        SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "inside setAustraliaDetails method");
        if (australiaDetails.getDateOfLastContact() != null) {
            australia.setDateOfLastContact(australiaDetails.getDateOfLastContact());
        }
    }

    /**
     * Set Tfn Details.
     * 
     * @param australia
     * @param countryNameType
     */
    private void setTfnDetails(ClientEntityType.Australia australia, CountryNameType countryNameType) {
        if (countryNameType.getTfn() != null) {
            SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Setting TFN Details");
            ClientEntityType.Australia.TfnDetail tfnDetails = new ClientEntityType.Australia.TfnDetail();
            tfnDetails.setTfn(countryNameType.getTfn());
            australia.setTfnDetail(tfnDetails);
        }
    }

    /**
     * Set Tfn Exemption Details.
     * 
     * @param australia
     * @param countryNameType
     */
    private void setTfnExemptionDetails(ClientEntityType.Australia australia, CountryNameType countryNameType) {
        if (countryNameType.getTfnExemptioncode() != null && countryNameType.getTfnExemptioncodetype() != null) {
            SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Setting TFN Exemption Details");
            ClientEntityType.Australia.TfnDetail tfnDetails = new ClientEntityType.Australia.TfnDetail();
            CodeIdentifierType tfnCodeIdentifierType = new CodeIdentifierType();
            tfnCodeIdentifierType.setCode(countryNameType.getTfnExemptioncode());
            tfnCodeIdentifierType.setCodeType(countryNameType.getTfnExemptioncodetype());
            tfnDetails.setTfnExemptionReason(tfnCodeIdentifierType);
            australia.setTfnDetail(tfnDetails);
        }
    }

    /**
     * Set SuperTick Details.
     * 
     * @param australia
     * @param countryNameType
     * @throws SILException
     */
    private void setSuperTickDetails(ClientEntityType.Australia australia, CountryNameType countryNameType) throws SILException {
        if (countryNameType.getTfnSupertickstatus() != null) {
            SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Setting SuperTick Details");
            ClientEntityType.Australia.SupertickDetails superTickDetails = new ClientEntityType.Australia.SupertickDetails();
            CodeIdentifierType superTickCodeIdentifierType = new CodeIdentifierType();
            superTickCodeIdentifierType.setCode(countryNameType.getTfnSupertickstatus());
            if (countryNameType.getSuperTickStatusCodeType() != null) {
                superTickCodeIdentifierType.setCodeType(countryNameType.getSuperTickStatusCodeType());
            }
            superTickDetails.setStatus(superTickCodeIdentifierType);
            if (countryNameType.getTfnSupertickdate() != null) {
                superTickDetails.setValidationDate(SILUtil.convertStringToXMLGregorianCalendar(countryNameType.getTfnSupertickdate(),
                        CommonConstants.DATE_FORMAT));
            }
            australia.setSupertickDetails(superTickDetails);
        }
    }

    /**
     * Set Aml Details.
     * 
     * @param australia
     * @param countryNameType
     * @throws SILException
     */
    private void setAmlDetails(ClientEntityType.Australia australia, CountryNameType countryNameType) throws SILException {
        if (countryNameType.getAmlctfRiskcode() != null && countryNameType.getAmlctfRiskcodetype() != null ||
                countryNameType.getAmlClasscode() != null && countryNameType.getAmlClasstypecode() != null) {
            SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Setting AML Details");
            ClientEntityType.Australia.AntiMoneyLaundering amlDetails = new ClientEntityType.Australia.AntiMoneyLaundering();
            CodeIdentifierType amlCtfRiskCodeIdentifierType = new CodeIdentifierType();
            amlCtfRiskCodeIdentifierType.setCode(countryNameType.getAmlctfRiskcode());
            amlCtfRiskCodeIdentifierType.setCodeType(countryNameType.getAmlctfRiskcodetype());
            amlDetails.setAmlCtfRisk(amlCtfRiskCodeIdentifierType);

            CodeIdentifierType amlClassCodeIdentifierType = new CodeIdentifierType();
            amlClassCodeIdentifierType.setCode(countryNameType.getAmlClasscode());
            amlClassCodeIdentifierType.setCodeType(countryNameType.getAmlClasstypecode());
            amlDetails.setAmlClass(amlClassCodeIdentifierType);

            if (countryNameType.getAmlNote() != null) {
                this.setAmlNoteDetails(amlDetails, countryNameType);
            }
            australia.setAntiMoneyLaundering(amlDetails);
        }
    }

    /**
     * Set Aml Note Details.
     * 
     * @param amlDetails
     * @param countryNameType
     * @throws SILException
     */
    private void setAmlNoteDetails(ClientEntityType.Australia.AntiMoneyLaundering amlDetails, CountryNameType countryNameType) throws SILException {
        SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Setting AML Note Details");
        NoteCategoryIdentifierType amlNoteCategoryType = new NoteCategoryIdentifierType();
        amlNoteCategoryType.setCode(countryNameType.getAmlNoteCategoryCode());
        NoteTemplateIdentifierType amlNoteTemplateType = new NoteTemplateIdentifierType();
        amlNoteTemplateType.setCode(countryNameType.getAmlNoteTemplateCode());
        amlNoteTemplateType.setNoteCategory(amlNoteCategoryType);
        NoteType amlNoteType = new NoteType();
        amlNoteType.setDelete(SILUtil.checkDeleteOperation(countryNameType.getOperation()));
        amlNoteType.setEffectiveDate(SILUtil.convertStringToXMLGregorianCalendar(countryNameType.getAmlNoteEffectiveDate(),
                CommonConstants.DATE_FORMAT));
        amlNoteType.setNote(countryNameType.getAmlNote());
        amlNoteType.setNoteTemplate(amlNoteTemplateType);
        amlDetails.setAmlNote(amlNoteType);
    }

    /**
     * Set Company Details.
     * 
     * @param australia
     * @param countryNameType
     */
    private void setCompanyDetails(ClientEntityType.Australia australia, CountryNameType countryNameType) {
        SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Setting Company Details");
        ClientEntityType.Australia.Company companyDetails = new ClientEntityType.Australia.Company();
        if (countryNameType.getCompany() != null) {
            Company company = countryNameType.getCompany();
            if (company.getRegListingCode() != null && company.getRegListingCodeType() != null) {
                CodeIdentifierType regListingCodeIdentifierType = new CodeIdentifierType();
                regListingCodeIdentifierType.setCode(company.getRegListingCode());
                regListingCodeIdentifierType.setCodeType(company.getRegListingCodeType());
                companyDetails.setRegListing(regListingCodeIdentifierType);
            }
            companyDetails.setAbn(company.getAbn());
            companyDetails.setAcnArbn(company.getAcnArbn());
            companyDetails.setSpin(company.getSpin());
        }
        australia.setCompany(companyDetails);
    }
}
