////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.clientservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code NoteBean} is used to hold the notes details.
 * 
 * @author U383754
 * @since 24/05/2016
 * @version 1.0
 */
public class NoteBean {
    private String id;
    private NoteTemplateBean noteTemplate;
    private String effectiveDate;
    private String expiryDate;
    private String note;
    private String delete;

    /**
     * Accessor for property id.
     * 
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     * 
     * @return id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id;
    }

    /**
     * Accessor for property noteTemplate.
     * 
     * @return noteTemplate of type NoteTemplateBean
     */
    public NoteTemplateBean getNoteTemplate() {
        return noteTemplate;
    }

    /**
     * Mutator for property noteTemplate.
     * 
     * @return noteTemplate of type NoteTemplateBean
     */
    @XmlElement(name = "noteTemplate")
    public void setNoteTemplate(NoteTemplateBean noteTemplate) {
        this.noteTemplate = noteTemplate;
    }

    /**
     * Accessor for property effectiveDate.
     * 
     * @return effectiveDate of type String
     */
    public String getEffectiveDate() {
        return effectiveDate;
    }

    /**
     * Mutator for property effectiveDate.
     * 
     * @return effectiveDate of type String
     */
    @XmlElement(name = "effectiveDate")
    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    /**
     * Accessor for property note.
     * 
     * @return note of type String
     */
    public String getNote() {
        return note;
    }

    /**
     * Mutator for property note.
     * 
     * @return note of type String
     */
    @XmlElement(name = "note")
    public void setNote(String note) {
        this.note = note;
    }

    /**
     * Accessor for property expiryDate.
     *
     * @return expiryDate of type String
     */
    public String getExpiryDate() {
        return expiryDate;
    }

    /**
     * Mutator for property expiryDate.
     *
     * @param expiryDate of type String
     */
    @XmlElement(name = "expiryDate")
    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }

    /**
     * Accessor for property delete.
     *
     * @return delete of type String
     */
    public String getDelete() {
        return delete;
    }

    /**
     * Mutator for property delete.
     *
     * @param delete of type String
     */
    @XmlElement(name = "delete")
    public void setDelete(String delete) {
        this.delete = delete;
    }
    

}
