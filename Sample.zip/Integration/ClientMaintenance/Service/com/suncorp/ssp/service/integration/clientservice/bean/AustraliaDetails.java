////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.clientservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code AustraliaDetails} is a pure java bean consisting details related to Australia.
 * 
 * @author U385424
 * @since 23/03/2017
 * @version 1.0
 */
public class AustraliaDetails {

    private String dateOfLastContact;

    /**
     * Accessor for property dateOfLastContact.
     * 
     * @return dateOfLastContact of type String
     */
    public String getDateOfLastContact() {
        return dateOfLastContact;
    }

    /**
     * Mutator for property dateOfLastContact.
     * 
     * @param dateOfLastContact of type String
     */
    @XmlElement(name = "dateOfLastContact")
    public void setDateOfLastContact(String dateOfLastContact) {
        this.dateOfLastContact = dateOfLastContact;
    }
}
