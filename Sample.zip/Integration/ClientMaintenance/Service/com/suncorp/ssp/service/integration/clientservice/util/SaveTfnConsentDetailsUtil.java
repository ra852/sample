////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.clientservice.util;

import java.util.List;

import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.ClientEntityType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CodeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.GenericVariableType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.clientservice.ClientServiceConstants;
import com.suncorp.ssp.service.integration.clientservice.bean.TfnConsentDetailsType;

/**
 * The class {@code SaveTfnConsentDetailsUtil} is a Utility class with TfnConsent details related to client, to construct request for saving client
 * external service's request object.
 * 
 * @author U383847
 * @since 10/12/2015
 * @version 1.0
 */
public class SaveTfnConsentDetailsUtil {
    private final String className = "SaveTfnConsentDetailsUtil";

    /**
     * Set Client TfnConsent Details.
     * 
     * @param clientEntityType
     * @param tfnConsentDetailsType
     */
    public void setTfnConsentDetailsType(ClientEntityType clientEntityType, TfnConsentDetailsType tfnConsentDetailsType) throws SILException {
        SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Setting Client Tfn Consent Details");
        List<GenericVariableType> genericVariable = clientEntityType.getGenericVariable();
        if (tfnConsentDetailsType.getTfnConsentCode() != null &&
                ClientServiceConstants.TFN_CONSENT_CODE.equals(tfnConsentDetailsType.getTfnConsentCode())) {
            GenericVariableType genericVariableType = new GenericVariableType();
            if (tfnConsentDetailsType.getTfnConsentId() != null) {
                try {
                    genericVariableType.setId(Long.parseLong(tfnConsentDetailsType.getTfnConsentId()));
                } catch (NumberFormatException exception) {
                    throw new SILException(ClientServiceConstants.INVALID_TFNCONSENT_ID_FORMAT);
                }
            }
            genericVariableType.setCode(tfnConsentDetailsType.getTfnConsentCode());
            genericVariableType.setDescription(tfnConsentDetailsType.getTfnConsentDesc());
            genericVariableType.setLabel(tfnConsentDetailsType.getTfnConsentLabel());
            genericVariableType.setDelete(SILUtil.checkDeleteOperation(tfnConsentDetailsType.getOperation()));

            if (tfnConsentDetailsType.getTfnConsentValue() != null) {
                setTfnConsentValue(tfnConsentDetailsType, genericVariableType);
            }
            genericVariable.add(genericVariableType);
        }
    }

    /**
     * Set Client TfnConsent Value Details.
     * 
     * @param tfnConsentDetailsType
     * @param genericVariableType
     */
    private void setTfnConsentValue(TfnConsentDetailsType tfnConsentDetailsType, GenericVariableType genericVariableType) {
        CodeIdentifierType codeIdentifierType = new CodeIdentifierType();
        codeIdentifierType.setCodeDescription(tfnConsentDetailsType.getTfnConsentValue());
        GenericVariableType.Value value = new GenericVariableType.Value();
        value.setCode(codeIdentifierType);
        genericVariableType.setValue(value);
    }
}
