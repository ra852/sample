////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.clientservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code ClientWorkDeclarationType} does this.
 * 
 * @author U383754
 * @since 23/10/2015
 * @version 1.0
 */
public class ClientWorkDeclarationType {
    private String dateDeclaredOn;
    private String dateFinancialYearEnd;
    /**
     * Accessor for property dateDeclaredOn.
     * @return dateDeclaredOn of type String
     */
    public String getDateDeclaredOn() {
        return dateDeclaredOn;
    }
    /**
     * Mutator for property dateDeclaredOn.
     * @return dateDeclaredOn of type String
     */
    @XmlElement(name = "dateDeclaredOn")
    public void setDateDeclaredOn(String dateDeclaredOn) {
        this.dateDeclaredOn = dateDeclaredOn;
    }
    /**
     * Accessor for property dateFinancialYearEnd.
     * @return dateFinancialYearEnd of type String
     */
    public String getDateFinancialYearEnd() {
        return dateFinancialYearEnd;
    }
    /**
     * Mutator for property dateFinancialYearEnd.
     * @return dateFinancialYearEnd of type String
     */
    @XmlElement(name = "dateFinancialYearEnd")
    public void setDateFinancialYearEnd(String dateFinancialYearEnd) {
        this.dateFinancialYearEnd = dateFinancialYearEnd;
    }
}
