////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package com.suncorp.ssp.service.integration.clientservice;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.cxf.jaxrs.model.wadl.Description;
import org.apache.cxf.jaxrs.model.wadl.Descriptions;
import org.apache.cxf.jaxrs.model.wadl.DocTarget;
import org.apache.cxf.jaxrs.model.wadl.ElementClass;

import com.suncorp.ssp.service.integration.clientservice.bean.SaveClientRequest;

/**
 * The interface {@code ClientService} exposes operations related to client details.
 * 
 * @author U383754
 * @since 2015-10-01
 * @version 1.0
 */
@Path("/clientservice")
public interface ClientService {

    /**
     * Fetches new GetClientResponse bean.
     * 
     * @return object of type GetClientResponse
     */
    @GET
    @Path("/getclient")
    @ElementClass(response = Response.class)
    @Produces(MediaType.APPLICATION_JSON)
    @Description(title = "Response Object", value = "Response", target = DocTarget.RESPONSE)
    Response getclient(@QueryParam("clientId") String clientId, @QueryParam("includeClientDetails") String includeClientDetails,
            @QueryParam("includeAddress") String includeAddress, @QueryParam("includeBankAccount") String includeBankAccount,
            @QueryParam("includeExternalReference") String includeExternalReference,
            @QueryParam("includeGenericVariable") String includeGenericVariable, @QueryParam("includeNote") String includeNote,
            @QueryParam("includeClientContext") String includeClientContext, @QueryParam("includeAdvisorGroup") String includeAdvisorGroup,
            @QueryParam("includeNewZealand") String includeNewZealand, @QueryParam("includeSouthAfrica") String includeSouthAfrica,
            @QueryParam("includeAustralia") String includeAustralia, @QueryParam("includeUnitedKingdom") String includeUnitedKingdom,
            @QueryParam("includeWorkDeclaration") String includeWorkDeclaration,
            @QueryParam("includeTaxTreatyDetails") String includeTaxTreatyDetails,
            @QueryParam("includeCorroDeliveryPreferences") String includeCorroDeliveryPreferences,
            @QueryParam("includeApsSubscription") String includeApsSubscription);

    /**
     * Fetches new SaveClientResponse bean.
     * 
     * @return object of type SaveClientResponse
     */
    @POST
    @Path("/saveclient")
    @ElementClass(request = SaveClientRequest.class, response = Response.class)
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Descriptions({ @Description(title = "Request Object", value = "SaveClientRequest", target = DocTarget.REQUEST),
            @Description(title = "Response Object", value = "Response", target = DocTarget.RESPONSE) })
    Response saveclient(SaveClientRequest saveClientRequest);

    /**
     * Fetches new GetAccountListtResponse bean.
     * 
     * @return object of type GetAccountListResponseBean
     */
    @GET
    @Path("/getaccountlist")
    @ElementClass(response = Response.class)
    @Produces(MediaType.APPLICATION_JSON)
    @Description(title = "Response Object", value = "Response", target = DocTarget.RESPONSE)
    Response getaccountlist(@QueryParam("clientId") String clientId, @QueryParam("includeEmployer") String includeEmployer, 
            @QueryParam("includeProduct") String includeProduct);

    /**
     * Fetches new SearchClientResponse bean.
     * 
     * @param surname
     * @param investTypeCode
     * @param investTypeCodeType
     * @param includeExternalReference
     * @param dateOfBirth
     * @return
     */
    @GET
    @Path("/searchclient")
    @ElementClass(response = Response.class)
    @Produces(MediaType.APPLICATION_JSON)
    @Description(title = "Response Object", value = "Response", target = DocTarget.RESPONSE)
    Response searchclient(@QueryParam("clientSurname") String clientSurname, @QueryParam("investTypeCode") String investTypeCode,
            @QueryParam("investTypeCodeType") String investTypeCodeType, @QueryParam("includeExternalReferences") String includeExternalReferences,
            @QueryParam("dateOfBirth") String dateOfBirth);

    /**
     * Fetches new GetClientResponse bean.
     * 
     * @return object of type GetClientResponse
     */
    @GET
    @Path("/getcustomerbyproduct")
    @ElementClass(response = Response.class)
    @Produces(MediaType.APPLICATION_JSON)
    @Description(title = "Response Object", value = "Response", target = DocTarget.RESPONSE)
    Response getcustomerbyproduct(@QueryParam("identity") String identity, @QueryParam("entityType") String entityType);
}
