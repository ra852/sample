////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.clientservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code ErrorBean} does this.
 * 
 * @author U385424
 * @since 03/11/2016
 * @version 1.0
 */
public class ErrorBean {
    private String code;
    private String severity;
    private String sourceSystem;
    private String description;

    /**
     * Accessor for property code.
     * 
     * @return code of type String
     */
    public String getCode() {
        return code;
    }

    /**
     * Mutator for property code.
     * 
     * @param code of type String
     */
    @XmlElement(name = "code")
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Accessor for property severity.
     * 
     * @return severity of type String
     */
    public String getSeverity() {
        return severity;
    }

    /**
     * Mutator for property severity.
     * 
     * @param severity of type String
     */
    @XmlElement(name = "severity")
    public void setSeverity(String severity) {
        this.severity = severity;
    }

    /**
     * Accessor for property sourceSystem.
     * 
     * @return sourceSystem of type String
     */
    public String getSourceSystem() {
        return sourceSystem;
    }

    /**
     * Mutator for property sourceSystem.
     * 
     * @param sourceSystem of type String
     */
    @XmlElement(name = "sourceSystem")
    public void setSourceSystem(String sourceSystem) {
        this.sourceSystem = sourceSystem;
    }

    /**
     * Accessor for property description.
     * 
     * @return description of type String
     */
    public String getDescription() {
        return description;
    }

    /**
     * Mutator for property description.
     * 
     * @param description of type String
     */
    @XmlElement(name = "description")
    public void setDescription(String description) {
        this.description = description;
    }
}
