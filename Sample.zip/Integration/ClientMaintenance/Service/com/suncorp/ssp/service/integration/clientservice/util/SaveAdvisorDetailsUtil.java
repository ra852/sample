////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.clientservice.util;

import java.math.BigDecimal;
import java.util.List;

import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.AdvisorGroupType;
import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.AdvisorSplitType;
import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.ClientEntityType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CodeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.MasterSchemeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.RelationshipTypeIdentifierType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.clientservice.ClientServiceConstants;
import com.suncorp.ssp.service.integration.clientservice.bean.ClientAdvisorDetailType;

/**
 * The class {@code SaveAdvisorDetailsUtil} is a Utility class with Advisor Group details related to client, to construct request for saving client
 * external service's request object.
 * 
 * @author U383847
 * @since 10/12/2015
 * @version 1.0
 */
public class SaveAdvisorDetailsUtil {
    private final String className = "SaveAdvisorDetailsUtil";

    /**
     * Set Client Advisor Group Details.
     * 
     * @param clientEntityType
     * @param advisorDetails
     * @throws Exception
     */
    public void setAdvisorGroupDetails(ClientEntityType clientEntityType, List<ClientAdvisorDetailType> advisorDetails) throws SILException {
        SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Setting Client Advisor Group Details");
        List<AdvisorGroupType> advisorGroupList = clientEntityType.getAdvisorGroup();
        for (ClientAdvisorDetailType advisorDetailType : advisorDetails) {
            AdvisorGroupType advisorGroupType = new AdvisorGroupType();
            if (advisorDetailType.getAdvisorgroupId() != null) {
                try {
                    advisorGroupType.setId(Long.parseLong(advisorDetailType.getAdvisorgroupId()));
                } catch (NumberFormatException exception) {
                    throw new SILException(ClientServiceConstants.INVALID_ADVISOR_GROUP_ID_FORMAT);
                }
            }
            RelationshipTypeIdentifierType relationshipIdentifierType = new RelationshipTypeIdentifierType();
            relationshipIdentifierType.setCode(advisorDetailType.getRelationshipCode());
            advisorGroupType.setRelationshipType(relationshipIdentifierType);
            if (advisorDetailType.getEffectiveDate() != null) {
                advisorGroupType.setEffectiveDate(SILUtil.convertStringToXMLGregorianCalendar(advisorDetailType.getEffectiveDate(),
                        CommonConstants.DATE_FORMAT));
            }

            setAdvisorSplitDetails(advisorDetailType, advisorGroupType);
            advisorGroupType.setDelete(SILUtil.checkDeleteOperation(advisorDetailType.getOperation()));
            advisorGroupList.add(advisorGroupType);
        }
    }

    /**
     * Set Client Advisor Split Details.
     * 
     * @param advisorDetailType
     * @param advisorGroupType
     */
    private void setAdvisorSplitDetails(ClientAdvisorDetailType advisorDetailType, AdvisorGroupType advisorGroupType) {
        SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Setting Client Advisor Split Details");
        List<AdvisorSplitType> advisorSplitTypeList = advisorGroupType.getAdvisorSplit();
        AdvisorSplitType.Advisor advisorSplitAdvisor = new AdvisorSplitType.Advisor();
        advisorSplitAdvisor.setAdvisorNumber(advisorDetailType.getAdvisorNumber());
        advisorSplitAdvisor.setClientForename(advisorDetailType.getAdvisorForename());
        advisorSplitAdvisor.setClientSurname(advisorDetailType.getAdvisorSurname());
        MasterSchemeIdentifierType masterSchemeIdentifierType = new MasterSchemeIdentifierType();
        masterSchemeIdentifierType.setDisplayName(advisorDetailType.getAdvisorMaster());
        advisorSplitAdvisor.setMasterScheme(masterSchemeIdentifierType);
        CodeIdentifierType codeIdentifierType = new CodeIdentifierType();
        codeIdentifierType.setCode(advisorDetailType.getOutletType());
        codeIdentifierType.setCodeType(advisorDetailType.getOutletypeCodetype());
        advisorSplitAdvisor.setOutletType(codeIdentifierType);
        CodeIdentifierType statusCodeIdentifierType = new CodeIdentifierType();
        statusCodeIdentifierType.setCode(advisorDetailType.getOutletstatusCode());
        statusCodeIdentifierType.setCodeType(advisorDetailType.getOutletstatusCodetype());
        advisorSplitAdvisor.setStatus(statusCodeIdentifierType);
        this.setAdvisorSplitTypeDetails(advisorDetailType, advisorSplitTypeList, advisorSplitAdvisor);
    }

    /**
     * Set Client Advisor Split Type Details.
     * 
     * @param advisorDetailType
     * @param advisorSplitTypeList
     * @param advisorSplitAdvisor
     */
    private void setAdvisorSplitTypeDetails(ClientAdvisorDetailType advisorDetailType, List<AdvisorSplitType> advisorSplitTypeList,
            AdvisorSplitType.Advisor advisorSplitAdvisor) {
        SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Setting Client Advisor Split Type Details");
        AdvisorSplitType advisorSplitType = new AdvisorSplitType();
        if (advisorDetailType.getAdvisorgroupId() != null) {
            advisorSplitType.setId(Long.parseLong(advisorDetailType.getAdvisorgroupId()));
        }
        if (advisorDetailType.getPercentageSplit() != null) {
            double percentSplit = Double.parseDouble(advisorDetailType.getPercentageSplit());
            advisorSplitType.setPercentageSplit(BigDecimal.valueOf(percentSplit));
        }
        advisorSplitType.setAdvisor(advisorSplitAdvisor);
        advisorSplitType.setPrimary(Boolean.parseBoolean(advisorDetailType.getPrimaryFlag()));
        advisorSplitType.setDelete(SILUtil.checkDeleteOperation(advisorDetailType.getOperation()));
        advisorSplitTypeList.add(advisorSplitType);
    }
}
