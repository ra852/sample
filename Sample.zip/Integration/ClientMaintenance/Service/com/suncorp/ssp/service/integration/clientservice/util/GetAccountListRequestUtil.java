////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.clientservice.util;

import javax.ws.rs.core.MultivaluedMap;

import com.sonatacentral.service.v30.common.client.GetAccountListRequestType;
import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.ClientIdentifierType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.clientservice.ClientServiceConstants;

/**
 * The class {@code GetAccountListRequestUtil} is a Utility class with all the properties related to client details, to construct request for
 * get account list external service's request object.
 * 
 * @author U385424
 * @since 20/12/2017
 * @version 1.0
 */
public class GetAccountListRequestUtil {
    private MultivaluedMap<String, String> inboundRequest;
    private GetAccountListRequestType outboundRequest;

    /**
     * This is a parameterized constructor.
     * 
     * @param inboundRequest
     */
    public GetAccountListRequestUtil(MultivaluedMap<String, String> inboundRequest) {
        this.inboundRequest = inboundRequest;
        this.outboundRequest = new GetAccountListRequestType();
    }

    /**
     * Does this.
     * 
     * @return
     */
    public GetAccountListRequestType createOutboundRequest() throws SILException {
        if (inboundRequest.containsKey(ClientServiceConstants.CLIENT_ID) && inboundRequest.get(ClientServiceConstants.CLIENT_ID).get(0) != null) {
            outboundRequest.setCallerDetails(SILUtil.createCallerDetails());
            outboundRequest.setIncludeEmployer(retrieveIncludeEmployer());
            outboundRequest.setIncludeSuperDetailsWithoutExp(true);
            outboundRequest.setClient(retrieveClientDetails());
            outboundRequest.setIncludeProduct(retrieveIncludeProduct());
            return outboundRequest;
        } else {
            throw new SILException(ClientServiceConstants.INVALID_REQUEST_MESSAGE);
        }
    }

    /**
     * Does this.
     * 
     * @param exchange
     * @return
     */
    private Boolean retrieveIncludeProduct() {
        Boolean includeProduct = false;
        if (inboundRequest.containsKey(ClientServiceConstants.INCLUDE_PRODUCT) &&
                inboundRequest.get(ClientServiceConstants.INCLUDE_PRODUCT).get(0) != null) {
            includeProduct = Boolean.valueOf(inboundRequest.get(ClientServiceConstants.INCLUDE_PRODUCT).get(0));
        }
        return includeProduct;
    }

    /**
     * This method is used to construct object of client identifier type.
     * 
     * @param clientId
     * @return clientIdentifierType
     */
    private ClientIdentifierType retrieveClientDetails() {
        ClientIdentifierType clientIdentifierType = new ClientIdentifierType();
        clientIdentifierType.setId(Long.parseLong(inboundRequest.get(ClientServiceConstants.CLIENT_ID).get(0)));
        return clientIdentifierType;
    }

    /**
     * This method is used to get the includeEmployer from query string.
     * 
     * @param exchange
     * 
     * @return
     */
    private Boolean retrieveIncludeEmployer() {
        Boolean includeEmployer = false;
        if (inboundRequest.containsKey(ClientServiceConstants.INCLUDE_EMPLOYER) &&
                inboundRequest.get(ClientServiceConstants.INCLUDE_EMPLOYER).get(0) != null) {
            includeEmployer = Boolean.valueOf(inboundRequest.get(ClientServiceConstants.INCLUDE_EMPLOYER).get(0));
        }
        return includeEmployer;
    }
}
