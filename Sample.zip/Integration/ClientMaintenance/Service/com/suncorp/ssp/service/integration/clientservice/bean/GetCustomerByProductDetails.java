////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.clientservice.bean;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.suncorp.ssp.common.bean.SILErrorMessage;

/**
 * The class {@code GetCustomerByProductDetails} does this.
 * 
 * @author U385424
 * @since 19/10/2016
 * @version 1.0
 */

@XmlRootElement(name = "GetCustomerByProductResponse")
public class GetCustomerByProductDetails extends SILErrorMessage {
    private String customerId;
    private String entityType;
    private String title;
    private String name;
    private String otherName;
    private ErrorBean error;

    /**
     * Accessor for property error.
     * 
     * @return error of type ErrorBean
     */
    public ErrorBean getError() {
        return error;
    }

    /**
     * Mutator for property error.
     * 
     * @param error of type ErrorBean
     */
    @XmlElement(name = "error")
    public void setError(ErrorBean error) {
        this.error = error;
    }

    /**
     * Accessor for property customerId.
     * 
     * @return customerId of type String
     */
    public String getCustomerId() {
        return customerId;
    }

    /**
     * Mutator for property customerId.
     * 
     * @param customerId of type String
     */
    @XmlElement(name = "customerId")
    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    /**
     * Accessor for property entityType.
     * 
     * @return entityType of type String
     */
    public String getEntityType() {
        return entityType;
    }

    /**
     * Mutator for property entityType.
     * 
     * @param entityType of type String
     */
    @XmlElement(name = "entityType")
    public void setEntityType(String entityType) {
        this.entityType = entityType;
    }

    /**
     * Accessor for property title.
     * 
     * @return title of type String
     */
    public String getTitle() {
        return title;
    }

    /**
     * Mutator for property title.
     * 
     * @param title of type String
     */
    @XmlElement(name = "title")
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * Accessor for property name.
     * 
     * @return name of type String
     */
    public String getName() {
        return name;
    }

    /**
     * Mutator for property name.
     * 
     * @param name of type String
     */
    @XmlElement(name = "name")
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Accessor for property otherName.
     * 
     * @return otherName of type String
     */
    public String getOtherName() {
        return otherName;
    }

    /**
     * Mutator for property otherName.
     * 
     * @param otherName of type String
     */
    @XmlElement(name = "otherName")
    public void setOtherName(String otherName) {
        this.otherName = otherName;
    }
}
