////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.clientservice.util;

import java.util.Iterator;
import java.util.List;

import com.sonatacentral.service.v30.common.client.GetClientResponseType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.ExternalRefType;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.clientservice.ClientServiceConstants;
import com.suncorp.ssp.service.integration.clientservice.bean.ExternalReferenceDetailType;

/**
 * The class {@code ExternalReferenceDetailsUtil} does this.
 * 
 * @author U383754
 * @since 06/01/2016
 * @version 1.0
 */
public class ExternalReferenceDetailsUtil {
    private GetClientResponseType getClientResponseType;
    private ExternalRefType externalRefType;
    private ClientServiceUtil clientServiceUtil = null;

    public ExternalReferenceDetailsUtil(GetClientResponseType getClientResponseType) {
        this.getClientResponseType = getClientResponseType;
        clientServiceUtil = new ClientServiceUtil();
    }

    /**
     * 
     * This method is used to get external references of clint.
     * 
     * @param externalReferenceDetails
     */
    public void getExternalReferenceDetails(List<ExternalReferenceDetailType> externalReferenceDetails) {
        SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "ExternalReferenceDetailsUtil", "Entering getExternalReferenceDetails()");
        if (this.getClientResponseType != null && this.getClientResponseType.getExternalReference() != null &&
                this.getClientResponseType.getExternalReference().size() > 0) {
            List<ExternalRefType> externalRefTypes = this.getClientResponseType.getExternalReference();
            Iterator<ExternalRefType> iterator = externalRefTypes.iterator();
            while (iterator.hasNext()) {
                this.externalRefType = iterator.next();
                externalReferenceDetails.add(clientServiceUtil.getExternalReferenceDetails(this.externalRefType,
                        ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT));
            }
        } else {
            externalReferenceDetails.add(clientServiceUtil.setExternalRefDefaultValues(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT));
        }
        SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "ExternalReferenceDetailsUtil", "Exiting getExternalReferenceDetails()");
    }
}
