////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.clientservice.util;

import java.util.List;

import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.ClientEntityType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.ExternalRefType;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.clientservice.ClientServiceConstants;
import com.suncorp.ssp.service.integration.clientservice.bean.ExternalReferenceDetailType;

/**
 * The class {@code SaveExternalReferenceUtil} is a Utility class with External Reference details related to client, to construct request for saving
 * client external service's request object.
 * 
 * @author U383847
 * @since 09/12/2015
 * @version 1.0
 */
public class SaveExternalReferenceUtil {
    private final String className = "SaveExternalReferenceUtil";

    /**
     * Set Client External Reference Details.
     * 
     * @param clientEntityType
     * @param externalRefDetailList
     */
    public void setExternalReferenceDetails(ClientEntityType clientEntityType, List<ExternalReferenceDetailType> externalRefDetailList) {
        SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Setting Client External Reference Details");
        List<ExternalRefType> externalRefTypeList = clientEntityType.getExternalReference();
        for (ExternalReferenceDetailType extRefDetailType : externalRefDetailList) {
            ExternalRefType externalRefType = new ExternalRefType();
            externalRefType.setReference(extRefDetailType.getExternalReferenceType());
            externalRefType.setReferenceCode(extRefDetailType.getExternalReferenceCode());
            externalRefType.setDelete(SILUtil.checkDeleteOperation(extRefDetailType.getOperation()));
            externalRefTypeList.add(externalRefType);
        }
    }
}
