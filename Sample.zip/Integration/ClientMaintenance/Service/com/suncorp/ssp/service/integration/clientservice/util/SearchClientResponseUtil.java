////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.clientservice.util;

import java.util.ArrayList;
import java.util.List;

import com.sonatacentral.service.v30.common.client.SearchClientResponseType;
import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.ClientIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.ClientSearchType;
import com.sonatacentral.service.v30.service.ValidationMessage;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.constants.clientservice.ClientServiceConstants;
import com.suncorp.ssp.service.constants.fundservice.FundServiceConstants;
import com.suncorp.ssp.service.integration.clientservice.bean.ClientIdentifier;
import com.suncorp.ssp.service.integration.clientservice.bean.ClientSearchResult;
import com.suncorp.ssp.service.integration.clientservice.bean.SearchClientResponse;

/**
 * The class {@code SearchClientResponseUtil} does this.
 * 
 * @author U383847
 * @since 15/03/2016
 * @version 1.0
 */
public class SearchClientResponseUtil {
    private final String className = "SearchClientResponseUtil";
    private SearchClientResponseType searchClientResponseType;
    private ClientServiceUtil clientServiceUtil = null;

    /**
     * Parameterized constructor for properties initialization.
     * 
     * @param searchClientResponseType of type SearchClientResponseType
     */
    public SearchClientResponseUtil(SearchClientResponseType searchClientResponseType) {
        this.searchClientResponseType = searchClientResponseType;
        clientServiceUtil = new ClientServiceUtil();
    }

    /**
     * Extracts values from the external service's response and maps to end client response.
     * 
     * @param searchClientResponse of type SearchClientResponse
     */
    public void searchClientResponse(SearchClientResponse searchClientResponse) throws SILException {
        if (this.searchClientResponseType != null) {
            this.getClientSearchResult(searchClientResponse);
        }
    }

    /**
     * Getting Client Search Results.
     * 
     * @param searchClientResponse
     */
    private void getClientSearchResult(SearchClientResponse searchClientResponse) throws SILException {
        if (searchClientResponseType.getSearchResult() != null && searchClientResponseType.getSearchResult().size() > 0) {
            SILLogger.debug(ClientServiceConstants.SEARCH_CLIENT_LOGGING_FORMAT, className, "Getting Client Search Results");
            List<ClientSearchType> clientSearchTypeList = searchClientResponseType.getSearchResult();
            List<ClientSearchResult> clientSearchResultList = new ArrayList<ClientSearchResult>();
            for (ClientSearchType clientSearchType : clientSearchTypeList) {
                ClientSearchResult clientSearchResult = new ClientSearchResult();
                ClientIdentifier clientIdentifier = this.getClientIdentifier(clientSearchType);
                if (clientIdentifier != null) {
                    clientSearchResult.setClient(clientIdentifier);
                }
                this.getCodeIdentifierDetails(clientSearchResult, clientSearchType);
                clientSearchResult.setAddress(clientServiceUtil.getAddressDetails(clientSearchType.getPrimaryAddress(),
                        ClientServiceConstants.SEARCH_CLIENT_LOGGING_FORMAT));
                clientSearchResult.setClientExternalReferences(clientServiceUtil.getClientExternalReferenceDetails(
                        clientSearchType.getClientExternalReference(), ClientServiceConstants.SEARCH_CLIENT_LOGGING_FORMAT));
                this.getClientDetails(clientSearchResult, clientSearchType);
                clientSearchResultList.add(clientSearchResult);
            }
            searchClientResponse.setClientSearchResult(clientSearchResultList);
        } else if (searchClientResponseType.getValidationMessage() != null && searchClientResponseType.getValidationMessage().size() > 0) {
            this.sendValidationMessages(searchClientResponseType.getValidationMessage());
        }
    }

    /**
     * Getting Client Details.
     * 
     * @param clientSearchResult
     * @param clientSearchType
     */
    private void getClientDetails(ClientSearchResult clientSearchResult, ClientSearchType clientSearchType) {
        SILLogger.debug(ClientServiceConstants.SEARCH_CLIENT_LOGGING_FORMAT, className, "Getting Client Details");
        clientSearchResult.setAltSurname(clientSearchType.getAltSurname());
        clientSearchResult.setAbnNumber(clientSearchType.getAbnNumber());
        clientSearchResult.setFirstName(clientSearchType.getForename2());
        clientSearchResult.setMiddleName(clientSearchType.getForename3());
        if (clientSearchType.isWrapIndicator() != null) {
            clientSearchResult.setWrapIndicator(clientSearchType.isWrapIndicator().toString());
        }
    }

    /**
     * Getting Client Code Identifier Details.
     * 
     * @param clientSearchResult
     * @param clientSearchType
     */
    private void getCodeIdentifierDetails(ClientSearchResult clientSearchResult, ClientSearchType clientSearchType) {
        SILLogger.debug(ClientServiceConstants.SEARCH_CLIENT_LOGGING_FORMAT, className, "Getting Client Code Identifier Details");
        clientSearchResult.setClientType(clientServiceUtil.getCodeIdentifierDetails(clientSearchType.getTypeCode(),
                ClientServiceConstants.SEARCH_CLIENT_LOGGING_FORMAT));
        clientSearchResult.setInvestorType(clientServiceUtil.getCodeIdentifierDetails(clientSearchType.getInvestorType(),
                ClientServiceConstants.SEARCH_CLIENT_LOGGING_FORMAT));
        clientSearchResult.setClientStatus(clientServiceUtil.getCodeIdentifierDetails(clientSearchType.getStatus(),
                ClientServiceConstants.SEARCH_CLIENT_LOGGING_FORMAT));
    }

    /**
     * Getting Client Identifier Details.
     * 
     * @param clientSearchType
     * @param clientSearchResult
     * @return
     */
    private ClientIdentifier getClientIdentifier(ClientSearchType clientSearchType) {
        ClientIdentifier clientIdentifier = new ClientIdentifier();
        ClientIdentifierType clientIdentifierType = clientSearchType.getClient();
        if (clientIdentifierType != null) {
            SILLogger.debug(ClientServiceConstants.SEARCH_CLIENT_LOGGING_FORMAT, className, "Getting Client Identifier Details");
            if (clientIdentifierType.getId() != null) {
                clientIdentifier.setClientId(clientIdentifierType.getId().toString());
            }
            clientIdentifier.setName(clientIdentifierType.getName());
            clientIdentifier.setMasterSchemeName(clientIdentifierType.getMasterScheme().getDisplayName());
            clientIdentifier.setSurname(clientIdentifierType.getClientSurname());
            clientIdentifier.setFirstName(clientIdentifierType.getClientForename());
            clientIdentifier.setMiddleName(clientIdentifierType.getClientForename2());
            clientIdentifier.setGlobalIntermediaryIDNumber(clientIdentifierType.getGlobalIntermediaryIDNumber());
            clientIdentifier.setExternalReferenceType(clientServiceUtil.getExternalReferenceDetails(clientIdentifierType.getClientExternalRef(),
                    ClientServiceConstants.SEARCH_CLIENT_LOGGING_FORMAT));
            clientIdentifier.setAudit(clientServiceUtil.getAuditDetails(clientIdentifierType.getAudit(),
                    ClientServiceConstants.SEARCH_CLIENT_LOGGING_FORMAT));
        }
        return clientIdentifier;
    }

    /**
     * Send Validation Messages.
     * 
     * @param validationMessageList
     * @throws SILException
     */
    private void sendValidationMessages(List<ValidationMessage> validationMessageList) throws SILException {
        for (ValidationMessage validationMessage : validationMessageList) {
            if (validationCheck(validationMessage)) {
                throw new SILException(validationMessage.getMessage());
            }
        }
    }

    /**
     * Check Validation Messages.
     * 
     * @param validationMessage
     * @return
     */
    private boolean validationCheck(ValidationMessage validationMessage) {
        return validationMessage != null &&
                validationMessage.getSeverity() != null &&
                (validationMessage.getSeverity().equalsIgnoreCase(FundServiceConstants.SEVERITY_ERROR) ||
                        validationMessage.getSeverity().equalsIgnoreCase(FundServiceConstants.SEVERITY_DEBUG) ||
                        validationMessage.getSeverity().equalsIgnoreCase(FundServiceConstants.SEVERITY_FATAL) || 
                        validationMessage.getSeverity().equalsIgnoreCase(AccountServiceConstants.SEVERITY_INFO));
    }
}
