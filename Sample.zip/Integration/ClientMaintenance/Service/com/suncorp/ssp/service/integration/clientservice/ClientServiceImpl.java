////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package com.suncorp.ssp.service.integration.clientservice;

import javax.ws.rs.core.Response;

import com.suncorp.ssp.service.integration.clientservice.bean.SaveClientRequest;

/**
 * The class {@code ClientService} exposes operations related to client details.
 * 
 * @author U383754
 * @since 2015-10-01
 * @version 1.0
 */
public class ClientServiceImpl implements ClientService {
    /**
     * Default constructor.
     */
    public ClientServiceImpl() {
    }

    /**
     * Fetches new GetClientResponse bean.
     * 
     * @return object of type GetClientResponse
     */
    public Response getclient(String clientId, String includeClientDetails, String includeAddress, String includeBankAccount,
            String includeExternalReference, String includeGenericVariable, String includeNote, String includeClientContext,
            String includeAdvisorGroup, String includeNewZealand, String includeSouthAfrica, String includeAustralia, String includeUnitedKingdom,
            String includeWorkDeclaration, String includeTaxTreatyDetails, String includeCorroDeliveryPreferences, String includeApsSubscription) {
        return null;
    }

    /**
     * Fetches new SaveClientResponse bean.
     * 
     * @return object of type SaveClientResponse
     */
    public Response saveclient(SaveClientRequest saveClientRequest) {
        return null;
    }

    /**
     * Fetches new GetAccountListtResponse bean.
     * 
     * @return object of type GetAccountListResponseBean
     */
    public Response getaccountlist(String clientId, String includeEmployer, String includeProduct) {
        return null;
    }

    /**
     * Fetches new SearchClientResponse bean.
     * 
     * @return object of type SearchClientResponse
     */
    public Response searchclient(String clientSurname, String investTypeCode, String investTypeCodeType, String includeExternalReferences,
            String dateOfBirth) {
        return null;
    }

    /**
     * Fetches new GetClientResponse bean.
     * 
     * @return object of type GetClientResponse
     */
    public Response getcustomerbyproduct(String identity, String entityType) {
        return null;
    }
}
