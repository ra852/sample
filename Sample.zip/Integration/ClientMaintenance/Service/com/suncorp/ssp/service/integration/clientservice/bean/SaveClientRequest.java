////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package com.suncorp.ssp.service.integration.clientservice.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * The class {@code GetClientRequest} is a java bean consisting of all the properties related to client details, to be used for constructing save
 * client request.
 * 
 * @author U383847
 * @since 29/10/2015
 * @version 1.0
 */
@XmlRootElement(name = "SaveClientRequest")
public class SaveClientRequest {
    private String clientId;
    private String surname;
    private String firstName;
    private String middleName;
    private String contactName;
    private String title;
    private String gender;
    private String dateOfBirth;
    private String maritalStatus;
    private OccupationIdentifierBean occupationDetail;
    private String mobileNumber;
    private String homeNumber;
    private String workNumber;
    private List<ClientAddressType> addressTypeList;
    private List<ClientBankDetailType> bankDetails;
    private List<ExternalReferenceDetailType> externalReferenceType;
    private TfnConsentDetailsType tfnConsentDetails;
    private List<ClientAdvisorDetailType> advisorGroupDetails;
    private List<ClientContextDetailType> clientContextDetails;
    private Boolean workDeclarationDetails;
    private CountryNameType countryDetails;
    private List<NoteBean> notes;
    private CodeIdentifier preferredRisk;
    private AustraliaDetails australia;

    /**
     * Accessor for property clientId.
     * 
     * @return clientId of type String
     */
    public String getClientId() {
        return clientId;
    }

    /**
     * Mutator for property clientID.
     * 
     * @param clientID of type String
     */
    @XmlElement(name = "clientId")
    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    /**
     * Accessor for property surname.
     * 
     * @return surname of type String
     */
    public String getSurname() {
        return surname;
    }

    /**
     * Mutator for property surname.
     * 
     * @param surname of type String
     */
    @XmlElement(name = "surname")
    public void setSurname(String surname) {
        this.surname = surname;
    }

    /**
     * Accessor for property firstName.
     * 
     * @return firstName of type String
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Mutator for property firstName.
     * 
     * @param firstName of type String
     */
    @XmlElement(name = "firstName")
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * Accessor for property middleName.
     * 
     * @return middleName of type String
     */
    public String getMiddleName() {
        return middleName;
    }

    /**
     * Mutator for property middleName.
     * 
     * @param middleName of type String
     */
    @XmlElement(name = "middleName")
    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    /**
     * Accessor for property contactName.
     * 
     * @return contactName of type String
     */
    public String getContactName() {
        return contactName;
    }

    /**
     * Mutator for property contactName.
     * 
     * @param contactName of type String
     */
    @XmlElement(name = "contactName")
    public void setContactName(String contactName) {
        this.contactName = contactName;
    }

    /**
     * Accessor for property title.
     * 
     * @return title of type String
     */
    public String getTitle() {
        return title;
    }

    /**
     * Mutator for property title.
     * 
     * @param title of type String
     */
    @XmlElement(name = "title")
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * Accessor for property gender.
     * 
     * @return gender of type String
     */
    public String getGender() {
        return gender;
    }

    /**
     * Mutator for property gender.
     * 
     * @param gender of type String
     */
    @XmlElement(name = "gender")
    public void setGender(String gender) {
        this.gender = gender;
    }

    /**
     * Accessor for property dateOfBirth.
     * 
     * @return dateOfBirth of type String
     */
    public String getDateOfBirth() {
        return dateOfBirth;
    }

    /**
     * Mutator for property dateOfBirth.
     * 
     * @param dateOfBirth of type String
     */
    @XmlElement(name = "dob")
    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    /**
     * Accessor for property maritalStatus.
     * 
     * @return maritalStatus of type String
     */
    public String getMaritalStatus() {
        return maritalStatus;
    }

    /**
     * Mutator for property maritalStatus.
     * 
     * @param maritalStatus of type String
     */
    @XmlElement(name = "maritalStatus")
    public void setMaritalStatus(String maritalStatus) {
        this.maritalStatus = maritalStatus;
    }

    /**
     * Accessor for property occupationDetail.
     * 
     * @return occupationDetail of type OccupationIdentifierBean
     */
    public OccupationIdentifierBean getOccupationDetail() {
        return occupationDetail;
    }

    /**
     * Mutator for property occupationDetail.
     * 
     * @param occupationDetail of type OccupationIdentifierBean
     */
    @XmlElement(name = "occupation")
    public void setOccupationDetail(OccupationIdentifierBean occupationDetail) {
        this.occupationDetail = occupationDetail;
    }

    /**
     * Accessor for property mobileNumber.
     * 
     * @return mobileNumber of type String
     */
    public String getMobileNumber() {
        return mobileNumber;
    }

    /**
     * Mutator for property mobileNumber.
     * 
     * @param mobileNumber of type String
     */
    @XmlElement(name = "mobileNumber")
    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    /**
     * Accessor for property homeNumber.
     * 
     * @return homeNumber of type String
     */
    public String getHomeNumber() {
        return homeNumber;
    }

    /**
     * Mutator for property homeNumber.
     * 
     * @param homeNumber of type String
     */
    @XmlElement(name = "homeNumber")
    public void setHomeNumber(String homeNumber) {
        this.homeNumber = homeNumber;
    }

    /**
     * Accessor for property workNumber.
     * 
     * @return workNumber of type String
     */
    public String getWorkNumber() {
        return workNumber;
    }

    /**
     * Mutator for property workNumber.
     * 
     * @param workNumber of type String
     */
    @XmlElement(name = "workNumber")
    public void setWorkNumber(String workNumber) {
        this.workNumber = workNumber;
    }

    /**
     * Accessor for property addressTypeList.
     * 
     * @return addressTypeList of type String
     */
    public List<ClientAddressType> getAddressTypeList() {
        return addressTypeList;
    }

    /**
     * Mutator for property addressTypeList.
     * 
     * @param addressTypeList of type String
     */
    @XmlElement(name = "addressDetails")
    public void setAddressTypeList(List<ClientAddressType> addressTypeList) {
        this.addressTypeList = addressTypeList;
    }

    /**
     * Accessor for property bankDetails.
     * 
     * @return bankDetails of type String
     */
    public List<ClientBankDetailType> getBankDetails() {
        return bankDetails;
    }

    /**
     * Mutator for property bankDetails.
     * 
     * @param bankDetails of type String
     */
    @XmlElement(name = "bankDetails")
    public void setBankDetails(List<ClientBankDetailType> bankDetails) {
        this.bankDetails = bankDetails;
    }

    /**
     * Accessor for property externalReferenceType.
     * 
     * @return externalReferenceType of type String
     */
    public List<ExternalReferenceDetailType> getExternalReferenceType() {
        return externalReferenceType;
    }

    /**
     * Mutator for property externalReferenceType.
     * 
     * @param externalReferenceType of type String
     */
    @XmlElement(name = "externalReferenceTypeDetails")
    public void setExternalReferenceType(List<ExternalReferenceDetailType> externalReferenceType) {
        this.externalReferenceType = externalReferenceType;
    }

    /**
     * Accessor for property tfnConsentDetails.
     * 
     * @return tfnConsentDetails of type String
     */
    public TfnConsentDetailsType getTfnConsentDetails() {
        return tfnConsentDetails;
    }

    /**
     * Mutator for property tfnConsentDetails.
     * 
     * @param tfnConsentDetails of type String
     */
    @XmlElement(name = "tfnConsentDetails")
    public void setTfnConsentDetails(TfnConsentDetailsType tfnConsentDetails) {
        this.tfnConsentDetails = tfnConsentDetails;
    }

    /**
     * Accessor for property advisorGroupDetails.
     * 
     * @return advisorGroupDetails of type String
     */
    public List<ClientAdvisorDetailType> getAdvisorGroupDetails() {
        return advisorGroupDetails;
    }

    /**
     * Mutator for property advisorGroupDetails.
     * 
     * @param advisorGroupDetails of type String
     */
    @XmlElement(name = "advisorDetails")
    public void setAdvisorGroupDetails(List<ClientAdvisorDetailType> advisorGroupDetails) {
        this.advisorGroupDetails = advisorGroupDetails;
    }

    /**
     * Accessor for property clientContextDetails.
     * 
     * @return clientContextDetails of type String
     */
    public List<ClientContextDetailType> getClientContextDetails() {
        return clientContextDetails;
    }

    /**
     * Mutator for property clientContextDetails.
     * 
     * @param clientContextDetails of type String
     */
    @XmlElement(name = "clientcontextDetails")
    public void setClientContextDetails(List<ClientContextDetailType> clientContextDetails) {
        this.clientContextDetails = clientContextDetails;
    }

    /**
     * Accessor for property workDeclarationDetails.
     * 
     * @return workDeclarationDetails of type String
     */
    public Boolean isWorkDeclarationDetails() {
        return workDeclarationDetails;
    }

    /**
     * Mutator for property workDeclarationDetails.
     * 
     * @param workDeclarationDetails of type String
     */
    @XmlElement(name = "workdeclarationDetails")
    public void setWorkDeclarationDetails(Boolean workDeclarationDetails) {
        this.workDeclarationDetails = workDeclarationDetails;
    }

    /**
     * Accessor for property countryDetails.
     * 
     * @return countryDetails of type String
     */
    public CountryNameType getCountryDetails() {
        return countryDetails;
    }

    /**
     * Mutator for property countryDetails.
     * 
     * @param countryDetails of type String
     */
    @XmlElement(name = "country")
    public void setCountryDetails(CountryNameType countryDetails) {
        this.countryDetails = countryDetails;
    }

    /**
     * Accessor for property notes.
     * 
     * @return notes of type List<NoteBean>
     */
    public List<NoteBean> getNotes() {
        return notes;
    }

    /**
     * Mutator for property notes.
     * 
     * @param notes of type List<NoteBean>
     */
    @XmlElement(name = "notes")
    public void setNotes(List<NoteBean> notes) {
        this.notes = notes;
    }

    /**
     * Accessor for property preferredRisk.
     * 
     * @return preferredRisk of type CodeIdentifier
     */
    public CodeIdentifier getPreferredRisk() {
        return preferredRisk;
    }

    /**
     * Mutator for property preferredRisk.
     * 
     * @param preferredRisk of type CodeIdentifier
     */
    @XmlElement(name = "preferredRisk")
    public void setPreferredRisk(CodeIdentifier preferredRisk) {
        this.preferredRisk = preferredRisk;
    }

    /**
     * Accessor for property australia.
     *
     * @return australia of type AustraliaDetails
     */
    public AustraliaDetails getAustralia() {
        return australia;
    }

    /**
     * Mutator for property australia.
     *
     * @param australia of type AustraliaDetails
     */
    @XmlElement(name = "australia")
    public void setAustralia(AustraliaDetails australia) {
        this.australia = australia;
    }
}
