////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.clientservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code ClientAdvisorDetailType} is a java bean consisting of properties related to advisor details.
 * 
 * @author U383754
 * @since 23/10/2015
 * @version 1.0
 */
public class ClientAdvisorDetailType {
    private String advisorgroupId;
    private String operation;
    private String relationshipId;
    private String relationshipCode;
    private String relationshipName;
    private String advisorNumber;
    private String advisorForename;
    private String advisorSurname;
    private String advisorMaster;
    private String outletstatusCodetype;
    private String outletstatusCode;
    private String outletypeCodetype;
    private String outletType;
    private String effectiveDate;
    private String percentageSplit;
    private String primaryFlag;

    /**
     * Accessor for property advisorgroupId.
     * 
     * @return advisorgroupId of type String
     */
    public String getAdvisorgroupId() {
        return advisorgroupId;
    }

    /**
     * Mutator for property advisorgroupId.
     * 
     * @param advisorgroupId of type String
     */
    @XmlElement(name = "advisorgroupId")
    public void setAdvisorgroupId(String advisorgroupId) {
        this.advisorgroupId = advisorgroupId != null ? advisorgroupId : "";
    }

    /**
     * Accessor for property operation.
     * 
     * @return operation of type String
     */
    public String getOperation() {
        return operation;
    }

    /**
     * Mutator for property operation.
     * 
     * @param operation of type String
     */
    @XmlElement(name = "operation")
    public void setOperation(String operation) {
        this.operation = operation;
    }

    /**
     * Accessor for property relationshipId.
     * 
     * @return relationshipId of type String
     */
    public String getRelationshipId() {
        return relationshipId;
    }

    /**
     * Mutator for property relationshipId.
     * 
     * @param relationshipId of type String
     */
    @XmlElement(name = "relationshipId")
    public void setRelationshipId(String relationshipId) {
        this.relationshipId = relationshipId != null ? relationshipId : "";
    }

    /**
     * Accessor for property relationshipCode.
     * 
     * @return relationshipCode of type String
     */
    public String getRelationshipCode() {
        return relationshipCode;
    }

    /**
     * Mutator for property relationshipCode.
     * 
     * @param relationshipCode of type String
     */
    @XmlElement(name = "relationshipCode")
    public void setRelationshipCode(String relationshipCode) {
        this.relationshipCode = relationshipCode != null ? relationshipCode : "";
    }
    
    /**
     * Accessor for property relationshipName.
     * 
     * @return relationshipName of type String
     */
    public String getRelationshipName() {
        return relationshipName;
    }

    /**
     * Mutator for property relationshipName.
     * 
     * @return relationshipName of type String
     */
    @XmlElement(name = "relationshipName")
    public void setRelationshipName(String relationshipName) {
        this.relationshipName = relationshipName != null ? relationshipName : "";
    }

    /**
     * Accessor for property advisorNumber.
     * 
     * @return advisorNumber of type String
     */
    public String getAdvisorNumber() {
        return advisorNumber;
    }

    /**
     * Mutator for property advisorNumber.
     * 
     * @param advisorNumber of type String
     */
    @XmlElement(name = "advisorNumber")
    public void setAdvisorNumber(String advisorNumber) {
        this.advisorNumber = advisorNumber != null ? advisorNumber : "";
    }

    /**
     * Accessor for property advisorForename.
     * 
     * @return advisorForename of type String
     */
    public String getAdvisorForename() {
        return advisorForename;
    }

    /**
     * Mutator for property advisorForename.
     * 
     * @param advisorForename of type String
     */
    @XmlElement(name = "advisorForename")
    public void setAdvisorForename(String advisorForename) {
        this.advisorForename = advisorForename != null ? advisorForename : "";
    }

    /**
     * Accessor for property advisorSurname.
     * 
     * @return advisorSurname of type String
     */
    public String getAdvisorSurname() {
        return advisorSurname;
    }

    /**
     * Mutator for property advisorSurname.
     * 
     * @param advisorSurname of type String
     */
    @XmlElement(name = "advisorSurname")
    public void setAdvisorSurname(String advisorSurname) {
        this.advisorSurname = advisorSurname != null ? advisorSurname : "";
    }

    /**
     * Accessor for property advisorMaster.
     * 
     * @return advisorMaster of type String
     */
    public String getAdvisorMaster() {
        return advisorMaster;
    }

    /**
     * Mutator for property advisorMaster.
     * 
     * @param advisorMaster of type String
     */
    @XmlElement(name = "advisorMaster")
    public void setAdvisorMaster(String advisorMaster) {
        this.advisorMaster = advisorMaster != null ? advisorMaster : "";
    }

    /**
     * Accessor for property outletstatusCodetype.
     * 
     * @return outletstatusCodetype of type String
     */
    public String getOutletstatusCodetype() {
        return outletstatusCodetype;
    }

    /**
     * Mutator for property outletstatusCodetype.
     * 
     * @param outletstatusCodetype of type String
     */
    @XmlElement(name = "outletstatusCodetype")
    public void setOutletstatusCodetype(String outletstatusCodetype) {
        this.outletstatusCodetype = outletstatusCodetype != null ? outletstatusCodetype : "";
    }

    /**
     * Accessor for property outletstatusCode.
     * 
     * @return outletstatusCode of type String
     */
    public String getOutletstatusCode() {
        return outletstatusCode;
    }

    /**
     * Mutator for property outletstatusCode.
     * 
     * @param outletstatusCode of type String
     */
    @XmlElement(name = "outletstatusCode")
    public void setOutletstatusCode(String outletstatusCode) {
        this.outletstatusCode = outletstatusCode != null ? outletstatusCode : "";
    }

    /**
     * Accessor for property outletypeCodetype.
     * 
     * @return outletypeCodetype of type String
     */
    public String getOutletypeCodetype() {
        return outletypeCodetype;
    }

    /**
     * Mutator for property outletypeCodetype.
     * 
     * @param outletypeCodetype of type String
     */
    @XmlElement(name = "outletypeCodetype")
    public void setOutletypeCodetype(String outletypeCodetype) {
        this.outletypeCodetype = outletypeCodetype != null ? outletypeCodetype : "";
    }

    /**
     * Accessor for property outletType.
     * 
     * @return outletType of type String
     */
    public String getOutletType() {
        return outletType;
    }

    /**
     * Mutator for property outletType.
     * 
     * @param outletType of type String
     */
    @XmlElement(name = "outletType")
    public void setOutletType(String outletType) {
        this.outletType = outletType != null ? outletType : "";
    }

    /**
     * Accessor for property effectiveDate.
     * 
     * @return effectiveDate of type String
     */
    public String getEffectiveDate() {
        return effectiveDate;
    }

    /**
     * Mutator for property effectiveDate.
     * 
     * @param effectiveDate of type String
     */
    @XmlElement(name = "effectiveDate")
    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate != null ? effectiveDate : "";
    }

    /**
     * Accessor for property percentageSplit.
     * 
     * @return percentageSplit of type String
     */
    public String getPercentageSplit() {
        return percentageSplit;
    }

    /**
     * Mutator for property percentageSplit.
     * 
     * @param percentageSplit of type String
     */
    @XmlElement(name = "percentageSplit")
    public void setPercentageSplit(String percentageSplit) {
        this.percentageSplit = percentageSplit != null ? percentageSplit : "";
    }

    /**
     * Accessor for property primaryFlag.
     * 
     * @return primaryFlag of type String
     */
    public String getPrimaryFlag() {
        return primaryFlag;
    }

    /**
     * Mutator for property primaryFlag.
     * 
     * @param primaryFlag of type String
     */
    @XmlElement(name = "primaryFlag")
    public void setPrimaryFlag(String primaryFlag) {
        this.primaryFlag = primaryFlag != null ? primaryFlag : "";
    }
}
