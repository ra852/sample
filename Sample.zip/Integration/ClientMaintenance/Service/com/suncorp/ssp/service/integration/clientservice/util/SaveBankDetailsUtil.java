////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.clientservice.util;

import java.util.List;

import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.ClientEntityType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CodeIdentifierType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.clientservice.ClientServiceConstants;
import com.suncorp.ssp.service.integration.clientservice.bean.ClientBankDetailType;

/**
 * The class {@code SaveBankDetailsUtil} is a Utility class with bank details related to client, to construct request for saving client external
 * service's request object.
 * 
 * @author U383847
 * @since 09/12/2015
 * @version 1.0
 */
public class SaveBankDetailsUtil {
    private final String className = "SaveBankDetailsUtil";

    /**
     * Set Client Bank Details.
     * 
     * @param clientEntityType
     * @param bankTypeList
     */
    public void setClientBankDetails(ClientEntityType clientEntityType, List<ClientBankDetailType> bankTypeList) throws SILException {
        SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Setting Client Bank Details");
        List<ClientEntityType.BankAccount> bankAccountLst = clientEntityType.getBankAccount();
        for (ClientBankDetailType bankDetailType : bankTypeList) {
            ClientEntityType.BankAccount bankAccount = new ClientEntityType.BankAccount();
            if (bankDetailType.getBankId() != null) {
                try {
                    bankAccount.setId(Long.parseLong(bankDetailType.getBankId()));
                } catch (NumberFormatException exception) {
                    throw new SILException(ClientServiceConstants.INVALID_BANK_ID_FORMAT);
                }
            }
            CodeIdentifierType bankCodeIdentifier = new CodeIdentifierType();
            bankCodeIdentifier.setCode(ClientServiceConstants.CLIENT_BANK_TYPE);
            bankCodeIdentifier.setCodeType(ClientServiceConstants.CLIENT_BANK_TYPE);
            bankAccount.setTypeCode(bankCodeIdentifier);
            bankAccount.setAccountNumber(bankDetailType.getBankAccount());
            bankAccount.setAccountName(bankDetailType.getAccountName());
            //bankAccount.setBankName(bankDetailType.getBankName());
            //bankAccount.setBankBranchName(bankDetailType.getBranchName());
            //bankAccount.setBsbNumber(bankDetailType.getBsbNumber());
            bankAccount.setDelete(SILUtil.checkDeleteOperation(bankDetailType.getOperation()));
            bankAccountLst.add(bankAccount);
        }
    }
}
