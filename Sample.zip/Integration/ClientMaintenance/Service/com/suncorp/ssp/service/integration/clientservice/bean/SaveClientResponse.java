////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package com.suncorp.ssp.service.integration.clientservice.bean;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.suncorp.ssp.common.bean.SILErrorMessage;

/**
 * The class {@code SaveClientResponse} is a java bean consisting of all the properties related to client details, to be used for constructing save
 * client response.
 * 
 * @author U383847
 * @since 29/10/2015
 * @version 1.0
 */
@XmlRootElement(name = "SaveClientResponse")
public class SaveClientResponse extends SILErrorMessage {
    private String clientId;
    private String clientName;
    private String clientTfn;
    private String firstName;
    private String lastName;
    private String status;
    private String errorCode;

    /**
     * Accessor for property clientId.
     * 
     * @return clientId of type String
     */
    public String getClientId() {
        return clientId;
    }

    /**
     * Mutator for property clientID.
     * 
     * @param clientID
     *            of type String
     */
    @XmlElement(name = "clientId")
    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    /**
     * Accessor for property clientName.
     * 
     * @return clientName of type String
     */
    public String getClientName() {
        return clientName;
    }

    /**
     * Mutator for property clientName.
     * 
     * @param clientName
     *            of type String
     */
    @XmlElement(name = "name")
    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    /**
     * Accessor for property clientTfn.
     * 
     * @return clientTfn of type String
     */
    public String getClientTfn() {
        return clientTfn;
    }

    /**
     * Mutator for property clientTfn.
     * 
     * @param clientTfn
     *            of type String
     */
    @XmlElement(name = "tfn")
    public void setClientTfn(String clientTfn) {
        this.clientTfn = clientTfn;
    }

    /**
     * Accessor for property firstName.
     * 
     * @return firstName of type String
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Mutator for property firstName.
     * 
     * @param firstName
     *            of type String
     */
    @XmlElement(name = "firstName")
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * Accessor for property lastName.
     * 
     * @return lastName of type String
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Mutator for property lastName.
     * 
     * @param lastName
     *            of type String
     */
    @XmlElement(name = "lastName")
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * Accessor for property status.
     * 
     * @return status of type String
     */
    public String getStatus() {
        return status;
    }

    /**
     * Mutator for property status.
     * 
     * @param status
     *            of type String
     */
    @XmlElement(name = "status")
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * Accessor for property errorCode.
     * 
     * @return errorCode of type String
     */
    public String getErrorCode() {
        return errorCode;
    }

    /**
     * Mutator for property errorCode.
     * 
     * @param errorCode
     *            of type String
     */
    @XmlElement(name = "errorCode")
    public void setErrorCode(String errorCode) {
        this.errorCode = errorCode;
    }
}
