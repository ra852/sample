////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.clientservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code AuditDetails} does this.
 *
 * @author U383847
 * @since 15/03/2016
 * @version 1.0
 */
public class AuditDetails {
    private String lastUpdated;
    private String lastUpdatedBy;
    private String dataVersion;
    
    /**
     * Accessor for property lastUpdated.
     * 
     * @return lastUpdated of type String
     */
    public String getLastUpdated() {
        return lastUpdated;
    }
    
    /**
     * Mutator for property lastUpdated.
     * 
     * @return lastUpdated of type String
     */
    @XmlElement(name = "lastUpdated")
    public void setLastUpdated(String lastUpdated) {
        this.lastUpdated = lastUpdated != null ? lastUpdated : "";
    }
    
    /**
     * Accessor for property lastUpdatedBy.
     * 
     * @return lastUpdatedBy of type String
     */
    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }
    
    /**
     * Mutator for property lastUpdatedBy.
     * 
     * @return lastUpdatedBy of type String
     */
    @XmlElement(name = "lastUpdatedBy")
    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy != null ? lastUpdatedBy : "";
    }
    
    /**
     * Accessor for property dataVersion.
     * 
     * @return dataVersion of type String
     */
    public String getDataVersion() {
        return dataVersion;
    }
    
    /**
     * Mutator for property dataVersion.
     * 
     * @return dataVersion of type String
     */
    @XmlElement(name = "dataVersion")
    public void setDataVersion(String dataVersion) {
        this.dataVersion = dataVersion != null ? dataVersion : "";
    }
}
