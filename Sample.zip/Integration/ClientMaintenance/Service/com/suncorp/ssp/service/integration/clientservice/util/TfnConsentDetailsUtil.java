////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.clientservice.util;

import java.util.List;

import com.sonatacentral.service.v30.common.client.GetClientResponseType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.GenericVariableType;
import com.suncorp.ssp.service.constants.clientservice.ClientServiceConstants;
import com.suncorp.ssp.service.integration.clientservice.bean.TfnConsentDetailsType;

/**
 * The class {@code TfnConsentDetailsUtil} does this.
 * 
 * @author u384380
 * @since 30/11/2015
 * @version 1.0
 */
public class TfnConsentDetailsUtil {

    private GetClientResponseType getClientResponseType;

    /**
     * Constructor of class TfnConsentDetailsUtil.
     * 
     * @param getClientResponseType
     *            of type GetClientResponseType
     */
    public TfnConsentDetailsUtil(GetClientResponseType getClientResponseType) {
        this.getClientResponseType = getClientResponseType;
    }

    /**
     * Will set the TFN Constent details.
     * 
     * @param tfnConsentDetailsType
     *            of type TfnConsentDetailsType
     */
    public void setTfnConsentDetails(TfnConsentDetailsType tfnConsentDetailsType) {
        boolean setTfnConstentFlag = false;
        if (this.getClientResponseType != null && this.getClientResponseType.getGenericVariable() != null) {
            List<GenericVariableType> genericVariable = this.getClientResponseType.getGenericVariable();
            for (GenericVariableType genericVariableType : genericVariable) {
                if (this.getTfnConsentCode(genericVariableType).equals(ClientServiceConstants.TFN_CONSENT_CODE)) {
                    tfnConsentDetailsType.setTfnConsentId(this.getTfnConsentId(genericVariableType));
                    tfnConsentDetailsType.setTfnConsentCode(this.getTfnConsentCode(genericVariableType));
                    tfnConsentDetailsType.setTfnConsentLabel(this.getTfnConsentLabel(genericVariableType));
                    tfnConsentDetailsType.setTfnConsentDesc(this.setTfnConsentDesc(genericVariableType));
                    tfnConsentDetailsType.setTfnConsentValue(this.getTfnConsentValue(genericVariableType));
                    setTfnConstentFlag = true;
                }
            }
        }
        if (setTfnConstentFlag == false) {
            setDummyTfnConsent(tfnConsentDetailsType);
        }
    }

    /**
     * Will return TFN Consent ID.
     * 
     * @param genericVariableType
     *            of type GenericVariableType
     */
    private String getTfnConsentId(GenericVariableType genericVariableType) {
        if (genericVariableType.getId() != null) {
            return String.valueOf(genericVariableType.getId());
        }

        return "";
    }

    /**
     * Will return TFN Constent Code.
     * 
     * @param genericVariableType
     *            of type GenericVariableType
     */
    private String getTfnConsentCode(GenericVariableType genericVariableType) {
        if (genericVariableType.getCode() != null) {
            return genericVariableType.getCode();
        }

        return "";
    }

    /**
     * Will return TFN Constent Label.
     * 
     * @param genericVariableType
     *            of type GenericVariableType
     */
    private String getTfnConsentLabel(GenericVariableType genericVariableType) {
        if (genericVariableType.getLabel() != null) {
            return genericVariableType.getLabel();
        }
        return "";
    }

    /**
     * Will return TFN Constent description.
     * 
     * @param genericVariableType
     *            of type GenericVariableType
     */
    private String setTfnConsentDesc(GenericVariableType genericVariableType) {
        if (genericVariableType.getDescription() != null) {
            return genericVariableType.getDescription();
        }
        return "";
    }

    /**
     * Will return TFN Constent value.
     * 
     * @param genericVariableType
     *            of type GenericVariableType
     */
    private String getTfnConsentValue(GenericVariableType genericVariableType) {
        if (genericVariableType.getValue() != null && genericVariableType.getValue().getCode() != null &&
                genericVariableType.getValue().getCode().getCodeDescription() != null) {
            return genericVariableType.getValue().getCode().getCodeDescription();
        }
        return "";
    }

    private void setDummyTfnConsent(TfnConsentDetailsType tfnConsentDetailsType) {
        tfnConsentDetailsType.setTfnConsentId("");
        tfnConsentDetailsType.setTfnConsentCode("");
        tfnConsentDetailsType.setTfnConsentLabel("");
        tfnConsentDetailsType.setTfnConsentDesc("");
        tfnConsentDetailsType.setTfnConsentValue("");
    }
}
