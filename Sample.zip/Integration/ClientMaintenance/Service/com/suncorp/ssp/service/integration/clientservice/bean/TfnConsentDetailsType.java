////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.clientservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code TfnConsentDeatilsType} does this.
 * 
 * @author u384380
 * @since 30/11/2015
 * @version 1.0
 */
public class TfnConsentDetailsType {
    private String tfnConsentId;
    private String tfnConsentCode;
    private String tfnConsentLabel;
    private String tfnConsentDesc;
    private String tfnConsentValue;
    private String operation;

    /**
     * Accessor for property tfnConsentId.
     * 
     * @return tfnConsentId of type String
     */
    public String getTfnConsentId() {
        return tfnConsentId;
    }

    /**
     * Mutator for property tfnConsentId.
     * 
     * @param tfnConsentId of type String
     */
    @XmlElement(name = "tfnConsentId")
    public void setTfnConsentId(String tfnConsentId) {
        this.tfnConsentId = tfnConsentId;
    }

    /**
     * Accessor for property tfnConsentCode.
     * 
     * @return tfnConsentCode of type String
     */
    public String getTfnConsentCode() {
        return tfnConsentCode;
    }

    /**
     * Mutator for property tfnConsentCode.
     * 
     * @param tfnConsentCode of type String
     */
    @XmlElement(name = "tfnConsentCode")
    public void setTfnConsentCode(String tfnConsentCode) {
        this.tfnConsentCode = tfnConsentCode;
    }

    /**
     * Accessor for property tfnConsentLabel.
     * 
     * @return tfnConsentLabel of type String
     */
    public String getTfnConsentLabel() {
        return tfnConsentLabel;
    }

    /**
     * Mutator for property tfnConsentLabel.
     * 
     * @param tfnConsentLabel of type String
     */
    @XmlElement(name = "tfnConsentLabel")
    public void setTfnConsentLabel(String tfnConsentLabel) {
        this.tfnConsentLabel = tfnConsentLabel;
    }

    /**
     * Accessor for property tfnConsentDesc.
     * 
     * @return tfnConsentDesc of type String
     */
    public String getTfnConsentDesc() {
        return tfnConsentDesc;
    }

    /**
     * Mutator for property tfnConsentDesc.
     * 
     * @param tfnConsentDesc of type String
     */
    @XmlElement(name = "tfnConsentDesc")
    public void setTfnConsentDesc(String tfnConsentDesc) {
        this.tfnConsentDesc = tfnConsentDesc;
    }

    /**
     * Accessor for property tfnConsentValue.
     * 
     * @return tfnConsentValue of type String
     */
    public String getTfnConsentValue() {
        return tfnConsentValue;
    }

    /**
     * Mutator for property tfnConsentValue.
     * 
     * @param tfnConsentValue of type String
     */
    @XmlElement(name = "tfnConsentValue")
    public void setTfnConsentValue(String tfnConsentValue) {
        this.tfnConsentValue = tfnConsentValue;
    }

    /**
     * Accessor for property operation.
     * 
     * @return operation of type String
     */
    public String getOperation() {
        return operation;
    }

    /**
     * Mutator for property operation.
     * 
     * @param operation of type String
     */
    @XmlElement(name = "operation")
    public void setOperation(String operation) {
        this.operation = operation;
    }
}
