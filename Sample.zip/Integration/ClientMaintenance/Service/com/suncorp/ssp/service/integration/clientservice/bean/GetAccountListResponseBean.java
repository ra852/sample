////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.clientservice.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.suncorp.ssp.common.bean.SILErrorMessage;

/**
 * The class {@code GetAccountListResponseBean} is a java bean consisting of all the properties related to getAccountList functionality, to be used
 * for constructing response for end-client.
 * 
 * @author U385424
 * @since 13/11/2015
 * @version 1.0
 */
@XmlRootElement(name = "GetAccountListResponse")
public class GetAccountListResponseBean extends SILErrorMessage {

    private List<AccountNumbers> accounts;

    /**
     * Accessor for property accounts.
     * 
     * @return accounts of type List<AccountNumbers>
     */
    public List<AccountNumbers> getAccounts() {
        return accounts;
    }

    /**
     * Mutator for property accounts.
     * 
     * @return accounts of type List<AccountNumbers>
     */
    @XmlElement(name = "accounts")
    public void setAccounts(List<AccountNumbers> accounts) {
        this.accounts = accounts;
    }

}
