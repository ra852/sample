////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.clientservice.util;

import java.util.List;

import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.ClientContextType;
import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.ClientEntityType;
import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.ClientIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CodeIdentifierType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.clientservice.ClientServiceConstants;
import com.suncorp.ssp.service.integration.clientservice.bean.ClientContextDetailType;

/**
 * The class {@code SaveContextDetailsUtil} is a Utility class with Context details related to client, to construct request for saving client external
 * service's request object.
 * 
 * @author U383847
 * @since 11/12/2015
 * @version 1.0
 */
public class SaveContextDetailsUtil {
    private final String className = "SaveContextDetailsUtil";

    /**
     * Set Client Context Details.
     * 
     * @param clientEntityType
     * @param contextDetails
     * @throws Exception
     */
    public void setContextDetails(ClientEntityType clientEntityType, List<ClientContextDetailType> contextDetails) throws SILException {
        SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Setting Client Context Details");
        List<ClientContextType> clientContextTypeList = clientEntityType.getClientContext();
        for (ClientContextDetailType contextDetailType : contextDetails) {
            ClientContextType clientContextType = new ClientContextType();
            if (contextDetailType.getClientContextId() != null) {
                try {
                    clientContextType.setId(Long.parseLong(contextDetailType.getClientContextId()));
                } catch (NumberFormatException exception) {
                    throw new SILException(ClientServiceConstants.INVALID_CONTEXT_ID_FORMAT);
                }
            }
            setClientContextDetails(contextDetailType, clientContextType);
            clientContextType.setEffectiveFromDate(SILUtil.convertStringToXMLGregorianCalendar(contextDetailType.getEffectiveFromDate(),
                    CommonConstants.DATE_FORMAT));
            clientContextType.setEffectiveEndDate(SILUtil.convertStringToXMLGregorianCalendar(contextDetailType.getEffectiveEndDate(),
                    CommonConstants.DATE_FORMAT));
            clientContextType.setIsRelatedClient(Boolean.parseBoolean(contextDetailType.getIsRelatedClient()));
            clientContextType.setDelete(SILUtil.checkDeleteOperation(contextDetailType.getOperation()));
            clientContextTypeList.add(clientContextType);
        }
    }

    /**
     * Set Related Client Context Details.
     * 
     * @param contextDetailType
     * @param clientContextType
     */
    private void setClientContextDetails(ClientContextDetailType contextDetailType, ClientContextType clientContextType) throws SILException {
        ClientIdentifierType clientIdentifierType = new ClientIdentifierType();
        clientIdentifierType.setId(SILUtil.validateClientId(contextDetailType.getRelatedClient()));
        clientContextType.setRelatedClient(clientIdentifierType);
        CodeIdentifierType codeIdentifierType = new CodeIdentifierType();
        codeIdentifierType.setCode(contextDetailType.getCodeIndentifierType());
        codeIdentifierType.setCodeType(contextDetailType.getCodeIndentifierCodeType());
        clientContextType.setTypeCode(codeIdentifierType);
    }
}
