////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.clientservice.util;

import javax.ws.rs.core.MultivaluedMap;

import com.sonatacentral.service.v30.common.client.GetClientRequestType;
import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.ClientIdentifierType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.clientservice.ClientServiceConstants;

/**
 * The class {@code GetClientRequestUtil} is a request util used to create request for sonata.
 * 
 * @author U385424
 * @since 22/12/2016
 * @version 1.0
 */
public class GetClientRequestUtil {
    private final String className = "GetClientRequestUtil";
    private GetClientRequestType outboundRequest;
    private MultivaluedMap<String, String> inboundRequest;

    /**
     * This is a parameterized constructor.
     * 
     * @param inboundRequest
     */
    public GetClientRequestUtil(MultivaluedMap<String, String> inboundRequest) {
        this.inboundRequest = inboundRequest;
        this.outboundRequest = new GetClientRequestType();
    }

    /**
     * This method is used to create outbound request.
     * 
     * 
     * 
     * @return outboundRequest
     */
    public GetClientRequestType createOutboundRequest() throws SILException {
        SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, className, "Entering createOutboundRequest()");
        this.outboundRequest.setCallerDetails(SILUtil.createCallerDetails());
        this.outboundRequest.setClient(retrieveClientIdentifier());
        constructRequestFlags();
        return this.outboundRequest;
    }

    /**
     * 
     * This method is used to get the client Id from query string.
     * 
     * @param exchange
     * @return the client Id
     * @throws SILException
     */
    private ClientIdentifierType retrieveClientIdentifier() throws SILException {
        ClientIdentifierType clientIdentifierType = new ClientIdentifierType();
        if (inboundRequest.containsKey(ClientServiceConstants.CLIENT_ID) && inboundRequest.get(ClientServiceConstants.CLIENT_ID).get(0) != null) {
            clientIdentifierType.setId(Long.parseLong(inboundRequest.get(ClientServiceConstants.CLIENT_ID).get(0)));
        } else {
            throw new SILException(ClientServiceConstants.INVALID_REQUEST_MESSAGE);
        }
        return clientIdentifierType;
    }

    /**
     * This method is used to construct request flags.
     * 
     */
    private void constructRequestFlags() {
        if (this.inboundRequest.containsKey(ClientServiceConstants.INCLUDE_CLIENT_DETAILS)) {
            this.outboundRequest.setIncludeClientDetails(Boolean.parseBoolean(this.inboundRequest.get(ClientServiceConstants.INCLUDE_CLIENT_DETAILS)
                    .get(0)));
        }
        if (this.inboundRequest.containsKey(ClientServiceConstants.INCLUDE_ADDRESS)) {
            this.outboundRequest.setIncludeAddress(Boolean.parseBoolean(this.inboundRequest.get(ClientServiceConstants.INCLUDE_ADDRESS).get(0)));
        }
        if (this.inboundRequest.containsKey(ClientServiceConstants.INCLUDE_BANK_ACCOUNT)) {
            this.outboundRequest.setIncludeBankAccount(Boolean.parseBoolean(this.inboundRequest.get(ClientServiceConstants.INCLUDE_BANK_ACCOUNT).get(
                    0)));
        }
        if (this.inboundRequest.containsKey(ClientServiceConstants.INCLUDE_EXTERNAL_REFERENCE)) {
            this.outboundRequest.setIncludeExternalReference(Boolean.parseBoolean(this.inboundRequest.get(
                    ClientServiceConstants.INCLUDE_EXTERNAL_REFERENCE).get(0)));
        }
        if (this.inboundRequest.containsKey(ClientServiceConstants.INCLUDE_GENERIC_VARIABLE)) {
            this.outboundRequest.setIncludeGenericVariable(Boolean.parseBoolean(this.inboundRequest.get(
                    ClientServiceConstants.INCLUDE_GENERIC_VARIABLE).get(0)));
        }
        constructRemainingRequestFlags();
    }

    /**
     * This method is used to construct request flags.
     * 
     */
    private void constructRemainingRequestFlags() {
        if (this.inboundRequest.containsKey(ClientServiceConstants.INCLUDE_NOTE)) {
            this.outboundRequest.setIncludeNote(Boolean.parseBoolean(this.inboundRequest.get(ClientServiceConstants.INCLUDE_NOTE).get(0)));
        }
        if (this.inboundRequest.containsKey(ClientServiceConstants.INCLUDE_CLIENT_CONTEXT)) {
            this.outboundRequest.setIncludeClientContext(Boolean.parseBoolean(this.inboundRequest.get(ClientServiceConstants.INCLUDE_CLIENT_CONTEXT)
                    .get(0)));
        }
        if (this.inboundRequest.containsKey(ClientServiceConstants.INCLUDE_ADVISOR_GROUP)) {
            this.outboundRequest.setIncludeAdvisorGroup(Boolean.parseBoolean(this.inboundRequest.get(ClientServiceConstants.INCLUDE_ADVISOR_GROUP)
                    .get(0)));
        }
        if (this.inboundRequest.containsKey(ClientServiceConstants.INCLUDE_NEWZEALAND)) {
            this.outboundRequest
                    .setIncludeNewZealand(Boolean.parseBoolean(this.inboundRequest.get(ClientServiceConstants.INCLUDE_NEWZEALAND).get(0)));
        }
        if (this.inboundRequest.containsKey(ClientServiceConstants.INCLUDE_SOUTH_AFRICA)) {
            this.outboundRequest.setIncludeSouthAfrica(Boolean.parseBoolean(this.inboundRequest.get(ClientServiceConstants.INCLUDE_SOUTH_AFRICA).get(
                    0)));
        }
        if (this.inboundRequest.containsKey(ClientServiceConstants.INCLUDE_AUSTRALIA)) {
            this.outboundRequest.setIncludeAustralia(Boolean.parseBoolean(this.inboundRequest.get(ClientServiceConstants.INCLUDE_AUSTRALIA).get(0)));
        }
        constructOtherRemainingFlags();
    }

    /**
     * This method is used to construct request flags.
     * 
     */
    private void constructOtherRemainingFlags() {
        if (this.inboundRequest.containsKey(ClientServiceConstants.INCLUDE_UNITED_KINGDOM)) {
            this.outboundRequest.setIncludeUnitedKingdom(Boolean.parseBoolean(this.inboundRequest.get(ClientServiceConstants.INCLUDE_UNITED_KINGDOM)
                    .get(0)));
        }
        if (this.inboundRequest.containsKey(ClientServiceConstants.INCLUDE_WORK_DECLARATION)) {
            this.outboundRequest.setIncludeWorkDeclaration(Boolean.parseBoolean(this.inboundRequest.get(
                    ClientServiceConstants.INCLUDE_WORK_DECLARATION).get(0)));
        }
        if (this.inboundRequest.containsKey(ClientServiceConstants.INCLUDE_TAX_TREATY_DETAILS)) {
            this.outboundRequest.setIncludeTaxTreatyDetails(Boolean.parseBoolean(this.inboundRequest.get(
                    ClientServiceConstants.INCLUDE_TAX_TREATY_DETAILS).get(0)));
        }
        if (this.inboundRequest.containsKey(ClientServiceConstants.INCLUDE_CORRO_DELIVERY_PREFERENCES)) {
            this.outboundRequest.setIncludeCorroDeliveryPreferences(Boolean.parseBoolean(this.inboundRequest.get(
                    ClientServiceConstants.INCLUDE_CORRO_DELIVERY_PREFERENCES).get(0)));
        }
        if (this.inboundRequest.containsKey(ClientServiceConstants.INCLUDE_APS_SUBSCRIPTION)) {
            this.outboundRequest.setIncludeApsSubscription(Boolean.parseBoolean(this.inboundRequest.get(
                    ClientServiceConstants.INCLUDE_APS_SUBSCRIPTION).get(0)));
        }
    }
}
