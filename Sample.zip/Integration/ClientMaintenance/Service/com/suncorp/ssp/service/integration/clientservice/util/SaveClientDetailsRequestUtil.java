////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.clientservice.util;

import java.util.ArrayList;
import java.util.List;

import com.sonatacentral.service.v30.common.client.SaveClientRequestType;
import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.AddressDetailsType;
import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.ClientDetailType;
import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.ClientEntityType;
import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.ClientIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CodeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.NoteCategoryIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.NoteTemplateIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.NoteType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.OccupationIdentifierType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.clientservice.ClientServiceConstants;
import com.suncorp.ssp.service.integration.clientservice.bean.AustraliaDetails;
import com.suncorp.ssp.service.integration.clientservice.bean.ClientAddressType;
import com.suncorp.ssp.service.integration.clientservice.bean.ClientAdvisorDetailType;
import com.suncorp.ssp.service.integration.clientservice.bean.ClientBankDetailType;
import com.suncorp.ssp.service.integration.clientservice.bean.ClientContextDetailType;
import com.suncorp.ssp.service.integration.clientservice.bean.CodeIdentifier;
import com.suncorp.ssp.service.integration.clientservice.bean.CountryNameType;
import com.suncorp.ssp.service.integration.clientservice.bean.ExternalReferenceDetailType;
import com.suncorp.ssp.service.integration.clientservice.bean.NoteBean;
import com.suncorp.ssp.service.integration.clientservice.bean.NoteCategoryBean;
import com.suncorp.ssp.service.integration.clientservice.bean.NoteTemplateBean;
import com.suncorp.ssp.service.integration.clientservice.bean.OccupationIdentifierBean;
import com.suncorp.ssp.service.integration.clientservice.bean.SaveClientRequest;
import com.suncorp.ssp.service.integration.clientservice.bean.TfnConsentDetailsType;

/**
 * The class {@code SaveClientDetailsRequestUtil} is a Utility class with all the properties related to client details, to construct request for
 * saving client external service's request object.
 * 
 * @author U383847
 * @since 09/12/2015
 * @version 1.0
 */
public class SaveClientDetailsRequestUtil {
    private final String className = "SaveClientDetailsRequestUtil";
    private SaveClientRequest saveClientRequest;
    private ClientServiceUtil clientServiceUtil = null;

    /**
     * Parameterized constructor for properties initialization.
     * 
     * @param saveClientRequest of type SaveClientRequest
     */
    public SaveClientDetailsRequestUtil(SaveClientRequest saveClientRequest) {
        this.saveClientRequest = saveClientRequest;
        this.clientServiceUtil = new ClientServiceUtil();
    }

    /**
     * Extracts values from all client details from respective objects and set the values to external service's request object.
     * 
     * @param saveClientRequestType
     * @throws SILException
     */
    public void setClientRequest(SaveClientRequestType saveClientRequestType) throws SILException {
        SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Setting Client Request Details");
        Long clientId = SILUtil.validateClientId(saveClientRequest.getClientId());
        ClientIdentifierType clientIdentifierType = setClientIdentifierType(clientId);
        ClientDetailType clientDetailType = setClientDetailType(clientId);
        ClientEntityType clientEntityType = new ClientEntityType();
        List<AddressDetailsType> address = clientEntityType.getAddress();
        this.setAddressDetails(this.saveClientRequest, address);
        this.setOccupationDetails(clientEntityType, clientDetailType);
        this.setBankDetails(this.saveClientRequest, clientEntityType);
        this.setExternalReferenceDetails(this.saveClientRequest, clientEntityType);
        this.setTfnConsentDetails(this.saveClientRequest, clientEntityType);
        this.setAdvisorDetails(this.saveClientRequest, clientEntityType);
        this.setContextDetails(this.saveClientRequest, clientEntityType);
        this.setWorkDeclarationDetails(this.saveClientRequest, clientEntityType);
        this.setWorkDeclarationDetails(this.saveClientRequest, clientEntityType);
        ClientEntityType.Australia australia = new ClientEntityType.Australia();
        this.setCountryDetails(this.saveClientRequest, australia);
        clientEntityType.setAustralia(australia);
        setNotesDetailsInRequest(saveClientRequest, clientEntityType);
        setClientDetailsInRequest(clientEntityType, clientIdentifierType, clientDetailType, saveClientRequestType);
    }

    /**
     * Set Client Identifier Details.
     * 
     * @param clientId
     * @return object type of ClientIdentifierType
     */
    private ClientIdentifierType setClientIdentifierType(Long clientId) {
        SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Setting Client Identifier Details");
        ClientIdentifierType clientIdentifierType = new ClientIdentifierType();
        clientIdentifierType.setId(clientId);
        return clientIdentifierType;
    }

    /**
     * Set Client Details.
     * 
     * @param clientId
     * @return object type of ClientDetailType
     */
    private ClientDetailType setClientDetailType(Long clientId) throws SILException {
        SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Setting Client Details");
        ClientDetailType clientDetailType = new ClientDetailType();
        clientDetailType.setId(clientId);
        clientDetailType.setSurname(saveClientRequest.getSurname());
        clientDetailType.setForename(saveClientRequest.getFirstName());
        clientDetailType.setForename2(saveClientRequest.getMiddleName());
        clientDetailType.setContactName(saveClientRequest.getContactName());
        setClientAdditionalDetails(clientDetailType);
        clientDetailType.setHomePhone(saveClientRequest.getHomeNumber());
        clientDetailType.setMobilePhone(saveClientRequest.getMobileNumber());
        clientDetailType.setBusinessPhone(saveClientRequest.getWorkNumber());
        return clientDetailType;
    }

    /**
     * Set Client Additional Details.
     * 
     * @param clientDetailType
     * @throws SILException
     */
    private void setClientAdditionalDetails(ClientDetailType clientDetailType) throws SILException {
        if (saveClientRequest.getTitle() != null) {
            setTitle(saveClientRequest, clientDetailType);
        }
        if (saveClientRequest.getGender() != null) {
            setGender(saveClientRequest, clientDetailType);
        }
        if (saveClientRequest.getMaritalStatus() != null) {
            setMaritalStatus(saveClientRequest, clientDetailType);
        }
        if (saveClientRequest.getDateOfBirth() != null) {
            clientDetailType.setDateOfBirth(SILUtil.convertStringToXMLGregorianCalendar(saveClientRequest.getDateOfBirth(),
                    CommonConstants.DATE_FORMAT));
        }
        if (saveClientRequest.getPreferredRisk() != null) {
            setPreferredRisk(saveClientRequest, clientDetailType);
        }
    }

    /**
     * Set Title Details.
     * 
     * @param saveClientRequest
     * @param clientDetailType
     */
    private void setTitle(SaveClientRequest saveClientRequest, ClientDetailType clientDetailType) {
        SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Setting Title");
        CodeIdentifierType codeIdentifierTitle = new CodeIdentifierType();
        codeIdentifierTitle.setCode(saveClientRequest.getTitle());
        codeIdentifierTitle.setCodeType(ClientServiceConstants.CLIENT_TITLE_CODE_TYPE);
        clientDetailType.setTitle(codeIdentifierTitle);
    }

    /**
     * Set Gender Details.
     * 
     * @param saveClientRequest
     * @param clientDetailType
     */
    private void setGender(SaveClientRequest saveClientRequest, ClientDetailType clientDetailType) {
        SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Setting Gender");
        CodeIdentifierType codeIdentifierGender = new CodeIdentifierType();
        codeIdentifierGender.setCode(saveClientRequest.getGender());
        codeIdentifierGender.setCodeType(ClientServiceConstants.SEX);
        clientDetailType.setGender(codeIdentifierGender);
    }

    /**
     * Set Marital Status Details.
     * 
     * @param saveClientRequest
     * @param clientDetailType
     */
    private void setMaritalStatus(SaveClientRequest saveClientRequest, ClientDetailType clientDetailType) {
        SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Setting Marital Status");
        CodeIdentifierType codeIdentifierMarital = new CodeIdentifierType();
        codeIdentifierMarital.setCode(saveClientRequest.getMaritalStatus());
        codeIdentifierMarital.setCodeType(ClientServiceConstants.MARITAL_STATUS);
        clientDetailType.setMaritalStatus(codeIdentifierMarital);
    }

    /**
     * Set Occupation Details.
     * 
     * @param saveClientRequest
     * @param clientEntityType
     * @param clientDetailType
     */
    private void setOccupationDetails(ClientEntityType clientEntityType, ClientDetailType clientDetailType) throws SILException {
        OccupationIdentifierType occupationIdentifierType = new OccupationIdentifierType();
        OccupationIdentifierBean occupationIdentifierBean = this.saveClientRequest.getOccupationDetail();
        if (occupationIdentifierBean != null) {
            SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Setting Occupation Details");
            if (occupationIdentifierBean.getId() != null) {
                occupationIdentifierType.setId(Long.parseLong(occupationIdentifierBean.getId()));
            }
            if (occupationIdentifierBean.getCode() != null) {
                occupationIdentifierType.setCode(occupationIdentifierBean.getCode());
            }
            if (occupationIdentifierBean.getName() != null) {
                occupationIdentifierType.setName(occupationIdentifierBean.getName());
            }
            clientDetailType.setOccupation(occupationIdentifierType);
            clientEntityType.setClientDetails(clientDetailType);
        }
    }

    /**
     * Set Address Details.
     * 
     * @param saveClientRequest
     * @param clientEntityType
     */
    private void setAddressDetails(SaveClientRequest saveClientRequest, List<AddressDetailsType> address) throws SILException {
        List<ClientAddressType> addressTypeList = saveClientRequest.getAddressTypeList();
        if (addressTypeList != null) {
            SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Setting Address Details");
            SaveAddressDetailsUtil saveAddressDetailsUtil = new SaveAddressDetailsUtil();
            saveAddressDetailsUtil.setClientAddressDetails(address, addressTypeList);
        }
    }

    /**
     * Set Bank Details.
     * 
     * @param saveClientRequest
     * @param clientEntityType
     */
    private void setBankDetails(SaveClientRequest saveClientRequest, ClientEntityType clientEntityType) throws SILException {
        List<ClientBankDetailType> bankTypeList = saveClientRequest.getBankDetails();
        if (bankTypeList != null) {
            SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Setting Bank Details");
            SaveBankDetailsUtil saveBankDetailsUtil = new SaveBankDetailsUtil();
            saveBankDetailsUtil.setClientBankDetails(clientEntityType, bankTypeList);
        }
    }

    /**
     * Set External Reference Details.
     * 
     * @param saveClientRequest
     * @param clientEntityType
     */
    private void setExternalReferenceDetails(SaveClientRequest saveClientRequest, ClientEntityType clientEntityType) {
        List<ExternalReferenceDetailType> externalRefType = saveClientRequest.getExternalReferenceType();
        if (externalRefType != null) {
            SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Setting External Reference Details");
            SaveExternalReferenceUtil saveExternalReferenceUtil = new SaveExternalReferenceUtil();
            saveExternalReferenceUtil.setExternalReferenceDetails(clientEntityType, externalRefType);
        }
    }

    /**
     * Set TfnConsent Details.
     * 
     * @param saveClientRequest
     * @param clientEntityType
     */
    private void setTfnConsentDetails(SaveClientRequest saveClientRequest, ClientEntityType clientEntityType) throws SILException {
        TfnConsentDetailsType tfnConsentDetails = saveClientRequest.getTfnConsentDetails();
        if (tfnConsentDetails != null) {
            SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Setting TfnConsent Details");
            SaveTfnConsentDetailsUtil saveTfnConsentDetailsUtil = new SaveTfnConsentDetailsUtil();
            saveTfnConsentDetailsUtil.setTfnConsentDetailsType(clientEntityType, tfnConsentDetails);
        }
    }

    /**
     * Set Advisor Details.
     * 
     * @param saveClientRequest
     * @param clientEntityType
     * @throws SILException
     */
    private void setAdvisorDetails(SaveClientRequest saveClientRequest, ClientEntityType clientEntityType) throws SILException {
        List<ClientAdvisorDetailType> advisorDetails = saveClientRequest.getAdvisorGroupDetails();
        if (advisorDetails != null) {
            SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Setting Advisor Details");
            SaveAdvisorDetailsUtil saveAdvisorDetailsUtil = new SaveAdvisorDetailsUtil();
            saveAdvisorDetailsUtil.setAdvisorGroupDetails(clientEntityType, advisorDetails);
        }
    }

    /**
     * Set Context Details.
     * 
     * @param saveClientRequest
     * @param clientEntityType
     * @throws SILException
     */
    private void setContextDetails(SaveClientRequest saveClientRequest, ClientEntityType clientEntityType) throws SILException {
        List<ClientContextDetailType> contextDetails = saveClientRequest.getClientContextDetails();
        if (contextDetails != null) {
            SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Setting Context Details");
            SaveContextDetailsUtil saveContextDetailsUtil = new SaveContextDetailsUtil();
            saveContextDetailsUtil.setContextDetails(clientEntityType, contextDetails);
        }
    }

    /**
     * Set Work Declaration Details.
     * 
     * @param saveClientRequest
     * @param clientEntityType
     */
    private void setWorkDeclarationDetails(SaveClientRequest saveClientRequest, ClientEntityType clientEntityType) {
        SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Setting Work Declaration Flag Details");
        clientEntityType.setHasWorkDeclaration(saveClientRequest.isWorkDeclarationDetails());
    }

    /**
     * Set Country Details.
     * 
     * @param saveClientRequest
     * @param clientEntityType
     * @throws SILException
     */
    private void setCountryDetails(SaveClientRequest saveClientRequest, ClientEntityType.Australia australia) throws SILException {
        CountryNameType countryNameType = saveClientRequest.getCountryDetails();
        AustraliaDetails australiaDetails = saveClientRequest.getAustralia();
        SaveCountryDetailsUtil saveCountryDetailsUtil = new SaveCountryDetailsUtil();
        if (countryNameType != null) {
            SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Setting Country Details");
            saveCountryDetailsUtil.setCountryDetails(australia, countryNameType, australiaDetails);
        }
        if (australiaDetails != null) {
            saveCountryDetailsUtil.setAustraliaDetails(australia, australiaDetails);
        }
    }

    /**
     * Set Client Details In Request.
     * 
     * @param clientEntityType
     * @param clientIdentifierType
     * @param clientDetailType
     * @param saveClientRequestType
     */
    private void setClientDetailsInRequest(ClientEntityType clientEntityType, ClientIdentifierType clientIdentifierType,
            ClientDetailType clientDetailType, SaveClientRequestType saveClientRequestType) {
        SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Setting Client Details In Request");
        clientEntityType.setClient(clientIdentifierType);
        clientEntityType.setClientDetails(clientDetailType);
        saveClientRequestType.setClient(clientEntityType);
    }

    /**
     * 
     * Set Notes in saveClient Request.
     * 
     * @param saveClientRequest
     * @param clientEntityType
     * @throws SILException
     */
    private void setNotesDetailsInRequest(SaveClientRequest saveClientRequest, ClientEntityType clientEntityType) throws SILException {
        String logger = ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT;
        SILLogger.debug(logger, className, "Setting setNotesDetailsInRequest()");
        List<NoteType> noteList = null;
        if (saveClientRequest != null && saveClientRequest.getNotes() != null && saveClientRequest.getNotes().size() > 0) {
            noteList = new ArrayList<NoteType>();
            List<NoteBean> noteBeansList = saveClientRequest.getNotes();
            for (NoteBean noteBean : noteBeansList) {
                if (noteBean != null) {
                    setNotesDetailsParam(logger, noteList, noteBean);
                }
            }
            clientEntityType.getNote().addAll(noteList);
        }

    }

    /**
     * 
     * Set Note details parameters.
     * 
     * @param logger
     * @param noteList
     * @param noteBean
     * @throws SILException
     */
    private void setNotesDetailsParam(String logger, List<NoteType> noteList, NoteBean noteBean) throws SILException {
        NoteType noteType = new NoteType();
        if (noteBean.getId() != null) {
            noteType.setId(Long.valueOf(noteBean.getId()));
        }
        if (noteBean.getNoteTemplate() != null) {
            noteType.setNoteTemplate(setNoteTemplateDetails(noteBean.getNoteTemplate()));
        }
        if (noteBean.getEffectiveDate() != null) {
            noteType.setEffectiveDate(clientServiceUtil.retrieveDateValueFromString(noteBean.getEffectiveDate(), logger));
        }
        if (noteBean.getExpiryDate() != null) {
            noteType.setExpiryDate(clientServiceUtil.retrieveDateValueFromString(noteBean.getExpiryDate(), logger));
        }
        if (noteBean.getNote() != null) {
            noteType.setNote(noteBean.getNote());
        }
        if (noteBean.getDelete() != null) {
            noteType.setDelete(Boolean.valueOf(noteBean.getDelete()));
        }
        noteList.add(noteType);
    }

    /**
     * 
     * Set note template details in save Client request.
     * 
     * @param noteTemplateBean
     * @return templateIdentifierType
     */
    private NoteTemplateIdentifierType setNoteTemplateDetails(NoteTemplateBean noteTemplateBean) {
        SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Setting setNoteTemplateDetails()");
        NoteTemplateIdentifierType templateIdentifierType = null;
        if (noteTemplateBean != null) {
            templateIdentifierType = new NoteTemplateIdentifierType();
            if (noteTemplateBean.getId() != null) {
                templateIdentifierType.setId(Long.valueOf(noteTemplateBean.getId()));
            }
            if (noteTemplateBean.getCode() != null) {
                templateIdentifierType.setCode(noteTemplateBean.getCode());
            }
            if (noteTemplateBean.getNoteCategory() != null) {
                templateIdentifierType.setNoteCategory(setNoteCategoryDetails(noteTemplateBean.getNoteCategory()));
            }
            if (noteTemplateBean.getName() != null) {
                templateIdentifierType.setName(noteTemplateBean.getName());
            }
        }
        return templateIdentifierType;

    }

    /**
     * 
     * Set note Category details in save Client request.
     * 
     * @param noteTemplateBean
     * @return templateIdentifierType
     */
    private NoteCategoryIdentifierType setNoteCategoryDetails(NoteCategoryBean noteCategoryBean) {
        SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Setting setNoteCategoryDetails()");
        NoteCategoryIdentifierType noteCategoryIdentifierType = null;
        if (noteCategoryBean != null) {
            noteCategoryIdentifierType = new NoteCategoryIdentifierType();
            if (noteCategoryBean.getCode() != null) {
                noteCategoryIdentifierType.setCode(noteCategoryBean.getCode());
            }

        }
        return noteCategoryIdentifierType;

    }

    /**
     * Set preferred Risk Details.
     * 
     * @param saveClientRequest
     * @param clientDetailType
     */
    private void setPreferredRisk(SaveClientRequest saveClientRequest, ClientDetailType clientDetailType) {
        SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Setting PreferredRisk");
        CodeIdentifier preferredRisk = saveClientRequest.getPreferredRisk();
        if (preferredRisk.getCode() != null && preferredRisk.getCodeType() != null) {
            CodeIdentifierType codeIdentifierTitle = new CodeIdentifierType();
            codeIdentifierTitle.setCode(preferredRisk.getCode());
            codeIdentifierTitle.setCodeType(preferredRisk.getCodeType());
            clientDetailType.setPreferredRisk(codeIdentifierTitle);
        }
    }
}
