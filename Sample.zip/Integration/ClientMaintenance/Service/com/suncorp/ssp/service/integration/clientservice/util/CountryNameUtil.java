////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.clientservice.util;

import java.text.SimpleDateFormat;

import com.sonatacentral.service.v30.common.client.GetClientResponseType;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.clientservice.ClientServiceConstants;
import com.suncorp.ssp.service.integration.clientservice.bean.Company;
import com.suncorp.ssp.service.integration.clientservice.bean.CountryNameType;

/**
 * The class {@code CountryNameUtil} does this.
 * 
 * @author U383754
 * @since 28/10/2015
 * @version 1.0
 */
public class CountryNameUtil {
    private GetClientResponseType getClientResponseType;
    private GetClientResponseType.Australia getClientCountryType;

    public CountryNameUtil(GetClientResponseType getClientResponseType) {
        this.getClientResponseType = getClientResponseType;
    }

    /**
     * 
     * This method is used to country info of client.
     * 
     * @param countryNameType
     */
    public void getCountryInfo(CountryNameType countryNameType) {
        SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "CountryNameUtil", "Entering in getCountryInfo.");
        if (this.getClientResponseType != null && this.getClientResponseType.getAustralia() != null) {
            this.getClientCountryType = this.getClientResponseType.getAustralia();
            this.getCountryTypeObj(countryNameType);
        } else {
            this.setDefaultValues(countryNameType);
        }
        SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "CountryNameUtil", "Exiting in getCountryInfo.");
    }

    /**
     * This method is used to get country type object.
     * 
     * @param countryNameType
     */
    private void getCountryTypeObj(CountryNameType countryNameType) {
        countryNameType.setTfn(this.getTfn());
        countryNameType.setTfnExemptioncodetype(this.getTfnExemptioncodetype());
        countryNameType.setTfnExemptioncode(this.getTfnExemptioncode());
        countryNameType.setTfnExemptionreason(this.getTfnExemptionreason());
        countryNameType.setTfnSupertickstatus(this.getTfnSupertickstatus());
        countryNameType.setTfnSupertickdate(this.getTfnSupertickdate());
        countryNameType.setAmlctfRiskcodetype(this.getAmlctfRiskcodetype());
        countryNameType.setAmlctfRiskcode(this.getAmlctfRiskcode());
        countryNameType.setAmlClasstypecode(this.getAmlClasstypecode());
        countryNameType.setAmlClasscode(this.getAmlClasscode());
        countryNameType.setAmlNote(this.getAmlNote());
        countryNameType.setCompany(this.getCompany());
    }

    /**
     * Accessor for property tfn.
     * 
     * @return tfn of type String
     */
    private String getTfn() {
        if (this.getClientResponseType.getClient() != null && this.getClientResponseType.getClient().getClientTFN() != null) {
            return this.getClientResponseType.getClient().getClientTFN();
        }
        return ClientServiceConstants.TFN_NOT_SUPPLIED;
    }

    /**
     * Accessor for property tfnExemptioncodetype.
     * 
     * @return tfnExemptioncodetype of type String
     */
    private String getTfnExemptioncodetype() {
        if (this.getClientCountryType != null && this.getClientCountryType.getTfnDetail() != null &&
                this.getClientCountryType.getTfnDetail().getTfnExemptionReason() != null &&
                this.getClientCountryType.getTfnDetail().getTfnExemptionReason().getCodeType() != null) {
            return this.getClientCountryType.getTfnDetail().getTfnExemptionReason().getCodeType();
        }
        return "";
    }

    /**
     * Accessor for property tfnExemptioncode.
     * 
     * @return tfnExemptioncode of type String
     */
    private String getTfnExemptioncode() {
        if (this.getClientCountryType != null && this.getClientCountryType.getTfnDetail() != null &&
                this.getClientCountryType.getTfnDetail().getTfnExemptionReason() != null &&
                this.getClientCountryType.getTfnDetail().getTfnExemptionReason().getCode() != null) {
            return this.getClientCountryType.getTfnDetail().getTfnExemptionReason().getCode();
        }
        return "";
    }

    /**
     * Accessor for property tfnExemptionreason.
     * 
     * @return tfnExemptionreason of type String
     */
    private String getTfnExemptionreason() {
        if (this.getClientCountryType != null && this.getClientCountryType.getTfnDetail() != null &&
                this.getClientCountryType.getTfnDetail().getTfnExemptionReason() != null &&
                this.getClientCountryType.getTfnDetail().getTfnExemptionReason().getCodeDescription() != null) {
            return this.getClientCountryType.getTfnDetail().getTfnExemptionReason().getCodeDescription();
        }
        return "";
    }

    /**
     * Accessor for property tfnSupertickstatus.
     * 
     * @return tfnSupertickstatus of type String
     */
    private String getTfnSupertickstatus() {
        if (this.getClientCountryType != null && this.getClientCountryType.getSupertickDetails() != null &&
                this.getClientCountryType.getSupertickDetails().getStatus() != null &&
                this.getClientCountryType.getSupertickDetails().getStatus().getCodeDescription() != null) {
            return this.getClientCountryType.getSupertickDetails().getStatus().getCodeDescription();
        }
        return "";
    }

    /**
     * Accessor for property tfnSupertickdate.
     * 
     * @return tfnSupertickdate of type String
     */
    private String getTfnSupertickdate() {
        if (this.getClientCountryType != null && this.getClientCountryType.getSupertickDetails() != null &&
                this.getClientCountryType.getSupertickDetails().getValidationDate() != null) {
            return new SimpleDateFormat(ClientServiceConstants.DATE_TIME_FORMAT).format(this.getClientCountryType.getSupertickDetails()
                    .getValidationDate().toGregorianCalendar().getTime());
        }
        return "";
    }

    /**
     * Accessor for property amlctfRiskcodetype.
     * 
     * @return amlctfRiskcodetype of type String
     */
    private String getAmlctfRiskcodetype() {
        if (this.getClientCountryType != null && this.getClientCountryType.getAntiMoneyLaundering() != null &&
                this.getClientCountryType.getAntiMoneyLaundering().getAmlCtfRisk() != null) {
            return this.getClientCountryType.getAntiMoneyLaundering().getAmlCtfRisk().getCodeType();
        }
        return "";
    }

    /**
     * Accessor for property amlctfRiskcode.
     * 
     * @return amlctfRiskcode of type String
     */
    private String getAmlctfRiskcode() {
        if (this.getClientCountryType != null && this.getClientCountryType.getAntiMoneyLaundering() != null &&
                this.getClientCountryType.getAntiMoneyLaundering().getAmlCtfRisk() != null) {
            return this.getClientCountryType.getAntiMoneyLaundering().getAmlCtfRisk().getCode();
        }
        return "";
    }

    /**
     * Accessor for property amlClasstypecode.
     * 
     * @return amlClasstypecode of type String
     */
    private String getAmlClasstypecode() {
        if (this.getClientCountryType != null && this.getClientCountryType.getAntiMoneyLaundering() != null &&
                this.getClientCountryType.getAntiMoneyLaundering().getAmlClass() != null) {
            return this.getClientCountryType.getAntiMoneyLaundering().getAmlClass().getCodeType();
        }
        return "";
    }

    /**
     * Accessor for property amlClasscode.
     * 
     * @return amlClasscode of type String
     */
    private String getAmlClasscode() {
        if (this.getClientCountryType != null && this.getClientCountryType.getAntiMoneyLaundering() != null &&
                this.getClientCountryType.getAntiMoneyLaundering().getAmlClass() != null) {
            return this.getClientCountryType.getAntiMoneyLaundering().getAmlClass().getCode();
        }
        return "";
    }

    /**
     * Accessor for property amlNote.
     * 
     * @return amlNote of type String
     */
    private String getAmlNote() {
        if (this.getClientCountryType != null && this.getClientCountryType.getAntiMoneyLaundering() != null &&
                this.getClientCountryType.getAntiMoneyLaundering().getAmlClassReason() != null) {
            return this.getClientCountryType.getAntiMoneyLaundering().getAmlClassReason();
        }
        return "";
    }

    /**
     * Get Company Details.
     * 
     * @return company of type Company
     */
    private Company getCompany() {
        Company company = new Company();
        if (this.getClientCountryType != null && this.getClientCountryType.getCompany() != null) {
            SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "CountryNameUtil", "Entering in getCompany.");
            company.setAbn(this.getAbn());
            company.setAcnArbn(this.getAcnArbn());
            company.setSpin(this.getSpin());
            company.setRegListingCodeType(this.getRegListingCodeType());
            company.setRegListingCode(this.getRegListingCode());
        } else {
            setDefaultCompanyValues(company);
        }
        return company;
    }

    /**
     * Accessor for property abn.
     * 
     * @return abn of type String
     */
    private String getAbn() {
        if (this.getClientCountryType != null && this.getClientCountryType.getCompany() != null &&
                this.getClientCountryType.getCompany().getAbn() != null) {
            return this.getClientCountryType.getCompany().getAbn();
        }
        return "";
    }

    /**
     * Accessor for property acnArbn.
     * 
     * @return acnArbn of type String
     */
    private String getAcnArbn() {
        if (this.getClientCountryType != null && this.getClientCountryType.getCompany() != null &&
                this.getClientCountryType.getCompany().getAcnArbn() != null) {
            return this.getClientCountryType.getCompany().getAcnArbn();
        }
        return "";
    }

    /**
     * Accessor for property spin.
     * 
     * @return spin of type String
     */
    private String getSpin() {
        if (this.getClientCountryType != null && this.getClientCountryType.getCompany() != null &&
                this.getClientCountryType.getCompany().getSpin() != null) {
            return this.getClientCountryType.getCompany().getSpin();
        }
        return "";
    }

    /**
     * Accessor for property regListingCodeType.
     * 
     * @return regListingCodeType of type String
     */
    private String getRegListingCodeType() {
        if (this.getClientCountryType != null && this.getClientCountryType.getCompany() != null &&
                this.getClientCountryType.getCompany().getRegListing() != null) {
            return this.getClientCountryType.getCompany().getRegListing().getCodeType();
        }
        return "";
    }

    /**
     * Accessor for property regListingCode.
     * 
     * @return regListingCode of type String
     */
    private String getRegListingCode() {
        if (this.getClientCountryType != null && this.getClientCountryType.getCompany() != null &&
                this.getClientCountryType.getCompany().getRegListing() != null) {
            return this.getClientCountryType.getCompany().getRegListing().getCode();
        }
        return "";
    }

    /**
     * Does this.
     * 
     * @param countryNameType
     */
    private void setDefaultValues(CountryNameType countryNameType) {
        countryNameType.setTfn("");
        countryNameType.setTfnExemptioncodetype("");
        countryNameType.setTfnExemptioncode("");
        countryNameType.setTfnExemptionreason("");
        countryNameType.setTfnSupertickstatus("");
        countryNameType.setTfnSupertickdate("");
        countryNameType.setAmlctfRiskcodetype("");
        countryNameType.setAmlctfRiskcode("");
        countryNameType.setAmlClasstypecode("");
        countryNameType.setAmlClasscode("");
        countryNameType.setAmlNote("");
        Company company = new Company();
        this.setDefaultCompanyValues(company);
        countryNameType.setCompany(company);
    }

    private void setDefaultCompanyValues(Company company) {
        company.setAbn("");
        company.setAcnArbn("");
        company.setSpin("");
        company.setRegListingCodeType("");
        company.setRegListingCode("");
    }
}
