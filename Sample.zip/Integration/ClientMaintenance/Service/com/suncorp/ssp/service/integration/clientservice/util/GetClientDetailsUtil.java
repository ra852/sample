////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package com.suncorp.ssp.service.integration.clientservice.util;

import java.util.ArrayList;
import java.util.List;

import org.apache.xerces.dom.ElementNSImpl;
import org.apache.xerces.dom.TextImpl;

import com.sonatacentral.service.v30.common.client.GetClientResponseType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.NoteCategoryIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.NoteTemplateIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.NoteType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.OccupationIdentifierType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.clientservice.ClientServiceConstants;
import com.suncorp.ssp.service.integration.clientservice.bean.AustraliaDetails;
import com.suncorp.ssp.service.integration.clientservice.bean.ClientAddressType;
import com.suncorp.ssp.service.integration.clientservice.bean.ClientAdvisorDetailType;
import com.suncorp.ssp.service.integration.clientservice.bean.ClientBankDetailType;
import com.suncorp.ssp.service.integration.clientservice.bean.ClientContextDetailType;
import com.suncorp.ssp.service.integration.clientservice.bean.ClientWorkDeclarationType;
import com.suncorp.ssp.service.integration.clientservice.bean.CodeIdentifier;
import com.suncorp.ssp.service.integration.clientservice.bean.CountryNameType;
import com.suncorp.ssp.service.integration.clientservice.bean.ExternalReferenceDetailType;
import com.suncorp.ssp.service.integration.clientservice.bean.GetClientResponse;
import com.suncorp.ssp.service.integration.clientservice.bean.NoteBean;
import com.suncorp.ssp.service.integration.clientservice.bean.NoteCategoryBean;
import com.suncorp.ssp.service.integration.clientservice.bean.NoteTemplateBean;
import com.suncorp.ssp.service.integration.clientservice.bean.OccupationIdentifierBean;
import com.suncorp.ssp.service.integration.clientservice.bean.TfnConsentDetailsType;

/**
 * The class {@code GetClientDetailsUtil} is a Utility class with all the properties related to client details, to construct response for end client
 * by extracting values from the external service's response object.
 * 
 * @author U383754
 * @since 2015-10-01
 * @version 1.0
 */
public class GetClientDetailsUtil {
    private GetClientResponseType getClientResponseType;

    /**
     * Parameterized constructor for properties initialization.
     * 
     * @param getClientResponseType of type GetClientResponseType
     */
    public GetClientDetailsUtil(GetClientResponseType getClientResponseType) {
        this.getClientResponseType = getClientResponseType;
    }

    /**
     * Extracts values from the external service's response and maps to end client response.
     * 
     * @param getClientResponse of type GetClientResponse
     * @throws SILException
     */
    public void setClientResponse(GetClientResponse getClientResponse) throws SILException {
        if (this.getClientResponseType != null) {
            getClientResponse.setClientId(this.getClientId());
            getClientResponse.setTitle(this.getTitle());
            getClientResponse.setGender(this.getGender());
            getClientResponse.setMaritalStatus(this.getMaritalStatus());
            getClientResponse.setFirstName(this.getFirstName());
            getClientResponse.setMiddleName(this.getMiddleName());
            getClientResponse.setLastName(this.getLastName());
            getClientResponse.setDateOfBirth(this.getDateOfBirth());
            if (this.getClientResponseType.getClientDetails() != null && this.getClientResponseType.getClientDetails().getOccupation() != null) {
                getClientResponse.setOccupation(this.getOccupation(this.getClientResponseType.getClientDetails().getOccupation()));
            } else {
                getClientResponse.setOccupation(this.getEmptyOccupation());
            }
            getClientResponse.setMobileNumber(this.getMobileNumber());
            getClientResponse.setClientTfn(this.getClientTfn());
            setClientResponseRemaining(getClientResponse);
        }
    }

    /**
     * Extracts values from the external service's response and maps to end client response.
     * 
     * @param getClientResponse of type GetClientResponse
     * @throws SILException
     */
    private void setClientResponseRemaining(GetClientResponse getClientResponse) throws SILException {
        getClientResponse.setHomeNumber(this.getHomeNumber());
        getClientResponse.setWorkNumber(this.getWorkNumber());
        getClientResponse.setBankDetails(this.getBankDetails());
        getClientResponse.setAddressDetails(this.getAddressDetails());
        getClientResponse.setAdvisorDetails(this.getAdvisorDetails());
        getClientResponse.setClientContextDetails(this.getClientContextDetails());
        getClientResponse.setWorkDeclarationDetails(this.getWorkDeclarationDetails());
        getClientResponse.setTfnConsentDetails(this.getTfnConsentDetails());
        getClientResponse.setCountryName(this.getCountryName());
        getClientResponse.setExternalReferenceTypeDetails(this.getExternalReferenceTypeDetails());
        getClientResponse.setContactName(this.getContactName());
        getClientResponse.setClientType(this.getClientTypeDetails());
        getClientResponse.setNotes(this.retrieveNotesList());
        getClientResponse.setPreferredRisk(this.getPreferredRisk());
        getClientResponse.setAustralia(retrieveAustraliaDetails());
    }

    /**
     * This method is used to retrieve Australia details.
     * 
     * @return
     */
    private AustraliaDetails retrieveAustraliaDetails() {
        AustraliaDetails australiaDetails = new AustraliaDetails();
        if (this.getClientResponseType.getAustralia() != null) {
            retrieveDateOfLastContact(australiaDetails);
        }
        return australiaDetails;
    }

    /**
     * This method is used to retrieve date of last contact.
     * 
     * @param australiaDetails
     */
    private void retrieveDateOfLastContact(AustraliaDetails australiaDetails) {
        String dateOfLastContact = null;
        ElementNSImpl elementImpl = (ElementNSImpl) this.getClientResponseType.getAustralia().getDateOfLastContact();
        if (elementImpl != null && elementImpl.getFirstChild() != null) {
            TextImpl textImpl = (TextImpl) elementImpl.getFirstChild();
            dateOfLastContact = textImpl.getData();
        }
        if (dateOfLastContact != null) {
            australiaDetails.setDateOfLastContact(dateOfLastContact);
        } else {
            australiaDetails.setDateOfLastContact("");
        }
    }

    /**
     * This method is used to get Preffered Risk.
     * 
     * @return
     */
    private CodeIdentifier getPreferredRisk() {
        SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "GetClientDetailsUtil", "Entering getPreferredRisk()");
        CodeIdentifier pIdentifier = new CodeIdentifier();
        if (this.getClientResponseType.getClientDetails() != null && this.getClientResponseType.getClientDetails().getPreferredRisk() != null) {
            PreferredRiskUtil util = new PreferredRiskUtil(this.getClientResponseType.getClientDetails().getPreferredRisk());
            util.createPrefferedRisk(pIdentifier);
        } else {
            new PreferredRiskUtil().setDefaultPreferredRisk(pIdentifier);
        }
        SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "GetClientDetailsUtil", "Exiting getPreferredRisk()");
        return pIdentifier;
    }

    /**
     * Returns Client Contact Name, if exists.
     * 
     * @return object of type String
     */
    private String getContactName() {
        if (this.getClientResponseType.getClientDetails() != null && this.getClientResponseType.getClientDetails().getContactName() != null) {
            return this.getClientResponseType.getClientDetails().getContactName();
        }
        return "";
    }

    /**
     * This method is used to get all external references.
     * 
     * @return the list of external references
     */
    private List<ExternalReferenceDetailType> getExternalReferenceTypeDetails() {
        SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "GetClientDetailsUtil", "Entering getExternalReferenceTypeDetails()");
        List<ExternalReferenceDetailType> externalReferenceDetails = new ArrayList<ExternalReferenceDetailType>();
        ExternalReferenceDetailsUtil externalReferenceDetailsUtil = new ExternalReferenceDetailsUtil(this.getClientResponseType);
        externalReferenceDetailsUtil.getExternalReferenceDetails(externalReferenceDetails);
        SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "GetClientDetailsUtil", "Exiting getExternalReferenceTypeDetails()");
        return externalReferenceDetails;
    }

    /**
     * This method is used to get the details of the country.
     * 
     * @return the object of country type which contains details of country
     */
    private CountryNameType getCountryName() {
        SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "GetClientDetailsUtil", "Entering in getCountryName.");
        CountryNameType countryNameType = new CountryNameType();
        CountryNameUtil countryNameUtil = new CountryNameUtil(this.getClientResponseType);
        countryNameUtil.getCountryInfo(countryNameType);
        SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "GetClientDetailsUtil", "Exiting in getCountryName.");
        return countryNameType;
    }

    /**
     * This method is used to get all the work declaration of the client.
     * 
     * @return list of work declaration type of client
     */
    private List<ClientWorkDeclarationType> getWorkDeclarationDetails() {
        SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "GetClientDetailsUtil", "Entering in getWorkDeclarationDetails.");
        List<ClientWorkDeclarationType> workDeclarationDetails = new ArrayList<ClientWorkDeclarationType>();
        WorkDeclarationDetailsUtil workDeclarationDetailsUtil = new WorkDeclarationDetailsUtil(this.getClientResponseType);
        workDeclarationDetailsUtil.getWorkDeclarationDetails(workDeclarationDetails);
        SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "GetClientDetailsUtil", "Exiting in getWorkDeclarationDetails.");
        return workDeclarationDetails;
    }

    /**
     * This method is used to get all context details of client.
     * 
     * @return the type of context detail of client
     */
    private List<ClientContextDetailType> getClientContextDetails() {
        SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "GetClientDetailsUtil", "Entering in getClientContextDetails.");
        List<ClientContextDetailType> contextDetails = new ArrayList<ClientContextDetailType>();
        ContextDetailsUtil contextDetailsUtil = new ContextDetailsUtil(this.getClientResponseType);
        contextDetailsUtil.getContextDetails(contextDetails);
        SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "GetClientDetailsUtil", "Exiting in getClientContextDetails.");
        return contextDetails;
    }

    /**
     * This method is used to get details of all advisor's.
     * 
     * @return the list of all advisor details
     */
    private List<ClientAdvisorDetailType> getAdvisorDetails() {
        SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "GetClientDetailsUtil", "Entering in getAdvisorDetails.");
        List<ClientAdvisorDetailType> advisorDetails = new ArrayList<ClientAdvisorDetailType>();
        AdvisorDetailsUtil advisorDetailsUtil = new AdvisorDetailsUtil(this.getClientResponseType);
        advisorDetailsUtil.getAdvisorDetails(advisorDetails);
        SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "GetClientDetailsUtil", "Exiting in getAdvisorDetails.");
        return advisorDetails;
    }

    /**
     * This method is used to get list of address of client.
     * 
     * @return the list of client address
     */
    private List<ClientAddressType> getAddressDetails() {
        SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "GetClientDetailsUtil", "Entering in getAddressDetails.");
        List<ClientAddressType> addressDetails = new ArrayList<ClientAddressType>();
        AddressDetailsUtil addressDetailsUtil = new AddressDetailsUtil(this.getClientResponseType);
        addressDetailsUtil.getAddressDetails(addressDetails);
        SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "GetClientDetailsUtil", "Exiting in getAddressDetails.");
        return addressDetails;
    }

    /**
     * This method is used to get All bank details of client
     * 
     * @return list of bank details
     */
    private List<ClientBankDetailType> getBankDetails() {
        SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "GetClientDetailsUtil", "Entering in getBankDetails.");
        List<ClientBankDetailType> bankDetails = new ArrayList<ClientBankDetailType>();
        BankDetailsUtil bankDetailsUtil = new BankDetailsUtil(this.getClientResponseType);
        bankDetailsUtil.getBankDetails(bankDetails);
        SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "GetClientDetailsUtil", "Exiting in getBankDetails.");
        return bankDetails;
    }

    /**
     * This method is used to get Marital status of client
     * 
     * @return the marital status of client
     */
    private String getMaritalStatus() {
        if (this.getClientResponseType.getClientDetails() != null &&
                this.getClientResponseType.getClientDetails().getMaritalStatus() != null &&
                this.getClientResponseType.getClientDetails().getMaritalStatus().getCodeType()
                        .equalsIgnoreCase(ClientServiceConstants.MARITAL_STATUS)) {
            return this.getClientResponseType.getClientDetails().getMaritalStatus().getCode();
        }
        return "";
    }

    /**
     * Returns Gender of client.
     * 
     * @return gender of type String
     */
    private String getGender() {
        if (this.getClientResponseType.getClientDetails() != null && this.getClientResponseType.getClientDetails().getGender() != null &&
                this.getClientResponseType.getClientDetails().getGender().getCodeType().equalsIgnoreCase(ClientServiceConstants.SEX)) {
            return this.getClientResponseType.getClientDetails().getGender().getCode();
        }
        return "";
    }

    /**
     * Returns Client ID, if exists.
     * 
     * @return clientId of type String
     */
    private String getClientId() {
        if (this.getClientResponseType.getClient() != null && this.getClientResponseType.getClient().getId() != null) {
            return this.getClientResponseType.getClient().getId().toString();
        }
        return "";
    }

    /**
     * Returns Client work number, if exists.
     * 
     * @return object of type String
     */
    private String getWorkNumber() {
        if (this.getClientResponseType.getClientDetails() != null && this.getClientResponseType.getClientDetails().getBusinessPhone() != null) {
            return this.getClientResponseType.getClientDetails().getBusinessPhone();
        }
        return "";
    }

    /**
     * Returns Client home number, if exists.
     * 
     * @return object of type String
     */
    private String getHomeNumber() {
        if (this.getClientResponseType.getClientDetails() != null && this.getClientResponseType.getClientDetails().getHomePhone() != null) {
            return this.getClientResponseType.getClientDetails().getHomePhone();
        }
        return "";
    }

    /**
     * Set default value in occupation detail.
     * 
     * @return occupationIdentifierBean
     */
    private OccupationIdentifierBean getEmptyOccupation() {
        OccupationIdentifierBean occupationIdentifierBean = new OccupationIdentifierBean();
        occupationIdentifierBean.setCode("");
        occupationIdentifierBean.setId("");
        occupationIdentifierBean.setName("");
        return occupationIdentifierBean;
    }

    /**
     * Extracts values from the external service's response and maps to end client response.
     * 
     * @param occupationIdentifierType
     * 
     * @return occupationIdentifierBean
     */
    private OccupationIdentifierBean getOccupation(OccupationIdentifierType occupationIdentifierType) {
        OccupationIdentifierBean occupationIdentifierBean = new OccupationIdentifierBean();
        if (occupationIdentifierType.getCode() != null) {
            occupationIdentifierBean.setCode(occupationIdentifierType.getCode());
        } else {
            occupationIdentifierBean.setCode("");
        }
        if (occupationIdentifierType.getId() != null) {
            occupationIdentifierBean.setId(occupationIdentifierType.getId().toString());
        } else {
            occupationIdentifierBean.setId("");
        }
        if (occupationIdentifierType.getName() != null) {
            occupationIdentifierBean.setName(occupationIdentifierType.getName());
        } else {
            occupationIdentifierBean.setName("");
        }
        return occupationIdentifierBean;
    }

    /**
     * Returns Client mobile number, if exists.
     * 
     * @return object of type String
     */
    private String getMobileNumber() {
        if (this.getClientResponseType.getClientDetails() != null && this.getClientResponseType.getClientDetails().getMobilePhone() != null) {
            return this.getClientResponseType.getClientDetails().getMobilePhone();
        }
        return "";
    }

    /**
     * Returns Client DOB, if exists.
     * 
     * @return object of type String
     * @throws SILException
     */
    private String getDateOfBirth() throws SILException {
        if (this.getClientResponseType.getClientDetails() != null && this.getClientResponseType.getClientDetails().getDateOfBirth() != null) {
            return SILUtil.convertXMLGregorianCalendartoString(this.getClientResponseType.getClientDetails().getDateOfBirth(),
                    CommonConstants.DATE_FORMAT_DDMMYYYY);
        }
        return "";
    }

    /**
     * Returns Client last name, if exists.
     * 
     * @return object of type String
     */
    private String getLastName() {
        if (this.getClientResponseType.getClientDetails() != null && this.getClientResponseType.getClientDetails().getSurname() != null) {
            return this.getClientResponseType.getClientDetails().getSurname();
        }
        return "";
    }

    /**
     * Returns Client middle name, if exists.
     * 
     * @return object of type String
     */
    private String getMiddleName() {
        if (this.getClientResponseType.getClientDetails() != null && this.getClientResponseType.getClientDetails().getForename2() != null) {
            return this.getClientResponseType.getClientDetails().getForename2();
        }
        return "";
    }

    /**
     * Returns Client first name, if exists.
     * 
     * @return object of type String
     */
    private String getFirstName() {
        if (this.getClientResponseType.getClientDetails() != null && this.getClientResponseType.getClientDetails().getForename() != null) {
            return this.getClientResponseType.getClientDetails().getForename();
        }
        return "";
    }

    /**
     * Returns Client title, if exists.
     * 
     * @return object of type String
     */
    private String getTitle() {
        if (this.getClientResponseType.getClientDetails() != null &&
                this.getClientResponseType.getClientDetails().getTitle() != null &&
                this.getClientResponseType.getClientDetails().getTitle().getCodeType()
                        .equalsIgnoreCase(ClientServiceConstants.CLIENT_TITLE_CODE_TYPE)) {
            return this.getClientResponseType.getClientDetails().getTitle().getCode();
        }
        return "";
    }

    /**
     * Returns Client title, if exists.
     * 
     * @return object of type String
     */
    private TfnConsentDetailsType getTfnConsentDetails() {
        TfnConsentDetailsType tfnConsentDetailsType = new TfnConsentDetailsType();
        TfnConsentDetailsUtil tfnConsentDetailsUtil = new TfnConsentDetailsUtil(getClientResponseType);
        tfnConsentDetailsUtil.setTfnConsentDetails(tfnConsentDetailsType);
        return tfnConsentDetailsType;

    }

    /**
     * Get Client Type Details.
     * 
     * @return object of CodeIdentifier
     * @throws SILException
     */
    private CodeIdentifier getClientTypeDetails() throws SILException {
        SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "GetClientDetailsUtil", "Entering getClientTypeDetails()");
        if (this.getClientResponseType.getClientDetails() != null && this.getClientResponseType.getClientDetails().getTypeCode() != null) {
            return new ClientServiceUtil().getCodeIdentifierDetails(this.getClientResponseType.getClientDetails().getTypeCode(),
                    ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT);
        } else {
            return new ClientServiceUtil().getDefaultCodeIdentifierDetails(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT);
        }
    }

    /**
     * 
     * This method constructs NotesList Details List object from response.
     * 
     * @return
     * @throws SILException
     */
    public List<NoteBean> retrieveNotesList() throws SILException {
        List<NoteBean> notes = new ArrayList<NoteBean>();
        List<NoteType> noteTypes = this.getClientResponseType.getNote();
        if (noteTypes != null && noteTypes.size() > 0) {
            SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "GetClientDetailsUtil", "Entering in retrieveNotesLst method");
            for (NoteType noteType : noteTypes) {
                if (noteType != null) {
                    notes.add(retrieveNotesDetails(noteType, ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT));
                }
            }
        }
        return notes;
    }

    /**
     * This method is used to retrieve notes details.
     * 
     * @param noteType
     * @param getAccDetailsListLoggingFormat
     * @return
     * @throws SILException
     */
    public NoteBean retrieveNotesDetails(NoteType noteType, String loggerType) throws SILException {
        SILLogger.debug(loggerType, "GetClientDetailsUtil", "Entering retrieveNotesDetails()");
        NoteBean noteBean = new NoteBean();
        if (noteType != null) {
            noteBean.setId(String.valueOf(noteType.getId()));
            noteBean.setNote(noteType.getNote());
            noteBean.setEffectiveDate(new ClientServiceUtil().retrieveDateValue(noteType.getEffectiveDate(), loggerType));
            noteBean.setNoteTemplate(retrieveNoteTemplate(noteType.getNoteTemplate(), loggerType));
        } else {
            noteBean = retrieveEmptyNotesDetails(loggerType);
        }
        return noteBean;
    }

    /**
     * This method is used to get Notes template.
     * 
     * @param noteTemplate
     * @return
     * @throws SILException
     */
    private NoteTemplateBean retrieveNoteTemplate(NoteTemplateIdentifierType noteTemplate, String loggerType) throws SILException {
        SILLogger.debug(loggerType, "GetClientDetailsUtil", "Entering retrieveNoteTemplate()");
        NoteTemplateBean noteTemplateBean = new NoteTemplateBean();
        noteTemplateBean.setId(String.valueOf(noteTemplate.getId()));
        noteTemplateBean.setName(noteTemplate.getName());
        noteTemplateBean.setCode(noteTemplate.getCode());
        noteTemplateBean.setWarning(String.valueOf(noteTemplate.isWarning()));
        noteTemplateBean.setNoteCategory(retriveCategoryDetails(noteTemplate.getNoteCategory(), loggerType));
        noteTemplateBean.setAudit(new ClientServiceUtil().retrieveAudit(noteTemplate.getAudit(), loggerType));
        return noteTemplateBean;
    }

    /**
     * This method is used to get category details.
     * 
     * @param noteCategory
     * @param loggerType
     * @return
     * @throws SILException
     */
    private NoteCategoryBean retriveCategoryDetails(NoteCategoryIdentifierType noteCategory, String loggerType) throws SILException {
        SILLogger.debug(loggerType, "GetClientDetailsUtil", "Entering retriveCategoryDetails()");
        NoteCategoryBean noteCategoryBean = new NoteCategoryBean();
        noteCategoryBean.setId(String.valueOf(noteCategory.getId()));
        noteCategoryBean.setName(noteCategory.getName());
        noteCategoryBean.setCode(noteCategory.getCode());
        noteCategoryBean.setAudit(new ClientServiceUtil().retrieveAudit(noteCategory.getAudit(), loggerType));
        return noteCategoryBean;
    }

    /**
     * This method is used to retrieve notes details.
     * 
     * @param loggerType
     * @return
     * @throws SILException
     */
    private NoteBean retrieveEmptyNotesDetails(String loggerType) throws SILException {
        SILLogger.debug(loggerType, "GetClientDetailsUtil", "Entering retrieveEmptyNotesDetails()");
        NoteBean noteBean = new NoteBean();
        noteBean.setId("");
        noteBean.setNote("");
        noteBean.setEffectiveDate("");
        noteBean.setNoteTemplate(retrieveEmptyNoteTemplate(loggerType));
        return null;
    }

    /**
     * This method is used to retrieve Empty Template.
     * 
     * @param loggerType
     * @return
     * @throws SILException
     */
    private NoteTemplateBean retrieveEmptyNoteTemplate(String loggerType) throws SILException {
        SILLogger.debug(loggerType, "GetClientDetailsUtil", "Entering retrieveNoteTemplate()");
        NoteTemplateBean noteTemplateBean = new NoteTemplateBean();
        noteTemplateBean.setId(String.valueOf(""));
        noteTemplateBean.setName("");
        noteTemplateBean.setCode("");
        noteTemplateBean.setWarning("");
        noteTemplateBean.setNoteCategory(retriveEmptyCategoryDetails(loggerType));
        noteTemplateBean.setAudit(new ClientServiceUtil().retrieveAudit(null, loggerType));
        return noteTemplateBean;
    }

    /**
     * This method is used to retrieve Empty category details.
     * 
     * @param loggerType
     * @return
     * @throws SILException
     */
    private NoteCategoryBean retriveEmptyCategoryDetails(String loggerType) throws SILException {
        SILLogger.debug(loggerType, "GetClientDetailsUtil", "Entering retriveCategoryDetails()");
        NoteCategoryBean noteCategoryBean = new NoteCategoryBean();
        noteCategoryBean.setId("");
        noteCategoryBean.setName("");
        noteCategoryBean.setCode("");
        noteCategoryBean.setAudit(new ClientServiceUtil().retrieveAudit(null, loggerType));
        return noteCategoryBean;
    }

    /**
     * 
     * This method is used to retrieve Client TFN.
     * 
     * @return
     */
    private String getClientTfn() {
        if (this.getClientResponseType.getClient() != null && this.getClientResponseType.getClient().getClientTFN() != null) {
            return this.getClientResponseType.getClient().getClientTFN();
        }
        return "";
    }
}
