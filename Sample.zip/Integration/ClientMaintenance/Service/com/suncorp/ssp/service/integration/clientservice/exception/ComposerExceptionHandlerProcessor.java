////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.clientservice.exception;

import javax.ws.rs.core.Response;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.clientservice.ClientServiceConstants;
import com.suncorp.ssp.service.integration.clientservice.bean.ErrorBean;
import com.suncorp.ssp.service.integration.clientservice.bean.GetCustomerByProductDetails;
import com.suncorp.ssp.service.integration.clientservice.util.ClientServiceUtil;

/**
 * The class {@code ComposerExceptionHandlerProcessor} is a exception handler.
 * 
 * @author U385424
 * @since 02/11/2016
 * @version 1.0
 */
public class ComposerExceptionHandlerProcessor implements Processor {
    private final String className = "ComposerExceptionHandlerProcessor";

    /**
     * This method is check whether soap fault coming from Sonata or not. If any soap fault there, just throwing the Sonata exception.
     * 
     * @param the object of exchange message
     */
    public void process(Exchange exchange) throws SILException {
        SILLogger.debug(ClientServiceConstants.GET_CUSTOMER_BY_PRODUCT_LOGGING_FORMAT, className, "Entering process()");
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, "ExceptionHandlerProcessor", "Entering in process method");
        String sonataResponse = (String) exchange.getIn().getBody();
        checkFaultMessage(sonataResponse, exchange);
        SILLogger.debug(ClientServiceConstants.GET_CUSTOMER_BY_PRODUCT_LOGGING_FORMAT, className, "Exiting process()");
    }

    /**
     * This method will check fault code fault string and will throw SILException with error message came from external system.
     * 
     * @param body
     * @param exchange
     * @throws Exception
     */
    private void checkFaultMessage(String body, Exchange exchange) throws SILException {
        if (body.indexOf("Fault") != -1 && body.indexOf("<faultcode>") != -1 && body.indexOf("<faultstring>") != -1) {
            SILLogger.debug(ClientServiceConstants.GET_CUSTOMER_BY_PRODUCT_LOGGING_FORMAT, className, "Entering checkFaultMessage()");
            ClientServiceUtil clientServiceUtil = new ClientServiceUtil();
            clientServiceUtil.setErrorResponse(exchange, ClientServiceConstants.ERROR_CODE_MEMBER_NOT_FOUND,
                    ClientServiceConstants.DESCRIPTION_MEMBER_NOT_FOUND);
        } else {
            exchange.setProperty("callComposerForEmployerService", "N");
        }
    }

    /**
     * this method is used to check response from composer.
     * 
     * @param body
     * @param exchange
     * @throws SILException
     */
    public void composerExceptionHandler(String body, Exchange exchange) throws SILException {
        if (body.indexOf("Fault") != -1 && body.indexOf("<faultcode>") != -1 && body.indexOf("</faultstring>") != -1) {
            SILLogger.debug(ClientServiceConstants.GET_CUSTOMER_BY_PRODUCT_LOGGING_FORMAT, className, "Entering composerExceptionHandler()");
            GetCustomerByProductDetails customerByProductDetails = new GetCustomerByProductDetails();
            ErrorBean bean = new ErrorBean();
            bean.setCode(ClientServiceConstants.ERROR_CODE_MEMBER_NOT_FOUND);
            bean.setSeverity(ClientServiceConstants.ERROR_SEVERITY_SYSTEM_ERROR);
            bean.setDescription(ClientServiceConstants.DESCRIPTION_MEMBER_NOT_FOUND);
            customerByProductDetails.setError(bean);
            Response response = Response.status(Response.Status.OK).entity(customerByProductDetails).build();
            exchange.getIn().setBody(response);
        } else {
            exchange.setProperty("exceptionInResponse", "N");
        }
    }

    /**
     * This method is used to set error response for invalid entityType.
     * 
     * @param body
     * @param exchange
     * @throws SILException
     */
    public void invalidEntityType(String body, Exchange exchange) throws SILException {
        SILLogger.debug(ClientServiceConstants.GET_CUSTOMER_BY_PRODUCT_LOGGING_FORMAT, className, "Entering invalidEntityType()");
        GetCustomerByProductDetails customerByProductDetails = new GetCustomerByProductDetails();
        ErrorBean bean = new ErrorBean();
        bean.setCode(ClientServiceConstants.ERROR_CODE_ENTITY_TYPE_NOT_SUPPORTED);
        bean.setSeverity(ClientServiceConstants.ERROR_SEVERITY_SYSTEM_ERROR);
        bean.setDescription(ClientServiceConstants.DESCRIPTION_ENTITY_TYPE_NOT_SUPPORTED);
        customerByProductDetails.setError(bean);
        Response response = Response.status(Response.Status.OK).entity(customerByProductDetails).build();
        exchange.getIn().setBody(response);
    }

    /**
     * This method is used to set error response.
     * 
     * @param exchange
     * 
     */
    public void setErrorResponse(Exchange exchange) {
        GetCustomerByProductDetails getCustomerByProductDetails = new GetCustomerByProductDetails();
        ErrorBean errorBean = new ErrorBean();
        errorBean.setCode(ClientServiceConstants.ERROR_CODE_GENERIC);
        errorBean.setSeverity(ClientServiceConstants.ERROR_SEVERITY_BUSINESS_ERROR);
        errorBean.setDescription(ClientServiceConstants.DESCRIPTION_GENERIC_MESSAGE);
        getCustomerByProductDetails.setError(errorBean);
        Response response = Response.status(Response.Status.OK).entity(getCustomerByProductDetails).build();
        exchange.getIn().setBody(response);
    }

    /**
     * This method is used to set error response.
     * 
     * @param exchange
     * 
     */
    public void setMemberNotFound(Exchange exchange) {
        ClientServiceUtil clientServiceUtil = new ClientServiceUtil();
        clientServiceUtil.setErrorResponse(exchange, ClientServiceConstants.ERROR_CODE_MEMBER_NOT_FOUND,
                ClientServiceConstants.DESCRIPTION_MEMBER_NOT_FOUND);
    }
}
