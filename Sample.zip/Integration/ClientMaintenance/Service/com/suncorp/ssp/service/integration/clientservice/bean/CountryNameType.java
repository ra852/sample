////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.clientservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code CountryNameType} is a java bean consisting of properties related to client tfn, supertick, aml and company details.
 * 
 * @author U383754
 * @since 23/10/2015
 * @version 1.0
 */
public class CountryNameType {
    private String tfn;
    private String tfnExemptioncodetype;
    private String tfnExemptioncode;
    private String tfnExemptionreason;
    private String tfnSupertickstatus;
    private String tfnSupertickdate;
    private String amlctfRiskcodetype;
    private String amlctfRiskcode;
    private String amlClasstypecode;
    private String amlClasscode;
    private String amlNoteTemplateCode;
    private String amlNoteCategoryCode;
    private String amlNoteEffectiveDate;
    private String amlNote;
    private String operation;
    private Company company;
    private String superTickStatusCodeType;

    /**
     * Accessor for property tfn.
     * 
     * @return tfn of type String
     */
    public String getTfn() {
        return tfn;
    }

    /**
     * Mutator for property tfn.
     * 
     * @param tfn of type String
     */
    @XmlElement(name = "tfn")
    public void setTfn(String tfn) {
        this.tfn = tfn;
    }

    /**
     * Accessor for property tfnExemptioncodetype.
     * 
     * @return tfnExemptioncodetype of type String
     */
    public String getTfnExemptioncodetype() {
        return tfnExemptioncodetype;
    }

    /**
     * Mutator for property tfnExemptioncodetype.
     * 
     * @param tfnExemptioncodetype of type String
     */
    @XmlElement(name = "tfnExemptioncodetype")
    public void setTfnExemptioncodetype(String tfnExemptioncodetype) {
        this.tfnExemptioncodetype = tfnExemptioncodetype != null ? tfnExemptioncodetype : "";
    }

    /**
     * Accessor for property tfnExemptioncode.
     * 
     * @return tfnExemptioncode of type String
     */
    public String getTfnExemptioncode() {
        return tfnExemptioncode;
    }

    /**
     * Mutator for property tfnExemptioncode.
     * 
     * @param tfnExemptioncode of type String
     */
    @XmlElement(name = "tfnExemptioncode")
    public void setTfnExemptioncode(String tfnExemptioncode) {
        this.tfnExemptioncode = tfnExemptioncode != null ? tfnExemptioncode : "";
    }

    /**
     * Accessor for property tfnExemptionreason.
     * 
     * @return tfnExemptionreason of type String
     */
    public String getTfnExemptionreason() {
        return tfnExemptionreason;
    }

    /**
     * Mutator for property tfnExemptionreason.
     * 
     * @param tfnExemptionreason of type String
     */
    @XmlElement(name = "tfnExemptionreason")
    public void setTfnExemptionreason(String tfnExemptionreason) {
        this.tfnExemptionreason = tfnExemptionreason != null ? tfnExemptionreason : "";
    }

    /**
     * Accessor for property tfnSupertickstatus.
     * 
     * @return tfnSupertickstatus of type String
     */
    public String getTfnSupertickstatus() {
        return tfnSupertickstatus;
    }

    /**
     * Mutator for property tfnSupertickstatus.
     * 
     * @param tfnSupertickstatus of type String
     */
    @XmlElement(name = "tfnSupertickstatus")
    public void setTfnSupertickstatus(String tfnSupertickstatus) {
        this.tfnSupertickstatus = tfnSupertickstatus != null ? tfnSupertickstatus : "";
    }

    /**
     * Accessor for property tfnSupertickdate.
     * 
     * @return tfnSupertickdate of type String
     */
    public String getTfnSupertickdate() {
        return tfnSupertickdate;
    }

    /**
     * Mutator for property tfnSupertickdate.
     * 
     * @param tfnSupertickdate of type String
     */
    @XmlElement(name = "tfnSupertickdate")
    public void setTfnSupertickdate(String tfnSupertickdate) {
        this.tfnSupertickdate = tfnSupertickdate != null ? tfnSupertickdate : "";
    }

    /**
     * Accessor for property amlctfRiskcodetype.
     * 
     * @return amlctfRiskcodetype of type String
     */
    public String getAmlctfRiskcodetype() {
        return amlctfRiskcodetype;
    }

    /**
     * Mutator for property amlctfRiskcodetype.
     * 
     * @return amlctfRiskcodetype of type String
     */
    @XmlElement(name = "amlctfRiskcodetype")
    public void setAmlctfRiskcodetype(String amlctfRiskcodetype) {
        this.amlctfRiskcodetype = amlctfRiskcodetype != null ? amlctfRiskcodetype : "";
    }

    /**
     * Accessor for property amlctfRiskcode.
     * 
     * @param amlctfRiskcode of type String
     */
    public String getAmlctfRiskcode() {
        return amlctfRiskcode;
    }

    /**
     * Mutator for property amlctfRiskcode.
     * 
     * @return amlctfRiskcode of type String
     */
    @XmlElement(name = "amlctfRiskcode")
    public void setAmlctfRiskcode(String amlctfRiskcode) {
        this.amlctfRiskcode = amlctfRiskcode != null ? amlctfRiskcode : "";
    }

    /**
     * Accessor for property amlClasstypecode.
     * 
     * @return amlClasstypecode of type String
     */
    public String getAmlClasstypecode() {
        return amlClasstypecode;
    }

    /**
     * Mutator for property amlClasstypecode.
     * 
     * @param amlClasstypecode of type String
     */
    @XmlElement(name = "amlClasstypecode")
    public void setAmlClasstypecode(String amlClasstypecode) {
        this.amlClasstypecode = amlClasstypecode != null ? amlClasstypecode : "";
    }

    /**
     * Accessor for property amlClasscode.
     * 
     * @return amlClasscode of type String
     */
    public String getAmlClasscode() {
        return amlClasscode;
    }

    /**
     * Mutator for property amlClasscode.
     * 
     * @param amlClasscode of type String
     */
    @XmlElement(name = "amlClasscode")
    public void setAmlClasscode(String amlClasscode) {
        this.amlClasscode = amlClasscode != null ? amlClasscode : "";
    }

    /**
     * Accessor for property amlNoteTemplateCode.
     * 
     * @return amlNoteTemplateCode of type String
     */
    public String getAmlNoteTemplateCode() {
        return amlNoteTemplateCode;
    }

    /**
     * Mutator for property amlNoteTemplateCode.
     * 
     * @param amlNoteTemplateCode of type String
     */
    @XmlElement(name = "amlNoteTemplateCode")
    public void setAmlNoteTemplateCode(String amlNoteTemplateCode) {
        this.amlNoteTemplateCode = amlNoteTemplateCode != null ? amlNoteTemplateCode : "";
    }

    /**
     * Accessor for property amlNoteCategoryCode.
     * 
     * @return amlNoteCategoryCode of type String
     */
    public String getAmlNoteCategoryCode() {
        return amlNoteCategoryCode;
    }

    /**
     * Mutator for property amlNoteCategoryCode.
     * 
     * @param amlNoteCategoryCode of type String
     */
    @XmlElement(name = "amlNoteCategoryCode")
    public void setAmlNoteCategoryCode(String amlNoteCategoryCode) {
        this.amlNoteCategoryCode = amlNoteCategoryCode != null ? amlNoteCategoryCode : "";
    }

    /**
     * Accessor for property amlNoteEffectiveDate.
     * 
     * @return amlNoteEffectiveDate of type String
     */
    public String getAmlNoteEffectiveDate() {
        return amlNoteEffectiveDate;
    }

    /**
     * Mutator for property amlNoteEffectiveDate.
     * 
     * @param amlNoteEffectiveDate of type String
     */
    @XmlElement(name = "amlNoteEffectiveDate")
    public void setAmlNoteEffectiveDate(String amlNoteEffectiveDate) {
        this.amlNoteEffectiveDate = amlNoteEffectiveDate != null ? amlNoteEffectiveDate : "";
    }

    /**
     * Accessor for property amlNote.
     * 
     * @return amlNote of type String
     */
    public String getAmlNote() {
        return amlNote;
    }

    /**
     * Mutator for property amlNote.
     * 
     * @param amlNote of type String
     */
    @XmlElement(name = "amlNote")
    public void setAmlNote(String amlNote) {
        this.amlNote = amlNote != null ? amlNote : "";
    }

    /**
     * Accessor for property operation.
     * 
     * @return operation of type String
     */
    public String getOperation() {
        return operation;
    }

    /**
     * Mutator for property operation.
     * 
     * @param operation of type String
     */
    @XmlElement(name = "operation")
    public void setOperation(String operation) {
        this.operation = operation != null ? operation : "";
    }

    /**
     * Accessor for property company.
     * 
     * @return company of type Company
     */
    public Company getCompany() {
        return company;
    }

    /**
     * Mutator for property company.
     * 
     * @param company of type Company
     */
    @XmlElement(name = "company")
    public void setCompany(Company company) {
        this.company = company;
    }

    /**
     * Accessor for property superTickStatusCodeType.
     * 
     * @return superTickStatusCodeType of type String
     */
    public String getSuperTickStatusCodeType() {
        return superTickStatusCodeType;
    }

    /**
     * Mutator for property superTickStatusCodeType.
     * 
     * @param superTickStatusCodeType of type String
     */
    @XmlElement(name = "superTickStatusCodeType")
    public void setSuperTickStatusCodeType(String superTickStatusCodeType) {
        this.superTickStatusCodeType = superTickStatusCodeType;
    }
}
