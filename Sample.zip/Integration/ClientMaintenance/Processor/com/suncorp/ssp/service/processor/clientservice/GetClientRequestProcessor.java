////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package com.suncorp.ssp.service.processor.clientservice;

import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.component.cxf.common.message.CxfConstants;
import org.apache.cxf.jaxrs.utils.JAXRSUtils;

import com.sonatacentral.service.v30.common.client.GetClientRequestType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.clientservice.ClientServiceConstants;
import com.suncorp.ssp.service.integration.clientservice.util.GetClientRequestUtil;

/**
 * The class {@code GetClientRequestProcessor} processes/constructs SOAP request for external service.
 * 
 * @author U383754
 * @since 2015-10-01
 * @version 1.0
 */
public class GetClientRequestProcessor implements Processor {

    /**
     * Extracts the values from end client's request and constructs a new request as per the external service's format.
     * 
     * @param exchange of type {@code Exchange}
     * @throws Exception of type {@code Exception}
     */
    @Override
    public void process(Exchange exchange) throws Exception {
        SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "GetClientRequestProcessor", "Entering in process method.");
        try {
            exchange.setProperty(CommonConstants.RESPONSE_CLASS_NAME, ClientServiceConstants.GET_CLIENT_RESPONSE_CLASS_NAME);
            MultivaluedMap<String, String> inboundRequest =
                    JAXRSUtils.getStructuredParams(exchange.getIn().getHeader(Exchange.HTTP_QUERY, String.class), "&", true, true);
            GetClientRequestUtil requestUtil = new GetClientRequestUtil(inboundRequest);
            GetClientRequestType outboundRequest = requestUtil.createOutboundRequest();
            this.setHeaderAndBody(exchange, outboundRequest);
            SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "GetClientRequestProcessor", "Exiting from process method");
        } catch (SILException silException) {
            SILLogger.error(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "GetClientRequestProcessor",
                    "Exception while creating soap request : " + silException.getMessage());
            exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, CommonConstants.HTTP_BAD_REQUEST_CODE);
            throw new SILException(silException.getMessage());
        } catch (Exception exception) {
            SILLogger.error(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "GetClientRequestProcessor",
                    "Exception while creating soap request : " + exception.getMessage());
            throw new Exception(ClientServiceConstants.GET_CLIENT_GENERIC_MSG);
        }
    }

    /**
     * This method is used to set header and body in the exchange message.
     * 
     * @param exchange
     * @param getClientRequestType
     */
    private void setHeaderAndBody(Exchange exchange, GetClientRequestType getClientRequestType) {
        Map<String, Object> mapHeaders = new HashMap<String, Object>();
        mapHeaders.put(CxfConstants.OPERATION_NAME, ClientServiceConstants.GET_CLIENT_OPERATION_NAME);
        mapHeaders.put(CxfConstants.OPERATION_NAMESPACE, ClientServiceConstants.OPERATION_NAMESPACE);
        exchange.getIn().setHeaders(mapHeaders);
        exchange.getIn().setBody(getClientRequestType);
    }
}
