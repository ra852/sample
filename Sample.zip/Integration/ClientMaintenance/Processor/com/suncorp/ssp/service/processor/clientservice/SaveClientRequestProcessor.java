////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.processor.clientservice;

import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.component.cxf.common.message.CxfConstants;

import com.sonatacentral.service.v30.common.client.SaveClientRequestType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.clientservice.ClientServiceConstants;
import com.suncorp.ssp.service.integration.clientservice.bean.SaveClientRequest;
import com.suncorp.ssp.service.integration.clientservice.util.SaveClientDetailsRequestUtil;

/**
 * The class {@code SaveClientRequestProcessor} processes/constructs SOAP request for external service.
 * 
 * @author U383847
 * @since 29/10/2015
 * @version 1.0
 */
public class SaveClientRequestProcessor implements Processor {
    private final String className = "SaveClientRequestProcessor";

    /**
     * Extracts the values from end client's request and constructs a new request as per the external service's format.
     * 
     * @param exchange of type Exchange
     * @throws Exception of type Exception
     */
    @Override
    public void process(Exchange exchange) throws Exception {
        SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Entering in process method");
        try {
            exchange.setProperty(CommonConstants.RESPONSE_CLASS_NAME, ClientServiceConstants.SAVE_CLIENT_RESPONSE_CLASS_NAME);
            SaveClientRequest saveClientRequest = exchange.getIn().getBody(SaveClientRequest.class);
            SaveClientRequestType saveClientRequestType = new SaveClientRequestType();
            saveClientRequestType.setCallerDetails(SILUtil.createCallerDetails());
            if (saveClientRequest != null) {
                SaveClientDetailsRequestUtil clientDetailsUtil = new SaveClientDetailsRequestUtil(saveClientRequest);
                clientDetailsUtil.setClientRequest(saveClientRequestType);
            } else {
                throw new SILException(ClientServiceConstants.INVALID_REQUEST_FORMAT);
            }
            setHeadersBody(exchange, saveClientRequestType);
            SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Exiting from process method");
        } catch (SILException silException) {
            SILLogger.error(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, SILUtil.getReqExMsg(silException));
            exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, CommonConstants.HTTP_BAD_REQUEST_CODE);
            throw new SILException(SILUtil.getReqExMsg(silException));
        } catch (Exception exception) {
            SILLogger.error(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, SILUtil.getReqExMsg(exception));
            throw new SILException(ClientServiceConstants.SAVE_CLIENT_EXCEPTION_MESSAGE);
        }
    }

    /**
     * Set Headers and Body for SOAP Request.
     * 
     * @param exchange
     * @param saveClientRequestType
     */
    private void setHeadersBody(Exchange exchange, SaveClientRequestType saveClientRequestType) {
        SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, "SaveClientRequestProcessor", "Setting Headers and Body for SOAP Request");
        Map<String, Object> mapHeaders = new HashMap<String, Object>();
        mapHeaders.put(CxfConstants.OPERATION_NAME, ClientServiceConstants.SAVE_CLIENT_OPERATION_NAME);
        mapHeaders.put(CxfConstants.OPERATION_NAMESPACE, ClientServiceConstants.OPERATION_NAMESPACE);
        exchange.getIn().setHeaders(mapHeaders);
        exchange.getIn().setBody(saveClientRequestType);
    }
}
