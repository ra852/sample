////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.processor.clientservice;

import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.component.cxf.common.message.CxfConstants;

import com.sonatacentral.service.v30.common.scheme.GetEmployerRequestType;
import com.sonatacentral.service.v30.globaltypes.common.scheme.schemegrouptype.EmployerIdentifierType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.clientservice.ClientServiceConstants;

/**
 * The class {@code GetEmployerRequestProcessor} Creates a SOAP request for Sonata's getEmployer.
 * 
 * @author U385424
 * @since 20/10/2016
 * @version 1.0
 */
public class GetEmployerRequestProcessor implements Processor {
    private final String className = "GetEmployerRequestProcessor";

    /**
     * Creates a SOAP request for Sonata's getEmployer service w.r.t. Employer, and sets its into the exchange body.
     * 
     * @param exchange of type Exchange
     * @throws Exception
     */
    @Override
    public void process(Exchange ex) throws Exception {
        SILLogger.debug(ClientServiceConstants.GET_CUSTOMER_BY_PRODUCT_LOGGING_FORMAT, className, "Entering process()");
        try {
            Long employerNumber = (Long) ex.getProperty(ClientServiceConstants.EMPLOYER_NUMBER_TAG);
            GetEmployerRequestType outboundRequest = new GetEmployerRequestType();
            outboundRequest.setCallerDetails(SILUtil.createCallerDetails());
            createOutboundRequest(employerNumber, outboundRequest);
            setHeaderAndBody(ex, outboundRequest);
        } catch (Exception excp) {
            throw new SILException(ClientServiceConstants.GET_CUSTOMER_BY_PRODUCT_GENERIC_MSG);
        }
    }

    /**
     * Creates a SOAP request for Sonata's GetEmployer, and sets its into the exchange body.
     * 
     * @param employerNumber
     * @param outboundRequest
     * 
     * @return outboundRequest of type GetEmployerRequestType
     */
    private GetEmployerRequestType createOutboundRequest(Long employerNumber, GetEmployerRequestType outboundRequest) {
        SILLogger.debug(ClientServiceConstants.GET_CUSTOMER_BY_PRODUCT_LOGGING_FORMAT, className, "Entering createOutboundRequest()");
        EmployerIdentifierType employer = new EmployerIdentifierType();
        if (employerNumber != null) {
            employer.setEmployerNumber(employerNumber.toString());
        }
        outboundRequest.setEmployer(employer);
        SILLogger.debug(ClientServiceConstants.GET_CUSTOMER_BY_PRODUCT_LOGGING_FORMAT, className, "Exiting createOutboundRequest()");
        return outboundRequest;
    }

    /**
     * Sets the headers and body into the exchange message.
     * 
     * @param exchange of type Exchange
     */
    private void setHeaderAndBody(Exchange exchange, GetEmployerRequestType outboundRequest) {
        SILLogger.debug(ClientServiceConstants.GET_CUSTOMER_BY_PRODUCT_LOGGING_FORMAT, className, "Entering setHeaderAndBody()");
        Map<String, Object> mapHeaders = new HashMap<String, Object>();
        mapHeaders.put(CxfConstants.OPERATION_NAME, ClientServiceConstants.GET_EMPLOYER_OPERATION_NAME);
        mapHeaders.put(CxfConstants.OPERATION_NAMESPACE, ClientServiceConstants.GET_EMPLOYER_OPERATION_NAMESPACE);
        exchange.getIn().setHeaders(mapHeaders);
        exchange.getIn().setBody(outboundRequest);
        SILLogger.debug(ClientServiceConstants.GET_CUSTOMER_BY_PRODUCT_LOGGING_FORMAT, className, "Exiting setHeaderAndBody()");
    }
}
