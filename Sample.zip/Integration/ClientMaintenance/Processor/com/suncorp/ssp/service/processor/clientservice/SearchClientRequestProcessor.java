////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.processor.clientservice;

import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.component.cxf.common.message.CxfConstants;
import org.apache.cxf.jaxrs.utils.JAXRSUtils;

import com.sonatacentral.service.v30.common.client.SearchClientRequestType;
import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.ClientIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CodeIdentifierType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.clientservice.ClientServiceConstants;

/**
 * The class {@code SearchClientRequestProcessor} does this.
 * 
 * @author U383847
 * @since 09/03/2016
 * @version 1.0
 */
public class SearchClientRequestProcessor implements Processor {
    private final String className = "SearchClientRequestProcessor";

    /**
     * Extracts the values from end client's request and constructs a new request as per the external service's format.
     * 
     * @param exchange
     * @throws Exception
     */
    @Override
    public void process(Exchange exchange) throws Exception {
        SILLogger.debug(ClientServiceConstants.SEARCH_CLIENT_LOGGING_FORMAT, className, "Entering into process");
        try {
            exchange.setProperty(CommonConstants.RESPONSE_CLASS_NAME, ClientServiceConstants.SERACH_CLIENT_RESPONSE_CLASS_NAME);
            SearchClientRequestType searchClientRequestType = new SearchClientRequestType();
            searchClientRequestType.setCallerDetails(SILUtil.createCallerDetails());
            ClientIdentifierType clientIdentifierType = new ClientIdentifierType();
            this.createSurnameQueryString(exchange, clientIdentifierType);
            SearchClientRequestType.SearchCriteria searchCriteria = new SearchClientRequestType.SearchCriteria();
            this.createInvestTypeCodeQueryString(exchange, searchCriteria);
            this.createExternalReferenceQueryString(exchange, searchCriteria);
            this.createDateOfBirthQueryString(exchange, searchCriteria);
            searchCriteria.setClient(clientIdentifierType);
            searchClientRequestType.setSearchCriteria(searchCriteria);
            this.setBodyAndHeader(exchange, searchClientRequestType);
        } catch (SILException silException) {
            SILLogger.error(ClientServiceConstants.SEARCH_CLIENT_LOGGING_FORMAT, className, SILUtil.getReqExMsg(silException));
            exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, CommonConstants.HTTP_BAD_REQUEST_CODE);
            throw new SILException(SILUtil.getReqExMsg(silException));
        } catch (Exception exception) {
            SILLogger.error(ClientServiceConstants.SEARCH_CLIENT_LOGGING_FORMAT, className, SILUtil.getReqExMsg(exception));
            throw new SILException(ClientServiceConstants.SEARCH_CLIENT_GENERIC_MSG);
        }
    }

    /**
     * This method is used to create query string for Surname.
     * 
     * @param exchange
     * @return
     */
    private void createSurnameQueryString(Exchange exchange, ClientIdentifierType clientIdentifierType) throws SILException {
        String searchClientQryString = exchange.getIn().getHeader(Exchange.HTTP_QUERY, String.class);
        MultivaluedMap<String, String> queryMap = JAXRSUtils.getStructuredParams(searchClientQryString, "&", true, true);
        if (queryMap.containsKey(ClientServiceConstants.CLIENT_SURNAME) && queryMap.get(ClientServiceConstants.CLIENT_SURNAME).get(0) != null) {
            SILLogger.debug(ClientServiceConstants.SEARCH_CLIENT_LOGGING_FORMAT, className, "Creating Surname Query String");
            clientIdentifierType.setClientSurname(queryMap.get(ClientServiceConstants.CLIENT_SURNAME).get(0) + ClientServiceConstants.PERCENT_SYMBOL);
        }
    }

    /**
     * This method is used to create query string for InvestTypeCode.
     * 
     * @param exchange
     * @param searchCriteria
     */
    private void createInvestTypeCodeQueryString(Exchange exchange, SearchClientRequestType.SearchCriteria searchCriteria) {
        String searchClientQryString = exchange.getIn().getHeader(Exchange.HTTP_QUERY, String.class);
        boolean flag1 = false, flag2 = false;
        MultivaluedMap<String, String> queryMap = JAXRSUtils.getStructuredParams(searchClientQryString, "&", true, true);
        CodeIdentifierType codeIdentifierType = new CodeIdentifierType();
        if (queryMap.containsKey(ClientServiceConstants.INVEST_TYPE_CODE) && queryMap.get(ClientServiceConstants.INVEST_TYPE_CODE).get(0) != null) {
            SILLogger.debug(ClientServiceConstants.SEARCH_CLIENT_LOGGING_FORMAT, className, "Creating InvestTypeCode Query String");
            codeIdentifierType.setCode(queryMap.get(ClientServiceConstants.INVEST_TYPE_CODE).get(0));
            flag1 = true;
        }
        if (queryMap.containsKey(ClientServiceConstants.INVEST_TYPE_CODE_TYPE) &&
                queryMap.get(ClientServiceConstants.INVEST_TYPE_CODE_TYPE).get(0) != null) {
            codeIdentifierType.setCodeType(queryMap.get(ClientServiceConstants.INVEST_TYPE_CODE_TYPE).get(0));
            flag2 = true;
        }
        if (flag1 || flag2) {
            searchCriteria.setInvestTypeCode(codeIdentifierType);
        }
    }

    /**
     * This method is used to create query string for include external reference.
     * 
     * @param exchange
     * @param searchCriteria
     */
    private void createExternalReferenceQueryString(Exchange exchange, SearchClientRequestType.SearchCriteria searchCriteria) {
        String searchClientQryString = exchange.getIn().getHeader(Exchange.HTTP_QUERY, String.class);
        MultivaluedMap<String, String> queryMap = JAXRSUtils.getStructuredParams(searchClientQryString, "&", true, true);
        if (queryMap.containsKey(ClientServiceConstants.INCLUDE_EXTERNAL_REF) &&
                queryMap.get(ClientServiceConstants.INCLUDE_EXTERNAL_REF).get(0) != null) {
            SILLogger.debug(ClientServiceConstants.SEARCH_CLIENT_LOGGING_FORMAT, className, "Creating External Reference Flag Query String");
            searchCriteria.setIncludeExternalReferences(Boolean.parseBoolean(queryMap.get(ClientServiceConstants.INCLUDE_EXTERNAL_REF).get(0)));
        }
    }

    /**
     * This method is used to set header and body in the exchange message.
     * 
     * @param exchange
     * @param searchClientRequestType
     */
    private void setBodyAndHeader(Exchange exchange, SearchClientRequestType searchClientRequestType) {
        SILLogger.debug(ClientServiceConstants.SEARCH_CLIENT_LOGGING_FORMAT, className, "Setting Body and Header");
        Map<String, Object> mapHeaders = new HashMap<String, Object>();
        mapHeaders.put(CxfConstants.OPERATION_NAME, ClientServiceConstants.SERACH_CLIENT_OPERATION_NAME);
        mapHeaders.put(CxfConstants.OPERATION_NAMESPACE, ClientServiceConstants.OPERATION_NAMESPACE);
        exchange.getIn().setHeaders(mapHeaders);
        exchange.getIn().setBody(searchClientRequestType);
    }
    
    /**
     * This method is used to create query string for include external reference.
     * 
     * @param exchange
     * @param searchCriteria
     * @throws SILException 
     */
    private void createDateOfBirthQueryString(Exchange exchange, SearchClientRequestType.SearchCriteria searchCriteria) throws SILException {
        String searchClientQryString = exchange.getIn().getHeader(Exchange.HTTP_QUERY, String.class);
        MultivaluedMap<String, String> queryMap = JAXRSUtils.getStructuredParams(searchClientQryString, "&", true, true);
        if (queryMap.containsKey(ClientServiceConstants.DATE_OF_BIRTH) &&
                queryMap.get(ClientServiceConstants.DATE_OF_BIRTH).get(0) != null) {
            SILLogger.debug(ClientServiceConstants.SEARCH_CLIENT_LOGGING_FORMAT, className, "Creating createDateOfBirthQueryString Query String");
            searchCriteria.setDateOfBirth(createDateOfBirth(queryMap.get(ClientServiceConstants.DATE_OF_BIRTH).get(0)));
        }
    }
    
    /**
     * This method checks the presence of parameter dateOfbirth and converts into XMLGregorianCalendar type.
     * 
     * @return dateOfBirth
     * @throws SILException
     */
    public XMLGregorianCalendar createDateOfBirth(String dateOfBirth) throws SILException {
        SILLogger.debug(ClientServiceConstants.SEARCH_CLIENT_LOGGING_FORMAT, className, "Entering createDateOfBirth");
        XMLGregorianCalendar dateOfBirthSoap = null;
        if (dateOfBirth != null) {
            dateOfBirthSoap = SILUtil.convertStringToXMLGregorianCalendar(dateOfBirth, CommonConstants.DATE_FORMAT);
        }
        return dateOfBirthSoap;
    }
}
