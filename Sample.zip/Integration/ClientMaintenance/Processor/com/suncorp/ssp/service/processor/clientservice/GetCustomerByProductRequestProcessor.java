////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.processor.clientservice;

import javax.ws.rs.core.MultivaluedMap;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.cxf.jaxrs.utils.JAXRSUtils;

import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.clientservice.ClientServiceConstants;

/**
 * The class {@code GetCustomerByProductRequestProcessor} retrieve the request from query exchange and set the input parameters to exchange property.
 * 
 * @author U385424
 * @since 20/10/2016
 * @version 1.0
 */
public class GetCustomerByProductRequestProcessor implements Processor {
    private final String className = "GetCustomerByProductRequestProcessor";

    /**
     * Extracts the values from end client's request and constructs a new request as per the external service's format.
     * 
     * @param exchange of type {@code Exchange}
     * @throws Exception of type {@code Exception}
     */
    @Override
    public void process(Exchange exchange) throws Exception {
        SILLogger.debug(ClientServiceConstants.GET_CUSTOMER_BY_PRODUCT_LOGGING_FORMAT, className, "Entering in process method.");
        try {
            String getCustomerQryString = exchange.getIn().getHeader(Exchange.HTTP_QUERY, String.class);
            MultivaluedMap<String, String> getIdentityQryMap = JAXRSUtils.getStructuredParams(getCustomerQryString, "&", true, true);
            Long identity = setIdentityFromQueryString(exchange, getIdentityQryMap);
            setEntityTypeProperty(exchange, getIdentityQryMap, identity);
            SILLogger.debug(ClientServiceConstants.GET_CUSTOMER_BY_PRODUCT_LOGGING_FORMAT, className, "Exiting from process method");
        } catch (Exception exception) {
            SILLogger.error(ClientServiceConstants.GET_CUSTOMER_BY_PRODUCT_LOGGING_FORMAT, className, "Exception while creating soap request : " +
                    exception.getMessage());
            throw new Exception(ClientServiceConstants.GET_CUSTOMER_BY_PRODUCT_GENERIC_MSG);
        }
    }

    /**
     * 
     * This method is used to set the identity in exchange property.
     * 
     * @param exchange
     * @param getIdentityQryMap
     * @return the client Id
     * @throws SILException
     */
    private Long setIdentityFromQueryString(Exchange exchange, MultivaluedMap<String, String> getIdentityQryMap) throws SILException {
        Long identity = null;
        SILLogger.debug(ClientServiceConstants.GET_CUSTOMER_BY_PRODUCT_LOGGING_FORMAT, className, "Entering setIdentityFromQueryString method.");
        if (getIdentityQryMap.containsKey(ClientServiceConstants.IDENTITY_TAG) &&
                getIdentityQryMap.get(ClientServiceConstants.IDENTITY_TAG).get(0) != null) {
            identity = Long.parseLong(getIdentityQryMap.get(ClientServiceConstants.IDENTITY_TAG).get(0).trim());
            exchange.setProperty(ClientServiceConstants.IDENTITY_PROPERTY_TAG, identity);
        } else {
            throw new SILException(ClientServiceConstants.INVALID_GET_CUSTOMER_REQUEST_MESSAGE);
        }
        SILLogger.debug(ClientServiceConstants.GET_CUSTOMER_BY_PRODUCT_LOGGING_FORMAT, className, "Exiting setIdentityFromQueryString method.");
        return identity;
    }

    /**
     * This method is used to check the entityType and set it to property.
     * 
     * @param exchange
     * @param getIdentityQryMap
     * @param identity
     * @throws SILException
     */
    private void setEntityTypeProperty(Exchange exchange, MultivaluedMap<String, String> getIdentityQryMap, Long identity) throws SILException {
        SILLogger.debug(ClientServiceConstants.GET_CUSTOMER_BY_PRODUCT_LOGGING_FORMAT, className, "Entering setEntityTypeProperty method.");
        String entityType = getIdentityQryMap.get(ClientServiceConstants.ENTITY_TYPE_TAG).get(0);
        if (getIdentityQryMap.containsKey(ClientServiceConstants.ENTITY_TYPE_TAG) &&
                getIdentityQryMap.get(ClientServiceConstants.ENTITY_TYPE_TAG).get(0) != null &&
                (entityType.equalsIgnoreCase(ClientServiceConstants.ENTITY_TYPE_EMPLOYER) || entityType
                        .equalsIgnoreCase(ClientServiceConstants.ENTITY_TYPE_MEMBER))) {
            exchange.setProperty(ClientServiceConstants.ENTITY_TYPE_PROPERTY_TAG, entityType);
            if (entityType.equalsIgnoreCase(ClientServiceConstants.ENTITY_TYPE_EMPLOYER)) {
                exchange.setProperty(ClientServiceConstants.CALL_EMPLOYER_SERVICE, CommonConstants.FLAG_Y);
                exchange.setProperty(ClientServiceConstants.EMPLOYER_NUMBER_TAG, identity);
            }
            if (entityType.equalsIgnoreCase(ClientServiceConstants.ENTITY_TYPE_MEMBER)) {
                exchange.setProperty(ClientServiceConstants.CALL_EMPLOYER_SERVICE, CommonConstants.FLAG_N);
                exchange.setProperty(ClientServiceConstants.ACCOUNT_NUMBER_TAG, identity);
            }
        } else {
            exchange.setProperty("InvalidEntityTypeValue", "Y");
        }
        SILLogger.debug(ClientServiceConstants.GET_CUSTOMER_BY_PRODUCT_LOGGING_FORMAT, className, "Exiting setEntityTypeProperty method.");
    }
}
