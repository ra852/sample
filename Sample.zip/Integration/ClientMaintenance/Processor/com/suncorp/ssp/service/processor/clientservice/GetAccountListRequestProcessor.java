////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.processor.clientservice;

import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.component.cxf.common.message.CxfConstants;
import org.apache.cxf.jaxrs.utils.JAXRSUtils;

import com.sonatacentral.service.v30.common.client.GetAccountListRequestType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.clientservice.ClientServiceConstants;
import com.suncorp.ssp.service.integration.clientservice.util.GetAccountListRequestUtil;

/**
 * The class {@code GetAccountListRequestProcessor} processes/constructs SOAP request for external service.
 * 
 * @author U385424
 * @since 2015-10-01
 * @version 1.0
 */
public class GetAccountListRequestProcessor implements Processor {

    /**
     * Extracts the values from end client's request and constructs a new request as per the external service's format.
     * 
     * @param exchange of type Exchange
     * @throws Exception of type Exception
     */
    @Override
    public void process(Exchange exchange) throws Exception {
        SILLogger.debug(ClientServiceConstants.GET_ACCOUNT_LIST_LOGGING_FORMAT, "GetAccountListRequestProcessor", "Entering in process method.");
        try {
            exchange.setProperty(CommonConstants.RESPONSE_CLASS_NAME, ClientServiceConstants.GET_ACCOUNT_LIST_RESPONSE_CLASS_NAME);
            MultivaluedMap<String, String> inboundRequest =
                    JAXRSUtils.getStructuredParams(exchange.getIn().getHeader(Exchange.HTTP_QUERY, String.class), "&", true, true);
            GetAccountListRequestUtil requestUtil = new GetAccountListRequestUtil(inboundRequest);
            GetAccountListRequestType outboundRequest = requestUtil.createOutboundRequest();
            setHeaderAndBody(exchange, outboundRequest);
            SILLogger.debug(ClientServiceConstants.GET_ACCOUNT_LIST_LOGGING_FORMAT, "GetAccountListRequestPro.cessor", "Exiting from process method");
        } catch (SILException silException) {
            SILLogger.error(ClientServiceConstants.GET_ACCOUNT_LIST_LOGGING_FORMAT, "GetAccountListRequestProcessor",
                    "Exception while creating soap request : " + silException.getMessage());
            exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, CommonConstants.HTTP_BAD_REQUEST_CODE);
            throw new SILException(silException.getMessage());
        } catch (Exception exception) {
            SILLogger.error(ClientServiceConstants.GET_ACCOUNT_LIST_LOGGING_FORMAT, "GetAccountListRequestProcessor",
                    "Exception while creating soap request" + exception.getMessage());
            throw new Exception(ClientServiceConstants.GET_ACCOUNT_LIST_GENERIC_MSG);
        }
    }

    /**
     * This method is used to set header and body in the exchange message.
     * 
     * @param exchange
     * @param getAccountListRequestType
     */

    private void setHeaderAndBody(Exchange exchange, GetAccountListRequestType outboundRequest) {
        Map<String, Object> mapHeaders = new HashMap<String, Object>();
        mapHeaders.put(CxfConstants.OPERATION_NAME, ClientServiceConstants.GET_ACCOUNT_LIST_OPERATION_NAME);
        mapHeaders.put(CxfConstants.OPERATION_NAMESPACE, ClientServiceConstants.OPERATION_NAMESPACE);
        exchange.getIn().setHeaders(mapHeaders);
        exchange.getIn().setBody(outboundRequest);

    }
}
