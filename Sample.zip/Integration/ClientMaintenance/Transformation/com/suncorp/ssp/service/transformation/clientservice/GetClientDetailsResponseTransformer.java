////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.transformation.clientservice;

import javax.ws.rs.core.Response;

import org.apache.camel.Exchange;

import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.clientservice.ClientServiceConstants;
import com.suncorp.ssp.service.integration.clientservice.bean.GetClientResponse;
import com.suncorp.ssp.service.integration.clientservice.bean.GetCustomerByProductDetails;
import com.suncorp.ssp.service.integration.clientservice.util.ClientServiceUtil;
import com.suncorp.ssp.service.integration.customerservice.bean.GetClientResponseWrapperBean;

/**
 * The class {@code GetClientDetailsResponseTransformer} does this.
 * 
 * @author U385424
 * @since 19/10/2016
 * @version 1.0
 */
public class GetClientDetailsResponseTransformer {
    private final String className = "GetClientDetailsResponseTransformer";

    /**
     * Extracts the values from external service's response, to forward to the end client.
     * 
     * @param exchange
     * @throws SILException
     */
    public void transform(Exchange exchange) throws SILException {
        try {
            SILLogger.debug(ClientServiceConstants.GET_CUSTOMER_BY_PRODUCT_LOGGING_FORMAT, className, "Entering in transform method");
            GetClientResponseWrapperBean getClientResponseWrapperBean = exchange.getIn().getBody(GetClientResponseWrapperBean.class);
            if (getClientResponseWrapperBean != null && getClientResponseWrapperBean.getClientResponse() != null &&
                    getClientResponseWrapperBean.getClientResponse().getErrorMessage() == null) {
                GetClientResponse getClientResponse = getClientResponseWrapperBean.getClientResponse();
                GetCustomerByProductDetails getCustomerByProductDetails = new GetCustomerByProductDetails();
                getClientDetails(getClientResponse, getCustomerByProductDetails, exchange);
                Response response = Response.status(Response.Status.OK).entity(getCustomerByProductDetails).build();
                exchange.getIn().setBody(response);
            } else {
                exchange.setProperty(ClientServiceConstants.STOP_ROUTE, CommonConstants.FLAG_Y);
            }
        } catch (Exception exception) {
            throw new SILException(ClientServiceConstants.GET_CUSTOMER_BY_PRODUCT_GENERIC_MSG);
        }
    }

    /**
     * Get Product Client Details.
     * 
     * @param exchange
     * @param getClientResponse
     * @param getCustomerByProductDetails
     * @param exchange
     * @throws Exception
     */
    private void getClientDetails(GetClientResponse getClientResponse, GetCustomerByProductDetails getCustomerByProductDetails, Exchange exchange)
            throws SILException {
        SILLogger.debug(ClientServiceConstants.GET_CUSTOMER_BY_PRODUCT_LOGGING_FORMAT, className, "Entering getClientDetails()");
        ClientServiceUtil clientServiceUtil = new ClientServiceUtil();
        getCustomerByProductDetails.setCustomerId(clientServiceUtil.retrieveStringValue(getClientResponse.getClientId()));
        getCustomerByProductDetails.setName(clientServiceUtil.retrieveStringValue(getClientResponse.getLastName()));
        getCustomerByProductDetails.setOtherName(clientServiceUtil.retrieveStringValue(getClientResponse.getFirstName()));
        getCustomerByProductDetails.setTitle(clientServiceUtil.retrieveStringValue(getClientResponse.getTitle()));
        getCustomerByProductDetails.setEntityType((String) exchange.getProperty(ClientServiceConstants.ENTITY_TYPE_PROPERTY_TAG));
        getCustomerByProductDetails.setError(clientServiceUtil
                .retrieveErrorDetailsSuccessfulScenario(ClientServiceConstants.GET_CUSTOMER_BY_PRODUCT_LOGGING_FORMAT));
        SILLogger.debug(ClientServiceConstants.GET_CUSTOMER_BY_PRODUCT_LOGGING_FORMAT, className, "Exiting getClientDetails()");
    }
}
