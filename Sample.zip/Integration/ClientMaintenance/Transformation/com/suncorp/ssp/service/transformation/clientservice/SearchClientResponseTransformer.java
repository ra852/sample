////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.transformation.clientservice;

import javax.ws.rs.core.Response;

import org.apache.camel.Exchange;

import com.sonatacentral.service.v30.common.client.SearchClientResponseType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.clientservice.ClientServiceConstants;
import com.suncorp.ssp.service.integration.clientservice.bean.SearchClientResponse;
import com.suncorp.ssp.service.integration.clientservice.util.SearchClientResponseUtil;

/**
 * The class {@code SearchClientResponseTransformer} does this.
 * 
 * @author U383847
 * @since 15/03/2016
 * @version 1.0
 */
public class SearchClientResponseTransformer {
    private final String className = "SearchClientResponseTransformer";

    /**
     * Extracts the values from external service's response, to forward to the end client.
     * 
     * @param exchange
     * @throws Exception
     */
    public void transform(Exchange exchange) throws SILException {
        try {
            SILLogger.debug(ClientServiceConstants.SEARCH_CLIENT_LOGGING_FORMAT, className, "Entering in transform method");
            SearchClientResponseType searchClientResponseType = exchange.getIn().getBody(SearchClientResponseType.class);
            SearchClientResponse searchClientResponse = new SearchClientResponse();
            SearchClientResponseUtil searchClientResponseUtil = new SearchClientResponseUtil(searchClientResponseType);
            searchClientResponseUtil.searchClientResponse(searchClientResponse);
            Response response = Response.status(Response.Status.OK).entity(searchClientResponse).build();
            exchange.getIn().setBody(response);
            SILLogger.debug(ClientServiceConstants.SEARCH_CLIENT_LOGGING_FORMAT, className, "Exiting from transform method");
        } catch (SILException silException) {
            SILLogger.error(ClientServiceConstants.SEARCH_CLIENT_LOGGING_FORMAT, className, SILUtil.getRespExMsg(silException));
            throw new SILException(SILUtil.getRespExMsg(silException));
        } catch (Exception exception) {
            SILLogger.error(ClientServiceConstants.SEARCH_CLIENT_LOGGING_FORMAT, className, SILUtil.getRespExMsg(exception));
            throw new SILException(SILUtil.getRespExMsg(exception));
        }
    }
}
