////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package com.suncorp.ssp.service.transformation.clientservice;

import javax.ws.rs.core.Response;

import org.apache.camel.Exchange;

import com.sonatacentral.service.v30.common.client.GetClientResponseType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.clientservice.ClientServiceConstants;
import com.suncorp.ssp.service.integration.clientservice.bean.GetClientResponse;
import com.suncorp.ssp.service.integration.clientservice.util.GetClientDetailsUtil;

/**
 * The class {@code GetClientResponseTransformer} transforms the response to required format for end client.
 * 
 * @author U383754
 * @since 2015-10-01
 * @version 1.0
 */
public class GetClientResponseTransformer {

    /**
     * Extracts the values from external service's response, to forward to the end client.
     * 
     * @param exchange of type Exchange
     * @throws Exception of type Exception
     */
    public void transform(Exchange exchange) throws SILException {
        try {
            SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "GetClientResponseTransformer", "Entering in transform method");
            GetClientResponseType getClientResponseType = exchange.getIn().getBody(GetClientResponseType.class);
            GetClientResponse getClientResponse = new GetClientResponse();
            GetClientDetailsUtil getClientDetailsUtil = new GetClientDetailsUtil(getClientResponseType);
            getClientDetailsUtil.setClientResponse(getClientResponse);
            Response response = Response.status(Response.Status.OK).entity(getClientResponse).build();
            exchange.getIn().setBody(response);
            SILLogger.debug(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "GetClientResponseTransformer", "Exiting from transform method");
        } catch (Exception exception) {
            SILLogger.error(ClientServiceConstants.GET_CLIENT_LOGGING_FORMAT, "GetClientResponseTransformer",
                    "Exception while constructing response:" + exception.getMessage());
            throw new SILException(ClientServiceConstants.GET_CLIENT_GENERIC_MSG);
        }
    }
}
