////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.transformation.clientservice;

import javax.ws.rs.core.Response;

import org.apache.camel.Exchange;

import com.sonatacentral.service.v30.common.client.GetAccountListResponseType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.clientservice.ClientServiceConstants;
import com.suncorp.ssp.service.integration.clientservice.bean.GetAccountListResponseBean;
import com.suncorp.ssp.service.integration.clientservice.util.GetAccountListUtil;

/**
 * The class {@code GetAccountListResponseTransformer} transforms the response received from external service, to a specified format for end-client.
 * 
 * @author U385424
 * @since 13/11/2015
 * @version 1.0
 */
public class GetAccountListResponseTransformer {

    /**
     * Extracts the values from external service's response, to forward to the end client.
     */
    public void tranform(Exchange exchange) throws SILException {
        try {
            SILLogger.debug(ClientServiceConstants.GET_ACCOUNT_LIST_LOGGING_FORMAT, "GetAccountListResponseTransformer", "Entering transform()");
            GetAccountListResponseType getAccountListResponseType = exchange.getIn().getBody(GetAccountListResponseType.class);

            GetAccountListResponseBean getAccountListResponseBean = new GetAccountListResponseBean();
            new GetAccountListUtil(getAccountListResponseType).setGetAccountListResponseType(getAccountListResponseBean);

            setExchangeResponse(exchange, getAccountListResponseBean);
            SILLogger.debug(ClientServiceConstants.GET_ACCOUNT_LIST_LOGGING_FORMAT, "GetAccountListResponseTransformer", "Exiting transform()");
        } catch (SILException silEx) {
            SILLogger.error(ClientServiceConstants.GET_ACCOUNT_LIST_LOGGING_FORMAT, "GetAccountListResponseTransformer", SILUtil.getReqExMsg(silEx));
            throw new SILException(silEx.getMessage());
        } catch (Exception exception) {
            SILLogger.error(ClientServiceConstants.GET_ACCOUNT_LIST_LOGGING_FORMAT, "GetAccountListResponseTransformer",
                    "Exception while constructing response:" + exception.getMessage());
            throw new SILException(ClientServiceConstants.GET_ACCOUNT_LIST_GENERIC_MSG);
        }
    }

    /**
     * Sets the response into exchange message.
     * 
     * @param exchange of type Exchange
     * @param getAccountListResponseBean of type GetAccountListResponseBean
     */
    private void setExchangeResponse(Exchange exchange, GetAccountListResponseBean getAccountListResponseBean) {
        Response response = Response.status(Response.Status.OK).entity(getAccountListResponseBean).build();
        exchange.getIn().setBody(response);
    }

}
