////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.transformation.clientservice;

import java.util.List;

import org.apache.camel.Exchange;

import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.clientservice.ClientServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.AccountDetailsList;
import com.suncorp.ssp.service.integration.accountservice.bean.ClientAccountRelationshipBean;
import com.suncorp.ssp.service.integration.clientservice.util.ClientServiceUtil;
import com.suncorp.ssp.service.integration.customerservice.bean.GetAccountListDetailsResponseWrapperBean;
import com.suncorp.ssp.service.integration.customerservice.util.CustomerServiceUtil;

/**
 * The class {@code GetAccountListDetailsResponseTransformer} transforms the response to required format for end client.
 * 
 * @author U385424
 * @since 18/10/2016
 * @version 1.0
 */
public class GetAccountListDetailsResponseTransformer {

    private final String className = "GetAccountListDetailsResponseTransformer";

    /**
     * Extracts the values from external service's response, to forward to the end-client.
     */
    public void transform(Exchange exchange) throws SILException {
        try {
            SILLogger.debug(ClientServiceConstants.GET_CUSTOMER_BY_PRODUCT_LOGGING_FORMAT, className, "Entering transform()");
            GetAccountListDetailsResponseWrapperBean inboundResponseWrapper =
                    exchange.getIn().getBody(GetAccountListDetailsResponseWrapperBean.class);
            if (inboundResponseWrapper != null && inboundResponseWrapper.getGetAccountDetailsResponse() != null) {
                checkInboundResponse(exchange, inboundResponseWrapper);
            } else {
                exchange.setProperty(ClientServiceConstants.STOP_ROUTE, CommonConstants.FLAG_Y);
            }
            SILLogger.debug(ClientServiceConstants.GET_CUSTOMER_BY_PRODUCT_LOGGING_FORMAT, className, "Exiting transform()");
        } catch (Exception excp) {
            throw new SILException(ClientServiceConstants.GET_CUSTOMER_BY_PRODUCT_RESPONSE_NOT_PROCESSED);
        }
    }

    /**
     * This method is used to check inbound response..
     * 
     * @param exchange
     * @param inboundResponseWrapper
     * @throws SILException
     */
    private void checkInboundResponse(Exchange exchange, GetAccountListDetailsResponseWrapperBean inboundResponseWrapper) throws SILException {
        if (inboundResponseWrapper.getGetAccountDetailsResponse().getErrorMessage() == null &&
                inboundResponseWrapper.getGetAccountDetailsResponse().getAccountDetailsList() != null &&
                inboundResponseWrapper.getGetAccountDetailsResponse().getAccountDetailsList().size() > 0) {
            checkAccountStatus(exchange, inboundResponseWrapper.getGetAccountDetailsResponse().getAccountDetailsList());
            new CustomerServiceUtil().removeExchangeHeaders(exchange);
        } else if (inboundResponseWrapper.getGetAccountDetailsResponse().getErrorMessage() != null &&
                inboundResponseWrapper.getGetAccountDetailsResponse().getErrorMessage().contains("BRA-151101")) {
            ClientServiceUtil clientServiceUtil = new ClientServiceUtil();
            clientServiceUtil.setErrorResponse(exchange, ClientServiceConstants.ERROR_CODE_MEMBER_NOT_FOUND,
                    ClientServiceConstants.DESCRIPTION_MEMBER_NOT_FOUND);
        } else {
            exchange.setProperty(ClientServiceConstants.STOP_ROUTE, CommonConstants.FLAG_Y);
        }
    }

    /**
     * This method is used to check the account status and to set exchange property if account status is inactive.
     * 
     * @param exchange
     * @param accountDetailsList
     * @throws SILException
     */
    private void checkAccountStatus(Exchange exchange, List<AccountDetailsList> accountDetailsList) throws SILException {
        SILLogger.debug(ClientServiceConstants.GET_CUSTOMER_BY_PRODUCT_LOGGING_FORMAT, className, "Entering checkAndSetFlags()");
        for (AccountDetailsList accountDetails : accountDetailsList) {
            if (accountDetails.getAccount() != null && accountDetails.getAccount().getStatusCode() != null &&
                    !ClientServiceConstants.SONATA_CODE_INACTIVE_ACCOUNT.equalsIgnoreCase(accountDetails.getAccount().getStatusCode().getCode())) {
                if (accountDetails.getClientAccountRelationships() != null && accountDetails.getClientAccountRelationships().size() > 0) {
                    checkClientRelationship(exchange, accountDetails.getClientAccountRelationships());
                }
            } else {
                ClientServiceUtil clientServiceUtil = new ClientServiceUtil();
                clientServiceUtil.setErrorResponse(exchange, ClientServiceConstants.ERROR_CODE_MEMBER_NOT_FOUND,
                        ClientServiceConstants.DESCRIPTION_MEMBER_NOT_FOUND);
                exchange.setProperty(ClientServiceConstants.ACCOUNT_IS_INACTIVE, CommonConstants.FLAG_Y);
            }
        }
    }

    /**
     * This method is used to check the client relationship and set the exchange property.
     * 
     * @param exchange
     * @param clientAccountRelationships
     */
    private void checkClientRelationship(Exchange exchange, List<ClientAccountRelationshipBean> clientAccountRelationshipList) {
        SILLogger.debug(ClientServiceConstants.GET_CUSTOMER_BY_PRODUCT_LOGGING_FORMAT, className, "Entering checkClientRelationship()");
        for (ClientAccountRelationshipBean relationship : clientAccountRelationshipList) {
            if (checkValidClient(relationship)) {
                exchange.setProperty(ClientServiceConstants.CALL_COMPOSER_FOR_MEMBER_SERVICE, CommonConstants.FLAG_N);
                exchange.setProperty(ClientServiceConstants.CUSTOMER_CLIENT_ID, relationship.getClientAccountRelationship().getClient().getId());
            }
            SILLogger.debug(ClientServiceConstants.GET_CUSTOMER_BY_PRODUCT_LOGGING_FORMAT, className, "Exiting checkClientRelationship()");
        }
    }

    /**
     * This method is used to check the valid client.
     * 
     * @param relationship
     * @return
     */
    private boolean checkValidClient(ClientAccountRelationshipBean relationship) {
        SILLogger.debug(ClientServiceConstants.GET_CUSTOMER_BY_PRODUCT_LOGGING_FORMAT, className, "Entering checkValidClient()");
        if (relationship.getClientAccountRelationship() != null &&
                relationship.getClientAccountRelationship().getClient() != null &&
                relationship.getClientAccountRelationship().getClient().getId() != null &&
                relationship.getClientAccountRelationship().getRelationshipType() != null &&
                relationship.getClientAccountRelationship().getRelationshipType().getCode() != null &&
                ClientServiceConstants.SONATA_CODE_ACCOUNT_RELATIONSHIP_OWNER.equalsIgnoreCase(relationship.getClientAccountRelationship()
                        .getRelationshipType().getCode())) {
            return true;
        }
        return false;
    }
}
