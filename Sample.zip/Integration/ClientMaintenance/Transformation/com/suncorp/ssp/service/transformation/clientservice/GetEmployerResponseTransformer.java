////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.transformation.clientservice;

import javax.ws.rs.core.Response;

import org.apache.camel.Exchange;

import com.sonatacentral.service.v30.common.scheme.GetEmployerResponseType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.clientservice.ClientServiceConstants;
import com.suncorp.ssp.service.integration.clientservice.bean.GetCustomerByProductDetails;
import com.suncorp.ssp.service.integration.clientservice.util.ClientServiceUtil;

/**
 * The class {@code GetEmployerResponseTransformer} Extracts the values from external service's response.
 * 
 * @author U385424
 * @since 20/10/2016
 * @version 1.0
 */
public class GetEmployerResponseTransformer {
    private final String className = "GetEmployerResponseTransformer";

    /**
     * Extracts the values from external service's response, to forward to the end-client.
     */
    public void transform(Exchange exchange) throws SILException {
        try {
            SILLogger.debug(ClientServiceConstants.GET_CUSTOMER_BY_PRODUCT_LOGGING_FORMAT, className, "Entering transform()");
            GetEmployerResponseType inboundResponse = exchange.getIn().getBody(GetEmployerResponseType.class);
            if (inboundResponse != null) {
                GetCustomerByProductDetails outboundResponse = new GetCustomerByProductDetails();
                createOutboundResponse(outboundResponse, inboundResponse, exchange);
                exchange.setProperty(ClientServiceConstants.GET_CUSTOMER_BY_PRODUCT_RESPONSE, outboundResponse);
                Response response = Response.status(Response.Status.OK).entity(outboundResponse).build();
                exchange.getIn().setBody(response);
            } else {
                exchange.setProperty(ClientServiceConstants.STOP_ROUTE, CommonConstants.FLAG_Y);
            }
            SILLogger.debug(ClientServiceConstants.GET_CUSTOMER_BY_PRODUCT_LOGGING_FORMAT, className, "Exiting transform()");
        } catch (Exception excp) {
            throw new SILException(ClientServiceConstants.GET_CUSTOMER_BY_PRODUCT_GENERIC_MSG);
        }
    }

    /**
     * create outbound response.
     * 
     * @param outboundResponse
     * @param inboundResponse
     * @param exchange
     * @throws SILException
     */
    private void createOutboundResponse(GetCustomerByProductDetails outboundResponse, GetEmployerResponseType inboundResponse, Exchange exchange)
            throws SILException {
        if (inboundResponse.getClientDetails() != null) {
            ClientServiceUtil clientServiceUtil = new ClientServiceUtil();
            outboundResponse.setCustomerId(clientServiceUtil.retrieveLongValue(inboundResponse.getClientDetails().getId()));
            outboundResponse.setName(clientServiceUtil.retrieveStringValue(inboundResponse.getClientDetails().getSurname()));
            outboundResponse.setEntityType((String) exchange.getProperty(ClientServiceConstants.ENTITY_TYPE_PROPERTY_TAG));
            outboundResponse.setTitle(CommonConstants.EMPTY_STRING_VALUE);
            outboundResponse.setOtherName(CommonConstants.EMPTY_STRING_VALUE);
            outboundResponse.setError(clientServiceUtil
                    .retrieveErrorDetailsSuccessfulScenario(ClientServiceConstants.GET_CUSTOMER_BY_PRODUCT_LOGGING_FORMAT));
        }
    }
}
