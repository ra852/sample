////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package com.suncorp.ssp.service.transformation.clientservice;

import javax.ws.rs.core.Response;

import org.apache.camel.Exchange;

import com.sonatacentral.service.v30.common.client.SaveClientResponseType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.clientservice.ClientServiceConstants;
import com.suncorp.ssp.service.integration.clientservice.bean.SaveClientResponse;
import com.suncorp.ssp.service.integration.clientservice.util.SaveClientDetailsUtil;

/**
 * The class {@code SaveClientResponseTransformer} transforms the response to required format for end client.
 * 
 * @author U383847
 * @since 29/10/2015
 * @version 1.0
 */
public class SaveClientResponseTransformer {
    private final String className = "SaveClientResponseTransformer";

    /**
     * Extracts the values from external service's response, to forward to the end client.
     * 
     * @param exchange of type Exchange
     * @throws Exception of type Exception
     */
    public void transform(Exchange exchange) throws SILException {
        try {
            SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Entering transform method");
            SaveClientResponseType saveClientResponseType = exchange.getIn().getBody(SaveClientResponseType.class);
            SaveClientResponse saveClientResponse = new SaveClientResponse();
            SaveClientDetailsUtil saveClientDetailsUtil = new SaveClientDetailsUtil(saveClientResponseType);
            saveClientDetailsUtil.saveClientResponse(saveClientResponse);
            Response response = Response.status(Response.Status.OK).entity(saveClientResponse).build();
            exchange.getIn().setBody(response);
            SILLogger.debug(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, "Exiting transform method");
        } catch (Exception exception) {
            SILLogger.error(ClientServiceConstants.SAVE_CLIENT_LOGGING_FORMAT, className, SILUtil.getReqExMsg(exception));
            throw new SILException(ClientServiceConstants.SAVE_CLIENT_EXCEPTION_MESSAGE);
        }
    }
}
