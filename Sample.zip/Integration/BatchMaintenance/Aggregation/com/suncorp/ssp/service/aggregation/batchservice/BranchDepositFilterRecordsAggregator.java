////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.aggregation.batchservice;

import java.util.ArrayList;
import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.processor.aggregate.AggregationStrategy;

import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.batchservice.BatchServiceConstants;
import com.suncorp.ssp.service.integration.batchservice.bean.branchdeposit.BranchDepositFilterRecordsModelBean;
import com.suncorp.ssp.service.integration.batchservice.bean.branchdeposit.BranchDepositRecordOrder;

/**
 * The class {@code BranchDepositFilterRecordsAggregator} is a Aggregator class used to aggregate the oldExchange and newExchange.
 * 
 * @author U385424
 * @since 25/10/2016
 * @version 1.0
 */
public class BranchDepositFilterRecordsAggregator implements AggregationStrategy {
    private final String className = "BranchDepositFilterRecordsAggregator";

    /**
     * Aggregate the old and new exchange, put order together in old exchange by adding the order from new exchange.
     * 
     * @param oldExchange
     * @param newExchange
     * @return exchange
     */
    @Override
    public Exchange aggregate(Exchange oldExchange, Exchange newExchange) {
        SILLogger.debug(BatchServiceConstants.BRANCH_DEPOSIT_FILTER_RECORDS_LOGGING_FORMAT, className, "Entering aggregate()");
        List<BranchDepositFilterRecordsModelBean> outputList = null;

        if (oldExchange == null) {
            // the first time we aggregate we only have the new exchange, so we just return it.
            return newExchange;
        }
        outputList =
                (List<BranchDepositFilterRecordsModelBean>) oldExchange.getProperty("outputList") != null ? 
                        (List<BranchDepositFilterRecordsModelBean>) oldExchange.getProperty("outputList")
                        : new ArrayList<BranchDepositFilterRecordsModelBean>();
        BranchDepositRecordOrder depositDetailRecord = (BranchDepositRecordOrder) newExchange.getProperty("depositDetailRecord");
        if (CommonConstants.FLAG_Y.equalsIgnoreCase((String) newExchange.getProperty("IsValidRecord"))) {
            BranchDepositFilterRecordsModelBean outputDetail = new BranchDepositFilterRecordsModelBean();
            outputDetail.setBranchDepositRecordOrder(depositDetailRecord);
            outputList.add(outputDetail);
            oldExchange.setProperty("outputList", outputList);
            oldExchange.setProperty("outputListSize", outputList.size());
        }
        SILLogger.debug(BatchServiceConstants.BRANCH_DEPOSIT_FILTER_RECORDS_LOGGING_FORMAT, className, "Exiting aggregate()");
        return oldExchange;
    }
}
