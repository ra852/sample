////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.batchservice.bean;

import java.util.List;

/**
 * The class {@code BranchDepositWorkFlowRequestBean} is a java bean consisting of properties related to Branch deposit record details.
 * 
 * @author U387938
 * @since 19/04/2016
 * @version 1.0
 */

public class BranchDepositWorkFlowRequestBean {

    private List<BranchDepositWorkFlowDataBean> lstWorkFlowDataBeans;
    private BranchDepositWorkFlowDataBean branchDepositWorkFlowDataBean;

    /**
     * Accessor for property lstWorkFlowDataBeans.
     * 
     * @return lstWorkFlowDataBeans of type List<BranchDepositWorkFlowDataBean>
     */
    public List<BranchDepositWorkFlowDataBean> getLstWorkFlowDataBeans() {
        return lstWorkFlowDataBeans;
    }

    /**
     * Mutator for property lstWorkFlowDataBeans.
     * 
     * @param lstWorkFlowDataBeans of type List<BranchDepositWorkFlowDataBean>
     */
    public void setLstWorkFlowDataBeans(List<BranchDepositWorkFlowDataBean> lstWorkFlowDataBeans) {
        this.lstWorkFlowDataBeans = lstWorkFlowDataBeans;
    }

    /**
     * Accessor for property branchDepositWorkFlowDataBean.
     * 
     * @return branchDepositWorkFlowDataBean of type BranchDepositWorkFlowDataBean
     */
    public BranchDepositWorkFlowDataBean getBranchDepositWorkFlowDataBean() {
        return branchDepositWorkFlowDataBean;
    }

    /**
     * Mutator for property branchDepositWorkFlowDataBean.
     * 
     * @param branchDepositWorkFlowDataBean of type BranchDepositWorkFlowDataBean
     */
    public void setBranchDepositWorkFlowDataBean(BranchDepositWorkFlowDataBean branchDepositWorkFlowDataBean) {
        this.branchDepositWorkFlowDataBean = branchDepositWorkFlowDataBean;
    }

}
