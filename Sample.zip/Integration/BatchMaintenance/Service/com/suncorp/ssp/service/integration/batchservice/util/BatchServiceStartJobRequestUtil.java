////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.batchservice.util;

import java.math.BigInteger;
import java.util.List;

import com.sonatacentral.service.v30.callerdetails.CallerDetails;
import com.sonatacentral.service.v30.common.system.StartJobRequestType;
import com.sonatacentral.service.v30.common.system.StartJobRequestType.ParameterSet;
import com.sonatacentral.service.v30.common.system.StartJobRequestType.ParameterSet.Value;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CodeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.system.jobgrouptype.ReportDefinitionIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.system.jobgrouptype.ReportParameterIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.system.jobgrouptype.ReportParameterViewIdentifierType;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.batchservice.BatchServiceConstants;

/**
 * The class {@code BatchServiceStartJobRequestUtil} is a Utility class with all the properties related to Branch deposit functionality, to construct
 * request for external system by extracting values from the end-client's request object.
 * 
 * @author U387938
 * @since 08/04/2016
 * @version 1.0
 */
public class BatchServiceStartJobRequestUtil {
    private final String className = "BatchServiceStartJobRequestUtil";
    private StartJobRequestType outboundRequest;
    private String filePathName;

    /**
     * Initializes the instance variable UploadBpayResponseBean with the one passed to the constructor.
     * 
     * @param inboundRequest of type String
     */
    public BatchServiceStartJobRequestUtil(String filePathName) {
        this.filePathName = filePathName;
        this.outboundRequest = new StartJobRequestType();
    }
    
    /**
     * Create Caller Details.
     * 
     * @param logFormat
     */
    private void createCallerDetails(String logFormat) {
        SILLogger.debug(logFormat, className, "Entering createCallerDetails()");
        CallerDetails callerDetails = SILUtil.createCallerDetails();
        if (callerDetails != null) {
            this.outboundRequest.setCallerDetails(callerDetails);
        }
        SILLogger.debug(logFormat, className, "Entering createCallerDetails()");
    }

    /**
     * 
     * Returns the outbound request object after setting the parameters.
     * 
     * @param logFormat
     * @return StartJobRequestType
     */
    public StartJobRequestType createOutboundRequest(String logFormat) {
        SILLogger.debug(logFormat, className, "Entering createOutboundRequest()");
        createCallerDetails(logFormat);
        
        this.outboundRequest.setJobDefinition(createJobDefinition(logFormat));
        this.outboundRequest.getParameterSet().add(setParamater(logFormat));

        SILLogger.debug(logFormat, className, "Exiting createOutboundRequest()");
        return this.outboundRequest;
    }

    /**
     * Returns a new instance of ReportDefinitionIdentifierType, with necessary values set.
     * 
     * @return jobDefinition of type ReportDefinitionIdentifierType
     */
    public ReportDefinitionIdentifierType createJobDefinition(String logFormat) {
        SILLogger.debug(logFormat, className, "Entering createJobDefinition()");
        ReportDefinitionIdentifierType jobDefinition = new ReportDefinitionIdentifierType();
        jobDefinition.setId(Long.valueOf(BatchServiceConstants.START_JOB_REPORT_DEFINATION_ID));
        jobDefinition.setName(BatchServiceConstants.BATCH_SERVICE_VALUE_BATCH_UPLOAD);
        jobDefinition.setSystemCode(createCodeIdentifierType(BatchServiceConstants.BATCH_SERVICE_VALUE_UNIT,
                BatchServiceConstants.BATCH_SERVICE_VALUE_SYTY, logFormat));
        SILLogger.debug(logFormat, className, "Exiting createJobDefinition()");
        return jobDefinition;
    }


    /**
     * 
     * This method constructs Parameter object.
     * 
     * @return ParameterSet
     */
    public ParameterSet setParamater(String logFormat) {
        SILLogger.debug(logFormat, className, "Entering setParamater()");
        ParameterSet parameterSet = new ParameterSet();
        ReportParameterIdentifierType parameterIdentifierType = new ReportParameterIdentifierType();
        parameterIdentifierType.setId(Long.valueOf(BatchServiceConstants.START_JOB_PARAMETER_IDENTIFIER_ID));
        ReportDefinitionIdentifierType reportDefinitionIdentifierType = new ReportDefinitionIdentifierType();
        reportDefinitionIdentifierType.setName(BatchServiceConstants.BATCH_SERVICE_VALUE_BATCH_UPLOAD);

        reportDefinitionIdentifierType.setSystemCode(createCodeIdentifierType(BatchServiceConstants.BATCH_SERVICE_VALUE_UNIT,
                BatchServiceConstants.BATCH_SERVICE_VALUE_SYTY, logFormat));
        parameterIdentifierType.setReportDefinition(reportDefinitionIdentifierType);
        ReportParameterViewIdentifierType parameterViewIdentifierType = new ReportParameterViewIdentifierType();
        parameterViewIdentifierType.setId(Long.valueOf(BatchServiceConstants.START_JOB_VIEWIDENTIFIER_ID));
        parameterIdentifierType.setParameterView(parameterViewIdentifierType);
        parameterIdentifierType.setParameterOrder(new BigInteger(BatchServiceConstants.START_JOB_PARAMETER_ORDER));
        parameterSet.setParameter(parameterIdentifierType);
        parameterSet.setValue(createValue(logFormat, this.filePathName));
        SILLogger.debug(logFormat, className, "Exiting setParamater()");
        return parameterSet;
    }

    /**
     * 
     * This method constructs CodeIdentifier object.
     * 
     * @param code
     * @param codeType
     * @return CodeIdentifierType
     */
    public CodeIdentifierType createCodeIdentifierType(String code, String codeType, String logFormat) {
        SILLogger.debug(logFormat, className, "Entering createCodeIdentifierType()");
        CodeIdentifierType codeIdentifierType = new CodeIdentifierType();
        codeIdentifierType.setCode(code);
        codeIdentifierType.setCodeType(codeType);
        SILLogger.debug(logFormat, className, "Exiting createCodeIdentifierType()");
        return codeIdentifierType;
    }

    /***
     * 
     * This method constructs Value object.
     * 
     * @return Value
     */
    public Value createValue(String logFormat, String target) {
        SILLogger.debug(logFormat, className, "Entering createValue()");
        Value value = new Value();
        value.setStringValue(target);
        SILLogger.debug(logFormat, className, "Exiting createValue()");
        return value;
    }

    /**
     * Returns the outbound request object after setting the parameters for Asset Allocation.
     * 
     * @param logFormat
     * @return
     */
    public StartJobRequestType createAssetAllocationOutboundRequest(String logFormat) {
        SILLogger.debug(logFormat, className, "Entering createAssetAllocationOutboundRequest()");
        createCallerDetails(logFormat);

        this.outboundRequest.setJobDefinition(createAssetAllocationJobDefinition(logFormat));
        setAssetAllocationParameters(logFormat);

        SILLogger.debug(logFormat, className, "Exiting createAssetAllocationOutboundRequest()");
        return this.outboundRequest;
    }

    /**
     * Create Asset Allocation Job Definition parameters for outbound request.
     * 
     * @param logFormat
     * @return
     */
    public ReportDefinitionIdentifierType createAssetAllocationJobDefinition(String logFormat) {
        SILLogger.debug(logFormat, className, "Entering createAssetAllocationJobDefinition()");
        ReportDefinitionIdentifierType jobDefinition = new ReportDefinitionIdentifierType();
        jobDefinition.setId(Long.valueOf(BatchServiceConstants.ASSET_ALLOCATION_START_JOB_DEFINITION_ID));
        jobDefinition.setName(BatchServiceConstants.ASSET_ALLOCATION_START_JOB_DEFINITION_NAME);
        SILLogger.debug(logFormat, className, "Exiting createAssetAllocationJobDefinition()");
        return jobDefinition;
    }

    /**
     * Sets Asset Allocation parameters for outbound request.
     * 
     * @param logFormat
     */
    public void setAssetAllocationParameters(String logFormat) {
        List<StartJobRequestType.ParameterSet> parameterSet = this.outboundRequest.getParameterSet();
        parameterSet.add(setAssetAllocationSourceParameter(logFormat));
        parameterSet.add(setAssetAllocationTargetParameter(logFormat));
    }

    /**
     * Sets Asset Allocation source parameter for outbound request.
     * 
     * @param logFormat
     * @return
     */
    public ParameterSet setAssetAllocationSourceParameter(String logFormat) {
        SILLogger.debug(logFormat, className, "Entering setAssetAllocationSourceParameter()");
        ParameterSet parameterSet = new ParameterSet();
        ReportParameterIdentifierType parameterIdentifierType = new ReportParameterIdentifierType();
        parameterIdentifierType.setId(Long.valueOf(BatchServiceConstants.ASSET_ALLOCATION_START_JOB_SOURCE_PARAMETER_ID));
        parameterIdentifierType.setName(BatchServiceConstants.ASSET_ALLOCATION_START_JOB_SOURCE_PARAMETER_NAME);
        ReportDefinitionIdentifierType reportDefinitionIdentifierType = new ReportDefinitionIdentifierType();
        reportDefinitionIdentifierType.setName(BatchServiceConstants.ASSET_ALLOCATION_START_JOB_REPORT_PARAMETER_NAME);
        reportDefinitionIdentifierType.setSystemCode(createCodeIdentifierType(BatchServiceConstants.ASSET_ALLOCATION_SYSTEM_PARAMETER_CODE,
                BatchServiceConstants.ASSET_ALLOCATION_SYSTEM_PARAMETER_CODE_TYPE, logFormat));
        parameterIdentifierType.setReportDefinition(reportDefinitionIdentifierType);
        ReportParameterViewIdentifierType parameterViewIdentifierType = new ReportParameterViewIdentifierType();
        parameterViewIdentifierType.setId(Long.valueOf(BatchServiceConstants.ASSET_ALLOCATION_SOURCE_PARAMETER_VIEW_ID));
        parameterViewIdentifierType.setName(BatchServiceConstants.ASSET_ALLOCATION_SOURCE_PARAMETER_VIEW_NAME);
        parameterIdentifierType.setParameterView(parameterViewIdentifierType);
        parameterIdentifierType.setParameterOrder(new BigInteger(BatchServiceConstants.ASSET_ALLOCATION_SOURCE_PARAMETER_ORDER));
        parameterSet.setParameter(parameterIdentifierType);
        parameterSet.setValue(createValue(logFormat, this.filePathName));
        SILLogger.debug(logFormat, className, "Exiting setAssetAllocationSourceParameter()");
        return parameterSet;
    }

    /**
     * Sets Asset Allocation target parameter for outbound request.
     * 
     * @param logFormat
     * @return
     */
    public ParameterSet setAssetAllocationTargetParameter(String logFormat) {
        SILLogger.debug(logFormat, className, "Entering setAssetAllocationTargetParameter()");
        ParameterSet parameterSet = new ParameterSet();
        ReportParameterIdentifierType parameterIdentifierType = new ReportParameterIdentifierType();
        parameterIdentifierType.setId(Long.valueOf(BatchServiceConstants.ASSET_ALLOCATION_START_JOB_TARGET_PARAMETER_ID));
        parameterIdentifierType.setName(BatchServiceConstants.ASSET_ALLOCATION_START_JOB_TARGET_PARAMETER_NAME);
        ReportDefinitionIdentifierType reportDefinitionIdentifierType = new ReportDefinitionIdentifierType();
        reportDefinitionIdentifierType.setName(BatchServiceConstants.ASSET_ALLOCATION_START_JOB_REPORT_PARAMETER_NAME);
        reportDefinitionIdentifierType.setSystemCode(createCodeIdentifierType(BatchServiceConstants.ASSET_ALLOCATION_SYSTEM_PARAMETER_CODE,
                BatchServiceConstants.ASSET_ALLOCATION_SYSTEM_PARAMETER_CODE_TYPE, logFormat));
        parameterIdentifierType.setReportDefinition(reportDefinitionIdentifierType);
        ReportParameterViewIdentifierType parameterViewIdentifierType = new ReportParameterViewIdentifierType();
        parameterViewIdentifierType.setId(Long.valueOf(BatchServiceConstants.ASSET_ALLOCATION_TARGET_PARAMETER_VIEW_ID));
        parameterViewIdentifierType.setName(BatchServiceConstants.ASSET_ALLOCATION_TARGET_PARAMETER_VIEW_NAME);
        parameterIdentifierType.setParameterView(parameterViewIdentifierType);
        parameterIdentifierType.setParameterOrder(new BigInteger(BatchServiceConstants.ASSET_ALLOCATION_TARGET_PARAMETER_ORDER));
        parameterSet.setParameter(parameterIdentifierType);
        parameterSet.setValue(createValue(logFormat, BatchServiceConstants.ASSET_ALLOCATION_SONATA_ARCHIVE_FOLDER));
        SILLogger.debug(logFormat, className, "Exiting setAssetAllocationTargetParameter()");
        return parameterSet;
    }

}
