////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.batchservice.bean;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.suncorp.ssp.common.bean.SILErrorMessage;

/**
 * The class {@code BranchDepositResponseBean} is a java bean consisting of all the properties related to Branch deposit functionality, to be used for
 * constructing response for end-client.
 * 
 * @author U387938
 * @since 08/04/2016
 * @version 1.0
 */
@XmlRootElement(name = "BranchDepositResponseBean")
public class BranchDepositResponseBean extends SILErrorMessage {
    private String queueId;

    /**
     * Accessor for property codes.
     * 
     * @return queueId of type String
     */
    public String getQueueId() {
        return queueId != null ? queueId : "";
    }

    /**
     * Mutator for property codes.
     * 
     * @return queueId of type String
     */
    @XmlElement(name = "queueId")
    public void setQueueId(String queueId) {
        this.queueId = queueId;
    }
}
