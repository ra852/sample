////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.batchservice.bean.branchdeposit;

import org.apache.camel.dataformat.bindy.annotation.CsvRecord;
import org.apache.camel.dataformat.bindy.annotation.Link;





/**
 * The class {@code BranchDepositHeaderRecord} does this.
 * 
 * @author U385424
 * @since 28/10/2016
 * @version 1.0
 */
@CsvRecord(separator = ",")
public class BranchDepositFilterRecordsModelBean {

    @Link
    private BranchDepositHeaderRecord branchDepositHeaderRecord;

    @Link
    private BranchDepositRecordOrder branchDepositRecordOrder;

    /**
     * Accessor for property branchDepositHeaderRecord.
     * 
     * @return branchDepositHeaderRecord of type BranchDepositHeaderRecord
     */
    public BranchDepositHeaderRecord getBranchDepositHeaderRecord() {
        return branchDepositHeaderRecord;
    }

    /**
     * Mutator for property branchDepositHeaderRecord.
     * 
     * @param branchDepositHeaderRecord of type BranchDepositHeaderRecord
     */
    public void setBranchDepositHeaderRecord(BranchDepositHeaderRecord branchDepositHeaderRecord) {
        this.branchDepositHeaderRecord = branchDepositHeaderRecord;
    }

    /**
     * Accessor for property branchDepositRecordOrder.
     * 
     * @return branchDepositRecordOrder of type BranchDepositRecordOrder
     */
    public BranchDepositRecordOrder getBranchDepositRecordOrder() {
        return branchDepositRecordOrder;
    }

    /**
     * Mutator for property branchDepositRecordOrder.
     * 
     * @param branchDepositRecordOrder of type BranchDepositRecordOrder
     */
    public void setBranchDepositRecordOrder(BranchDepositRecordOrder branchDepositRecordOrder) {
        this.branchDepositRecordOrder = branchDepositRecordOrder;
    }

}
