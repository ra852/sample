////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.batchservice.bean.bankstatement;

import java.math.BigDecimal;

import org.apache.camel.dataformat.bindy.annotation.CsvRecord;
import org.apache.camel.dataformat.bindy.annotation.DataField;

/**
 * The class {@code BankStatementHeaderRecord} is a java bean consisting of properties related to Bank Statement CSV file header record details.
 * 
 * @author U383847
 * @since 19/04/2016
 * @version 1.0
 */
@CsvRecord(separator = ",")
public class BankStatementHeaderRecord {

    @DataField(pos = 1)
    private String headerRecordType;

    @DataField(pos = 2)
    private Integer recordCount;

    @DataField(pos = 3, precision = 2)
    private BigDecimal totalAmount;

    /**
     * Accessor for property headerRecordType.
     * 
     * @return headerRecordType of type String
     */
    public String getHeaderRecordType() {
        return headerRecordType;
    }

    /**
     * Mutator for property headerRecordType.
     * 
     * @param headerRecordType of type String
     */
    public void setHeaderRecordType(String headerRecordType) {
        this.headerRecordType = headerRecordType;
    }

    /**
     * Accessor for property recordCount.
     * 
     * @return recordCount of type Integer
     */
    public Integer getRecordCount() {
        return recordCount;
    }

    /**
     * Mutator for property recordCount.
     * 
     * @param recordCount of type Integer
     */
    public void setRecordCount(Integer recordCount) {
        this.recordCount = recordCount;
    }

    /**
     * Accessor for property totalAmount.
     * 
     * @return totalAmount of type BigDecimal
     */
    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    /**
     * Mutator for property totalAmount.
     * 
     * @param totalAmount of type BigDecimal
     */
    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }
}
