////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.batchservice.bean;

import org.apache.camel.Exchange;

import com.suncorp.ssp.service.constants.batchservice.BatchServiceConstants;

/**
 * The class {@code EmailDetails} does this.
 * 
 * @author U384380
 * @since 10/03/2017
 * @version 1.0
 */
public class EmailDetails {

    private String fromEmailId;
    private String toEmailId;

    /**
     * Accessor for property fromEmaild.
     * 
     * @return fromEmaild of type String
     */
    public String getFromEmailId() {
        return fromEmailId;
    }

    /**
     * Mutator for property fromEmaild.
     * 
     * @return fromEmaild of type String
     */
    public void setFromEmailId(String fromEmailId) {
        this.fromEmailId = fromEmailId;
    }

    /**
     * Accessor for property toEmailId.
     * 
     * @return toEmailId of type String
     */
    public String getToEmailId() {
        return toEmailId;
    }

    /**
     * Mutator for property toEmailId.
     * 
     * @return toEmailId of type String
     */
    public void setToEmailId(String toEmailId) {
        this.toEmailId = toEmailId;
    }

    public void setProperties(Exchange exchange) {
        exchange.setProperty(BatchServiceConstants.FROM_EMAIL_ID, this.fromEmailId);
        exchange.setProperty(BatchServiceConstants.TO_EMAIL_ID, this.toEmailId);
    }

}
