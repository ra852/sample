////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.batchservice.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import com.sonatacentral.service.v30.globaltypes.workflow.workflowgrouptype.WorkflowDataType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.batchservice.BatchServiceConstants;

/**
 * The class {@code BatchServiceUtil} is the common util for batch services.
 * 
 * @author u387938
 * @since 23/04/2016
 * @version 1.0
 */
public class BatchServiceUtil {

    private final String className = "BatchServiceUtil";

    /**
     * Creates WorkflowDataType object for String Type values and adds it to sonata's DataPool List.
     * 
     * @param tagName of type String
     * @param tagValue of type String
     */
    public void createWorkflowDataTypeForString(String tagName, String tagValue, List<WorkflowDataType> outboundWorkflowDataTypeList, String logger)
            throws SILException {
        SILLogger.debug(logger, className, "Entering createWorkflowDataTypeForString()");
        if (tagValue != null) {
            WorkflowDataType workflowDataType = createWorkflowDataType(tagName, logger);
            workflowDataType.setStringValue(tagValue);
            outboundWorkflowDataTypeList.add(workflowDataType);
        }
        SILLogger.debug(logger, className, "Exiting createWorkflowDataTypeForString()");
    }

    /**
     * Creates WorkflowDataType object for String Type values and adds it to sonata's DataPool List.
     * 
     * @param tagName of type String
     * @param tagValue of type String
     */
    public void createWorkflowDataTypeForStringDate(String tagName, String tagValue, List<WorkflowDataType> outboundWorkflowDataTypeList,
            String logger) throws SILException {
        SILLogger.debug(logger, className, "Entering createWorkflowDataTypeForString()");
        if (tagValue != null) {
            WorkflowDataType workflowDataType = createWorkflowDataType(tagName, logger);
            workflowDataType.setStringValue(dateFormatter(tagValue, logger));
            outboundWorkflowDataTypeList.add(workflowDataType);
        }
        SILLogger.debug(logger, className, "Exiting createWorkflowDataTypeForString()");
    }

    /**
     * Creates WorkflowDataType object for Long Type values and adds it to sonata's DataPool List.
     * 
     * @param tagName of type String
     * @param tagValue of type String
     */
    public void createWorkflowDataTypeForLong(String tagName, String tagValue, List<WorkflowDataType> outboundWorkflowDataTypeList, String logger)
            throws SILException {
        SILLogger.debug(logger, className, "Entering addDateValueToList()");
        if (tagValue != null) {
            WorkflowDataType workflowDataType = createWorkflowDataType(tagName, logger);
            workflowDataType.setLongValue(Long.parseLong(tagValue));
            outboundWorkflowDataTypeList.add(workflowDataType);
        }
        SILLogger.debug(logger, className, "Exiting addDateValueToList()");
    }

    /**
     * 
     * Create date feild in the required format.
     * 
     * @param inputDate
     * @return
     * @throws SILException
     */
    public String dateFormatter(String inputDate, String logger) throws SILException {
        String ouputDate = null;
        SimpleDateFormat inputDateFormat = new SimpleDateFormat(BatchServiceConstants.DATE_FORMAT_YYYYMMDD);
        SimpleDateFormat outputDateFormat = new SimpleDateFormat(BatchServiceConstants.DATE_FORMAT_DDMMYYYY);
        try {
            ouputDate = outputDateFormat.format(inputDateFormat.parse(inputDate));
        } catch (ParseException e) {
            SILLogger.error(logger, className, "Invalid date passed");
            throw new SILException(BatchServiceConstants.INVALID_DATE_FORMAT);
        }
        return ouputDate;

    }

    /**
     * Returns a new WorkflowDataType instance with tagName already set.
     * 
     * @param tagName of type String
     * 
     * @return workflowDataType of type WorkflowDataType
     */
    public WorkflowDataType createWorkflowDataType(String tagName, String logger) throws SILException {
        SILLogger.debug(logger, className, "Entering createWorkflowDataType()");
        WorkflowDataType workflowDataType = new WorkflowDataType();
        workflowDataType.setTagName(tagName);
        SILLogger.debug(logger, className, "Exiting createWorkflowDataType()");
        return workflowDataType;
    }

}
