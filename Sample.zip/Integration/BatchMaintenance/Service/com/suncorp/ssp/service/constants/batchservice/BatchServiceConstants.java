////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.constants.batchservice;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * The class {@code BatchServiceConstants} does this.
 * 
 * @author u383847
 * @since 12/04/2016
 * @version 1.0
 */
public abstract class BatchServiceConstants {

    public static final String START_JOB_OPERATION_NAMESPACE = "http://www.sonatacentral.com/service/v30/common/system";
    public static final String START_JOB_OPERATION_NAME = "startJob";
    public static final String START_WORKFLOW_OPERATION_NAMESPACE = "http://www.sonatacentral.com/service/v30/workflow";
    public static final String START_WORKFLOW_OPERATION_NAME = "startWorkflow";
    public static final String BATCH_SERVICE_VALUE_UNIT = "UNIT";
    public static final String BATCH_SERVICE_VALUE_SYTY = "SYTY";
    public static final String TRG_WF_RESP_CNAME = "com.suncorp.ssp.service.integration.batchservice.bean.TriggerWorkflowResponseBean";
    public static final String BATCH_SERVICE_VALUE_BATCH_UPLOAD = "Batch Upload Receipts";
    public static final String MEMBER_EMPLOYER_WORKFLOW_NAME = "SUN_BPAYMEMP_M";
    public static final String EMPLOYER_WORKFLOW_NAME = "SUN_BPAYEMPP_M";
    public static final String RECEIPT_DATE_TAG_NAME = "receiptDate";
    public static final String RECEIPT_NUMBER_TAG_NAME = "receiptNumber";
    public static final String DOLLAR_AMOUNT_TAG_NAME = "dollarAmount";
    public static final String BILLER_CODE_TAG_NAME = "billerCode";
    public static final String DATE_FORMAT_YYYYMMDD = "yyyyMMdd";
    public static final String DATE_FORMAT_DDMMYYYY = "dd/MM/yyyy";
    public static final String INVALID_DATE_FORMAT = "Invalid date. Please provide a valid date.";
    public static final String START_WORK_FLOW_GENERIC_MSG = "StartWorkflow functionality could not get processed.";
    public static final String START_WORKFLOW_RESPONSE_ERROR_MSG = "TriggerWorkflow response could not be processed.";
    public static final String START_JOB_VIEWIDENTIFIER_ID = "7";
    public static final String START_JOB_PARAMETER_ORDER = "5";
    public static final String START_JOB_PARAMETER_IDENTIFIER_ID = "150990";
    public static final String START_JOB_REPORT_DEFINATION_ID = "150335";
    public static final String WORK_FLOW_STARTEVENTCODE = "Start";
    public static final String LOGGER_CLASS_TYPE = "loggerClassType";
    public static final String TRIGGER_WORKFLOW_FILERECEIVED = "FileReceived";

    // BankStatement Constants
    public static final String BANK_STATEMENT_TRANSFORMATION_LOGGING_FORMAT = "BankStatementTransformation_{}_".concat(
            new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat("_{}");
    public static final String BANK_STATEMENT_WORKFLOW_LOGGING_FORMAT = "BankStatementWorkflow_{}_".concat(
            new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat("_{}");
    public static final String BANK_STATEMENT_RESPONSE_CLASS = "com.suncorp.ssp.service.integration.batchservice.bean.BankStatementResponse";
    public static final String START_JOB_RESPONSE_CLASS = "com.suncorp.ssp.service.integration.batchservice.bean.StartJobResponse";
    public static final String START_WORKFLOW_RESPONSE_CLASS = "com.suncorp.ssp.service.integration.batchservice.bean.BankStatementWorkflowResponse";
    public static final String NEGATIVE_SIGN = "-";
    public static final String EMPTY_STRING_VALUE = "";
    public static final String INITIAL_RECORD_TYPE_VALUE = "#BRS#";
    public static final String FILE_HEADER_RECORD_TYPE_VALUE = "01";
    public static final String ACCOUNT_HEADER_RECORD_TYPE_VALUE = "02";
    public static final String ACCOUNT_RECORD_TYPE_VALUE = "03";
    public static final String TRANSACTION_RECORD_TYPE_VALUE = "05";
    public static final String ACCOUNT_TRALIER_RECORD_TYPE_VALUE = "07";
    public static final String DELETE_ACCOUNT_RECORD_TYPE_VALUE = "90";
    public static final String FILE_TRALIER_RECORD_TYPE_VALUE = "99";
    public static final String FINAL_RECORD_TYPE_VALUE = "#END#";
    public static final String OTC_TRANSACTION_RECORD_TYPE_VALUE = "OTC";
    public static final String TRANSACTION_RECORD_TYPE_CODE = "510";
    public static final String HEADER_RECORD_TYPE_VALUE = "1";
    public static final String DETAIL_RECORD_TYPE_VALUE = "2";
    public static final String BANK_ACCOUNT_NUMBER = "032016559980";
    public static final String DIRECT_CREDIT_CODE_TYPE_VALUE = "DIRC";
    public static final String RECEIPT_CONVERSION_RATE_VALUE = "1";
    public static final String RECEIPT_PREFIX_LETTER = "S";
    public static final String BANK_STATEMENT_CSV_FILE_NAME = "bankStatementFileName";
    public static final String REGEX_BANK_STATEMENT_FILENAME_PATTERN = "P_[A-Za-z]+_\\d{8}_\\d{6}\\.txt"; // P_SMTBankStat_20160518_060000.txt
    public static final String REGEX_BANK_STATEMENT_CSV_FILENAME_PATTERN = "S\\d{8}.csv"; // SYYYYMMDD.csv
    public static final String BANK_STATEMENT_SONATA_INBOUND_FOLDER = "/sonata/SonataFileTransfer/WestpacBank/SuncorpMTBankStatement/";

    public static final String JULIAN_DATE_FORMAT = "yyyyDDD";
    public static final String ISO_DATE_FORMAT = "yyyyMMdd";

    public static final String SEQUENCE_NUMBER_ONE_ZERO = "0";
    public static final String SEQUENCE_NUMBER_TWO_ZERO = "00";
    public static final String SEQUENCE_NUMBER_THREE_ZERO = "000";

    public static final String BILLER_CODE = "4038";
    public static final String MEMBER_BILLER_CODE = "40390";
    public static final String EMPLOYER_BILLER_CODE = "40384";

    public static final String BANK_STAT_WF_PERSIST_REQ_OBJECT = "BANK_STAT_WF_PERSIST_REQ_OBJECT";

    public static final String NO_CONTENT_FILE_EXCEPTION = "Exception Occurred as File has no content";
    public static final String FILE_STRIP_EXCEPTION = "Exception Occurred During File Stripping";
    public static final String GENERATE_PAYMENT_REFERENCE_EXCEPTION = "Exception Occurred During Payment Reference Generation";
    public static final String GENERATE_SEQUENCE_NUMBER_EXCEPTION = "Exception Occurred During Sequence Number Generation";
    public static final String GENERATE_RECEIPT_NUMBER_EXCEPTION = "Exception Occurred During Receipt Number Generation";
    public static final String JULIAN_DATE_CONVERSION_PARSE_EXCEPTION = "Exception Occurred During Julian Date Conversion";
    public static final String WORKFLOW_DATE_CONVERSION_PARSE_EXCEPTION = "Exception Occurred During Workflow Date Conversion";
    public static final String NO_BILLER_CODE_RECORDS_GENERIC_EXCEPTION = "Biller Code Records are not there for processing";
    public static final String BANK_STATEMENT_TRANSFORM_GENERIC_EXCEPTION = "Bank Statement Transformation functionality could not get processed";
    public static final String BANK_STATEMENT_BILLER_CODE_GENERIC_EXCEPTION = "Bank Statement Biller Code functionality could not get processed";
    public static final String BANK_STATEMENT_STARTJOB_GENERIC_EXCEPTION = "Bank Statement StartJob functionality could not get processed";
    public static final String BANK_STATEMENT_STARTJOB_RESPONSE_EXCEPTION = "Bank Statement StartJob Response could not get processed";
    public static final String BANK_STATEMENT_WORKFLOW_GENERIC_EXCEPTION = "Bank Statement Workflow functionality could not get processed";
    public static final String BANK_STATEMENT_WORKFLOW_RESPONSE_ERROR_MSG = "Bank Statement TriggerWorkflow response could not be processed.";
    public static final String BANK_STATEMENT_MAX_LIMIT_MSG = "Bank Statement records exceeds sequence numbers limit (9999).";

    // Branch Deposit Constants
    public static final String BRANCH_DEPOSIT_LOGGING_FORMAT = "BranchDeposit_{}_".concat(
            new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat("_{}");
    public static final String BRANCH_DEPOSIT_RESP_CNAME = "com.suncorp.ssp.service.integration.batchservice.bean.BranchDepositResponseBean";
    public static final String BRANCH_DEPOSIT_REQUEST_NOT_PROCESSED = "BranchDeposit request could not be processed.";
    public static final String BRANCH_DEPOSIT_RESPONSE_NOT_PROCESSED = "BranchDeposit response could not be processed.";
    public static final String BRANCH_DEPOSIT_SONATA_INBOUND_FOLDER = "/sonata/SonataFileTransfer/Suncorp/BranchDeposit/";
    public static final String BRANCH_DEPOSIT_VALUE_UNIT = "UNIT";
    public static final String BRANCH_DEPOSIT_VALUE_SYTY = "SYTY";
    public static final String BRANCH_DEPOSIT_PARAM_VALUE = "Westpac BPAY";
    public static final String BRANCH_DEPOSIT_FILE_TYPE = "BPAY File Type";
    public static final String BRANCH_DEPOSIT_FILE_LOAD = "BPAY File Load";
    public static final String REGEX_BRANCH_DEPOSIT_FILENAME_PATTERN = "B\\d{8}\\.csv";
    public static final String BRANCH_DEPOSIT_CSV_PARSE_ERROR = "Error received while branch deposit csv file parsing";
    public static final String ACCOUNT_NUMBER_TAG_NAME = "accntNbr";
    public static final String BRANCH_DEPT_INFO_TAG_NAME = "branchDepInfo";
    public static final String BRANCH_DEPOSIT_TRIGGER_WORKFLOW_LIST = "triggerWorkFlowlst";
    public static final String BRANCH_DEPOSIT_TRIGGER_WORKFLOW_SIZE = "noOfWorkflows";
    public static final String[] BRANCH_DEPOSIT_CSV_HEADER = { "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16",
            "17", "18" };
    public static final String BRANCH_DEPOSIT_WORKFLOW_NAME = "SUN_AUTOMTCH_M";
    public static final String WEST_PAC_ID_TAG_NAME = "westpacId";

    // Asset Allocation Constants
    public static final String ASSET_ALLOCATION_FILEUPLOAD_LOGGING_FORMAT = "AssetAllocationFileUpload_{}_".concat(
            new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat("_{}");
    public static final String REGEX_ASSET_ALLOCATION_FILE_PATTERN = "\\d{8}\\_Sonata_Asset_Allocation.csv"; // 20160726_Sonata_Asset_Allocation.csv
    public static final String ASSET_ALLOCATION_SONATA_INBOUND_FOLDER = "/sonata/SonataFileTransfer/AssetAllocation/";
    public static final String ASSET_ALLOCATION_SONATA_ARCHIVE_FOLDER = "/sonata/SonataFileTransfer/AssetAllocation/Archive/";
    public static final String ASSET_ALLOCATION_START_JOB_DEFINITION_ID = "151469";
    public static final String ASSET_ALLOCATION_START_JOB_DEFINITION_NAME = "Asset Allocation Upload";
    public static final String ASSET_ALLOCATION_START_JOB_SOURCE_PARAMETER_ID = "153420";
    public static final String ASSET_ALLOCATION_START_JOB_SOURCE_PARAMETER_NAME = "Select file to Import";
    public static final String ASSET_ALLOCATION_START_JOB_REPORT_PARAMETER_NAME = "Asset Allocation Upload";
    public static final String ASSET_ALLOCATION_SYSTEM_PARAMETER_CODE = "UNIT";
    public static final String ASSET_ALLOCATION_SYSTEM_PARAMETER_CODE_TYPE = "15";
    public static final String ASSET_ALLOCATION_SOURCE_PARAMETER_VIEW_ID = "7";
    public static final String ASSET_ALLOCATION_SOURCE_PARAMETER_VIEW_NAME = "Select File Name";
    public static final String ASSET_ALLOCATION_SOURCE_PARAMETER_ORDER = "5";
    public static final String ASSET_ALLOCATION_START_JOB_TARGET_PARAMETER_ID = "153421";
    public static final String ASSET_ALLOCATION_TARGET_PARAMETER_VIEW_ID = "140020";
    public static final String ASSET_ALLOCATION_TARGET_PARAMETER_VIEW_NAME = "Save To Folder";
    public static final String ASSET_ALLOCATION_TARGET_PARAMETER_ORDER = "10";
    public static final String ASSET_ALLOCATION_START_JOB_TARGET_PARAMETER_NAME = "Select the destination to move the file after processing";
    public static final String ASSET_ALLOCATION_STARTJOB_GENERIC_EXCEPTION = "Asset Allocation StartJob functionality could not be processed.";

    // Common Fund Fee Constants
    public static final String COMMON_FUND_FEE_LOGGING_FORMAT = "CommonFundFee_{}_".concat(
            new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat("_{}");
    public static final String REGEX_COMMON_FUND_FEE_FILE_PATTERN = "\\d{8}\\_CommonFundFee.csv"; // YYYYMMDD_CommonFundFee.csv
    public static final String COMMON_FUND_FEE_SONATA_INBOUND_FOLDER = "/sonata/SonataFileTransfer/CommonFundFee/";
    public static final String COMMON_FUND_FEE_SONATA_ARCHIVE_FOLDER = "/sonata/SonataFileTransfer/CommonFundFee/Archive";
    public static final String COMMON_FUND_FEE_JOB_DEF_ID = "150179";
    public static final String COMMON_FUND_FEE_JOB_DEF_NAME = "Upload Common Fund Fee Rates";
    public static final String COMMON_FUND_FEE_JOB_DEF_SYS_CODE = "UNIT";
    public static final String COMMON_FUND_FEE_JOB_DEF_SYS_CODE_TYPE = "SYTY";
    public static final String COMMON_FUND_FEE_PARAM_ID = "150496";
    public static final String COMMON_FUND_FEE_PARAM_NAME = "Select the Name of the file holding the rate information";
    public static final String COMMON_FUND_FEE_REP_DEF_NAME = "Upload Common Fund Fee Rates";
    public static final String COMMON_FUND_FEE_REP_DEF_SYS_CODE = "UNIT";
    public static final String COMMON_FUND_FEE_REP_DEF_SYS_CODE_TYPE = "SYTY";
    public static final String COMMON_FUND_FEE_PARAM_VIEW_ID = "7";
    public static final String COMMON_FUND_FEE_PARAM_ORDER = "5";
    public static final String COMMON_FUND_FEE_GENERIC_EXCEPTION = "Common Fund Fee functionality could not be processed.";
    public static final String COMMON_FUND_FEE_QUEUE_ID = "COMMON_FUND_FEE_QUEUE_ID";
    
  //BranchDeposit filter Records
    public static final String BRANCH_DEPOSIT_FILTER_RECORDS_LOGGING_FORMAT = "BranchDepositFilterRecords_{}_".concat(
            new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat("_{}");
    public static final String REGEX_BRANCH_DEPOSIT_FILTER_RECORDS_FILENAME_PATTERN = "B\\d{8}\\_Full\\.csv";
    public static final String VALID_RECORD_FLAG = "IsValidRecord";
    public static final String SONATA_CODE_INACTIVE_ACCOUNT = "ESTO";
    public static final String VALUE_ONE = "1";
    public static final String FILTERED_RECORD_OUTPUT_FILENAME = "branchDepositFilteredOutputFileName";
    
    //Email parameter details
    public static final String EMAIL_FAILURE_DESCRIPTION = "Processing of one or more records have been failed";
    public static final String EMAIL_TO = "To";
    public static final String EMAIL_FROM = "From";
    public static final String EMAIL_SUBJECT_DESC = "Subject";
    public static final String EMAIL_FAILURE_DATE_TIME = " Date Timestamp: ";
    public static final String INPUT_FILE_NAME = "File name :";
    public static final String EMAIL_DESCRIPTION = "Description : ";
    public static final String FROM_EMAIL_ID = "fromEmailId";
    public static final String TO_EMAIL_ID = "toEmailId";
    public static final String EMAIL_SUBJECT = "emailSubject";
    public static final String EMAIL_PROCESSING_LOGGING_FORMAT = "EmailProcessing_{}_".concat(
            new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat("_{}");;

}
