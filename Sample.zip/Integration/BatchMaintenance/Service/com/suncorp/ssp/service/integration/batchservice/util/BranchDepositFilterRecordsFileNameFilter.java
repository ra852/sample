////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.batchservice.util;

import org.apache.camel.component.file.GenericFile;
import org.apache.camel.component.file.GenericFileFilter;

import com.suncorp.ssp.service.constants.batchservice.BatchServiceConstants;

/**
 * The class {@code BranchDepositFilterRecordsFileNameFilter} is used to pick the specific file which matches the REGEX.
 *
 * @author U385424
 * @since 07/11/2016
 * @version 1.0
 */
public class BranchDepositFilterRecordsFileNameFilter<T> implements GenericFileFilter<T> {

    /**
     * Checks whether the file name matches the pattern.
     * 
     * @param file of type GenericFile&lt;T&gt;
     * @return boolean
     */
    @Override
    public boolean accept(GenericFile<T> file) {
        return file.getFileName().matches(BatchServiceConstants.REGEX_BRANCH_DEPOSIT_FILTER_RECORDS_FILENAME_PATTERN);
    }

}
