////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.batchservice.bean;

import java.util.ArrayList;
import java.util.List;

import com.suncorp.ssp.common.bean.SILErrorMessage;
import com.suncorp.ssp.service.integration.batchservice.bean.bankstatement.BankStatementDetailRecord;

/**
 * The class {@code BankStatementWorkflowResponse} is used as response bean for TriggerWorkflow operation for BankStatement.
 *
 * @author U383847
 * @since 29/04/2016
 * @version 1.0
 */
public class BankStatementWorkflowResponse extends SILErrorMessage {
    private List<BankStatementDetailRecord> bankStatementDetailRecordList;

    /**
     * Accessor for property bankStatementDetailRecordList.
     *
     * @return bankStatementDetailRecordList of type List<BankStatementDetailRecord>
     */
    public List<BankStatementDetailRecord> getBankStatementDetailRecordList() {
        if (bankStatementDetailRecordList == null) {
            bankStatementDetailRecordList = new ArrayList<BankStatementDetailRecord>();
        }
        return bankStatementDetailRecordList;
    }
}
