////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.batchservice.bean;

import com.suncorp.ssp.common.bean.SILErrorMessage;

/**
 * The class {@code StartJobResponse} does this.
 *
 * @author U383847
 * @since 27/04/2016
 * @version 1.0
 */
public class StartJobResponse extends SILErrorMessage {
    
    private String queueId;

    /**
     * Accessor for property queueId.
     *
     * @return queueId of type String
     */
    public String getQueueId() {
        return queueId;
    }

    /**
     * Mutator for property queueId.
     *
     * @param queueId of type String
     */
    public void setQueueId(String queueId) {
        this.queueId = queueId;
    }
}
