////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.batchservice.bean;

import java.util.List;

import com.suncorp.ssp.service.integration.batchservice.bean.bankstatement.BankStatementDetailRecord;

/**
 * The class {@code BankStatementStartWorkflowRequest} does this.
 *
 * @author U383847
 * @since 29/04/2016
 * @version 1.0
 */
public class BankStatementStartWorkflowRequest {
    
    private List<BankStatementDetailRecord> bankStatementDetailRecordList;
    private BankStatementDetailRecord bankStatementDetailRecord;
    /**
     * Accessor for property bankStatementDetailRecordList.
     *
     * @return bankStatementDetailRecordList of type List<BankStatementDetailRecord>
     */
    public List<BankStatementDetailRecord> getBankStatementDetailRecordList() {
        return bankStatementDetailRecordList;
    }
    /**
     * Mutator for property bankStatementDetailRecordList.
     *
     * @param bankStatementDetailRecordList of type List<BankStatementDetailRecord>
     */
    public void setBankStatementDetailRecordList(List<BankStatementDetailRecord> bankStatementDetailRecordList) {
        this.bankStatementDetailRecordList = bankStatementDetailRecordList;
    }
    /**
     * Accessor for property bankStatementDetailRecord.
     *
     * @return bankStatementDetailRecord of type BankStatementDetailRecord
     */
    public BankStatementDetailRecord getBankStatementDetailRecord() {
        return bankStatementDetailRecord;
    }
    /**
     * Mutator for property bankStatementDetailRecord.
     *
     * @param bankStatementDetailRecord of type BankStatementDetailRecord
     */
    public void setBankStatementDetailRecord(BankStatementDetailRecord bankStatementDetailRecord) {
        this.bankStatementDetailRecord = bankStatementDetailRecord;
    }
    
    
    
    
}
