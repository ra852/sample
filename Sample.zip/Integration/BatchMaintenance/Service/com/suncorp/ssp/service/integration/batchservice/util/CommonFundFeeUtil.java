////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.batchservice.util;

import java.math.BigInteger;

import com.sonatacentral.service.v30.callerdetails.CallerDetails;
import com.sonatacentral.service.v30.common.system.StartJobRequestType;
import com.sonatacentral.service.v30.common.system.StartJobRequestType.ParameterSet;
import com.sonatacentral.service.v30.common.system.StartJobRequestType.ParameterSet.Value;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CodeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.system.jobgrouptype.ReportDefinitionIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.system.jobgrouptype.ReportParameterIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.system.jobgrouptype.ReportParameterViewIdentifierType;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.batchservice.BatchServiceConstants;

/**
 * The class {@code CommonFundFeeUtil} is used to construct request for common fund fee.
 * 
 * @author U383754
 * @since 02/11/2016
 * @version 1.0
 */
public class CommonFundFeeUtil {
    private String className = "CommonFundFeeUtil";
    private StartJobRequestType outboundRequest;
    private String logFormat;
    private String fileName;

    /**
     * Constructor.
     */
    public CommonFundFeeUtil(String fileName, String logFormat) {
        this.fileName = fileName;
        this.logFormat = logFormat;
        this.outboundRequest = new StartJobRequestType();
    }

    /**
     * This method is used to create request for Common Fund Fee.
     * 
     * @param loggingFormat
     * @return
     */
    public StartJobRequestType createCommonFundFeeRequest() {
        SILLogger.debug(this.logFormat, className, "Entering createCommonFundFeeRequest()");
        createCallerDetails();

        this.outboundRequest.setJobDefinition(createJobDefinition());
        this.outboundRequest.getParameterSet().add(createParameterSet());

        SILLogger.debug(this.logFormat, className, "Exiting createCommonFundFeeRequest()");
        return this.outboundRequest;
    }

    /**
     * This method is used to create Parameter set.
     * 
     * @return
     */
    private ParameterSet createParameterSet() {
        SILLogger.debug(this.logFormat, className, "Entering createParameterSet()");
        ParameterSet parameterSet = new ParameterSet();
        parameterSet.setParameter(createParameter());
        parameterSet.setValue(createValue());
        SILLogger.debug(this.logFormat, className, "Exiting createParameterSet()");
        return parameterSet;
    }

    /**
     * This method is used to create Value.
     * 
     * @return
     */
    private Value createValue() {
        SILLogger.debug(this.logFormat, className, "Entering createValue()");
        Value value = new Value();
        value.setStringValue(BatchServiceConstants.COMMON_FUND_FEE_SONATA_INBOUND_FOLDER + this.fileName);
        SILLogger.debug(this.logFormat, className, "Exiting createValue()");
        return value;
    }

    /**
     * This method is used to create the parameter.
     * 
     * @return
     */
    private ReportParameterIdentifierType createParameter() {
        SILLogger.debug(this.logFormat, className, "Entering createParameter()");
        ReportParameterIdentifierType identifierType = new ReportParameterIdentifierType();
        identifierType.setId(Long.parseLong(BatchServiceConstants.COMMON_FUND_FEE_PARAM_ID));
        identifierType.setName(BatchServiceConstants.COMMON_FUND_FEE_PARAM_NAME);
        identifierType.setReportDefinition(createReportDefinition());
        identifierType.setParameterView(createParameterView());
        identifierType.setParameterOrder(BigInteger.valueOf(Long.parseLong(BatchServiceConstants.COMMON_FUND_FEE_PARAM_ORDER)));
        SILLogger.debug(this.logFormat, className, "Exiting createParameter()");
        return identifierType;
    }

    /**
     * This method is used to create Parameter View.
     * 
     * @return
     */
    private ReportParameterViewIdentifierType createParameterView() {
        SILLogger.debug(this.logFormat, className, "Entering createParameterView()");
        ReportParameterViewIdentifierType identifierType = new ReportParameterViewIdentifierType();
        identifierType.setId(Long.parseLong(BatchServiceConstants.COMMON_FUND_FEE_PARAM_VIEW_ID));
        SILLogger.debug(this.logFormat, className, "Exiting createParameterView()");
        return identifierType;
    }

    /**
     * This method is used to create the Report Definition.
     * 
     * @return
     */
    private ReportDefinitionIdentifierType createReportDefinition() {
        SILLogger.debug(this.logFormat, className, "Entering createReportDefinition()");
        ReportDefinitionIdentifierType identifierType = new ReportDefinitionIdentifierType();
        identifierType.setName(BatchServiceConstants.COMMON_FUND_FEE_REP_DEF_NAME);
        identifierType.setSystemCode(createReportSystemCode());
        SILLogger.debug(this.logFormat, className, "Exiting createReportDefinition()");
        return identifierType;
    }

    /**
     * This method is used to create System Code.
     * 
     * @return
     */
    private CodeIdentifierType createReportSystemCode() {
        SILLogger.debug(this.logFormat, className, "Entering createReportSystemCode()");
        CodeIdentifierType identifierType = new CodeIdentifierType();
        identifierType.setCode(BatchServiceConstants.COMMON_FUND_FEE_REP_DEF_SYS_CODE);
        identifierType.setCodeType(BatchServiceConstants.COMMON_FUND_FEE_REP_DEF_SYS_CODE_TYPE);
        SILLogger.debug(this.logFormat, className, "Exiting createReportSystemCode()");
        return identifierType;
    }

    /**
     * This method is used to create Job definition for Common Fund Fee.
     * 
     * @return
     */
    private ReportDefinitionIdentifierType createJobDefinition() {
        SILLogger.debug(this.logFormat, className, "Entering createJobDefinition()");
        ReportDefinitionIdentifierType identifierType = new ReportDefinitionIdentifierType();
        identifierType.setId(Long.parseLong(BatchServiceConstants.COMMON_FUND_FEE_JOB_DEF_ID));
        identifierType.setName(BatchServiceConstants.COMMON_FUND_FEE_JOB_DEF_NAME);
        identifierType.setSystemCode(createSystemCode());
        SILLogger.debug(this.logFormat, className, "Exiting createJobDefinition()");
        return identifierType;
    }

    /**
     * This method is used to create the system code.
     * 
     * @return
     */
    private CodeIdentifierType createSystemCode() {
        SILLogger.debug(this.logFormat, className, "Entering createSystemCode()");
        CodeIdentifierType identifierType = new CodeIdentifierType();
        identifierType.setCode(BatchServiceConstants.COMMON_FUND_FEE_JOB_DEF_SYS_CODE);
        identifierType.setCodeType(BatchServiceConstants.COMMON_FUND_FEE_JOB_DEF_SYS_CODE_TYPE);
        SILLogger.debug(this.logFormat, className, "Exiting createSystemCode()");
        return identifierType;
    }

    /**
     * Create Caller Details.
     * 
     */
    private void createCallerDetails() {
        SILLogger.debug(this.logFormat, className, "Entering createCallerDetails()");
        CallerDetails callerDetails = SILUtil.createCallerDetails();
        if (callerDetails != null) {
            this.outboundRequest.setCallerDetails(callerDetails);
        }
        SILLogger.debug(this.logFormat, className, "Exiting createCallerDetails()");
    }
}
