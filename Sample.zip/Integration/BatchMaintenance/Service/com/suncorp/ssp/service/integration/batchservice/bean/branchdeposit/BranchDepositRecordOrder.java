////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.batchservice.bean.branchdeposit;

import java.math.BigDecimal;
import java.math.BigInteger;

import org.apache.camel.dataformat.bindy.annotation.CsvRecord;
import org.apache.camel.dataformat.bindy.annotation.DataField;

/**
 * The class {@code BranchDepositRecordOrder} does this.
 * 
 * @author U385424
 * @since 25/10/2016
 * @version 1.0
 */
@CsvRecord(separator = ",")
public class BranchDepositRecordOrder {

    @DataField(pos = 1)
    private String detailRecordType;

    @DataField(pos = 2)
    private String employeeNumber;

    @DataField(pos = 3, precision = 2)
    private BigDecimal receiptAmount;

    @DataField(pos = 4)
    private String paymentReference;

    @DataField(pos = 5)
    private String accountNumber;

    @DataField(pos = 6)
    private String bankAccount;

    @DataField(pos = 7)
    private BigInteger effectiveDate;

    @DataField(pos = 8)
    private BigInteger dateBanked;

    @DataField(pos = 9)
    private String toCurrencyCode;

    @DataField(pos = 10)
    private String depositTypeCode;

    @DataField(pos = 11)
    private String chequeBSB;

    @DataField(pos = 12)
    private String chequeBankAccountNumber;

    @DataField(pos = 13)
    private String chequeAccountName;

    @DataField(pos = 14)
    private String chequeNumber;

    @DataField(pos = 15)
    private String receiptNumber;

    @DataField(pos = 16)
    private String fromCurrencyCode;

    @DataField(pos = 17)
    private String receiptConversionRate;

    @DataField(pos = 18)
    private String reference;

    /**
     * Accessor for property detailRecordType.
     * 
     * @return detailRecordType of type String
     */
    public String getDetailRecordType() {
        return detailRecordType;
    }

    /**
     * Mutator for property detailRecordType.
     * 
     * @param detailRecordType of type String
     */
    public void setDetailRecordType(String detailRecordType) {
        this.detailRecordType = detailRecordType;
    }

    /**
     * Accessor for property employeeNumber.
     * 
     * @return employeeNumber of type String
     */
    public String getEmployeeNumber() {
        return employeeNumber;
    }

    /**
     * Mutator for property employeeNumber.
     * 
     * @param employeeNumber of type String
     */
    public void setEmployeeNumber(String employeeNumber) {
        this.employeeNumber = employeeNumber;
    }

    /**
     * Accessor for property receiptAmount.
     * 
     * @return receiptAmount of type BigDecimal
     */
    public BigDecimal getReceiptAmount() {
        return receiptAmount;
    }

    /**
     * Mutator for property receiptAmount.
     * 
     * @param receiptAmount of type BigDecimal
     */
    public void setReceiptAmount(BigDecimal receiptAmount) {
        this.receiptAmount = receiptAmount;
    }

    /**
     * Accessor for property paymentReference.
     * 
     * @return paymentReference of type String
     */
    public String getPaymentReference() {
        return paymentReference;
    }

    /**
     * Mutator for property paymentReference.
     * 
     * @param paymentReference of type String
     */
    public void setPaymentReference(String paymentReference) {
        this.paymentReference = paymentReference;
    }

    /**
     * Accessor for property accountNumber.
     * 
     * @return accountNumber of type String
     */
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * Mutator for property accountNumber.
     * 
     * @param accountNumber of type String
     */
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    /**
     * Accessor for property bankAccount.
     * 
     * @return bankAccount of type String
     */
    public String getBankAccount() {
        return bankAccount;
    }

    /**
     * Mutator for property bankAccount.
     * 
     * @param bankAccount of type String
     */
    public void setBankAccount(String bankAccount) {
        this.bankAccount = bankAccount;
    }

    /**
     * Accessor for property effectiveDate.
     * 
     * @return effectiveDate of type BigInteger
     */
    public BigInteger getEffectiveDate() {
        return effectiveDate;
    }

    /**
     * Mutator for property effectiveDate.
     * 
     * @param effectiveDate of type BigInteger
     */
    public void setEffectiveDate(BigInteger effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    /**
     * Accessor for property dateBanked.
     * 
     * @return dateBanked of type BigInteger
     */
    public BigInteger getDateBanked() {
        return dateBanked;
    }

    /**
     * Mutator for property dateBanked.
     * 
     * @param dateBanked of type BigInteger
     */
    public void setDateBanked(BigInteger dateBanked) {
        this.dateBanked = dateBanked;
    }

    /**
     * Accessor for property toCurrencyCode.
     * 
     * @return toCurrencyCode of type String
     */
    public String getToCurrencyCode() {
        return toCurrencyCode;
    }

    /**
     * Mutator for property toCurrencyCode.
     * 
     * @param toCurrencyCode of type String
     */
    public void setToCurrencyCode(String toCurrencyCode) {
        this.toCurrencyCode = toCurrencyCode;
    }

    /**
     * Accessor for property depositTypeCode.
     * 
     * @return depositTypeCode of type String
     */
    public String getDepositTypeCode() {
        return depositTypeCode;
    }

    /**
     * Mutator for property depositTypeCode.
     * 
     * @param depositTypeCode of type String
     */
    public void setDepositTypeCode(String depositTypeCode) {
        this.depositTypeCode = depositTypeCode;
    }

    /**
     * Accessor for property chequeBSB.
     * 
     * @return chequeBSB of type String
     */
    public String getChequeBSB() {
        return chequeBSB;
    }

    /**
     * Mutator for property chequeBSB.
     * 
     * @param chequeBSB of type String
     */
    public void setChequeBSB(String chequeBSB) {
        this.chequeBSB = chequeBSB;
    }

    /**
     * Accessor for property chequeBankAccountNumber.
     * 
     * @return chequeBankAccountNumber of type String
     */
    public String getChequeBankAccountNumber() {
        return chequeBankAccountNumber;
    }

    /**
     * Mutator for property chequeBankAccountNumber.
     * 
     * @param chequeBankAccountNumber of type String
     */
    public void setChequeBankAccountNumber(String chequeBankAccountNumber) {
        this.chequeBankAccountNumber = chequeBankAccountNumber;
    }

    /**
     * Accessor for property chequeAccountName.
     * 
     * @return chequeAccountName of type String
     */
    public String getChequeAccountName() {
        return chequeAccountName;
    }

    /**
     * Mutator for property chequeAccountName.
     * 
     * @param chequeAccountName of type String
     */
    public void setChequeAccountName(String chequeAccountName) {
        this.chequeAccountName = chequeAccountName;
    }

    /**
     * Accessor for property chequeNumber.
     * 
     * @return chequeNumber of type String
     */
    public String getChequeNumber() {
        return chequeNumber;
    }

    /**
     * Mutator for property chequeNumber.
     * 
     * @param chequeNumber of type String
     */
    public void setChequeNumber(String chequeNumber) {
        this.chequeNumber = chequeNumber;
    }

    /**
     * Accessor for property receiptNumber.
     * 
     * @return receiptNumber of type String
     */
    public String getReceiptNumber() {
        return receiptNumber;
    }

    /**
     * Mutator for property receiptNumber.
     * 
     * @param receiptNumber of type String
     */
    public void setReceiptNumber(String receiptNumber) {
        this.receiptNumber = receiptNumber;
    }

    /**
     * Accessor for property fromCurrencyCode.
     * 
     * @return fromCurrencyCode of type String
     */
    public String getFromCurrencyCode() {
        return fromCurrencyCode;
    }

    /**
     * Mutator for property fromCurrencyCode.
     * 
     * @param fromCurrencyCode of type String
     */
    public void setFromCurrencyCode(String fromCurrencyCode) {
        this.fromCurrencyCode = fromCurrencyCode;
    }

    /**
     * Accessor for property receiptConversionRate.
     * 
     * @return receiptConversionRate of type String
     */
    public String getReceiptConversionRate() {
        return receiptConversionRate;
    }

    /**
     * Mutator for property receiptConversionRate.
     * 
     * @param receiptConversionRate of type String
     */
    public void setReceiptConversionRate(String receiptConversionRate) {
        this.receiptConversionRate = receiptConversionRate;
    }

    /**
     * Accessor for property reference.
     * 
     * @return reference of type String
     */
    public String getReference() {
        return reference;
    }

    /**
     * Mutator for property reference.
     * 
     * @param reference of type String
     */
    public void setReference(String reference) {
        this.reference = reference;
    }
}
