////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.batchservice.bean;

/**
 * The class {@code BranchDepositWorkFlowDataBean} is a java bean consisting of properties related to Branch deposit record details.
 * 
 * @author U387938
 * @since 19/04/2016
 * @version 1.0
 */

public class BranchDepositWorkFlowDataBean {

    private String accountNumber;
    private String reference;
    private String effectiveDate;
    private String receiptNumber;
    private String transactionAmount;

    /**
     * Accessor for property accountNumber.
     * 
     * @return accountNumber of type String
     */
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * Mutator for property accountNumber.
     * 
     * @param accountNumber of type String
     */
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    /**
     * Accessor for property reference.
     * 
     * @return reference of type String
     */
    public String getReference() {
        return reference;
    }

    /**
     * Mutator for property reference.
     * 
     * @param reference of type String
     */
    public void setReference(String reference) {
        this.reference = reference;
    }

    /**
     * Accessor for property receiptNumber.
     * 
     * @return receiptNumber of type String
     */
    public String getReceiptNumber() {
        return receiptNumber;
    }

    /**
     * Mutator for property receiptNumber.
     * 
     * @param receiptNumber of type String
     */
    public void setReceiptNumber(String receiptNumber) {
        this.receiptNumber = receiptNumber;
    }

    /**
     * Accessor for property effectiveDate.
     * 
     * @return effectiveDate of type String
     */
    public String getEffectiveDate() {
        return effectiveDate;
    }

    /**
     * Mutator for property effectiveDate.
     * 
     * @param effectiveDate of type String
     */
    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    /**
     * Accessor for property transactionAmount.
     * 
     * @return transactionAmount of type String
     */
    public String getTransactionAmount() {
        return transactionAmount;
    }

    /**
     * Mutator for property transactionAmount.
     * 
     * @param transactionAmount of type String
     */
    public void setTransactionAmount(String transactionAmount) {
        this.transactionAmount = transactionAmount;
    }

}
