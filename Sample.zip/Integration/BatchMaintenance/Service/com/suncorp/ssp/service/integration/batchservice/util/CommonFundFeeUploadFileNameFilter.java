////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.batchservice.util;

import org.apache.camel.component.file.GenericFile;
import org.apache.camel.component.file.GenericFileFilter;

import com.suncorp.ssp.service.constants.batchservice.BatchServiceConstants;

/**
 * The class {@code CommonFundFeeUploadFileNameFilter} is used as a filter class for Common Fund Fee.
 * 
 * @author U383847
 * @since 05/08/2016
 * @version 1.0
 */
public class CommonFundFeeUploadFileNameFilter<T> implements GenericFileFilter<T> {

    /**
     * Checks whether the file name matches the pattern.
     * 
     * @param file of type GenericFile&lt;T&gt;
     * @return boolean
     */
    @Override
    public boolean accept(GenericFile<T> file) {
        return file.getFileName().matches(BatchServiceConstants.REGEX_COMMON_FUND_FEE_FILE_PATTERN);
    }
}
