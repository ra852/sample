////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.batchservice.bean.bankstatement;

import org.apache.camel.dataformat.bindy.annotation.CsvRecord;
import org.apache.camel.dataformat.bindy.annotation.Link;

/**
 * The class {@code BankStatementRecordOrder} does this.
 *
 * @author U383847
 * @since 23/04/2016
 * @version 1.0
 */
@CsvRecord(separator = ",")
public class BankStatementRecordOrder {

    @Link
    private BankStatementHeaderRecord headerRecord;
    
    @Link
    private BankStatementDetailRecord detailRecord;

    /**
     * Accessor for property headerRecord.
     *
     * @return headerRecord of type BankStatementHeaderRecord
     */
    public BankStatementHeaderRecord getHeaderRecord() {
        return headerRecord;
    }

    /**
     * Mutator for property headerRecord.
     *
     * @param headerRecord of type BankStatementHeaderRecord
     */
    public void setHeaderRecord(BankStatementHeaderRecord headerRecord) {
        this.headerRecord = headerRecord;
    }

    /**
     * Accessor for property detailRecord.
     *
     * @return detailRecord of type BankStatementDetailRecord
     */
    public BankStatementDetailRecord getDetailRecord() {
        return detailRecord;
    }

    /**
     * Mutator for property detailRecord.
     *
     * @param detailRecord of type BankStatementDetailRecord
     */
    public void setDetailRecord(BankStatementDetailRecord detailRecord) {
        this.detailRecord = detailRecord;
    }
}
