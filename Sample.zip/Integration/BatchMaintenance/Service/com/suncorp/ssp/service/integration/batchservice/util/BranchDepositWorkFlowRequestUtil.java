////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.batchservice.util;

import java.util.List;

import com.sonatacentral.service.v30.callerdetails.CallerDetails;
import com.sonatacentral.service.v30.globaltypes.workflow.workflowgrouptype.ProcessModelIdentifierType;
import com.sonatacentral.service.v30.globaltypes.workflow.workflowgrouptype.StartWorkflowType;
import com.sonatacentral.service.v30.globaltypes.workflow.workflowgrouptype.StartWorkflowType.DataPool;
import com.sonatacentral.service.v30.globaltypes.workflow.workflowgrouptype.WorkflowDataType;
import com.sonatacentral.service.v30.workflow.StartWorkflowRequestType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.batchservice.BatchServiceConstants;
import com.suncorp.ssp.service.integration.batchservice.bean.BranchDepositWorkFlowDataBean;
import com.suncorp.ssp.service.integration.batchservice.bean.BranchDepositWorkFlowRequestBean;

/**
 * The class {@code BranchDepositWorkFlowRequestUtil} is a Utility class with all the properties related to Branch deposit functionality, to construct
 * request for external system by extracting values from the end-client's request object.
 * 
 * @author U387938
 * @since 08/04/2016
 * @version 1.0
 */
public class BranchDepositWorkFlowRequestUtil {
    private final String className = "BranchDepositRequestUtil";
    private StartWorkflowRequestType outboundRequest;
    private BranchDepositWorkFlowRequestBean inboundRequest;
    private BranchDepositWorkFlowDataBean inboundWorkflowDataBean;
    private List<WorkflowDataType> outboundWorkflowDataTypeList;

    /**
     * Initializes the instance variable BranchDepositWorkFlowRequestUtil with the one passed to the constructor.
     * 
     * @param inboundRequest of type BranchDepositWorkFlowRequestBean
     */
    public BranchDepositWorkFlowRequestUtil(BranchDepositWorkFlowRequestBean inboundRequest) {
        SILLogger.debug(BatchServiceConstants.BRANCH_DEPOSIT_LOGGING_FORMAT, className, "Entering BranchDepositWorkFlowRequestUtil()");
        this.inboundRequest = inboundRequest;
        inboundWorkflowDataBean = inboundRequest.getBranchDepositWorkFlowDataBean();
        this.outboundRequest = new StartWorkflowRequestType();
        SILLogger.debug(BatchServiceConstants.BRANCH_DEPOSIT_LOGGING_FORMAT, className, "Exiting BranchDepositWorkFlowRequestUtil()");
    }

    /**
     * Returns the outbound request object after setting the parameters.
     * 
     * @return outboundRequest of type StartWorkflowRequestType
     * @throws SILException
     */
    public StartWorkflowRequestType createOutboundRequest() throws SILException {
        SILLogger.debug(BatchServiceConstants.BRANCH_DEPOSIT_LOGGING_FORMAT, className, "Entering createOutboundRequest()");
        if (this.inboundRequest != null) {
            CallerDetails callerDetails = SILUtil.createCallerDetails();
            StartWorkflowType startWorkflowType = createStartWorkflowType();
            if (callerDetails != null) {
                this.outboundRequest.setCallerDetails(callerDetails);
            }
            if (startWorkflowType != null) {
                this.outboundRequest.setWorkflow(startWorkflowType);
            }
        }
        SILLogger.debug(BatchServiceConstants.BRANCH_DEPOSIT_LOGGING_FORMAT, className, "Exiting createOutboundRequest()");
        return this.outboundRequest;
    }

    /**
     * 
     * Creates the woek flow request.
     * 
     * @return
     * @throws SILException
     */
    private StartWorkflowType createStartWorkflowType() throws SILException {
        SILLogger.debug(BatchServiceConstants.BRANCH_DEPOSIT_LOGGING_FORMAT, className, "Exiting createStartWorkflowType()");
        StartWorkflowType startWorkflowType = new StartWorkflowType();
        ProcessModelIdentifierType processModelIdentifierType = new ProcessModelIdentifierType();
        processModelIdentifierType.setCode(BatchServiceConstants.BRANCH_DEPOSIT_WORKFLOW_NAME);
        startWorkflowType.setProcessModel(processModelIdentifierType);
        startWorkflowType.setStartEventCode(BatchServiceConstants.WORK_FLOW_STARTEVENTCODE);
        startWorkflowType.setNewTransaction(true);
        startWorkflowType.setDataPool(createDataPool());
        SILLogger.debug(BatchServiceConstants.BRANCH_DEPOSIT_LOGGING_FORMAT, className, "Exiting createStartWorkflowType()");

        return startWorkflowType;
    }

    /**
     * Returns a new instance of {@code DataPool}, with necessary values set.
     * 
     * @return dataPool of type DataPool
     * @throws SILException
     */
    private DataPool createDataPool() throws SILException {
        SILLogger.debug(BatchServiceConstants.BRANCH_DEPOSIT_LOGGING_FORMAT, className, "Entering createDataPool()");
        DataPool dataPool = new DataPool();
        this.outboundWorkflowDataTypeList = dataPool.getData();
        addWorkflowDatatoOutboundRequest();
        SILLogger.debug(BatchServiceConstants.BRANCH_DEPOSIT_LOGGING_FORMAT, className, "Exiting createDataPool()");
        return dataPool;
    }

    /**
     * 
     * Create the WorkFlow block for the request.
     * 
     * @throws SILException
     */
    private void addWorkflowDatatoOutboundRequest() throws SILException {
        String logger = BatchServiceConstants.BRANCH_DEPOSIT_LOGGING_FORMAT;
        SILLogger.debug(logger, className, "Entering addWorkflowDatatoOutboundRequest()");
        BatchServiceUtil batchServiceUtil = new BatchServiceUtil();
        if (inboundRequest != null && inboundWorkflowDataBean != null) {
            SILLogger.debug(logger, className, "Entering addWorkflowDatatoOutboundRequest() inside if");
            createWorkFlowDataPool(logger, batchServiceUtil);
            SILLogger.debug(BatchServiceConstants.BRANCH_DEPOSIT_LOGGING_FORMAT, className, "Exiting addWorkflowDatatoOutboundRequest()");
        }
    }

    /**
     * This method creates the WorkFlow datapool for sonata request.
     *
     * @param logger
     * @param batchServiceUtil
     * @throws SILException
     */
    private void createWorkFlowDataPool(String logger, BatchServiceUtil batchServiceUtil) throws SILException {
        SILLogger.debug(logger, className, "Entering createWorkFlowDataPool()");
        if (inboundWorkflowDataBean.getAccountNumber() != null) {
            batchServiceUtil.createWorkflowDataTypeForLong(BatchServiceConstants.ACCOUNT_NUMBER_TAG_NAME,
                    inboundWorkflowDataBean.getAccountNumber(), this.outboundWorkflowDataTypeList, logger);
        }
        if (inboundWorkflowDataBean.getEffectiveDate() != null) {
            batchServiceUtil.createWorkflowDataTypeForStringDate(BatchServiceConstants.RECEIPT_DATE_TAG_NAME,
                    inboundWorkflowDataBean.getEffectiveDate(), this.outboundWorkflowDataTypeList, logger);
        }
        if (inboundWorkflowDataBean.getReceiptNumber() != null) {
            batchServiceUtil.createWorkflowDataTypeForString(BatchServiceConstants.WEST_PAC_ID_TAG_NAME,
                    inboundWorkflowDataBean.getReceiptNumber(), this.outboundWorkflowDataTypeList, logger);
        }
        if (inboundWorkflowDataBean.getReference() != null) {
            batchServiceUtil.createWorkflowDataTypeForString(BatchServiceConstants.BRANCH_DEPT_INFO_TAG_NAME,
                    inboundWorkflowDataBean.getReference(), this.outboundWorkflowDataTypeList, logger);
        }
        if (inboundWorkflowDataBean.getTransactionAmount() != null) {
            batchServiceUtil.createWorkflowDataTypeForString(BatchServiceConstants.DOLLAR_AMOUNT_TAG_NAME,
                    inboundWorkflowDataBean.getTransactionAmount(), this.outboundWorkflowDataTypeList, logger);
        }
        SILLogger.debug(logger, className, "Exiting createWorkFlowDataPool()");
    }

}
