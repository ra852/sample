////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.batchservice.bean;

import com.suncorp.ssp.common.bean.SILErrorMessage;

/**
 * The class {@code StartWorkflowResponse} is the bean used to for capturing start workflow response details.
 * 
 * @author u387938
 * @since 05/05/2016
 * @version 1.0
 */
public class StartWorkflowResponse extends SILErrorMessage {
    private String workflowId;
    private String workflowName;
    private String workflowReference;

    /**
     * Accessor for property workflowId.
     * 
     * @return workflowId of type String
     */
    public String getWorkflowId() {
        return workflowId;
    }

    /**
     * Mutator for property workflowId.
     * 
     * @param workflowId of type String
     */
    public void setWorkflowId(String workflowId) {
        this.workflowId = workflowId;
    }

    /**
     * Accessor for property workflowName.
     * 
     * @return workflowName of type String
     */
    public String getWorkflowName() {
        return workflowName;
    }

    /**
     * Mutator for property workflowName.
     * 
     * @param workflowName of type String
     */
    public void setWorkflowName(String workflowName) {
        this.workflowName = workflowName;
    }

    /**
     * Accessor for property workflowReference.
     * 
     * @return workflowReference of type String
     */
    public String getWorkflowReference() {
        return workflowReference;
    }

    /**
     * Mutator for property workflowReference.
     * 
     * @param workflowReference of type String
     */
    public void setWorkflowReference(String workflowReference) {
        this.workflowReference = workflowReference;
    }

}
