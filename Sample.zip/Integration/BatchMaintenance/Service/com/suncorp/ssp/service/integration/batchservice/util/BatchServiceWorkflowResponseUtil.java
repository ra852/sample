////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.batchservice.util;

import com.sonatacentral.service.v30.workflow.StartWorkflowResponseType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.integration.batchservice.bean.StartWorkflowResponse;

/**
 * The class {@code TriggerWorkflowResponseUtil} is used as a Utility class for preparing TriggerWorkflow's response.
 * 
 * @author U384381
 * @since 08/01/2016
 * @version 1.0
 */
public class BatchServiceWorkflowResponseUtil {
    private final String className = "BatchServiceWorkflowResponseUtil";

    /**
     * Displays Workflow Response details.
     * 
     * @return outboundResponse of type TriggerWorkflowResponseBean
     * @throws SILException
     */
    public void createOutboundResponse(StartWorkflowResponseType inboundResponse, String loggerClassType, StartWorkflowResponse startWorkflowResponse)
            throws SILException {
        if (inboundResponse != null && inboundResponse.getWorkflow().getWorkflow() != null) {
            SILLogger.info(loggerClassType, className, "Displaying Workflow Response details");
            if (inboundResponse.getWorkflow().getWorkflow().getId() != null) {
                startWorkflowResponse.setWorkflowId(String.valueOf(inboundResponse.getWorkflow().getWorkflow().getId()));
                SILLogger.info(loggerClassType, className, "Workflow ID " + String.valueOf(inboundResponse.getWorkflow().getWorkflow().getId()));
            }
            if (inboundResponse.getWorkflow().getWorkflow().getName() != null) {
                startWorkflowResponse.setWorkflowName(inboundResponse.getWorkflow().getWorkflow().getName());
                SILLogger.info(loggerClassType, className, "Workflow Name " + inboundResponse.getWorkflow().getWorkflow().getName());
            }
            if (inboundResponse.getWorkflow().getWorkflow().getReference() != null) {
                startWorkflowResponse.setWorkflowReference(inboundResponse.getWorkflow().getWorkflow().getReference());
                SILLogger.info(loggerClassType, className, "Workflow Reference " + inboundResponse.getWorkflow().getWorkflow().getReference());
            }
        }
    }
}
