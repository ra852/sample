////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.batchservice.util;

import java.util.List;

import com.sonatacentral.service.v30.callerdetails.CallerDetails;
import com.sonatacentral.service.v30.globaltypes.workflow.workflowgrouptype.ProcessModelIdentifierType;
import com.sonatacentral.service.v30.globaltypes.workflow.workflowgrouptype.StartWorkflowType;
import com.sonatacentral.service.v30.globaltypes.workflow.workflowgrouptype.StartWorkflowType.DataPool;
import com.sonatacentral.service.v30.globaltypes.workflow.workflowgrouptype.WorkflowDataType;
import com.sonatacentral.service.v30.workflow.StartWorkflowRequestType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.batchservice.BatchServiceConstants;
import com.suncorp.ssp.service.integration.batchservice.bean.BankStatementStartWorkflowRequest;
import com.suncorp.ssp.service.integration.batchservice.bean.bankstatement.BankStatementDetailRecord;

/**
 * The class {@code BankStatementWorkflowRequestUtil} is a Utility class to construct TriggerWorkflow request for BankStatement functionality.
 * 
 * @author U383847
 * @since 30/04/2016
 * @version 1.0
 */
public class BankStatementWorkflowRequestUtil {
    private final String className = "BankStatementWorkflowRequestUtil";
    private StartWorkflowRequestType outboundRequest;
    private BankStatementStartWorkflowRequest inboundRequest;
    private BankStatementDetailRecord bankStatementDetailRecord;
    private List<WorkflowDataType> outboundWorkflowDataTypeList;

    /**
     * Parameterized constructor for properties initialization.
     * 
     * @param inboundRequest of type BankStatementStartWorkflowRequest
     */
    public BankStatementWorkflowRequestUtil(BankStatementStartWorkflowRequest inboundRequest) {
        this.inboundRequest = inboundRequest;
        this.bankStatementDetailRecord = this.inboundRequest.getBankStatementDetailRecord();
        this.outboundRequest = new StartWorkflowRequestType();
    }

    /**
     * Creates Outbound Request.
     * 
     * @return
     * @throws SILException
     */
    public StartWorkflowRequestType createOutboundRequest() throws SILException {
        SILLogger.debug(BatchServiceConstants.BANK_STATEMENT_WORKFLOW_LOGGING_FORMAT, className, "Creating Outbound Request");
        if (this.inboundRequest != null) {
            CallerDetails callerDetails = SILUtil.createCallerDetails();
            StartWorkflowType startWorkflowType = createStartWorkflowType();
            if (callerDetails != null) {
                this.outboundRequest.setCallerDetails(callerDetails);
            }
            if (startWorkflowType != null) {
                this.outboundRequest.setWorkflow(startWorkflowType);
            }
        }
        return this.outboundRequest;
    }

    /**
     * Creates Start Workflow Type request.
     * 
     * @return
     * @throws SILException
     */
    private StartWorkflowType createStartWorkflowType() throws SILException {
        SILLogger.debug(BatchServiceConstants.BANK_STATEMENT_WORKFLOW_LOGGING_FORMAT, className, "Creating Start Workflow Type request");
        StartWorkflowType startWorkflowType = new StartWorkflowType();
        ProcessModelIdentifierType processModelIdentifierType = new ProcessModelIdentifierType();
        if (!getBillerCodeType().equals("")) {
            processModelIdentifierType.setCode(this.getBillerCodeType());
        }
        startWorkflowType.setProcessModel(processModelIdentifierType);
        startWorkflowType.setStartEventCode(BatchServiceConstants.WORK_FLOW_STARTEVENTCODE);
        startWorkflowType.setNewTransaction(true);
        startWorkflowType.setDataPool(createDataPool());

        return startWorkflowType;
    }

    /**
     * Gets Biller Code Type.
     * 
     * @return String
     */
    private String getBillerCodeType() {
        SILLogger.debug(BatchServiceConstants.BANK_STATEMENT_WORKFLOW_LOGGING_FORMAT, className, "Getting Biller Code Type");
        if (bankStatementDetailRecord.getReference() != null &&
                BatchServiceConstants.EMPLOYER_BILLER_CODE.equalsIgnoreCase(bankStatementDetailRecord.getReference())) {
            return BatchServiceConstants.EMPLOYER_WORKFLOW_NAME;
        } else if (bankStatementDetailRecord.getReference() != null &&
                (bankStatementDetailRecord.getReference().startsWith(BatchServiceConstants.BILLER_CODE) || bankStatementDetailRecord.getReference()
                        .startsWith(BatchServiceConstants.MEMBER_BILLER_CODE))) {
            return BatchServiceConstants.MEMBER_EMPLOYER_WORKFLOW_NAME;
        }
        return "";
    }

    /**
     * Creates Data Pool request data block.
     * 
     * @return
     * @throws SILException
     */
    private DataPool createDataPool() throws SILException {
        SILLogger.debug(BatchServiceConstants.BANK_STATEMENT_WORKFLOW_LOGGING_FORMAT, className, "Creating Data Pool request data block");
        DataPool dataPool = new DataPool();
        this.outboundWorkflowDataTypeList = dataPool.getData();
        addWorkflowDatatoOutboundRequest();

        return dataPool;
    }

    /**
     * Adds Workflow Data to Outbound Request.
     * 
     * @throws SILException
     */
    private void addWorkflowDatatoOutboundRequest() throws SILException {
        SILLogger.debug(BatchServiceConstants.BANK_STATEMENT_WORKFLOW_LOGGING_FORMAT, className, "Adding Workflow Data to Outbound Request");
        BatchServiceUtil batchServiceUtil = new BatchServiceUtil();
        if (inboundRequest != null && bankStatementDetailRecord != null) {
            createWorkFlowDataPool(BatchServiceConstants.BANK_STATEMENT_WORKFLOW_LOGGING_FORMAT, batchServiceUtil);
        }
    }

    /**
     * Creates Workflow Data Pool.
     * 
     * @param logger
     * @param batchServiceUtil
     * @throws SILException
     */
    private void createWorkFlowDataPool(String logger, BatchServiceUtil batchServiceUtil) throws SILException {
        SILLogger.debug(BatchServiceConstants.BANK_STATEMENT_WORKFLOW_LOGGING_FORMAT, className, "Creating Workflow Data Pool");
        if (bankStatementDetailRecord.getEffectiveDate() != null) {
            batchServiceUtil.createWorkflowDataTypeForStringDate(BatchServiceConstants.RECEIPT_DATE_TAG_NAME, bankStatementDetailRecord
                    .getEffectiveDate().toString(), outboundWorkflowDataTypeList, logger);
        }
        if (bankStatementDetailRecord.getReceiptNumber() != null) {
            batchServiceUtil.createWorkflowDataTypeForString(BatchServiceConstants.RECEIPT_NUMBER_TAG_NAME,
                    bankStatementDetailRecord.getReceiptNumber(), this.outboundWorkflowDataTypeList, logger);
        }
        if (bankStatementDetailRecord.getReference() != null) {
            batchServiceUtil.createWorkflowDataTypeForString(BatchServiceConstants.BILLER_CODE_TAG_NAME, bankStatementDetailRecord.getReference(),
                    this.outboundWorkflowDataTypeList, logger);
        }
        if (bankStatementDetailRecord.getReceiptAmount() != null) {
            batchServiceUtil.createWorkflowDataTypeForString(BatchServiceConstants.DOLLAR_AMOUNT_TAG_NAME, bankStatementDetailRecord
                    .getReceiptAmount().toString(), this.outboundWorkflowDataTypeList, logger);
        }
    }
}
