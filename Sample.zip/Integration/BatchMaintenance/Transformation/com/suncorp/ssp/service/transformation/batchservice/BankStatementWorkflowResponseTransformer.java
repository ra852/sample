////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.transformation.batchservice;

import javax.ws.rs.core.Response;

import org.apache.camel.Exchange;

import com.sonatacentral.service.v30.workflow.StartWorkflowResponseType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.batchservice.BatchServiceConstants;
import com.suncorp.ssp.service.integration.batchservice.bean.StartWorkflowResponse;
import com.suncorp.ssp.service.integration.batchservice.util.BatchServiceWorkflowResponseUtil;

/**
 * The class {@code StartWorkflowResponseTransformer} is used to transforms the response received from external service, to a specified format.
 * 
 * @author U383754
 * @since 17/03/2016
 * @version 1.0
 */
public class BankStatementWorkflowResponseTransformer {
    private String className = "BankStatementWorkflowResponseTransformer";

    /**
     * Extracts the values from external service's response, to forward to the end-client.
     * 
     * @param exchange
     * @throws SILException
     */
    public void transform(Exchange exchange) throws SILException {
        try {
            SILLogger.debug(BatchServiceConstants.BANK_STATEMENT_WORKFLOW_LOGGING_FORMAT, className, "Entering transform method");
            StartWorkflowResponseType inboundResponse = exchange.getIn().getBody(StartWorkflowResponseType.class);
            StartWorkflowResponse startWorkflowResponse = new StartWorkflowResponse();
            new BatchServiceWorkflowResponseUtil().createOutboundResponse(inboundResponse,
                    BatchServiceConstants.BANK_STATEMENT_WORKFLOW_LOGGING_FORMAT, startWorkflowResponse);
            setExchangeResponse(exchange, startWorkflowResponse);
        } catch (Exception exception) {
            SILLogger.error(BatchServiceConstants.BANK_STATEMENT_WORKFLOW_LOGGING_FORMAT, className, SILUtil.getRespExMsg(exception));
            throw new SILException(BatchServiceConstants.BANK_STATEMENT_WORKFLOW_RESPONSE_ERROR_MSG);
        }
    }

    /**
     * Handles SOAP FaultException.
     * 
     * @param exchange
     */
    public void handleSOAPFaultException(Exchange exchange) {
        SILLogger.debug(BatchServiceConstants.BANK_STATEMENT_WORKFLOW_LOGGING_FORMAT, className, "Handling SOAP FaultException");
        exchange.removeProperty(Exchange.EXCEPTION_CAUGHT);
    }
    
    /**
     * Gets the outbound response object based on the iteration of the route.
     *
     * @param exchange
     * @param startWorkflowResponse
     */
    private void setExchangeResponse(Exchange exchange, StartWorkflowResponse startWorkflowResponse) {
        Response response = Response.status(Response.Status.OK).entity(startWorkflowResponse).build();
        exchange.getIn().setBody(response);
    }
}
