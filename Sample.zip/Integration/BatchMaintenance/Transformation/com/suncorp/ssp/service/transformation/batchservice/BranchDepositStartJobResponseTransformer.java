////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.transformation.batchservice;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.camel.Exchange;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVRecord;

import com.sonatacentral.service.v30.common.system.StartJobResponseType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.batchservice.BatchServiceConstants;
import com.suncorp.ssp.service.integration.batchservice.bean.BranchDepositResponseBean;
import com.suncorp.ssp.service.integration.batchservice.bean.BranchDepositWorkFlowDataBean;
import com.suncorp.ssp.service.integration.batchservice.bean.BranchDepositWorkFlowRequestBean;

/**
 * The class {@code BranchDepositResponseTransformer} transforms the response received from external service, to a specified format for end-client.
 * 
 * @author U387938
 * @since 13/04/2015
 * @version 1.0
 */
public class BranchDepositStartJobResponseTransformer {
    private final String cName = "BranchDepositResponseTransformer";

    /**
     * Extracts the values from external service's response, to forward to the end-client.
     * 
     * @param exchange
     * @throws Exception
     */
    public void transform(Exchange exchange) throws SILException {
        try {
            SILLogger.debug(BatchServiceConstants.BRANCH_DEPOSIT_LOGGING_FORMAT, cName, "Entering transform()");
            StartJobResponseType inboundResponse = exchange.getIn().getBody(StartJobResponseType.class);
            BranchDepositResponseBean outboundResponse = new BranchDepositResponseBean();
            outboundResponse.setQueueId(String.valueOf(inboundResponse.getQueueId()));
            SILLogger.info(BatchServiceConstants.BRANCH_DEPOSIT_LOGGING_FORMAT, cName,
                    "QueueId received from Sonata:" + outboundResponse.getQueueId());
            setExchangeResponse(exchange);
            SILLogger.debug(BatchServiceConstants.BRANCH_DEPOSIT_LOGGING_FORMAT, cName, "Exiting transform()");
        } catch (Exception exception) {
            SILLogger.error(BatchServiceConstants.BRANCH_DEPOSIT_LOGGING_FORMAT, cName, SILUtil.getRespExMsg(exception));
            throw new SILException(BatchServiceConstants.BRANCH_DEPOSIT_RESPONSE_NOT_PROCESSED);
        }
    }

    /**
     * Sets the response into exchange message.
     * 
     * @param exchange of type Exchange
     * @throws IOException
     * @throws SILException
     */
    private void setExchangeResponse(Exchange exchange) throws IOException, SILException {
        SILLogger.debug(BatchServiceConstants.BRANCH_DEPOSIT_LOGGING_FORMAT, cName, "Entering setExchangeResponse()");
        List<BranchDepositWorkFlowDataBean> lstDepositWorkFlowDataBeans = new ArrayList<BranchDepositWorkFlowDataBean>();
        FileReader fileReader = null;
        CSVParser csvParser = null;
        CSVFormat csvFormat = CSVFormat.DEFAULT.withHeader(BatchServiceConstants.BRANCH_DEPOSIT_CSV_HEADER);
        try {
            File inboundFile = (File) exchange.getProperty(BatchServiceConstants.TRIGGER_WORKFLOW_FILERECEIVED);
            if (inboundFile != null) {
                fileReader = new FileReader(inboundFile);
                csvParser = new CSVParser(fileReader, csvFormat);
                BranchDepositWorkFlowRequestBean branchDepositWorkFlowRequestBean =
                        createBranchDepositRecords(exchange, csvParser, lstDepositWorkFlowDataBeans);
                SILLogger.debug(BatchServiceConstants.BRANCH_DEPOSIT_LOGGING_FORMAT, cName,
                        String.valueOf(branchDepositWorkFlowRequestBean.getLstWorkFlowDataBeans().size()));
            }
        } catch (Exception exception) {
            SILLogger.error(BatchServiceConstants.BRANCH_DEPOSIT_LOGGING_FORMAT, cName, SILUtil.getRespExMsg(exception));
            throw new SILException(BatchServiceConstants.BRANCH_DEPOSIT_CSV_PARSE_ERROR);
        } finally {
            postFileprocessing(fileReader, csvParser);
        }
    }

    /**
     * closing File I/O object after csv parser.
     * 
     * @param fileReader
     * @param csvParser
     */
    private void postFileprocessing(FileReader fileReader, CSVParser csvParser) {
        try {
            if (fileReader != null) {
                fileReader.close();
            }
            if (csvParser != null) {
                csvParser.close();
            }
        } catch (IOException ioException) {
            SILLogger.error(CommonConstants.LOGGING_FORMAT, cName, SILUtil.getRespExMsg(ioException));
        }
    }

    /**
     * Parse the csv record and creates the pojo.
     * 
     * @param exchange
     * @param csvParser
     * @param lstDepositWorkFlowDataBeans
     * @param countFlag
     * @return
     * @throws IOException
     */
    private BranchDepositWorkFlowRequestBean createBranchDepositRecords(Exchange exchange, CSVParser csvParser,
            List<BranchDepositWorkFlowDataBean> lstDepositWorkFlowDataBeans) throws IOException {
        int countFlag = 0;
        for (CSVRecord record : csvParser.getRecords()) {
            SILLogger.debug(BatchServiceConstants.BRANCH_DEPOSIT_LOGGING_FORMAT, cName, "Entering createBranchDepositRecords()");
            if (countFlag != 0 && record != null) {
                BranchDepositWorkFlowDataBean depositWorkFlowDataBean = new BranchDepositWorkFlowDataBean();
                depositWorkFlowDataBean.setAccountNumber(record.get("5"));
                depositWorkFlowDataBean.setEffectiveDate(record.get("7"));
                depositWorkFlowDataBean.setReceiptNumber(record.get("15"));
                depositWorkFlowDataBean.setReference(record.get("18"));
                depositWorkFlowDataBean.setTransactionAmount(record.get("3"));
                lstDepositWorkFlowDataBeans.add(depositWorkFlowDataBean);
            }
            countFlag++;
        }
        BranchDepositWorkFlowRequestBean branchDepositWorkFlowRequestBean = new BranchDepositWorkFlowRequestBean();
        branchDepositWorkFlowRequestBean.setLstWorkFlowDataBeans(lstDepositWorkFlowDataBeans);
        exchange.setProperty(BatchServiceConstants.BRANCH_DEPOSIT_TRIGGER_WORKFLOW_LIST, branchDepositWorkFlowRequestBean);
        exchange.setProperty(BatchServiceConstants.BRANCH_DEPOSIT_TRIGGER_WORKFLOW_SIZE, branchDepositWorkFlowRequestBean.getLstWorkFlowDataBeans()
                .size());
        SILLogger.debug(BatchServiceConstants.BRANCH_DEPOSIT_LOGGING_FORMAT, cName, "Exitng createBranchDepositRecords()");
        return branchDepositWorkFlowRequestBean;
    }
}
