////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.transformation.batchservice;

import org.apache.camel.Exchange;

import com.sonatacentral.service.v30.common.system.StartJobResponseType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.batchservice.BatchServiceConstants;
import com.suncorp.ssp.service.integration.batchservice.bean.StartJobResponse;

/**
 * The class {@code AssetAllocationStartJobResponseTransformer} is used to transform response received from external service, to a specified format.
 *
 * @author U383847
 * @since 05/08/2016
 * @version 1.0
 */
public class AssetAllocationStartJobResponseTransformer {
private final String className = "AssetAllocationStartJobResponseTransformer";
    
    /**
     * Extracts the values from external service's response, to forward to the next service.
     *
     * @param exchange
     * @throws SILException
     */
    public void transform(Exchange exchange) throws SILException {
        SILLogger.debug(BatchServiceConstants.ASSET_ALLOCATION_FILEUPLOAD_LOGGING_FORMAT, className, "Entering in transform method");
        try {
            StartJobResponseType inboundResponse = exchange.getIn().getBody(StartJobResponseType.class);
            StartJobResponse startJobResponse = new StartJobResponse();
            startJobResponse.setQueueId(String.valueOf(inboundResponse.getQueueId()));
            SILLogger.info(BatchServiceConstants.ASSET_ALLOCATION_FILEUPLOAD_LOGGING_FORMAT, className,
                    "Asset Allocation StartJob Response Queue Id " + String.valueOf(inboundResponse.getQueueId()));
        } catch (Exception exception) {
            SILLogger.error(BatchServiceConstants.ASSET_ALLOCATION_FILEUPLOAD_LOGGING_FORMAT, className, SILUtil.getRespExMsg(exception));
            throw new SILException(BatchServiceConstants.ASSET_ALLOCATION_STARTJOB_GENERIC_EXCEPTION);
        }
    }
}
