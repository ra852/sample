////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.transformation.batchservice;

import java.math.BigDecimal;
import java.util.List;

import org.apache.camel.Exchange;

import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.batchservice.BatchServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.AccountDetailsList;
import com.suncorp.ssp.service.integration.batchservice.bean.branchdeposit.BranchDepositFilterRecordsModelBean;
import com.suncorp.ssp.service.integration.batchservice.bean.branchdeposit.BranchDepositHeaderRecord;
import com.suncorp.ssp.service.integration.customerservice.bean.GetAccountListDetailsResponseWrapperBean;

/**
 * The class {@code GetAccountListDetailsResponseTransformer} is a transformer used to check the result from getAccountListDetails and set the flag in
 * exchange property for successful results.
 * 
 * @author U385424
 * @since 25/10/2016
 * @version 1.0
 */
public class GetAccountListDetailsResponseTransformer {
    private final String className = "GetAccountListDetailsResponseTransformer";

    /**
     * Extracts the values from external service's response, to forward to the end-client.
     */
    public void transform(Exchange exchange) {
        SILLogger.debug(BatchServiceConstants.BRANCH_DEPOSIT_FILTER_RECORDS_LOGGING_FORMAT, className, "Entering transform()");
        GetAccountListDetailsResponseWrapperBean inboundResponseWrapper = exchange.getIn().getBody(GetAccountListDetailsResponseWrapperBean.class);
        if (inboundResponseWrapper != null && inboundResponseWrapper.getGetAccountDetailsResponse() != null &&
                inboundResponseWrapper.getGetAccountDetailsResponse().getErrorMessage() == null &&
                inboundResponseWrapper.getGetAccountDetailsResponse().getAccountDetailsList() != null &&
                inboundResponseWrapper.getGetAccountDetailsResponse().getAccountDetailsList().size() > 0) {
            checkAccountStatus(exchange, inboundResponseWrapper.getGetAccountDetailsResponse().getAccountDetailsList());
            SILLogger.debug(BatchServiceConstants.BRANCH_DEPOSIT_FILTER_RECORDS_LOGGING_FORMAT, className, "Exiting transform()");
        }
    }

    /**
     * This method is used to check the account status and set the flag for successful response.
     * 
     * @param exchange
     * @param accountDetailsList
     */
    private void checkAccountStatus(Exchange exchange, List<AccountDetailsList> accountDetailsList) {
        SILLogger.debug(BatchServiceConstants.BRANCH_DEPOSIT_FILTER_RECORDS_LOGGING_FORMAT, className, "Entering checkAccountStatus()");
        for (AccountDetailsList accountDetails : accountDetailsList) {
            if (accountDetails.getAccount() != null && accountDetails.getAccount().getStatusCode() != null &&
                    !BatchServiceConstants.SONATA_CODE_INACTIVE_ACCOUNT.equalsIgnoreCase(accountDetails.getAccount().getStatusCode().getCode())) {
                exchange.setProperty(BatchServiceConstants.VALID_RECORD_FLAG, CommonConstants.FLAG_Y);
            }
        }
        SILLogger.debug(BatchServiceConstants.BRANCH_DEPOSIT_FILTER_RECORDS_LOGGING_FORMAT, className, "Exiting checkAccountStatus()");
    }

    /**
     * This method is used to set filtered records in exchange body.
     * 
     * @param ex
     */
    public void setRecordsinBody(Exchange ex) {
        SILLogger.debug(BatchServiceConstants.BRANCH_DEPOSIT_FILTER_RECORDS_LOGGING_FORMAT, className, "Entering setRecordsinBody()");
        List<BranchDepositFilterRecordsModelBean> finalOutput = (List<BranchDepositFilterRecordsModelBean>) ex.getProperty("outputList");
        setOutboundFileHeader(finalOutput);
        setOutboundFileName(ex);
        ex.getIn().setBody(finalOutput);
        SILLogger.debug(BatchServiceConstants.BRANCH_DEPOSIT_FILTER_RECORDS_LOGGING_FORMAT, className, "Exiting setRecordsinBody()");
    }

    /**
     * This method is used to set output fileName.
     * 
     * @param ex
     */
    private void setOutboundFileName(Exchange ex) {
        SILLogger.debug(BatchServiceConstants.BRANCH_DEPOSIT_FILTER_RECORDS_LOGGING_FORMAT, className, "Entering setOutboundFileName()");
        String brachDepositInputFileName = (String) ex.getProperty("inputFileName");
        ex.setProperty(BatchServiceConstants.FILTERED_RECORD_OUTPUT_FILENAME, brachDepositInputFileName.substring(0, 9));
        SILLogger.debug(BatchServiceConstants.BRANCH_DEPOSIT_FILTER_RECORDS_LOGGING_FORMAT, className, "Exiting setOutboundFileName()");
    }

    /**
     * This method is used to set header in output csv file.
     * 
     * @param finalOutput
     */
    private void setOutboundFileHeader(List<BranchDepositFilterRecordsModelBean> finalOutput) {
        SILLogger.debug(BatchServiceConstants.BRANCH_DEPOSIT_FILTER_RECORDS_LOGGING_FORMAT, className, "Entering setOutboundFileHeader()");
        int numberOfRecords = 0;
        if (finalOutput.size() > 0) {
            numberOfRecords = finalOutput.size();
        }
        BigDecimal totalAmount = BigDecimal.ZERO;
        for (BranchDepositFilterRecordsModelBean branchDepositOutput : finalOutput) {
            if (branchDepositOutput != null && branchDepositOutput.getBranchDepositRecordOrder() != null &&
                    branchDepositOutput.getBranchDepositRecordOrder().getReceiptAmount() != null) {
                BigDecimal receiptAmount = branchDepositOutput.getBranchDepositRecordOrder().getReceiptAmount();
                totalAmount = totalAmount.add(receiptAmount);
            }
        }
        BranchDepositHeaderRecord header = new BranchDepositHeaderRecord();
        BranchDepositFilterRecordsModelBean branchDepositOutput = new BranchDepositFilterRecordsModelBean();
        header.setHeaderRecordType(BatchServiceConstants.VALUE_ONE);
        header.setRecordCount(numberOfRecords);
        header.setTotalAmount(totalAmount);
        branchDepositOutput.setBranchDepositHeaderRecord(header);
        finalOutput.add(0, branchDepositOutput);
        SILLogger.debug(BatchServiceConstants.BRANCH_DEPOSIT_FILTER_RECORDS_LOGGING_FORMAT, className, "Exiting setOutboundFileHeader()");
    }
}
