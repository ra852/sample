////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.transformation.batchservice;

import org.apache.camel.Exchange;

import com.sonatacentral.service.v30.common.system.StartJobResponseType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.batchservice.BatchServiceConstants;
import com.suncorp.ssp.service.integration.batchservice.bean.StartJobResponse;

/**
 * The class {@code CommonFundFeeResponseTransformer} is used to transform the response.
 * 
 * @author U383754
 * @since 02/11/2016
 * @version 1.0
 */
public class CommonFundFeeResponseTransformer {
    private String className = "CommonFundFeeResponseTransformer";

    /**
     * This method is used to transform the response.
     * 
     * @param exchange
     * @throws SILException
     */
    public void transform(Exchange exchange) throws SILException {
        SILLogger.debug(BatchServiceConstants.COMMON_FUND_FEE_LOGGING_FORMAT, className, "Entering transform()");
        try {
            StartJobResponseType inboundResponse = exchange.getIn().getBody(StartJobResponseType.class);
            StartJobResponse startJobResponse = new StartJobResponse();
            startJobResponse.setQueueId(String.valueOf(inboundResponse.getQueueId()));
            exchange.setProperty(BatchServiceConstants.COMMON_FUND_FEE_QUEUE_ID, String.valueOf(inboundResponse.getQueueId()));
            SILLogger.debug(BatchServiceConstants.COMMON_FUND_FEE_LOGGING_FORMAT, className, "Exiting transform()");
        } catch (Exception exception) {
            SILLogger.error(BatchServiceConstants.COMMON_FUND_FEE_LOGGING_FORMAT, className, exception.getMessage());
            throw new SILException(exception.getMessage());
        }
    }
}
