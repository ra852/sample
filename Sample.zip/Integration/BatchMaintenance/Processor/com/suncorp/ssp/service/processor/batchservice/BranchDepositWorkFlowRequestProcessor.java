////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.processor.batchservice;

import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.component.cxf.common.message.CxfConstants;

import com.sonatacentral.service.v30.workflow.StartWorkflowRequestType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.batchservice.BatchServiceConstants;
import com.suncorp.ssp.service.integration.batchservice.bean.BranchDepositWorkFlowDataBean;
import com.suncorp.ssp.service.integration.batchservice.bean.BranchDepositWorkFlowRequestBean;
import com.suncorp.ssp.service.integration.batchservice.util.BranchDepositWorkFlowRequestUtil;

/**
 * The class {@code BranchDepositWorkFlowRequestProcessor} processes/constructs SOAP request for external service.
 * 
 * @author U387938
 * @since 08/04/2016
 * @version 1.0
 */
public class BranchDepositWorkFlowRequestProcessor implements Processor {

    private final String className = "BranchDepositWorkFlowRequestProcessor";

    /**
     * Creates a SOAP request for Sonata's StartJob (BranchDeposit) service and sets its into the exchange body.
     * 
     * @param exchange of type Exchange
     * @throws Exception
     */
    @Override
    public void process(Exchange exchange) throws Exception {
        SILLogger.debug(BatchServiceConstants.BRANCH_DEPOSIT_LOGGING_FORMAT, className, "Entering process()");
        try {
            exchange.setProperty(CommonConstants.RESPONSE_CLASS_NAME, BatchServiceConstants.TRG_WF_RESP_CNAME);
            BranchDepositWorkFlowRequestBean inboundRequest = getInboundRequest(exchange);
            persistRequestObject(exchange, inboundRequest);
            StartWorkflowRequestType outboundRequest = new BranchDepositWorkFlowRequestUtil(inboundRequest).createOutboundRequest();
            setHeaderAndBody(exchange, outboundRequest);
            SILLogger.debug(BatchServiceConstants.BRANCH_DEPOSIT_LOGGING_FORMAT, className, "Exiting process()");
        } catch (Exception excp) {
            SILLogger.error(BatchServiceConstants.BRANCH_DEPOSIT_LOGGING_FORMAT, className, SILUtil.getReqExMsg(excp));
            throw new SILException(BatchServiceConstants.BRANCH_DEPOSIT_REQUEST_NOT_PROCESSED);
        }
    }

    /**
     * Sets the headers and body into the exchange message.
     * 
     * @param exchange of type Exchange
     * @param outboundRequest of type StartJobRequestType
     */
    private void setHeaderAndBody(Exchange exchange, StartWorkflowRequestType outboundRequest) {
        SILLogger.debug(BatchServiceConstants.BRANCH_DEPOSIT_LOGGING_FORMAT, className, "Entering setHeaderAndBody()");
        Map<String, Object> mapHeaders = new HashMap<String, Object>();
        mapHeaders.put(CxfConstants.OPERATION_NAME, BatchServiceConstants.START_WORKFLOW_OPERATION_NAME);
        mapHeaders.put(CxfConstants.OPERATION_NAMESPACE, BatchServiceConstants.START_WORKFLOW_OPERATION_NAMESPACE);
        exchange.getIn().setHeaders(mapHeaders);
        exchange.getIn().setBody(outboundRequest);
        SILLogger.debug(BatchServiceConstants.BRANCH_DEPOSIT_LOGGING_FORMAT, className, "Exiting setHeaderAndBody()");
    }

    /**
     * Stores the request object into Camel Exchange as property. Also sets the workflow set to be used for the request for current iteration.
     * 
     * @param ex of type Exchange
     * @param inboundRequest of type TriggerWorkflowRequestBean
     */
    private void persistRequestObject(Exchange ex, BranchDepositWorkFlowRequestBean inboundRequest) {
        SILLogger.debug(BatchServiceConstants.BRANCH_DEPOSIT_LOGGING_FORMAT, className, "Entering persistRequestObject()");
        int iterationNo = (int) ex.getProperty(CommonConstants.CAMEL_LOOP_INDEX);
        SILLogger.debug(BatchServiceConstants.BRANCH_DEPOSIT_LOGGING_FORMAT, className, String.valueOf(iterationNo));
        if (inboundRequest != null && inboundRequest.getLstWorkFlowDataBeans() != null) {
            BranchDepositWorkFlowDataBean branchDepositWorkFlowDataBean = inboundRequest.getLstWorkFlowDataBeans().get(iterationNo);
            inboundRequest.setBranchDepositWorkFlowDataBean(branchDepositWorkFlowDataBean);
        }
        SILLogger.debug(BatchServiceConstants.BRANCH_DEPOSIT_LOGGING_FORMAT, className, "Entering persistRequestObject()");

    }

    /**
     * Gets the inbound request object based on the iteration of the route.
     * 
     * @param ex of type {@code Exchange}
     * @return inboundRequest of type TriggerWorkflowRequestBean
     */

    private BranchDepositWorkFlowRequestBean getInboundRequest(Exchange ex) {
        SILLogger.debug(BatchServiceConstants.BRANCH_DEPOSIT_LOGGING_FORMAT, className, "Entering getInboundRequest()");
        BranchDepositWorkFlowRequestBean inboundRequest = new BranchDepositWorkFlowRequestBean();
        inboundRequest = (BranchDepositWorkFlowRequestBean) ex.getProperty("triggerWorkFlowlst");
        SILLogger.debug(BatchServiceConstants.BRANCH_DEPOSIT_LOGGING_FORMAT, className, "Entering getInboundRequest()");
        return inboundRequest;
    }
}
