////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.processor.batchservice;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.batchservice.BatchServiceConstants;

/**
 * The class {@code EmailProcessor} does this.
 * 
 * @author U384380
 * @since 10/01/2017
 * @version 1.0
 */
public class EmailProcessor implements Processor {

    private final String className = "EmailProcessor";

    /**
     * Set parameters for email.
     * 
     * @param exchange
     * @throws Exception
     */
    @Override
    public void process(Exchange exchange) throws Exception {
        SILLogger.debug(BatchServiceConstants.EMAIL_PROCESSING_LOGGING_FORMAT, className, "Entering process()");
        String emailBody = BatchServiceConstants.EMAIL_FAILURE_DATE_TIME + new SimpleDateFormat().format(new Date());
        emailBody = emailBody + " \r\n " + BatchServiceConstants.INPUT_FILE_NAME + (String) exchange.getProperty("inputFileName");
        emailBody = emailBody + " \r\n " + BatchServiceConstants.EMAIL_DESCRIPTION + BatchServiceConstants.EMAIL_FAILURE_DESCRIPTION;
        exchange.getIn().setBody(emailBody);
        Map<String, Object> headerParameters = new HashMap<String, Object>();
        headerParameters.put(BatchServiceConstants.EMAIL_TO, exchange.getProperty(BatchServiceConstants.TO_EMAIL_ID));
        headerParameters.put(BatchServiceConstants.EMAIL_FROM, exchange.getProperty(BatchServiceConstants.FROM_EMAIL_ID));
        headerParameters.put(BatchServiceConstants.EMAIL_SUBJECT_DESC, exchange.getProperty(BatchServiceConstants.EMAIL_SUBJECT));
        exchange.getIn().setHeaders(headerParameters);
        SILLogger.debug(BatchServiceConstants.EMAIL_PROCESSING_LOGGING_FORMAT, className, "Entering process()");
    }
}
