////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.processor.batchservice;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.batchservice.BatchServiceConstants;
import com.suncorp.ssp.service.integration.batchservice.bean.bankstatement.BankStatementDetailRecord;
import com.suncorp.ssp.service.integration.batchservice.bean.bankstatement.BankStatementHeaderRecord;
import com.suncorp.ssp.service.integration.batchservice.bean.bankstatement.BankStatementRecordOrder;

/**
 * The class {@code BankStatementTransformationRequestProcessor} is used to read the BRS file, strip and transform to generate CSV file.
 * 
 * @author u383847
 * @since 12/04/2016
 * @version 1.0
 */
public class BankStatementTransformationRequestProcessor implements Processor {
    private final String className = "BankStatementTransformationRequestProcessor";
    private String headerRecordTemp = null;

    /**
     * Reads the file from SIL Inbound folder, strip and transform the content to generate CSV file format and drop it in same folder.
     * 
     * @param exchange
     * @throws Exception
     */
    @Override
    public void process(Exchange exchange) throws SILException {
        SILLogger.debug(BatchServiceConstants.BANK_STATEMENT_TRANSFORMATION_LOGGING_FORMAT, className, "Entering in process method");
        try {
            exchange.setProperty(CommonConstants.RESPONSE_CLASS_NAME, BatchServiceConstants.BANK_STATEMENT_RESPONSE_CLASS);
            File inboundFile = exchange.getIn().getBody(File.class);
            List<String> strippedFileContent = this.readStrippedFileContent(inboundFile);
            List<BankStatementRecordOrder> recordOrderList = new ArrayList<BankStatementRecordOrder>();
            this.checkStrippedFileContent(strippedFileContent, recordOrderList);
            exchange.getIn().setBody(recordOrderList);
            exchange.setProperty(BatchServiceConstants.BANK_STATEMENT_CSV_FILE_NAME, inboundFile.getName().substring(14, 22));
        } catch (SILException silException) {
            SILLogger.error(BatchServiceConstants.BANK_STATEMENT_TRANSFORMATION_LOGGING_FORMAT, className, SILUtil.getReqExMsg(silException));
            throw new SILException(SILUtil.getReqExMsg(silException));
        } catch (Exception exception) {
            SILLogger.error(BatchServiceConstants.BANK_STATEMENT_TRANSFORMATION_LOGGING_FORMAT, className, SILUtil.getReqExMsg(exception));
            throw new SILException(BatchServiceConstants.BANK_STATEMENT_TRANSFORM_GENERIC_EXCEPTION);
        }
    }

    /**
     * Reads Stripped File Content.
     * 
     * @param exchange
     * @return
     * @throws SILException
     */
    private List<String> readStrippedFileContent(File inboundFile) throws SILException {
        SILLogger.debug(BatchServiceConstants.BANK_STATEMENT_TRANSFORMATION_LOGGING_FORMAT, className, "Reading Stripped File Content");
        BufferedReader bufferedReader = null;
        try {
            bufferedReader = new BufferedReader(new FileReader(inboundFile));
            return this.getStrippedFileContent(bufferedReader);
        } catch (SILException silException) {
            SILLogger.error(BatchServiceConstants.BANK_STATEMENT_TRANSFORMATION_LOGGING_FORMAT, className, SILUtil.getReqExMsg(silException));
            throw new SILException(SILUtil.getReqExMsg(silException));
        } catch (IOException ioException) {
            SILLogger.error(BatchServiceConstants.BANK_STATEMENT_TRANSFORMATION_LOGGING_FORMAT, className, SILUtil.getReqExMsg(ioException));
            throw new SILException(SILUtil.getReqExMsg(ioException));
        } finally {
            try {
                if (bufferedReader != null) {
                    bufferedReader.close();
                }
            } catch (IOException ioException) {
                SILLogger.error(BatchServiceConstants.BANK_STATEMENT_TRANSFORMATION_LOGGING_FORMAT, className, SILUtil.getReqExMsg(ioException));
            }
        }

    }

    /**
     * Gets Stripped File Content.
     * 
     * @param bufferedReader
     * @return
     * @throws IOException
     */
    private List<String> getStrippedFileContent(BufferedReader bufferedReader) throws SILException {
        SILLogger.debug(BatchServiceConstants.BANK_STATEMENT_TRANSFORMATION_LOGGING_FORMAT, className, "Getting Stripped File Content");
        List<String> strippedFileContent = new ArrayList<String>();
        StringBuffer stringBuffer = new StringBuffer();
        int currentChar;
        Boolean accountCheckCounter = false;
        try {
            while ((currentChar = bufferedReader.read()) != -1) {
                char character = (char) currentChar;
                stringBuffer.append(character);
                if (currentChar == CommonConstants.NEW_LINE_CHARACTER_VALUE) {
                    String currentLine = stringBuffer.toString();
                    stringBuffer.delete(0, stringBuffer.length());
                    if (checkValue(currentLine) && !checkStripFileRecords(currentLine)) {
                        accountCheckCounter = generateFileContent(strippedFileContent, accountCheckCounter, currentLine);
                    }
                }
            }
        } catch (IOException ioException) {
            SILLogger.error(BatchServiceConstants.BANK_STATEMENT_TRANSFORMATION_LOGGING_FORMAT, className, SILUtil.getReqIOExMsg(ioException));
            throw new SILException(BatchServiceConstants.FILE_STRIP_EXCEPTION);
        }
        return strippedFileContent;
    }

    /**
     * Does this.
     * 
     * @param strippedFileContent
     * @param accountCheckCounter
     * @param currentLine
     * @return
     */
    private Boolean generateFileContent(List<String> strippedFileContent, Boolean accountCheckCounter, String currentLine) {
        Boolean accountCounter = accountCheckCounter;
        if (currentLine.startsWith(BatchServiceConstants.FILE_HEADER_RECORD_TYPE_VALUE)) {
            headerRecordTemp = currentLine;
        } else if (currentLine.startsWith(BatchServiceConstants.ACCOUNT_HEADER_RECORD_TYPE_VALUE)) {
            accountCounter = checkBankAccountNumber(currentLine);
            generateStrippedContent(strippedFileContent, accountCounter, headerRecordTemp);
        } else {
            generateStrippedContent(strippedFileContent, accountCounter, currentLine);
        }
        return accountCounter;
    }

    /**
     * Does this.
     * 
     * @param strippedFileContent
     * @param accountCheckCounter
     * @param currentLine
     */
    private void generateStrippedContent(List<String> strippedFileContent, Boolean accountCheckCounter, String currentLine) {
        if (accountCheckCounter) {
            this.generateStrippedFileContent(currentLine, strippedFileContent);
        }
    }

    /**
     * Checks Stripped File Records.
     * 
     * @param currentLine
     * @return
     */
    private boolean checkStripFileRecords(String currentLine) {
        return isInitialOrFinalRecord(currentLine) || isAccountHeaderRecord(currentLine) || isTrailingOrDeleteRecord(currentLine) ||
                isTransactionRecord(currentLine);
    }

    /**
     * Checks Stripped File Content.
     * 
     * @param strippedFileContent
     * @param recordOrderList
     * @throws SILException
     */
    private void checkStrippedFileContent(List<String> strippedFileContent, List<BankStatementRecordOrder> recordOrderList) throws SILException {
        if (strippedFileContent != null && strippedFileContent.size() > 0) {
            this.transformedFileContent(strippedFileContent, recordOrderList);
        } else {
            throw new SILException(BatchServiceConstants.NO_CONTENT_FILE_EXCEPTION);
        }
    }

    /**
     * Checks for Initial or Final Record.
     * 
     * @param currentLine
     * @return
     */
    private boolean isInitialOrFinalRecord(String currentLine) {
        return currentLine.startsWith(BatchServiceConstants.INITIAL_RECORD_TYPE_VALUE) ||
                currentLine.startsWith(BatchServiceConstants.FINAL_RECORD_TYPE_VALUE) ? true : false;
    }

    /**
     * Checks for Account Header Records.
     * 
     * @param currentLine
     * @return
     */
    private boolean isAccountHeaderRecord(String currentLine) {
        return currentLine.startsWith(BatchServiceConstants.ACCOUNT_RECORD_TYPE_VALUE) ? true : false;
    }

    private boolean checkBankAccountNumber(String currentLine) {
        return BatchServiceConstants.BANK_ACCOUNT_NUMBER.substring(6, BatchServiceConstants.BANK_ACCOUNT_NUMBER.length()).equalsIgnoreCase(
                currentLine.substring(11, 17));
    }

    /**
     * Checks for Trailing or Delete Records.
     * 
     * @param currentLine
     * @return
     */
    private boolean isTrailingOrDeleteRecord(String currentLine) {
        return currentLine.startsWith(BatchServiceConstants.ACCOUNT_TRALIER_RECORD_TYPE_VALUE) ||
                currentLine.startsWith(BatchServiceConstants.DELETE_ACCOUNT_RECORD_TYPE_VALUE) ||
                currentLine.startsWith(BatchServiceConstants.FILE_TRALIER_RECORD_TYPE_VALUE) ? true : false;
    }

    /**
     * Checks for Transaction Records.
     * 
     * @param currentLine
     * @return
     */
    private boolean isTransactionRecord(String currentLine) {
        return currentLine.startsWith(BatchServiceConstants.TRANSACTION_RECORD_TYPE_VALUE) &&
                (currentLine.substring(21, 36).equalsIgnoreCase("DEPOSIT 0009116") ||
                        currentLine.substring(45, 48).equalsIgnoreCase(BatchServiceConstants.OTC_TRANSACTION_RECORD_TYPE_VALUE) ||
                        currentLine.substring(17, 18).equalsIgnoreCase(BatchServiceConstants.NEGATIVE_SIGN) || currentLine.substring(18, 21)
                        .equalsIgnoreCase(BatchServiceConstants.TRANSACTION_RECORD_TYPE_CODE)) ? true : false;
    }

    /**
     * Generates Stripped File Content.
     * 
     * @param currentLine
     * @param strippedFileContent
     */
    private void generateStrippedFileContent(String currentLine, List<String> strippedFileContent) {
        if (!currentLine.startsWith(BatchServiceConstants.ACCOUNT_HEADER_RECORD_TYPE_VALUE) && !currentLine.trim().equalsIgnoreCase("")) {
            strippedFileContent.add(currentLine);
        }
    }

    /**
     * Gets Transformed File Content.
     * 
     * @param strippedFileContent
     * @param records
     * @throws SILException
     */
    private void transformedFileContent(List<String> strippedFileContent, List<BankStatementRecordOrder> recordOrderList) throws SILException {
        SILLogger.debug(BatchServiceConstants.BANK_STATEMENT_TRANSFORMATION_LOGGING_FORMAT, className, "Getting Transformed File Content");
        BigInteger effectiveBankedDate = null;
        int counter = 0;
        Integer totalRecords = getTotalStrippedTransactionRecords(strippedFileContent);
        BigDecimal totalAmount = calculateTotalAmount(strippedFileContent);
        for (String stripLine : strippedFileContent) {
            String strippedLine = stripLine.replace("'", "");
            if (strippedLine.startsWith(BatchServiceConstants.FILE_HEADER_RECORD_TYPE_VALUE)) {
                effectiveBankedDate = this.convertJulianDateToBigInteger(strippedLine.substring(7, 14));
                this.generateHeaderRecordOrder(recordOrderList, totalRecords, totalAmount);
            } else if (strippedLine.startsWith(BatchServiceConstants.TRANSACTION_RECORD_TYPE_VALUE)) {
                counter = counter + 1;
                this.transformDetailRecords(counter, strippedLine, recordOrderList, effectiveBankedDate);
            }
        }
    }

    /**
     * Gets Total Stripped Transaction Records.
     * 
     * @param strippedFileContent
     * @return
     */
    private Integer getTotalStrippedTransactionRecords(List<String> strippedFileContent) {
        SILLogger.debug(BatchServiceConstants.BANK_STATEMENT_TRANSFORMATION_LOGGING_FORMAT, className, "Getting Total Stripped Transaction Records");
        int count = 0;
        for (String strippedLine : strippedFileContent) {
            if (strippedLine.startsWith(BatchServiceConstants.TRANSACTION_RECORD_TYPE_VALUE) && checkStripLineReference(strippedLine)) {
                count = count + 1;
            }
        }
        return count;
    }

    /**
     * Calculates Total Amount.
     * 
     * @param strippedFileContent
     * @return
     */
    private BigDecimal calculateTotalAmount(List<String> strippedFileContent) {
        SILLogger.debug(BatchServiceConstants.BANK_STATEMENT_TRANSFORMATION_LOGGING_FORMAT, className, "Calculates Total Amount");
        BigDecimal total = BigDecimal.ZERO;
        BigDecimal totalAmount = null;
        for (String strippedLine : strippedFileContent) {
            if (strippedLine.startsWith(BatchServiceConstants.TRANSACTION_RECORD_TYPE_VALUE) && checkStripLineReference(strippedLine)) {
                if (totalAmount != null) {
                    totalAmount = totalAmount.add(new BigDecimal(strippedLine.substring(2, 17)).divide(new BigDecimal(100)));
                } else {
                    totalAmount = total.add(new BigDecimal(strippedLine.substring(2, 17)).divide(new BigDecimal(100)));
                }
            }
        }
        return totalAmount;
    }

    /**
     * Generates Header Record Order.
     * 
     * @param records
     * @param totalRecords
     * @param totalAmount
     */
    private void generateHeaderRecordOrder(List<BankStatementRecordOrder> recordOrderList, Integer totalRecords, BigDecimal totalAmount) {
        SILLogger.debug(BatchServiceConstants.BANK_STATEMENT_TRANSFORMATION_LOGGING_FORMAT, className, "Generating Header Record Order");
        BankStatementHeaderRecord headerRecord = new BankStatementHeaderRecord();
        headerRecord.setHeaderRecordType(BatchServiceConstants.HEADER_RECORD_TYPE_VALUE);
        headerRecord.setRecordCount(totalRecords);
        headerRecord.setTotalAmount(totalAmount);
        BankStatementRecordOrder headerRecordOrder = new BankStatementRecordOrder();
        headerRecordOrder.setHeaderRecord(headerRecord);
        recordOrderList.add(headerRecordOrder);
    }

    /**
     * Transforms Detail Records.
     * 
     * @param counter
     * @param strippedLine
     * @param records
     * @param effectiveBankedDate
     * @throws SILException
     */
    private void transformDetailRecords(int counter, String strippedLine, List<BankStatementRecordOrder> recordOrderList,
            BigInteger effectiveBankedDate) throws SILException {
        SILLogger.debug(BatchServiceConstants.BANK_STATEMENT_TRANSFORMATION_LOGGING_FORMAT, className, "Transforming Detail Records");
        String sequenceNumber = this.generateReceiptSequenceNumber(counter);
        if (checkValue(sequenceNumber)) {
            this.generateDetailRecordOrder(strippedLine, recordOrderList, effectiveBankedDate, sequenceNumber);
        } else {
            throw new SILException(BatchServiceConstants.GENERATE_SEQUENCE_NUMBER_EXCEPTION);
        }
    }

    /**
     * Generates Transaction Record Order.
     * 
     * @param strippedLine
     * @param records
     * @param effectiveBankedDate
     * @param sequenceNumber
     * @throws SILException
     */
    private void generateDetailRecordOrder(String strippedLine, List<BankStatementRecordOrder> recordOrderList, BigInteger effectiveBankedDate,
            String sequenceNumber) throws SILException {
        if (checkStripLineReference(strippedLine)) {
            SILLogger.debug(BatchServiceConstants.BANK_STATEMENT_TRANSFORMATION_LOGGING_FORMAT, className, "Generating Transaction Record Order");
            BankStatementDetailRecord detailRecord = new BankStatementDetailRecord();
            retrieveDetailRecordValues(strippedLine, effectiveBankedDate, sequenceNumber, detailRecord);
            BankStatementRecordOrder detailRecordOrder = new BankStatementRecordOrder();
            detailRecordOrder.setDetailRecord(detailRecord);
            recordOrderList.add(detailRecordOrder);
        }
    }

    /**
     * This method is used to retrieve Detail Record.
     * 
     * @param strippedLine
     * @param effectiveBankedDate
     * @param sequenceNumber
     * @param detailRecord
     * @throws SILException
     */
    private void retrieveDetailRecordValues(String strippedLine, BigInteger effectiveBankedDate, String sequenceNumber,
            BankStatementDetailRecord detailRecord) throws SILException {
        detailRecord.setDetailRecordType(BatchServiceConstants.DETAIL_RECORD_TYPE_VALUE);
        detailRecord.setEmployeeNumber(BatchServiceConstants.EMPTY_STRING_VALUE);
        detailRecord.setReceiptAmount(new BigDecimal(strippedLine.substring(2, 17)).divide(new BigDecimal(100)));
        detailRecord.setPaymentReference(this.getPaymentReferenceValue(strippedLine));
        detailRecord.setAccountNumber(BatchServiceConstants.EMPTY_STRING_VALUE);
        detailRecord.setBankAccount(BatchServiceConstants.BANK_ACCOUNT_NUMBER);
        detailRecord.setEffectiveDate(effectiveBankedDate);
        detailRecord.setDateBanked(effectiveBankedDate);
        detailRecord.setToCurrencyCode(CommonConstants.CURRENCY_CODE);
        detailRecord.setDepositTypeCode(BatchServiceConstants.DIRECT_CREDIT_CODE_TYPE_VALUE);
        detailRecord.setChequeBSB(BatchServiceConstants.EMPTY_STRING_VALUE);
        detailRecord.setChequeBankAccountNumber(BatchServiceConstants.EMPTY_STRING_VALUE);
        detailRecord.setChequeAccountName(BatchServiceConstants.EMPTY_STRING_VALUE);
        detailRecord.setChequeNumber(BatchServiceConstants.EMPTY_STRING_VALUE);
        detailRecord.setReceiptNumber(this.getGeneratedReceiptNumber(effectiveBankedDate, sequenceNumber));
        detailRecord.setFromCurrencyCode(CommonConstants.CURRENCY_CODE);
        detailRecord.setReceiptConversionRate(BatchServiceConstants.RECEIPT_CONVERSION_RATE_VALUE);
        detailRecord.setReference(strippedLine.substring(21, 36));
    }

    /**
     * This method is used to check the reference value in the stripped record.
     * 
     * @param strippedLine
     * 
     * @return
     */
    private boolean checkStripLineReference(String strippedLine) {
        String referencevalue1 = strippedLine.substring(21, 37).trim();
        String referenceValue2 = strippedLine.substring(45, 63).trim();
        if (referencevalue1.equalsIgnoreCase("SUNCORP SUPER Ap")) {
            String[] invalidReferences = { "0040384", "0040386", "0040387", "0040388", "0040389", "0040390" };
            for (String reference : invalidReferences) {
                if (referenceValue2.equalsIgnoreCase(reference)) {
                     return false;
                }
            }
        }
        return true;
    }

    /**
     * Gets Payment Reference Value.
     * 
     * @param strippedLine
     * @return
     */
    private String getPaymentReferenceValue(String strippedLine) {
        SILLogger.debug(BatchServiceConstants.BANK_STATEMENT_TRANSFORMATION_LOGGING_FORMAT, className, "Getting Payment Reference Value");
        String paymentReference;
        String billerCodeRecord = strippedLine.substring(21, 36);
        if (checkValue(billerCodeRecord) && billerCodeRecord.trim().contains(BatchServiceConstants.BILLER_CODE)) {
            String billerCodePaymentReference = strippedLine.substring(63, 70);
            if (checkValue(billerCodePaymentReference)) {
                paymentReference = billerCodePaymentReference.trim();
            } else {
                paymentReference = BatchServiceConstants.EMPTY_STRING_VALUE;
            }
        } else {
            String nonBillerCodePaymentReference = strippedLine.substring(45, 63).trim();
            if (checkValue(nonBillerCodePaymentReference)) {
                paymentReference = nonBillerCodePaymentReference.trim();
            } else {
                paymentReference = BatchServiceConstants.EMPTY_STRING_VALUE;
            }
        }
        return paymentReference;
    }

    /**
     * Gets Generated Receipt Number.
     * 
     * @param effectiveBankedDate
     * @param sequenceNumber
     * @return
     * @throws SILException
     */
    private String getGeneratedReceiptNumber(BigInteger effectiveBankedDate, String sequenceNumber) throws SILException {
        SILLogger.debug(BatchServiceConstants.BANK_STATEMENT_TRANSFORMATION_LOGGING_FORMAT, className, "Getting Generated Receipt Number");
        String receiptNumber = this.generateReceiptNumber(effectiveBankedDate, sequenceNumber);
        if (checkValue(receiptNumber)) {
            return receiptNumber;
        } else {
            throw new SILException(BatchServiceConstants.GENERATE_RECEIPT_NUMBER_EXCEPTION);
        }
    }

    /**
     * Converts JulianDate To BigInteger.
     * 
     * @param inputDate
     * @return
     * @throws SILException
     */
    private BigInteger convertJulianDateToBigInteger(String inputDate) throws SILException {
        SILLogger.debug(BatchServiceConstants.BANK_STATEMENT_TRANSFORMATION_LOGGING_FORMAT, className, "Converting JulianDate To BigInteger");
        SimpleDateFormat sdf = new SimpleDateFormat(BatchServiceConstants.JULIAN_DATE_FORMAT);
        SimpleDateFormat sdfIso = new SimpleDateFormat(BatchServiceConstants.ISO_DATE_FORMAT);
        BigInteger outputDate = null;
        try {
            outputDate = new BigInteger(sdfIso.format(sdf.parse(inputDate)));
        } catch (ParseException exception) {
            throw new SILException(BatchServiceConstants.JULIAN_DATE_CONVERSION_PARSE_EXCEPTION);
        }
        return outputDate;
    }

    /**
     * Generating Receipt Number.
     * 
     * @param effectiveBankedDate
     * @param sequenceNumber
     * @return
     */
    private String generateReceiptNumber(BigInteger effectiveBankedDate, String sequenceNumber) {
        if (effectiveBankedDate != null) {
            SILLogger.debug(BatchServiceConstants.BANK_STATEMENT_TRANSFORMATION_LOGGING_FORMAT, className, "Generating Receipt Number");
            return BatchServiceConstants.RECEIPT_PREFIX_LETTER.concat(effectiveBankedDate.toString()).concat(sequenceNumber);
        } else {
            return BatchServiceConstants.EMPTY_STRING_VALUE;
        }
    }

    /**
     * Generates Sequence Number.
     * 
     * @param count
     * @return
     * @throws SILException
     */
    private String generateReceiptSequenceNumber(int count) throws SILException {
        SILLogger.debug(BatchServiceConstants.BANK_STATEMENT_TRANSFORMATION_LOGGING_FORMAT, className, "Generating Sequence Number");
        if (count > 9999) {
            throw new SILException(BatchServiceConstants.BANK_STATEMENT_MAX_LIMIT_MSG);
        }
        if (count > 0 && count < 10) {
            return BatchServiceConstants.SEQUENCE_NUMBER_THREE_ZERO.concat(String.valueOf(count));
        } else {
            return checkLimit(count);
        }
    }

    /**
     * This method is used to check the limit.
     * 
     * @param count
     * @return
     */
    private String checkLimit(int count) {
        SILLogger.debug(BatchServiceConstants.BANK_STATEMENT_TRANSFORMATION_LOGGING_FORMAT, className, "Entering checkLimit()");
        if (count > 9 && count < 100) {
            return BatchServiceConstants.SEQUENCE_NUMBER_TWO_ZERO.concat(String.valueOf(count));
        } else if (count > 99 && count < 1000) {
            return BatchServiceConstants.SEQUENCE_NUMBER_ONE_ZERO.concat(String.valueOf(count));
        } else if (count > 999 && count < 10000) {
            return String.valueOf(count);
        } else {
            return BatchServiceConstants.EMPTY_STRING_VALUE;
        }
    }

    /**
     * Checks Null Value.
     * 
     * @param value
     * @return
     */
    private boolean checkValue(String value) {
        SILLogger.debug(BatchServiceConstants.BANK_STATEMENT_TRANSFORMATION_LOGGING_FORMAT, className, "Checking Null Value");
        if (value != null && !value.trim().equalsIgnoreCase("")) {
            return true;
        }
        return false;
    }
}
