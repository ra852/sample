////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.processor.batchservice;

import java.io.File;
import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.component.cxf.common.message.CxfConstants;

import com.sonatacentral.service.v30.common.system.StartJobRequestType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.batchservice.BatchServiceConstants;
import com.suncorp.ssp.service.integration.batchservice.util.CommonFundFeeUtil;

/**
 * The class {@code CommonFundFeeRequestProcessor} is used to perform the operations of CommonFundFee.
 * 
 * @author U383754
 * @since 02/11/2016
 * @version 1.0
 */
public class CommonFundFeeRequestProcessor implements Processor {
    private String className = "CommonFundFeeRequestProcessor";

    /**
     * This method is used to prepare request for CommonFundFee.
     * 
     * @param exchange
     * @throws Exception
     */
    @Override
    public void process(Exchange exchange) throws Exception {
        SILLogger.debug(BatchServiceConstants.COMMON_FUND_FEE_LOGGING_FORMAT, className, "Entering process()");
        try {
            File inboundFile = exchange.getIn().getBody(File.class);
            CommonFundFeeUtil util = new CommonFundFeeUtil(inboundFile.getName(), BatchServiceConstants.COMMON_FUND_FEE_LOGGING_FORMAT);
            StartJobRequestType outboundRequest = util.createCommonFundFeeRequest();
            this.setHeaderAndBody(exchange, outboundRequest);
            SILLogger.debug(BatchServiceConstants.COMMON_FUND_FEE_LOGGING_FORMAT, className, "Exiting process()");
        } catch (Exception exception) {
            SILLogger.error(BatchServiceConstants.COMMON_FUND_FEE_LOGGING_FORMAT, className, SILUtil.getReqExMsg(exception));
            throw new SILException(BatchServiceConstants.COMMON_FUND_FEE_GENERIC_EXCEPTION);
        }
    }

    /**
     * Sets Header and Body.
     * 
     * @param exchange
     * @param outboundRequest
     */
    private void setHeaderAndBody(Exchange exchange, StartJobRequestType outboundRequest) {
        SILLogger.debug(BatchServiceConstants.COMMON_FUND_FEE_LOGGING_FORMAT, className, "Entering setHeaderAndBody()");
        Map<String, Object> mapHeaders = new HashMap<String, Object>();
        mapHeaders.put(CxfConstants.OPERATION_NAME, BatchServiceConstants.START_JOB_OPERATION_NAME);
        mapHeaders.put(CxfConstants.OPERATION_NAMESPACE, BatchServiceConstants.START_JOB_OPERATION_NAMESPACE);
        exchange.getIn().setHeaders(mapHeaders);
        exchange.getIn().setBody(outboundRequest);
        SILLogger.debug(BatchServiceConstants.COMMON_FUND_FEE_LOGGING_FORMAT, className, "Exiting setHeaderAndBody()");
    }
}
