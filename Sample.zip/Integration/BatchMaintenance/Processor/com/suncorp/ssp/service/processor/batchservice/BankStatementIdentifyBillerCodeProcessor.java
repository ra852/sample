////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.processor.batchservice;

import java.util.ArrayList;
import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.batchservice.BatchServiceConstants;

import com.suncorp.ssp.service.integration.batchservice.bean.BankStatementStartWorkflowRequest;
import com.suncorp.ssp.service.integration.batchservice.bean.bankstatement.BankStatementDetailRecord;
import com.suncorp.ssp.service.integration.batchservice.bean.bankstatement.BankStatementRecordOrder;

/**
 * The class {@code BankStatementIdentifyBillerCodeProcessor} is used to identify Biller code detail records.
 * 
 * @author U383847
 * @since 29/04/2016
 * @version 1.0
 */
public class BankStatementIdentifyBillerCodeProcessor implements Processor {
    private final String className = "BankStatementIdentifyBillerCodeProcessor";

    /**
     * Gets the detail records and identify Biller codes for records for TriggerWorkflow functionality.
     *
     * @param exchange
     * @throws Exception
     */
    @Override
    public void process(Exchange exchange) throws SILException {
        SILLogger.debug(BatchServiceConstants.BANK_STATEMENT_WORKFLOW_LOGGING_FORMAT, className, "Entering in process method");
        try {
            exchange.setProperty(CommonConstants.RESPONSE_CLASS_NAME, BatchServiceConstants.START_WORKFLOW_RESPONSE_CLASS);
            List<BankStatementRecordOrder> recordOrderList = (List<BankStatementRecordOrder>) exchange.getIn().getBody();
            List<BankStatementDetailRecord> workflowRecordList = new ArrayList<BankStatementDetailRecord>();
            if (recordOrderList != null && recordOrderList.size() > 0) {
                this.generateWorkflowRecords(recordOrderList, workflowRecordList);
                BankStatementStartWorkflowRequest startWorkflowRequest = new BankStatementStartWorkflowRequest();
                startWorkflowRequest.setBankStatementDetailRecordList(workflowRecordList);
                exchange.getIn().setBody(startWorkflowRequest);
            }
        } catch (ClassCastException classCastException) {
            throw new SILException(BatchServiceConstants.NO_BILLER_CODE_RECORDS_GENERIC_EXCEPTION);
        } catch (Exception exception) {
            SILLogger.error(BatchServiceConstants.BANK_STATEMENT_WORKFLOW_LOGGING_FORMAT, className, SILUtil.getReqExMsg(exception));
            throw new SILException(BatchServiceConstants.BANK_STATEMENT_BILLER_CODE_GENERIC_EXCEPTION);
        }
    }

    /**
     * Generates Workflow Records.
     *
     * @param recordOrderList
     * @param workflowRecordList
     */
    private void generateWorkflowRecords(List<BankStatementRecordOrder> recordOrderList, List<BankStatementDetailRecord> workflowRecordList) {
        SILLogger.debug(BatchServiceConstants.BANK_STATEMENT_WORKFLOW_LOGGING_FORMAT, className, "Generating Workflow Records");
        for (BankStatementRecordOrder bankStatementRecordOrder : recordOrderList) {
            identifyWorkflowRecords(workflowRecordList, bankStatementRecordOrder);
        }
    }

    /**
     * Identify Workflow Records.
     *
     * @param workflowRecordList
     * @param bankStatementRecordOrder
     */
    private void identifyWorkflowRecords(List<BankStatementDetailRecord> workflowRecordList, BankStatementRecordOrder bankStatementRecordOrder) {
        BankStatementDetailRecord workflowDetailRecord = new BankStatementDetailRecord();
        if (bankStatementRecordOrder.getHeaderRecord() != null && bankStatementRecordOrder.getDetailRecord() != null &&
                bankStatementRecordOrder.getDetailRecord().getReference() != null) {
            String reference = bankStatementRecordOrder.getDetailRecord().getReference();
            identifyBillerCodeRecords(workflowRecordList, bankStatementRecordOrder, workflowDetailRecord, reference);
        }
    }

    /**
     * Identify Biller Code Records.
     *
     * @param workflowRecordList
     * @param bankStatementRecordOrder
     * @param workflowDetailRecord
     * @param reference
     */
    private void identifyBillerCodeRecords(List<BankStatementDetailRecord> workflowRecordList, BankStatementRecordOrder bankStatementRecordOrder,
            BankStatementDetailRecord workflowDetailRecord, String reference) {
        if (BatchServiceConstants.HEADER_RECORD_TYPE_VALUE.endsWith(bankStatementRecordOrder.getHeaderRecord().getHeaderRecordType())) {
            return;
        } else if (BatchServiceConstants.DETAIL_RECORD_TYPE_VALUE.endsWith(bankStatementRecordOrder.getHeaderRecord().getHeaderRecordType()) &&
                (reference.contains(BatchServiceConstants.BILLER_CODE) || reference.contains(BatchServiceConstants.MEMBER_BILLER_CODE))) {
            this.getBillerCodeRecords(bankStatementRecordOrder, workflowDetailRecord);
            workflowRecordList.add(workflowDetailRecord);
        }
    }

    /**
     * Gets Biller Code Records.
     *
     * @param bankStatementRecordOrder
     * @param workflowDetailRecord
     */
    private void getBillerCodeRecords(BankStatementRecordOrder bankStatementRecordOrder, BankStatementDetailRecord workflowDetailRecord) {
        SILLogger.debug(BatchServiceConstants.BANK_STATEMENT_WORKFLOW_LOGGING_FORMAT, className, "Getting Biller Code Records");
        workflowDetailRecord.setDetailRecordType(bankStatementRecordOrder.getHeaderRecord().getHeaderRecordType());
        workflowDetailRecord.setReceiptAmount(bankStatementRecordOrder.getHeaderRecord().getTotalAmount());
        if (bankStatementRecordOrder.getDetailRecord().getEffectiveDate() != null) {
            workflowDetailRecord.setEffectiveDate(bankStatementRecordOrder.getDetailRecord().getEffectiveDate());
        }
        if (bankStatementRecordOrder.getDetailRecord().getReceiptNumber() != null) {
            workflowDetailRecord.setReceiptNumber(bankStatementRecordOrder.getDetailRecord().getReceiptNumber());
        }
        String billerCodeValue = bankStatementRecordOrder.getDetailRecord().getReference();
        if (billerCodeValue.contains(BatchServiceConstants.BILLER_CODE)) {
            workflowDetailRecord.setReference(billerCodeValue.substring(billerCodeValue.lastIndexOf(BatchServiceConstants.BILLER_CODE),
                    billerCodeValue.length()));
        } else if (billerCodeValue.contains(BatchServiceConstants.MEMBER_BILLER_CODE)) {
            workflowDetailRecord.setReference(billerCodeValue.substring(billerCodeValue.lastIndexOf(BatchServiceConstants.MEMBER_BILLER_CODE)));
        }        
    }
}
