////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.processor.batchservice;

import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.component.cxf.common.message.CxfConstants;

import com.sonatacentral.service.v30.workflow.StartWorkflowRequestType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.batchservice.BatchServiceConstants;
import com.suncorp.ssp.service.integration.batchservice.bean.BankStatementStartWorkflowRequest;
import com.suncorp.ssp.service.integration.batchservice.bean.bankstatement.BankStatementDetailRecord;
import com.suncorp.ssp.service.integration.batchservice.util.BankStatementWorkflowRequestUtil;

/**
 * The class {@code BankStatementWorkflowRequestProcessor} is used to get the Biller code records, call Sonata's startWorkflow service.
 * 
 * @author U383847
 * @since 28/04/2016
 * @version 1.0
 */
public class BankStatementWorkflowRequestProcessor implements Processor {
    private final String className = "BankStatementWorkflowRequestProcessor";

    /**
     * Constructs TriggerWorkflow Outbound request for BankStatement functionality.
     * 
     * @param exchange
     * @throws Exception
     */
    @Override
    public void process(Exchange exchange) throws SILException {
        SILLogger.debug(BatchServiceConstants.BANK_STATEMENT_WORKFLOW_LOGGING_FORMAT, className, "Entering in process method");
        try {
            exchange.setProperty(CommonConstants.RESPONSE_CLASS_NAME, BatchServiceConstants.START_WORKFLOW_RESPONSE_CLASS);
            BankStatementStartWorkflowRequest inboundRequest = this.getInboundRequest(exchange);
            persistRequestObject(exchange, inboundRequest);
            StartWorkflowRequestType startWorkflowRequestType = new BankStatementWorkflowRequestUtil(inboundRequest).createOutboundRequest();
            this.setHeaderAndBody(exchange, startWorkflowRequestType);
            exchange.setProperty(BatchServiceConstants.LOGGER_CLASS_TYPE, BatchServiceConstants.BANK_STATEMENT_WORKFLOW_LOGGING_FORMAT);
        } catch (Exception exception) {
            SILLogger.error(BatchServiceConstants.BANK_STATEMENT_WORKFLOW_LOGGING_FORMAT, className, SILUtil.getRespExMsg(exception));
            throw new SILException(BatchServiceConstants.BANK_STATEMENT_STARTJOB_GENERIC_EXCEPTION);
        }
    }

    /**
     * Gets Inbound Request.
     * 
     * @param exchange
     * @return
     */
    private BankStatementStartWorkflowRequest getInboundRequest(Exchange exchange) {
        SILLogger.debug(BatchServiceConstants.BANK_STATEMENT_WORKFLOW_LOGGING_FORMAT, className, "Getting Inbound Request");
        BankStatementStartWorkflowRequest inboundRequest =
                (BankStatementStartWorkflowRequest) (exchange.getIn().getBody(BankStatementStartWorkflowRequest.class) != null ? exchange.getIn()
                        .getBody(BankStatementStartWorkflowRequest.class) : (BankStatementStartWorkflowRequest) exchange
                        .getProperty(BatchServiceConstants.BANK_STAT_WF_PERSIST_REQ_OBJECT));
        return inboundRequest;
    }

    /**
     * Persists Request Object for next workflow record.
     * 
     * @param exchange
     * @param inboundRequest
     */
    private void persistRequestObject(Exchange exchange, BankStatementStartWorkflowRequest inboundRequest) {
        SILLogger.debug(BatchServiceConstants.BANK_STATEMENT_WORKFLOW_LOGGING_FORMAT, className, "Persist Request Object for next workflow record");
        int loopIndex = (int) exchange.getProperty(CommonConstants.CAMEL_LOOP_INDEX);
        BankStatementDetailRecord bankStatementDetailRecord = inboundRequest.getBankStatementDetailRecordList().get(loopIndex);
        inboundRequest.setBankStatementDetailRecord(bankStatementDetailRecord);
        exchange.setProperty(BatchServiceConstants.BANK_STAT_WF_PERSIST_REQ_OBJECT, inboundRequest);
    }

    /**
     * Sets Header And Body.
     * 
     * @param exchange
     * @param startWorkflowRequestType
     */
    private void setHeaderAndBody(Exchange exchange, StartWorkflowRequestType startWorkflowRequestType) {
        SILLogger.debug(BatchServiceConstants.BANK_STATEMENT_WORKFLOW_LOGGING_FORMAT, className, "Setting Header And Body");
        Map<String, Object> mapHeaders = new HashMap<String, Object>();
        mapHeaders.put(CxfConstants.OPERATION_NAME, BatchServiceConstants.START_WORKFLOW_OPERATION_NAME);
        mapHeaders.put(CxfConstants.OPERATION_NAMESPACE, BatchServiceConstants.START_WORKFLOW_OPERATION_NAMESPACE);
        exchange.getIn().setHeaders(mapHeaders);
        exchange.getIn().setBody(startWorkflowRequestType);
    }
}
