////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.transformation.applicationservice;

import javax.ws.rs.core.Response;

import org.apache.camel.Exchange;

import com.sonatacentral.service.v30.wrap.application.AccountApplicationResponseType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.applicationservice.ApplicationServiceConstants;
import com.suncorp.ssp.service.integration.applicationservice.bean.AccountApplicationResponse;
import com.suncorp.ssp.service.integration.applicationservice.util.AccountApplicationResponseUtil;

/**
 * The class {@code CreateAccountApplicationResponseTransformer} transforms the response to required format for end client.
 * 
 * @author U383847
 * @since 06/01/2016
 * @version 1.0
 */
public class CreateAccountApplicationResponseTransformer {
    private final String className = "CreateAccountApplicationResponseTransformer";

    /**
     * Extracts the values from end client's request and constructs a new request as per the CreateAccountApplication service.
     *
     * @param exchange
     * @throws Exception
     */
    public void transform(Exchange exchange) throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Entering in transform method");
        try {
            AccountApplicationResponseType accountApplicationResponseType = exchange.getIn().getBody(AccountApplicationResponseType.class);
            AccountApplicationResponse accountApplicationResponse = new AccountApplicationResponse();
            AccountApplicationResponseUtil createAccountApplicationResponseUtil = new AccountApplicationResponseUtil(accountApplicationResponseType);
            createAccountApplicationResponseUtil.createAccountApplicationReponse(accountApplicationResponse);
            Response response = Response.status(Response.Status.OK).entity(accountApplicationResponse).build();
            exchange.getIn().setBody(response);
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Exiting from transform method");
        } catch (SILException exception) {
            SILLogger.error(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, SILUtil.getRespExMsg(exception));
            throw new SILException(SILUtil.getRespExMsg(exception));
        } catch (Exception exception) {
            SILLogger.error(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, SILUtil.getReqExMsg(exception));
            throw new SILException(ApplicationServiceConstants.CREATE_ACC_APP_EXCEPTION_MESSAGE);
        }
    }
}
