////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.processor.applicationservice;

import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.component.cxf.common.message.CxfConstants;

import com.sonatacentral.service.v30.wrap.application.AccountApplicationRequestType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.applicationservice.ApplicationServiceConstants;
import com.suncorp.ssp.service.integration.applicationservice.bean.AccountApplicationRequest;
import com.suncorp.ssp.service.integration.applicationservice.util.AccountApplicationRequestUtil;

/**
 * The class {@code CreateAccountApplicationRequestProcessor} processes/constructs SOAP request for external service.
 * 
 * @author U383847
 * @since 06/01/2016
 * @version 1.0
 */
public class CreateAccountApplicationRequestProcessor implements Processor {
    private final String className = "CreateAccountApplicationRequestProcessor";

    /**
     * Extracts the values from end client's request and constructs a new request as per the external service's format.
     * 
     * @param exchange
     * @throws Exception
     */
    @Override
    public void process(Exchange exchange) throws Exception {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Entering in process method");
        try {
            exchange.setProperty(CommonConstants.RESPONSE_CLASS_NAME, ApplicationServiceConstants.CREATE_ACC_APP_RESPONSE_CLASS_NAME);
            AccountApplicationRequest accountApplicationRequest = exchange.getIn().getBody(AccountApplicationRequest.class);
            AccountApplicationRequestType accountApplicationRequestType = new AccountApplicationRequestType();
            if (accountApplicationRequest != null) {
                accountApplicationRequestType.setCallerDetails(SILUtil.createCallerDetails());
                accountApplicationRequestType.setResponseLevel(ApplicationServiceConstants.RESPONSE_LEVEL);
                AccountApplicationRequestUtil accountApplicationRequestUtil = new AccountApplicationRequestUtil(accountApplicationRequest);
                accountApplicationRequestUtil.createAccountApplicationRequest(accountApplicationRequestType);
            }
            setHeadersBody(exchange, accountApplicationRequestType);
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Exiting from process method");
        } catch (SILException silException) {
            SILLogger.error(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, SILUtil.getReqExMsg(silException));
            exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, CommonConstants.HTTP_BAD_REQUEST_CODE);
            throw new SILException(SILUtil.getReqExMsg(silException));
        } catch (Exception exception) {
            SILLogger.error(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, SILUtil.getReqExMsg(exception));
            throw new SILException(ApplicationServiceConstants.CREATE_ACC_APP_EXCEPTION_MESSAGE);
        }
    }

    /**
     * Set Headers and Body for SOAP Request.
     * 
     * @param exchange
     * @param accountApplicationRequestType
     */
    private void setHeadersBody(Exchange exchange, AccountApplicationRequestType accountApplicationRequestType) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Headers and Body for SOAP Request");
        Map<String, Object> mapHeaders = new HashMap<String, Object>();
        mapHeaders.put(CxfConstants.OPERATION_NAME, ApplicationServiceConstants.CREATE_ACC_APP_OPERATION_NAME);
        mapHeaders.put(CxfConstants.OPERATION_NAMESPACE, ApplicationServiceConstants.OPERATION_NAMESPACE);
        exchange.getIn().setHeaders(mapHeaders);
        exchange.getIn().setBody(accountApplicationRequestType);
    }
}
