////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code DistributionOutletBean} is a java bean consisting properties related to Distribution Outlet details.
 * 
 * @author U384381
 * @since 01/03/2016
 * @version 1.0
 */
public class DistributionOutletBean {
    private String id;
    private String name;
    private String advisorNumber;
    private String clientId;
    private IDRefBean clientRef;
    private String clientForename;
    private String clientSurname;
    private MasterSchemeIdentifierDetails masterScheme;
    private String username;
    private AuditDetails audit;

    /**
     * Accessor for property id.
     * 
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     * 
     * @return id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id != null ? id : "";
    }

    /**
     * Accessor for property name.
     * 
     * @return name of type String
     */
    public String getName() {
        return name;
    }

    /**
     * Mutator for property name.
     * 
     * @return name of type String
     */
    @XmlElement(name = "name")
    public void setName(String name) {
        this.name = name != null ? name : "";
    }

    /**
     * Accessor for property advisorNumber.
     * 
     * @return advisorNumber of type String
     */
    public String getAdvisorNumber() {
        return advisorNumber;
    }

    /**
     * Mutator for property advisorNumber.
     * 
     * @return advisorNumber of type String
     */
    @XmlElement(name = "advisorNumber")
    public void setAdvisorNumber(String advisorNumber) {
        this.advisorNumber = advisorNumber != null ? advisorNumber : "";
    }

    /**
     * Accessor for property clientId.
     * 
     * @return clientId of type String
     */
    public String getClientId() {
        return clientId;
    }

    /**
     * Mutator for property clientId.
     * 
     * @return clientId of type String
     */
    @XmlElement(name = "clientId")
    public void setClientId(String clientId) {
        this.clientId = clientId != null ? clientId : "";
    }

    /**
     * Accessor for property outletRefType.
     * 
     * @return outletRefType of type IDRefBean
     */
    public IDRefBean getClientRef() {
        return clientRef;
    }

    /**
     * Mutator for property outletRefType.
     * 
     * @return outletRefType of type IDRefBean
     */
    @XmlElement(name = "clientRef")
    public void setClientRef(IDRefBean clientRef) {
        this.clientRef = clientRef;
    }

    /**
     * Accessor for property clientForename.
     * 
     * @return clientForename of type String
     */
    public String getClientForename() {
        return clientForename;
    }

    /**
     * Mutator for property clientForename.
     * 
     * @return clientForename of type String
     */
    @XmlElement(name = "clientForename")
    public void setClientForename(String clientForename) {
        this.clientForename = clientForename != null ? clientForename : "";
    }

    /**
     * Accessor for property clientSurname.
     * 
     * @return clientSurname of type String
     */
    public String getClientSurname() {
        return clientSurname;
    }

    /**
     * Mutator for property clientSurname.
     * 
     * @return clientSurname of type String
     */
    @XmlElement(name = "clientSurname")
    public void setClientSurname(String clientSurname) {
        this.clientSurname = clientSurname != null ? clientSurname : "";
    }

    /**
     * Accessor for property masterScheme.
     * 
     * @return masterScheme of type MasterSchemeIdentifierDetails
     */
    public MasterSchemeIdentifierDetails getMasterScheme() {
        return masterScheme;
    }

    /**
     * Mutator for property masterScheme.
     * 
     * @return masterScheme of type MasterSchemeIdentifierDetails
     */
    @XmlElement(name = "masterScheme")
    public void setMasterScheme(MasterSchemeIdentifierDetails masterScheme) {
        this.masterScheme = masterScheme;
    }

    /**
     * Accessor for property username.
     * 
     * @return username of type String
     */
    public String getUsername() {
        return username;
    }

    /**
     * Mutator for property username.
     * 
     * @return username of type String
     */
    @XmlElement(name = "username")
    public void setUsername(String username) {
        this.username = username != null ? username : "";
    }

    /**
     * Accessor for property audit.
     * 
     * @return audit of type AuditDetails
     */
    public AuditDetails getAudit() {
        return audit;
    }

    /**
     * Mutator for property audit.
     * 
     * @return audit of type AuditDetails
     */
    @XmlElement(name = "audit")
    public void setAudit(AuditDetails audit) {
        this.audit = audit;
    }

}
