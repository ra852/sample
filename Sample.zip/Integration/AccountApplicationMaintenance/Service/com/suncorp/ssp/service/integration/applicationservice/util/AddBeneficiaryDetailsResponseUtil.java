////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.util;

import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.AdvisorIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.ClientIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.BeneficiaryType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.ClientAccountRelationshipIdentifierType;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.applicationservice.ApplicationServiceConstants;
import com.suncorp.ssp.service.integration.applicationservice.bean.BeneficiaryBean;
import com.suncorp.ssp.service.integration.applicationservice.bean.ClientAccountRelationshipBean;
import com.suncorp.ssp.service.integration.applicationservice.bean.ClientDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.CodeNameIdentifier;
import com.suncorp.ssp.service.integration.applicationservice.bean.DistributionOutletBean;
import com.suncorp.ssp.service.integration.applicationservice.bean.IDRefBean;

/**
 * The class {@code AddBeneficiaryDetailsResponseUtil} is used as a util class for preparing CreateAccountApplication service's Beneficiary Details.
 * 
 * @author U384381
 * @since 29/02/2016
 * @version 1.0
 */
public class AddBeneficiaryDetailsResponseUtil {
    private String cName = "AddBeneficiaryDetailsResponseUtil";
    private AccountApplicationUtil accountApplicationUtil = new AccountApplicationUtil();
    private BeneficiaryBean outboundBeneficiary = null;
    private BeneficiaryType inboundBeneficiary = null;

    /**
     * Default constructor.
     * 
     */
    public AddBeneficiaryDetailsResponseUtil() {

    }

    /**
     * Initializes the inbound and outbound response objects.
     * 
     * @param inboundBeneficiary of type BeneficiaryType
     */
    public AddBeneficiaryDetailsResponseUtil(BeneficiaryType inboundBeneficiary) {
        this.inboundBeneficiary = inboundBeneficiary;
        this.outboundBeneficiary = new BeneficiaryBean();
    }

    /**
     * Returns a new instance of BeneficiaryBean, with necessary values set.
     * 
     * @return outboundBeneficiary of type BeneficiaryBean
     */
    public BeneficiaryBean createOutboundBeneficiary() {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, cName, "Entering createBeneficiary()");
        if (this.inboundBeneficiary != null) {
            this.outboundBeneficiary.setClientAccountRelationship(createClientAccountRelationship());
            this.outboundBeneficiary.setCategory(this.accountApplicationUtil.createCodeIdentifierInfo(this.inboundBeneficiary.getCategory()));
            this.outboundBeneficiary.setType(this.accountApplicationUtil.createCodeIdentifierInfo(this.inboundBeneficiary.getType()));
            this.outboundBeneficiary.setRelationship(this.accountApplicationUtil.createCodeIdentifierInfo(this.inboundBeneficiary.getRelationship()));
            this.outboundBeneficiary.setDistributionOutlet(createDistributionOutlet());
            setBeneficiaryDetails();
        } else {
            createDefaultOutboundBeneficiary();
        }
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, cName, "Exiting createBeneficiary()");
        return outboundBeneficiary;
    }

    /**
     * Returns a new instance of ClientAccountRelationshipBean, with necessary values set.
     * 
     * @return outboundClientAccountRelationshipBean of type ClientAccountRelationshipBean
     */
    private ClientAccountRelationshipBean createClientAccountRelationship() {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, cName, "Entering createClientAccountRelationship()");
        ClientAccountRelationshipBean outboundClientAccountRelationshipBean = new ClientAccountRelationshipBean();
        ClientAccountRelationshipIdentifierType inboundCAR = this.inboundBeneficiary.getClientAccountRelationship();
        if (inboundCAR != null) {
            outboundClientAccountRelationshipBean = new ClientAccountRelationshipBean();
            outboundClientAccountRelationshipBean.setId(inboundCAR.getId() != null ? inboundCAR.getId().toString() : "");
            outboundClientAccountRelationshipBean.setClient(createClient());
            outboundClientAccountRelationshipBean.setRelationshipType(createClientAccountRelationshipType());
            outboundClientAccountRelationshipBean.setPrimaryFlag(inboundCAR.isPrimary() != null ? inboundCAR.isPrimary().toString() : "");
        } else {
            return createDefaultClientAccountRelationship();
        }
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, cName, "Exiting createClientAccountRelationship()");
        return outboundClientAccountRelationshipBean;
    }

    /**
     * Returns a new instance of ClientDetails, with necessary values set.
     * 
     * @return outboundClientBean of type ClientDetails
     */
    private ClientDetails createClient() {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, cName, "Entering createClient()");
        ClientDetails outboundClientBean = null;
        ClientIdentifierType inboundClient = this.inboundBeneficiary.getClientAccountRelationship().getClient();
        if (inboundClient != null) {
            outboundClientBean = new ClientDetails();
            outboundClientBean.setClientId(inboundClient.getId() != null ? inboundClient.getId().toString() : "");
            outboundClientBean.setName(inboundClient.getName());
            outboundClientBean.setMasterScheme(this.accountApplicationUtil.createMasterScheme(inboundClient.getMasterScheme()));
            outboundClientBean.setClientPointer(this.accountApplicationUtil.createClientPointer(inboundClient.getClientPointer()));
            outboundClientBean.setClientRef(this.accountApplicationUtil.createClientRef(inboundClient.getClientExternalRef()));
            outboundClientBean.setClientSurname(inboundClient.getClientSurname());
            outboundClientBean.setClientForename(inboundClient.getClientForename());
            outboundClientBean.setClientForename2(inboundClient.getClientForename2());
            outboundClientBean.setClientTFN(inboundClient.getClientTFN());
            outboundClientBean.setAudit(this.accountApplicationUtil.createAuditInfo(inboundClient.getAudit()));
            outboundClientBean.setGlobalIntermediaryIDNumber(inboundClient.getGlobalIntermediaryIDNumber());
        } else {
            return createDefaultClient();
        }
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, cName, "Exiting createClient()");
        return outboundClientBean;
    }

    /**
     * Returns a new instance of CodeNameIdentifier, with necessary values set.
     * 
     * @return outboundRelationshipTypeBean of type CodeNameIdentifier
     */
    private CodeNameIdentifier createClientAccountRelationshipType() {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, cName, "Entering createClientAccountRelationshipType()");
        CodeNameIdentifier outboundRelationshipTypeBean = null;
        if (this.inboundBeneficiary.getClientAccountRelationship() != null) {
            outboundRelationshipTypeBean = new CodeNameIdentifier();
            outboundRelationshipTypeBean.setId(this.inboundBeneficiary.getClientAccountRelationship().getRelationshipType().getId().toString());
            outboundRelationshipTypeBean.setCode(this.inboundBeneficiary.getClientAccountRelationship().getRelationshipType().getCode());
            outboundRelationshipTypeBean.setName(this.inboundBeneficiary.getClientAccountRelationship().getRelationshipType().getName());
        } else {
            return createDefaultClientAccountRelationshipType();
        }
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, cName, "Exiting createClientAccountRelationshipType()");
        return outboundRelationshipTypeBean;
    }

    /**
     * Returns a new instance of DistributionOutletBean, with necessary values set.
     * 
     * @return outboundDistributionOutletBean of type DistributionOutletBean
     */
    private DistributionOutletBean createDistributionOutlet() {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, cName, "Entering createDistributionOutlet()");
        DistributionOutletBean outboundDO = null;
        AdvisorIdentifierType inboundDistOutlet = this.inboundBeneficiary.getDistributionOutlet();
        if (inboundDistOutlet != null) {
            outboundDO = new DistributionOutletBean();
            outboundDO.setId(inboundDistOutlet.getId() != null ? inboundDistOutlet.getId().toString() : "");
            outboundDO.setName(inboundDistOutlet.getName());
            outboundDO.setAdvisorNumber(inboundDistOutlet.getAdvisorNumber());
            outboundDO.setClientId(inboundDistOutlet.getClientId() != null ? inboundDistOutlet.getClientId().toString() : "");
            outboundDO.setClientRef(this.accountApplicationUtil.createClientRef(inboundDistOutlet.getClientExternalRef()));
            outboundDO.setClientForename(inboundDistOutlet.getClientForename());
            outboundDO.setClientSurname(inboundDistOutlet.getClientSurname());
            outboundDO.setMasterScheme(this.accountApplicationUtil.createMasterScheme(inboundDistOutlet.getMasterScheme()));
            outboundDO.setAudit(this.accountApplicationUtil.createAuditInfo(inboundDistOutlet.getAudit()));
            outboundDO.setUsername(inboundDistOutlet.getUsername());
        } else {
            return createDefaultDistributionOutlet();
        }
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, cName, "Exiting createDistributionOutlet()");
        return outboundDO;
    }

    /**
     * Sets the Advice Received, Allocation properties of the beneficiary.
     * 
     */
    private void setBeneficiaryDetails() {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, cName, "Entering setBeneficiaryDetails()");
        this.outboundBeneficiary.setAdviceReceived(this.inboundBeneficiary.isAdviceReceived() != null ? this.inboundBeneficiary.isAdviceReceived()
                .toString() : "");
        this.outboundBeneficiary.setSplitPercentage(this.inboundBeneficiary.getSplitPercentage() != null ? this.inboundBeneficiary
                .getSplitPercentage().toString() : "");
        setBeneficiaryDates();
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, cName, "Exiting setBeneficiaryDetails()");
    }

    /**
     * Sets the End date and Nomination signed date properties of the beneficiary.
     * 
     * @param inboundBeneficiary of type BeneficiaryDetails
     * @param outboundBeneficiary of type BeneficiaryType
     */
    private void setBeneficiaryDates() {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, cName, "Entering setBeneficiaryDates()");
        this.outboundBeneficiary.setEndDate(this.inboundBeneficiary.getEndDate() != null ? this.inboundBeneficiary.getEndDate().toString() : "");
        this.outboundBeneficiary.setDateNominationSigned(this.inboundBeneficiary.getDateNominationSigned() != null ? this.inboundBeneficiary
                .getDateNominationSigned().toString() : "");
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, cName, "Exiting setBeneficiaryDates()");
    }

    /**
     * Returns a new instance of BeneficiaryBean, with default values set.
     * 
     * @return outboundBeneficiary of type BeneficiaryBean
     */
    public BeneficiaryBean createDefaultOutboundBeneficiary() {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, cName, "Entering createDefaultOutboundBeneficiary()");
        this.outboundBeneficiary.setClientAccountRelationship(createDefaultClientAccountRelationship());
        this.outboundBeneficiary.setCategory(this.accountApplicationUtil.createDefaultCodeIdentifierInfo());
        this.outboundBeneficiary.setType(this.accountApplicationUtil.createDefaultCodeIdentifierInfo());
        this.outboundBeneficiary.setRelationship(this.accountApplicationUtil.createDefaultCodeIdentifierInfo());
        this.outboundBeneficiary.setDistributionOutlet(createDefaultDistributionOutlet());
        setDefaultBeneficiaryDetails();
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, cName, "Exiting createDefaultOutboundBeneficiary()");
        return outboundBeneficiary;
    }

    /**
     * Returns a new instance of ClientAccountRelationshipBean, with default values set.
     * 
     * @return outboundClientAccountRelationshipBean of type ClientAccountRelationshipBean
     */
    private ClientAccountRelationshipBean createDefaultClientAccountRelationship() {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, cName, "Entering createDefaultClientAccountRelationship()");
        ClientAccountRelationshipBean outboundClientAccountRelationshipBean = new ClientAccountRelationshipBean();
        outboundClientAccountRelationshipBean.setId("");
        outboundClientAccountRelationshipBean.setClient(createDefaultClient());
        outboundClientAccountRelationshipBean.setRelationshipType(createDefaultClientAccountRelationshipType());
        outboundClientAccountRelationshipBean.setPrimaryFlag("");
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, cName, "Exiting createDefaultClientAccountRelationship()");
        return outboundClientAccountRelationshipBean;
    }

    /**
     * Returns a new instance of ClientDetails, with default values set.
     * 
     * @return outboundClientBean of type ClientDetails
     */
    private ClientDetails createDefaultClient() {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, cName, "Entering createDefaultClient()");
        ClientDetails outboundClientBean = new ClientDetails();
        outboundClientBean.setClientId("");
        outboundClientBean.setName("");
        outboundClientBean.setMasterScheme(this.accountApplicationUtil.createDefaultMasterScheme());
        outboundClientBean.setClientPointer(this.accountApplicationUtil.createDefaultClientPointer());
        outboundClientBean.setClientRef(this.accountApplicationUtil.createDefaultClientRef());
        outboundClientBean.setAudit(this.accountApplicationUtil.createDefaultAuditInfo());
        outboundClientBean.setGlobalIntermediaryIDNumber("");
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, cName, "Exiting createDefaultClient()");
        return outboundClientBean;
    }

    /**
     * Returns a new instance of CodeNameIdentifier, with default values set.
     * 
     * @return outboundRelationshipTypeBean of type CodeNameIdentifier
     */
    private CodeNameIdentifier createDefaultClientAccountRelationshipType() {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, cName, "Entering createDefaultClientAccountRelationshipType()");
        CodeNameIdentifier outboundRelationshipTypeBean = new CodeNameIdentifier();
        outboundRelationshipTypeBean.setId("");
        outboundRelationshipTypeBean.setCode("");
        outboundRelationshipTypeBean.setName("");
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, cName, "Exiting createDefaultClientAccountRelationshipType()");
        return outboundRelationshipTypeBean;
    }

    /**
     * Returns a new instance of DistributionOutletBean, with default values set.
     * 
     * @return outboundDistributionOutletBean of type DistributionOutletBean
     */
    private DistributionOutletBean createDefaultDistributionOutlet() {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, cName, "Entering createDefaultDistributionOutlet()");
        DistributionOutletBean outboundDistributionOutletBean = new DistributionOutletBean();
        outboundDistributionOutletBean.setId("");
        outboundDistributionOutletBean.setName("");
        outboundDistributionOutletBean.setAdvisorNumber("");
        outboundDistributionOutletBean.setClientId("");
        outboundDistributionOutletBean.setClientRef(createDefaultClientRef());
        outboundDistributionOutletBean.setMasterScheme(this.accountApplicationUtil.createDefaultMasterScheme());
        outboundDistributionOutletBean.setAudit(this.accountApplicationUtil.createDefaultAuditInfo());
        outboundDistributionOutletBean.setUsername("");
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, cName, "Exiting createDefaultDistributionOutlet()");
        return outboundDistributionOutletBean;
    }

    /**
     * Returns a new instance of IDRefBean, with default values set.
     * 
     * @return outboundIDRefBean of type IDRefBean
     */
    private IDRefBean createDefaultClientRef() {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, cName, "Entering createDefaultClientRef()");
        IDRefBean outboundIDRefBean = new IDRefBean();
        outboundIDRefBean.setReference("");
        outboundIDRefBean.setReferenceCode("");
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, cName, "Exiting createDefaultClientRef()");
        return outboundIDRefBean;
    }

    /**
     * Sets the default values for Advice Received, Allocation properties of the beneficiary.
     * 
     */
    private void setDefaultBeneficiaryDetails() {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, cName, "Entering setDefaultBeneficiaryDetails()");
        this.outboundBeneficiary.setAdviceReceived("");
        this.outboundBeneficiary.setSplitPercentage("");
        this.outboundBeneficiary.setEndDate("");
        this.outboundBeneficiary.setDateNominationSigned("");
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, cName, "Exiting setDefaultBeneficiaryDetails()");
    }
}
