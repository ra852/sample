////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code PensionPaymentSplit} does this.
 * 
 * @author u385424
 * @since 16/02/2016
 * @version 1.0
 */
public class PensionPaymentSplitDetails {

    private String effectiveDate;
    private String id;
    private ClientDetails client;
    private String clientPointer;
    private String fixedAmount;
    private String defaultPayee;
    private PaymentSplitInfo paymentSplit;
    private CodeIdentifierDetails paymentMethodCode;
    private String bankAccountCardNumber;

    /**
     * Accessor for property effectiveDate.
     * 
     * @return effectiveDate of type String
     */
    public String getEffectiveDate() {
        return effectiveDate;
    }

    /**
     * Mutator for property effectiveDate.
     * 
     * @return effectiveDate of type String
     */
    @XmlElement(name = "effectiveDate")
    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    /**
     * Accessor for property id.
     * 
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     * 
     * @return id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id;
    }

   

    /**
     * Accessor for property client.
     *
     * @return client of type ClientDetails
     */
    public ClientDetails getClient() {
        return client;
    }

    /**
     * Mutator for property client.
     *
     * @param client of type ClientDetails
     */
    @XmlElement(name = "client")
    public void setClient(ClientDetails client) {
        this.client = client;
    }

    /**
     * Accessor for property fixedAmount.
     * 
     * @return fixedAmount of type String
     */
    public String getFixedAmount() {
        return fixedAmount;
    }

    /**
     * Mutator for property fixedAmount.
     * 
     * @return fixedAmount of type String
     */
    @XmlElement(name = "fixedAmount")
    public void setFixedAmount(String fixedAmount) {
        this.fixedAmount = fixedAmount;
    }

    /**
     * Accessor for property defaultPayee.
     * 
     * @return defaultPayee of type String
     */
    public String getDefaultPayee() {
        return defaultPayee;
    }

    /**
     * Mutator for property defaultPayee.
     * 
     * @return defaultPayee of type String
     */
    @XmlElement(name = "defaultPayee")
    public void setDefaultPayee(String defaultPayee) {
        this.defaultPayee = defaultPayee;
    }

    /**
     * Accessor for property paymentSplit.
     * 
     * @return paymentSplit of type PaymentSplitInfo
     */
    public PaymentSplitInfo getPaymentSplit() {
        return paymentSplit;
    }

    /**
     * Mutator for property paymentSplit.
     * 
     * @return paymentSplit of type PaymentSplitInfo
     */
    @XmlElement(name = "paymentSplit")
    public void setPaymentSplit(PaymentSplitInfo paymentSplit) {
        this.paymentSplit = paymentSplit;
    }

    /**
     * Accessor for property paymentMethodCode.
     * 
     * @return paymentMethodCode of type CodeIdentifierDetails
     */
    public CodeIdentifierDetails getPaymentMethodCode() {
        return paymentMethodCode;
    }

    /**
     * Mutator for property paymentMethodCode.
     * 
     * @return paymentMethodCode of type CodeIdentifierDetails
     */
    @XmlElement(name = "paymentMethodCode")
    public void setPaymentMethodCode(CodeIdentifierDetails paymentMethodCode) {
        this.paymentMethodCode = paymentMethodCode;
    }

    /**
     * Accessor for property bankAccountCardNumber.
     * 
     * @return bankAccountCardNumber of type String
     */
    public String getBankAccountCardNumber() {
        return bankAccountCardNumber;
    }

    /**
     * Mutator for property bankAccountCardNumber.
     * 
     * @return bankAccountCardNumber of type String
     */
    @XmlElement(name = "bankAccountCardNumber")
    public void setBankAccountCardNumber(String bankAccountCardNumber) {
        this.bankAccountCardNumber = bankAccountCardNumber;
    }

    /**
     * Accessor for property clientPointer.
     *
     * @return clientPointer of type String
     */
    public String getClientPointer() {
        return clientPointer;
    }

    /**
     * Mutator for property clientPointer.
     *
     * @param clientPointer of type String
     */
    @XmlElement(name = "clientPointer")
    public void setClientPointer(String clientPointer) {
        this.clientPointer = clientPointer;
    }

}
