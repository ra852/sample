////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.util;

import java.util.ArrayList;
import java.util.List;

import org.apache.xerces.dom.ElementNSImpl;

import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.ExpCalcBasisIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.ExpenseLineType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.ExpenseLineType.ExcludedAssetClass;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.ExpenseParameterType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.ExpenseParameterType.Tier;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.GenericReference;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.MasterSchemeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.applicationservice.ApplicationServiceConstants;
import com.suncorp.ssp.service.integration.applicationservice.bean.AccountExternalReferenceDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.AccountIdentifierDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.AccountNumberDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.ExcludedAssetClassDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.ExpCalcBasisIdentifierDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.ExpenseLineDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.ExpenseParameterDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.GenericReferenceDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.MasterSchemeIdentifierDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.TierDetails;

/**
 * The class {@code ExpenseLineResponseUtil} does this.
 * 
 * @author U383847
 * @since 09/02/2016
 * @version 1.0
 */
public class ExpenseLineResponseUtil {
    private final String className = "ExpenseLineResponseUtil";

    /**
     * Get Expense Details.
     * 
     * @param expenseLineType
     * @param expenseLineDetails
     */
    public void getExpenseDetails(ExpenseLineType expenseLineType, ExpenseLineDetails expenseLineDetails,
            AccountApplicationUtil accountApplicationUtil) {
        if (expenseLineType != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Expense Details");
            this.getExpenseLineDetails(expenseLineType, expenseLineDetails);
            this.getExpCalBasisDetails(expenseLineType, expenseLineDetails);
            this.getExpenseParameterDetails(expenseLineType, expenseLineDetails, accountApplicationUtil);
            this.getExcludedAssetClassDetails(expenseLineType, expenseLineDetails, accountApplicationUtil);
            this.getExpenseChargeBasisDetails(expenseLineType, expenseLineDetails, accountApplicationUtil);
            this.getAccountFeeDetails(expenseLineType, expenseLineDetails, accountApplicationUtil);
        }
    }

    /**
     * Get Expense Line Details.
     * 
     * @param expenseLineType
     * @param expenseLineDetails
     */
    private void getExpenseLineDetails(ExpenseLineType expenseLineType, ExpenseLineDetails expenseLineDetails) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Expense Line Details");
        if (expenseLineType.getId() != null) {
            expenseLineDetails.setId(Long.toString(expenseLineType.getId()));
        } else {
            expenseLineDetails.setId("");
        }
        expenseLineDetails.setOverride(Boolean.toString(expenseLineType.isOverride()));
        if (expenseLineType.getMaxConsentAmount() != null) {
            expenseLineDetails.setMaxConsentAmount(expenseLineType.getMaxConsentAmount().toString());
        } else {
            expenseLineDetails.setMaxConsentAmount("");
        }
        if (expenseLineType.getMaxConsentPercentage() != null) {
            expenseLineDetails.setMaxConsentPercentage(expenseLineType.getMaxConsentPercentage().toString());
        } else {
            expenseLineDetails.setMaxConsentPercentage("");
        }
    }

    /**
     * Get Expense Calculation Basis Details.
     * 
     * @param expenseLineType
     * @param expenseLineDetails
     */
    private void getExpCalBasisDetails(ExpenseLineType expenseLineType, ExpenseLineDetails expenseLineDetails) {
        ExpCalcBasisIdentifierDetails expCalcBasisIdentifierDetails = new ExpCalcBasisIdentifierDetails();
        if (expenseLineType.getExpCalcBasis() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Expense Calculation Basis Details");
            ExpCalcBasisIdentifierType expCalcBasisIdentifierType = expenseLineType.getExpCalcBasis();
            if (expCalcBasisIdentifierType.getId() != null) {
                expCalcBasisIdentifierDetails.setId(Long.toString(expCalcBasisIdentifierType.getId()));
            }
            expCalcBasisIdentifierDetails.setName(expCalcBasisIdentifierType.getName());
            expCalcBasisIdentifierDetails.setExcbDescription(expCalcBasisIdentifierType.getExcbDescription());
        } else {
            expCalcBasisIdentifierDetails.setId("");
            expCalcBasisIdentifierDetails.setName("");
            expCalcBasisIdentifierDetails.setExcbDescription("");
        }
        expenseLineDetails.setExpCalcBasis(expCalcBasisIdentifierDetails);
    }

    /**
     * Get Expense Calculation Basis Details.
     * 
     * @param expenseLineType
     * @param expenseLineDetails
     */
    private void getExpenseParameterDetails(ExpenseLineType expenseLineType, ExpenseLineDetails expenseLineDetails,
            AccountApplicationUtil accountApplicationUtil) {
        List<ExpenseParameterDetails> expenseParameterDetails = new ArrayList<ExpenseParameterDetails>();
        if (expenseLineType.getParameter() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Expense Calculation Basis Details");
            List<ExpenseParameterType> expenseParameterTypes = expenseLineType.getParameter();
            for (ExpenseParameterType expenseParameterType : expenseParameterTypes) {
                ExpenseParameterDetails expenseParameters = new ExpenseParameterDetails();
                this.getExpenseAmountPercentageDetails(expenseParameters, expenseParameterType);
                this.getTierDetails(expenseParameters, expenseParameterType);
                expenseParameters.setAudit(accountApplicationUtil.createAuditInfo(expenseParameterType.getAudit()));
                expenseParameterDetails.add(expenseParameters);
            }
        } else {
            ExpenseParameterDetails expenseParameters = new ExpenseParameterDetails();
            expenseParameters.setAmount("");
            expenseParameters.setPercentage("");
            expenseParameters.setAudit(accountApplicationUtil.createDefaultAuditInfo());
            TierDetails tierDetails = new TierDetails();
            tierDetails.setValueRangeTo("");
            tierDetails.setDurationRangeTo("");
            expenseParameters.setTier(tierDetails);
            expenseParameterDetails.add(expenseParameters);
        }
        expenseLineDetails.setParameters(expenseParameterDetails);
    }

    /**
     * Get Expense Amount and Percentage Details.
     * 
     * @param expenseParameters
     * @param expenseParameterType
     */
    private void getExpenseAmountPercentageDetails(ExpenseParameterDetails expenseParameters, ExpenseParameterType expenseParameterType) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Expense Amount and Percentage Details");
        if (expenseParameterType.getAmount() != null) {
            expenseParameters.setAmount(expenseParameterType.getAmount().toString());
        } else {
            expenseParameters.setAmount("");
        }
        if (expenseParameterType.getPercentage() != null) {
            expenseParameters.setPercentage(expenseParameterType.getPercentage().toString());
        } else {
            expenseParameters.setPercentage("");
        }
    }

    /**
     * Get Expense Tier Details.
     * 
     * @param expenseParameters
     * @param expenseParameterType
     */
    private void getTierDetails(ExpenseParameterDetails expenseParameters, ExpenseParameterType expenseParameterType) {
        TierDetails tierDetails = new TierDetails();
        if (expenseParameterType.getTier() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Expense Tier Details");
            Tier tier = expenseParameterType.getTier();
            if (tier.getValueRangeTo() != null) {
                tierDetails.setValueRangeTo(tier.getValueRangeTo().toString());
            } else {
                tierDetails.setValueRangeTo("");
            }
            if (tier.getDurationRangeTo() != null) {
                tierDetails.setDurationRangeTo(tier.getDurationRangeTo().toString());
            } else {
                tierDetails.setDurationRangeTo("");
            }
        } else {
            tierDetails.setValueRangeTo("");
            tierDetails.setDurationRangeTo("");
        }
        expenseParameters.setTier(tierDetails);
    }

    /**
     * Get Excluded Asset Class Details.
     * 
     * @param expenseLineType
     * @param expenseLineDetails
     */
    private void getExcludedAssetClassDetails(ExpenseLineType expenseLineType, ExpenseLineDetails expenseLineDetails,
            AccountApplicationUtil accountApplicationUtil) {
        List<ExcludedAssetClassDetails> excludedAssetClassList = new ArrayList<ExcludedAssetClassDetails>();
        if (expenseLineType.getExcludedAssetClass() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Excluded Asset Class Details");
            List<ExcludedAssetClass> excludedAssetClasses = expenseLineType.getExcludedAssetClass();
            for (ExcludedAssetClass excludedAssetClass : excludedAssetClasses) {
                ExcludedAssetClassDetails excludedAssetClassDetails = new ExcludedAssetClassDetails();
                this.getAssetClassDetails(excludedAssetClass, excludedAssetClassDetails, accountApplicationUtil);
                excludedAssetClassDetails.setExclude(Boolean.toString(excludedAssetClass.isExclude()));
                excludedAssetClassList.add(excludedAssetClassDetails);
            }
        } else {
            ExcludedAssetClassDetails excludedAssetClassDetails = new ExcludedAssetClassDetails();
            excludedAssetClassDetails.setAssetClass(accountApplicationUtil.createDefaultCodeIdentifierInfo());
            excludedAssetClassDetails.setExclude("");
            excludedAssetClassList.add(excludedAssetClassDetails);
        }
        expenseLineDetails.setExcludedAssetClass(excludedAssetClassList);
    }

    /**
     * Get Asset Class Details.
     * 
     * @param excludedAssetClass
     * @param excludedAssetClassDetails
     */
    private void getAssetClassDetails(ExcludedAssetClass excludedAssetClass, ExcludedAssetClassDetails excludedAssetClassDetails,
            AccountApplicationUtil accountApplicationUtil) {
        if (excludedAssetClass.getAssetClass() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Asset Class Details");
            excludedAssetClassDetails.setAssetClass(accountApplicationUtil.createCodeIdentifierInfo(excludedAssetClass.getAssetClass()));
        } else {
            excludedAssetClassDetails.setAssetClass(accountApplicationUtil.createDefaultCodeIdentifierInfo());
        }
    }

    /**
     * Get Expense Charge Basis Details.
     * 
     * @param expenseLineType
     * @param expenseLineDetails
     */
    private void getExpenseChargeBasisDetails(ExpenseLineType expenseLineType, ExpenseLineDetails expenseLineDetails,
            AccountApplicationUtil accountApplicationUtil) {
        if (expenseLineType.getChargeBasis() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Expense Charge Basis Details");
            expenseLineDetails.setChargeBasis(accountApplicationUtil.createCodeIdentifierInfo(expenseLineType.getChargeBasis()));
        } else {
            expenseLineDetails.setChargeBasis(accountApplicationUtil.createDefaultCodeIdentifierInfo());
        }
    }

    /**
     * Get Expense Account Fee Details.
     * 
     * @param expenseLineType
     * @param expenseLineDetails
     */
    private void getAccountFeeDetails(ExpenseLineType expenseLineType, ExpenseLineDetails expenseLineDetails,
            AccountApplicationUtil accountApplicationUtil) {
        AccountIdentifierDetails accountIdentifierDetails = new AccountIdentifierDetails();
        if (expenseLineType.getFeeAccount() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Expense Account Fee Details");
            AccountIdentifierType account = expenseLineType.getFeeAccount();
            accountApplicationUtil.getAccountIdentifierType(account, accountIdentifierDetails);
            this.getAccountPointerReferenceDetails(account, accountIdentifierDetails);
            this.getMasterSchemeDetails(account, accountIdentifierDetails);
        } else {
            this.getDefaultFeeAccountDetails(accountIdentifierDetails, accountApplicationUtil);
        }
        expenseLineDetails.setFeeAccount(accountIdentifierDetails);
    }

    /**
     * Get Account Pointer Reference Details.
     * 
     * @param account
     * @param accountIdentifierDetails
     */
    private void getAccountPointerReferenceDetails(AccountIdentifierType account, AccountIdentifierDetails accountIdentifierDetails) {
        GenericReferenceDetails genericReferenceDetails = new GenericReferenceDetails();
        if (account.getAccountPointer() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Account Pointer Reference Details");
            GenericReference genericReference = account.getAccountPointer();
            if (genericReference.getId() != null) {
                genericReferenceDetails.setId(genericReference.getId());
            } else {
                genericReferenceDetails.setId("");
            }
            Object referenceObject = genericReference.getRef();
            ElementNSImpl nsImpl = (ElementNSImpl) referenceObject;
            String str = nsImpl.getTextContent();
            genericReferenceDetails.setReference(str);
        } else {
            genericReferenceDetails.setId("");
            genericReferenceDetails.setReference("");
        }
        accountIdentifierDetails.setAccountPointer(genericReferenceDetails);
    }

    /**
     * Get Master Scheme Details.
     * 
     * @param account
     * @param accountIdentifierDetails
     */
    private void getMasterSchemeDetails(AccountIdentifierType account, AccountIdentifierDetails accountIdentifierDetails) {
        MasterSchemeIdentifierDetails masterSchemeIdentifierDetails = new MasterSchemeIdentifierDetails();
        if (account.getMasterScheme() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Master Scheme Details");
            MasterSchemeIdentifierType masterScheme = account.getMasterScheme();
            if (masterScheme.getId() != null) {
                masterSchemeIdentifierDetails.setId(Long.toString(masterScheme.getId()));
            } else {
                masterSchemeIdentifierDetails.setId("");
            }
            masterSchemeIdentifierDetails.setName(masterScheme.getName());
            masterSchemeIdentifierDetails.setDisplayName(masterScheme.getDisplayName());
            masterSchemeIdentifierDetails.setLongName(masterScheme.getLongName());
        } else {
            masterSchemeIdentifierDetails.setId("");
            masterSchemeIdentifierDetails.setName("");
            masterSchemeIdentifierDetails.setDisplayName("");
            masterSchemeIdentifierDetails.setLongName("");
        }
        accountIdentifierDetails.setMasterScheme(masterSchemeIdentifierDetails);
    }

    private void getDefaultFeeAccountDetails(AccountIdentifierDetails accountIdentifierDetails, AccountApplicationUtil accountApplicationUtil) {
        accountIdentifierDetails.setAccountId("");
        accountIdentifierDetails.setAccountName("");
        AccountNumberDetails accountNumberDetails = new AccountNumberDetails();
        accountNumberDetails.setAccountNumber("");
        accountNumberDetails.setProductName("");
        accountIdentifierDetails.setAccountNumber(accountNumberDetails);
        AccountExternalReferenceDetails accountExternalReferenceDetails = new AccountExternalReferenceDetails();
        accountExternalReferenceDetails.setExternalReferenceCode("");
        accountExternalReferenceDetails.setExternalReferenceType("");
        accountIdentifierDetails.setAccountExternalReference(accountExternalReferenceDetails);
        accountIdentifierDetails.setAccountStatus(accountApplicationUtil.createDefaultCodeIdentifierInfo());
        accountIdentifierDetails.setAudit(accountApplicationUtil.createDefaultAuditInfo());
        GenericReferenceDetails genericReferenceDetails = new GenericReferenceDetails();
        genericReferenceDetails.setId("");
        genericReferenceDetails.setReference("");
        accountIdentifierDetails.setAccountPointer(genericReferenceDetails);
        MasterSchemeIdentifierDetails masterSchemeIdentifierDetails = new MasterSchemeIdentifierDetails();
        masterSchemeIdentifierDetails.setId("");
        masterSchemeIdentifierDetails.setName("");
        masterSchemeIdentifierDetails.setDisplayName("");
        masterSchemeIdentifierDetails.setLongName("");
        accountIdentifierDetails.setMasterScheme(masterSchemeIdentifierDetails);
    }
}
