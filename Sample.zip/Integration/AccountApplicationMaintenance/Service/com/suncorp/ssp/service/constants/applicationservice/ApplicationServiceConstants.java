////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.constants.applicationservice;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * The class {@code ApplicationServiceConstants} does this.
 * 
 * @author U383847
 * @since 06/01/2016
 * @version 1.0
 */
public abstract class ApplicationServiceConstants {
    public static final String OPERATION_NAMESPACE = "http://www.sonatacentral.com/service/v30/wrap/application";
    public static final String CREATE_ACC_APP_LOGGING_FORMAT = "ApplicationService_CreateAccountApplication_{}_".concat(
            new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat("_{}");
    public static final String ADDRESS_EMAL_TYPE = "EMAL";
    public static final String ADDRESS_FAX_TYPE = "FAX";
    public static final String RESPONSE_LEVEL = "FullDetail";
    public static final String CREATE_ACC_APP_OPERATION_NAME = "createAccountApplication";
    public static final String INVALID_ADDRESS_ID_FORMAT = "Invalid Address Id. Please provide valid Address Id.";
    public static final String CREATE_ACC_APP_RESPONSE_CLASS_NAME =
            "com.suncorp.ssp.service.integration.applicationservice.bean.AccountApplicationResponse";
    public static final String CREATE_ACC_APP_EXCEPTION_MESSAGE = "Create Account Application functionality could not get processed";
    public static final String INVALID_ACCOUNT_NAME_FORMAT = "Invalid accountName. Please provide valid accountName.";
    public static final String INVALID_ACCOUNT_NUMBER_FORMAT = "Invalid accountNumber. Please provide valid accountNumber.";
    public static final String INVALID_COUNTRY_ID_FORMAT = "Invalid Country id. Please provide valid id.";
    public static final String INVALID_CURRENCY_ID_FORMAT = "Invalid Currency id. Please provide valid id.";
    public static final String INVALID_TYPECODE_ID_FORMAT = "Invalid TypeCode id. Please provide valid id.";
    public static final String INVALID_ACCOUNT_ID_FORMAT = "Invalid Bank Account id. Please provide valid id.";
    public static final String INVALID_MONTH_FORMAT = "Invalid month. Please provide valid month.";
    public static final String INVALID_YEAR_FORMAT = "Invalid year. Please provide valid year.";
    public static final String INVALID_FIST_ID_FORMAT = "Invalid fistId. Please provide valid fistId.";
    public static final String INVALID_ID_FORMAT = "Invalid id. Please provide valid id.";
    public static final String INVALID_REGULAR_PLAN_ID_FORMAT = "Invalid regularPlanId. Please provide valid id.";
    public static final String INVALID_RELATIONSHIP_ID_FORMAT = "Invalid Realtionship id. Please provide valid id.";
    public static final String INVALID_AMOUNT_FORMAT = "Invalid amount. Please provide valid amount.";
    public static final String INVALID_NEXT_DUE_DATE_FORMAT = "Invalid Next Due Date. Please provide valid date.";
    public static final String INVALID_LINKED_TO_PROFILE_FORMAT = "Invalid LinkedToProfile flag. Please provide valid LinkedToProfile.";
    public static final String INVALID_FUND_SPLIT_PERCENTAGE_FORMAT = "Invalid fundSplitPercentage. Please provide valid percentage split.";
    public static final String INVALID_FUND_ID_FORMAT = "Invalid Fund id. Please provide valid percentage id.";
    public static final String INVALID_CONTRIBUTION_SPLIT_PERCENTAGE_FORMAT =
            "Invalid Contribution Split Percentage. Please provide valid percentage id.";
    public static final String INVALID_PRODUCT_INFO = "Please provide valid product details.";

    // Add Beneficiary constants
    public static final String ADD_BENE_INVALID_ALLOCATION_MSG = "Invalid splitPercentage. Please provide valid splitPercentage.";
}
