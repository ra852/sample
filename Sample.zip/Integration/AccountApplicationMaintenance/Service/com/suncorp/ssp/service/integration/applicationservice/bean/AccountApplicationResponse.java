////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.suncorp.ssp.common.bean.SILErrorMessage;

/**
 * The class {@code AccountApplicationResponse} is a java bean consisting of properties related to account application response details.
 * 
 * @author U383847
 * @since 06/01/2016
 * @version 1.0
 */
@XmlRootElement(name = "AccountApplicationResponse")
public class AccountApplicationResponse extends SILErrorMessage {
    private List<ClientDetails> clientDetails;
    private List<AccountDetails> accountDetails;

    /**
     * Accessor for property clientDetails.
     * 
     * @return clientDetails of type List<ClientDetails>
     */
    public List<ClientDetails> getClientDetails() {
        return clientDetails;
    }

    /**
     * Mutator for property clientDetails.
     * 
     * @param clientDetails of type List<ClientDetails>
     */
    @XmlElement(name = "clientDetails")
    public void setClientDetails(List<ClientDetails> clientDetails) {
        this.clientDetails = clientDetails;
    }

    /**
     * Accessor for property accountEntityDetails.
     * 
     * @return accountEntityDetails of type List<AccountDetails>
     */
    public List<AccountDetails> getAccountDetails() {
        return accountDetails;
    }

    /**
     * Mutator for property accountEntityDetails.
     * 
     * @param accountEntityDetails of type List<AccountDetails>
     */
    @XmlElement(name = "accountDetails")
    public void setAccountDetails(List<AccountDetails> accountDetails) {
        this.accountDetails = accountDetails;
    }
}
