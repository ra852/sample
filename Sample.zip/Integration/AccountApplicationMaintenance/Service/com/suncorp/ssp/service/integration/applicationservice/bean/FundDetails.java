////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code FundDetails} does this.
 * @author U383847
 * @since 28/01/2016
 * @version 1.0
 */
public class FundDetails {
    private String splitPercent;
    private FundIdentifierDetails fundIdentifier;
    private FundIdentifierDetails alternateFundIdentifier;

    /**
     * Accessor for property splitPercent.
     * 
     * @return splitPercent of type String
     */
    public String getSplitPercent() {
        return splitPercent;
    }
    
    /**
     * Mutator for property splitPercent.
     * 
     * @return splitPercent of type String
     */
    @XmlElement(name = "fundSplitPercent")
    public void setSplitPercent(String splitPercent) {
        this.splitPercent = splitPercent != null ? splitPercent : "";
    }
    
    /**
     * Accessor for property fundIdentifier.
     * 
     * @return fundIdentifier of type FundIdentifierDetails
     */
    public FundIdentifierDetails getFundIdentifier() {
        return fundIdentifier;
    }

    /**
     * Mutator for property fundIdentifier.
     * 
     * @return fundIdentifier of type FundIdentifierDetails
     */
    @XmlElement(name = "fundIdentifier")
    public void setFundIdentifier(FundIdentifierDetails fundIdentifier) {
        this.fundIdentifier = fundIdentifier;
    }

    /**
     * Accessor for property alternateFundIdentifier.
     * 
     * @return alternateFundIdentifier of type FundIdentifierDetails
     */
    public FundIdentifierDetails getAlternateFundIdentifier() {
        return alternateFundIdentifier;
    }

    /**
     * Mutator for property alternateFundIdentifier.
     * 
     * @return alternateFundIdentifier of type FundIdentifierDetails
     */
    @XmlElement(name = "alternateFundIdentifier")
    public void setAlternateFundIdentifier(FundIdentifierDetails alternateFundIdentifier) {
        this.alternateFundIdentifier = alternateFundIdentifier;
    }
}
