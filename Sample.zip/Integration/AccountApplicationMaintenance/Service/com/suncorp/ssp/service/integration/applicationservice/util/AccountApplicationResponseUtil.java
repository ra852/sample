////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.util;

import java.util.List;

import com.sonatacentral.service.v30.wrap.application.AccountApplicationResponseType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.applicationservice.ApplicationServiceConstants;
import com.suncorp.ssp.service.integration.applicationservice.bean.AccountApplicationResponse;
import com.suncorp.ssp.service.integration.applicationservice.bean.AccountDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.ClientDetails;

/**
 * The class {@code AccountApplicationResponseUtil} is a Utility class with all the properties related to account and client details, to construct
 * response for end client by extracting values from the external service's response object.
 * 
 * @author U383847
 * @since 12/01/2016
 * @version 1.0
 */
public class AccountApplicationResponseUtil {
    private AccountApplicationResponseType accountApplicationResponseType;
    private final String className = "AccountApplicationResponseUtil";

    /**
     * Parameterized constructor for properties initialization.
     * 
     * @param accountApplicationResponseType
     */
    public AccountApplicationResponseUtil(AccountApplicationResponseType accountApplicationResponseType) {
        this.accountApplicationResponseType = accountApplicationResponseType;
    }

    /**
     * Create Account Application Response Details.
     * 
     * @param accountApplicationResponse
     */
    public void createAccountApplicationReponse(AccountApplicationResponse accountApplicationResponse) throws SILException {
        if (this.accountApplicationResponseType != null && this.accountApplicationResponseType.getFullDetail() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Creating Account Application Reponse Details");
            if (this.accountApplicationResponseType.getFullDetail().getClientDetails() != null) {
                this.getFullClientDetails(accountApplicationResponse);
            }
            if (this.accountApplicationResponseType.getFullDetail().getAccountDetails() != null) {
                this.getFullAccountDetails(accountApplicationResponse);
            }
        }
    }

    /**
     * Get Full Client Details.
     * 
     * @param accountApplicationResponse
     * @throws SILException
     */
    private void getFullClientDetails(AccountApplicationResponse accountApplicationResponse) throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Creating Full Client Details");
        ClientDetailsResponseUtil clientDetailsResponseUtil = new ClientDetailsResponseUtil();
        List<ClientDetails> clientDetailsList = clientDetailsResponseUtil.getClientDetails(accountApplicationResponseType);
        if (clientDetailsList != null) {
            accountApplicationResponse.setClientDetails(clientDetailsList);
        }
    }

    /**
     * Get Full Account Details.
     * 
     * @param accountApplicationResponse
     * @throws SILException
     */
    private void getFullAccountDetails(AccountApplicationResponse accountApplicationResponse) throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Creating Full Account Details");
        AccountDetailsResponseUtil accountDetailsResponseUtil = new AccountDetailsResponseUtil();
        List<AccountDetails> accountDetailsList = accountDetailsResponseUtil.getAccountDetails(accountApplicationResponseType);
        if (accountDetailsList != null) {
            accountApplicationResponse.setAccountDetails(accountDetailsList);
        }
    }
}
