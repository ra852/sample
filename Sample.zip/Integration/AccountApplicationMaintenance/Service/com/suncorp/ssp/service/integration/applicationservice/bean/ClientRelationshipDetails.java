////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code ClientRelationshipDetails} is a java bean consisting of properties related to client relationship details.
 * 
 * @author U383847
 * @since 06/01/2016
 * @version 1.0
 */
public class ClientRelationshipDetails {
    private String relationshipTypeCode;
    private String clientPointer;
    private String primaryFlag;
    private String dateJoined;
    private String endDate;
    private ClientDetails client;
    
    /**
     * Accessor for property relationshipTypeCode.
     * 
     * @return relationshipTypeCode of type String
     */
    public String getRelationshipTypeCode() {
        return relationshipTypeCode;
    }
    
    /**
     * Mutator for property relationshipTypeCode.
     * 
     * @param relationshipTypeCode of type String
     */
    @XmlElement(name = "relationshipTypeCode")
    public void setRelationshipTypeCode(String relationshipTypeCode) {
        this.relationshipTypeCode = relationshipTypeCode;
    }
    
    /**
     * Accessor for property clientPointer.
     * 
     * @return clientPointer of type ClientPointerRef
     */
    public String getClientPointer() {
        return clientPointer;
    }

    /**
     * Mutator for property clientPointer.
     * 
     * @param clientPointer of type ClientPointerRef
     */
    @XmlElement(name = "clientPointer")
    public void setClientPointer(String clientPointer) {
        this.clientPointer = clientPointer;
    }

    /**
     * Accessor for property primaryFlag.
     * 
     * @return primaryFlag of type String
     */
    public String getPrimaryFlag() {
        return primaryFlag;
    }
    
    /**
     * Mutator for property primaryFlag.
     * 
     * @param primaryFlag of type String
     */
    @XmlElement(name = "primaryFlag")
    public void setPrimaryFlag(String primaryFlag) {
        this.primaryFlag = primaryFlag;
    }
    
    /**
     * Accessor for property dateJoined.
     * 
     * @return dateJoined of type String
     */
    public String getDateJoined() {
        return dateJoined;
    }
    
    /**
     * Mutator for property dateJoined.
     * 
     * @param dateJoined of type String
     */
    @XmlElement(name = "dateJoined")
    public void setDateJoined(String dateJoined) {
        this.dateJoined = dateJoined != null ? dateJoined : "";
    }
    
    /**
     * Accessor for property endDate.
     * 
     * @return endDate of type String
     */
    public String getEndDate() {
        return endDate;
    }
    
    /**
     * Mutator for property endDate.
     * 
     * @param endDate of type String
     */
    @XmlElement(name = "endDate")
    public void setEndDate(String endDate) {
        this.endDate = endDate != null ? endDate : "";
    }

    /**
     * Accessor for property client.
     *
     * @return client of type ClientDetails
     */
    public ClientDetails getClient() {
        return client;
    }

    /**
     * Mutator for property client.
     *
     * @param client of type ClientDetails
     */
    @XmlElement(name = "client")
    public void setClient(ClientDetails client) {
        this.client = client;
    }
    
}
