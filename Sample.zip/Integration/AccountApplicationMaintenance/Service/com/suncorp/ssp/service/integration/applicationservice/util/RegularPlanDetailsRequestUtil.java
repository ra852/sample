////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.util;

import java.math.BigDecimal;
import java.util.List;

import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.BankAccountIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CodeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CurrencyIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.FrequencyIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.RelationshipTypeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.fund.fundgrouptype.FundIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.RegularPlanType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.RegularPlanType.ContributionTypeSplit;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.RegularPlanType.FundSplit;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.applicationservice.ApplicationServiceConstants;
import com.suncorp.ssp.service.integration.applicationservice.bean.CodeIdentifierDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.CodeNameIdentifier;
import com.suncorp.ssp.service.integration.applicationservice.bean.ContributionSplitInfo;
import com.suncorp.ssp.service.integration.applicationservice.bean.FundDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.FundIdentifierDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.RegularPlanDetails;

/**
 * The class {@code RegularPlanDetailsRequestUtil} is used as a util class for preparing CreateAccountApplication service Regular Plans Details.
 * 
 * @author U386868
 * @since 10/02/2016
 * @version 1.0
 */
public class RegularPlanDetailsRequestUtil {
    private String className = "RegularPlanDetailsRequestUtil";
    private AccountApplicationUtil accountApplicationUtil = new AccountApplicationUtil();

    /**
     * This method is used to set RegularPlan into RegularPlanList request Stub, with necessary values set.
     * 
     * @param regularPlan of type RegularPlanDetails
     * @param regularPlanTypeList of type RegularPlanType
     * @throws SILException
     */
    public void setRegularPlanDetails(RegularPlanDetails regularPlan, List<RegularPlanType> regularPlanTypeList) throws SILException {
        if (regularPlan != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "setRegularPlanDetails");
            RegularPlanType regularPlanType = new RegularPlanType();
            this.setFrequency(regularPlanType, regularPlan);
            this.setRegularPlanId(regularPlanType, regularPlan);
            this.setRelationshipType(regularPlanType, regularPlan);
            Object clientObject = accountApplicationUtil.getClientPointerDetails(regularPlan);
            //accountApplicationUtil.setClientRefDetails(regularPlanType, clientObject);            
            accountApplicationUtil.setClientIdClientRefDetails(regularPlanType, regularPlan, clientObject);
            this.setBankAccount(regularPlanType, regularPlan);
            this.setAmount(regularPlanType, regularPlan);
            this.setNextDueDate(regularPlanType, regularPlan);
            this.setLinkedToProfile(regularPlanType, regularPlan);
            this.setStatus(regularPlanType, regularPlan);
            this.setPaymentMethod(regularPlanType, regularPlan);
            this.setFundSplits(regularPlanType, regularPlan);
            this.setContributionTypeSplits(regularPlanType, regularPlan);
            
            regularPlanTypeList.add(regularPlanType);
        }
    }

    /**
     * This method is used to set Frequency into Regular Plan List request Stub, with necessary values set.
     * 
     * @param regularPlanType of type RegularPlanType
     * @param regularPlan of type RegularPlanDetails
     * @throws SILException
     */
    public void setFrequency(RegularPlanType regularPlanType, RegularPlanDetails regularPlan) throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "setFreequency");
        if (regularPlan.getFrequency() != null) {
            FrequencyIdentifierType frequencyIdentifierType = new FrequencyIdentifierType();
            if (regularPlan.getFrequency().getFistId() != null) {
                frequencyIdentifierType.setFistId(createFrequencyFistId(regularPlan.getFrequency().getFistId()));
            }
            if (regularPlan.getFrequency().getFreqCode() != null) {
                frequencyIdentifierType.setFreqCode(regularPlan.getFrequency().getFreqCode());
            }
            if (regularPlan.getFrequency().getFreqSetCode() != null) {
                frequencyIdentifierType.setFreqSetCode(regularPlan.getFrequency().getFreqSetCode());
            }
            if (regularPlan.getFrequency().getId() != null) {
                frequencyIdentifierType.setId(accountApplicationUtil.createId(regularPlan.getFrequency().getId()));
            }
            if (regularPlan.getFrequency().getName() != null) {
                frequencyIdentifierType.setName(regularPlan.getFrequency().getName());
            }
            regularPlanType.setFrequency(frequencyIdentifierType);
        }
    }

    /**
     * This method is used to create Frequency fistId, with necessary values set.
     * 
     * @param fistId of type String
     * @return id of type Long
     * @throws SILException
     */
    public Long createFrequencyFistId(String fistId) throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "createFrequencyFistId");
        Long id;
        try {
            id = Long.parseLong(fistId);
        } catch (Exception ex) {
            throw new SILException(ApplicationServiceConstants.INVALID_FIST_ID_FORMAT);
        }
        return id;
    }

    /**
     * This method is used to set RegularPlanId into Regular Plan List request Stub, with necessary values set.
     * 
     * @param regularPlanType of type RegularPlanType
     * @param regularPlan of type RegularPlanDetails
     * @throws SILException
     */
    public void setRegularPlanId(RegularPlanType regularPlanType, RegularPlanDetails regularPlan) throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "setRegularPlanId");
        if (regularPlan.getRegularPlanId() != null) {
            try {
                regularPlanType.setRegularPlanId(Long.parseLong(regularPlan.getRegularPlanId()));
            } catch (Exception ex) {
                throw new SILException(ApplicationServiceConstants.INVALID_REGULAR_PLAN_ID_FORMAT);
            }
        }
    }

    /**
     * This method is used to set RelationshipType into Regular Plan List request Stub, with necessary values set.
     * 
     * @param regularPlanType of type RegularPlanType
     * @param regularPlan of type RegularPlanDetails
     * @throws SILException
     */
    public void setRelationshipType(RegularPlanType regularPlanType, RegularPlanDetails regularPlan) throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "setRelationshipType");
        if (regularPlan.getRelationshipType() != null) {
            RelationshipTypeIdentifierType relationship = new RelationshipTypeIdentifierType();
            if (regularPlan.getRelationshipType().getCode() != null) {
                relationship.setCode(regularPlan.getRelationshipType().getCode());
            }
            if (regularPlan.getRelationshipType().getName() != null) {
                relationship.setName(regularPlan.getRelationshipType().getName());
            }
            if (regularPlan.getRelationshipType().getId() != null) {
                try {
                    relationship.setId(Long.parseLong(regularPlan.getRelationshipType().getId()));
                } catch (Exception ex) {
                    throw new SILException(ApplicationServiceConstants.INVALID_RELATIONSHIP_ID_FORMAT);
                }
            }
            regularPlanType.setRelationshipType(relationship);
        }
    }

    /**
     * This method is used to set Status into Regular Plan List request Stub, with necessary values set.
     * 
     * @param regularPlanType of type RegularPlanType
     * @param regularPlan of type RegularPlanDetails
     * @throws SILException
     */
    public void setStatus(RegularPlanType regularPlanType, RegularPlanDetails regularPlan) throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "setStatus");
        if (regularPlan.getStatus() != null) {
            CodeIdentifierType codeIdentifierType = new CodeIdentifierType();
            if (regularPlan.getStatus().getCode() != null) {
                codeIdentifierType.setCode(regularPlan.getStatus().getCode());
            }
            if (regularPlan.getStatus().getCodeDescription() != null) {
                codeIdentifierType.setCodeDescription(regularPlan.getStatus().getCodeDescription());
            }
            if (regularPlan.getStatus().getCodeShortDescription() != null) {
                codeIdentifierType.setCodeShortDescription(regularPlan.getStatus().getCodeShortDescription());
            }
            if (regularPlan.getStatus().getCodeType() != null) {
                codeIdentifierType.setCodeType(regularPlan.getStatus().getCodeType());
            }
            if (regularPlan.getStatus().getId() != null) {
                codeIdentifierType.setId(accountApplicationUtil.createId(regularPlan.getStatus().getId()));
            }
            regularPlanType.setStatus(codeIdentifierType);
        }
    }

    /**
     * This method is used to set ContributionTypeCode into contributionTypeSplit, with necessary values set.
     * 
     * @param contributionTypeSplit of type ContributionTypeSplit
     * @param contributionTypeCodeDetails of type CodeIdentifierDetails
     * @throws SILException
     */
    public void setContributionTypeCode(ContributionTypeSplit contributionTypeSplit, CodeIdentifierDetails contributionTypeCodeDetails)
            throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "setContributionTypeCode");
        CodeIdentifierType contributionTypeCode = new CodeIdentifierType();
        if (contributionTypeCodeDetails.getCode() != null) {
            contributionTypeCode.setCode(contributionTypeCodeDetails.getCode());
        }
        if (contributionTypeCodeDetails.getCodeDescription() != null) {
            contributionTypeCode.setCodeDescription(contributionTypeCodeDetails.getCodeDescription());
        }
        if (contributionTypeCodeDetails.getCodeShortDescription() != null) {
            contributionTypeCode.setCodeShortDescription(contributionTypeCodeDetails.getCodeShortDescription());
        }
        if (contributionTypeCodeDetails.getCodeType() != null) {
            contributionTypeCode.setCodeType(contributionTypeCodeDetails.getCodeType());
        }
        if (contributionTypeCodeDetails.getId() != null) {
            contributionTypeCode.setId(accountApplicationUtil.createId(contributionTypeCodeDetails.getId()));
        }
        contributionTypeSplit.setContributionTypeCode(contributionTypeCode);
    }

    /**
     * This method is used to set PaymentMethod details into Regular Plan List request Stub, with necessary values set.
     * 
     * @param regularPlanType of type RegularPlanType
     * @param regularPlan of type RegularPlanDetails
     * @throws SILException
     */
    public void setPaymentMethod(RegularPlanType regularPlanType, RegularPlanDetails regularPlan) throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "setPaymentMethod");
        if (regularPlan.getPaymentMethod() != null) {
            CodeIdentifierType codeIdentifierType = new CodeIdentifierType();
            if (regularPlan.getPaymentMethod().getCode() != null) {
                codeIdentifierType.setCode(regularPlan.getPaymentMethod().getCode());
            }
            if (regularPlan.getPaymentMethod().getCodeDescription() != null) {
                codeIdentifierType.setCodeDescription(regularPlan.getPaymentMethod().getCodeDescription());
            }
            if (regularPlan.getPaymentMethod().getCodeShortDescription() != null) {
                codeIdentifierType.setCodeShortDescription(regularPlan.getPaymentMethod().getCodeShortDescription());
            }
            if (regularPlan.getPaymentMethod().getCodeType() != null) {
                codeIdentifierType.setCodeType(regularPlan.getPaymentMethod().getCodeType());
            }
            if (regularPlan.getPaymentMethod().getId() != null) {
                codeIdentifierType.setId(accountApplicationUtil.createId(regularPlan.getPaymentMethod().getId()));
            }
            regularPlanType.setPaymentMethod(codeIdentifierType);
        }
    }

    /**
     * This method is used to set BankAccount Details into Regular Plan List request Stub, with necessary values set.
     * 
     * @param regularPlanType of type RegularPlanType
     * @param regularPlan of type RegularPlanDetails
     */
    public void setBankAccount(RegularPlanType regularPlanType, RegularPlanDetails regularPlan) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "setBankAccount");
        if (regularPlan.getBankAccount() != null) {
            BankAccountIdentifierType accountIdentifierType = new BankAccountIdentifierType();
            if (regularPlan.getBankAccount().getBankAccountNumber() != null) {
                accountIdentifierType.setBankAccountNumber(regularPlan.getBankAccount().getBankAccountNumber());
            }
            if (regularPlan.getBankAccount().getBankAccountCurrencyCode() != null) {
                accountIdentifierType.setBankAccountCurrencyCode(createBankAccCurrCode(regularPlan.getBankAccount().getBankAccountCurrencyCode()));
            }
            if (regularPlan.getBankAccount().getBankAccountTypeCode() != null) {
                accountIdentifierType.setBankAccountTypeCode(regularPlan.getBankAccount().getBankAccountTypeCode());
            }
            regularPlanType.setBankAccount(accountIdentifierType);
        }
    }

    /**
     * This method is used to create BankAccCurrCode details, with necessary values set.
     * 
     * @param codeNameIdentifier of type CodeNameIdentifier
     * @return currency of type CurrencyIdentifierType
     */
    public CurrencyIdentifierType createBankAccCurrCode(CodeNameIdentifier codeNameIdentifier) {
        CurrencyIdentifierType currency = new CurrencyIdentifierType();
        if (codeNameIdentifier.getCode() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "createBankAccCurrCode");
            currency.setCode(codeNameIdentifier.getCode());
        }
        return currency;
    }

    /**
     * This method is used to set Amount into Regular Plan List request Stub, with necessary values set.
     * 
     * @param regularPlanType of type RegularPlanType
     * @param regularPlan of type RegularPlanDetails
     * @throws SILException
     */
    public void setAmount(RegularPlanType regularPlanType, RegularPlanDetails regularPlan) throws SILException {
        if (regularPlan.getAmount() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "setAmount");
            try {
                regularPlanType.setAmount(new BigDecimal(regularPlan.getAmount()));
            } catch (Exception ex) {
                throw new SILException(ApplicationServiceConstants.INVALID_AMOUNT_FORMAT);
            }
        }
    }

    /**
     * This method is used to set NextDueDate into Regular Plan List request Stub, with necessary values set.
     * 
     * @param regularPlanType of type RegularPlanType
     * @param regularPlan of type RegularPlanDetails
     * @throws SILException
     */
    public void setNextDueDate(RegularPlanType regularPlanType, RegularPlanDetails regularPlan) throws SILException {
        if (regularPlan.getNextDueDate() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "setNextDueDate");
            try {
                regularPlanType
                        .setNextDueDate(SILUtil.convertStringToXMLGregorianCalendar(regularPlan.getNextDueDate(), CommonConstants.DATE_FORMAT));
            } catch (Exception ex) {
                throw new SILException(ApplicationServiceConstants.INVALID_NEXT_DUE_DATE_FORMAT);
            }
        }
    }

    /**
     * This method is used to set LinkedToProfile into Regular Plan List request Stub, with necessary values set.
     * 
     * @param regularPlanType of type RegularPlanType
     * @param regularPlan of type RegularPlanDetails
     * @throws SILException
     */
    public void setLinkedToProfile(RegularPlanType regularPlanType, RegularPlanDetails regularPlan) throws SILException {
        if (regularPlan.getLinkedToProfile() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "setLinkedToProfile");
            try {
                regularPlanType.setLinkedToProfile(Boolean.parseBoolean(regularPlan.getLinkedToProfile()));
            } catch (Exception ex) {
                throw new SILException(ApplicationServiceConstants.INVALID_NEXT_DUE_DATE_FORMAT);
            }
        }
    }

    /**
     * This method is used to set FundSplits into Regular Plan List request Stub, with necessary values set.
     * 
     * @param regularPlanType of type RegularPlanType
     * @param regularPlan of type RegularPlanDetails
     * @throws SILException
     */
    public void setFundSplits(RegularPlanType regularPlanType, RegularPlanDetails regularPlan) throws SILException {
        if (regularPlan.getFundSplits() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "setFundSplits");
            List<FundSplit> fundSplitsTypeList = regularPlanType.getFundSplit();
            for (FundDetails fund : regularPlan.getFundSplits()) {
                FundSplit fundSplit = new FundSplit();
                if (fund.getSplitPercent() != null) {
                    fundSplit.setPercentage(createFundSplitPercentage(fund.getSplitPercent()));
                }
                if (fund.getFundIdentifier() != null) {
                    fundSplit.setFund(createFundIdentifier(fund.getFundIdentifier()));
                }
                fundSplitsTypeList.add(fundSplit);
            }
        }
    }

    /**
     * This method is used to create FundIdentifier Details, with necessary values set.
     * 
     * @param fundIdentifierDetails of type FundIdentifierDetails
     * @return identifierType of type FundIdentifierType
     * @throws SILException
     */
    public FundIdentifierType createFundIdentifier(FundIdentifierDetails fundIdentifierDetails) throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "createFundIdentifier");
        FundIdentifierType identifierType = new FundIdentifierType();
        if (fundIdentifierDetails.getId() != null) {
            identifierType.setId(accountApplicationUtil.createId(fundIdentifierDetails.getId()));
        }
        if (fundIdentifierDetails.getName() != null) {
            identifierType.setName(fundIdentifierDetails.getName());
        }
        return identifierType;
    }

    /**
     * This method is used to create FundSplit Percentage, with necessary value set.
     * 
     * @param percentage of type String
     * @return fundSplitPercentage of type BigDecimal
     * @throws SILException
     */
    public BigDecimal createFundSplitPercentage(String percentage) throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "createFundSplitPercentage");
        BigDecimal fundSplitPercentage;
        try {
            fundSplitPercentage = new BigDecimal(percentage);
        } catch (Exception ex) {
            throw new SILException(ApplicationServiceConstants.INVALID_FUND_SPLIT_PERCENTAGE_FORMAT);
        }
        return fundSplitPercentage;
    }

    /**
     * This method is used to set ContributionTypeSplits into Regular Plan List request Stub, with necessary values set.
     * 
     * @param regularPlanType of type RegularPlanType
     * @param regularPlan of type RegularPlanDetails
     * @throws SILException
     */
    public void setContributionTypeSplits(RegularPlanType regularPlanType, RegularPlanDetails regularPlan) throws SILException {
        if (regularPlan.getContributionTypeSplits() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "setContributionTypeSplits");
            List<ContributionTypeSplit> contributionTypeSplitsList = regularPlanType.getContributionTypeSplit();
            for (ContributionSplitInfo contributionSplit : regularPlan.getContributionTypeSplits()) {
                ContributionTypeSplit contributionTypeSplit = new ContributionTypeSplit();
                if (contributionSplit.getPercentage() != null) {
                    contributionTypeSplit.setPercentage(createContbSplitPercentage(contributionSplit.getPercentage()));
                }
                if (contributionSplit.getAmount() != null) {
                    contributionTypeSplit.setAmount(createContbSplitAmount(contributionSplit.getAmount()));
                }
                if (contributionSplit.getAmountCurrencyCode() != null) {
                    this.setAmountCurrencyCode(contributionTypeSplit, contributionSplit.getAmountCurrencyCode());
                }
                if (contributionSplit.getContributionTypeCode() != null) {
                    this.setContributionTypeCode(contributionTypeSplit, contributionSplit.getContributionTypeCode());
                }
                contributionTypeSplitsList.add(contributionTypeSplit);
            }
        }
    }

    /**
     * This method is used to create ContbSplit Amount, with necessary value set.
     * 
     * @param amount of type String
     * @return contbSplitAmount of type BigDecimal
     * @throws SILException
     */
    public BigDecimal createContbSplitAmount(String amount) throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "createContbSplitAmount");
        BigDecimal contbSplitAmount;
        try {
            contbSplitAmount = new BigDecimal(amount);
        } catch (Exception ex) {
            throw new SILException(ApplicationServiceConstants.INVALID_AMOUNT_FORMAT);
        }
        return contbSplitAmount;
    }

    /**
     * This method is used to create ContbSplit Percentage, with necessary value set.
     * 
     * @param percentage of type String
     * @return contbSplitPercentage of type BigDecimal
     * @throws SILException
     */
    public BigDecimal createContbSplitPercentage(String percentage) throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "createContbSplitPercentage");
        BigDecimal contbSplitPercentage;
        try {
            contbSplitPercentage = new BigDecimal(percentage);
        } catch (Exception ex) {
            throw new SILException(ApplicationServiceConstants.INVALID_CONTRIBUTION_SPLIT_PERCENTAGE_FORMAT);
        }
        return contbSplitPercentage;
    }

    /**
     * This method is used to set AmountCurrencyCode into contributionTypeSplit, with necessary values set.
     * 
     * @param contributionTypeSplit of type ContributionTypeSplit
     * @param amountCurrencyCode of type CodeNameIdentifier
     * @throws SILException
     */
    public void setAmountCurrencyCode(ContributionTypeSplit contributionTypeSplit, CodeNameIdentifier amountCurrencyCode) throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "setAmountCurrencyCode()");
        CurrencyIdentifierType amountCurrencyCodeType = new CurrencyIdentifierType();
        if (amountCurrencyCode.getId() != null) {
            amountCurrencyCodeType.setId(accountApplicationUtil.createId(amountCurrencyCode.getId()));
        }
        if (amountCurrencyCode.getName() != null) {
            amountCurrencyCodeType.setName(amountCurrencyCode.getName());
        }
        contributionTypeSplit.setAmountCurrencyCode(amountCurrencyCodeType);
    }
}
