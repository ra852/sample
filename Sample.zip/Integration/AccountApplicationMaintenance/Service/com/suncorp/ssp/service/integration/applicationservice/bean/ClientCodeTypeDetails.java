////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code ClientCodeTypeDetails} does this.
 * @author U383847
 * @since 14/01/2016
 * @version 1.0
 */
public class ClientCodeTypeDetails {
    private String clientCode;
    private String clientCodeType;
    private String clientCodeDescription;
    private String titleCode;
    private String titleCodeType;
    private String titleCodeDescription;
    private String genderCode;
    private String genderCodeType;
    private String genderCodeDescription;
    private String maritalStatusCode;
    private String maritalStatusCodeType;
    private String maritalStatusCodeDescription;
    private String preferLanguageCode;
    private String preferLanguageCodeType;
    private String preferLanguageCodeDescription;
    private String statusCode;
    private String statusCodeType;
    private String statusCodeDescription;
    private String onlineStatusCode;
    private String onlineStatusCodeType;
    private String onlineStatusCodeDescription;
    private String preferredRiskCode;
    private String preferredRiskCodeType;
    private String preferredRiskCodeDescription;
    private String investorTypeCompCode;
    private String investorTypeCompCodeType;
    private String investorTypeCompCodeDescription;
    private String investorTypePersCode;
    private String investorTypePersCodeType;
    private String investorTypePersCodeDescription;
    private String nationalityCode;
    private String nationalityCodeType;
    private String nationalityCodeDescription;
    private String correspondingViewOptionCode;
    private String correspondingViewOptionCodeType;
    private String correspondingViewOptionCodeDescription;
    private String correspondingDeliveryPreferCode;
    private String correspondingDeliveryPreferCodeType;
    private String correspondingDeliveryPreferCodeDescription;
    
    /**
     * Accessor for property clientCode.
     * 
     * @return clientCode of type String
     */
    public String getClientCode() {
        return clientCode;
    }
    
    /**
     * Mutator for property clientCode.
     * 
     * @param clientCode of type String
     */
    @XmlElement(name = "clientCode")
    public void setClientCode(String clientCode) {
        this.clientCode = clientCode != null ? clientCode : "";
    }
    
    /**
     * Accessor for property clientCodeType.
     * 
     * @return clientCodeType of type String
     */
    public String getClientCodeType() {
        return clientCodeType;
    }
    
    /**
     * Mutator for property clientCodeType.
     * 
     * @param clientCodeType of type String
     */
    @XmlElement(name = "clientCodeType")
    public void setClientCodeType(String clientCodeType) {
        this.clientCodeType = clientCodeType != null ? clientCodeType : "";
    }
    
    /**
     * Accessor for property clientCodeDescription.
     * 
     * @return clientCodeDescription of type String
     */
    public String getClientCodeDescription() {
        return clientCodeDescription;
    }

    /**
     * Mutator for property clientCodeDescription.
     * 
     * @param clientCodeDescription of type String
     */
    @XmlElement(name = "clientCodeDescription")
    public void setClientCodeDescription(String clientCodeDescription) {
        this.clientCodeDescription = clientCodeDescription != null ? clientCodeDescription : "";
    }
    
    /**
     * Accessor for property titleCode.
     * 
     * @return titleCode of type String
     */
    public String getTitleCode() {
        return titleCode;
    }
    
    /**
     * Mutator for property titleCode.
     * 
     * @param titleCode of type String
     */
    @XmlElement(name = "titleCode")
    public void setTitleCode(String titleCode) {
        this.titleCode = titleCode != null ? titleCode : "";
    }
    
    /**
     * Accessor for property titleCodeType.
     * 
     * @return titleCodeType of type String
     */
    public String getTitleCodeType() {
        return titleCodeType;
    }
    
    /**
     * Mutator for property titleCodeType.
     * 
     * @param titleCodeType of type String
     */
    @XmlElement(name = "titleCodeType")
    public void setTitleCodeType(String titleCodeType) {
        this.titleCodeType = titleCodeType != null ? titleCodeType : "";
    }
    
    /**
     * Accessor for property titleCodeDescription.
     * 
     * @return titleCodeDescription of type String
     */
    public String getTitleCodeDescription() {
        return titleCodeDescription;
    }

    /**
     * Mutator for property titleCodeDescription.
     * 
     * @param titleCodeDescription of type String
     */
    @XmlElement(name = "titleCodeDescription")
    public void setTitleCodeDescription(String titleCodeDescription) {
        this.titleCodeDescription = titleCodeDescription != null ? titleCodeDescription : "";
    }
    
    /**
     * Accessor for property genderCode.
     * 
     * @return genderCode of type String
     */
    public String getGenderCode() {
        return genderCode;
    }
    
    /**
     * Mutator for property genderCode.
     * 
     * @param genderCode of type String
     */
    @XmlElement(name = "genderCode")
    public void setGenderCode(String genderCode) {
        this.genderCode = genderCode != null ? genderCode : "";
    }
    
    /**
     * Accessor for property genderCodeType.
     * 
     * @return genderCodeType of type String
     */
    public String getGenderCodeType() {
        return genderCodeType;
    }
    
    /**
     * Mutator for property genderCodeType.
     * 
     * @param genderCodeType of type String
     */
    @XmlElement(name = "genderCodeType")
    public void setGenderCodeType(String genderCodeType) {
        this.genderCodeType = genderCodeType != null ? genderCodeType : "";
    }
    
    /**
     * Accessor for property genderCodeDescription.
     * 
     * @return genderCodeDescription of type String
     */
    public String getGenderCodeDescription() {
        return genderCodeDescription;
    }

    /**
     * Mutator for property genderCodeDescription.
     * 
     * @param genderCodeDescription of type String
     */
    @XmlElement(name = "genderCodeDescription")
    public void setGenderCodeDescription(String genderCodeDescription) {
        this.genderCodeDescription = genderCodeDescription != null ? genderCodeDescription : "";
    }
    
    /**
     * Accessor for property maritalStatusCode.
     * 
     * @return maritalStatusCode of type String
     */
    public String getMaritalStatusCode() {
        return maritalStatusCode;
    }
    
    /**
     * Mutator for property maritalStatusCode.
     * 
     * @param maritalStatusCode of type String
     */
    @XmlElement(name = "maritalStatusCode")
    public void setMaritalStatusCode(String maritalStatusCode) {
        this.maritalStatusCode = maritalStatusCode != null ? maritalStatusCode : "";
    }
    
    /**
     * Accessor for property maritalStatusCodeType.
     * 
     * @return maritalStatusCodeType of type String
     */
    public String getMaritalStatusCodeType() {
        return maritalStatusCodeType;
    }

    /**
     * Mutator for property maritalStatusCodeType.
     * 
     * @param maritalStatusCodeType of type String
     */
    @XmlElement(name = "maritalStatusCodeType")
    public void setMaritalStatusCodeType(String maritalStatusCodeType) {
        this.maritalStatusCodeType = maritalStatusCodeType != null ? maritalStatusCodeType : "";
    }

    /**
     * Accessor for property maritalStatusCodeDescription.
     * 
     * @return maritalStatusCodeDescription of type String
     */
    public String getMaritalStatusCodeDescription() {
        return maritalStatusCodeDescription;
    }

    /**
     * Mutator for property maritalStatusCodeDescription.
     * 
     * @param maritalStatusCodeDescription of type String
     */
    @XmlElement(name = "maritalStatusCodeDescription")
    public void setMaritalStatusCodeDescription(String maritalStatusCodeDescription) {
        this.maritalStatusCodeDescription = maritalStatusCodeDescription != null ? maritalStatusCodeDescription : "";
    }
    
    /**
     * Accessor for property preferLanguageCode.
     * 
     * @return preferLanguageCode of type String
     */
    public String getPreferLanguageCode() {
        return preferLanguageCode;
    }
    
    /**
     * Mutator for property preferLanguageCode.
     * 
     * @param preferLanguageCode of type String
     */
    @XmlElement(name = "preferLanguageCode")
    public void setPreferLanguageCode(String preferLanguageCode) {
        this.preferLanguageCode = preferLanguageCode != null ? preferLanguageCode : "";
    }
    
    /**
     * Accessor for property preferLanguageCodeType.
     * 
     * @return preferLanguageCodeType of type String
     */
    public String getPreferLanguageCodeType() {
        return preferLanguageCodeType;
    }
    
    /**
     * Mutator for property preferLanguageCodeType.
     * 
     * @param preferLanguageCodeType of type String
     */
    @XmlElement(name = "preferLanguageCodeType")
    public void setPreferLanguageCodeType(String preferLanguageCodeType) {
        this.preferLanguageCodeType = preferLanguageCodeType != null ? preferLanguageCodeType : "";
    }
    
    /**
     * Accessor for property preferLanguageDescription.
     * 
     * @return preferLanguageDescription of type String
     */
    public String getPreferLanguageCodeDescription() {
        return preferLanguageCodeDescription;
    }

    /**
     * Mutator for property preferLanguageDescription.
     * 
     * @param preferLanguageDescription of type String
     */
    @XmlElement(name = "preferLanguageCodeDescription")
    public void setPreferLanguageCodeDescription(String preferLanguageCodeDescription) {
        this.preferLanguageCodeDescription = preferLanguageCodeDescription != null ? preferLanguageCodeDescription : "";
    }
    
    /**
     * Accessor for property statusCode.
     * 
     * @return statusCode of type String
     */
    public String getStatusCode() {
        return statusCode;
    }
    
    /**
     * Mutator for property statusCode.
     * 
     * @param statusCode of type String
     */
    @XmlElement(name = "statusCode")
    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode != null ? statusCode : "";
    }
    
    /**
     * Accessor for property statusCodeType.
     * 
     * @return statusCodeType of type String
     */
    public String getStatusCodeType() {
        return statusCodeType;
    }
    
    /**
     * Mutator for property statusCodeType.
     * 
     * @param statusCodeType of type String
     */
    @XmlElement(name = "statusCodeType")
    public void setStatusCodeType(String statusCodeType) {
        this.statusCodeType = statusCodeType != null ? statusCodeType : "";
    }

    /**
     * Accessor for property statusCodeDescription.
     * 
     * @return statusCodeDescription of type String
     */
    public String getStatusCodeDescription() {
        return statusCodeDescription;
    }

    /**
     * Mutator for property statusCodeDescription.
     * 
     * @param statusCodeDescription of type String
     */
    @XmlElement(name = "statusCodeDescription")
    public void setStatusCodeDescription(String statusCodeDescription) {
        this.statusCodeDescription = statusCodeDescription != null ? statusCodeDescription : "";
    }
    
    /**
     * Accessor for property onlineStatusCode.
     * 
     * @return onlineStatusCode of type String
     */
    public String getOnlineStatusCode() {
        return onlineStatusCode;
    }
    
    /**
     * Mutator for property onlineStatusCode.
     * 
     * @param onlineStatusCode of type String
     */
    @XmlElement(name = "onlineStatusCode")
    public void setOnlineStatusCode(String onlineStatusCode) {
        this.onlineStatusCode = onlineStatusCode != null ? onlineStatusCode : "";
    }
    
    /**
     * Accessor for property onlineStatusCodeType.
     * 
     * @return onlineStatusCodeType of type String
     */
    public String getOnlineStatusCodeType() {
        return onlineStatusCodeType;
    }
    
    /**
     * Mutator for property onlineStatusCodeType.
     * 
     * @param onlineStatusCodeType of type String
     */
    @XmlElement(name = "onlineStatusCodeType")
    public void setOnlineStatusCodeType(String onlineStatusCodeType) {
        this.onlineStatusCodeType = onlineStatusCodeType != null ? onlineStatusCodeType : "";
    }

    /**
     * Accessor for property onlineStatusCodeDescription.
     * 
     * @return onlineStatusCodeDescription of type String
     */
    public String getOnlineStatusCodeDescription() {
        return onlineStatusCodeDescription;
    }

    /**
     * Mutator for property onlineStatusCodeDescription.
     * 
     * @param onlineStatusCodeDescription of type String
     */
    @XmlElement(name = "onlineStatusCodeDescription")
    public void setOnlineStatusCodeDescription(String onlineStatusCodeDescription) {
        this.onlineStatusCodeDescription = onlineStatusCodeDescription != null ? onlineStatusCodeDescription : "";
    }
    
    /**
     * Accessor for property preferredRiskCode.
     * 
     * @return preferredRiskCode of type String
     */
    public String getPreferredRiskCode() {
        return preferredRiskCode;
    }
    
    /**
     * Mutator for property preferredRiskCode.
     * 
     * @param preferredRiskCode of type String
     */
    @XmlElement(name = "preferRiskCode")
    public void setPreferredRiskCode(String preferredRiskCode) {
        this.preferredRiskCode = preferredRiskCode != null ? preferredRiskCode : "";
    }
    
    /**
     * Accessor for property preferredRiskCodeType.
     * 
     * @return preferredRiskCodeType of type String
     */
    public String getPreferredRiskCodeType() {
        return preferredRiskCodeType;
    }
    
    /**
     * Mutator for property preferredRiskCodeType.
     * 
     * @param preferredRiskCodeType of type String
     */
    @XmlElement(name = "preferRiskCodeType")
    public void setPreferredRiskCodeType(String preferredRiskCodeType) {
        this.preferredRiskCodeType = preferredRiskCodeType != null ? preferredRiskCodeType : "";
    }

    /**
     * Accessor for property preferredRiskCodeDescription.
     * 
     * @return preferredRiskCodeDescription of type String
     */
    public String getPreferredRiskCodeDescription() {
        return preferredRiskCodeDescription;
    }

    /**
     * Mutator for property preferredRiskCodeDescription.
     * 
     * @param preferredRiskCodeDescription of type String
     */
    @XmlElement(name = "preferRiskCodeDescription")
    public void setPreferredRiskCodeDescription(String preferredRiskCodeDescription) {
        this.preferredRiskCodeDescription = preferredRiskCodeDescription != null ? preferredRiskCodeDescription : "";
    }
    
    /**
     * Accessor for property investorTypeCompCode.
     * 
     * @return investorTypeCompCode of type String
     */
    public String getInvestorTypeCompCode() {
        return investorTypeCompCode;
    }
    
    /**
     * Mutator for property investorTypeCompCode.
     * 
     * @param investorTypeCompCode of type String
     */
    @XmlElement(name = "investorTypeCompCode")
    public void setInvestorTypeCompCode(String investorTypeCompCode) {
        this.investorTypeCompCode = investorTypeCompCode != null ? investorTypeCompCode : "";
    }
    
    /**
     * Accessor for property investorTypeCompCodeType.
     * 
     * @return investorTypeCompCodeType of type String
     */
    public String getInvestorTypeCompCodeType() {
        return investorTypeCompCodeType;
    }
    
    /**
     * Mutator for property investorTypeCompCodeType.
     * 
     * @param investorTypeCompCodeType of type String
     */
    @XmlElement(name = "investorTypeCompCodeType")
    public void setInvestorTypeCompCodeType(String investorTypeCompCodeType) {
        this.investorTypeCompCodeType = investorTypeCompCodeType != null ? investorTypeCompCodeType : "";
    }

    /**
     * Accessor for property investorTypeCompCodeDescription.
     * 
     * @return investorTypeCompCodeDescription of type String
     */
    public String getInvestorTypeCompCodeDescription() {
        return investorTypeCompCodeDescription;
    }

    /**
     * Mutator for property investorTypeCompCodeDescription.
     * 
     * @param investorTypeCompCodeDescription of type String
     */
    @XmlElement(name = "investorTypeCompCodeDescription")
    public void setInvestorTypeCompCodeDescription(String investorTypeCompCodeDescription) {
        this.investorTypeCompCodeDescription = investorTypeCompCodeDescription != null ? investorTypeCompCodeDescription : "";
    }
    
    /**
     * Accessor for property investorTypePersCode.
     * 
     * @return investorTypePersCode of type String
     */
    public String getInvestorTypePersCode() {
        return investorTypePersCode;
    }
    
    /**
     * Mutator for property investorTypePersCode.
     * 
     * @param investorTypePersCode of type String
     */
    @XmlElement(name = "investorTypePersCode")
    public void setInvestorTypePersCode(String investorTypePersCode) {
        this.investorTypePersCode = investorTypePersCode != null ? investorTypePersCode : "";
    }
    
    /**
     * Accessor for property investorTypePersCodeType.
     * 
     * @return investorTypePersCodeType of type String
     */
    public String getInvestorTypePersCodeType() {
        return investorTypePersCodeType;
    }
    
    /**
     * Mutator for property investorTypePersCodeType.
     * 
     * @param investorTypePersCodeType of type String
     */
    @XmlElement(name = "investorTypePersCodeType")
    public void setInvestorTypePersCodeType(String investorTypePersCodeType) {
        this.investorTypePersCodeType = investorTypePersCodeType != null ? investorTypePersCodeType : "";
    }

    /**
     * Accessor for property investorTypePersCodeDescription.
     * 
     * @return investorTypePersCodeDescription of type String
     */
    public String getInvestorTypePersCodeDescription() {
        return investorTypePersCodeDescription;
    }

    /**
     * Mutator for property investorTypePersCodeDescription.
     * 
     * @param investorTypePersCodeDescription of type String
     */
    @XmlElement(name = "investorTypePersCodeDescription")
    public void setInvestorTypePersCodeDescription(String investorTypePersCodeDescription) {
        this.investorTypePersCodeDescription = investorTypePersCodeDescription != null ? investorTypePersCodeDescription : "";
    }

    /**
     * Accessor for property nationalityCode.
     * 
     * @return nationalityCode of type String
     */
    public String getNationalityCode() {
        return nationalityCode;
    }
    
    /**
     * Mutator for property nationalityCode.
     * 
     * @param nationalityCode of type String
     */
    @XmlElement(name = "nationalityCode")
    public void setNationalityCode(String nationalityCode) {
        this.nationalityCode = nationalityCode != null ? nationalityCode : "";
    }
    
    /**
     * Accessor for property nationalityCodeType.
     * 
     * @return nationalityCodeType of type String
     */
    public String getNationalityCodeType() {
        return nationalityCodeType;
    }
    
    /**
     * Mutator for property nationalityCodeType.
     * 
     * @param nationalityCodeType of type String
     */
    @XmlElement(name = "nationalityCodeType")
    public void setNationalityCodeType(String nationalityCodeType) {
        this.nationalityCodeType = nationalityCodeType != null ? nationalityCodeType : "";
    }

    /**
     * Accessor for property nationalityCodeDescription.
     * 
     * @return nationalityCodeDescription of type String
     */
    public String getNationalityCodeDescription() {
        return nationalityCodeDescription;
    }

    /**
     * Mutator for property nationalityCodeDescription.
     * 
     * @param nationalityCodeDescription of type String
     */
    @XmlElement(name = "nationalityCodeDescription")
    public void setNationalityCodeDescription(String nationalityCodeDescription) {
        this.nationalityCodeDescription = nationalityCodeDescription != null ? nationalityCodeDescription : "";
    }
    
    /**
     * Accessor for property correspondingViewOptionCode.
     * 
     * @return correspondingViewOptionCode of type String
     */
    public String getCorrespondingViewOptionCode() {
        return correspondingViewOptionCode;
    }
    
    /**
     * Mutator for property correspondingViewOptionCode.
     * 
     * @param correspondingViewOptionCode of type String
     */
    @XmlElement(name = "corrViewOptionCode")
    public void setCorrespondingViewOptionCode(String correspondingViewOptionCode) {
        this.correspondingViewOptionCode = correspondingViewOptionCode != null ? correspondingViewOptionCode : "";
    }
    
    /**
     * Accessor for property correspondingViewOptionCodeType.
     * 
     * @return correspondingViewOptionCodeType of type String
     */
    public String getCorrespondingViewOptionCodeType() {
        return correspondingViewOptionCodeType;
    }
    
    /**
     * Mutator for property correspondingViewOptionCodeType.
     * 
     * @param correspondingViewOptionCodeType of type String
     */
    @XmlElement(name = "corrViewOptionCodeType")
    public void setCorrespondingViewOptionCodeType(String correspondingViewOptionCodeType) {
        this.correspondingViewOptionCodeType = correspondingViewOptionCodeType != null ? correspondingViewOptionCodeType : "";
    }

    /**
     * Accessor for property correspondingViewOptionCodeDescription.
     * 
     * @return correspondingViewOptionCodeDescription of type String
     */
    public String getCorrespondingViewOptionCodeDescription() {
        return correspondingViewOptionCodeDescription;
    }

    /**
     * Mutator for property correspondingViewOptionCodeDescription.
     * 
     * @param correspondingViewOptionCodeDescription of type String
     */
    @XmlElement(name = "corrViewOptionCodeDescription")
    public void setCorrespondingViewOptionCodeDescription(String correspondingViewOptionCodeDescription) {
        this.correspondingViewOptionCodeDescription = correspondingViewOptionCodeDescription != null ? correspondingViewOptionCodeDescription : "";
    }
    
    /**
     * Accessor for property correspondingDeliveryPreferCode.
     * 
     * @return correspondingDeliveryPreferCode of type String
     */
    public String getCorrespondingDeliveryPreferCode() {
        return correspondingDeliveryPreferCode;
    }
    
    /**
     * Mutator for property correspondingDeliveryPreferCode.
     * 
     * @param correspondingDeliveryPreferCode of type String
     */
    @XmlElement(name = "corrDeliveryPreferCode")
    public void setCorrespondingDeliveryPreferCode(String correspondingDeliveryPreferCode) {
        this.correspondingDeliveryPreferCode = correspondingDeliveryPreferCode != null ? correspondingDeliveryPreferCode : "";
    }
    
    /**
     * Accessor for property correspondingDeliveryPreferCodeType.
     * 
     * @return correspondingDeliveryPreferCodeType of type String
     */
    public String getCorrespondingDeliveryPreferCodeType() {
        return correspondingDeliveryPreferCodeType;
    }
    
    /**
     * Mutator for property correspondingDeliveryPreferCodeType.
     * 
     * @param correspondingDeliveryPreferCodeType of type String
     */
    @XmlElement(name = "corrDeliveryPreferCodeType")
    public void setCorrespondingDeliveryPreferCodeType(String correspondingDeliveryPreferCodeType) {
        this.correspondingDeliveryPreferCodeType = correspondingDeliveryPreferCodeType != null ? correspondingDeliveryPreferCodeType : "";
    }

    /**
     * Accessor for property correspondingDeliveryPreferCodeDescription.
     * 
     * @return correspondingDeliveryPreferCodeDescription of type String
     */
    public String getCorrespondingDeliveryPreferCodeDescription() {
        return correspondingDeliveryPreferCodeDescription;
    }

    /**
     * Mutator for property correspondingDeliveryPreferCodeDescription.
     * 
     * @param correspondingDeliveryPreferCodeDescription of type String
     */
    @XmlElement(name = "corrDeliveryPreferCodeDescription")
    public void setCorrespondingDeliveryPreferCodeDescription(String correspondingDeliveryPreferCodeDescription) {
        this.correspondingDeliveryPreferCodeDescription = correspondingDeliveryPreferCodeDescription != null ? 
                correspondingDeliveryPreferCodeDescription : "";
    }
}
