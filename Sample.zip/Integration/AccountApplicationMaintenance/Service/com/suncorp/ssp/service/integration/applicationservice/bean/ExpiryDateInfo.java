////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code ExpiryDateInfo} does this.
 * 
 * @author U386868
 * @since 09/02/2016
 * @version 1.0
 */
public class ExpiryDateInfo {

    private String month;
    private String year;

    /**
     * Accessor for property month.
     * 
     * @return month of type String
     */
    public String getMonth() {
        return month;
    }

    /**
     * Mutator for property month.
     * 
     * @return month of type String
     */
    @XmlElement(name = "month")
    public void setMonth(String month) {
        this.month = month != null ? month : "";
    }

    /**
     * Accessor for property year.
     * 
     * @return year of type String
     */
    public String getYear() {
        return year;
    }

    /**
     * Mutator for property year.
     * 
     * @return year of type String
     */
    @XmlElement(name = "year")
    public void setYear(String year) {
        this.year = year != null ? year : "";
    }
}
