////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.AddressDetailsType;
import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.ClientDetailType;
import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.ClientEntityType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CodeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CountryIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CurrencyIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.GenericVariableType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.OccupationIdentifierType;
import com.sonatacentral.service.v30.wrap.application.AccountApplicationRequestType.Client;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.applicationservice.ApplicationServiceConstants;
import com.suncorp.ssp.service.integration.applicationservice.bean.BankAccountDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.ClientAddressDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.ClientDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.CodeIdentifierDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.GenericVariableDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.ValueDetails;

/**
 * The class {@code ClientDetailsRequestUtil} is a Utility class with all the properties related to client details, to construct request for creating
 * account application external service's request object.
 * 
 * @author U383847
 * @since 07/01/2016
 * @version 1.0
 */
public class ClientDetailsRequestUtil {
    private final String className = "ClientDetailsRequestUtil";

    /**
     * Extracts values from address details of client and set the values to external service's request object.
     * 
     * @param clientEntityType
     * @param clientDetailsList
     * @param clientDetailTypeList
     * @throws SILException
     */
    public void setClientDetails(List<ClientDetails> clientDetailsList, List<Client> clientDetailTypeList) throws SILException {
        if (clientDetailsList != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Client Details");
            for (ClientDetails clientDetails : clientDetailsList) {
                ClientDetailType clientDetailType = new ClientDetailType();
                this.setClientTypeCode(clientDetailType, clientDetails);
                this.setClientName(clientDetailType, clientDetails);
                this.setClientTitle(clientDetailType, clientDetails);
                this.setClientGender(clientDetailType, clientDetails);
                this.setClientDateDetails(clientDetailType, clientDetails);
                this.setClientCountry(clientDetailType, clientDetails);
                this.setClientMaritalStatus(clientDetailType, clientDetails);
                this.setClientContactDetails(clientDetailType, clientDetails);
                this.setClientOccupation(clientDetailType, clientDetails);
                this.setClientOtherDetails(clientDetailType, clientDetails);
                this.setClientPreferredDetails(clientDetailType, clientDetails);
                this.setClientStatus(clientDetailType, clientDetails);
                this.setClientOnlineStatus(clientDetailType, clientDetails);
                this.setClientInvestorDetails(clientDetailType, clientDetails);
                this.setClientNationality(clientDetailType, clientDetails);
                this.setClientCorrespondenceDetails(clientDetailType, clientDetails);
                this.setClientRequestTypeDetails(clientDetailType, clientDetails, clientDetailTypeList);
            }
        }
    }

    /**
     * Set Client Request Type Details.
     * 
     * @param clientDetailType
     * @param clientDetails
     * @param clientDetailTypeList
     * @throws SILException
     */
    private void setClientRequestTypeDetails(ClientDetailType clientDetailType, ClientDetails clientDetails,
            List<Client> clientDetailTypeList) throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Client Request Type Details");
        List<ClientEntityType.BankAccount> bankAccount = new ArrayList<ClientEntityType.BankAccount>();
        this.setBankAccountDetails(clientDetails.getBankAccount(), bankAccount);
        ClientEntityType.Australia australia = new ClientEntityType.Australia();
        this.setClientCountryDetails(australia, clientDetails);
        Client clientRequestDetailsType = new Client();
        List<AddressDetailsType> address = clientRequestDetailsType.getAddress();
        this.setClientAddressDetails(clientDetails.getAddressTypeList(), address);
        if (clientDetails.getClientId() != null) {
            clientRequestDetailsType.setId(clientDetails.getClientId());
        }
        if (clientDetails.getGenericVariables() != null && clientDetails.getGenericVariables().size() > 0) {
            List<GenericVariableType> genericVariableTypes = new ArrayList<GenericVariableType>();
            setGenericVariableDetails(clientDetails.getGenericVariables(), genericVariableTypes);
            clientRequestDetailsType.getGenericVariable().addAll(genericVariableTypes);
        }
        //clientRequestDetailsType.getAddress().addAll(address);
        clientRequestDetailsType.getBankAccount().addAll(bankAccount);
        setClientRequestTypeParams(clientDetailType, clientDetails, australia, clientRequestDetailsType);
        clientDetailTypeList.add(clientRequestDetailsType);
    }

    /**
     * Set Client Request Type Details.
     *
     * @param clientDetailType
     * @param clientDetails
     * @param australia
     * @param clientRequestDetailsType
     */
    private void setClientRequestTypeParams(ClientDetailType clientDetailType, ClientDetails clientDetails, ClientEntityType.Australia australia,
            ClientEntityType clientRequestDetailsType) {
        clientRequestDetailsType.setAustralia(australia);
        clientRequestDetailsType.setClientDetails(clientDetailType);
        if (clientDetails.getHasWorkDeclaration() != null) {
            clientRequestDetailsType.setHasWorkDeclaration(Boolean.valueOf(clientDetails.getHasWorkDeclaration()));
        }
    }

    /**
     * Set Client Type Code Details.
     * 
     * @param clientDetailType
     * @param clientDetails
     */
    private void setClientTypeCode(ClientDetailType clientDetailType, ClientDetails clientDetails) {
        if (clientDetails.getClient() != null && clientDetails.getClient().getCode() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Client Type Code Details");
            CodeIdentifierType typeCode = new CodeIdentifierType();
            typeCode.setCode(clientDetails.getClient().getCode());
            typeCode.setCodeType(clientDetails.getClient().getCodeType());
            typeCode.setCodeDescription(clientDetails.getClient().getCodeDescription());
            clientDetailType.setTypeCode(typeCode);
        }
    }

    /**
     * Set Client Name Details.
     * 
     * @param clientDetailType
     * @param clientDetails
     */
    private void setClientName(ClientDetailType clientDetailType, ClientDetails clientDetails) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Client Name Details");
        clientDetailType.setSurname(clientDetails.getSurname());
        clientDetailType.setForename(clientDetails.getFirstName());
        clientDetailType.setForename2(clientDetails.getMiddleName());
        clientDetailType.setInitials(clientDetails.getInitials());
        clientDetailType.setSalutation(clientDetails.getSalutation());
    }

    /**
     * Set Client Title Details.
     * 
     * @param clientDetailType
     * @param clientDetails
     */
    private void setClientTitle(ClientDetailType clientDetailType, ClientDetails clientDetails) {
        if (clientDetails.getTitle() != null && clientDetails.getTitle().getCode() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Client Title Details");
            CodeIdentifierType title = new CodeIdentifierType();
            title.setCode(clientDetails.getTitle().getCode());
            title.setCodeType(clientDetails.getTitle().getCodeType());
            title.setCodeDescription(clientDetails.getTitle().getCodeDescription());
            clientDetailType.setTitle(title);
        }
    }

    /**
     * Set Client Gender Details.
     * 
     * @param clientDetailType
     * @param clientDetails
     */
    private void setClientGender(ClientDetailType clientDetailType, ClientDetails clientDetails) {
        if (clientDetails.getGender() != null && clientDetails.getGender().getCode() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Client Gender Details");
            CodeIdentifierType gender = new CodeIdentifierType();
            gender.setCode(clientDetails.getGender().getCode());
            gender.setCodeType(clientDetails.getGender().getCodeType());
            gender.setCodeDescription(clientDetails.getGender().getCodeDescription());
            clientDetailType.setGender(gender);
        }
    }

    /**
     * Set Client Date Details.
     * 
     * @param clientDetailType
     * @param clientDetails
     * @throws SILException
     */
    private void setClientDateDetails(ClientDetailType clientDetailType, ClientDetails clientDetails) throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Client Date Fields");
        if (clientDetails.getDateofBirth() != null) {
            clientDetailType.setDateOfBirth(SILUtil.convertStringToXMLGregorianCalendar(clientDetails.getDateofBirth(), CommonConstants.DATE_FORMAT));
        }
        if (clientDetails.getDateofDeath() != null) {
            clientDetailType.setDateOfDeath(SILUtil.convertStringToXMLGregorianCalendar(clientDetails.getDateofDeath(), CommonConstants.DATE_FORMAT));
        }
        if (clientDetails.getPlannedRetirementDate() != null) {
            clientDetailType.setPlannedRetirementDate(SILUtil.convertStringToXMLGregorianCalendar(clientDetails.getPlannedRetirementDate(),
                    CommonConstants.DATE_FORMAT));
        }
    }

    /**
     * Set Client Country Details.
     * 
     * @param clientDetailType
     * @param clientDetails
     */
    private void setClientCountry(ClientDetailType clientDetailType, ClientDetails clientDetails) {
        if (clientDetails.getCountryCode() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Client Country Details");
            CountryIdentifierType country = new CountryIdentifierType();
            country.setCode(clientDetails.getCountryCode());
            country.setName(clientDetails.getCountryName());
            clientDetailType.setCountry(country);
        }
    }

    /**
     * Set Client Marital Status Details.
     * 
     * @param clientDetailType
     * @param clientDetails
     */
    private void setClientMaritalStatus(ClientDetailType clientDetailType, ClientDetails clientDetails) {
        if (clientDetails.getMaritalStatus() != null && clientDetails.getMaritalStatus().getCode() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Client Marital Status Details");
            CodeIdentifierType maritalStatus = new CodeIdentifierType();
            maritalStatus.setCode(clientDetails.getMaritalStatus().getCode());
            maritalStatus.setCodeType(clientDetails.getMaritalStatus().getCodeType());
            maritalStatus.setCodeDescription(clientDetails.getMaritalStatus().getCodeDescription());
            clientDetailType.setMaritalStatus(maritalStatus);
        }
    }

    /**
     * Set Client Contact Details.
     * 
     * @param clientDetailType
     * @param clientDetails
     */
    private void setClientContactDetails(ClientDetailType clientDetailType, ClientDetails clientDetails) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Client Contact Details");
        clientDetailType.setContactName(clientDetails.getContactName());
        clientDetailType.setBusinessName(clientDetails.getBusinessName());
        clientDetailType.setMailingName(clientDetails.getMailingName());
        clientDetailType.setBusinessPhone(clientDetails.getWorkNumber());
        clientDetailType.setHomePhone(clientDetails.getHomeNumber());
        clientDetailType.setMobilePhone(clientDetails.getMobileNumber());
    }

    /**
     * Set Client Occupation Details.
     * 
     * @param clientDetailType
     * @param clientDetails
     */
    private void setClientOccupation(ClientDetailType clientDetailType, ClientDetails clientDetails) {
        if (clientDetails.getOccupationId() != null || clientDetails.getOccupationCode() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Client Occupation Details");
            OccupationIdentifierType occupation = new OccupationIdentifierType();
            if (clientDetails.getOccupationId() != null) {
                occupation.setId(Long.parseLong(clientDetails.getOccupationId()));
            }
            if (clientDetails.getOccupationCode() != null) {
                occupation.setCode(clientDetails.getOccupationCode());
            }
            if (clientDetails.getOccupationName() != null) {
                occupation.setName(clientDetails.getOccupationName());
            }
            clientDetailType.setOccupation(occupation);
        }
    }

    /**
     * Set Client Other Details.
     * 
     * @param clientDetailType
     * @param clientDetails
     */
    private void setClientOtherDetails(ClientDetailType clientDetailType, ClientDetails clientDetails) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Client Other Details");
        clientDetailType.setAgeAdmitted(Boolean.parseBoolean(clientDetails.getAgeAdmitted()));
        clientDetailType.setDisclaimerSigned(Boolean.parseBoolean(clientDetails.getDisclaimerSigned()));
        clientDetailType.setHoldCorrespondence(Boolean.parseBoolean(clientDetails.getHoldCorrespondence()));
        clientDetailType.setCanSolicit(Boolean.parseBoolean(clientDetails.getCanSolicit()));
        clientDetailType.setSecureSalaryFlag(Boolean.parseBoolean(clientDetails.getSecureSalaryFlag()));
    }

    /**
     * Set Client Preferred Language Details.
     * 
     * @param clientDetailType
     * @param clientDetails
     */
    private void setClientPreferredDetails(ClientDetailType clientDetailType, ClientDetails clientDetails) {
        if (clientDetails.getPreferredLanguage() != null && clientDetails.getPreferredLanguage().getCode() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Client Preferred Language Details");
            CodeIdentifierType preferredLanguage = new CodeIdentifierType();
            preferredLanguage.setCode(clientDetails.getPreferredLanguage().getCode());
            preferredLanguage.setCodeType(clientDetails.getPreferredLanguage().getCodeType());
            preferredLanguage.setCodeDescription(clientDetails.getPreferredLanguage().getCodeDescription());
            clientDetailType.setPreferredLanguage(preferredLanguage);
        }
        this.setClientPreferredCurrency(clientDetailType, clientDetails);
        if (clientDetails.getPreferredRisk() != null && clientDetails.getPreferredRisk().getCode() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Client Preferred Risk Details");
            CodeIdentifierType preferredRisk = new CodeIdentifierType();
            preferredRisk.setCode(clientDetails.getPreferredRisk().getCode());
            preferredRisk.setCodeType(clientDetails.getPreferredRisk().getCodeType());
            preferredRisk.setCodeDescription(clientDetails.getPreferredRisk().getCodeDescription());
            clientDetailType.setPreferredRisk(preferredRisk);
        }
    }

    /**
     * Set Client Preferred Currency Details.
     * 
     * @param clientDetailType
     * @param clientDetails
     */
    private void setClientPreferredCurrency(ClientDetailType clientDetailType, ClientDetails clientDetails) {
        if (clientDetails.getPreferCurrencyCode() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Client Preferred Currency Details");
            CurrencyIdentifierType preferredCurrency = new CurrencyIdentifierType();
            preferredCurrency.setCode(clientDetails.getPreferCurrencyCode());
            preferredCurrency.setName(clientDetails.getPreferCurrencyName());
            clientDetailType.setReportingCurrency(preferredCurrency);
        }
    }

    /**
     * Set Client Status Details.
     * 
     * @param clientDetailType
     * @param clientDetails
     */
    private void setClientStatus(ClientDetailType clientDetailType, ClientDetails clientDetails) {
        if (clientDetails.getStatus() != null && clientDetails.getStatus().getCode() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Client Status Details");
            CodeIdentifierType status = new CodeIdentifierType();
            status.setCode(clientDetails.getStatus().getCode());
            status.setCodeType(clientDetails.getStatus().getCodeType());
            status.setCodeDescription(clientDetails.getStatus().getCodeDescription());
            clientDetailType.setStatus(status);
        }
    }

    /**
     * Set Client Online Status Details.
     * 
     * @param clientDetailType
     * @param clientDetails
     */
    private void setClientOnlineStatus(ClientDetailType clientDetailType, ClientDetails clientDetails) {
        if (clientDetails.getOnlineStatus() != null && clientDetails.getOnlineStatus().getCode() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Client Online Status Details");
            CodeIdentifierType onlineStatus = new CodeIdentifierType();
            onlineStatus.setCode(clientDetails.getOnlineStatus().getCode());
            onlineStatus.setCodeType(clientDetails.getOnlineStatus().getCodeType());
            onlineStatus.setCodeDescription(clientDetails.getOnlineStatus().getCodeDescription());
            clientDetailType.setOnlineStatus(onlineStatus);
        }
    }

    /**
     * Set Client Investor Type Company and Personal Details.
     * 
     * @param clientDetailType
     * @param clientDetails
     */
    private void setClientInvestorDetails(ClientDetailType clientDetailType, ClientDetails clientDetails) {
        if (clientDetails.getInvestorTypeCompany() != null && clientDetails.getInvestorTypeCompany().getCode() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Client Investor Type Company Details");
            CodeIdentifierType investorCompany = new CodeIdentifierType();
            investorCompany.setCode(clientDetails.getInvestorTypeCompany().getCode());
            investorCompany.setCodeType(clientDetails.getInvestorTypeCompany().getCodeType());
            investorCompany.setCodeDescription(clientDetails.getInvestorTypeCompany().getCodeDescription());
            clientDetailType.setInvestorTypeCompany(investorCompany);
        }
        if (clientDetails.getInvestorTypePersonal() != null && clientDetails.getInvestorTypePersonal().getCode() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Client Investor Type Personal Details");
            CodeIdentifierType investorPersonal = new CodeIdentifierType();
            investorPersonal.setCode(clientDetails.getInvestorTypePersonal().getCode());
            investorPersonal.setCodeType(clientDetails.getInvestorTypePersonal().getCodeType());
            investorPersonal.setCodeDescription(clientDetails.getInvestorTypePersonal().getCodeDescription());
            clientDetailType.setInvestorTypePersonal(investorPersonal);
        }
    }

    /**
     * Set Client Nationality Details.
     * 
     * @param clientDetailType
     * @param clientDetails
     */
    private void setClientNationality(ClientDetailType clientDetailType, ClientDetails clientDetails) {
        if (clientDetails.getNationality() != null && clientDetails.getNationality().getCode() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Client Nationality Details");
            CodeIdentifierType nationality = new CodeIdentifierType();
            nationality.setCode(clientDetails.getNationality().getCode());
            nationality.setCodeType(clientDetails.getNationality().getCodeType());
            nationality.setCodeDescription(clientDetails.getNationality().getCodeDescription());
            clientDetailType.setNationality(nationality);
        }
    }

    /**
     * Set Client Correspondence View Option and Delivery Preference Details.
     * 
     * @param clientDetailType
     * @param clientDetails
     */
    private void setClientCorrespondenceDetails(ClientDetailType clientDetailType, ClientDetails clientDetails) {
        if (clientDetails.getCorrespondingViewOption() != null && clientDetails.getCorrespondingViewOption().getCode() != null) {
            SILLogger
                    .debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Client Correspondence View Option Details");
            CodeIdentifierType correspondenceViewOption = new CodeIdentifierType();
            correspondenceViewOption.setCode(clientDetails.getCorrespondingViewOption().getCode());
            correspondenceViewOption.setCodeType(clientDetails.getCorrespondingViewOption().getCodeType());
            correspondenceViewOption.setCodeDescription(clientDetails.getCorrespondingViewOption().getCodeDescription());
            clientDetailType.setCorrespondenceViewOptionCode(correspondenceViewOption);
        }
        if (clientDetails.getCorrespondingDeliveryPreference() != null && clientDetails.getCorrespondingDeliveryPreference().getCode() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className,
                    "Setting Client Correspondence Delivery Preference Details");
            CodeIdentifierType correspondenceDeliveryPreference = new CodeIdentifierType();
            correspondenceDeliveryPreference.setCode(clientDetails.getCorrespondingDeliveryPreference().getCode());
            correspondenceDeliveryPreference.setCodeType(clientDetails.getCorrespondingDeliveryPreference().getCodeType());
            correspondenceDeliveryPreference.setCodeDescription(clientDetails.getCorrespondingDeliveryPreference().getCodeDescription());
            clientDetailType.setCorresDeliveryPreferenceCode(correspondenceDeliveryPreference);
        }
    }

    /**
     * Set Client Address Details.
     * 
     * @param addressDetailsList
     * @param clientEntityType
     * @throws SILException
     */
    private void setClientAddressDetails(List<ClientAddressDetails> addressDetailsList, List<AddressDetailsType> address) throws SILException {
        if (addressDetailsList != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Client Address Details");
            AddressDetailsRequestUtil addressDetailsRequestUtil = new AddressDetailsRequestUtil();
            addressDetailsRequestUtil.setAddressDetails(address, addressDetailsList);
        }
    }

    /**
     * Set Client Country Details.
     * 
     * @param australia
     * @param clientDetails
     * @throws SILException
     */
    private void setClientCountryDetails(ClientEntityType.Australia australia, ClientDetails clientDetails) throws SILException {
        if (clientDetails.getCountryDetails() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Client Country Details");
            CountryDetailsRequestUtil countryDetailsRequestUtil = new CountryDetailsRequestUtil();
            countryDetailsRequestUtil.setCountryDetails(australia, clientDetails.getCountryDetails());
        }
    }

    /**
     * Set Bank Account Details.
     * 
     * @param bankAccountDetails
     * @param bankAccount
     * @throws SILException
     */
    private void setBankAccountDetails(List<BankAccountDetails> bankAccountDetails, List<ClientEntityType.BankAccount> bankAccount)
            throws SILException {
        if (bankAccountDetails != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Client Bank Account Details");
            BankAccountDetailsRequestUtil bankAccountDetailsRequestUtil = new BankAccountDetailsRequestUtil();
            bankAccountDetailsRequestUtil.setClientBankAccountDetails(bankAccount, bankAccountDetails);
        }
    }
    
    /**
     * Get Account Generic Variable Details.
     *
     * @param accountEntityDetails
     * @param accountEntityType
     * @throws SILException 
     */
    private void setGenericVariableDetails(List<GenericVariableDetails> genericVariableDetails, List<GenericVariableType> genericVariableTypeList)
            throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Account Generic Variable Details");
        for (GenericVariableDetails genericVariable : genericVariableDetails) {
            GenericVariableType genericVariableType = new GenericVariableType();
            if (genericVariable.getCode() != null) {
                genericVariableType.setCode(genericVariable.getCode());
                setValueDetails(genericVariable, genericVariableType);
            }
            genericVariableTypeList.add(genericVariableType);
        }
    }
    
    /**
     * Set Account Generic Variable Value Details.
     * 
     * @param genericVariableDetails
     * @param genericVariableType
     * @throws SILException
     */
    private void setValueDetails(GenericVariableDetails genericVariableDetails, GenericVariableType genericVariableType) throws SILException {
        GenericVariableType.Value value = new GenericVariableType.Value();
        AccountApplicationUtil accountApplicationUtil = new AccountApplicationUtil();
        if (genericVariableDetails.getValues() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Account Generic Variable Value Details");
            ValueDetails valueDetails = genericVariableDetails.getValues();
            if (valueDetails.getCode() != null) {
                CodeIdentifierDetails codeIdentifierDetails = valueDetails.getCode();
                value.setCode(accountApplicationUtil.createCodeIdentifierType(codeIdentifierDetails));
            }
            setValues(valueDetails, value);
            genericVariableType.setValue(value);
        }
    }
    /**
     * Setting Account Generic Variable Values.
     * 
     * @param valueDetails
     * @param value
     * @throws SILException
     */
    private void setValues(ValueDetails valueDetails, GenericVariableType.Value value) throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Account Generic Variable Values");
        if (valueDetails.getDecimal() != null) {
            value.setDecimal(new BigDecimal(valueDetails.getDecimal()));
        }
        if (valueDetails.getInteger() != null) {
            value.setInteger(Integer.valueOf(valueDetails.getInteger()));
        }
        if (valueDetails.getDateTime() != null) {
            value.setDatetime(SILUtil.convertStringToXMLGregorianCalendar(valueDetails.getDateTime(), CommonConstants.DATE_FORMAT));
        }
        if (valueDetails.getChecked() != null) {
            value.setChecked(valueDetails.getChecked());
        }
        if (valueDetails.getString() != null) {
            value.setString(valueDetails.getString());
        }
    }
}
