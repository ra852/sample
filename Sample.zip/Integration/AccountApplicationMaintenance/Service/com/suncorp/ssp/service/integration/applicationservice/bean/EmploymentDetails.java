////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code EmploymentDetails} does this.
 * 
 * @author U383847
 * @since 12/05/2016
 * @version 1.0
 */
public class EmploymentDetails {
    private String startDate;
    private CodeIdentifierDetails employmentType;
    private String primaryEmployer;
    private CodeIdentifierDetails employmentStatus;
    private String employerName;
    private String payrollId;
    private String salary;
    private String employerNumber;

    /**
     * Accessor for property startDate.
     * 
     * @return startDate of type String
     */
    public String getStartDate() {
        return startDate;
    }

    /**
     * Mutator for property startDate.
     * 
     * @param startDate of type String
     */
    @XmlElement(name = "startDate")
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    /**
     * Accessor for property employmentType.
     * 
     * @return employmentType of type CodeIdentifierDetails
     */
    public CodeIdentifierDetails getEmploymentType() {
        return employmentType;
    }

    /**
     * Mutator for property employmentType.
     * 
     * @param employmentType of type CodeIdentifierDetails
     */
    @XmlElement(name = "employmentType")
    public void setEmploymentType(CodeIdentifierDetails employmentType) {
        this.employmentType = employmentType;
    }

    /**
     * Accessor for property primaryEmployer.
     * 
     * @return primaryEmployer of type String
     */
    public String getPrimaryEmployer() {
        return primaryEmployer;
    }

    /**
     * Mutator for property primaryEmployer.
     * 
     * @param primaryEmployer of type String
     */
    @XmlElement(name = "primaryEmployer")
    public void setPrimaryEmployer(String primaryEmployer) {
        this.primaryEmployer = primaryEmployer;
    }

    /**
     * Accessor for property employmentStatus.
     * 
     * @return employmentStatus of type CodeIdentifierDetails
     */
    public CodeIdentifierDetails getEmploymentStatus() {
        return employmentStatus;
    }

    /**
     * Mutator for property employmentStatus.
     * 
     * @param employmentStatus of type CodeIdentifierDetails
     */
    @XmlElement(name = "employmentStatus")
    public void setEmploymentStatus(CodeIdentifierDetails employmentStatus) {
        this.employmentStatus = employmentStatus;
    }

    /**
     * Accessor for property employerName.
     * 
     * @return employerName of type String
     */
    public String getEmployerName() {
        return employerName;
    }

    /**
     * Mutator for property employerName.
     * 
     * @param employerName of type String
     */
    @XmlElement(name = "employerName")
    public void setEmployerName(String employerName) {
        this.employerName = employerName;
    }

    /**
     * Accessor for property payrollId.
     *
     * @return payrollId of type String
     */
    public String getPayrollId() {
        return payrollId;
    }

    /**
     * Mutator for property payrollId.
     *
     * @param payrollId of type String
     */
    @XmlElement(name = "payrollId")
    public void setPayrollId(String payrollId) {
        this.payrollId = payrollId;
    }

    /**
     * Accessor for property salary.
     *
     * @return salary of type String
     */
    public String getSalary() {
        return salary;
    }

    /**
     * Mutator for property salary.
     *
     * @param salary of type String
     */
    @XmlElement(name = "salary")
    public void setSalary(String salary) {
        this.salary = salary;
    }

    /**
     * Accessor for property employerNumber.
     * 
     * @return employerNumber of type String
     */
    public String getEmployerNumber() {
        return employerNumber;
    }

    /**
     * Mutator for property employerNumber.
     * 
     * @param employerNumber of type String
     */
    @XmlElement(name = "employerNumber")
    public void setEmployerNumber(String employerNumber) {
        this.employerNumber = employerNumber;
    }
    
}
