////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.xml.datatype.XMLGregorianCalendar;

import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.BankAccountIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.RelationshipTypeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.fund.fundgrouptype.FundIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.RegularPlanType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.RegularPlanType.ContributionTypeSplit;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.RegularPlanType.FundSplit;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.applicationservice.ApplicationServiceConstants;
import com.suncorp.ssp.service.integration.applicationservice.bean.BankAccountIdentifier;
import com.suncorp.ssp.service.integration.applicationservice.bean.ClientDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.CodeNameIdentifier;
import com.suncorp.ssp.service.integration.applicationservice.bean.ContributionSplitInfo;
import com.suncorp.ssp.service.integration.applicationservice.bean.FundDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.FundIdentifierDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.RegularPlanDetails;

/**
 * The class {@code RegularPlanDetailsResponseUtil} does this.
 * 
 * @author U386868
 * @since 18/02/2016
 * @version 1.0
 */
public class RegularPlanDetailsResponseUtil {
    private String className = "RegularPlanDetailsResponseUtil";
    private AccountApplicationUtil accountApplicationUtil = new AccountApplicationUtil();

    /**
     * This method is used to add RegularPlanDetails into regularPlanDetailsList, with necessary values set.
     * 
     * @param regularPlanDetailsList of type RegularPlanDetails
     * @param regularPlanType of type RegularPlanType
     */
    public void addRegularPlanDetails(List<RegularPlanDetails> regularPlanDetailsList, RegularPlanType regularPlanType) {
        if (regularPlanType != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "getRegularPlanDetails()");
            RegularPlanDetails outbounbdResponse = new RegularPlanDetails();
            outbounbdResponse.setAmount(createAmount(regularPlanType.getAmount()));
            outbounbdResponse.setBankAccount(createBankAccount(regularPlanType.getBankAccount()));
            outbounbdResponse.setClient(createClientId(regularPlanType));
            outbounbdResponse.setContributionTypeSplits(createContributionTypeSplitsList(regularPlanType.getContributionTypeSplit()));
            outbounbdResponse.setFrequency(accountApplicationUtil.createFrequencyIdentifier(regularPlanType.getFrequency()));
            outbounbdResponse.setFundSplits(createFundDetailsList(regularPlanType.getFundSplit()));
            outbounbdResponse.setLinkedToProfile(String.valueOf(regularPlanType.isLinkedToProfile()));
            outbounbdResponse.setNextDueDate(createNextDueDate(regularPlanType.getNextDueDate()));
            outbounbdResponse.setPaymentMethod(accountApplicationUtil.createCodeIdentifierInfo(regularPlanType.getPaymentMethod()));
            outbounbdResponse.setRegularPlanId(createRegularPlanId(regularPlanType.getRegularPlanId()));
            outbounbdResponse.setRelationshipType(createRelationshipType(regularPlanType.getRelationshipType()));
            outbounbdResponse.setStatus(accountApplicationUtil.createCodeIdentifierInfo(regularPlanType.getStatus()));
            regularPlanDetailsList.add(outbounbdResponse);
        } else {
            this.addDefaultRegularPlanDetails(regularPlanDetailsList);
        }
    }

    /**
     * Create Next Due Date, with necessary values set.
     * 
     * @param xmlGregorianCalendar
     * @return
     */
    private String createNextDueDate(XMLGregorianCalendar xmlGregorianCalendar) {
        String nextDueDate;
        if (xmlGregorianCalendar != null) {
            nextDueDate = SILUtil.convertXMLGregorianCalendartoString(xmlGregorianCalendar, CommonConstants.DATE_FORMAT);
        } else {
            nextDueDate = "";
        }
        return nextDueDate;
    }

    /**
     * Create Amount, with necessary values set.
     * 
     * @param amount
     * @return
     */
    private String createAmount(BigDecimal amount) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "createAmount()");
        String amt;
        if (amount != null) {
            amt = amount.toString();
        } else {
            amt = "";
        }
        return amt;
    }

    /**
     * This method is used to add Default RegularPlanDetails into regularPlanDetailsList, with necessary values set..
     * 
     * @param regularPlanDetailsList of type RegularPlanDetails
     * 
     */
    public void addDefaultRegularPlanDetails(List<RegularPlanDetails> regularPlanDetailsList) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "getDefaultRegularPlanDetails()");
        RegularPlanDetails outboundResponse = new RegularPlanDetails();
        outboundResponse.setAmount("");
        outboundResponse.setBankAccount(accountApplicationUtil.createDefaultBankAccount());
        outboundResponse.setClient(createDefaultClient());
        outboundResponse.setContributionTypeSplits(regularPlanDetailsList.get(0).getContributionTypeSplits());
        outboundResponse.setFrequency(accountApplicationUtil.createDefaultFrequencyIdentifier());
        outboundResponse.setFundSplits(addDefaultFundDetails(regularPlanDetailsList.get(0).getFundSplits()));
        outboundResponse.setLinkedToProfile("");
        outboundResponse.setNextDueDate("");
        outboundResponse.setPaymentMethod(accountApplicationUtil.createDefaultCodeIdentifierInfo());
        outboundResponse.setRegularPlanId("");
        outboundResponse.setRelationshipType(accountApplicationUtil.createDefaultCodeNameIdentifier());
        outboundResponse.setStatus(accountApplicationUtil.createDefaultCodeIdentifierInfo());
        regularPlanDetailsList.add(outboundResponse);
    }

    /**
     * This method is used to create Bank Account Details, with necessary values set.
     * 
     * @param bankAccount of type BankAccountIdentifierType
     * @return accountIdentifier of type BankAccountIdentifier
     */
    public BankAccountIdentifier createBankAccount(BankAccountIdentifierType bankAccount) {
        BankAccountIdentifier accountIdentifier = new BankAccountIdentifier();
        if (bankAccount != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "createBankAccount()");
            if (bankAccount.getId() != null) {
                accountIdentifier.setId(String.valueOf(bankAccount.getId()));
            } else {
                accountIdentifier.setId("");
            }
            accountIdentifier.setName(bankAccount.getName());
            accountIdentifier.setBankAccountCurrencyCode(createBankAccCurrCode(bankAccount));
            accountIdentifier.setAudit(accountApplicationUtil.createAuditInfo(bankAccount.getAudit()));
            accountIdentifier.setBankAccountNumber(bankAccount.getBankAccountNumber());
            accountIdentifier.setBankAccountTypeCode(bankAccount.getBankAccountTypeCode());
        } else {
            return accountApplicationUtil.createDefaultBankAccount();
        }
        return accountIdentifier;
    }

    /**
     * This method is used to create BankAccCurrCode Details, with necessary values set.
     * 
     * @param bankAccount of type BankAccountIdentifierType
     * @return bankAccCurrCode of type CodeNameIdentifier
     */
    public CodeNameIdentifier createBankAccCurrCode(BankAccountIdentifierType bankAccount) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "createBankAccCurrCodes()");
        CodeNameIdentifier bankAccCurrCode = new CodeNameIdentifier();
        if (bankAccount.getBankAccountCurrencyCode() != null) {
            bankAccCurrCode.setCode(bankAccount.getBankAccountCurrencyCode().getCode());
        } else {
            return accountApplicationUtil.createDefaultCodeNameIdentifier();
        }
        return bankAccCurrCode;
    }

    /**
     * This method is used to create ClientId, with necessary values set.
     * 
     * @param regularPlanType of type RegularPlanType
     * @return client of type ClientDetails
     */
    public ClientDetails createClientId(RegularPlanType regularPlanType) {
        ClientDetails client = new ClientDetails();
        if (regularPlanType.getClient() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "createClientId()");
            if (regularPlanType.getClient().getId() != null) {
                client.setClientId(String.valueOf(regularPlanType.getClient().getId()));
            } else {
                client.setClientId("");
            }
            return client;
        } else {
            return createDefaultClient();
        }
    }

    /**
     * This method is used to create DefaultClient Details, with necessary values set.
     * 
     * @return client of type ClientDetails
     */
    public ClientDetails createDefaultClient() {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "createDefaultClient()");
        ClientDetails client = new ClientDetails();
        client.setClientId("");
        return client;
    }

    /**
     * This method is used to create ContributionTypeSplitsList, with necessary values set.
     * 
     * @param contributionTypeSplit of type ContributionTypeSplit
     * @return contributionSplitList of type ContributionSplitInfo
     */
    public List<ContributionSplitInfo> createContributionTypeSplitsList(List<ContributionTypeSplit> contributionTypeSplit) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "createContributionTypeSplitsList()");
        List<ContributionSplitInfo> contributionSplitList = new ArrayList<ContributionSplitInfo>();
        if (contributionTypeSplit != null && contributionTypeSplit.size() > 0) {
            addContributionTypeSplits(contributionTypeSplit, contributionSplitList);
        } else {
            addDefaultContributionTypeSplits(contributionSplitList);
        }
        return contributionSplitList;
    }

    /**
     * This method is used to add ContributionTypeSplits into contributionSplitList, with necessary values set.
     * 
     * @param contributionTypeSplit of type ContributionTypeSplit
     * @param contributionSplitList of type contributionSplitList
     */
    public void addContributionTypeSplits(List<ContributionTypeSplit> contributionTypeSplit, List<ContributionSplitInfo> contributionSplitList) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "addContributionTypeSplits()");
        ContributionTypeSplit split;
        for (ContributionTypeSplit type : contributionTypeSplit) {
            split = type;
            ContributionSplitInfo splitInfo = new ContributionSplitInfo();
            if (split.getAmount() != null) {
                splitInfo.setAmount(split.getAmount().toString());
            } else {
                splitInfo.setAmount("");
            }
            if (split.getPercentage() != null) {
                splitInfo.setPercentage(split.getPercentage().toString());
            } else {
                splitInfo.setPercentage("");
            }
            if (split.getContributionTypeCode() != null) {
                splitInfo.setContributionTypeCode(accountApplicationUtil.createCodeIdentifierInfo(split.getContributionTypeCode()));
            } else {
                splitInfo.setContributionTypeCode(accountApplicationUtil.createDefaultCodeIdentifierInfo());
            }
            contributionSplitList.add(splitInfo);
        }
    }

    /**
     * This method is used to add Default ContributionTypeSplits into contributionSplitList, with necessary values set.
     * 
     * @param contributionSplitList of type ContributionSplitInfo
     */
    public void addDefaultContributionTypeSplits(List<ContributionSplitInfo> contributionSplitList) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "addDefaultContributionTypeSplits()");
        ContributionSplitInfo splitInfo = new ContributionSplitInfo();
        splitInfo.setAmount("");
        splitInfo.setPercentage("");
        splitInfo.setContributionTypeCode(accountApplicationUtil.createDefaultCodeIdentifierInfo());
        contributionSplitList.add(splitInfo);
    }

    /**
     * This method is used to create FundDetailsList, with necessary values set.
     * 
     * @param fundSplit of type FundSplit
     * @return fundDetailsList of type FundDetails
     */
    public List<FundDetails> createFundDetailsList(List<FundSplit> fundSplit) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "createFundDetailsList()");
        List<FundDetails> fundDetailsList = new ArrayList<FundDetails>();
        if (fundSplit != null && fundSplit.size() > 0) {
            addFundDetails(fundSplit, fundDetailsList);
        } else {
            addDefaultFundDetails(fundDetailsList);
        }
        return fundDetailsList;
    }

    /**
     * This method is used to add FundDetails into fundDetailsList, with necessary values set.
     * 
     * @param fundSplit of type FundSplit
     * @param fundDetailsList of type FundDetails
     */
    public void addFundDetails(List<FundSplit> fundSplit, List<FundDetails> fundDetailsList) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "addFundDetails()");
        FundSplit split;
        for (FundSplit type : fundSplit) {
            split = type;
            FundDetails fundDetails = new FundDetails();
            if (split.getFund() != null) {
                fundDetails.setFundIdentifier(getFund(split.getFund()));
            } else {
                fundDetails.setFundIdentifier(getDefaultFund());
            }
            if (split.getPercentage() != null) {
                fundDetails.setSplitPercent(split.getPercentage().toString());
            } else {
                fundDetails.setSplitPercent("");
            }
            fundDetailsList.add(fundDetails);
        }
    }

    /**
     * This method is used to get Default FundIdentifierDetails, with necessary values set.
     * 
     * @return fund of type FundIdentifierDetails
     */
    public FundIdentifierDetails getDefaultFund() {
        FundIdentifierDetails fund = new FundIdentifierDetails();
        fund.setId("");
        return fund;
    }

    /**
     * This method is used to get FundIdentifierDetails, with necessary values set.
     * 
     * @param fundIdentifierType of type FundIdentifierType
     * @return fund of type FundIdentifierDetails
     * 
     */
    public FundIdentifierDetails getFund(FundIdentifierType fundIdentifierType) {
        FundIdentifierDetails fund = new FundIdentifierDetails();
        if (fundIdentifierType.getId() != null) {
            fund.setId(fundIdentifierType.getId().toString());
        } else {
            fund.setId("");
        }
        return fund;
    }

    /**
     * This method is used to add Default FundDetails, with necessary values set.
     * 
     * @param fundDetailsList of type FundDetails
     * @return fundDetailsList of type FundDetails
     */
    public List<FundDetails> addDefaultFundDetails(List<FundDetails> fundDetailsList) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "addDefaultFundDetails()");
        FundDetails fundDetails = new FundDetails();
        FundIdentifierDetails fund = new FundIdentifierDetails();
        fund.setId("");
        fundDetails.setFundIdentifier(fund);
        fundDetails.setSplitPercent("");
        fundDetailsList.add(fundDetails);
        return fundDetailsList;
    }

    /**
     * This method is used to create RegularPlanId, with necessary values set.
     * 
     * @param regularPlanId of type Long
     * @return id of type String
     */
    public String createRegularPlanId(Long regularPlanId) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "createRegularPlanId()");
        String id = null;
        if (regularPlanId != null) {
            id = regularPlanId.toString();
        } else {
            id = "";
        }
        return id;
    }

    /**
     * This method is used to create RelationshipType Details, with necessary values set.
     * 
     * @param relationshipType of type RelationshipTypeIdentifierType
     * @return identifier of type CodeNameIdentifier
     */
    public CodeNameIdentifier createRelationshipType(RelationshipTypeIdentifierType relationshipType) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "createRelationshipType()");
        CodeNameIdentifier identifier = new CodeNameIdentifier();
        if (relationshipType != null) {
            identifier.setCode(relationshipType.getCode());
            identifier.setName(relationshipType.getName());
            if (relationshipType.getId() != null) {
                identifier.setId(relationshipType.getId().toString());
            } else {
                identifier.setId("");
            }
        } else {
            return accountApplicationUtil.createDefaultCodeNameIdentifier();
        }
        return identifier;
    }

}
