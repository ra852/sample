////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code PaymentSplitInfo} does this.
 * 
 * @author u385424
 * @since 16/02/2016
 * @version 1.0
 */
public class PaymentSplitInfo {
    private String percentage;
    private String amount;

    /**
     * Accessor for property percentage.
     * 
     * @return percentage of type String
     */
    public String getPercentage() {
        return percentage;
    }

    /**
     * Mutator for property percentage.
     * 
     * @return percentage of type String
     */
    @XmlElement(name = "percentage")
    public void setPercentage(String percentage) {
        this.percentage = percentage;
    }

    /**
     * Accessor for property amount.
     * 
     * @return amount of type String
     */
    public String getAmount() {
        return amount;
    }

    /**
     * Mutator for property amount.
     * 
     * @return amount of type String
     */
    @XmlElement(name = "amount")
    public void setAmount(String amount) {
        this.amount = amount;
    }

}
