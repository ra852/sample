////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code SchemeCategoryDetails} is a java bean consisting of properties related to Scheme Category Details.
 * @author U383847
 * @since 06/01/2016
 * @version 1.0
 */
public class SchemeCategoryDetails {
    private String schemeCategoryId;
    private String schemeCategoryName;
    private SchemeDetails scheme;
    
    /**
     * Accessor for property schemeCategoryId.
     *
     * @return schemeCategoryId of type String
     */
    public String getSchemeCategoryId() {
        return schemeCategoryId;
    }

    /**
     * Mutator for property schemeCategoryId.
     *
     * @param schemeCategoryId of type String
     */
    @XmlElement(name = "schemeCategoryId")
    public void setSchemeCategoryId(String schemeCategoryId) {
        this.schemeCategoryId = schemeCategoryId;
    }

    /**
     * Accessor for property schemeCategoryName.
     * 
     * @return schemeCategoryName of type String
     */
    public String getSchemeCategoryName() {
        return schemeCategoryName;
    }
    
    /**
     * Mutator for property schemeCategoryName.
     * 
     * @param schemeCategoryName of type String
     */
    @XmlElement(name = "schemeCategoryName")
    public void setSchemeCategoryName(String schemeCategoryName) {
        this.schemeCategoryName = schemeCategoryName != null ? schemeCategoryName : "";
    }

    /**
     * Accessor for property scheme.
     * @return scheme of type SchemeDetails
     */
    public SchemeDetails getScheme() {
        return scheme;
    }

    /**
     * Mutator for property scheme.
     * @return scheme of type SchemeDetails
     */
    public void setScheme(SchemeDetails scheme) {
        this.scheme = scheme;
    }
    
    
}
