////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code ContributionSplitInfo} does this.
 * 
 * @author U386868
 * @since 10/02/2016
 * @version 1.0
 */
public class ContributionSplitInfo {

    private CodeIdentifierDetails contributionTypeCode;
    private String percentage;
    private String amount;
    private CodeNameIdentifier amountCurrencyCode;

    /**
     * Accessor for property contributionTypeCode.
     * 
     * @return contributionTypeCode of type CodeIdentifierDetails
     */
    public CodeIdentifierDetails getContributionTypeCode() {
        return contributionTypeCode;
    }

    /**
     * Mutator for property contributionTypeCode.
     * 
     * @return contributionTypeCode of type CodeIdentifierDetails
     */
    @XmlElement(name = "contributionTypeCode")
    public void setContributionTypeCode(CodeIdentifierDetails contributionTypeCode) {
        this.contributionTypeCode = contributionTypeCode;
    }

    /**
     * Accessor for property percentage.
     * 
     * @return percentage of type String
     */
    public String getPercentage() {
        return percentage;
    }

    /**
     * Mutator for property percentage.
     * 
     * @return percentage of type String
     */
    @XmlElement(name = "percentage")
    public void setPercentage(String percentage) {
        this.percentage = percentage;
    }

    /**
     * Accessor for property amount.
     * 
     * @return amount of type String
     */
    public String getAmount() {
        return amount;
    }

    /**
     * Mutator for property amount.
     * 
     * @return amount of type String
     */
    @XmlElement(name = "amount")
    public void setAmount(String amount) {
        this.amount = amount;
    }

    /**
     * Accessor for property amountCurrencyCode.
     * 
     * @return amountCurrencyCode of type CodeNameIdentifier
     */
    public CodeNameIdentifier getAmountCurrencyCode() {
        return amountCurrencyCode;
    }

    /**
     * Mutator for property amountCurrencyCode.
     * 
     * @return amountCurrencyCode of type CodeNameIdentifier
     */
    @XmlElement(name = "amountCurrencyCode")
    public void setAmountCurrencyCode(CodeNameIdentifier amountCurrencyCode) {
        this.amountCurrencyCode = amountCurrencyCode;
    }
}
