////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code ProfileFunctionDetails} does this.
 * @author U383847
 * @since 28/01/2016
 * @version 1.0
 */
public class ProfileFunctionDetails {
    private String id;
    private String name;
    private String code;
    private AuditDetails auditDetails;
    
    /**
     * Accessor for property id.
     * 
     * @return id of type String
     */
    public String getId() {
        return id;
    }
    
    /**
     * Mutator for property id.
     * 
     * @param id of type String
     */
    @XmlElement(name = "profileFunctionId")
    public void setId(String id) {
        this.id = id;
    }
    
    /**
     * Accessor for property name.
     * 
     * @return name of type String
     */
    public String getName() {
        return name;
    }
    
    /**
     * Mutator for property name.
     * 
     * @param name of type String
     */
    @XmlElement(name = "profileFunctionName")
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Accessor for property code.
     * 
     * @return code of type String
     */
    public String getCode() {
        return code;
    }

    /**
     * Mutator for property code.
     * 
     * @return code of type String
     */
    @XmlElement(name = "profileFunctionCode")
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Accessor for property auditDetails.
     * 
     * @return auditDetails of type AuditDetails
     */
    public AuditDetails getAuditDetails() {
        return auditDetails;
    }

    /**
     * Mutator for property auditDetails.
     * 
     * @return auditDetails of type AuditDetails
     */
    @XmlElement(name = "auditDetails")
    public void setAuditDetails(AuditDetails auditDetails) {
        this.auditDetails = auditDetails;
    }    
}
