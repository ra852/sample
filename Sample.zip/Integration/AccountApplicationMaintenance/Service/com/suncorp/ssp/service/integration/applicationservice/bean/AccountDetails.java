////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code AccountDetails} is a java bean consisting of properties related to account details.
 * 
 * @author U383847
 * @since 06/01/2016
 * @version 1.0
 */
public class AccountDetails {
    private AccountIdentifierDetails accountIdentifier;
    private String clientPointer;
    private ClientDetails client;
    private List<ClientRelationshipDetails> clientRelationship;
    private ProductDetails product;
    private SchemeDetails scheme;
    private SchemeCategoryDetails schemeCategory;
    private MarketingCampaignDetails marketingCampaign;
    private AccountDetail accountDetails;
    private List<AccountExternalReferenceDetails> externalReferenceType;
    private List<AccountAdvisorDetails> advisorGroup;
    private List<InvestmentProfileDetails> investmentProfile;
    private ExpenseGroupDetails expenseGroup;
    private List<ExpenseLineDetails> expenseLine;
    private List<RegularPlanDetails> regularContributionPlan;
    private AccountTaxDetail accountTaxDetail;
    private PensionPaymentDetails pensionPaymentDetails;
    private List<PensionPaymentSplitDetails> pensionPaymentSplitDetails;
    private List<BeneficiaryBean> beneficiaries;
    private List<GenericVariableDetails> genericVariables;
    private List<EmploymentDetails> employmentDetails;

    /**
     * Accessor for property accountIdentifier.
     * 
     * @return accountIdentifier of type AccountIdentifierDetails
     */
    public AccountIdentifierDetails getAccountIdentifier() {
        return accountIdentifier;
    }

    /**
     * Mutator for property accountIdentifier.
     * 
     * @return accountIdentifier of type AccountIdentifierDetails
     */
    @XmlElement(name = "accountIdentifierDetails")
    public void setAccountIdentifier(AccountIdentifierDetails accountIdentifier) {
        this.accountIdentifier = accountIdentifier;
    }

    /**
     * Accessor for property clientPointer.
     * 
     * @return clientPointer of type ClientPointerRef
     */
    public String getClientPointer() {
        return clientPointer;
    }

    /**
     * Mutator for property clientPointer.
     * 
     * @param clientPointer of type ClientPointerRef
     */
    @XmlElement(name = "clientPointer")
    public void setClientPointer(String clientPointer) {
        this.clientPointer = clientPointer;
    }

    /**
     * Accessor for property clientRelationship.
     * 
     * @return clientRelationship of type ClientRelationshipDetails
     */
    public List<ClientRelationshipDetails> getClientRelationship() {
        return clientRelationship;
    }

    /**
     * Mutator for property clientRelationship.
     * 
     * @param clientRelationship of type ClientRelationshipDetails
     */
    @XmlElement(name = "clientRelationshipDetails")
    public void setClientRelationship(List<ClientRelationshipDetails> clientRelationship) {
        this.clientRelationship = clientRelationship;
    }

    /**
     * Accessor for property product.
     * 
     * @return product of type ProductDetails
     */
    public ProductDetails getProduct() {
        return product;
    }

    /**
     * Mutator for property product.
     * 
     * @param product of type ProductDetails
     */
    @XmlElement(name = "productDetails")
    public void setProduct(ProductDetails product) {
        this.product = product;
    }

    /**
     * Accessor for property scheme.
     * 
     * @return scheme of type SchemeDetails
     */
    public SchemeDetails getScheme() {
        return scheme;
    }

    /**
     * Mutator for property scheme.
     * 
     * @param scheme of type SchemeDetails
     */
    @XmlElement(name = "schemeDetails")
    public void setScheme(SchemeDetails scheme) {
        this.scheme = scheme;
    }

    /**
     * Accessor for property schemeCategory.
     * 
     * @return schemeCategory of type SchemeCategoryDetails
     */
    public SchemeCategoryDetails getSchemeCategory() {
        return schemeCategory;
    }

    /**
     * Mutator for property schemeCategory.
     * 
     * @param schemeCategory of type SchemeCategoryDetails
     */
    @XmlElement(name = "schemeCategoryDetails")
    public void setSchemeCategory(SchemeCategoryDetails schemeCategory) {
        this.schemeCategory = schemeCategory;
    }

    /**
     * Accessor for property marketingCampaign.
     * 
     * @return marketingCampaign of type MarketingCampaignDetails
     */
    public MarketingCampaignDetails getMarketingCampaign() {
        return marketingCampaign;
    }

    /**
     * Mutator for property marketingCampaign.
     * 
     * @param marketingCampaign of type MarketingCampaignDetails
     */
    @XmlElement(name = "marketingCampaignDetails")
    public void setMarketingCampaign(MarketingCampaignDetails marketingCampaign) {
        this.marketingCampaign = marketingCampaign;
    }

    /**
     * Accessor for property accountDetails.
     * 
     * @return accountDetails of type AccountDetail
     */
    public AccountDetail getAccountDetails() {
        return accountDetails;
    }

    /**
     * Mutator for property accountDetails.
     * 
     * @param accountDetails of type AccountDetail
     */
    @XmlElement(name = "accountDetail")
    public void setAccountDetails(AccountDetail accountDetails) {
        this.accountDetails = accountDetails;
    }

    /**
     * Accessor for property externalReferenceType.
     * 
     * @return externalReferenceType of type List<AccountExternalReferenceDetails>
     */
    public List<AccountExternalReferenceDetails> getExternalReferenceType() {
        return externalReferenceType;
    }

    /**
     * Mutator for property externalReferenceType.
     * 
     * @param externalReferenceType of type List<AccountExternalReferenceDetails>
     */
    @XmlElement(name = "externalReferenceTypeDetails")
    public void setExternalReferenceType(List<AccountExternalReferenceDetails> externalReferenceType) {
        this.externalReferenceType = externalReferenceType;
    }

    /**
     * Accessor for property advisorGroup.
     * 
     * @return advisorGroup of type List<AccountAdvisorDetails>
     */
    public List<AccountAdvisorDetails> getAdvisorGroup() {
        return advisorGroup;
    }

    /**
     * Mutator for property advisorGroup.
     * 
     * @param advisorGroup of type List<AccountAdvisorDetails>
     */
    @XmlElement(name = "advisorDetails")
    public void setAdvisorGroup(List<AccountAdvisorDetails> advisorGroup) {
        this.advisorGroup = advisorGroup;
    }

    /**
     * Accessor for property investmentProfile.
     * 
     * @return investmentProfile of type List<InvestmentProfileDetails>
     */
    public List<InvestmentProfileDetails> getInvestmentProfile() {
        return investmentProfile;
    }

    /**
     * Mutator for property investmentProfile.
     * 
     * @return investmentProfile of type List<InvestmentProfileDetails>
     */
    @XmlElement(name = "investmentProfileDetails")
    public void setInvestmentProfile(List<InvestmentProfileDetails> investmentProfile) {
        this.investmentProfile = investmentProfile;
    }

    /**
     * Accessor for property expenseGroup.
     * 
     * @return expenseGroup of type ExpenseGroupDetails
     */
    public ExpenseGroupDetails getExpenseGroup() {
        return expenseGroup;
    }

    /**
     * Mutator for property expenseGroup.
     * 
     * @return expenseGroup of type ExpenseGroupDetails
     */
    @XmlElement(name = "expenseGroupDetails")
    public void setExpenseGroup(ExpenseGroupDetails expenseGroup) {
        this.expenseGroup = expenseGroup;
    }

    /**
     * Accessor for property expenseLine.
     * 
     * @return expenseLine of type List<ExpenseLineDetails>
     */
    public List<ExpenseLineDetails> getExpenseLine() {
        return expenseLine;
    }

    /**
     * Mutator for property expenseLine.
     * 
     * @return expenseLine of type List<ExpenseLineDetails>
     */
    @XmlElement(name = "expenseLineDetails")
    public void setExpenseLine(List<ExpenseLineDetails> expenseLine) {
        this.expenseLine = expenseLine;
    }

    /**
     * Accessor for property regularContributionPlan.
     * 
     * @return regularContributionPlan of type List<RegularPlanDetails>
     */
    public List<RegularPlanDetails> getRegularContributionPlan() {
        return regularContributionPlan;
    }

    /**
     * Mutator for property regularContributionPlan.
     * 
     * @return regularContributionPlan of type List<RegularPlanDetails>
     */
    @XmlElement(name = "regularContributionPlan")
    public void setRegularContributionPlan(List<RegularPlanDetails> regularContributionPlan) {
        this.regularContributionPlan = regularContributionPlan;
    }

    /**
     * Accessor for property accountTaxDetail.
     * 
     * @return accountTaxDetail of type AccountTaxDetail
     */
    public AccountTaxDetail getAccountTaxDetail() {
        return accountTaxDetail;
    }

    /**
     * Mutator for property accountTaxDetail.
     * 
     * @return accountTaxDetail of type AccountTaxDetail
     */
    @XmlElement(name = "accountTaxDetail")
    public void setAccountTaxDetail(AccountTaxDetail accountTaxDetail) {
        this.accountTaxDetail = accountTaxDetail;
    }

    /**
     * Accessor for property pensionPaymentDetails.
     * 
     * @return pensionPaymentDetails of type PensionPaymentDetails
     */
    public PensionPaymentDetails getPensionPaymentDetails() {
        return pensionPaymentDetails;
    }

    /**
     * Mutator for property pensionPaymentDetails.
     * 
     * @return pensionPaymentDetails of type PensionPaymentDetails
     */
    @XmlElement(name = "pensionPaymentDetails")
    public void setPensionPaymentDetails(PensionPaymentDetails pensionPaymentDetails) {
        this.pensionPaymentDetails = pensionPaymentDetails;
    }

    /**
     * Accessor for property pensionPaymentSplitDetails.
     * 
     * @return pensionPaymentSplitDetails of type List<PensionPaymentSplit>
     */
    public List<PensionPaymentSplitDetails> getPensionPaymentSplitDetails() {
        return pensionPaymentSplitDetails;
    }

    /**
     * Mutator for property pensionPaymentSplitDetails.
     * 
     * @return pensionPaymentSplitDetails of type List<PensionPaymentSplit>
     */
    @XmlElement(name = "pensionPaymentSplitDetails")
    public void setPensionPaymentSplitDetails(List<PensionPaymentSplitDetails> pensionPaymentSplitDetails) {
        this.pensionPaymentSplitDetails = pensionPaymentSplitDetails;
    }

    /**
     * Accessor for property client.
     * 
     * @return client of type ClientDetails
     */
    public ClientDetails getClient() {
        return client;
    }

    /**
     * Mutator for property client.
     * 
     * @param client of type ClientDetails
     */
    @XmlElement(name = "client")
    public void setClient(ClientDetails client) {
        this.client = client;
    }

    /**
     * Accessor for property beneficiaries.
     * 
     * @return beneficiaries of type List<BeneficiaryBean>
     */
    public List<BeneficiaryBean> getBeneficiaries() {
        return beneficiaries;
    }

    /**
     * Mutator for property beneficiaries.
     * 
     * @param beneficiaries of type List<BeneficiaryBean>
     */
    @XmlElement(name = "beneficiaries")
    public void setBeneficiaries(List<BeneficiaryBean> beneficiaries) {
        this.beneficiaries = beneficiaries;
    }

    /**
     * Accessor for property genericVariables.
     *
     * @return genericVariables of type List<GenericVariableDetails>
     */
    public List<GenericVariableDetails> getGenericVariables() {
        return genericVariables;
    }

    /**
     * Mutator for property genericVariables.
     *
     * @param genericVariables of type List<GenericVariableDetails>
     */
    @XmlElement(name = "genericVariables")
    public void setGenericVariables(List<GenericVariableDetails> genericVariables) {
        this.genericVariables = genericVariables;
    }

    /**
     * Accessor for property employmentDetails.
     *
     * @return employmentDetails of type List<EmploymentDetails>
     */
    public List<EmploymentDetails> getEmploymentDetails() {
        return employmentDetails;
    }

    /**
     * Mutator for property employmentDetails.
     *
     * @param employmentDetails of type List<EmploymentDetails>
     */
    @XmlElement(name = "employmentDetails")
    public void setEmploymentDetails(List<EmploymentDetails> employmentDetails) {
        this.employmentDetails = employmentDetails;
    }

}
