////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.util;

import java.math.BigDecimal;
import java.util.List;

import javax.xml.datatype.XMLGregorianCalendar;

import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.AdvisorGroupType;
import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.AdvisorSplitType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CodeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.ExpenseLineType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.ExpenseParameterType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.ExternalRefType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.FrequencyIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.GenericVariableType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.PatternTemplateIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.ProfileFunctionIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.RelationshipTypeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.fund.fundgrouptype.FundIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.marketing.marketinggrouptype.MarketingCampaignIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.scheme.schemegrouptype.EmploymentCreateType;
import com.sonatacentral.service.v30.globaltypes.common.scheme.schemegrouptype.SchemeCategoryIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.scheme.schemegrouptype.SchemeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.scheme.schemegrouptype.SchemeLocationIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountDetailType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountEntityType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType.AccountNumber;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountTaxType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.BeneficiaryType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.ClientRelationshipType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.InvestmentProfileType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.PensionPaymentSplitType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.RegularPlanType;
import com.sonatacentral.service.v30.globaltypes.wrap.product.productgrouptype.ProductIdentifierType;
import com.sonatacentral.service.v30.life.application.CreateApplicationRequestType.Client;
import com.sonatacentral.service.v30.wrap.application.AccountApplicationRequestType.Account;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.applicationservice.ApplicationServiceConstants;
import com.suncorp.ssp.service.integration.applicationservice.bean.AccountAdvisorDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.AccountDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.AccountExternalReferenceDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.AccountIdentifierDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.AccountTaxDetail;
import com.suncorp.ssp.service.integration.applicationservice.bean.AdvisorSplitDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.BeneficiaryBean;
import com.suncorp.ssp.service.integration.applicationservice.bean.ClientRelationshipDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.CodeIdentifierDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.EmploymentDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.ExpenseLineDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.ExpenseParameterDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.FundDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.FundIdentifierDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.GenericVariableDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.InvestmentProfileDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.PatternTemplateDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.PensionPaymentDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.PensionPaymentSplitDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.ProfileDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.RebalancingBean;
import com.suncorp.ssp.service.integration.applicationservice.bean.RebalancingFrequencyBean;
import com.suncorp.ssp.service.integration.applicationservice.bean.RegularPlanDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.ValueDetails;

/**
 * The class {@code AccountDetailsRequestUtil} is a Utility class with all the properties related to account details, to construct request for
 * creating account application external service's request object.
 * 
 * @author U383847
 * @since 08/01/2016
 * @version 1.0
 */
public class AccountDetailsRequestUtil {
    private final String className = "AccountDetailsRequestUtil";
    private AccountApplicationUtil accountApplicationUtil = null;

    /**
     * Default Constructor.
     * 
     */
    public AccountDetailsRequestUtil() {
        accountApplicationUtil = new AccountApplicationUtil();
    }

    /**
     * Set Account Entity Details.
     * 
     * @param accountEntityType
     * @param accountReqTypeList
     * @throws SILException
     */
    public void setAccountDetails(List<AccountDetails> accountDetailsList, List<Account> accountReqTypeList) throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Account Entity Details");
        for (AccountDetails accountDetails : accountDetailsList) {
            Account accountRequestDetailsType = new Account();
            Object clientObject = this.getClientPointerDetails(accountDetails, null);
            createAccountApplicationDetails(accountDetails, accountRequestDetailsType, clientObject);
            this.setAccountInvestmentProfileDetails(accountRequestDetailsType, accountDetails.getInvestmentProfile());
            this.setAccountExpenseLineDetails(accountRequestDetailsType, accountDetails.getExpenseLine());
            this.setAccountRegularPlanDetails(accountRequestDetailsType, accountDetails.getRegularContributionPlan());
            this.setAccountTaxDetails(accountRequestDetailsType, accountDetails.getAccountTaxDetail());
            this.setPensionPaymentDetails(accountRequestDetailsType, accountDetails.getPensionPaymentDetails());
            this.setPensionPaymentSplit(accountRequestDetailsType, accountDetails);
            this.addBeneficiaryDetails(accountRequestDetailsType, accountDetails);
            this.setGenericVariableDetails(accountRequestDetailsType, accountDetails);
            this.setAccountEmploymentDetails(accountRequestDetailsType, accountDetails);
            accountReqTypeList.add(accountRequestDetailsType);
        }
    }

    /**
     * Create request for Account Application Details.
     * 
     * @param accountDetails
     * @param accountRequestDetailsType
     * @param clientObject
     * @throws SILException
     */
    private void createAccountApplicationDetails(AccountDetails accountDetails, Account accountRequestDetailsType,
            Object clientObject) throws SILException {
        this.setAccountIdClientRefDetails(accountDetails, accountRequestDetailsType, clientObject);
        this.setClientDetailInfo(accountRequestDetailsType, accountDetails);
        this.setAccountClientRelationshipDetails(accountRequestDetailsType, accountDetails.getClientRelationship());
        this.setAccountProductDetails(accountRequestDetailsType, accountDetails);
        this.setAccountSchemeDetails(accountRequestDetailsType, accountDetails);
        this.setAccountSchemeCategoryDetails(accountRequestDetailsType, accountDetails);
        this.setAccountMarketingCampaignDetails(accountRequestDetailsType, accountDetails);
        this.setAccountDetails(accountRequestDetailsType, accountDetails);
        this.setAccountExternalReferenceDetails(accountRequestDetailsType, accountDetails.getExternalReferenceType());
        this.setAccountAdvisorGroupDetails(accountRequestDetailsType, accountDetails.getAdvisorGroup());
    }

    /**
     * Set Client Details.
     * 
     * @param accountRequestDetailsType
     * @param accountDetails
     */
    private void setClientDetailInfo(Account accountRequestDetailsType, AccountDetails accountDetails) {
        if (accountDetails.getClient() != null) {
            accountRequestDetailsType.setClient(accountApplicationUtil.setClientInfo(accountDetails.getClient()));
        }

    }

    /**
     * Get Client Pointer Details.
     * 
     * @param accountDetails
     * @return
     */
    private Client getClientPointerDetails(AccountDetails accountDetails, ClientRelationshipDetails clientRelationshipDetails) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Client Pointer Details");
        Client clientRequestDetailsType = new Client();
        if (accountDetails != null) {
            clientRequestDetailsType.setId(accountDetails.getClientPointer());
        } else if (clientRelationshipDetails != null) {
            clientRequestDetailsType.setId(clientRelationshipDetails.getClientPointer());
        }
        if (clientRequestDetailsType.getId() != null) {
            return clientRequestDetailsType;
        }
        return null;
    }

    /**
     * Set Account Id and Client Reference Details.
     * 
     * @param accountDetails
     * @param accountRequestDetailsType
     * @param clientRequestDetailType
     */
    private void setAccountIdClientRefDetails(AccountDetails accountDetails, Account accountRequestDetails, Object clientObject) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Account Id and Client Reference Details");
        if (accountDetails.getAccountIdentifier() != null) {
            accountRequestDetails.setId(accountDetails.getAccountIdentifier().getAccountId());
        }
        if (clientObject != null) {
            accountRequestDetails.setClient(accountApplicationUtil.getClientPointerReference(clientObject));
        }
    }

    /**
     * Set Account Client Relationship Details.
     * 
     * @param accountEntityType
     * @param clientRelationshipDetailsList
     * @throws SILException
     */
    private void setAccountClientRelationshipDetails(Account accountRequestDetailsType,
            List<ClientRelationshipDetails> clientRelationshipDetailsList) throws SILException {
        if (clientRelationshipDetailsList != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Account Client Relationship Details");
            List<ClientRelationshipType> clientRelationshipTypeList = accountRequestDetailsType.getRelationship();
            for (ClientRelationshipDetails clientRelationshipDetails : clientRelationshipDetailsList) {
                ClientRelationshipType clientRelationshipType = new ClientRelationshipType();
                this.setClientRelationshipPointer(clientRelationshipDetails, clientRelationshipType);
                RelationshipTypeIdentifierType relationshipType = new RelationshipTypeIdentifierType();
                relationshipType.setCode(clientRelationshipDetails.getRelationshipTypeCode());
                clientRelationshipType.setRelationshipType(relationshipType);
                clientRelationshipType.setPrimary(Boolean.parseBoolean(clientRelationshipDetails.getPrimaryFlag()));
                this.setDate(clientRelationshipDetails, clientRelationshipType);
                if (clientRelationshipDetails.getClient() != null) {
                    clientRelationshipType.setClient(accountApplicationUtil.setClientInfo(clientRelationshipDetails.getClient()));
                }
                clientRelationshipTypeList.add(clientRelationshipType);
            }
        }
    }

    /**
     * Set Account Client Relationship Details.
     * 
     * @param clientRelationshipDetails
     * @param clientRelationshipType
     * @throws SILException
     */
    private void setDate(ClientRelationshipDetails clientRelationshipDetails, ClientRelationshipType clientRelationshipType) throws SILException {
        if (clientRelationshipDetails.getDateJoined() != null) {
            clientRelationshipType.setDateJoined(SILUtil.convertStringToXMLGregorianCalendar(clientRelationshipDetails.getDateJoined(),
                    CommonConstants.DATE_FORMAT));
        }
        if (clientRelationshipDetails.getEndDate() != null) {
            clientRelationshipType.setEndDate(SILUtil.convertStringToXMLGregorianCalendar(clientRelationshipDetails.getEndDate(),
                    CommonConstants.DATE_FORMAT));
        }

    }

    /**
     * Set Client Relationship Pointer.
     * 
     * @param clientRelationshipDetails
     * @param clientRelationshipType
     */
    private void setClientRelationshipPointer(ClientRelationshipDetails clientRelationshipDetails, ClientRelationshipType clientRelationshipType) {
        if (clientRelationshipDetails != null) {
            Object clientObject = this.getClientPointerDetails(null, clientRelationshipDetails);
            if (clientObject != null) {
                SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Client Relationship Pointer");
                clientRelationshipType.setClient(accountApplicationUtil.getClientPointerReference(clientObject));
            }
        }
    }

    /**
     * Set Account Product Details.
     * 
     * @param accountEntityType
     * @param accountEntityDetails
     * @throws SILException
     */
    private void setAccountProductDetails(Account accountRequestDetailsType, AccountDetails accountEntityDetails)
            throws SILException {
        if (accountEntityDetails.getProduct() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Account Product Details");
            ProductIdentifierType productIdentifierType = new ProductIdentifierType();
            if (accountEntityDetails.getProduct().getProductName() != null) {
                productIdentifierType.setName(accountEntityDetails.getProduct().getProductName());
            }
            if (accountEntityDetails.getProduct().getProductId() != null) {
                productIdentifierType.setId(Long.parseLong(accountEntityDetails.getProduct().getProductId()));
            }
            if (productIdentifierType.getName() != null || productIdentifierType.getId() != null) {
                accountRequestDetailsType.setProduct(productIdentifierType);
            } else {
                throw new SILException(ApplicationServiceConstants.INVALID_PRODUCT_INFO);
            }
        }
    }

    /**
     * Set Account Scheme Details.
     * 
     * @param accountEntityType
     * @param accountEntityDetails
     */
    private void setAccountSchemeDetails(Account accountRequestDetailsType, AccountDetails accountEntityDetails) {
        if (accountEntityDetails.getScheme() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Account Scheme Details");
            SchemeIdentifierType schemeIdentifierType = new SchemeIdentifierType();
            schemeIdentifierType.setName(accountEntityDetails.getScheme().getSchemeName());
            schemeIdentifierType.setSchemeNumber(accountEntityDetails.getScheme().getSchemeNumber());
            accountRequestDetailsType.setScheme(schemeIdentifierType);
        }
    }

    /**
     * Set Account Scheme Category Details.
     * 
     * @param accountEntityType
     * @param accountEntityDetails
     */
    private void setAccountSchemeCategoryDetails(Account accountRequestDetailsType, AccountDetails accountEntityDetails) {
        if (accountEntityDetails.getSchemeCategory() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Account Scheme Category Details");
            SchemeIdentifierType schemeIdentifierType = new SchemeIdentifierType();
            schemeIdentifierType.setName(accountEntityDetails.getScheme().getSchemeName());
            SchemeCategoryIdentifierType schemeCategoryIdentifierType = new SchemeCategoryIdentifierType();
            if (accountEntityDetails.getSchemeCategory().getSchemeCategoryId() != null) {
                schemeCategoryIdentifierType.setId(Long.parseLong(accountEntityDetails.getSchemeCategory().getSchemeCategoryId()));
            }
            schemeCategoryIdentifierType.setName(accountEntityDetails.getSchemeCategory().getSchemeCategoryName());
            schemeCategoryIdentifierType.setScheme(schemeIdentifierType);
            accountRequestDetailsType.setSchemeCategory(schemeCategoryIdentifierType);
        }
    }

    /**
     * Set Account Marketing Campaign Details.
     * 
     * @param accountEntityType
     * @param accountEntityDetails
     */
    private void setAccountMarketingCampaignDetails(Account accountRequestDetailsType, AccountDetails accountEntityDetails) {
        if (accountEntityDetails.getMarketingCampaign() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Account Marketing Campaign Details");
            MarketingCampaignIdentifierType marketingCampaignIdentifierType = new MarketingCampaignIdentifierType();
            marketingCampaignIdentifierType.setCode(accountEntityDetails.getMarketingCampaign().getMarketingCampaignCode());
            marketingCampaignIdentifierType.setName(accountEntityDetails.getMarketingCampaign().getMarketingCampaignName());
            accountRequestDetailsType.setMarketingCampaign(marketingCampaignIdentifierType);
        }
    }

    /**
     * Set Account Details.
     * 
     * @param accountEntityType
     * @param accountEntityDetails
     * @throws SILException
     */
    private void setAccountDetails(Account accountRequestDetailsType, AccountDetails accountEntityDetails) throws SILException {
        if (accountEntityDetails.getAccountDetails() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Account Details");
            AccountEntityType.AccountDetail accountDetail = new AccountEntityType.AccountDetail();
            this.setAccountDetailDates(accountEntityDetails, accountDetail);
            accountDetail.setPreventWithdrawal(Boolean.parseBoolean(accountEntityDetails.getAccountDetails().getPreventWithdrawal()));
            accountDetail.setStaff(Boolean.parseBoolean(accountEntityDetails.getAccountDetails().getStaff()));
            if (accountEntityDetails.getAccountDetails().getStatusCode() != null) {
                accountDetail
                        .setStatusCode(accountApplicationUtil.createCodeIdentifierType(accountEntityDetails.getAccountDetails().getStatusCode()));
            }
            if (accountEntityDetails.getAccountDetails().getRebalancingBean() != null) {
                AccountDetailType.IncludeInRebalancing includeInRebalancing = new AccountDetailType.IncludeInRebalancing();
                RebalancingBean rebalancingBean = accountEntityDetails.getAccountDetails().getRebalancingBean();
                this.setAccountRebalancingDetails(rebalancingBean, includeInRebalancing);
                accountDetail.setIncludeInRebalancing(includeInRebalancing);
            }
            if (accountEntityDetails.getAccountDetails().getOpenReason() != null) {
                accountDetail
                        .setOpenReason(accountApplicationUtil.createCodeIdentifierType(accountEntityDetails.getAccountDetails().getOpenReason()));
            }
            accountRequestDetailsType.setAccountDetail(accountDetail);
        }
    }

    /**
     * Set Account Detail Dates.
     * 
     * @param accountEntityDetails
     * @param accountDetail
     * @throws SILException
     */
    private void setAccountDetailDates(AccountDetails accountEntityDetails, AccountEntityType.AccountDetail accountDetail) throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Account Detail Dates");
        if (accountEntityDetails.getAccountDetails().getCommencementDate() != null) {
            accountDetail.setCommencementDate(SILUtil.convertStringToXMLGregorianCalendar(accountEntityDetails.getAccountDetails()
                    .getCommencementDate(), CommonConstants.DATE_FORMAT));
        }
        accountDetail.setAccountDesignation(accountEntityDetails.getAccountDetails().getAccountDesignation());
        if (accountEntityDetails.getAccountDetails().getDateJoinedParticipant() != null) {
            accountDetail.setDateJoinedParticipant(SILUtil.convertStringToXMLGregorianCalendar(accountEntityDetails.getAccountDetails()
                    .getDateJoinedParticipant(), CommonConstants.DATE_FORMAT));
        }
        if (accountEntityDetails.getAccountDetails().getEligibleServiceDate() != null) {
            accountDetail.setEligibleServiceDate(SILUtil.convertStringToXMLGregorianCalendar(accountEntityDetails.getAccountDetails()
                    .getEligibleServiceDate(), CommonConstants.DATE_FORMAT));
        }
    }

    /**
     * Set Account External Reference Details.
     * 
     * @param accountEntityType
     * @param externalReferenceTypeList
     */
    private void setAccountExternalReferenceDetails(Account accountRequestDetailsType,
            List<AccountExternalReferenceDetails> externalReferenceTypeList) {
        if (externalReferenceTypeList != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Account External Reference Details");
            List<ExternalRefType> externalReferenceList = accountRequestDetailsType.getExternalReference();
            for (AccountExternalReferenceDetails externalReferenceType : externalReferenceTypeList) {
                ExternalRefType externalRefType = new ExternalRefType();
                externalRefType.setReference(externalReferenceType.getExternalReferenceType());
                externalRefType.setReferenceCode(externalReferenceType.getExternalReferenceCode());
                externalReferenceList.add(externalRefType);
            }
        }
    }

    /**
     * Set Account Advisor Group Details.
     * 
     * @param accountEntityType
     * @param advisorGroupList
     */
    private void setAccountAdvisorGroupDetails(Account accountRequestDetailsType, List<AccountAdvisorDetails> advisorGroupList) {
        if (advisorGroupList != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Account Advisor Group Details");
            List<AdvisorGroupType> advisorGroupTypeList = accountRequestDetailsType.getAdvisorGroup();
            for (AccountAdvisorDetails advisorGroup : advisorGroupList) {
                RelationshipTypeIdentifierType relationshipType = new RelationshipTypeIdentifierType();
                relationshipType.setCode(advisorGroup.getRelationshipCode());
                relationshipType.setName(advisorGroup.getRelationshipName());
                AdvisorGroupType advisorGroupType = new AdvisorGroupType();
                advisorGroupType.setRelationshipType(relationshipType);
                this.setAccountAdvisorSplitTypeDetails(advisorGroup, advisorGroupType);
                advisorGroupTypeList.add(advisorGroupType);
            }
        }
    }

    /**
     * Set Account Advisor Split Type Details.
     * 
     * @param clientAdvisorGroupType
     * @param advisorGroupType
     */
    private void setAccountAdvisorSplitTypeDetails(AccountAdvisorDetails advisorGroupDetails, AdvisorGroupType advisorGroupType) {
        if (advisorGroupDetails.getAdvisorSplit() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Account Advisor Split Type Details");
            List<AdvisorSplitDetails> advisorSplitDetailsList = advisorGroupDetails.getAdvisorSplit();
            List<AdvisorSplitType> advisorSplitTypeList = advisorGroupType.getAdvisorSplit();
            for (AdvisorSplitDetails advisorSplitDetails : advisorSplitDetailsList) {
                AdvisorSplitType.Advisor advisorSplit = new AdvisorSplitType.Advisor();
                advisorSplit.setAdvisorNumber(advisorSplitDetails.getAdvisorNumber());
                AdvisorSplitType advisorSplitType = new AdvisorSplitType();
                if (advisorSplitDetails.getAdvisorClientId() != null) {
                    advisorSplit.setClientId(Long.parseLong(advisorSplitDetails.getAdvisorClientId()));
                }
                if (advisorSplitDetails.getPercentageSplit() != null) {
                    double percentSplit = Double.parseDouble(advisorSplitDetails.getPercentageSplit());
                    advisorSplitType.setPercentageSplit(BigDecimal.valueOf(percentSplit));
                }
                advisorSplitType.setPrimary(Boolean.parseBoolean(advisorSplitDetails.getPrimaryFlag()));
                advisorSplitType.setAdvisor(advisorSplit);
                advisorSplitTypeList.add(advisorSplitType);
            }
        }
    }

    /**
     * Set Account Investment Profile Details.
     * 
     * @param accountRequestDetailsType
     * @param investmentProfileList
     */
    private void setAccountInvestmentProfileDetails(Account accountRequestDetailsType,
            List<InvestmentProfileDetails> investmentProfileList) {
        if (investmentProfileList != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Account Investment Profile Details");
            List<InvestmentProfileType> investmentProfileTypeList = accountRequestDetailsType.getInvestmentProfile();
            for (InvestmentProfileDetails investmentProfile : investmentProfileList) {
                this.setInvestmentProfileDetails(investmentProfile, investmentProfileTypeList);
            }
        }
    }

    /**
     * Set Investment Profile Details.
     * 
     * @param investmentProfile
     * @param investmentProfileTypeList
     */
    private void setInvestmentProfileDetails(InvestmentProfileDetails investmentProfile, List<InvestmentProfileType> investmentProfileTypeList) {
        if (investmentProfile != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Investment Profile Type Details");
            InvestmentProfileType investmentProfileType = new InvestmentProfileType();
            InvestmentProfileType.AccountProfileLink accountProfileLink = new InvestmentProfileType.AccountProfileLink();
            this.setProfileFunctionDetails(accountProfileLink, investmentProfile);
            InvestmentProfileType.AccountProfileLink.Profile profile = new InvestmentProfileType.AccountProfileLink.Profile();
            this.setProfileDetails(profile, investmentProfile.getProfileDetails());
            this.setPatternTemplateDetails(accountProfileLink, profile, investmentProfile.getProfileDetails().getPatternTemplateDetails());
            this.setPatternMethodCodeDetails(accountProfileLink, investmentProfile);
            this.setFundDetails(accountProfileLink, investmentProfile);
            investmentProfileType.setAccountProfileLink(accountProfileLink);
            investmentProfileTypeList.add(investmentProfileType);
        }
    }

    /**
     * Set Profile Function Details.
     * 
     * @param accountProfileLink
     * @param accountProfileLinkDetails
     */
    private void setProfileFunctionDetails(InvestmentProfileType.AccountProfileLink accountProfileLink, InvestmentProfileDetails investmentProfile) {
        if (investmentProfile.getProfileFunctionDetails() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Profile Function Type Details");
            ProfileFunctionIdentifierType profileFunctionIdentifier = new ProfileFunctionIdentifierType();
            profileFunctionIdentifier.setName(investmentProfile.getProfileFunctionDetails().getName());
            accountProfileLink.setProfileFunctionIdentifier(profileFunctionIdentifier);
        }
    }

    /**
     * Set Profile Details.
     * 
     * @param profile
     * @param profileDetails
     */
    private void setProfileDetails(InvestmentProfileType.AccountProfileLink.Profile profile, ProfileDetails profileDetails) {
        if (profileDetails != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Profile Details");
            profile.setBespokeNew(Boolean.parseBoolean(profileDetails.getBespoke()));
        }
    }

    /**
     * Set Pattern Template Details.
     * 
     * @param accountProfileLink
     * @param profile
     * @param patternTemplateDetails
     */
    private void setPatternTemplateDetails(InvestmentProfileType.AccountProfileLink accountProfileLink,
            InvestmentProfileType.AccountProfileLink.Profile profile, PatternTemplateDetails patternTemplateDetails) {
        if (patternTemplateDetails != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Pattern Template Details");
            PatternTemplateIdentifierType patternTemplateIdentifierType = new PatternTemplateIdentifierType();
            if (patternTemplateDetails.getId() != null) {
                patternTemplateIdentifierType.setId(Long.parseLong(patternTemplateDetails.getId()));
            }
            patternTemplateIdentifierType.setName(patternTemplateDetails.getName());
            profile.setPatternTemplate(patternTemplateIdentifierType);
            accountProfileLink.setProfile(profile);
        }
    }

    /**
     * Set Pattern Method Code Details.
     * 
     * @param accountProfileLink
     * @param investmentProfileDetails
     */
    private void setPatternMethodCodeDetails(InvestmentProfileType.AccountProfileLink accountProfileLink,
            InvestmentProfileDetails investmentProfileDetails) {
        if (investmentProfileDetails.getPatternMethod() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Pattern Method Code Details");
            CodeIdentifierType codeIdentifierType = new CodeIdentifierType();
            codeIdentifierType.setCode(investmentProfileDetails.getPatternMethod().getCode());
            codeIdentifierType.setCodeType(investmentProfileDetails.getPatternMethod().getCodeType());
            accountProfileLink.setPatternMethodCode(codeIdentifierType);
        }
    }

    /**
     * Set Fund Details.
     * 
     * @param accountProfileLink
     * @param investmentProfile
     */
    private void setFundDetails(InvestmentProfileType.AccountProfileLink accountProfileLink, InvestmentProfileDetails investmentProfile) {
        if (investmentProfile.getFundDetails() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Fund Details");
            List<InvestmentProfileType.AccountProfileLink.Fund> fundList = accountProfileLink.getFund();
            List<FundDetails> fundDetailsList = investmentProfile.getFundDetails();
            for (FundDetails fundDetails : fundDetailsList) {
                InvestmentProfileType.AccountProfileLink.Fund fund = new InvestmentProfileType.AccountProfileLink.Fund();
                fund.setSplitPercent(new BigDecimal(fundDetails.getSplitPercent()));
                this.setFundIdentifierDetails(fundDetails, fund);
                fundList.add(fund);
            }
        }
    }

    /**
     * Set Fund Identifier Details.
     * 
     * @param fundDetails
     * @param fund
     */
    private void setFundIdentifierDetails(FundDetails fundDetails, InvestmentProfileType.AccountProfileLink.Fund fund) {
        if (fundDetails.getFundIdentifier() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Fund Identifier Details");
            FundIdentifierDetails fundIdentifierDetails = fundDetails.getFundIdentifier();
            FundIdentifierType fundIdentifierType = new FundIdentifierType();
            fundIdentifierType.setId(Long.parseLong(fundIdentifierDetails.getId()));
            fund.setFundIdentifier(fundIdentifierType);
        }
    }

    /**
     * Set Account Expense Line Details.
     * 
     * @param accountRequestDetailsType
     * @param expenseLineDetailsList
     */
    private void setAccountExpenseLineDetails(Account accountRequestDetailsType, List<ExpenseLineDetails> expenseLineDetailsList) {
        if (expenseLineDetailsList != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Account Expense Line Details");
            List<ExpenseLineType> expenseLineTypeList = accountRequestDetailsType.getExpenseLine();
            for (ExpenseLineDetails expenseLineDetails : expenseLineDetailsList) {
                this.setExpenseLineDetails(expenseLineDetails, expenseLineTypeList);
            }
        }
    }

    /**
     * Set Expense Line Details.
     * 
     * @param expenseLineDetails
     * @param expenseLineTypeList
     */
    private void setExpenseLineDetails(ExpenseLineDetails expenseLineDetails, List<ExpenseLineType> expenseLineTypeList) {
        if (expenseLineDetails != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Expense Line Details");
            ExpenseLineType expenseLineType = new ExpenseLineType();
            if (expenseLineDetails.getId() != null) {
                expenseLineType.setId(Long.parseLong(expenseLineDetails.getId()));
            }
            expenseLineType.setOverride(Boolean.parseBoolean(expenseLineDetails.getOverride()));
            if (expenseLineDetails.getParameters() != null) {
                List<ExpenseParameterDetails> expParamDetailsList = expenseLineDetails.getParameters();
                this.setExpenseParameterDetails(expenseLineType, expParamDetailsList);
            }
            expenseLineTypeList.add(expenseLineType);
        }
    }

    /**
     * Set Expense Parameter Details.
     * 
     * @param expenseLineType
     * @param expParamDetailsList
     */
    private void setExpenseParameterDetails(ExpenseLineType expenseLineType, List<ExpenseParameterDetails> expParamDetailsList) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Expense Parameter Details");
        List<ExpenseParameterType> expenseParameterTypeList = expenseLineType.getParameter();
        for (ExpenseParameterDetails expenseParameterDetails : expParamDetailsList) {
            ExpenseParameterType expenseParameterType = new ExpenseParameterType();
            if (expenseParameterDetails.getAmount() != null) {
                expenseParameterType.setAmount(new BigDecimal(expenseParameterDetails.getAmount()));
            }
            if (expenseParameterDetails.getPercentage() != null) {
                expenseParameterType.setPercentage(new BigDecimal(expenseParameterDetails.getPercentage()));
            }
            expenseParameterTypeList.add(expenseParameterType);
        }
    }

    /**
     * Set Account Regular Plan Details.
     * 
     * @param accountRequestDetailsType
     * @param regularContributionPlan
     * @throws SILException
     */
    private void setAccountRegularPlanDetails(Account accountRequestDetailsType,
            List<RegularPlanDetails> regularContributionPlanList) throws SILException {
        if (regularContributionPlanList != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Account Regular Plan Details");
            List<RegularPlanType> regularPlanTypeList = accountRequestDetailsType.getRegularContributionPlan();
            for (RegularPlanDetails regularPlan : regularContributionPlanList) {
                RegularPlanDetailsRequestUtil regularPlanDetailsRequestUtil = new RegularPlanDetailsRequestUtil();
                regularPlanDetailsRequestUtil.setRegularPlanDetails(regularPlan, regularPlanTypeList);
            }
        }
    }

    /**
     * Set PensionPaymentDetails.
     * 
     * @param accountRequestDetailsType
     * @param pensionPaymentDetails
     * @throws SILException
     */
    private void setPensionPaymentDetails(Account accountRequestDetailsType, PensionPaymentDetails pensionPaymentDetails)
            throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "setPensionPaymentDetails");
        PensionPaymentDetailsRequestUtil pensionPaymentDetailsUtil = new PensionPaymentDetailsRequestUtil();
        if (pensionPaymentDetails != null) {
            pensionPaymentDetailsUtil.setPensionPayment(accountRequestDetailsType, pensionPaymentDetails);
        }

    }

    /**
     * Set AccountTaxDetails
     * 
     * @param accountRequestDetailsType
     * @param accountTaxDetail
     */
    private void setAccountTaxDetails(Account accountRequestDetailsType, AccountTaxDetail accountTaxDetail) {
        AccountTaxType accountTaxType = new AccountTaxType();
        CodeIdentifierType codeIdentifierType = new CodeIdentifierType();
        if (accountTaxDetail != null && accountTaxDetail.getTaxScale() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "setAccountTaxDetails");
            CodeIdentifierDetails codeIdentifierDetails = accountTaxDetail.getTaxScale();
            codeIdentifierType.setCode(codeIdentifierDetails.getCode());
            codeIdentifierType.setCodeType(codeIdentifierDetails.getCodeType());
            accountTaxType.setTaxScale(codeIdentifierType);
            accountRequestDetailsType.setAccountTaxDetail(accountTaxType);
        }
    }

    /**
     * Set PensionPaymentSplit.
     * 
     * @param accountRequestDetailsType
     * @param pensionPaymentSplitDetails
     * @throws SILException
     */
    private void setPensionPaymentSplit(Account accountRequestDetailsType, AccountDetails accountDetails) throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "setPensionPaymentSplit");
        PensionPaymentDetailsRequestUtil pensionPaymentDetailsUtil = new PensionPaymentDetailsRequestUtil();
        if (accountDetails != null && accountDetails.getPensionPaymentSplitDetails() != null) {
            List<PensionPaymentSplitType> pensionPaymentSplitTypeList = accountRequestDetailsType.getPensionPaymentSplit();
            for (PensionPaymentSplitDetails PensionPaymentSplitDetails : accountDetails.getPensionPaymentSplitDetails()) {
                pensionPaymentDetailsUtil.setPensionPaymentSplitDetails(PensionPaymentSplitDetails, pensionPaymentSplitTypeList, accountDetails);
            }
        }
    }

    /**
     * Adds the beneficiary related data to the request.
     * 
     * @param accountRequestDetailsTypeof type AccountRequestDetailsType
     * @param accountDetails of type AccountDetail
     * @throws SILException
     */
    private void addBeneficiaryDetails(Account accountRequestDetailsType, AccountDetails accountDetails) throws SILException {
        if (accountDetails.getAccountIdentifier() != null) {
            this.setAccountNumberDetails(accountRequestDetailsType, accountDetails.getAccountIdentifier());
        }
        if (accountDetails.getBeneficiaries() != null) {
            this.setAccountBeneficiaryDetails(accountRequestDetailsType, accountDetails.getBeneficiaries());
        }
    }

    /**
     * Sets the account number in Sonata's Request object.
     * 
     * @param accountRequestDetailsType of type AccountRequestDetailsType
     * @param inboundAccountDetails of type AccountIdentifierDetails
     */
    private void setAccountNumberDetails(Account accountRequestDetailsType, AccountIdentifierDetails inboundAccountDetails) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Account Number Details");
        if (inboundAccountDetails.getAccountNumber() != null && inboundAccountDetails.getAccountNumber().getAccountNumber() != null) {
            AccountNumber accountNumber = new AccountNumber();
            accountNumber.setAccountNo(inboundAccountDetails.getAccountNumber().getAccountNumber());
            AccountIdentifierType accountIdentifierType = new AccountIdentifierType();
            accountIdentifierType.setAccountNumber(accountNumber);
            accountRequestDetailsType.setAccount(accountIdentifierType);
        }
    }

    /**
     * Sets the account beneficiaries in Sonata's Request object.
     * 
     * @param outboundAccountDetails of type AccountRequestDetailsType
     * @param inboundBeneficiaryList of type List&lt;BeneficiaryDetails&gt;
     * @throws SILException
     */
    private void setAccountBeneficiaryDetails(Account outboundAccountDetails, List<BeneficiaryBean> inboundBeneficiaryList)
            throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Account Beneficiary Details");
        if (inboundBeneficiaryList != null) {
            List<BeneficiaryType> outboundBeneficiaryList = outboundAccountDetails.getBeneficiary();
            for (BeneficiaryBean inboundBeneficiary : inboundBeneficiaryList) {
                outboundBeneficiaryList.add(new AddBeneficiaryDetailsRequestUtil(inboundBeneficiary).createOutboundBeneficiary());
            }
        }
    }

    /**
     * Set Account Rebalancing Details.
     * 
     * @param rebalancingBean
     * @return
     * @throws SILException
     */
    private void setAccountRebalancingDetails(RebalancingBean rebalancingBean, AccountDetailType.IncludeInRebalancing includeInRebalancing)
            throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Account Rebalancing Details");
        XMLGregorianCalendar nextRebalanceDate = null;
        if (rebalancingBean.getRebalancingFrequencyBean() != null) {
            RebalancingFrequencyBean rebalancingFrequencyBean = rebalancingBean.getRebalancingFrequencyBean();
            nextRebalanceDate = SILUtil.calculateNextRebalanceDate(rebalancingFrequencyBean.getName());
            this.setRebalancingFrequencyDetails(rebalancingFrequencyBean, includeInRebalancing);
        }
        if (nextRebalanceDate != null) {
            includeInRebalancing.setNextRebalanceDate(nextRebalanceDate);
        }
        includeInRebalancing.setRebalanceImmediately(Boolean.parseBoolean(rebalancingBean.getRebalanceImmediately()));
        includeInRebalancing.setIncludeInRebalance(Boolean.parseBoolean(rebalancingBean.getIncludeInRebalance()));
    }

    /**
     * Set Account Rebalancing Frequency Details.
     * 
     * @param rebalancingFrequencyBean
     * @param includeInRebalancing
     */
    private void setRebalancingFrequencyDetails(RebalancingFrequencyBean rebalancingFrequencyBean,
            AccountDetailType.IncludeInRebalancing includeInRebalancing) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Account Rebalancing Frequency Details");
        FrequencyIdentifierType rebalancingFrequency = new FrequencyIdentifierType();
        rebalancingFrequency.setName(rebalancingFrequencyBean.getName());
        rebalancingFrequency.setFreqSetCode(rebalancingFrequencyBean.getFreqSetCode());
        includeInRebalancing.setRebalancingFrequency(rebalancingFrequency);
    }

    /**
     * Set Account Generic Variable Details.
     * 
     * @param accountRequestDetailsType
     * @param accountDetails
     * @throws SILException
     */
    private void setGenericVariableDetails(Account accountRequestDetailsType, AccountDetails accountDetails) throws SILException {
        if (accountDetails.getGenericVariables() != null && accountDetails.getGenericVariables().size() > 0) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Account Generic Variable Details");
            List<GenericVariableDetails> genericVariableDetails = accountDetails.getGenericVariables();
            List<GenericVariableType> genericVariableTypeList = accountRequestDetailsType.getGenericVariable();
            for (GenericVariableDetails genericVariable : genericVariableDetails) {
                GenericVariableType genericVariableType = new GenericVariableType();
                if (genericVariable.getCode() != null) {
                    genericVariableType.setCode(genericVariable.getCode());
                    setValueDetails(genericVariable, genericVariableType);
                }
                genericVariableTypeList.add(genericVariableType);
            }
        }
    }

    /**
     * Set Account Generic Variable Value Details.
     * 
     * @param genericVariableDetails
     * @param genericVariableType
     * @throws SILException
     */
    private void setValueDetails(GenericVariableDetails genericVariableDetails, GenericVariableType genericVariableType) throws SILException {
        GenericVariableType.Value value = new GenericVariableType.Value();
        if (genericVariableDetails.getValues() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Account Generic Variable Value Details");
            ValueDetails valueDetails = genericVariableDetails.getValues();
            if (valueDetails.getCode() != null) {
                CodeIdentifierDetails codeIdentifierDetails = valueDetails.getCode();
                value.setCode(accountApplicationUtil.createCodeIdentifierType(codeIdentifierDetails));
            }
            setValues(valueDetails, value);
            genericVariableType.setValue(value);
        }
    }

    /**
     * Setting Account Generic Variable Values.
     * 
     * @param valueDetails
     * @param value
     * @throws SILException
     */
    private void setValues(ValueDetails valueDetails, GenericVariableType.Value value) throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Account Generic Variable Values");
        if (valueDetails.getDecimal() != null) {
            value.setDecimal(new BigDecimal(valueDetails.getDecimal()));
        }
        if (valueDetails.getInteger() != null) {
            value.setInteger(Integer.valueOf(valueDetails.getInteger()));
        }
        if (valueDetails.getDateTime() != null) {
            value.setDatetime(SILUtil.convertStringToXMLGregorianCalendar(valueDetails.getDateTime(), CommonConstants.DATE_FORMAT));
        }
        if (valueDetails.getChecked() != null) {
            value.setChecked(valueDetails.getChecked());
        }
        if (valueDetails.getString() != null) {
            value.setString(valueDetails.getString());
        }
    }

    /**
     * Set Account Employment Details.
     * 
     * @param accountRequestDetailsType
     * @param accountDetails
     * @throws SILException
     */
    private void setAccountEmploymentDetails(Account accountRequestDetailsType, AccountDetails accountDetails) throws SILException {
        if (accountDetails.getEmploymentDetails() != null && accountDetails.getEmploymentDetails().size() > 0) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Account Employment Details");
            List<EmploymentDetails> employmentDetailsList = accountDetails.getEmploymentDetails();
            List<EmploymentCreateType> employmentList = accountRequestDetailsType.getEmployment();
            for (EmploymentDetails employmentDetails : employmentDetailsList) {
                EmploymentCreateType employmentCreateType = new EmploymentCreateType();
                setEmploymentDetails(employmentDetails, employmentCreateType);
                employmentList.add(employmentCreateType);
            }
        }
    }

    /**
     * Set Employment Details.
     * 
     * @param employmentDetails
     * @param employmentCreateType
     * @throws SILException
     */
    private void setEmploymentDetails(EmploymentDetails employmentDetails, EmploymentCreateType employmentCreateType) throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Employment Details");
        if (employmentDetails.getStartDate() != null) {
            employmentCreateType.setStartDate(SILUtil.convertStringToXMLGregorianCalendar(employmentDetails.getStartDate(),
                    CommonConstants.DATE_FORMAT));
        }
        if (employmentDetails.getEmploymentType() != null) {
            employmentCreateType.setEmploymentType(accountApplicationUtil.createCodeIdentifierType(employmentDetails.getEmploymentType()));
        }
        if (employmentDetails.getPrimaryEmployer() != null) {
            employmentCreateType.setPrimaryEmployer(Boolean.valueOf(employmentDetails.getPrimaryEmployer()));
        }
        if (employmentDetails.getEmploymentStatus() != null) {
            employmentCreateType.setEmploymentStatus(accountApplicationUtil.createCodeIdentifierType(employmentDetails.getEmploymentStatus()));
        }
        setEmploymentDetailsParam(employmentDetails, employmentCreateType);
    }

    /**
     * Set Employment Details.
     * 
     * @param employmentDetails
     * @param employmentCreateType
     */
    private void setEmploymentDetailsParam(EmploymentDetails employmentDetails, EmploymentCreateType employmentCreateType) {
        if (employmentDetails.getPayrollId() != null) {
            employmentCreateType.setPayrollId(employmentDetails.getPayrollId());
        }
        if (employmentDetails.getSalary() != null) {
            employmentCreateType.setSalary(new BigDecimal(employmentDetails.getSalary()));
        }
        if (employmentDetails.getEmployerName() != null || employmentDetails.getEmployerNumber() != null) {
            SchemeLocationIdentifierType employer = new SchemeLocationIdentifierType();
            if (employmentDetails.getEmployerName() != null) {
                employer.setName(employmentDetails.getEmployerName());
            }
            if (employmentDetails.getEmployerNumber() != null) {
                employer.setNumber(employmentDetails.getEmployerNumber());
            }
            employmentCreateType.setEmployer(employer);
        }
    }
}
