////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.util;

import java.math.BigDecimal;

import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.ClientIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.RelationshipTypeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.BeneficiaryType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.ClientAccountRelationshipIdentifierType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.applicationservice.ApplicationServiceConstants;
import com.suncorp.ssp.service.integration.applicationservice.bean.BeneficiaryBean;

/**
 * The class {@code AddBeneficiaryDetailsRequestUtil} is used as a util class for preparing CreateAccountApplication service Beneficiary Details.
 * 
 * @author U386868
 * @since 10/02/2016
 * @version 1.0
 */
public class AddBeneficiaryDetailsRequestUtil {
    private String cName = "AddBeneficiaryDetailsRequestUtil";
    private AccountApplicationUtil accountApplicationUtil = new AccountApplicationUtil();
    private BeneficiaryType outboundBeneficiary = null;
    private BeneficiaryBean inboundBeneficiary = null;

    public AddBeneficiaryDetailsRequestUtil() {

    }

    public AddBeneficiaryDetailsRequestUtil(BeneficiaryBean inboundBeneficiary) {
        this.inboundBeneficiary = inboundBeneficiary;
        this.outboundBeneficiary = new BeneficiaryType();
    }

    /**
     * Add a new instance of BeneficiaryType to the outboundBeneficiaryList, with necessary values set.
     * 
     * @param outboundBeneficiaryList of type List&lt;BeneficiaryType&gt;
     * @param inboundBeneficiaryList of type List&lt;BeneficiaryBean&gt;
     * @throws SILException
     */
    public BeneficiaryType createOutboundBeneficiary() throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, cName, "Entering createOutboundBeneficiary()");
        if (this.inboundBeneficiary.getClientAccountRelationship() != null) {
            this.outboundBeneficiary.setClientAccountRelationship(createClientAccountRelationshipIdentifierType());
        }
        if (this.inboundBeneficiary.getCategory() != null) {
            this.outboundBeneficiary.setCategory(accountApplicationUtil.createCodeIdentifierType(this.inboundBeneficiary.getCategory()));
        }
        if (this.inboundBeneficiary.getType() != null) {
            this.outboundBeneficiary.setType(accountApplicationUtil.createCodeIdentifierType(this.inboundBeneficiary.getType()));
        }
        if (this.inboundBeneficiary.getRelationship() != null) {
            this.outboundBeneficiary.setRelationship(accountApplicationUtil.createCodeIdentifierType(this.inboundBeneficiary.getRelationship()));
        }
        setBeneficiaryAllocationDetails();
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, cName, "Exiting createOutboundBeneficiary()");
        return outboundBeneficiary;
    }

    /**
     * Returns a new instance of ClientAccountRelationshipIdentifierType, with necessary values set.
     * 
     * @return clientAccountRelationshipIdentifierType of type ClientAccountRelationshipIdentifierType
     * @throws SILException
     */
    private ClientAccountRelationshipIdentifierType createClientAccountRelationshipIdentifierType() throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, cName, "Entering createClientAccountRelationshipIdentifierType()");
        ClientAccountRelationshipIdentifierType clientAccountRelationshipIdentifierType = new ClientAccountRelationshipIdentifierType();
        if (this.inboundBeneficiary.getClientAccountRelationship().getClient() != null) {
            clientAccountRelationshipIdentifierType.setClient(createClientIdentifierType());
        }
        if (this.inboundBeneficiary.getClientAccountRelationship().getRelationshipType() != null) {
            clientAccountRelationshipIdentifierType.setRelationshipType(createClientAccountRelationshipType());
        }
        if (this.inboundBeneficiary.getClientAccountRelationship().getPrimaryFlag() != null) {
            clientAccountRelationshipIdentifierType.setPrimary(Boolean.parseBoolean(this.inboundBeneficiary.getClientAccountRelationship()
                    .getPrimaryFlag()));
        }
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, cName, "Exiting createClientAccountRelationshipIdentifierType()");
        return clientAccountRelationshipIdentifierType;
    }

    /**
     * Returns a new instance of ClientAccountRelationshipIdentifierType, with necessary values set.
     * 
     * @param inboundClientBean of type ClientBean
     * @return clientIdentifierType of type ClientIdentifierType
     */
    private ClientIdentifierType createClientIdentifierType() {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, cName, "Entering createClientIdentifierType()");
        ClientIdentifierType clientIdentifierType = new ClientIdentifierType();
        if (this.inboundBeneficiary.getClientAccountRelationship().getClient().getClientPointer() != null) {
            clientIdentifierType.setClientPointer(accountApplicationUtil.createClientPointer(this.inboundBeneficiary.getClientAccountRelationship()
                    .getClient().getClientPointer()));
        }
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, cName, "Exiting createClientIdentifierType()");
        return clientIdentifierType;
    }

    /**
     * Returns a new instance of RelationshipTypeIdentifierType, with necessary values set.
     * 
     * @return outboundRelationshipTypeIdentifierType of type RelationshipTypeIdentifierType
     */
    private RelationshipTypeIdentifierType createClientAccountRelationshipType() {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, cName, "Entering createClientAccountRelationshipType()");
        RelationshipTypeIdentifierType outboundRelationshipTypeIdentifierType = new RelationshipTypeIdentifierType();
        if (this.inboundBeneficiary.getClientAccountRelationship().getRelationshipType().getCode() != null) {
            outboundRelationshipTypeIdentifierType.setCode(this.inboundBeneficiary.getClientAccountRelationship().getRelationshipType().getCode());
        }
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, cName, "Exiting createClientAccountRelationshipType()");
        return outboundRelationshipTypeIdentifierType;
    }

    /**
     * Sets the adviceReceived & allocation properties of the beneficiary.
     * 
     * @throws SILException
     * @throws DatatypeConfigurationException
     */
    private void setBeneficiaryAllocationDetails() throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, cName, "Entering setBeneficiaryAllocationDetails()");
        if (this.inboundBeneficiary.getAdviceReceived() != null) {
            this.outboundBeneficiary.setAdviceReceived(Boolean.parseBoolean(this.inboundBeneficiary.getAdviceReceived()));
        }
        if (this.inboundBeneficiary.getSplitPercentage() != null) {
            try {
                this.outboundBeneficiary.setSplitPercentage(new BigDecimal(this.inboundBeneficiary.getSplitPercentage()));
            } catch (NumberFormatException nfe) {
                SILLogger.error(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, cName, SILUtil.getReqExMsg(nfe));
                throw new SILException(ApplicationServiceConstants.ADD_BENE_INVALID_ALLOCATION_MSG);
            }
        }
        setBeneficiaryDates();
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, cName, "Exiting setBeneficiaryAllocationDetails()");
    }

    /**
     * Sets the endDate and dateNominationSigned properties of the beneficiary.
     * 
     * @throws SILException
     */
    private void setBeneficiaryDates() throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, cName, "Entering setBeneficiaryDates()");
        if (this.inboundBeneficiary.getEndDate() != null) {
            this.outboundBeneficiary.setEndDate(SILUtil.convertStringToXMLGregorianCalendar(this.inboundBeneficiary.getEndDate(),
                    CommonConstants.DATE_FORMAT));
        }
        if (this.inboundBeneficiary.getDateNominationSigned() != null) {
            this.outboundBeneficiary.setDateNominationSigned(SILUtil.convertStringToXMLGregorianCalendar(
                    this.inboundBeneficiary.getDateNominationSigned(), CommonConstants.DATE_FORMAT));
        }
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, cName, "Exiting setBeneficiaryDates()");
    }
}
