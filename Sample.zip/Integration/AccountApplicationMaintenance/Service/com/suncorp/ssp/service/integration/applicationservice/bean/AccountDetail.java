////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import javax.xml.bind.annotation.XmlElement;


/**
 * The class {@code AccountDetail} is a java bean consisting of properties related to account additional details.
 * 
 * @author U383847
 * @since 05/01/2016
 * @version 1.0
 */
public class AccountDetail {
    private String commencementDate;
    private String accountDesignation;
    private String dateJoinedParticipant;
    private String eligibleServiceDate;
    private String preventWithdrawal;
    private CodeIdentifierDetails statusCode;
    private RebalancingBean rebalancingBean;
    private CodeIdentifierDetails openReason;
    private String staff;
    
    /**
     * Accessor for property commencementDate.
     * 
     * @return commencementDate of type String
     */
    public String getCommencementDate() {
        return commencementDate;
    }
    
    /**
     * Mutator for property commencementDate.
     * 
     * @param commencementDate of type String
     */
    @XmlElement(name = "commencementDate")
    public void setCommencementDate(String commencementDate) {
        this.commencementDate = commencementDate != null ? commencementDate : "";
    }
    
    /**
     * Accessor for property accountDesignation.
     * 
     * @return accountDesignation of type String
     */
    public String getAccountDesignation() {
        return accountDesignation;
    }
    
    /**
     * Mutator for property accountDesignation.
     * 
     * @param accountDesignation of type String
     */
    @XmlElement(name = "accountDesignation")
    public void setAccountDesignation(String accountDesignation) {
        this.accountDesignation = accountDesignation != null ? accountDesignation : "";
    }
    
    /**
     * Accessor for property dateJoinedParticipant.
     * 
     * @return dateJoinedParticipant of type String
     */
    public String getDateJoinedParticipant() {
        return dateJoinedParticipant;
    }
    
    /**
     * Mutator for property dateJoinedParticipant.
     * 
     * @param dateJoinedParticipant of type String
     */
    @XmlElement(name = "dateJoinedParticipant")
    public void setDateJoinedParticipant(String dateJoinedParticipant) {
        this.dateJoinedParticipant = dateJoinedParticipant != null ? dateJoinedParticipant : "";
    }
    
    /**
     * Accessor for property eligibleServiceDate.
     * 
     * @return eligibleServiceDate of type String
     */
    public String getEligibleServiceDate() {
        return eligibleServiceDate;
    }
    
    /**
     * Mutator for property eligibleServiceDate.
     * 
     * @param eligibleServiceDate of type String
     */
    @XmlElement(name = "eligibleServiceDate")
    public void setEligibleServiceDate(String eligibleServiceDate) {
        this.eligibleServiceDate = eligibleServiceDate != null ? eligibleServiceDate : "";
    }
    
    /**
     * Accessor for property preventWithdrawal.
     * 
     * @return preventWithdrawal of type String
     */
    public String getPreventWithdrawal() {
        return preventWithdrawal;
    }
    
    /**
     * Mutator for property preventWithdrawal.
     * 
     * @param preventWithdrawal of type String
     */
    @XmlElement(name = "preventWithdrawal")
    public void setPreventWithdrawal(String preventWithdrawal) {
        this.preventWithdrawal = preventWithdrawal != null ? preventWithdrawal : "";
    }

    /**
     * Accessor for property statusCode.
     *
     * @return statusCode of type CodeIdentifierDetails
     */
    public CodeIdentifierDetails getStatusCode() {
        return statusCode;
    }

    /**
     * Mutator for property statusCode.
     *
     * @param statusCode of type CodeIdentifierDetails
     */
    @XmlElement(name = "statusCode")
    public void setStatusCode(CodeIdentifierDetails statusCode) {
        this.statusCode = statusCode;
    }

    /**
     * Accessor for property rebalancingBean.
     *
     * @return rebalancingBean of type RebalancingBean
     */
    public RebalancingBean getRebalancingBean() {
        return rebalancingBean;
    }

    /**
     * Mutator for property rebalancingBean.
     *
     * @param rebalancingBean of type RebalancingBean
     */
    @XmlElement(name = "includeRebalancing")
    public void setRebalancingBean(RebalancingBean rebalancingBean) {
        this.rebalancingBean = rebalancingBean;
    }

    /**
     * Accessor for property openReason.
     *
     * @return openReason of type CodeIdentifierDetails
     */
    public CodeIdentifierDetails getOpenReason() {
        return openReason;
    }

    /**
     * Mutator for property openReason.
     *
     * @param openReason of type CodeIdentifierDetails
     */
    @XmlElement(name = "openReason")
    public void setOpenReason(CodeIdentifierDetails openReason) {
        this.openReason = openReason;
    }

    /**
     * Accessor for property staff.
     *
     * @return staff of type String
     */
    public String getStaff() {
        return staff;
    }

    /**
     * Mutator for property staff.
     *
     * @param staff of type String
     */
    @XmlElement(name = "staff")
    public void setStaff(String staff) {
        this.staff = staff;
    }
    
}
