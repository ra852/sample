////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code CompanyDetails} does this.
 *
 * @author U383847
 * @since 10/03/2016
 * @version 1.0
 */
public class CompanyDetails {
    private String abn;
    
    /**
     * Accessor for property abn.
     *
     * @return abn of type String
     */
    public String getAbn() {
        return abn;
    }

    /**
     * Mutator for property abn.
     *
     * @param abn of type String
     */
    @XmlElement(name = "abn")
    public void setAbn(String abn) {
        this.abn = abn;
    } 
}
