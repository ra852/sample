////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code AccountIdentifierDetails} does this.
 * @author U383847
 * @since 03/02/2016
 * @version 1.0
 */
public class AccountIdentifierDetails {
    private String accountId;
    private String accountName;
    private AccountNumberDetails accountNumber;
    private AccountExternalReferenceDetails accountExternalReference;
    private CodeIdentifierDetails accountStatus;
    private AuditDetails audit;
    private GenericReferenceDetails accountPointer;
    private MasterSchemeIdentifierDetails masterScheme;
    
    /**
     * Accessor for property accountId.
     * 
     * @return accountId of type String
     */
    public String getAccountId() {
        return accountId;
    }

    /**
     * Mutator for property accountId.
     * 
     * @return accountId of type String
     */
    @XmlElement(name = "accountId")
    public void setAccountId(String accountId) {
        this.accountId = accountId != null ? accountId : "";
    }

    /**
     * Accessor for property accountName.
     * 
     * @return accountName of type String
     */
    public String getAccountName() {
        return accountName;
    }

    /**
     * Mutator for property accountName.
     * 
     * @return accountName of type String
     */
    @XmlElement(name = "accountName")
    public void setAccountName(String accountName) {
        this.accountName = accountName != null ? accountName : "";
    }

    /**
     * Accessor for property accountNumber.
     * 
     * @return accountNumber of type AccountNumberDetails
     */
    public AccountNumberDetails getAccountNumber() {
        return accountNumber;
    }
    
    /**
     * Mutator for property accountNumber.
     * 
     * @return accountNumber of type AccountNumberDetails
     */
    @XmlElement(name = "accountNumberDetails")
    public void setAccountNumber(AccountNumberDetails accountNumber) {
        this.accountNumber = accountNumber;
    }
    
    /**
     * Accessor for property accountExternalReference.
     * 
     * @return accountExternalReference of type AccountExternalReferenceDetails
     */
    public AccountExternalReferenceDetails getAccountExternalReference() {
        return accountExternalReference;
    }
    
    /**
     * Mutator for property accountExternalReference.
     * 
     * @return accountExternalReference of type AccountExternalReferenceDetails
     */
    @XmlElement(name = "accountExternalReferenceDetails")
    public void setAccountExternalReference(AccountExternalReferenceDetails accountExternalReference) {
        this.accountExternalReference = accountExternalReference;
    }
    
    /**
     * Accessor for property accountStatus.
     * 
     * @return accountStatus of type CodeIdentifierDetails
     */
    public CodeIdentifierDetails getAccountStatus() {
        return accountStatus;
    }

    /**
     * Mutator for property accountStatus.
     * 
     * @return accountStatus of type CodeIdentifierDetails
     */
    @XmlElement(name = "accountStatusDetails")
    public void setAccountStatus(CodeIdentifierDetails accountStatus) {
        this.accountStatus = accountStatus;
    }

    /**
     * Accessor for property audit.
     * 
     * @return audit of type AuditDetails
     */
    public AuditDetails getAudit() {
        return audit;
    }
    
    /**
     * Mutator for property audit.
     * 
     * @return audit of type AuditDetails
     */
    @XmlElement(name = "accountAuditDetails")
    public void setAudit(AuditDetails audit) {
        this.audit = audit;
    }
    
    /**
     * Accessor for property accountPointer.
     * 
     * @return accountPointer of type GenericReferenceDetails
     */
    public GenericReferenceDetails getAccountPointer() {
        return accountPointer;
    }

    /**
     * Mutator for property accountPointer.
     * 
     * @return accountPointer of type GenericReferenceDetails
     */
    @XmlElement(name = "accountPointer")
    public void setAccountPointer(GenericReferenceDetails accountPointer) {
        this.accountPointer = accountPointer;
    }

    /**
     * Accessor for property masterScheme.
     * 
     * @return masterScheme of type MasterSchemeIdentifierDetails
     */
    public MasterSchemeIdentifierDetails getMasterScheme() {
        return masterScheme;
    }

    /**
     * Mutator for property masterScheme.
     * 
     * @return masterScheme of type MasterSchemeIdentifierDetails
     */
    @XmlElement(name = "masterSchemeDetails")
    public void setMasterScheme(MasterSchemeIdentifierDetails masterScheme) {
        this.masterScheme = masterScheme;
    }
}
