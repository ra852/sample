////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code FundExternalReferenceDetails} does this.
 * 
 * @author U383847
 * @since 01/02/2016
 * @version 1.0
 */
public class FundExternalReferenceDetails {
    private String externalReferenceCode;
    private String externalReference;
    
    /**
     * Accessor for property externalReferenceCode.
     * 
     * @return externalReferenceCode of type String
     */
    public String getExternalReferenceCode() {
        return externalReferenceCode;
    }
    
    /**
     * Mutator for property externalReferenceCode.
     * 
     * @return externalReferenceCode of type String
     */
    @XmlElement(name = "fundExternalReferenceCode")
    public void setExternalReferenceCode(String externalReferenceCode) {
        this.externalReferenceCode = externalReferenceCode != null ? externalReferenceCode : "";
    }
    
    /**
     * Accessor for property externalReference.
     * 
     * @return externalReference of type String
     */
    public String getExternalReference() {
        return externalReference;
    }
    
    /**
     * Mutator for property externalReference.
     * 
     * @return externalReference of type String
     */
    @XmlElement(name = "fundExternalReference")
    public void setExternalReference(String externalReference) {
        this.externalReference = externalReference != null ? externalReference : "";
    }    
}
