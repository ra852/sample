////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.util;

import java.util.ArrayList;
import java.util.List;

import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.AdvisorGroupType;
import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.AdvisorSplitType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CodeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.ExpenseGroupIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.ExpenseLineType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.ExternalRefType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.FrequencyIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.GenericVariableType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.PatternTemplateIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.ProfileFunctionIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.RelationshipTypeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.fund.fundgrouptype.FundIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.marketing.marketinggrouptype.MarketingCampaignIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.scheme.schemegrouptype.SchemeCategoryIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.scheme.schemegrouptype.SchemeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountDetailType.IncludeInRebalancing;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountEntityType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountTaxType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.BeneficiaryType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.InvestmentProfileType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.PensionPaymentSplitType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.RegularPlanType;
import com.sonatacentral.service.v30.globaltypes.wrap.product.productgrouptype.ProductIdentifierType;
import com.sonatacentral.service.v30.wrap.application.AccountApplicationResponseType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.applicationservice.ApplicationServiceConstants;
import com.suncorp.ssp.service.integration.applicationservice.bean.AccountAdvisorDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.AccountDetail;
import com.suncorp.ssp.service.integration.applicationservice.bean.AccountDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.AccountExternalReferenceDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.AccountIdentifierDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.AccountProfileLinkDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.AccountTaxDetail;
import com.suncorp.ssp.service.integration.applicationservice.bean.AdvisorSplitDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.BeneficiaryBean;
import com.suncorp.ssp.service.integration.applicationservice.bean.CodeIdentifierDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.ExpenseGroupDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.ExpenseLineDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.FundDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.FundExternalReferenceDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.FundIdentifierDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.GenericVariableDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.InvestmentProfileDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.MarketingCampaignDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.PatternTemplateDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.PensionPaymentSplitDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.ProductDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.ProfileDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.ProfileFunctionDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.RebalancingBean;
import com.suncorp.ssp.service.integration.applicationservice.bean.RebalancingFrequencyBean;
import com.suncorp.ssp.service.integration.applicationservice.bean.RegularPlanDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.SchemeCategoryDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.SchemeDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.ValueDetails;

/**
 * The class {@code AccountDetailsResponseUtil} is a Utility class with all the properties related to account details, to construct response for
 * creating account application external service's response object.
 * 
 * @author U383847
 * @since 27/01/2016
 * @version 1.0
 */
public class AccountDetailsResponseUtil {
    private final String className = "AccountDetailsResponseUtil";
    private AccountApplicationUtil accountApplicationUtil = null;

    public AccountDetailsResponseUtil() {
        accountApplicationUtil = new AccountApplicationUtil();
    }

    /**
     * Get Account Details.
     * 
     * @param accountApplicationResponseType
     * @return
     * @throws SILException
     */
    public List<AccountDetails> getAccountDetails(AccountApplicationResponseType accountApplicationResponseType) throws SILException {
        List<AccountDetails> accountDetailsList = new ArrayList<AccountDetails>();
        if (accountApplicationResponseType.getFullDetail().getAccountDetails() != null) {
            List<AccountEntityType> accountEntityTypeList = accountApplicationResponseType.getFullDetail().getAccountDetails();
            for (AccountEntityType accountEntityType : accountEntityTypeList) {
                AccountDetails accountEntityDetails = new AccountDetails();
                createAccountApplicationDetails(accountEntityDetails, accountEntityType);
                this.getAccountInvestmentProfileDetails(accountEntityDetails, accountEntityType);
                this.getAccountExpenseGroupDetails(accountEntityDetails, accountEntityType);
                this.getAccountExpenseLineDetails(accountEntityDetails, accountEntityType);
                this.getAccountRegularPlanDetails(accountEntityDetails, accountEntityType);
                this.getAccountTaxDetails(accountEntityDetails, accountEntityType);
                this.getPensionPaymentSplit(accountEntityDetails, accountEntityType);
                this.getAccountBeneficiaryDetails(accountEntityDetails, accountEntityType);
                this.getGenericVariableDetails(accountEntityDetails, accountEntityType);
                accountDetailsList.add(accountEntityDetails);
            }
        }
        return accountDetailsList;
    }

    /**
     * Create request for Account Application Details
     * 
     * @param accountEntityDetails
     * @param accountEntityType
     */
    private void createAccountApplicationDetails(AccountDetails accountEntityDetails, AccountEntityType accountEntityType) {
        this.getAccountIdentifierTypeDetails(accountEntityDetails, accountEntityType);
        this.getAccountProductDetails(accountEntityDetails, accountEntityType);
        this.getAccountSchemeDetails(accountEntityDetails, accountEntityType);
        this.getAccountSchemeCategoryDetails(accountEntityDetails, accountEntityType);
        this.getAccountMarketingCampaignDetails(accountEntityDetails, accountEntityType);
        this.getAccountDetail(accountEntityDetails, accountEntityType);
        this.getAccountExternalReferenceDetails(accountEntityDetails, accountEntityType);
        this.getAccountAdvisorGroupDetails(accountEntityDetails, accountEntityType);
    }

    /**
     * Get Account Identifier Type Details.
     * 
     * @param accountEntityDetails
     * @param accountEntityType
     */
    private void getAccountIdentifierTypeDetails(AccountDetails accountEntityDetails, AccountEntityType accountEntityType) {
        if (accountEntityType.getAccount() != null) {
            AccountIdentifierType account = accountEntityType.getAccount();
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Account Identifier Type Details");
            AccountIdentifierDetails accountIdentifierDetails = new AccountIdentifierDetails();
            accountApplicationUtil.getAccountIdentifierType(account, accountIdentifierDetails);
            accountEntityDetails.setAccountIdentifier(accountIdentifierDetails);
        }
    }

    /**
     * Get Account Product Details.
     * 
     * @param accountEntityDetails
     * @param accountEntityType
     */
    private void getAccountProductDetails(AccountDetails accountEntityDetails, AccountEntityType accountEntityType) {
        ProductDetails product = new ProductDetails();
        if (accountEntityType.getProduct() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Account Product Details");
            ProductIdentifierType productIdentifierType = accountEntityType.getProduct();
            product.setProductName(productIdentifierType.getName());
            product.setProductId(Long.toString(productIdentifierType.getId()));
        } else {
            product.setProductName("");
            product.setProductId("");
        }
        accountEntityDetails.setProduct(product);
    }

    /**
     * Get Account Scheme Details.
     * 
     * @param accountEntityDetails
     * @param accountEntityType
     */
    private void getAccountSchemeDetails(AccountDetails accountEntityDetails, AccountEntityType accountEntityType) {
        SchemeDetails scheme = new SchemeDetails();
        if (accountEntityType.getScheme() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Account Scheme Details");
            SchemeIdentifierType schemeIdentifierType = accountEntityType.getScheme();
            scheme.setSchemeName(schemeIdentifierType.getName());
            scheme.setSchemeNumber(schemeIdentifierType.getSchemeNumber());
        } else {
            scheme.setSchemeName("");
            scheme.setSchemeNumber("");
        }
        accountEntityDetails.setScheme(scheme);
    }

    /**
     * Get Account Scheme Category Details.
     * 
     * @param accountEntityDetails
     * @param accountEntityType
     */
    private void getAccountSchemeCategoryDetails(AccountDetails accountEntityDetails, AccountEntityType accountEntityType) {
        SchemeCategoryDetails schemeCategory = new SchemeCategoryDetails();
        if (accountEntityType.getSchemeCategory() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Account Scheme Category Details");
            SchemeCategoryIdentifierType schemeCategoryIdentifierType = accountEntityType.getSchemeCategory();
            SchemeDetails scheme = new SchemeDetails();
            scheme.setSchemeName(schemeCategoryIdentifierType.getScheme().getName());
            scheme.setSchemeNumber(schemeCategoryIdentifierType.getScheme().getSchemeNumber());
            schemeCategory.setScheme(scheme);
            schemeCategory.setSchemeCategoryName(schemeCategoryIdentifierType.getName());
        } else {
            schemeCategory.setSchemeCategoryName("");
        }
        accountEntityDetails.setSchemeCategory(schemeCategory);
    }

    /**
     * Get Account Marketing Campaign Details.
     * 
     * @param accountEntityDetails
     * @param accountEntityType
     */
    private void getAccountMarketingCampaignDetails(AccountDetails accountEntityDetails, AccountEntityType accountEntityType) {
        MarketingCampaignDetails marketingCampaign = new MarketingCampaignDetails();
        if (accountEntityType.getMarketingCampaign() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Account Marketing Campaign Details");
            MarketingCampaignIdentifierType marketingCampaignType = accountEntityType.getMarketingCampaign();
            marketingCampaign.setMarketingCampaignCode(marketingCampaignType.getCode());
            marketingCampaign.setMarketingCampaignName(marketingCampaignType.getName());
        } else {
            marketingCampaign.setMarketingCampaignCode("");
            marketingCampaign.setMarketingCampaignName("");
        }
        accountEntityDetails.setMarketingCampaign(marketingCampaign);
    }

    /**
     * Get Account Detail.
     * 
     * @param accountEntityDetails
     * @param accountEntityType
     */
    private void getAccountDetail(AccountDetails accountEntityDetails, AccountEntityType accountEntityType) {
        AccountDetail accountDetails = new AccountDetail();
        if (accountEntityType.getAccountDetail() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Account Detail");
            AccountEntityType.AccountDetail accountDetail = accountEntityType.getAccountDetail();
            accountDetails.setAccountDesignation(accountDetail.getAccountDesignation());
            accountDetails.setPreventWithdrawal(accountDetail.isPreventWithdrawal().toString());
            accountDetails.setStatusCode(accountApplicationUtil.createCodeIdentifierInfo(accountDetail.getStatusCode()));
            this.getAccountDetailDates(accountDetail, accountDetails);
            this.getAccountRebalancingDetails(accountDetail, accountDetails);
            accountDetails.setOpenReason(accountApplicationUtil.createCodeIdentifierInfo(accountDetail.getOpenReason()));
        } else {
            accountDetails.setAccountDesignation("");
            accountDetails.setPreventWithdrawal("");
            accountDetails.setCommencementDate("");
            accountDetails.setDateJoinedParticipant("");
            accountDetails.setEligibleServiceDate("");
            accountDetails.setStatusCode(accountApplicationUtil.createDefaultCodeIdentifierInfo());
            accountDetails.setRebalancingBean(accountApplicationUtil.createDefaultRebalancingDetails());
            accountDetails.setOpenReason(accountApplicationUtil.createDefaultCodeIdentifierInfo());
        }
        accountEntityDetails.setAccountDetails(accountDetails);
    }

    /**
     * Get Account Detail Dates.
     * 
     * @param accountDetail
     * @param accountDetails
     */
    private void getAccountDetailDates(AccountEntityType.AccountDetail accountDetail, AccountDetail accountDetails) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Account Detail Dates");
        if (accountDetail.getCommencementDate() != null) {
            accountDetails.setCommencementDate(SILUtil.convertXMLGregorianCalendartoString(accountDetail.getCommencementDate(),
                    CommonConstants.DATE_FORMAT));
        }
        if (accountDetail.getDateJoinedParticipant() != null) {
            accountDetails.setDateJoinedParticipant(SILUtil.convertXMLGregorianCalendartoString(accountDetail.getDateJoinedParticipant(),
                    CommonConstants.DATE_FORMAT));
        }
        if (accountDetail.getEligibleServiceDate() != null) {
            accountDetails.setEligibleServiceDate(SILUtil.convertXMLGregorianCalendartoString(accountDetail.getEligibleServiceDate(),
                    CommonConstants.DATE_FORMAT));
        }
    }

    /**
     * Get Account Rebalancing Details.
     * 
     * @param accountDetail
     * @param accountDetails
     */
    private void getAccountRebalancingDetails(AccountEntityType.AccountDetail accountDetail, AccountDetail accountDetails) {
        if (accountDetail.getIncludeInRebalancing() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Account Rebalancing Details");
            RebalancingBean rebalancingBean = new RebalancingBean();
            IncludeInRebalancing rebalancing = accountDetail.getIncludeInRebalancing();
            if (rebalancing.getNextRebalanceDate() != null) {
                rebalancingBean.setNextRebalanceDate(SILUtil.convertXMLGregorianCalendartoString(rebalancing.getNextRebalanceDate(),
                        CommonConstants.DATE_FORMAT));
            }
            rebalancingBean.setRebalanceImmediately(rebalancing.isRebalanceImmediately() != null ? rebalancing.isRebalanceImmediately().toString()
                    : "");
            rebalancingBean.setIncludeInRebalance(rebalancing.isIncludeInRebalance() != null ? rebalancing.isIncludeInRebalance().toString() : "");
            rebalancingBean.setInstructorCategoryCode(accountApplicationUtil.createCodeIdentifierInfo(rebalancing.getInstructorCategoryCode()));
            this.getRebalancingFrequencyDetails(rebalancing, rebalancingBean);
            accountDetails.setRebalancingBean(rebalancingBean);
        } else {
            accountDetails.setRebalancingBean(accountApplicationUtil.createDefaultRebalancingDetails());
        }
    }

    /**
     * Get Rebalancing Frequency Details.
     * 
     * @param rebalancing
     * @param rebalancingBean
     */
    private void getRebalancingFrequencyDetails(IncludeInRebalancing rebalancing, RebalancingBean rebalancingBean) {
        if (rebalancing.getRebalancingFrequency() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Rebalancing Frequency Details");
            FrequencyIdentifierType frequencyIdentifierType = rebalancing.getRebalancingFrequency();
            RebalancingFrequencyBean rebalancingFrequencyBean = new RebalancingFrequencyBean();
            rebalancingFrequencyBean.setId(frequencyIdentifierType.getId() != null ? frequencyIdentifierType.getId().toString() : "");
            rebalancingFrequencyBean.setName(frequencyIdentifierType.getName());
            rebalancingFrequencyBean.setFistId(frequencyIdentifierType.getFistId() != null ? frequencyIdentifierType.getFistId().toString() : "");
            rebalancingFrequencyBean.setFreqCode(frequencyIdentifierType.getFreqCode());
            rebalancingFrequencyBean.setFreqSetCode(frequencyIdentifierType.getFreqSetCode());
            rebalancingBean.setRebalancingFrequencyBean(rebalancingFrequencyBean);
        } else {
            rebalancingBean.setRebalancingFrequencyBean(accountApplicationUtil.createDefaultRebalancingFrequencyDetails());
        }
    }

    /**
     * Get Account External Reference Details.
     * 
     * @param accountEntityDetails
     * @param accountEntityType
     */
    private void getAccountExternalReferenceDetails(AccountDetails accountEntityDetails, AccountEntityType accountEntityType) {
        List<AccountExternalReferenceDetails> externalReferenceTypeList = new ArrayList<AccountExternalReferenceDetails>();
        if (accountEntityType.getExternalReference() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Account External Reference Details");
            List<ExternalRefType> externalReferenceList = accountEntityType.getExternalReference();
            for (ExternalRefType externalReference : externalReferenceList) {
                AccountExternalReferenceDetails accountExternalReferenceDetails = new AccountExternalReferenceDetails();
                accountExternalReferenceDetails.setExternalReferenceCode(externalReference.getReferenceCode());
                accountExternalReferenceDetails.setExternalReferenceType(externalReference.getReference());
                externalReferenceTypeList.add(accountExternalReferenceDetails);
            }
        } else {
            AccountExternalReferenceDetails accountExternalReferenceDetails = new AccountExternalReferenceDetails();
            accountExternalReferenceDetails.setExternalReferenceCode("");
            accountExternalReferenceDetails.setExternalReferenceType("");
            externalReferenceTypeList.add(accountExternalReferenceDetails);
        }
        accountEntityDetails.setExternalReferenceType(externalReferenceTypeList);
    }

    /**
     * Get Account Advisor Group Details.
     * 
     * @param accountEntityDetails
     * @param accountEntityType
     */
    private void getAccountAdvisorGroupDetails(AccountDetails accountEntityDetails, AccountEntityType accountEntityType) {
        List<AccountAdvisorDetails> advisorGroupList = new ArrayList<AccountAdvisorDetails>();
        if (accountEntityType.getAdvisorGroup() != null) {
            List<AdvisorGroupType> advisorGroupTypeList = accountEntityType.getAdvisorGroup();
            for (AdvisorGroupType advisorGroupType : advisorGroupTypeList) {
                RelationshipTypeIdentifierType relationshipType = advisorGroupType.getRelationshipType();
                AccountAdvisorDetails accountAdvisorDetails = new AccountAdvisorDetails();
                accountAdvisorDetails.setAdvisorgroupId(advisorGroupType.getId().toString());
                accountAdvisorDetails.setRelationshipId(relationshipType.getId().toString());
                accountAdvisorDetails.setRelationshipCode(relationshipType.getCode());
                accountAdvisorDetails.setRelationshipName(relationshipType.getName());
                List<AdvisorSplitType> advisorSplit = advisorGroupType.getAdvisorSplit();
                this.getAccountAdvisorSplitTypeDetails(advisorSplit, accountAdvisorDetails);
                advisorGroupList.add(accountAdvisorDetails);
            }
        } else {
            AccountAdvisorDetails accountAdvisorDetails = new AccountAdvisorDetails();
            accountAdvisorDetails.setAdvisorgroupId("");
            accountAdvisorDetails.setRelationshipId("");
            accountAdvisorDetails.setRelationshipCode("");
            accountAdvisorDetails.setRelationshipName("");
            advisorGroupList.add(accountAdvisorDetails);
        }
        accountEntityDetails.setAdvisorGroup(advisorGroupList);
    }

    /**
     * Get Account Advisor Split Type Details.
     * 
     * @param advisorSplit
     * @param advisorGroup
     */
    private void getAccountAdvisorSplitTypeDetails(List<AdvisorSplitType> advisorSplit, AccountAdvisorDetails accountAdvisorDetails) {
        List<AdvisorSplitDetails> advisorSplitDetailsList = new ArrayList<AdvisorSplitDetails>();
        if (advisorSplit != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Account Advisor Split Type Details");
            for (AdvisorSplitType advisorSplitType : advisorSplit) {
                AdvisorSplitDetails advisorSplitDetails = new AdvisorSplitDetails();
                advisorSplitDetails.setPercentageSplit(advisorSplitType.getPercentageSplit().toString());
                advisorSplitDetails.setPrimaryFlag(String.valueOf(advisorSplitType.isPrimary()));
                AdvisorSplitType.Advisor advisor = advisorSplitType.getAdvisor();
                this.getAdvisorSplitDetails(advisorSplitDetails, advisor);
                advisorSplitDetailsList.add(advisorSplitDetails);
            }
        } else {
            AdvisorSplitDetails advisorSplitDetails = new AdvisorSplitDetails();
            advisorSplitDetails.setPercentageSplit("");
            advisorSplitDetails.setPrimaryFlag("");
            advisorSplitDetails.setAdvisorNumber("");
            advisorSplitDetails.setAdvisorSurname("");
            advisorSplitDetails.setAdvisorForename("");
            advisorSplitDetails.setAdvisorClientId("");
            advisorSplitDetailsList.add(advisorSplitDetails);
        }
        accountAdvisorDetails.setAdvisorSplit(advisorSplitDetailsList);
    }

    /**
     * Does this.
     * 
     * @param advisorSplitDetails
     * @param advisor
     */
    private void getAdvisorSplitDetails(AdvisorSplitDetails advisorSplitDetails, AdvisorSplitType.Advisor advisor) {
        advisorSplitDetails.setAdvisorNumber(advisor.getAdvisorNumber());
        advisorSplitDetails.setAdvisorSurname(advisor.getClientSurname());
        advisorSplitDetails.setAdvisorForename(advisor.getClientForename());
        advisorSplitDetails.setAdvisorClientId(advisor.getClientId().toString());
    }

    /**
     * Get Account Investment Profile Details.
     * 
     * @param accountEntityDetails
     * @param accountEntityType
     */
    private void getAccountInvestmentProfileDetails(AccountDetails accountEntityDetails, AccountEntityType accountEntityType) {
        if (accountEntityType.getInvestmentProfile() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Account Investment Profile Details");
            List<InvestmentProfileType> investmentProfileTypeList = accountEntityType.getInvestmentProfile();
            List<InvestmentProfileDetails> investmentProfileList = new ArrayList<InvestmentProfileDetails>();
            for (InvestmentProfileType investmentProfileType : investmentProfileTypeList) {
                this.getInvestmentProfiles(investmentProfileList, investmentProfileType);
            }
            accountEntityDetails.setInvestmentProfile(investmentProfileList);
        }
    }

    /**
     * Get Investment Profile Details.
     * 
     * @param investmentProfileTypeList
     * @param investmentProfileList
     * @param investmentProfileType
     */
    private void getInvestmentProfiles(List<InvestmentProfileDetails> investmentProfileList, InvestmentProfileType investmentProfileType) {
        if (investmentProfileType.getAccountProfileLink() != null) {
            InvestmentProfileType.AccountProfileLink accountProfileLink = investmentProfileType.getAccountProfileLink();
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Investment Profile Details");
            InvestmentProfileDetails investmentProfileDetails = new InvestmentProfileDetails();
            AccountProfileLinkDetails accountProfileLinkDetails = new AccountProfileLinkDetails();
            this.getAccountProfileLinkDetails(accountProfileLinkDetails, accountProfileLink);
            this.getInvestmentProfileDetails(investmentProfileDetails, accountProfileLink);
            this.getPatternMethodCodeDetails(investmentProfileDetails, accountProfileLink);
            this.getOverrideCodeDetails(investmentProfileDetails, accountProfileLink);
            this.getProfileFunctionDetails(investmentProfileDetails, investmentProfileType.getAccountProfileLink().getProfileFunctionIdentifier());
            this.getProfileDetails(investmentProfileDetails, investmentProfileType.getAccountProfileLink().getProfile());
            this.getFundDetails(investmentProfileDetails, investmentProfileType.getAccountProfileLink().getFund());
            investmentProfileDetails.setAccountProfileLinkDetails(accountProfileLinkDetails);
            investmentProfileList.add(investmentProfileDetails);
        }
    }

    /**
     * Get Account Profile Link Details.
     * 
     * @param accountProfileLinkDetails
     * @param accountProfileLink
     */
    private void getAccountProfileLinkDetails(AccountProfileLinkDetails accountProfileLinkDetails,
            InvestmentProfileType.AccountProfileLink accountProfileLink) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Account Profile Link Details");
        if (accountProfileLink.getEffectiveDate() != null) {
            accountProfileLinkDetails.setEffectiveDate(SILUtil.convertXMLGregorianCalendartoString(accountProfileLink.getEffectiveDate(),
                    CommonConstants.DATE_TIME_FORMAT));
        } else {
            accountProfileLinkDetails.setEffectiveDate("");
        }
    }

    private void getInvestmentProfileDetails(InvestmentProfileDetails investmentProfileDetails,
            InvestmentProfileType.AccountProfileLink accountProfileLink) {
        if (accountProfileLink.isSameAsDefaultInvestmentProfile() != null) {
            investmentProfileDetails.setSameAsDefaultInvestmentProfile(Boolean.toString(accountProfileLink.isSameAsDefaultInvestmentProfile()));
        } else {
            investmentProfileDetails.setSameAsDefaultInvestmentProfile("");
        }
        if (accountProfileLink.getTotalAmount() != null) {
            investmentProfileDetails.setTotalAmount(accountProfileLink.getTotalAmount().toString());
        } else {
            investmentProfileDetails.setTotalAmount("");
        }
        if (accountProfileLink.isClearAllFunds() != null) {
            investmentProfileDetails.setClearAllFunds(accountProfileLink.isClearAllFunds().toString());
        } else {
            investmentProfileDetails.setClearAllFunds("");
        }
    }

    /**
     * Get Profile Function Details.
     * 
     * @param investmentProfile
     * @param profileFunctionIdentifier
     */
    private void getProfileFunctionDetails(InvestmentProfileDetails investmentProfile, ProfileFunctionIdentifierType profileFunctionIdentifier) {
        ProfileFunctionDetails profileFunctionDetails = new ProfileFunctionDetails();
        if (profileFunctionIdentifier != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Profile Function Details");
            profileFunctionDetails.setId(profileFunctionIdentifier.getId().toString());
            profileFunctionDetails.setName(profileFunctionIdentifier.getName());
            profileFunctionDetails.setCode(profileFunctionIdentifier.getCode());
            profileFunctionDetails.setAuditDetails(accountApplicationUtil.createAuditInfo(profileFunctionIdentifier.getAudit()));
        } else {
            profileFunctionDetails.setId("");
            profileFunctionDetails.setName("");
            profileFunctionDetails.setCode("");
            profileFunctionDetails.setAuditDetails(accountApplicationUtil.createDefaultAuditInfo());
        }
        investmentProfile.setProfileFunctionDetails(profileFunctionDetails);
    }

    /**
     * Get Profile Details.
     * 
     * @param investmentProfileDetails
     * @param profile
     */
    private void getProfileDetails(InvestmentProfileDetails investmentProfileDetails, InvestmentProfileType.AccountProfileLink.Profile profile) {
        if (profile != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Profile Details");
            ProfileDetails profileDetails = new ProfileDetails();
            this.getPatternTemplateDetails(profileDetails, profile.getPatternTemplate());
            if (profile.isBespokeNew() != null) {
                profileDetails.setBespoke(profile.isBespokeNew().toString());
            } else {
                profileDetails.setBespoke("");
            }
            investmentProfileDetails.setProfileDetails(profileDetails);
        }
    }

    /**
     * Get Pattern Template Details.
     * 
     * @param profileDetails
     * @param patternTemplate
     */
    private void getPatternTemplateDetails(ProfileDetails profileDetails, PatternTemplateIdentifierType patternTemplate) {
        PatternTemplateDetails patternTemplateDetails = new PatternTemplateDetails();
        if (patternTemplate != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Pattern Template Details");
            if (patternTemplate.getId() != null) {
                patternTemplateDetails.setId(String.valueOf(patternTemplate.getId()));
            }
            patternTemplateDetails.setName(patternTemplate.getName());
            if (patternTemplate.getPatternHeaderId() != null) {
                patternTemplateDetails.setHeaderId(String.valueOf(patternTemplate.getPatternHeaderId()));
            }
            patternTemplateDetails.setReference(patternTemplate.getReference());
            patternTemplateDetails.setEffectiveDate(SILUtil.convertXMLGregorianCalendartoString(patternTemplate.getEffectiveDate(),
                    CommonConstants.DATE_TIME_FORMAT));
            patternTemplateDetails.setTemplateName(patternTemplate.getTemplateName());
            patternTemplateDetails.setAuditDetails(accountApplicationUtil.createAuditInfo(patternTemplate.getAudit()));
        } else {
            patternTemplateDetails.setId("");
            patternTemplateDetails.setName("");
            patternTemplateDetails.setHeaderId("");
            patternTemplateDetails.setReference("");
            patternTemplateDetails.setEffectiveDate("");
            patternTemplateDetails.setTemplateName("");
            patternTemplateDetails.setAuditDetails(accountApplicationUtil.createDefaultAuditInfo());
        }
        profileDetails.setPatternTemplateDetails(patternTemplateDetails);
    }

    /**
     * Get Pattern Method Code Details.
     * 
     * @param accountProfileLinkDetails
     * @param accountProfileLink
     */
    private void getPatternMethodCodeDetails(InvestmentProfileDetails investmentProfileDetails,
            InvestmentProfileType.AccountProfileLink accountProfileLink) {
        if (accountProfileLink.getPatternMethodCode() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Pattern Method Code Details");
            CodeIdentifierDetails codeIdentifier = new CodeIdentifierDetails();
            codeIdentifier.setId(accountProfileLink.getPatternMethodCode().getId().toString());
            codeIdentifier.setCode(accountProfileLink.getPatternMethodCode().getCode());
            codeIdentifier.setCodeType(accountProfileLink.getPatternMethodCode().getCodeType());
            codeIdentifier.setCodeDescription(accountProfileLink.getPatternMethodCode().getCodeDescription());
            codeIdentifier.setCodeShortDescription(accountProfileLink.getPatternMethodCode().getCodeShortDescription());
            investmentProfileDetails.setPatternMethod(codeIdentifier);
        } else {
            investmentProfileDetails.setPatternMethod(accountApplicationUtil.createDefaultCodeIdentifierInfo());
        }
    }

    /**
     * Get Override Code Details.
     * 
     * @param accountProfileLinkDetails
     * @param accountProfileLink
     */
    private void getOverrideCodeDetails(InvestmentProfileDetails investmentProfile, InvestmentProfileType.AccountProfileLink accountProfileLink) {
        if (accountProfileLink.getOverrideCode() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Override Code Details");
            CodeIdentifierDetails codeIdentifier = new CodeIdentifierDetails();
            codeIdentifier.setId(accountProfileLink.getOverrideCode().getId().toString());
            codeIdentifier.setCode(accountProfileLink.getOverrideCode().getCode());
            codeIdentifier.setCodeType(accountProfileLink.getOverrideCode().getCodeType());
            codeIdentifier.setCodeDescription(accountProfileLink.getOverrideCode().getCodeDescription());
            codeIdentifier.setCodeShortDescription(accountProfileLink.getOverrideCode().getCodeShortDescription());
            investmentProfile.setOverrideCode(codeIdentifier);
        } else {
            investmentProfile.setOverrideCode(accountApplicationUtil.createDefaultCodeIdentifierInfo());
        }
    }

    /**
     * Get Fund Details.
     * 
     * @param accountProfileLinkDetails
     * @param fundList
     */
    private void getFundDetails(InvestmentProfileDetails investmentProfileDetails, List<InvestmentProfileType.AccountProfileLink.Fund> fundList) {
        if (fundList != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Fund Details");
            List<FundDetails> fundDetailsList = new ArrayList<FundDetails>();
            for (InvestmentProfileType.AccountProfileLink.Fund fund : fundList) {
                FundDetails fundDetails = new FundDetails();
                if (fund.getSplitPercent() != null) {
                    fundDetails.setSplitPercent(fund.getSplitPercent().toString());
                } else {
                    fundDetails.setSplitPercent("");
                }
                this.getFundIdentifierDetails(fundDetails, fund);
                this.getAlternateFundIdentifierDetails(fundDetails, fund);
                fundDetailsList.add(fundDetails);
            }
            investmentProfileDetails.setFundDetails(fundDetailsList);
        }
    }

    /**
     * Get Fund Identifier Details.
     * 
     * @param fundDetails
     * @param fund
     */
    private void getFundIdentifierDetails(FundDetails fundDetails, InvestmentProfileType.AccountProfileLink.Fund fund) {
        FundIdentifierType fundIdentifierType = fund.getFundIdentifier();
        FundIdentifierDetails fundIdentifier = new FundIdentifierDetails();
        if (fundIdentifierType != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Fund Identifier Details");
            this.getFundIdentifierTypeDetails(fundIdentifierType, fundIdentifier);
            this.getFundAmountSplitPercentDetails(fund, fundIdentifier);
        } else {
            fundIdentifier.setId("");
            fundIdentifier.setName("");
            fundIdentifier.setFundFullName("");
            fundIdentifier.setFundCorrespondenceName("");
        }
        fundDetails.setFundIdentifier(fundIdentifier);
    }

    private void getFundAmountSplitPercentDetails(InvestmentProfileType.AccountProfileLink.Fund fund, FundIdentifierDetails fundIdentifier) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Fund Amount and Split Percent Details");
        if (fund.getAmount() != null) {
            fundIdentifier.setAmount(fund.getAmount().toString());
        } else {
            fundIdentifier.setAmount("");
        }
        if (fund.getSequence() != null) {
            fundIdentifier.setSequence(fund.getSequence().toString());
        } else {
            fundIdentifier.setSequence("");
        }
    }

    /**
     * Get Fund External Reference Details.
     * 
     * @param fundIdentifier
     * @param fundIdentifierType
     */
    private void getFundExternalReferenceDetails(FundIdentifierDetails fundIdentifier, FundIdentifierType fundIdentifierType) {
        FundExternalReferenceDetails fundExternalReference = new FundExternalReferenceDetails();
        if (fundIdentifierType.getFundExternalRef() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Fund External Reference Details");
            fundExternalReference.setExternalReferenceCode(fundIdentifierType.getFundExternalRef().getReferenceCode());
            fundExternalReference.setExternalReference(fundIdentifierType.getFundExternalRef().getReference());
        } else {
            fundExternalReference.setExternalReferenceCode("");
            fundExternalReference.setExternalReference("");
        }
        fundIdentifier.setFundExternalReference(fundExternalReference);
    }

    /**
     * Get Fund Type Details.
     * 
     * @param fundIdentifier
     * @param fundIdentifierType
     */
    private void getFundTypeDetails(FundIdentifierDetails fundIdentifier, FundIdentifierType fundIdentifierType) {
        if (fundIdentifierType.getFundType() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Fund Type Details");
            CodeIdentifierDetails codeIdentifier = new CodeIdentifierDetails();
            codeIdentifier.setId(fundIdentifierType.getFundType().getId().toString());
            codeIdentifier.setCode(fundIdentifierType.getFundType().getCode());
            codeIdentifier.setCodeType(fundIdentifierType.getFundType().getCodeType());
            codeIdentifier.setCodeDescription(fundIdentifierType.getFundType().getCodeDescription());
            codeIdentifier.setCodeShortDescription(fundIdentifierType.getFundType().getCodeShortDescription());
            fundIdentifier.setFundType(codeIdentifier);
        } else {
            fundIdentifier.setFundType(accountApplicationUtil.createDefaultCodeIdentifierInfo());
        }
    }

    /**
     * Get Alternate Fund Identifier Details.
     * 
     * @param fundDetails
     * @param fund
     */
    private void getAlternateFundIdentifierDetails(FundDetails fundDetails, InvestmentProfileType.AccountProfileLink.Fund fund) {
        FundIdentifierType alternatefundIdentifierType = fund.getAlternateFundIdentifier();
        FundIdentifierDetails fundIdentifier = new FundIdentifierDetails();
        if (alternatefundIdentifierType != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Alternate Fund Identifier Details");
            this.getFundIdentifierTypeDetails(alternatefundIdentifierType, fundIdentifier);
        } else {
            fundIdentifier.setId("");
            fundIdentifier.setName("");
            fundIdentifier.setFundFullName("");
            fundIdentifier.setFundCorrespondenceName("");
        }
        fundDetails.setAlternateFundIdentifier(fundIdentifier);
    }

    /**
     * Get Fund Identifier Type Details.
     * 
     * @param fundDetails
     * @param fundIdentifierType
     * @param fundIdentifier
     */
    private void getFundIdentifierTypeDetails(FundIdentifierType fundIdentifierType, FundIdentifierDetails fundIdentifier) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Fund Identifier Type Details");
        fundIdentifier.setId(fundIdentifierType.getId().toString());
        fundIdentifier.setName(fundIdentifierType.getName());
        fundIdentifier.setFundFullName(fundIdentifierType.getFundFullName());
        fundIdentifier.setFundCorrespondenceName(fundIdentifierType.getFundCorrespondenceName());
        this.getFundExternalReferenceDetails(fundIdentifier, fundIdentifierType);
        this.getFundTypeDetails(fundIdentifier, fundIdentifierType);
        fundIdentifier.setAuditDetails(accountApplicationUtil.createAuditInfo(fundIdentifierType.getAudit()));
    }

    /**
     * Get Account Expense Group Details.
     * 
     * @param accountEntityDetails
     * @param accountEntityType
     */
    private void getAccountExpenseGroupDetails(AccountDetails accountEntityDetails, AccountEntityType accountEntityType) {
        ExpenseGroupDetails expenseGroupDetails = new ExpenseGroupDetails();
        if (accountEntityType.getExpenseGroup() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Account Expense Group Details");
            ExpenseGroupIdentifierType expenseGroupIdentifier = accountEntityType.getExpenseGroup();
            expenseGroupDetails.setAudit(accountApplicationUtil.createAuditInfo(expenseGroupIdentifier.getAudit()));
            if (expenseGroupIdentifier.getId() != null) {
                expenseGroupDetails.setId(Long.toString(expenseGroupIdentifier.getId()));
            } else {
                expenseGroupDetails.setId("");
            }
            expenseGroupDetails.setName(expenseGroupIdentifier.getName());
        } else {
            expenseGroupDetails.setId("");
            expenseGroupDetails.setName("");
            expenseGroupDetails.setAudit(accountApplicationUtil.createDefaultAuditInfo());
        }
        accountEntityDetails.setExpenseGroup(expenseGroupDetails);
    }

    /**
     * Get Account Expense Line Details.
     * 
     * @param accountEntityDetails
     * @param accountEntityType
     */
    private void getAccountExpenseLineDetails(AccountDetails accountEntityDetails, AccountEntityType accountEntityType) {
        if (accountEntityType.getExpenseLine() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Account Expense Line Details");
            List<ExpenseLineType> expenseLineTypeList = accountEntityType.getExpenseLine();
            List<ExpenseLineDetails> expenseLineDetailsList = new ArrayList<ExpenseLineDetails>();
            for (ExpenseLineType expenseLineType : expenseLineTypeList) {
                ExpenseLineDetails expenseLineDetails = new ExpenseLineDetails();
                ExpenseLineResponseUtil expenseLineResponseUtil = new ExpenseLineResponseUtil();
                expenseLineResponseUtil.getExpenseDetails(expenseLineType, expenseLineDetails, accountApplicationUtil);
                expenseLineDetailsList.add(expenseLineDetails);
            }
            accountEntityDetails.setExpenseLine(expenseLineDetailsList);
        }
    }

    /**
     * Get Account Regular Plan Details.
     * 
     * @param accountEntityDetails of type AccountDetails
     * @param accountEntityType of type AccountEntityType
     */
    private void getAccountRegularPlanDetails(AccountDetails accountEntityDetails, AccountEntityType accountEntityType) {
        if (accountEntityType.getRegularContributionPlan() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Account Regular Plan Details");
            List<RegularPlanType> regularPlanTypeList = accountEntityType.getRegularContributionPlan();
            List<RegularPlanDetails> regularPlanDetailsList = new ArrayList<RegularPlanDetails>();
            for (RegularPlanType regularPlanType : regularPlanTypeList) {
                RegularPlanDetailsResponseUtil regularPlanDetailsResponseUtil = new RegularPlanDetailsResponseUtil();
                regularPlanDetailsResponseUtil.addRegularPlanDetails(regularPlanDetailsList, regularPlanType);
            }
            accountEntityDetails.setRegularContributionPlan(regularPlanDetailsList);
        }
    }

    /**
     * Get Pension Payment Split Details.
     * 
     * @param accountEntityDetails
     * @param accountEntityType
     */
    private void getPensionPaymentSplit(AccountDetails accountEntityDetails, AccountEntityType accountEntityType) {
        List<PensionPaymentSplitDetails> pensionPaymentSplitList = new ArrayList<PensionPaymentSplitDetails>();
        if (accountEntityType.getPensionPaymentSplit() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "getPensionPaymentSplit");
            List<PensionPaymentSplitType> pensionPaymentSplitTypeList = accountEntityType.getPensionPaymentSplit();
            for (PensionPaymentSplitType pensionPaymentSplitType : pensionPaymentSplitTypeList) {
                PensionSplitResponseUtil pensionSplitResponseUtil = new PensionSplitResponseUtil();
                pensionSplitResponseUtil.addPensionPaymentSplitDetails(pensionPaymentSplitList, pensionPaymentSplitType);
            }
            accountEntityDetails.setPensionPaymentSplitDetails(pensionPaymentSplitList);
        } else {
            PensionPaymentSplitDetails pensionPaymentSplit = new PensionPaymentSplitDetails();
            PensionSplitResponseUtil pensionSplitResponseUtil = new PensionSplitResponseUtil();
            pensionSplitResponseUtil.createDefaultPensionSplit(pensionPaymentSplit);
            pensionPaymentSplitList.add(pensionPaymentSplit);
            accountEntityDetails.setPensionPaymentSplitDetails(pensionPaymentSplitList);
        }
    }

    /**
     * Get Account Tax Details.
     * 
     * @param accountEntityDetails
     * @param accountEntityType
     */
    private void getAccountTaxDetails(AccountDetails accountEntityDetails, AccountEntityType accountEntityType) {
        AccountTaxDetail accountTaxDetail = new AccountTaxDetail();
        if (accountEntityType.getAccountTaxDetail() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "getAccountTaxDetails");
            AccountTaxType accountTaxType = accountEntityType.getAccountTaxDetail();
            PensionSplitResponseUtil pensionSplitResponseUtil = new PensionSplitResponseUtil();
            pensionSplitResponseUtil.getAccountTaxDetail(accountTaxType, accountTaxDetail);
            accountEntityDetails.setAccountTaxDetail(accountTaxDetail);
        } else {
            PensionSplitResponseUtil pensionSplitResponseUtil = new PensionSplitResponseUtil();
            pensionSplitResponseUtil.setDefaultAccountTaxDetail(accountTaxDetail);
            accountEntityDetails.setAccountTaxDetail(accountTaxDetail);
        }
    }

    /**
     * Get Account Beneficiary Details.
     * 
     * @param outboundAccountDetails of type AccountDetails
     * @param inboundAccountType of type AccountEntityType
     */
    private void getAccountBeneficiaryDetails(AccountDetails outboundAccountDetails, AccountEntityType inboundAccountType) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Account Beneficiary Details");
        List<BeneficiaryType> inboundBeneficiaryList = inboundAccountType.getBeneficiary();
        List<BeneficiaryBean> outboundBeneficiaryList = new ArrayList<BeneficiaryBean>();
        if (inboundBeneficiaryList != null && inboundBeneficiaryList.size() > 0) {
            for (BeneficiaryType inboundBeneficiary : inboundBeneficiaryList) {
                outboundBeneficiaryList.add(new AddBeneficiaryDetailsResponseUtil(inboundBeneficiary).createOutboundBeneficiary());
            }
        } else {
            outboundBeneficiaryList.add(new AddBeneficiaryDetailsResponseUtil(null).createDefaultOutboundBeneficiary());
        }
        outboundAccountDetails.setBeneficiaries(outboundBeneficiaryList);
    }

    /**
     * Get Account Generic Variable Details.
     * 
     * @param accountEntityDetails
     * @param accountEntityType
     */
    private void getGenericVariableDetails(AccountDetails accountEntityDetails, AccountEntityType accountEntityType) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Account Generic Variable Details");
        List<GenericVariableType> genericVariableTypeList = accountEntityType.getGenericVariable();
        List<GenericVariableDetails> genericVariableDetailsList = new ArrayList<GenericVariableDetails>();
        if (accountEntityType.getGenericVariable() != null && accountEntityType.getGenericVariable().size() > 0) {
            for (GenericVariableType genericVariableType : genericVariableTypeList) {
                GenericVariableDetails genericVariableDetails = new GenericVariableDetails();
                genericVariableDetails.setId(String.valueOf(genericVariableType.getId()));
                genericVariableDetails.setCode(genericVariableType.getCode());
                genericVariableDetails.setLabel(genericVariableType.getLabel());
                genericVariableDetails.setDescription(genericVariableType.getDescription());
                this.getValueDetails(genericVariableType, genericVariableDetails);
                genericVariableDetailsList.add(genericVariableDetails);
            }
            accountEntityDetails.setGenericVariables(genericVariableDetailsList);
        }
    }

    /**
     * Get Account Generic Variable Value Details.
     * 
     * @param genericVariableType
     * @param genericVariableDetails
     */
    private void getValueDetails(GenericVariableType genericVariableType, GenericVariableDetails genericVariableDetails) {
        if (genericVariableType.getValue() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Account Generic Variable Value Details");
            GenericVariableType.Value value = genericVariableType.getValue();
            ValueDetails valueDetails = new ValueDetails();
            getValues(value, valueDetails);
            if (value.getCode() != null) {
                CodeIdentifierType codeIdentifierType = value.getCode();
                CodeIdentifierDetails codeIdentifierDetails = new CodeIdentifierDetails();
                codeIdentifierDetails.setId(String.valueOf(codeIdentifierType.getId()));
                codeIdentifierDetails.setCode(codeIdentifierType.getCode());
                codeIdentifierDetails.setCodeType(codeIdentifierType.getCodeType());
                codeIdentifierDetails.setCodeDescription(codeIdentifierType.getCodeDescription());
                codeIdentifierDetails.setCodeShortDescription(codeIdentifierType.getCodeShortDescription());
                valueDetails.setCode(codeIdentifierDetails);
            }
            genericVariableDetails.setValues(valueDetails);
        }
    }

    /**
     * Get Account Generic Variable Values.
     * 
     * @param value
     * @param valueDetails
     */
    private void getValues(GenericVariableType.Value value, ValueDetails valueDetails) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Account Generic Variable Values");
        if (value.getDecimal() != null) {
            valueDetails.setDecimal(String.valueOf(value.getDecimal()));
        }
        if (value.getInteger() != null) {
            valueDetails.setInteger(String.valueOf(value.getInteger()));
        }
        if (value.getDatetime() != null) {
            valueDetails.setDateTime(SILUtil.convertXMLGregorianCalendartoString(value.getDatetime(), CommonConstants.DATE_FORMAT));
        }
        if (value.getChecked() != null) {
            valueDetails.setChecked(value.getChecked());
        }
        if (value.getString() != null) {
            valueDetails.setString(value.getString());
        }
    }
}
