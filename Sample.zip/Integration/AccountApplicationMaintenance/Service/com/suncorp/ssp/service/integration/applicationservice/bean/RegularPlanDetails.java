////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code RegularPlanDetails} does this.
 * 
 * @author U386868
 * @since 10/02/2016
 * @version 1.0
 */
public class RegularPlanDetails {

    private String regularPlanId;
    private CodeNameIdentifier relationshipType;
    private String clientPointer;
    private ClientDetails client;
    private CodeIdentifierDetails status;
    private CodeIdentifierDetails paymentMethod;
    private FrequencyIdentifierInfo frequency;
    private BankAccountIdentifier bankAccount;
    private String amount;
    private String nextDueDate;
    private String linkedToProfile;
    private List<FundDetails> fundSplits;
    private List<ContributionSplitInfo> contributionTypeSplits;

    /**
     * Accessor for property regularPlanId.
     * 
     * @return regularPlanId of type String
     */
    public String getRegularPlanId() {
        return regularPlanId;
    }

    /**
     * Mutator for property regularPlanId.
     * 
     * @return regularPlanId of type String
     */
    @XmlElement(name = "regularPlanId")
    public void setRegularPlanId(String regularPlanId) {
        this.regularPlanId = regularPlanId;
    }

    /**
     * Accessor for property relationshipType.
     * 
     * @return relationshipType of type CodeNameIdentifier
     */
    public CodeNameIdentifier getRelationshipType() {
        return relationshipType;
    }

    /**
     * Mutator for property relationshipType.
     * 
     * @return relationshipType of type CodeNameIdentifier
     */
    @XmlElement(name = "relationshipType")
    public void setRelationshipType(CodeNameIdentifier relationshipType) {
        this.relationshipType = relationshipType;
    }

    /**
     * Accessor for property clientPointer.
     * 
     * @return clientPointer of type String
     */
    public String getClientPointer() {
        return clientPointer;
    }

    /**
     * Mutator for property clientPointer.
     * 
     * @return clientPointer of type String
     */
    @XmlElement(name = "clientPointer")
    public void setClientPointer(String clientPointer) {
        this.clientPointer = clientPointer;
    }

    /**
     * Accessor for property client.
     * 
     * @return client of type ClientDetails
     */
    public ClientDetails getClient() {
        return client;
    }

    /**
     * Mutator for property client.
     * 
     * @return client of type ClientDetails
     */
    @XmlElement(name = "client")
    public void setClient(ClientDetails client) {
        this.client = client;
    }

    /**
     * Accessor for property status.
     * 
     * @return status of type CodeIdentifierDetails
     */
    public CodeIdentifierDetails getStatus() {
        return status;
    }

    /**
     * Mutator for property status.
     * 
     * @return status of type CodeIdentifierDetails
     */
    @XmlElement(name = "status")
    public void setStatus(CodeIdentifierDetails status) {
        this.status = status;
    }

    /**
     * Accessor for property paymentMethod.
     * 
     * @return paymentMethod of type CodeIdentifierDetails
     */
    public CodeIdentifierDetails getPaymentMethod() {
        return paymentMethod;
    }

    /**
     * Mutator for property paymentMethod.
     * 
     * @return paymentMethod of type CodeIdentifierDetails
     */
    @XmlElement(name = "paymentMethod")
    public void setPaymentMethod(CodeIdentifierDetails paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    /**
     * Accessor for property frequency.
     * 
     * @return frequency of type FrequencyIdentifierInfo
     */
    public FrequencyIdentifierInfo getFrequency() {
        return frequency;
    }

    /**
     * Mutator for property frequency.
     * 
     * @return frequency of type FrequencyIdentifierInfo
     */
    @XmlElement(name = "frequency")
    public void setFrequency(FrequencyIdentifierInfo frequency) {
        this.frequency = frequency;
    }

    /**
     * Accessor for property bankAccount.
     * 
     * @return bankAccount of type BankAccountIdentifier
     */
    public BankAccountIdentifier getBankAccount() {
        return bankAccount;
    }

    /**
     * Mutator for property bankAccount.
     * 
     * @return bankAccount of type BankAccountIdentifier
     */
    @XmlElement(name = "bankAccount")
    public void setBankAccount(BankAccountIdentifier bankAccount) {
        this.bankAccount = bankAccount;
    }

    /**
     * Accessor for property amount.
     * 
     * @return amount of type String
     */
    public String getAmount() {
        return amount;
    }

    /**
     * Mutator for property amount.
     * 
     * @return amount of type String
     */
    @XmlElement(name = "amount")
    public void setAmount(String amount) {
        this.amount = amount;
    }

    /**
     * Accessor for property nextDueDate.
     * 
     * @return nextDueDate of type String
     */
    public String getNextDueDate() {
        return nextDueDate;
    }

    /**
     * Mutator for property nextDueDate.
     * 
     * @return nextDueDate of type String
     */
    @XmlElement(name = "nextDueDate")
    public void setNextDueDate(String nextDueDate) {
        this.nextDueDate = nextDueDate;
    }

    /**
     * Accessor for property linkedToProfile.
     * 
     * @return linkedToProfile of type String
     */
    public String getLinkedToProfile() {
        return linkedToProfile;
    }

    /**
     * Mutator for property linkedToProfile.
     * 
     * @return linkedToProfile of type String
     */
    @XmlElement(name = "linkedToProfile")
    public void setLinkedToProfile(String linkedToProfile) {
        this.linkedToProfile = linkedToProfile;
    }

    /**
     * Accessor for property fundSplits.
     * 
     * @return fundSplits of type List<FundDetails>
     */
    public List<FundDetails> getFundSplits() {
        return fundSplits;
    }

    /**
     * Mutator for property fundSplits.
     * 
     * @return fundSplits of type List<FundDetails>
     */
    @XmlElement(name = "fundDetails")
    public void setFundSplits(List<FundDetails> fundSplits) {
        this.fundSplits = fundSplits;
    }

    /**
     * Accessor for property contributionTypeSplits.
     * 
     * @return contributionTypeSplits of type ContributionSplitInfo
     */
    public List<ContributionSplitInfo> getContributionTypeSplits() {
        return contributionTypeSplits;
    }

    /**
     * Mutator for property contributionTypeSplits.
     * 
     * @return contributionTypeSplits of type ContributionSplitInfo
     */
    @XmlElement(name = "contributionTypeSplits")
    public void setContributionTypeSplits(List<ContributionSplitInfo> contributionTypeSplits) {
        this.contributionTypeSplits = contributionTypeSplits;
    }
}
