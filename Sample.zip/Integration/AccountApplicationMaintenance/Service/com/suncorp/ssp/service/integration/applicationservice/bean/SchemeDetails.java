////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code SchemeDetails} is a java bean consisting of properties related to Scheme Details.
 * 
 * @author U383847
 * @since 06/01/2016
 * @version 1.0
 */
public class SchemeDetails {
    private String schemeName;
    private String schemeNumber;
    
    /**
     * Accessor for property schemeName.
     * 
     * @return schemeName of type String
     */
    public String getSchemeName() {
        return schemeName;
    }
    
    /**
     * Mutator for property schemeName.
     * 
     * @param schemeName of type String
     */
    @XmlElement(name = "schemeName")
    public void setSchemeName(String schemeName) {
        this.schemeName = schemeName != null ? schemeName : "";
    }
    
    /**
     * Accessor for property schemeNumber.
     * 
     * @return schemeNumber of type String
     */
    public String getSchemeNumber() {
        return schemeNumber;
    }
    
    /**
     * Mutator for property schemeNumber.
     * 
     * @param schemeNumber of type String
     */
    @XmlElement(name = "schemeNumber")
    public void setSchemeNumber(String schemeNumber) {
        this.schemeNumber = schemeNumber != null ? schemeNumber : "";
    }
}
