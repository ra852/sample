////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code PensionPaymentDetails} does this.
 * 
 * @author u385424
 * @since 16/02/2016
 * @version 1.0
 */
public class PensionPaymentDetails {
    private String effectiveDate;
    private FrequencyIdentifierDetails paymentFrequency;
    private String numberOfPayments;
    private CodeIdentifierDetails pensionPaymentRule;
    private CodeIdentifierDetails reviewType;
    private FrequencyIdentifierDetails reviewFrequency;
    private String taxOverridePercent;
    private CodeIdentifierDetails taxFreeMethod;
    private CodeIdentifierDetails revAnnuitantRelationship;
    private String pensionStartDate;
    private String paymentDate1;
    private String paymentDate2;
    private String nextPaymentDue;
    private String nominatedIndexRate;
    private String additionalTax;
    private String nextReviewDate;
    private String taxFreeProportion;
    private String annualNominatedPercent;
    private String claimRebate;
    private String claimDeductible;
    private String carryForwardDeductible;
    private String ttr;

    /**
     * Accessor for property effectiveDate.
     * 
     * @return effectiveDate of type String
     */
    public String getEffectiveDate() {
        return effectiveDate;
    }

    /**
     * Mutator for property effectiveDate.
     * 
     * @return effectiveDate of type String
     */
    @XmlElement(name = "effectiveDate")
    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    /**
     * Accessor for property paymentFrequency.
     * 
     * @return paymentFrequency of type paymentFrequencyDetails
     */
    public FrequencyIdentifierDetails getPaymentFrequency() {
        return paymentFrequency;
    }

    /**
     * Mutator for property paymentFrequency.
     * 
     * @return paymentFrequency of type paymentFrequencyDetails
     */
    @XmlElement(name = "paymentFrequency")
    public void setPaymentFrequency(FrequencyIdentifierDetails paymentFrequency) {
        this.paymentFrequency = paymentFrequency;
    }

    /**
     * Accessor for property numberOfPayments.
     * 
     * @return numberOfPayments of type Long
     */
    public String getNumberOfPayments() {
        return numberOfPayments;
    }

    /**
     * Mutator for property numberOfPayments.
     * 
     * @return numberOfPayments of type Long
     */
    @XmlElement(name = "numberOfPayments")
    public void setNumberOfPayments(String numberOfPayments) {
        this.numberOfPayments = numberOfPayments;
    }

    /**
     * Accessor for property pensionPaymentRule.
     * 
     * @return pensionPaymentRule of type CodeIdentifierDetails
     */
    public CodeIdentifierDetails getPensionPaymentRule() {
        return pensionPaymentRule;
    }

    /**
     * Mutator for property pensionPaymentRule.
     * 
     * @return pensionPaymentRule of type CodeIdentifierDetails
     */
    @XmlElement(name = "pensionPaymentRule")
    public void setPensionPaymentRule(CodeIdentifierDetails pensionPaymentRule) {
        this.pensionPaymentRule = pensionPaymentRule;
    }

    /**
     * Accessor for property reviewType.
     * 
     * @return reviewType of type CodeIdentifierDetails
     */
    public CodeIdentifierDetails getReviewType() {
        return reviewType;
    }

    /**
     * Mutator for property reviewType.
     * 
     * @return reviewType of type CodeIdentifierDetails
     */
    @XmlElement(name = "reviewType")
    public void setReviewType(CodeIdentifierDetails reviewType) {
        this.reviewType = reviewType;
    }

    /**
     * Accessor for property reviewFrequency.
     * 
     * @return reviewFrequency of type FrequencyIdentifierDetails
     */
    public FrequencyIdentifierDetails getReviewFrequency() {
        return reviewFrequency;
    }

    /**
     * Mutator for property reviewFrequency.
     * 
     * @return reviewFrequency of type FrequencyIdentifierDetails
     */
    @XmlElement(name = "reviewFrequency")
    public void setReviewFrequency(FrequencyIdentifierDetails reviewFrequency) {
        this.reviewFrequency = reviewFrequency;
    }

    /**
     * Accessor for property taxOverridePercent.
     * 
     * @return taxOverridePercent of type String
     */
    public String getTaxOverridePercent() {
        return taxOverridePercent;
    }

    /**
     * Mutator for property taxOverridePercent.
     * 
     * @return taxOverridePercent of type String
     */
    @XmlElement(name = "taxOverridePercent")
    public void setTaxOverridePercent(String taxOverridePercent) {
        this.taxOverridePercent = taxOverridePercent;
    }

    /**
     * Accessor for property taxFreeMethod.
     * 
     * @return taxFreeMethod of type CodeIdentifierDetails
     */
    public CodeIdentifierDetails getTaxFreeMethod() {
        return taxFreeMethod;
    }

    /**
     * Mutator for property taxFreeMethod.
     * 
     * @return taxFreeMethod of type CodeIdentifierDetails
     */
    @XmlElement(name = "taxFreeMethod")
    public void setTaxFreeMethod(CodeIdentifierDetails taxFreeMethod) {
        this.taxFreeMethod = taxFreeMethod;
    }

    /**
     * Accessor for property revAnnuitantRelationship.
     * 
     * @return revAnnuitantRelationship of type CodeIdentifierDetails
     */
    public CodeIdentifierDetails getRevAnnuitantRelationship() {
        return revAnnuitantRelationship;
    }

    /**
     * Mutator for property revAnnuitantRelationship.
     * 
     * @return revAnnuitantRelationship of type CodeIdentifierDetails
     */
    @XmlElement(name = "revAnnuitantRelationship")
    public void setRevAnnuitantRelationship(CodeIdentifierDetails revAnnuitantRelationship) {
        this.revAnnuitantRelationship = revAnnuitantRelationship;
    }

    /**
     * Accessor for property pensionStartDate.
     * 
     * @return pensionStartDate of type String
     */
    public String getPensionStartDate() {
        return pensionStartDate;
    }

    /**
     * Mutator for property pensionStartDate.
     * 
     * @return pensionStartDate of type String
     */
    @XmlElement(name = "pensionStartDate")
    public void setPensionStartDate(String pensionStartDate) {
        this.pensionStartDate = pensionStartDate;
    }

    /**
     * Accessor for property paymentDate1.
     * 
     * @return paymentDate1 of type String
     */
    public String getPaymentDate1() {
        return paymentDate1;
    }

    /**
     * Mutator for property paymentDate1.
     * 
     * @return paymentDate1 of type String
     */
    @XmlElement(name = "paymentDate1")
    public void setPaymentDate1(String paymentDate1) {
        this.paymentDate1 = paymentDate1;
    }

    /**
     * Accessor for property paymentDate2.
     * 
     * @return paymentDate2 of type String
     */
    public String getPaymentDate2() {
        return paymentDate2;
    }

    /**
     * Mutator for property paymentDate2.
     * 
     * @return paymentDate2 of type String
     */
    @XmlElement(name = "paymentDate2")
    public void setPaymentDate2(String paymentDate2) {
        this.paymentDate2 = paymentDate2;
    }

    /**
     * Accessor for property nextPaymentDue.
     * 
     * @return nextPaymentDue of type String
     */
    public String getNextPaymentDue() {
        return nextPaymentDue;
    }

    /**
     * Mutator for property nextPaymentDue.
     * 
     * @return nextPaymentDue of type String
     */
    @XmlElement(name = "nextPaymentDue")
    public void setNextPaymentDue(String nextPaymentDue) {
        this.nextPaymentDue = nextPaymentDue;
    }

    /**
     * Accessor for property nominatedIndexRate.
     * 
     * @return nominatedIndexRate of type String
     */
    public String getNominatedIndexRate() {
        return nominatedIndexRate;
    }

    /**
     * Mutator for property nominatedIndexRate.
     * 
     * @return nominatedIndexRate of type String
     */
    @XmlElement(name = "nominatedIndexRate")
    public void setNominatedIndexRate(String nominatedIndexRate) {
        this.nominatedIndexRate = nominatedIndexRate;
    }

    /**
     * Accessor for property additionalTax.
     * 
     * @return additionalTax of type String
     */
    public String getAdditionalTax() {
        return additionalTax;
    }

    /**
     * Mutator for property additionalTax.
     * 
     * @return additionalTax of type String
     */
    @XmlElement(name = "additionalTax")
    public void setAdditionalTax(String additionalTax) {
        this.additionalTax = additionalTax;
    }

    /**
     * Accessor for property nextReviewDate.
     * 
     * @return nextReviewDate of type String
     */
    public String getNextReviewDate() {
        return nextReviewDate;
    }

    /**
     * Mutator for property nextReviewDate.
     * 
     * @return nextReviewDate of type String
     */
    @XmlElement(name = "nextReviewDate")
    public void setNextReviewDate(String nextReviewDate) {
        this.nextReviewDate = nextReviewDate;
    }

    /**
     * Accessor for property taxFreeProportion.
     * 
     * @return taxFreeProportion of type String
     */
    public String getTaxFreeProportion() {
        return taxFreeProportion;
    }

    /**
     * Mutator for property taxFreeProportion.
     * 
     * @return taxFreeProportion of type String
     */
    @XmlElement(name = "taxFreeProportion")
    public void setTaxFreeProportion(String taxFreeProportion) {
        this.taxFreeProportion = taxFreeProportion;
    }

    /**
     * Accessor for property annualNominatedPercent.
     * 
     * @return annualNominatedPercent of type String
     */
    public String getAnnualNominatedPercent() {
        return annualNominatedPercent;
    }

    /**
     * Mutator for property annualNominatedPercent.
     * 
     * @return annualNominatedPercent of type String
     */
    @XmlElement(name = "annualNominatedPercent")
    public void setAnnualNominatedPercent(String annualNominatedPercent) {
        this.annualNominatedPercent = annualNominatedPercent;
    }

    /**
     * Accessor for property claimRebate.
     * 
     * @return claimRebate of type String
     */
    public String getClaimRebate() {
        return claimRebate;
    }

    /**
     * Mutator for property claimRebate.
     * 
     * @return claimRebate of type String
     */
    @XmlElement(name = "claimRebate")
    public void setClaimRebate(String claimRebate) {
        this.claimRebate = claimRebate;
    }

    /**
     * Accessor for property claimDeductible.
     * 
     * @return claimDeductible of type String
     */
    public String getClaimDeductible() {
        return claimDeductible;
    }

    /**
     * Mutator for property claimDeductible.
     * 
     * @return claimDeductible of type String
     */
    @XmlElement(name = "claimDeductible")
    public void setClaimDeductible(String claimDeductible) {
        this.claimDeductible = claimDeductible;
    }

    /**
     * Accessor for property carryForwardDeductible.
     * 
     * @return carryForwardDeductible of type String
     */
    public String getCarryForwardDeductible() {
        return carryForwardDeductible;
    }

    /**
     * Mutator for property carryForwardDeductible.
     * 
     * @return carryForwardDeductible of type String
     */
    @XmlElement(name = "carryForwardDeductible")
    public void setCarryForwardDeductible(String carryForwardDeductible) {
        this.carryForwardDeductible = carryForwardDeductible;
    }

    /**
     * Accessor for property ttr.
     * 
     * @return ttr of type String
     */
    public String getTtr() {
        return ttr;
    }

    /**
     * Mutator for property ttr.
     * 
     * @return ttr of type String
     */
    @XmlElement(name = "ttr")
    public void setTtr(String ttr) {
        this.ttr = ttr;
    }

}
