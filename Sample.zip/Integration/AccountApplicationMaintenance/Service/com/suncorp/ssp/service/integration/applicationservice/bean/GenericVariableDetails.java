////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code GenericVariableDetails} is simple POJO for generic variable.
 * 
 * @author U384381
 * @since 15/04/2016
 * @version 1.0
 */
public class GenericVariableDetails {
    private String id;
    private String code;
    private String label;
    private String description;
    private ValueDetails values;

    /**
     * Accessor for property id.
     *
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     *
     * @param id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id;
    }

    /**
     * Accessor for property code.
     * 
     * @return code of type String
     */
    public String getCode() {
        return code;
    }

    /**
     * Mutator for property code.
     * 
     * @param code of type String
     */
    @XmlElement(name = "code")
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Accessor for property label.
     *
     * @return label of type String
     */
    public String getLabel() {
        return label;
    }

    /**
     * Mutator for property label.
     *
     * @param label of type String
     */
    @XmlElement(name = "label")
    public void setLabel(String label) {
        this.label = label;
    }

    /**
     * Accessor for property description.
     *
     * @return description of type String
     */
    public String getDescription() {
        return description;
    }

    /**
     * Mutator for property description.
     *
     * @param description of type String
     */
    @XmlElement(name = "description")
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Accessor for property values.
     *
     * @return values of type ValueDetails
     */
    public ValueDetails getValues() {
        return values;
    }

    /**
     * Mutator for property values.
     *
     * @param values of type ValueDetails
     */
    @XmlElement(name = "values")
    public void setValues(ValueDetails values) {
        this.values = values;
    }

}
