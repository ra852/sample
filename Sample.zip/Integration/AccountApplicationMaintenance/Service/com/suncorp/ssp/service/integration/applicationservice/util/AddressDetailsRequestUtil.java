////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.util;

import java.util.List;

import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.AddressDetailsType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CodeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CountryIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.StateIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.model.ModelOperationType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.applicationservice.ApplicationServiceConstants;
import com.suncorp.ssp.service.integration.applicationservice.bean.ClientAddressDetails;

/**
 * The class {@code AddressDetailsRequestUtil} does this.
 * @author U383847
 * @since 11/02/2016
 * @version 1.0
 */
public class AddressDetailsRequestUtil {
    private final String className = "AddressDetailsRequestUtil";
    
    /**
     * Extracts values from address details of client and set the values to external service's request object.
     * 
     * @param clientEntityType
     * @param addressTypeList
     */
    public void setAddressDetails(List<AddressDetailsType> address, List<ClientAddressDetails> addressTypeList) throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Client Address Details");
        for (ClientAddressDetails clientAddressType : addressTypeList) {
            AddressDetailsType addressDetailsTypeObj = new AddressDetailsType();
            if (clientAddressType.getAddressId() != null) {
                setAddressId(clientAddressType, addressDetailsTypeObj);
            }
            if (checkAddressOperation(clientAddressType, addressDetailsTypeObj, address)) {
                continue;
            }
            setAddressDetailsType(clientAddressType, addressDetailsTypeObj, address);
        }
    }

    /**
     * Set Address Id Details.
     * 
     * @param clientAddressTypeObj
     * @param addressDetailsTypeObj
     */
    private void setAddressId(ClientAddressDetails clientAddressTypeObj, AddressDetailsType addressDetailsTypeObj) throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Address Id");
        Long addressId = null;
        try {
            addressId = Long.parseLong(clientAddressTypeObj.getAddressId());
        } catch (NumberFormatException exception) {
            throw new SILException(ApplicationServiceConstants.INVALID_ADDRESS_ID_FORMAT);
        }
        addressDetailsTypeObj.setId(addressId);
    }

    /**
     * Check for Address Operation.
     * 
     * @param clientAddressTypeObj
     * @param addressDetailsTypeObj
     * @param address
     * @return type boolean
     */
    private boolean checkAddressOperation(ClientAddressDetails clientAddressTypeObj, AddressDetailsType addressDetailsTypeObj,
            List<AddressDetailsType> address) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Checking Address Operation");
        if (clientAddressTypeObj.getOperation() != null &&
                ModelOperationType.DELETE.equals(ModelOperationType.fromValue(clientAddressTypeObj.getOperation()))) {
            addressDetailsTypeObj.setOperation(ModelOperationType.fromValue(clientAddressTypeObj.getOperation()));
            address.add(addressDetailsTypeObj);
            return true;
        } else if (clientAddressTypeObj.getOperation() != null &&
                !ModelOperationType.DELETE.equals(ModelOperationType.fromValue(clientAddressTypeObj.getOperation()))) {
            addressDetailsTypeObj.setOperation(ModelOperationType.fromValue(clientAddressTypeObj.getOperation()));
        }
        return false;
    }

    /**
     * Set Address Type Details.
     * 
     * @param clientAddressTypeObj
     * @param addressDetailsTypeObj
     * @param address
     * @param addressTypeListObj
     */
    private void setAddressDetailsType(ClientAddressDetails clientAddressTypeObj, AddressDetailsType addressDetailsTypeObj,
            List<AddressDetailsType> address) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Address Type Details");
        setCommonAddressFields(clientAddressTypeObj, addressDetailsTypeObj);
        if (clientAddressTypeObj.getAddressCode() != null &&
                !clientAddressTypeObj.getAddressCode().equals(ApplicationServiceConstants.ADDRESS_EMAL_TYPE) &&
                !clientAddressTypeObj.getAddressCode().equals(ApplicationServiceConstants.ADDRESS_FAX_TYPE)) {
            CountryIdentifierType countryIdentifierTypeObj = setCountryIdentifierType(clientAddressTypeObj);
            StateIdentifierType stateIdentifierTypeObj = setStateIdentifierType(clientAddressTypeObj, countryIdentifierTypeObj);
            setAddressDetails(countryIdentifierTypeObj, stateIdentifierTypeObj, clientAddressTypeObj, addressDetailsTypeObj);
        }
        address.add(addressDetailsTypeObj);
    }

    /**
     * Set Common Address Fields.
     * 
     * @param clientAddressTypeObj
     * @param addressDetailsTypeObj
     */
    private void setCommonAddressFields(ClientAddressDetails clientAddressTypeObj, AddressDetailsType addressDetailsTypeObj) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Common Address Fields");
        CodeIdentifierType codeIdentifierTypeObj = new CodeIdentifierType();
        codeIdentifierTypeObj.setCode(clientAddressTypeObj.getAddressCode());
        codeIdentifierTypeObj.setCodeType(clientAddressTypeObj.getAddressCodeType());
        addressDetailsTypeObj.setTypeCode(codeIdentifierTypeObj);
        addressDetailsTypeObj.setPrimaryType(Boolean.parseBoolean(clientAddressTypeObj.getPrimaryType()));
        addressDetailsTypeObj.setPrimary(Boolean.parseBoolean(clientAddressTypeObj.getPrimaryFlag()));
        addressDetailsTypeObj.setLine1(clientAddressTypeObj.getLine1());
        addressDetailsTypeObj.setLine2(clientAddressTypeObj.getLine2());
        addressDetailsTypeObj.setLine3(clientAddressTypeObj.getLine3());
        addressDetailsTypeObj.setLine4(clientAddressTypeObj.getLine4());
        addressDetailsTypeObj.setDpid(clientAddressTypeObj.getDpid());
        addressDetailsTypeObj.setBarCode(clientAddressTypeObj.getBarCode());
        addressDetailsTypeObj.setCareOf(clientAddressTypeObj.getCareOf());
    }

    /**
     * Set Address Details.
     * 
     * @param countryIdentifierTypeObj
     * @param stateIdentifierTypeObj
     * @param clientAddressTypeObj
     * @param addressDetailsTypeObj
     */
    private void setAddressDetails(CountryIdentifierType countryIdentifierTypeObj, StateIdentifierType stateIdentifierTypeObj,
            ClientAddressDetails clientAddressTypeObj, AddressDetailsType addressDetailsTypeObj) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Address Details");
        if (stateIdentifierTypeObj != null) {
            addressDetailsTypeObj.setState(stateIdentifierTypeObj);
        }
        addressDetailsTypeObj.setCountry(countryIdentifierTypeObj);
        addressDetailsTypeObj.setSuburb(clientAddressTypeObj.getSuburb());
        addressDetailsTypeObj.setPostcode(clientAddressTypeObj.getPostcode());
        addressDetailsTypeObj.setCity(clientAddressTypeObj.getCity());
    }

    /**
     * Set Country Identifier Details.
     * 
     * @param clientAddressTypeObj
     * @return object type of CountryIdentifierType
     */
    private CountryIdentifierType setCountryIdentifierType(ClientAddressDetails clientAddressTypeObj) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Country Identifier Details");
        CountryIdentifierType countryIdentifierTypeObj = new CountryIdentifierType();
        countryIdentifierTypeObj.setCode(clientAddressTypeObj.getCountry());
        return countryIdentifierTypeObj;
    }

    /**
     * Set State Identifier Details.
     * 
     * @param clientAddressTypeObj
     * @param countryIdentifierTypeObj
     * @return object type of StateIdentifierType
     */
    private StateIdentifierType setStateIdentifierType(ClientAddressDetails clientAddressTypeObj, CountryIdentifierType countryIdentifierTypeObj) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting State Identifier Details");
        if (clientAddressTypeObj.getState() != null) {
            StateIdentifierType stateIdentifierTypeObj = new StateIdentifierType();
            stateIdentifierTypeObj.setCode(clientAddressTypeObj.getState());
            stateIdentifierTypeObj.setCountry(countryIdentifierTypeObj);
            return stateIdentifierTypeObj;
        }
        return null;
    }
}
