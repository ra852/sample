////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code AccountNumberDetails} does this.
 * @author U383847
 * @since 03/02/2016
 * @version 1.0
 */
public class AccountNumberDetails {
    private String accountNumber;
    private String productName;
    
    /**
     * Accessor for property accountNumber.
     * 
     * @return accountNumber of type String
     */
    public String getAccountNumber() {
        return accountNumber;
    }
    
    /**
     * Mutator for property accountNumber.
     * 
     * @return accountNumber of type String
     */
    @XmlElement(name = "accountNumber")
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber != null ? accountNumber : "";
    }
    
    /**
     * Accessor for property productName.
     * 
     * @return productName of type String
     */
    public String getProductName() {
        return productName;
    }
    
    /**
     * Mutator for property productName.
     * 
     * @return productName of type String
     */
    @XmlElement(name = "productName")
    public void setProductName(String productName) {
        this.productName = productName != null ? productName : "";
    }
}
