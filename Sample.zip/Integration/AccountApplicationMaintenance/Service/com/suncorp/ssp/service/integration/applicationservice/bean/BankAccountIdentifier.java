////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code BankAccountIdentifier} does this.
 * 
 * @author U386868
 * @since 28/01/2016
 * @version 1.0
 */
public class BankAccountIdentifier {

    private String id;
    private String name;
    private String bankAccountNumber;
    private String bankAccountTypeCode;
    private CodeNameIdentifier bankAccountCurrencyCode;
    private AuditDetails audit;

    /**
     * Accessor for property id.
     * 
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     * 
     * @return id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id != null ? id : "";
    }

    /**
     * Accessor for property name.
     * 
     * @return name of type String
     */
    public String getName() {
        return name;
    }

    /**
     * Mutator for property name.
     * 
     * @return name of type String
     */
    @XmlElement(name = "name")
    public void setName(String name) {
        this.name = name != null ? name : "";
    }

    /**
     * Accessor for property bankAccountNumber.
     * 
     * @return bankAccountNumber of type String
     */
    public String getBankAccountNumber() {
        return bankAccountNumber;
    }

    /**
     * Mutator for property bankAccountNumber.
     * 
     * @return bankAccountNumber of type String
     */
    @XmlElement(name = "bankAccountNumber")
    public void setBankAccountNumber(String bankAccountNumber) {
        this.bankAccountNumber = bankAccountNumber != null ? bankAccountNumber : "";
    }

    /**
     * Accessor for property bankAccountTypeCode.
     * 
     * @return bankAccountTypeCode of type String
     */
    public String getBankAccountTypeCode() {
        return bankAccountTypeCode;
    }

    /**
     * Mutator for property bankAccountTypeCode.
     * 
     * @return bankAccountTypeCode of type String
     */
    @XmlElement(name = "bankAccountTypeCode")
    public void setBankAccountTypeCode(String bankAccountTypeCode) {
        this.bankAccountTypeCode = bankAccountTypeCode != null ? bankAccountTypeCode : "";
    }

    /**
     * Accessor for property bankAccountCurrencyCode.
     * 
     * @return bankAccountCurrencyCode of type CodeNameIdentifier
     */
    public CodeNameIdentifier getBankAccountCurrencyCode() {
        return bankAccountCurrencyCode;
    }

    /**
     * Mutator for property bankAccountCurrencyCode.
     * 
     * @return bankAccountCurrencyCode of type CodeNameIdentifier
     */
    @XmlElement(name = "bankAccountCurrencyCode")
    public void setBankAccountCurrencyCode(CodeNameIdentifier bankAccountCurrencyCode) {
        this.bankAccountCurrencyCode = bankAccountCurrencyCode;
    }

    /**
     * Accessor for property audit.
     * 
     * @return audit of type AuditDetails
     */
    public AuditDetails getAudit() {
        return audit;
    }

    /**
     * Mutator for property audit.
     * 
     * @return audit of type AuditDetails
     */
    @XmlElement(name = "audit")
    public void setAudit(AuditDetails audit) {
        this.audit = audit;
    }
}
