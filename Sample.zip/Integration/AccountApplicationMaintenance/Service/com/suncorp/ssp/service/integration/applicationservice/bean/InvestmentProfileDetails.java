////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code InvestmentProfileDetails} does this.
 * @author U383847
 * @since 28/01/2016
 * @version 1.0
 */
public class InvestmentProfileDetails {
    private AccountProfileLinkDetails accountProfileLinkDetails;
    private ProfileFunctionDetails profileFunctionDetails;
    private ProfileDetails profileDetails;
    private String sameAsDefaultInvestmentProfile;
    private String totalAmount;
    private String clearAllFunds;
    private CodeIdentifierDetails patternMethod;
    private CodeIdentifierDetails overrideCode;
    private List<FundDetails> fundDetails;
    
    /**
     * Accessor for property accountProfileLinkDetails.
     * 
     * @return accountProfileLink of type AccountProfileLinkDetails
     */
    public AccountProfileLinkDetails getAccountProfileLinkDetails() {
        return accountProfileLinkDetails;
    }
    
    /**
     * Mutator for property accountProfileLinkDetails.
     * 
     * @return accountProfileLink of type AccountProfileLinkDetails
     */
    @XmlElement(name = "accountProfileLinkDetails")
    public void setAccountProfileLinkDetails(AccountProfileLinkDetails accountProfileLinkDetails) {
        this.accountProfileLinkDetails = accountProfileLinkDetails;
    }
    
    /**
     * Accessor for property profileFunction.
     * 
     * @return profileFunction of type ProfileFunctionDetails
     */
    public ProfileFunctionDetails getProfileFunctionDetails() {
        return profileFunctionDetails;
    }
    
    /**
     * Mutator for property profileFunction.
     * 
     * @return profileFunction of type ProfileFunctionDetails
     */
    @XmlElement(name = "profileFunctionDetails")
    public void setProfileFunctionDetails(ProfileFunctionDetails profileFunctionDetails) {
        this.profileFunctionDetails = profileFunctionDetails;
    }
    
    /**
     * Accessor for property profileDetails.
     * 
     * @return profile of type ProfileDetails
     */
    public ProfileDetails getProfileDetails() {
        return profileDetails;
    }
    
    /**
     * Mutator for property profileDetails.
     * 
     * @return profile of type ProfileDetails
     */
    @XmlElement(name = "profileDetails")
    public void setProfileDetails(ProfileDetails profileDetails) {
        this.profileDetails = profileDetails;
    }
    
    /**
     * Accessor for property sameAsDefaultInvestmentProfile.
     * 
     * @return sameAsDefaultInvestmentProfile of type String
     */
    public String getSameAsDefaultInvestmentProfile() {
        return sameAsDefaultInvestmentProfile;
    }

    /**
     * Mutator for property sameAsDefaultInvestmentProfile.
     * 
     * @return sameAsDefaultInvestmentProfile of type String
     */
    @XmlElement(name = "sameAsDefaultInvestmentProfile")
    public void setSameAsDefaultInvestmentProfile(String sameAsDefaultInvestmentProfile) {
        this.sameAsDefaultInvestmentProfile = sameAsDefaultInvestmentProfile != null ? sameAsDefaultInvestmentProfile : "";
    }
    
    /**
     * Accessor for property totalAmount.
     * 
     * @return totalAmount of type String
     */
    public String getTotalAmount() {
        return totalAmount;
    }

    /**
     * Mutator for property totalAmount.
     * 
     * @return totalAmount of type String
     */
    @XmlElement(name = "totalAmount")
    public void setTotalAmount(String totalAmount) {
        this.totalAmount = totalAmount;
    }

    /**
     * Accessor for property clearAllFunds.
     * 
     * @return clearAllFunds of type String
     */
    public String getClearAllFunds() {
        return clearAllFunds;
    }

    /**
     * Mutator for property clearAllFunds.
     * 
     * @return clearAllFunds of type String
     */
    @XmlElement(name = "clearAllFunds")
    public void setClearAllFunds(String clearAllFunds) {
        this.clearAllFunds = clearAllFunds;
    }
    
    /**
     * Accessor for property patternMethod.
     * 
     * @return patternMethod of type CodeIdentifierDetails
     */
    public CodeIdentifierDetails getPatternMethod() {
        return patternMethod;
    }
    
    /**
     * Mutator for property patternMethod.
     * 
     * @return patternMethod of type CodeIdentifierDetails
     */
    @XmlElement(name = "patternMethodDetails")
    public void setPatternMethod(CodeIdentifierDetails patternMethod) {
        this.patternMethod = patternMethod;
    }
    
    /**
     * Accessor for property overrideCode.
     * 
     * @return overrideCode of type CodeIdentifierDetails
     */
    public CodeIdentifierDetails getOverrideCode() {
        return overrideCode;
    }

    /**
     * Mutator for property overrideCode.
     * 
     * @return overrideCode of type CodeIdentifierDetails
     */
    @XmlElement(name = "overrideCodeDetails")
    public void setOverrideCode(CodeIdentifierDetails overrideCode) {
        this.overrideCode = overrideCode;
    }
    
    /**
     * Accessor for property fundDetails.
     * 
     * @return fundDetails of type List<FundDetails>
     */
    public List<FundDetails> getFundDetails() {
        return fundDetails;
    }

    /**
     * Mutator for property fundDetails.
     * 
     * @return fundDetails of type List<FundDetails>
     */
    @XmlElement(name = "fundDetails")
    public void setFundDetails(List<FundDetails> fundDetails) {
        this.fundDetails = fundDetails;
    }
}
