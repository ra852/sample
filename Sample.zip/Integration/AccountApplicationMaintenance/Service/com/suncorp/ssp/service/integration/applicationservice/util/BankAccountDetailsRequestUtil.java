////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.util;

import java.math.BigInteger;
import java.util.List;

import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.BankAccountType.ExpiryDate;
import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.ClientEntityType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CodeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CountryIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CurrencyIdentifierType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.applicationservice.ApplicationServiceConstants;
import com.suncorp.ssp.service.integration.applicationservice.bean.BankAccountDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.CodeIdentifierDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.CodeNameIdentifier;
import com.suncorp.ssp.service.integration.applicationservice.bean.ExpiryDateInfo;

/**
 * The class {@code BankAccountDetailsRequestUtil} is used as a util class for preparing Bank Account Details for CreateAccountApplication service.
 * 
 * @author U386868
 * @since 09/02/2016
 * @version 1.0
 */
public class BankAccountDetailsRequestUtil {
    private String className = "BankAccountDetailsRequestUtil";

    /**
     * Set Client Bank Account Details, with necessary values set.
     * 
     * @param bankAccount of type BankAccountType
     * @param bankTypeList of type BankAccountDetails
     */
    public void setClientBankAccountDetails(List<ClientEntityType.BankAccount> bankAccount, List<BankAccountDetails> bankTypeList)
            throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Client Account Details");
        for (BankAccountDetails accountDetails : bankTypeList) {
            ClientEntityType.BankAccount accountDetailType = new ClientEntityType.BankAccount();
            if (accountDetails.getId() != null) {
                accountDetailType.setId(createClientAccountId(accountDetails.getId()));
            }
            if (accountDetails.getAccountName() != null) {
                accountDetailType.setAccountName(accountDetails.getAccountName());
            }
            if (accountDetails.getAccountNumber() != null) {
                accountDetailType.setAccountNumber(accountDetails.getAccountNumber());
            }
            if (accountDetails.getCountry() != null) {
                accountDetailType.setCountry(createCountryIdentifier(accountDetails.getCountry()));
            }
            if (accountDetails.getCurrency() != null) {
                accountDetailType.setCurrency(createCurrencyIdentifier(accountDetails.getCurrency()));
            }
            accountDetailType = setClientBankDetails(accountDetailType, accountDetails);
            bankAccount.add(accountDetailType);
        }
    }

    /**
     * This method is used to create ClientAccountId, with necessary value set.
     * 
     * @param id of type String
     * @return accountId of type Long
     * @throws SILException
     */
    private Long createClientAccountId(String id) throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "createClientAccountId()");
        Long accountId;
        try {
            accountId = Long.parseLong(id);
        } catch (Exception ex) {
            throw new SILException(ApplicationServiceConstants.INVALID_ACCOUNT_ID_FORMAT);
        }
        return accountId;
    }

    /**
     * This method is used to Set Client Bank Details, with necessary values set.
     * 
     * @param accountDetailType of type ClientEntityType.BankAccount
     * @param accountDetails of type BankAccountDetails
     * @return bankAccountType of type BankAccountDetailType
     * @throws SILException
     */
    private ClientEntityType.BankAccount setClientBankDetails(ClientEntityType.BankAccount accountDetailType, BankAccountDetails accountDetails)
            throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Client Bank Details");
        if (accountDetails.getBankOtherPayRef() != null) {
            accountDetailType.setBankOtherPayRef(accountDetails.getBankOtherPayRef());
        }
        if (accountDetails.getExpiryDate() != null) {
            accountDetailType.setExpiryDate(createExpiryDateInfo(accountDetails.getExpiryDate()));
        }
        if (accountDetails.getTypeCode() != null) {
            accountDetailType.setTypeCode(createCodeIdentifier(accountDetails.getTypeCode()));
        }
        return accountDetailType;
    }

    /**
     * This method is used to create ExpiryDateInfo, with necessary values set.
     * 
     * @param expiryDateInfo of type ExpiryDateInfo
     * @return expiryDate of type ExpiryDate
     * @throws SILException
     */
    private ExpiryDate createExpiryDateInfo(ExpiryDateInfo expiryDateInfo) throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "createExpiryDateInfo()");
        ExpiryDate expiryDate = new ExpiryDate();
        if (expiryDateInfo.getMonth() != null) {
            try {
                expiryDate.setMonth(new BigInteger(expiryDateInfo.getMonth()));
            } catch (Exception ex) {
                throw new SILException(ApplicationServiceConstants.INVALID_MONTH_FORMAT);
            }
        }
        if (expiryDateInfo.getYear() != null) {
            try {
                expiryDate.setYear(new BigInteger(expiryDateInfo.getYear()));
            } catch (Exception ex) {
                throw new SILException(ApplicationServiceConstants.INVALID_YEAR_FORMAT);
            }
        }
        return expiryDate;
    }

    /**
     * This method is used to create CodeIdentifier, with necessary values set.
     * 
     * @param typeCode of type CodeIdentifierDetails
     * @return codeIdentifierType of type CodeIdentifierType
     * @throws SILException
     */
    private CodeIdentifierType createCodeIdentifier(CodeIdentifierDetails typeCode) throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "createTypeCode()");
        CodeIdentifierType codeIdentifierType = new CodeIdentifierType();
        if (typeCode.getCode() != null) {
            codeIdentifierType.setCode(typeCode.getCode());
        }
        if (typeCode.getCodeDescription() != null) {
            codeIdentifierType.setCodeDescription(typeCode.getCodeDescription());
        }
        if (typeCode.getCodeShortDescription() != null) {
            codeIdentifierType.setCodeShortDescription(typeCode.getCodeShortDescription());
        }
        if (typeCode.getCodeType() != null) {
            codeIdentifierType.setCodeType(typeCode.getCodeType());
        }
        if (typeCode.getId() != null) {
            try {
                codeIdentifierType.setId(Long.parseLong(typeCode.getId()));
            } catch (Exception ex) {
                throw new SILException(ApplicationServiceConstants.INVALID_TYPECODE_ID_FORMAT);
            }
        }
        return codeIdentifierType;
    }

    /**
     * This method is used to create CurrencyIdentifier Details, with necessary values set.
     * 
     * @param currency of type CodeNameIdentifier
     * @return countryIdentifierType of type CurrencyIdentifierType
     * @throws SILException
     */
    private CurrencyIdentifierType createCurrencyIdentifier(CodeNameIdentifier currency) throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "createCurrencyIdentifier()");
        CurrencyIdentifierType countryIdentifierType = new CurrencyIdentifierType();
        if (currency.getCode() != null) {
            countryIdentifierType.setCode(currency.getCode());
        }
        if (currency.getName() != null) {
            countryIdentifierType.setCode(currency.getName());
        }
        if (currency.getId() != null) {
            try {
                countryIdentifierType.setId(Long.parseLong(currency.getId()));
            } catch (Exception exception) {
                throw new SILException(ApplicationServiceConstants.INVALID_CURRENCY_ID_FORMAT);
            }
        }
        return countryIdentifierType;
    }

    /**
     * This method is used to create CountryIdentifier Details, with necessary values set.
     * 
     * @param codeNameIdentifier of type CodeNameIdentifier
     * @return countryIdentifierType of type CountryIdentifierType
     * @throws SILException
     */
    private CountryIdentifierType createCountryIdentifier(CodeNameIdentifier codeNameIdentifier) throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "createCountryIdentifier()");
        CountryIdentifierType countryIdentifierType = new CountryIdentifierType();
        if (codeNameIdentifier.getCode() != null) {
            countryIdentifierType.setCode(codeNameIdentifier.getCode());
        }
        if (codeNameIdentifier.getName() != null) {
            countryIdentifierType.setCode(codeNameIdentifier.getName());
        }
        if (codeNameIdentifier.getId() != null) {
            try {
                countryIdentifierType.setId(Long.parseLong(codeNameIdentifier.getId()));
            } catch (Exception exception) {
                throw new SILException(ApplicationServiceConstants.INVALID_COUNTRY_ID_FORMAT);
            }
        }
        return countryIdentifierType;
    }
}
