////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code ExpenseParameterDetails} does this.
 * 
 * @author U383847
 * @since 09/02/2016
 * @version 1.0
 */
public class ExpenseParameterDetails {
    private TierDetails tier;
    private String amount;
    private String percentage;
    private AuditDetails audit;
    
    /**
     * Accessor for property tier.
     * 
     * @return tier of type TierDetails
     */
    public TierDetails getTier() {
        return tier;
    }

    /**
     * Mutator for property tier.
     * 
     * @return tier of type TierDetails
     */
    @XmlElement(name = "tier")
    public void setTier(TierDetails tier) {
        this.tier = tier;
    }

    /**
     * Accessor for property amount.
     * 
     * @return amount of type String
     */
    public String getAmount() {
        return amount;
    }
    
    /**
     * Mutator for property amount.
     * 
     * @return amount of type String
     */
    @XmlElement(name = "amount")
    public void setAmount(String amount) {
        this.amount = amount != null ? amount : "";
    }
    
    /**
     * Accessor for property percentage.
     * 
     * @return percentage of type String
     */
    public String getPercentage() {
        return percentage;
    }
    
    /**
     * Mutator for property percentage.
     * 
     * @return percentage of type String
     */
    @XmlElement(name = "percentage")
    public void setPercentage(String percentage) {
        this.percentage = percentage != null ? percentage : "";
    }

    /**
     * Accessor for property audit.
     * 
     * @return audit of type AuditDetails
     */
    public AuditDetails getAudit() {
        return audit;
    }

    /**
     * Mutator for property audit.
     * 
     * @return audit of type AuditDetails
     */
    public void setAudit(AuditDetails audit) {
        this.audit = audit;
    }
}
