////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code FrequencyIdentifier} does this.
 * @author u385424
 * @since 16/02/2016
 * @version 1.0
 */
public class FrequencyIdentifierDetails {
    private String freqCode;

    /**
     * Accessor for property freqCode.
     * @return freqCode of type String
     */
    public String getFreqCode() {
        return freqCode;
    }

    /**
     * Mutator for property freqCode.
     * @return freqCode of type String
     */
    @XmlElement(name = "freqCode")
    public void setFreqCode(String freqCode) {
        this.freqCode = freqCode;
    }

}
