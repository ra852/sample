////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code MarketingCampaignDetails} is a java bean consisting of properties related to Marketing Campaign Details.
 * 
 * @author U383847
 * @since 06/01/2016
 * @version 1.0
 */
public class MarketingCampaignDetails {
    private String marketingCampaignName;
    private String marketingCampaignCode;
    
    /**
     * Accessor for property marketingCampaignName.
     * 
     * @return marketingCampaignName of type String
     */
    public String getMarketingCampaignName() {
        return marketingCampaignName;
    }
    
    /**
     * Mutator for property marketingCampaignName.
     * 
     * @param marketingCampaignName of type String
     */
    @XmlElement(name = "marketingCampaignName")
    public void setMarketingCampaignName(String marketingCampaignName) {
        this.marketingCampaignName = marketingCampaignName != null ? marketingCampaignName : "";
    }
    
    /**
     * Accessor for property marketingCampaignCode.
     * 
     * @return marketingCampaignCode of type String
     */
    public String getMarketingCampaignCode() {
        return marketingCampaignCode;
    }
    
    /**
     * Mutator for property marketingCampaignCode.
     * 
     * @param marketingCampaignCode of type String
     */
    @XmlElement(name = "marketingCampaignCode")
    public void setMarketingCampaignCode(String marketingCampaignCode) {
        this.marketingCampaignCode = marketingCampaignCode != null ? marketingCampaignCode : "";
    }
}
