////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code ProductDetails} is a java bean consisting of properties related to Product Details.
 * 
 * @author U383847
 * @since 06/01/2016
 * @version 1.0
 */
public class ProductDetails {
    private String productName;
    private String productId;

    /**
     * Accessor for property productName.
     * 
     * @return productName of type String
     */
    public String getProductName() {
        return productName;
    }

    /**
     * Mutator for property productName.
     * 
     * @param productName of type String
     */
    @XmlElement(name = "productName")
    public void setProductName(String productName) {
        this.productName = productName != null ? productName : "";
    }

    /**
     * Accessor for property productId.
     * 
     * @return productId of type String
     */
    public String getProductId() {
        return productId;
    }

    /**
     * Mutator for property productId.
     * 
     * @return productId of type String
     */
    @XmlElement(name = "productId")
    public void setProductId(String productId) {
        this.productId = productId != null ? productId : "";
    }
}
