////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code FundIdentifierDetails} does this.
 * @author U383847
 * @since 01/02/2016
 * @version 1.0
 */
public class FundIdentifierDetails {
    private String id;
    private String name;
    private String fundFullName;
    private String fundCorrespondenceName;
    private String amount;
    private String sequence;
    private FundExternalReferenceDetails fundExternalReference;
    private AuditDetails auditDetails;
    private CodeIdentifierDetails fundType;
    
    /**
     * Accessor for property id.
     * 
     * @return id of type String
     */
    public String getId() {
        return id;
    }
    
    /**
     * Mutator for property id.
     * 
     * @return id of type String
     */
    @XmlElement(name = "fundId")
    public void setId(String id) {
        this.id = id != null ? id : "";
    }
    
    /**
     * Accessor for property name.
     * 
     * @return name of type String
     */
    public String getName() {
        return name;
    }

    /**
     * Mutator for property name.
     * 
     * @return name of type String
     */
    @XmlElement(name = "fundName")
    public void setName(String name) {
        this.name = name != null ? name : "";
    }

    /**
     * Accessor for property fundFullName.
     * 
     * @return fundFullName of type String
     */
    public String getFundFullName() {
        return fundFullName;
    }

    /**
     * Mutator for property fundFullName.
     * 
     * @return fundFullName of type String
     */
    @XmlElement(name = "fundFullName")
    public void setFundFullName(String fundFullName) {
        this.fundFullName = fundFullName != null ? fundFullName : "";
    }

    /**
     * Accessor for property funcCorrespondenceName.
     * 
     * @return funcCorrespondenceName of type String
     */
    public String getFundCorrespondenceName() {
        return fundCorrespondenceName;
    }

    /**
     * Mutator for property funcCorrespondenceName.
     * 
     * @return funcCorrespondenceName of type String
     */
    @XmlElement(name = "fundCorrespondenceName")
    public void setFundCorrespondenceName(String fundCorrespondenceName) {
        this.fundCorrespondenceName = fundCorrespondenceName != null ? fundCorrespondenceName : "";
    }

    /**
     * Accessor for property amount.
     * 
     * @return amount of type String
     */
    @XmlElement(name = "fundAmount")
    public String getAmount() {
        return amount;
    }

    /**
     * Mutator for property amount.
     * 
     * @return amount of type String
     */
    public void setAmount(String amount) {
        this.amount = amount;
    }

    /**
     * Accessor for property sequence.
     * 
     * @return sequence of type String
     */
    @XmlElement(name = "fundSequence")
    public String getSequence() {
        return sequence;
    }

    /**
     * Mutator for property sequence.
     * @return sequence of type String
     */
    public void setSequence(String sequence) {
        this.sequence = sequence;
    }
    
    /**
     * Accessor for property fundExternalReference.
     * 
     * @return fundExternalReference of type FundExternalReferenceDetails
     */
    public FundExternalReferenceDetails getFundExternalReference() {
        return fundExternalReference;
    }

    /**
     * Mutator for property fundExternalReference.
     * 
     * @return fundExternalReference of type FundExternalReferenceDetails
     */
    @XmlElement(name = "fundExternalReferenceDetails")
    public void setFundExternalReference(FundExternalReferenceDetails fundExternalReference) {
        this.fundExternalReference = fundExternalReference;
    }

    /**
     * Accessor for property auditDetails.
     * 
     * @return auditDetails of type AuditDetails
     */
    public AuditDetails getAuditDetails() {
        return auditDetails;
    }

    /**
     * Mutator for property auditDetails.
     * 
     * @return auditDetails of type AuditDetails
     */
    @XmlElement(name = "fundAuditDetails")
    public void setAuditDetails(AuditDetails auditDetails) {
        this.auditDetails = auditDetails;
    }

    /**
     * Accessor for property fundType.
     * 
     * @return fundType of type CodeIdentifierDetails
     */
    public CodeIdentifierDetails getFundType() {
        return fundType;
    }

    /**
     * Mutator for property fundType.
     * 
     * @return fundType of type CodeIdentifierDetails
     */
    @XmlElement(name = "fundTypeDetails")
    public void setFundType(CodeIdentifierDetails fundType) {
        this.fundType = fundType;
    }
}
