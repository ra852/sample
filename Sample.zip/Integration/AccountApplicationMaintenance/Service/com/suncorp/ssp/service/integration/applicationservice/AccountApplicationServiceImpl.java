////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice;

import javax.ws.rs.core.Response;

import com.suncorp.ssp.service.integration.applicationservice.bean.AccountApplicationRequest;

/**
 * The class {@code AccountApplicationServiceImpl} does this.
 * 
 * @author U383847
 * @since 19/01/2016
 * @version 1.0
 */
public class AccountApplicationServiceImpl implements AccountApplicationService {

    /**
     * Default constructor.
     */
    public AccountApplicationServiceImpl() {

    }

    /**
     * Fetches new AccountApplicationResponse bean.
     * 
     * @param accountApplicationRequest
     * @return object of type AccountApplicationResponse
     */
    public Response createaccountapplication(AccountApplicationRequest accountApplicationRequest) {
        return null;
    }
}
