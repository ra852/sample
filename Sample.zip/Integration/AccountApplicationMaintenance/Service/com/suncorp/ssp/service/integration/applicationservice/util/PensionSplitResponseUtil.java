////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.util;

import java.math.BigDecimal;
import java.util.List;

import javax.xml.datatype.XMLGregorianCalendar;

import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.ClientIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CodeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountTaxType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.PensionPaymentSplitType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.PensionPaymentSplitType.PaymentSplit;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.constants.applicationservice.ApplicationServiceConstants;
import com.suncorp.ssp.service.integration.applicationservice.bean.AccountTaxDetail;
import com.suncorp.ssp.service.integration.applicationservice.bean.ClientDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.CodeIdentifierDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.PaymentSplitInfo;
import com.suncorp.ssp.service.integration.applicationservice.bean.PensionPaymentSplitDetails;

/**
 * The class {@code PensionSplitResponseUtil} is an util class use to map the response in response bean.
 * 
 * @author u385424
 * @since 18/02/2016
 * @version 1.0
 */
public class PensionSplitResponseUtil {
    private final String className = "PensionSplitResponseUtil";

    /**
     * Get Pension Payment Split Details.
     * 
     * @param pensionPaymentSplitList
     * @param pensionPaymentSplitType
     */
    public void addPensionPaymentSplitDetails(List<PensionPaymentSplitDetails> pensionPaymentSplitList,
            PensionPaymentSplitType pensionPaymentSplitType) {
        if (pensionPaymentSplitType != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "addPensionPaymentSplitDetails");
            PensionPaymentSplitDetails outbounbdResponse = new PensionPaymentSplitDetails();
            outbounbdResponse.setEffectiveDate(retrieveDate(pensionPaymentSplitType.getEffectiveDate()));
            outbounbdResponse.setClient(retrieveClientDetails(pensionPaymentSplitType.getClient()));
            outbounbdResponse.setId(retrieveLong(pensionPaymentSplitType.getId()));
            outbounbdResponse.setFixedAmount(retrieveBoolean(pensionPaymentSplitType.isFixedAmount()));
            outbounbdResponse.setDefaultPayee(retrieveBoolean(pensionPaymentSplitType.isDefaultPayee()));
            outbounbdResponse.setPaymentSplit(retrievePaymentSplit(pensionPaymentSplitType.getPaymentSplit()));
            outbounbdResponse.setPaymentMethodCode(retrieveCodeIdentifier(pensionPaymentSplitType.getPaymentMethodCode()));
            outbounbdResponse.setBankAccountCardNumber(retrieveString(pensionPaymentSplitType.getBankAccountCardNumber()));
            pensionPaymentSplitList.add(outbounbdResponse);
        }
    }

    /**
     * Get Account Tax Details.
     * 
     * @param accountTaxType
     * @param accountTaxDetail
     */
    public void getAccountTaxDetail(AccountTaxType accountTaxType, AccountTaxDetail accountTaxDetail) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "getAccountTaxDetail");
        accountTaxDetail.setDeductMedicareSurcharge(retrieveBoolean(accountTaxType.isDeductMedicareSurcharge()));
        accountTaxDetail.setDependantSpouse(retrieveBoolean(accountTaxType.isDependantSpouse()));
        accountTaxDetail.setIncludeInvalidity(retrieveBoolean(accountTaxType.isIncludeInvalidity()));
        accountTaxDetail.setMedicareLevyReduction(retrieveBoolean(accountTaxType.isMedicareLevyReduction()));
        accountTaxDetail.setNumberOfDependantChildren(retrieveLong(accountTaxType.getNumberOfDependantChildren()));
        accountTaxDetail.setRebatableProportion(retrieveBigDecimal(accountTaxType.getRebatableProportion()));
        accountTaxDetail.setTaxOffsetAmount(retrieveBigDecimal(accountTaxType.getTaxOffsetAmount()));
        accountTaxDetail.setTaxScale(retrieveCodeIdentifier(accountTaxType.getTaxScale()));
    }

    /**
     * Create Default Pension Split.
     * 
     * @param pensionPaymentSplit
     */
    public void createDefaultPensionSplit(PensionPaymentSplitDetails pensionPaymentSplit) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "createDefaultPensionSplit");
        pensionPaymentSplit.setBankAccountCardNumber("");
        pensionPaymentSplit.setDefaultPayee("");
        pensionPaymentSplit.setEffectiveDate("");
        pensionPaymentSplit.setFixedAmount("");
        pensionPaymentSplit.setId("");
        pensionPaymentSplit.setPaymentMethodCode(new AccountApplicationUtil().createDefaultCodeIdentifierInfo());
        pensionPaymentSplit.setPaymentSplit(createDefaultPaymentSplit());
    }

    /**
     * Create Default Account Tax Details.
     * 
     * @param accountTaxDetail
     */
    public void setDefaultAccountTaxDetail(AccountTaxDetail accountTaxDetail) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "setDefaultAccountTaxDetail");
        accountTaxDetail.setDeductMedicareSurcharge("");
        accountTaxDetail.setDependantSpouse("");
        accountTaxDetail.setIncludeInvalidity("");
        accountTaxDetail.setMedicareLevyReduction("");
        accountTaxDetail.setNumberOfDependantChildren("");
        accountTaxDetail.setRebatableProportion("");
        accountTaxDetail.setTaxOffsetAmount("");
        accountTaxDetail.setTaxScale(new AccountApplicationUtil().createDefaultCodeIdentifierInfo());
    }

    /**
     * Create Default Payment Info.
     * 
     * @return
     */
    private PaymentSplitInfo createDefaultPaymentSplit() {
        PaymentSplitInfo paymentSplitInfo = new PaymentSplitInfo();
        paymentSplitInfo.setAmount("");
        paymentSplitInfo.setPercentage("");
        return paymentSplitInfo;
    }

    /**
     * Retrieve Long.
     * 
     * @param id
     * @return value
     */
    private String retrieveLong(Long value) {
        if (value != null) {
            return value.toString();
        }
        return "";
    }

    /**
     * Retrieve Date.
     * 
     * @param effectiveDate
     * @return value
     */
    private String retrieveDate(XMLGregorianCalendar value) {
        if (value != null) {
            return value.toString();
        }
        return "";
    }

    /**
     * Retrieve PaymentSplit.
     * 
     * @param paymentSplit
     * @return paymentSplitInfo
     */
    private PaymentSplitInfo retrievePaymentSplit(PaymentSplit paymentSplit) {
        PaymentSplitInfo paymentSplitInfo = new PaymentSplitInfo();
        if (paymentSplit != null) {
            if (paymentSplit.getAmount() != null) {
                paymentSplitInfo.setAmount(paymentSplit.getAmount().toString());
            } else {
                paymentSplitInfo.setAmount("");
            }
            if (paymentSplit.getPercentage() != null) {
                paymentSplitInfo.setPercentage(paymentSplit.getPercentage().toString());
            } else {
                paymentSplitInfo.setPercentage("");
            }
        } else {
            createDefaultPaymentSplit();
        }
        return paymentSplitInfo;
    }

    /**
     * Retrieve String.
     * 
     * @param bankAccountCardNumber
     * @return
     */
    private String retrieveString(String value) {
        if (value != null) {
            return value;
        }
        return "";
    }

    /**
     * Retrieve CodeIdentifier.
     * 
     * @param taxScale
     * @return codeIdentifier
     */
    private CodeIdentifierDetails retrieveCodeIdentifier(CodeIdentifierType codeIdentifierType) {
        CodeIdentifierDetails codeIdentifier = new CodeIdentifierDetails();
        if (codeIdentifierType != null) {
            codeIdentifier.setId(retrieveLong(codeIdentifierType.getId()));
            codeIdentifier.setCode(retrieveString(codeIdentifierType.getCode()));
            codeIdentifier.setCodeType(retrieveString(codeIdentifierType.getCodeType()));
            codeIdentifier.setCodeShortDescription(retrieveString(codeIdentifierType.getCodeShortDescription()));
            codeIdentifier.setCodeDescription(retrieveString(codeIdentifierType.getCodeDescription()));
        } else {
            AccountApplicationUtil accountApplicationUtil = new AccountApplicationUtil();
            accountApplicationUtil.createDefaultCodeIdentifierInfo();
        }
        return codeIdentifier;
    }

    /**
     * This method retrieve ClientDetails.
     * 
     * @param advisorIdentifierType
     * @return client
     */
    private ClientDetails retrieveClientDetails(ClientIdentifierType clientIdentifierType) {
        ClientDetails client = new ClientDetails();
        if (clientIdentifierType != null) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveAdvisorDetails method");
            client.setClientId(retrieveLong(clientIdentifierType.getId()));
            client.setFirstName(clientIdentifierType.getClientForename());
            client.setSurname(clientIdentifierType.getClientSurname());
            client.setAudit(new AccountApplicationUtil().createAuditInfo(clientIdentifierType.getAudit()));
        } else {
            client = retrieveEmptyClient();
        }
        return client;
    }

    /**
     * This method constructs default ClientDetails.
     * 
     * @return client
     */
    private ClientDetails retrieveEmptyClient() {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveEmptyAdvisor method");
        ClientDetails client = new ClientDetails();
        client.setClientId("");
        client.setFirstName("");
        client.setSurname("");
        client.setAudit(new AccountApplicationUtil().createDefaultAuditInfo());
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveEmptyAdvisor method");
        return client;
    }

    /**
     * Retrieve BigDecimal.
     * 
     * @param rebatableProportion
     * @return
     */
    private String retrieveBigDecimal(BigDecimal value) {
        if (value != null) {
            return value.toString();
        }
        return "";
    }

    /**
     * retrieve Boolean.
     * 
     * @param deductMedicareSurcharge
     * @return
     */
    private String retrieveBoolean(Boolean value) {
        if (value != null) {
            return value.toString();
        }
        return "";
    }

}
