////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.util;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

import javax.xml.datatype.XMLGregorianCalendar;

import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CodeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.FrequencyIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.PensionPaymentDetailType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.PensionPaymentSplitType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.PensionPaymentSplitType.PaymentSplit;
import com.sonatacentral.service.v30.life.application.CreateApplicationRequestType.Client;
import com.sonatacentral.service.v30.wrap.application.AccountApplicationRequestType.Account;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.applicationservice.ApplicationServiceConstants;
import com.suncorp.ssp.service.integration.applicationservice.bean.AccountDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.CodeIdentifierDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.FrequencyIdentifierDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.PaymentSplitInfo;
import com.suncorp.ssp.service.integration.applicationservice.bean.PensionPaymentDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.PensionPaymentSplitDetails;

/**
 * The class {@code PensionPaymentDetailsUtil} is a util class use to set request for creating request for create Pension account and tax details.
 * 
 * @author u385424
 * @since 17/02/2016
 * @version 1.0
 */
public class PensionPaymentDetailsRequestUtil {
    private String className = "PensionPaymentDetailsUtil";

    /**
     * Set Pension Payment Details.
     * 
     * @param accountRequestDetailsType
     * @param pensionPaymentDetails
     * @throws SILException
     */
    public void setPensionPayment(Account accountRequestDetailsType, PensionPaymentDetails pensionPaymentDetails)
            throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "setPensionPayment()");
        PensionPaymentDetailType pensionPaymentDetailType = new PensionPaymentDetailType();
        pensionPaymentDetailType.setEffectiveDate(retrieveDate(pensionPaymentDetails.getEffectiveDate()));
        pensionPaymentDetailType.setPaymentFrequency(retrieveFrequencyIdentifier(pensionPaymentDetails.getPaymentFrequency()));
        pensionPaymentDetailType.setNumberOfPayments(retrieveLong(pensionPaymentDetails.getNumberOfPayments()));
        pensionPaymentDetailType.setPensionPaymentRule(retrieveCodeIdentifier(pensionPaymentDetails.getPensionPaymentRule()));
        pensionPaymentDetailType.setReviewType(retrieveCodeIdentifier(pensionPaymentDetails.getReviewType()));
        pensionPaymentDetailType.setReviewFrequency(retrieveFrequencyIdentifier(pensionPaymentDetails.getReviewFrequency()));
        pensionPaymentDetailType.setTaxOverridePercent(retrieveBigDecimal(pensionPaymentDetails.getTaxOverridePercent()));
        pensionPaymentDetailType.setTaxFreeMethod(retrieveCodeIdentifier(pensionPaymentDetails.getTaxFreeMethod()));
        pensionPaymentDetailType.setRevAnnuitantRelationship(retrieveCodeIdentifier(pensionPaymentDetails.getRevAnnuitantRelationship()));
        setPensionPaymentParameters(accountRequestDetailsType, pensionPaymentDetails, pensionPaymentDetailType);
    }

    /**
     * Set Pension Payment Details.
     * 
     * @param accountRequestDetailsType
     * @param pensionPaymentDetails
     * @param pensionPaymentDetailType
     * @throws SILException
     */
    private void setPensionPaymentParameters(Account accountRequestDetailsType, PensionPaymentDetails pensionPaymentDetails,
            PensionPaymentDetailType pensionPaymentDetailType) throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "setPensionPaymentParameters()");
        pensionPaymentDetailType.setPensionStartDate(retrieveDate(pensionPaymentDetails.getPensionStartDate()));
        pensionPaymentDetailType.setPaymentDate1(retrieveBigInteger(pensionPaymentDetails.getPaymentDate1()));
        pensionPaymentDetailType.setPaymentDate2(retrieveBigInteger(pensionPaymentDetails.getPaymentDate2()));
        pensionPaymentDetailType.setNextPaymentDue(retrieveDate(pensionPaymentDetails.getNextPaymentDue()));
        pensionPaymentDetailType.setNominatedIndexRate(retrieveBigDecimal(pensionPaymentDetails.getNominatedIndexRate()));
        pensionPaymentDetailType.setAdditionalTax(retrieveBigDecimal(pensionPaymentDetails.getAdditionalTax()));
        pensionPaymentDetailType.setNextReviewDate(retrieveDate(pensionPaymentDetails.getNextReviewDate()));
        pensionPaymentDetailType.setTaxFreeProportion(retrieveBigDecimal(pensionPaymentDetails.getTaxFreeProportion()));
        pensionPaymentDetailType.setAnnualNominatedPercent(retrieveBigDecimal(pensionPaymentDetails.getAnnualNominatedPercent()));
        pensionPaymentDetailType.setClaimRebate(retrieveBooleanDefTrue(pensionPaymentDetails.getClaimRebate()));
        pensionPaymentDetailType.setClaimDeductible(retrieveBooleanDefTrue(pensionPaymentDetails.getClaimDeductible()));
        pensionPaymentDetailType.setCarryForwardDeductible(retrieveBooleanDefFalse(pensionPaymentDetails.getCarryForwardDeductible()));
        pensionPaymentDetailType.setTtr(retrieveBooleanDefFalse(pensionPaymentDetails.getTtr()));
        accountRequestDetailsType.setPensionPaymentDetail(pensionPaymentDetailType);
    }

    /**
     * Set Pension Payment Split Details.
     * 
     * @param pensionPaymentSplitDetails
     * @param pensionPaymentSplitTypeList
     * @throws SILException
     */
    public void setPensionPaymentSplitDetails(PensionPaymentSplitDetails pensionPaymentSplitDetails,
            List<PensionPaymentSplitType> pensionPaymentSplitTypeList, AccountDetails accountDetails) throws SILException {
        if (pensionPaymentSplitDetails != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "setPensionPaymentSplitDetails()");
            PensionPaymentSplitType pensionPaymentSplitType = new PensionPaymentSplitType();
            Object clientObject = getClientPointerDetails(pensionPaymentSplitDetails);
            pensionPaymentSplitType.setEffectiveDate(retrieveDate(pensionPaymentSplitDetails.getEffectiveDate()));
            pensionPaymentSplitType.setId(retrieveLong(pensionPaymentSplitDetails.getId()));
            pensionPaymentSplitType.setClient(new AccountApplicationUtil().getClientPointerReference(clientObject));
            pensionPaymentSplitType.setFixedAmount(retrieveBooleanDefFalse(pensionPaymentSplitDetails.getFixedAmount()));
            pensionPaymentSplitType.setDefaultPayee(retrieveBooleanDefTrue(pensionPaymentSplitDetails.getDefaultPayee()));
            pensionPaymentSplitType.setPaymentSplit(retrievePaymentSplit(pensionPaymentSplitDetails.getPaymentSplit()));
            pensionPaymentSplitType.setPaymentMethodCode(retrieveCodeIdentifier(pensionPaymentSplitDetails.getPaymentMethodCode()));
            pensionPaymentSplitType.setBankAccountCardNumber(retrieveString(pensionPaymentSplitDetails.getBankAccountCardNumber()));
            if (pensionPaymentSplitDetails.getClient() != null) {
                pensionPaymentSplitType.setClient(new AccountApplicationUtil().setClientInfo(pensionPaymentSplitDetails.getClient()));
            }
            pensionPaymentSplitTypeList.add(pensionPaymentSplitType);

        }
    }

    /**
     * Get Client Pointer Details.
     * 
     * @param accountDetails
     * @return
     */
    private Client getClientPointerDetails(PensionPaymentSplitDetails pensionPaymentSplitDetails) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Client Pointer Details");
        if (pensionPaymentSplitDetails != null && pensionPaymentSplitDetails.getClientPointer() != null) {
            Client clientRequestDetailsType = new Client();
            clientRequestDetailsType.setId(pensionPaymentSplitDetails.getClientPointer());
            return clientRequestDetailsType;
        }
        return null;
    }

    /**
     * Get Payment Split.
     * 
     * @param paymentSplit
     * @return
     */
    private PaymentSplit retrievePaymentSplit(PaymentSplitInfo paymentSplitInfo) {
        PaymentSplit paymentSplit = new PaymentSplit();
        if (paymentSplitInfo != null) {
            if (paymentSplitInfo.getAmount() != null) {
                paymentSplit.setAmount(new BigDecimal(paymentSplitInfo.getAmount()));
            }
            if (paymentSplitInfo.getPercentage() != null) {
                paymentSplit.setPercentage(new BigDecimal(paymentSplitInfo.getPercentage()));
            }
            return paymentSplit;
        }
        return null;
    }

    /**
     * Retrieve String.
     * 
     * @param bankAccountCardNumber
     * @return value
     */
    private String retrieveString(String value) {
        if (value != null) {
            return value;
        }
        return null;
    }

    /**
     * Retrieve BigInteger.
     * 
     * @return BigInteger
     */
    private BigInteger retrieveBigInteger(String value) {
        if (value != null) {
            return new BigInteger(value);
        }
        return null;
    }

    /**
     * Retrieve Boolean Default False.
     * 
     * @return defaultValue
     */
    private Boolean retrieveBooleanDefFalse(String value) {
        Boolean defaultValue = false;
        if (value != null) {
            defaultValue = Boolean.valueOf(value);
        }
        return defaultValue;
    }

    /**
     * Retrieve Boolean Default True.
     * 
     * @return defaultValue
     */
    private Boolean retrieveBooleanDefTrue(String value) {
        Boolean defaultValue = true;
        if (value != null) {
            return Boolean.valueOf(value);
        }
        return defaultValue;
    }

    /**
     * Retrieve XMLGregorianCalendar.
     * 
     * @return XMLGregorianCalendar
     * @throws SILException
     */
    private XMLGregorianCalendar retrieveDate(String value) throws SILException {
        if (value != null) {
            return SILUtil.convertStringToXMLGregorianCalendar(value, CommonConstants.DATE_FORMAT);
        }
        return null;
    }

    /**
     * Retrieve BigDecimal.
     * 
     * @param value
     * @return BigDecimal
     */
    private BigDecimal retrieveBigDecimal(String value) {
        if (value != null) {
            return new BigDecimal(value);
        }
        return null;
    }

    /**
     * Retrieve CodeIdentifier.
     * 
     * @param codeIdentifierDetails
     * @return codeIdentifierType
     */
    private CodeIdentifierType retrieveCodeIdentifier(CodeIdentifierDetails codeIdentifierDetails) {
        CodeIdentifierType codeIdentifierType = new CodeIdentifierType();
        if (codeIdentifierDetails != null) {
            codeIdentifierType.setId(retrieveLong(codeIdentifierDetails.getId()));
            codeIdentifierType.setCode(retrieveString(codeIdentifierDetails.getCode()));
            codeIdentifierType.setCodeType(retrieveString(codeIdentifierDetails.getCodeType()));
            codeIdentifierType.setCodeShortDescription(retrieveString(codeIdentifierDetails.getCodeShortDescription()));
            codeIdentifierType.setCodeDescription(retrieveString(codeIdentifierDetails.getCodeDescription()));
            return codeIdentifierType;
        }
        return null;
    }

    /**
     * Retrieve FrequencyIdentifier.
     * 
     * @param frequencyIdentifierDetails
     * @return frequencyIdentifierType
     */
    private FrequencyIdentifierType retrieveFrequencyIdentifier(FrequencyIdentifierDetails frequencyIdentifierDetails) {
        FrequencyIdentifierType frequencyIdentifierType = new FrequencyIdentifierType();
        if (frequencyIdentifierDetails != null) {
            frequencyIdentifierType.setFreqCode(frequencyIdentifierDetails.getFreqCode());
            return frequencyIdentifierType;
        }
        return null;
    }

    /**
     * Retrieve Long.
     * 
     * @return value
     */
    private Long retrieveLong(String value) {
        if (value != null) {
            return Long.parseLong(value);
        }
        return null;
    }
}
