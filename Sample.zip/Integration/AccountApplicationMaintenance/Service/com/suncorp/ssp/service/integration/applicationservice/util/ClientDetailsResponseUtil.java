////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.util;

import java.util.ArrayList;
import java.util.List;

import org.apache.xerces.dom.ElementNSImpl;

import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.AddressDetailsType;
import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.ClientEntityType;
import com.sonatacentral.service.v30.wrap.application.AccountApplicationResponseType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.applicationservice.ApplicationServiceConstants;
import com.suncorp.ssp.service.integration.applicationservice.bean.ClientAddressDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.ClientDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.CodeIdentifierDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.CompanyDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.CountryDetails;

/**
 * The class {@code ClientDetailsResponseUtil} is a Utility class with all the properties related to client details, to construct response for
 * creating account application external service's response object.
 * 
 * @author U383847
 * @since 27/01/2016
 * @version 1.0
 */
public class ClientDetailsResponseUtil {
    private final String className = "ClientDetailsResponseUtil";

    /**
     * Get Client Details.
     * 
     * @param accountApplicationResponseType
     * @return
     * @throws SILException
     */
    public List<ClientDetails> getClientDetails(AccountApplicationResponseType accountApplicationResponseType) throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Client Details");
        List<ClientEntityType> clientEntityTypeList = accountApplicationResponseType.getFullDetail().getClientDetails();
        List<ClientDetails> clientDetailsList = new ArrayList<ClientDetails>();
        for (ClientEntityType clientEntityType : clientEntityTypeList) {
            ClientDetails clientDetails = new ClientDetails();
            clientDetails.setClientId(clientEntityType.getClient().getId().toString());
            this.getClientSpecificDetails(clientDetails, clientEntityType);
            this.getClientOtherDetails(clientDetails, clientEntityType);
            this.getClientPreferredDetails(clientDetails, clientEntityType);
            this.getClientStatusDetails(clientDetails, clientEntityType);
            this.getClientInvestorDetails(clientDetails, clientEntityType);
            this.getClientCorrespondenceDetails(clientDetails, clientEntityType);
            this.getClientAddressDetails(clientDetails, clientEntityType);
            this.getClientCountryDetails(clientDetails, clientEntityType);
            clientDetailsList.add(clientDetails);
        }
        return clientDetailsList;
    }

    /**
     * Get Client Specific Details.
     * 
     * @param clientDetails
     * @param clientEntityType
     */
    private void getClientSpecificDetails(ClientDetails clientDetails, ClientEntityType clientEntityType) throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Client Specific Details");
        this.getClientTypeCode(clientDetails, clientEntityType);
        this.getClientName(clientDetails, clientEntityType);
        this.getClientTitle(clientDetails, clientEntityType);
        this.getClientGender(clientDetails, clientEntityType);
        this.getClientCountry(clientDetails, clientEntityType);
        this.getClientMaritalStatus(clientDetails, clientEntityType);
        this.getClientContactDetails(clientDetails, clientEntityType);
        this.getClientOccupation(clientDetails, clientEntityType);
        this.getClientDateDetails(clientDetails, clientEntityType);
        this.getNationalityDetails(clientDetails, clientEntityType);
    }

    /**
     * Get Client Other Details.
     * 
     * @param clientDetails
     * @param clientEntityType
     */
    private void getClientOtherDetails(ClientDetails clientDetails, ClientEntityType clientEntityType) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Client Other Details");
        clientDetails.setAgeAdmitted(clientEntityType.getClientDetails().isAgeAdmitted().toString());
        clientDetails.setDisclaimerSigned(clientEntityType.getClientDetails().isDisclaimerSigned().toString());
        clientDetails.setHoldCorrespondence(clientEntityType.getClientDetails().isHoldCorrespondence().toString());
        clientDetails.setCanSolicit(clientEntityType.getClientDetails().isCanSolicit().toString());
        clientDetails.setSecureSalaryFlag(clientEntityType.getClientDetails().isSecureSalaryFlag().toString());
        clientDetails.setInitials(clientEntityType.getClientDetails().getInitials());
        clientDetails.setSalutation(clientEntityType.getClientDetails().getSalutation());
    }

    /**
     * Get Client Type Code Details.
     * 
     * @param clientDetails
     * @param clientEntityType
     */
    private void getClientTypeCode(ClientDetails clientDetails, ClientEntityType clientEntityType) {
        if (clientEntityType.getClientDetails().getTypeCode() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Client Type Code Details");
            CodeIdentifierDetails codeIdentifier = new CodeIdentifierDetails();
            codeIdentifier.setId(clientEntityType.getClientDetails().getTypeCode().getId().toString());
            codeIdentifier.setCode(clientEntityType.getClientDetails().getTypeCode().getCode());
            codeIdentifier.setCodeType(clientEntityType.getClientDetails().getTypeCode().getCodeType());
            codeIdentifier.setCodeDescription(clientEntityType.getClientDetails().getTypeCode().getCodeDescription());
            codeIdentifier.setCodeShortDescription(clientEntityType.getClientDetails().getTypeCode().getCodeShortDescription());
            clientDetails.setClient(codeIdentifier);
        } else {
            clientDetails.setClient(new AccountApplicationUtil().createDefaultCodeIdentifierInfo());
        }
    }

    /**
     * Get Client Name Details.
     * 
     * @param clientDetails
     * @param clientEntityType
     */
    private void getClientName(ClientDetails clientDetails, ClientEntityType clientEntityType) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Client Name Details");
        clientDetails.setSurname(clientEntityType.getClient().getClientSurname());
        clientDetails.setFirstName(clientEntityType.getClient().getClientForename());
        clientDetails.setMiddleName(clientEntityType.getClient().getClientForename2());
    }

    /**
     * Get Client Title Details.
     * 
     * @param clientDetails
     * @param clientEntityType
     */
    private void getClientTitle(ClientDetails clientDetails, ClientEntityType clientEntityType) {
        if (clientEntityType.getClientDetails().getTitle() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Client Title Details");
            CodeIdentifierDetails codeIdentifier = new CodeIdentifierDetails();
            codeIdentifier.setId(clientEntityType.getClientDetails().getTitle().getId().toString());
            codeIdentifier.setCode(clientEntityType.getClientDetails().getTitle().getCode());
            codeIdentifier.setCodeType(clientEntityType.getClientDetails().getTitle().getCodeType());
            codeIdentifier.setCodeDescription(clientEntityType.getClientDetails().getTitle().getCodeDescription());
            codeIdentifier.setCodeShortDescription(clientEntityType.getClientDetails().getTitle().getCodeShortDescription());
            clientDetails.setTitle(codeIdentifier);
        } else {
            clientDetails.setTitle(new AccountApplicationUtil().createDefaultCodeIdentifierInfo());
        }
    }

    /**
     * Get Client Gender Details.
     * 
     * @param clientDetails
     * @param clientEntityType
     */
    private void getClientGender(ClientDetails clientDetails, ClientEntityType clientEntityType) {
        if (clientEntityType.getClientDetails().getGender() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Client Gender Details");
            CodeIdentifierDetails codeIdentifier = new CodeIdentifierDetails();
            codeIdentifier.setId(clientEntityType.getClientDetails().getGender().getId().toString());
            codeIdentifier.setCode(clientEntityType.getClientDetails().getGender().getCode());
            codeIdentifier.setCodeType(clientEntityType.getClientDetails().getGender().getCodeType());
            codeIdentifier.setCodeDescription(clientEntityType.getClientDetails().getGender().getCodeDescription());
            codeIdentifier.setCodeShortDescription(clientEntityType.getClientDetails().getGender().getCodeShortDescription());
            clientDetails.setGender(codeIdentifier);
        } else {
            clientDetails.setGender(new AccountApplicationUtil().createDefaultCodeIdentifierInfo());
        }
    }

    /**
     * Get Client Country Details.
     * 
     * @param clientDetails
     * @param clientEntityType
     */
    private void getClientCountry(ClientDetails clientDetails, ClientEntityType clientEntityType) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Client Country Details");
        clientDetails.setCountryCode(clientEntityType.getClientDetails().getCountry().getCode());
        clientDetails.setCountryName(clientEntityType.getClientDetails().getCountry().getName());
    }

    /**
     * Get Client Marital Status Details.
     * 
     * @param clientDetails
     * @param clientEntityType
     */
    private void getClientMaritalStatus(ClientDetails clientDetails, ClientEntityType clientEntityType) {
        if (clientEntityType.getClientDetails().getMaritalStatus() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Client Marital Status Details");
            CodeIdentifierDetails codeIdentifier = new CodeIdentifierDetails();
            codeIdentifier.setCode(clientEntityType.getClientDetails().getMaritalStatus().getCode().toString());
            codeIdentifier.setCodeType(clientEntityType.getClientDetails().getMaritalStatus().getCodeType());
            codeIdentifier.setCodeDescription(clientEntityType.getClientDetails().getMaritalStatus().getCodeDescription());
            codeIdentifier.setCodeShortDescription(clientEntityType.getClientDetails().getMaritalStatus().getCodeShortDescription());
            clientDetails.setMaritalStatus(codeIdentifier);
        } else {
            clientDetails.setMaritalStatus(new AccountApplicationUtil().createDefaultCodeIdentifierInfo());
        }
    }

    /**
     * Get Client Contact Details.
     * 
     * @param clientDetails
     * @param clientEntityType
     */
    private void getClientContactDetails(ClientDetails clientDetails, ClientEntityType clientEntityType) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Client Contact Details");
        clientDetails.setContactName(clientEntityType.getClientDetails().getContactName());
        clientDetails.setBusinessName(clientEntityType.getClientDetails().getBusinessName());
        clientDetails.setMailingName(clientEntityType.getClientDetails().getMailingName());
        clientDetails.setMobileNumber(clientEntityType.getClientDetails().getMobilePhone());
        clientDetails.setHomeNumber(clientEntityType.getClientDetails().getHomePhone());
        clientDetails.setWorkNumber(clientEntityType.getClientDetails().getBusinessPhone());
    }

    /**
     * Get Client Occupation Details.
     * 
     * @param clientDetails
     * @param clientEntityType
     */
    private void getClientOccupation(ClientDetails clientDetails, ClientEntityType clientEntityType) {
        if (clientEntityType.getClientDetails().getOccupation() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Client Occupation Details");
            clientDetails.setOccupationId(clientEntityType.getClientDetails().getOccupation().getId().toString());
            clientDetails.setOccupationCode(clientEntityType.getClientDetails().getOccupation().getCode());
            clientDetails.setOccupationName(clientEntityType.getClientDetails().getOccupation().getName());
        } else {
            clientDetails.setOccupationId("");
            clientDetails.setOccupationCode("");
            clientDetails.setOccupationName("");
        }
    }

    /**
     * Get Client Date Details.
     * 
     * @param clientDetails
     * @param clientEntityType
     */
    private void getClientDateDetails(ClientDetails clientDetails, ClientEntityType clientEntityType) throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Client Date Details");
        clientDetails.setDateofBirth(clientEntityType.getClientDetails().getDateOfBirth() != null ? SILUtil.convertXMLGregorianCalendartoString(
                clientEntityType.getClientDetails().getDateOfBirth(), CommonConstants.DATE_FORMAT) : "");

        if (clientEntityType.getClientDetails().getDateOfDeath() != null) {
            String deathDate = clientEntityType.getClientDetails().getDateOfDeath().toString();
            clientDetails.setDateofDeath(SILUtil.convertXMLGregorianCalendartoString(
                    SILUtil.convertStringToXMLGregorianCalendar(deathDate, CommonConstants.DATE_FORMAT), CommonConstants.DATE_FORMAT));
        } else {
            clientDetails.setDateofDeath("");
        }
        if (clientEntityType.getClientDetails().getPlannedRetirementDate() != null) {
            ElementNSImpl nsImpl = (ElementNSImpl) clientEntityType.getClientDetails().getPlannedRetirementDate();
            String retirementDate = nsImpl.getTextContent();
            clientDetails.setPlannedRetirementDate(SILUtil.convertXMLGregorianCalendartoString(
                    SILUtil.convertStringToXMLGregorianCalendar(retirementDate, CommonConstants.DATE_FORMAT), CommonConstants.DATE_FORMAT));
        } else {
            clientDetails.setPlannedRetirementDate("");
        }
    }

    private void getNationalityDetails(ClientDetails clientDetails, ClientEntityType clientEntityType) {
        if (clientEntityType.getClientDetails().getNationality() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Client Nationality Details");
            CodeIdentifierDetails codeIdentifier = new CodeIdentifierDetails();
            codeIdentifier.setId(clientEntityType.getClientDetails().getNationality().getId().toString());
            codeIdentifier.setCode(clientEntityType.getClientDetails().getNationality().getCode());
            codeIdentifier.setCodeType(clientEntityType.getClientDetails().getNationality().getCodeType());
            codeIdentifier.setCodeDescription(clientEntityType.getClientDetails().getNationality().getCodeDescription());
            codeIdentifier.setCodeShortDescription(clientEntityType.getClientDetails().getNationality().getCodeShortDescription());
            clientDetails.setNationality(codeIdentifier);
        } else {
            clientDetails.setNationality(new AccountApplicationUtil().createDefaultCodeIdentifierInfo());
        }
    }

    /**
     * Get Client Preferred Details.
     * 
     * @param clientDetails
     * @param clientEntityType
     */
    private void getClientPreferredDetails(ClientDetails clientDetails, ClientEntityType clientEntityType) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Client Preferred Details");
        this.getClientPreferredLanguageDetails(clientDetails, clientEntityType);
        this.getClientPreferredRiskDetails(clientDetails, clientEntityType);
        this.getClientPreferredCurrencyDetails(clientDetails, clientEntityType);
    }

    /**
     * Get Client Preferred Language Details.
     * 
     * @param clientDetails
     * @param clientEntityType
     */
    private void getClientPreferredLanguageDetails(ClientDetails clientDetails, ClientEntityType clientEntityType) {
        if (clientEntityType.getClientDetails().getPreferredLanguage() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Client Preferred Language Details");
            CodeIdentifierDetails codeIdentifier = new CodeIdentifierDetails();
            codeIdentifier.setId(clientEntityType.getClientDetails().getPreferredLanguage().getId().toString());
            codeIdentifier.setCode(clientEntityType.getClientDetails().getPreferredLanguage().getCode());
            codeIdentifier.setCodeType(clientEntityType.getClientDetails().getPreferredLanguage().getCodeType());
            codeIdentifier.setCodeDescription(clientEntityType.getClientDetails().getPreferredLanguage().getCodeDescription());
            codeIdentifier.setCodeShortDescription(clientEntityType.getClientDetails().getPreferredLanguage().getCodeShortDescription());
            clientDetails.setPreferredLanguage(codeIdentifier);
        } else {
            clientDetails.setPreferredLanguage(new AccountApplicationUtil().createDefaultCodeIdentifierInfo());
        }
    }

    /**
     * Get Client Preferred Risk Details.
     * 
     * @param clientDetails
     * @param clientEntityType
     */
    private void getClientPreferredRiskDetails(ClientDetails clientDetails, ClientEntityType clientEntityType) {
        if (clientEntityType.getClientDetails().getPreferredRisk() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Client Preferred Risk Details");
            CodeIdentifierDetails codeIdentifier = new CodeIdentifierDetails();
            codeIdentifier.setId(clientEntityType.getClientDetails().getPreferredRisk().getId().toString());
            codeIdentifier.setCode(clientEntityType.getClientDetails().getPreferredRisk().getCode());
            codeIdentifier.setCodeType(clientEntityType.getClientDetails().getPreferredRisk().getCodeType());
            codeIdentifier.setCodeDescription(clientEntityType.getClientDetails().getPreferredRisk().getCodeDescription());
            codeIdentifier.setCodeShortDescription(clientEntityType.getClientDetails().getPreferredRisk().getCodeShortDescription());
            clientDetails.setPreferredRisk(codeIdentifier);
        } else {
            clientDetails.setPreferredRisk(new AccountApplicationUtil().createDefaultCodeIdentifierInfo());
        }
    }

    /**
     * Get Client Preferred Currency Details.
     * 
     * @param clientDetails
     * @param clientEntityType
     */
    private void getClientPreferredCurrencyDetails(ClientDetails clientDetails, ClientEntityType clientEntityType) {
        if (clientEntityType.getClientDetails().getReportingCurrency() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Client Preferred Currency Details");
            clientDetails.setPreferCurrencyCode(clientEntityType.getClientDetails().getReportingCurrency().getCode());
            clientDetails.setPreferCurrencyName(clientEntityType.getClientDetails().getReportingCurrency().getName());
        } else {
            clientDetails.setPreferCurrencyCode("");
            clientDetails.setPreferCurrencyName("");
        }
    }

    /**
     * Get Client Status Details.
     * 
     * @param clientDetails
     * @param clientEntityType
     */
    private void getClientStatusDetails(ClientDetails clientDetails, ClientEntityType clientEntityType) {
        this.getClientStatus(clientDetails, clientEntityType);
        this.getClientOnlineStatus(clientDetails, clientEntityType);
    }

    /**
     * Get Client Status.
     * 
     * @param clientDetails
     * @param clientEntityType
     */
    private void getClientStatus(ClientDetails clientDetails, ClientEntityType clientEntityType) {
        if (clientEntityType.getClientDetails().getStatus() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Client Status Details");
            CodeIdentifierDetails codeIdentifier = new CodeIdentifierDetails();
            codeIdentifier.setId(clientEntityType.getClientDetails().getStatus().getId().toString());
            codeIdentifier.setCode(clientEntityType.getClientDetails().getStatus().getCode());
            codeIdentifier.setCodeType(clientEntityType.getClientDetails().getStatus().getCodeType());
            codeIdentifier.setCodeDescription(clientEntityType.getClientDetails().getStatus().getCodeDescription());
            codeIdentifier.setCodeShortDescription(clientEntityType.getClientDetails().getStatus().getCodeShortDescription());
            clientDetails.setStatus(codeIdentifier);
        } else {
            clientDetails.setStatus(new AccountApplicationUtil().createDefaultCodeIdentifierInfo());
        }
    }

    /**
     * Get Client Online Status.
     * 
     * @param clientDetails
     * @param clientEntityType
     */
    private void getClientOnlineStatus(ClientDetails clientDetails, ClientEntityType clientEntityType) {
        if (clientEntityType.getClientDetails().getOnlineStatus() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Client Online Status Details");
            CodeIdentifierDetails codeIdentifier = new CodeIdentifierDetails();
            codeIdentifier.setId(clientEntityType.getClientDetails().getOnlineStatus().getId().toString());
            codeIdentifier.setCode(clientEntityType.getClientDetails().getOnlineStatus().getCode());
            codeIdentifier.setCodeType(clientEntityType.getClientDetails().getOnlineStatus().getCodeType());
            codeIdentifier.setCodeDescription(clientEntityType.getClientDetails().getOnlineStatus().getCodeDescription());
            codeIdentifier.setCodeShortDescription(clientEntityType.getClientDetails().getOnlineStatus().getCodeShortDescription());
            clientDetails.setOnlineStatus(codeIdentifier);
        } else {
            clientDetails.setOnlineStatus(new AccountApplicationUtil().createDefaultCodeIdentifierInfo());
        }
    }

    /**
     * Get Client Investor Details.
     * 
     * @param clientDetails
     * @param clientEntityType
     */
    private void getClientInvestorDetails(ClientDetails clientDetails, ClientEntityType clientEntityType) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Client Investor Details");
        this.getClientInvestorCompanyDetails(clientDetails, clientEntityType);
        this.getClientInvestorPersonalDetails(clientDetails, clientEntityType);
    }

    /**
     * Get Client Investor Company Details.
     * 
     * @param clientDetails
     * @param clientEntityType
     */
    private void getClientInvestorCompanyDetails(ClientDetails clientDetails, ClientEntityType clientEntityType) {
        if (clientEntityType.getClientDetails().getInvestorTypeCompany() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Client Investor Company Details");
            CodeIdentifierDetails codeIdentifier = new CodeIdentifierDetails();
            codeIdentifier.setId(clientEntityType.getClientDetails().getInvestorTypeCompany().getId().toString());
            codeIdentifier.setCode(clientEntityType.getClientDetails().getInvestorTypeCompany().getCode());
            codeIdentifier.setCodeType(clientEntityType.getClientDetails().getInvestorTypeCompany().getCodeType());
            codeIdentifier.setCodeDescription(clientEntityType.getClientDetails().getInvestorTypeCompany().getCodeDescription());
            codeIdentifier.setCodeShortDescription(clientEntityType.getClientDetails().getInvestorTypeCompany().getCodeShortDescription());
            clientDetails.setInvestorTypeCompany(codeIdentifier);
        } else {
            clientDetails.setInvestorTypeCompany(new AccountApplicationUtil().createDefaultCodeIdentifierInfo());
        }
    }

    /**
     * Get Client Investor Personal Details.
     * 
     * @param clientDetails
     * @param clientEntityType
     */
    private void getClientInvestorPersonalDetails(ClientDetails clientDetails, ClientEntityType clientEntityType) {
        if (clientEntityType.getClientDetails().getInvestorTypePersonal() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Client Investor Personal Details");
            CodeIdentifierDetails codeIdentifier = new CodeIdentifierDetails();
            codeIdentifier.setId(clientEntityType.getClientDetails().getInvestorTypePersonal().getId().toString());
            codeIdentifier.setCode(clientEntityType.getClientDetails().getInvestorTypePersonal().getCode());
            codeIdentifier.setCodeType(clientEntityType.getClientDetails().getInvestorTypePersonal().getCodeType());
            codeIdentifier.setCodeDescription(clientEntityType.getClientDetails().getInvestorTypePersonal().getCodeDescription());
            clientDetails.setInvestorTypePersonal(codeIdentifier);
        } else {
            clientDetails.setInvestorTypePersonal(new AccountApplicationUtil().createDefaultCodeIdentifierInfo());
        }
    }

    /**
     * Get Correspondence Details.
     * 
     * @param clientDetails
     * @param clientEntityType
     */
    private void getClientCorrespondenceDetails(ClientDetails clientDetails, ClientEntityType clientEntityType) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Client Correspondence Details");
        this.getClientCorrespondenceViewOptionDetails(clientDetails, clientEntityType);
        this.getClientCorrespondingDeliveryPreferenceDetails(clientDetails, clientEntityType);
    }

    /**
     * Get Correspondence View Option Details.
     * 
     * @param clientDetails
     * @param clientEntityType
     */
    private void getClientCorrespondenceViewOptionDetails(ClientDetails clientDetails, ClientEntityType clientEntityType) {
        if (clientEntityType.getClientDetails().getCorrespondenceViewOptionCode() != null) {
            SILLogger
                    .debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Client Correspondence View Option Details");
            CodeIdentifierDetails codeIdentifier = new CodeIdentifierDetails();
            codeIdentifier.setId(clientEntityType.getClientDetails().getCorrespondenceViewOptionCode().getId().toString());
            codeIdentifier.setCode(clientEntityType.getClientDetails().getCorrespondenceViewOptionCode().getCode());
            codeIdentifier.setCodeType(clientEntityType.getClientDetails().getCorrespondenceViewOptionCode().getCodeType());
            codeIdentifier.setCodeDescription(clientEntityType.getClientDetails().getCorrespondenceViewOptionCode().getCodeDescription());
            codeIdentifier.setCodeShortDescription(clientEntityType.getClientDetails().getCorrespondenceViewOptionCode().getCodeShortDescription());
            clientDetails.setCorrespondingViewOption(codeIdentifier);
        } else {
            clientDetails.setCorrespondingViewOption(new AccountApplicationUtil().createDefaultCodeIdentifierInfo());
        }
    }

    /**
     * Get Correspondence Delivery Preference Details.
     * 
     * @param clientDetails
     * @param clientEntityType
     */
    private void getClientCorrespondingDeliveryPreferenceDetails(ClientDetails clientDetails, ClientEntityType clientEntityType) {
        if (clientEntityType.getClientDetails().getCorresDeliveryPreferenceCode() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className,
                    "Getting Client Correspondence Delivery Preference Details");
            CodeIdentifierDetails codeIdentifier = new CodeIdentifierDetails();
            codeIdentifier.setId(clientEntityType.getClientDetails().getCorresDeliveryPreferenceCode().getId().toString());
            codeIdentifier.setCode(clientEntityType.getClientDetails().getCorresDeliveryPreferenceCode().getCode());
            codeIdentifier.setCodeType(clientEntityType.getClientDetails().getCorresDeliveryPreferenceCode().getCodeType());
            codeIdentifier.setCodeDescription(clientEntityType.getClientDetails().getCorresDeliveryPreferenceCode().getCodeDescription());
            codeIdentifier.setCodeShortDescription(clientEntityType.getClientDetails().getCorresDeliveryPreferenceCode().getCodeShortDescription());
            clientDetails.setCorrespondingDeliveryPreference(codeIdentifier);
        } else {
            clientDetails.setCorrespondingDeliveryPreference(new AccountApplicationUtil().createDefaultCodeIdentifierInfo());
        }
    }

    /**
     * Get Client Address Details.
     * 
     * @param clientDetails
     * @param clientEntityType
     */
    private void getClientAddressDetails(ClientDetails clientDetails, ClientEntityType clientEntityType) {
        if (clientEntityType.getAddress() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Client Address Details");
            List<AddressDetailsType> addressDetailsTypeList = clientEntityType.getAddress();
            List<ClientAddressDetails> clientAddressTypeList = new ArrayList<ClientAddressDetails>();
            for (AddressDetailsType addressDetailsType : addressDetailsTypeList) {
                ClientAddressDetails clientAddressDetails = new ClientAddressDetails();
                clientAddressDetails.setAddressId(addressDetailsType.getId().toString());
                clientAddressDetails.setAddressCode(addressDetailsType.getTypeCode().getCode());
                clientAddressDetails.setAddressCodeType(addressDetailsType.getTypeCode().getCodeType());
                this.getClientAddressLineDetails(addressDetailsType, clientAddressDetails);
                this.getAddressPostCodeStateSuburb(addressDetailsType, clientAddressDetails);
                this.getPrimaryAddressTypeDetails(addressDetailsType, clientAddressDetails);
                clientAddressDetails.setCity(addressDetailsType.getCity());
                clientAddressDetails.setCountry(addressDetailsType.getCountry().getCode());
                clientAddressDetails.setDpid(addressDetailsType.getDpid());
                clientAddressDetails.setBarCode(addressDetailsType.getBarCode());
                clientAddressDetails.setCareOf(addressDetailsType.getCareOf());
                clientAddressTypeList.add(clientAddressDetails);
            }
            clientDetails.setAddressTypeList(clientAddressTypeList);
        }
    }

    /**
     * Get Client Address Lines Details.
     * 
     * @param addressDetailsType
     * @param clientAddressType
     */
    private void getClientAddressLineDetails(AddressDetailsType addressDetailsType, ClientAddressDetails clientAddressDetails) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Client Address Lines Details");
        clientAddressDetails.setLine1(addressDetailsType.getLine1());
        clientAddressDetails.setLine2(addressDetailsType.getLine2());
        clientAddressDetails.setLine3(addressDetailsType.getLine3());
        clientAddressDetails.setLine4(addressDetailsType.getLine4());
    }

    /**
     * Get Postcode State and Suburb Details.
     * 
     * @param addressDetailsType
     * @param clientAddressType
     */
    private void getAddressPostCodeStateSuburb(AddressDetailsType addressDetailsType, ClientAddressDetails clientAddressDetails) {
        if (addressDetailsType.getPostcode() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Client Postcode");
            clientAddressDetails.setPostcode(addressDetailsType.getPostcode());
        } else {
            clientAddressDetails.setPostcode("");
        }
        if (addressDetailsType.getState() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Client State");
            clientAddressDetails.setState(addressDetailsType.getState().getCode());
        } else {
            clientAddressDetails.setState("");
        }
        if (addressDetailsType.getSuburb() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Client Suburb");
            clientAddressDetails.setSuburb(addressDetailsType.getSuburb());
        } else {
            clientAddressDetails.setSuburb("");
        }
    }

    /**
     * Get Primary Address Type Details.
     * 
     * @param addressDetailsType
     * @param clientAddressType
     */
    private void getPrimaryAddressTypeDetails(AddressDetailsType addressDetailsType, ClientAddressDetails clientAddressType) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Primary Address Type Details");
        clientAddressType.setPrimaryFlag(Boolean.toString(addressDetailsType.isPrimary()));
        clientAddressType.setPrimaryType(Boolean.toString(addressDetailsType.isPrimaryType()));
    }

    /**
     * Get Client Country Details.
     * 
     * @param clientDetails
     * @param clientEntityType
     */
    private void getClientCountryDetails(ClientDetails clientDetails, ClientEntityType clientEntityType) {
        CountryDetails countryDetails = new CountryDetails();
        if (clientEntityType.getClient() != null && clientEntityType.getClient().getClientTFN() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Client Tfn Details");
            countryDetails.setTfn(clientEntityType.getClient().getClientTFN());
        } else {
            countryDetails.setTfn("");
        }
        if (clientEntityType.getAustralia() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Client Country Details");
            this.getClientTfnDetails(countryDetails, clientEntityType);
            this.getClientSuperTickDetails(countryDetails, clientEntityType);
            this.getCompanyDetails(countryDetails, clientEntityType);
            clientDetails.setCountryDetails(countryDetails);
        } else {
            countryDetails.setTfnExemptioncode("");
            countryDetails.setTfnExemptioncodetype("");
            countryDetails.setTfnExemptionreason("");
            countryDetails.setSuperTickValidationDate("");
            countryDetails.setSuperTickStatusCode("");
            countryDetails.setSuperTickStatusCodeType("");
        }
        clientDetails.setCountryDetails(countryDetails);
    }

    /**
     * Get Client Tfn Details.
     * 
     * @param countryDetails
     * @param clientEntityType
     * @return
     */
    private CountryDetails getClientTfnDetails(CountryDetails countryDetails, ClientEntityType clientEntityType) {
        if (clientEntityType.getAustralia().getTfnDetail() != null) {
            ClientEntityType.Australia.TfnDetail tfnDetail = clientEntityType.getAustralia().getTfnDetail();
            if (tfnDetail.getTfnExemptionReason() != null && tfnDetail.getTfnExemptionReason().getCode() != null) {
                SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Client Tfn Exemption Details");
                countryDetails.setTfnExemptioncode(tfnDetail.getTfnExemptionReason().getCode());
                countryDetails.setTfnExemptioncodetype(tfnDetail.getTfnExemptionReason().getCodeType());
                countryDetails.setTfnExemptionreason(tfnDetail.getTfnExemptionReason().getCodeDescription());
            } else {
                countryDetails.setTfnExemptioncode("");
                countryDetails.setTfnExemptioncodetype("");
                countryDetails.setTfnExemptionreason("");
            }
            return countryDetails;
        }
        return null;
    }

    /**
     * Get Client Supertick Details.
     * 
     * @param countryDetails
     * @param clientEntityType
     * @return
     */
    private CountryDetails getClientSuperTickDetails(CountryDetails countryDetails, ClientEntityType clientEntityType) {
        if (clientEntityType.getAustralia().getSupertickDetails() != null) {
            ClientEntityType.Australia.SupertickDetails supertickDetails = clientEntityType.getAustralia().getSupertickDetails();
            if (supertickDetails.getValidationDate() != null && supertickDetails.getStatus() != null) {
                SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Client Supertick Details");
                countryDetails.setSuperTickValidationDate(SILUtil.convertXMLGregorianCalendartoString(supertickDetails.getValidationDate(),
                        CommonConstants.DATE_FORMAT));
                countryDetails.setSuperTickStatusCode(supertickDetails.getStatus().getCode());
                countryDetails.setSuperTickStatusCodeType(supertickDetails.getStatus().getCodeType());
            } else {
                countryDetails.setSuperTickValidationDate("");
                countryDetails.setSuperTickStatusCode("");
                countryDetails.setSuperTickStatusCodeType("");
            }
            return countryDetails;
        }
        return null;
    }

    /**
     * Get Client Company Details.
     * 
     * @param countryDetails
     * @param clientEntityType
     * @return
     */
    private CountryDetails getCompanyDetails(CountryDetails countryDetails, ClientEntityType clientEntityType) {
        if (clientEntityType.getAustralia().getCompany() != null) {
            ClientEntityType.Australia.Company company = clientEntityType.getAustralia().getCompany();
            CompanyDetails companyDetails = new CompanyDetails();
            if (company.getAbn() != null) {
                SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Client Company ABN Details");
                companyDetails.setAbn(company.getAbn());
            } else {
                companyDetails.setAbn("");
            }
            countryDetails.setCompanyDetails(companyDetails);
            return countryDetails;
        }
        return null;
    }
}
