////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.util;

import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.ClientEntityType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CodeIdentifierType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.applicationservice.ApplicationServiceConstants;
import com.suncorp.ssp.service.integration.applicationservice.bean.CountryDetails;

/**
 * The class {@code CountryDetailsRequestUtil} does this.
 * 
 * @author U383847
 * @since 11/02/2016
 * @version 1.0
 */
public class CountryDetailsRequestUtil {
    private final String className = "CountryDetailsRequestUtil";

    /**
     * Set Client Country Details.
     * 
     * @param clientEntityType
     * @param countryNameType
     * @throws Exception
     */
    public void setCountryDetails(ClientEntityType.Australia australia, CountryDetails countryDetails) throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Client Country Details");
        this.setTfnDetails(australia, countryDetails);
        this.setTfnExemptionDetails(australia, countryDetails);
        this.setSuperTickDetails(australia, countryDetails);
        this.setAbnDetails(australia, countryDetails);
    }

    /**
     * Set Tfn Details.
     * 
     * @param australia
     * @param countryNameType
     */
    private void setTfnDetails(ClientEntityType.Australia australia, CountryDetails countryDetails) {
        if (countryDetails.getTfn() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting TFN Details");
            ClientEntityType.Australia.TfnDetail tfnDetails = new ClientEntityType.Australia.TfnDetail();
            tfnDetails.setTfn(countryDetails.getTfn());
            australia.setTfnDetail(tfnDetails);
        }
    }

    /**
     * Set Tfn Exemption Details.
     * 
     * @param australia
     * @param countryNameType
     */
    private void setTfnExemptionDetails(ClientEntityType.Australia australia, CountryDetails countryDetails) {
        if (countryDetails.getTfnExemptioncode() != null && countryDetails.getTfnExemptioncodetype() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting TFN Exemption Details");
            ClientEntityType.Australia.TfnDetail tfnDetails = new ClientEntityType.Australia.TfnDetail();
            CodeIdentifierType tfnCodeIdentifierType = new CodeIdentifierType();
            tfnCodeIdentifierType.setCode(countryDetails.getTfnExemptioncode());
            tfnCodeIdentifierType.setCodeType(countryDetails.getTfnExemptioncodetype());
            tfnDetails.setTfnExemptionReason(tfnCodeIdentifierType);
            australia.setTfnDetail(tfnDetails);
        }
    }

    /**
     * Set SuperTick Details.
     * 
     * @param australia
     * @param countryNameType
     * @throws SILException
     */
    private void setSuperTickDetails(ClientEntityType.Australia australia, CountryDetails countryDetails) throws SILException {
        if (countryDetails.getSuperTickStatusCode() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting SuperTick Details");
            ClientEntityType.Australia.SupertickDetails superTickDetails = new ClientEntityType.Australia.SupertickDetails();
            CodeIdentifierType superTickCodeIdentifierType = new CodeIdentifierType();
            superTickCodeIdentifierType.setCode(countryDetails.getSuperTickStatusCode());
            superTickCodeIdentifierType.setCodeType(countryDetails.getSuperTickStatusCodeType());
            superTickDetails.setStatus(superTickCodeIdentifierType);
            if (countryDetails.getSuperTickValidationDate() != null) {
                superTickDetails.setValidationDate(SILUtil.convertStringToXMLGregorianCalendar(countryDetails.getSuperTickValidationDate(),
                        CommonConstants.DATE_FORMAT));
            }
            australia.setSupertickDetails(superTickDetails);
        }
    }

    /**
     * Set Company ABN Details.
     * 
     * @param australia
     * @param countryDetails
     * @throws SILException
     */
    private void setAbnDetails(ClientEntityType.Australia australia, CountryDetails countryDetails) throws SILException {
        ClientEntityType.Australia.Company company = new ClientEntityType.Australia.Company();
        if (countryDetails.getCompanyDetails() != null && countryDetails.getCompanyDetails().getAbn() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting ABN Details");
            company.setAbn(countryDetails.getCompanyDetails().getAbn());
        } else {
            company.setAbn("");
        }
        australia.setCompany(company);
    }
}
