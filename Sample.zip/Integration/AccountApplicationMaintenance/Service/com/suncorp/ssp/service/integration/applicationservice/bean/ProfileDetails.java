////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code ProfileDetails} does this.
 * @author U383847
 * @since 28/01/2016
 * @version 1.0
 */
public class ProfileDetails {
    private PatternTemplateDetails patternTemplateDetails;
    private String bespoke;

    /**
     * Accessor for property patternTemplateDetails.
     * 
     * @return patternTemplate of type PatternTemplateDetails
     */
    public PatternTemplateDetails getPatternTemplateDetails() {
        return patternTemplateDetails;
    }

    /**
     * Mutator for property patternTemplateDetails.
     * 
     * @return patternTemplate of type PatternTemplateDetails
     */
    @XmlElement(name = "patternTemplateDetails")
    public void setPatternTemplateDetails(PatternTemplateDetails patternTemplateDetails) {
        this.patternTemplateDetails = patternTemplateDetails;
    }
    
    /**
     * Accessor for property bespoke.
     * 
     * @return bespoke of type String
     */
    public String getBespoke() {
        return bespoke;
    }

    /**
     * Mutator for property bespoke.
     * 
     * @return bespoke of type String
     */
    @XmlElement(name = "bespoke")
    public void setBespoke(String bespoke) {
        this.bespoke = bespoke != null ? bespoke : "";
    }
}
