////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code AccountExternalReferenceDetails} does this.
 * @author U383847
 * @since 03/02/2016
 * @version 1.0
 */
public class AccountExternalReferenceDetails {
    private String externalReferenceType;
    private String externalReferenceCode;

    /**
     * Accessor for property externalReferenceType.
     * 
     * @return externalReferenceType of type String
     */
    public String getExternalReferenceType() {
        return externalReferenceType;
    }

    /**
     * Mutator for property externalReferenceType.
     * 
     * @param externalReferenceType of type String
     */
    @XmlElement(name = "externalReferenceType")
    public void setExternalReferenceType(String externalReferenceType) {
        this.externalReferenceType = externalReferenceType != null ? externalReferenceType : "";
    }

    /**
     * Accessor for property externalReferenceCode.
     * 
     * @return externalReferenceCode of type String
     */
    public String getExternalReferenceCode() {
        return externalReferenceCode;
    }

    /**
     * Mutator for property externalReferenceCode.
     * 
     * @param externalReferenceCode of type String
     */
    @XmlElement(name = "externalReferenceCode")
    public void setExternalReferenceCode(String externalReferenceCode) {
        this.externalReferenceCode = externalReferenceCode != null ? externalReferenceCode : "";
    }
}
