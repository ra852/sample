////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code CountryDetails} does this.
 * 
 * @author U383847
 * @since 03/02/2016
 * @version 1.0
 */
public class CountryDetails {
    private String tfn;
    private String tfnExemptioncodetype;
    private String tfnExemptioncode;
    private String tfnExemptionreason;
    private String superTickStatusCode;
    private String superTickStatusCodeType;
    private String superTickValidationDate;
    private CompanyDetails companyDetails;

    /**
     * Accessor for property tfn.
     * 
     * @return tfn of type String
     */
    public String getTfn() {
        return tfn;
    }

    /**
     * Mutator for property tfn.
     * 
     * @param tfn of type String
     */
    @XmlElement(name = "tfn")
    public void setTfn(String tfn) {
        this.tfn = tfn != null ? tfn : "";
    }

    /**
     * Accessor for property tfnExemptioncodetype.
     * 
     * @return tfnExemptioncodetype of type String
     */
    public String getTfnExemptioncodetype() {
        return tfnExemptioncodetype;
    }

    /**
     * Mutator for property tfnExemptioncodetype.
     * 
     * @param tfnExemptioncodetype of type String
     */
    @XmlElement(name = "tfnExemptioncodetype")
    public void setTfnExemptioncodetype(String tfnExemptioncodetype) {
        this.tfnExemptioncodetype = tfnExemptioncodetype != null ? tfnExemptioncodetype : "";
    }

    /**
     * Accessor for property tfnExemptioncode.
     * 
     * @return tfnExemptioncode of type String
     */
    public String getTfnExemptioncode() {
        return tfnExemptioncode;
    }

    /**
     * Mutator for property tfnExemptioncode.
     * 
     * @param tfnExemptioncode of type String
     */
    @XmlElement(name = "tfnExemptioncode")
    public void setTfnExemptioncode(String tfnExemptioncode) {
        this.tfnExemptioncode = tfnExemptioncode != null ? tfnExemptioncode : "";
    }

    /**
     * Accessor for property tfnExemptionreason.
     * 
     * @return tfnExemptionreason of type String
     */
    public String getTfnExemptionreason() {
        return tfnExemptionreason;
    }

    /**
     * Mutator for property tfnExemptionreason.
     * 
     * @param tfnExemptionreason of type String
     */
    @XmlElement(name = "tfnExemptionreason")
    public void setTfnExemptionreason(String tfnExemptionreason) {
        this.tfnExemptionreason = tfnExemptionreason != null ? tfnExemptionreason : "";
    }

    /**
     * Accessor for property superTickStatusCode.
     * 
     * @return superTickStatusCode of type String
     */
    public String getSuperTickStatusCode() {
        return superTickStatusCode;
    }

    /**
     * Mutator for property superTickStatusCode.
     * 
     * @param superTickStatusCode of type String
     */
    @XmlElement(name = "tfnSupertickstatus")
    public void setSuperTickStatusCode(String superTickStatusCode) {
        this.superTickStatusCode = superTickStatusCode;
    }

    /**
     * Accessor for property superTickStatusCodeType.
     * 
     * @return superTickStatusCodeType of type String
     */
    public String getSuperTickStatusCodeType() {
        return superTickStatusCodeType;
    }

    /**
     * Mutator for property superTickStatusCodeType.
     * 
     * @param superTickStatusCodeType of type String
     */
    @XmlElement(name = "superTickStatusCodeType")
    public void setSuperTickStatusCodeType(String superTickStatusCodeType) {
        this.superTickStatusCodeType = superTickStatusCodeType;
    }

    /**
     * Accessor for property superTickValidationDate.
     * 
     * @return superTickValidationDate of type String
     */
    public String getSuperTickValidationDate() {
        return superTickValidationDate;
    }

    /**
     * Mutator for property superTickValidationDate.
     * 
     * @param superTickValidationDate of type String
     */
    @XmlElement(name = "tfnSupertickdate")
    public void setSuperTickValidationDate(String superTickValidationDate) {
        this.superTickValidationDate = superTickValidationDate;
    }

    /**
     * Accessor for property companyDetails.
     * 
     * @return companyDetails of type CompanyDetails
     */
    public CompanyDetails getCompanyDetails() {
        return companyDetails;
    }

    /**
     * Mutator for property companyDetails.
     * 
     * @param companyDetails of type CompanyDetails
     */
    @XmlElement(name = "company")
    public void setCompanyDetails(CompanyDetails companyDetails) {
        this.companyDetails = companyDetails;
    }
}
