////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code BeneficiaryBean} is a simple POJO for beneficiary related details.
 * 
 * @author U384381
 * @since 23/02/2016
 * @version 1.0
 */
public class BeneficiaryBean {
    private ClientAccountRelationshipBean clientAccountRelationship;
    private CodeIdentifierDetails category;
    private CodeIdentifierDetails type;
    private CodeIdentifierDetails relationship;
    private String adviceReceived;
    private DistributionOutletBean distributionOutlet;
    private String endDate;
    private String dateNominationSigned;
    private String splitPercentage;

    /**
     * Accessor for property clientPointerReference.
     * 
     * @return clientPointerReference of type String
     */
    public ClientAccountRelationshipBean getClientAccountRelationship() {
        return clientAccountRelationship;
    }

    /**
     * Mutator for property clientPointerReference.
     * 
     * @param clientPointerReference of type String
     */
    @XmlElement(name = "clientAccountRelationship")
    public void setClientAccountRelationship(ClientAccountRelationshipBean clientAccountRelationship) {
        this.clientAccountRelationship = clientAccountRelationship;
    }

    /**
     * Accessor for property category.
     * 
     * @return category of type CodeIdentifierDetails
     */
    public CodeIdentifierDetails getCategory() {
        return category;
    }

    /**
     * Mutator for property category.
     * 
     * @param category of type CodeIdentifierDetails
     */
    @XmlElement(name = "category")
    public void setCategory(CodeIdentifierDetails category) {
        this.category = category;
    }

    /**
     * Accessor for property type.
     * 
     * @return type of type CodeIdentifierDetails
     */
    public CodeIdentifierDetails getType() {
        return type;
    }

    /**
     * Mutator for property type.
     * 
     * @param type of type CodeIdentifierDetails
     */
    @XmlElement(name = "type")
    public void setType(CodeIdentifierDetails type) {
        this.type = type;
    }

    /**
     * Accessor for property relationship.
     * 
     * @return relationship of type CodeIdentifierDetails
     */
    public CodeIdentifierDetails getRelationship() {
        return relationship;
    }

    /**
     * Mutator for property relationship.
     * 
     * @param relationship of type CodeIdentifierDetails
     */
    @XmlElement(name = "relationship")
    public void setRelationship(CodeIdentifierDetails relationship) {
        this.relationship = relationship;
    }

    /**
     * Accessor for property adviceReceived.
     * 
     * @return adviceReceived of type String
     */
    public String getAdviceReceived() {
        return adviceReceived;
    }

    /**
     * Mutator for property adviceReceived.
     * 
     * @param adviceReceived of type String
     */
    @XmlElement(name = "adviceReceived")
    public void setAdviceReceived(String adviceReceived) {
        this.adviceReceived = adviceReceived != null ? adviceReceived : "";
    }

    /**
     * Accessor for property distributionOutlet.
     * 
     * @return distributionOutlet of type DistributionOutletDetails
     */
    public DistributionOutletBean getDistributionOutlet() {
        return distributionOutlet;
    }

    /**
     * Mutator for property distributionOutlet.
     * 
     * @param distributionOutlet of type DistributionOutletDetails
     */
    @XmlElement(name = "distributionOutlet")
    public void setDistributionOutlet(DistributionOutletBean distributionOutlet) {
        this.distributionOutlet = distributionOutlet;
    }

    /**
     * Accessor for property endDate.
     * 
     * @return endDate of type String
     */
    public String getEndDate() {
        return endDate;
    }

    /**
     * Mutator for property endDate.
     * 
     * @param endDate of type String
     */
    @XmlElement(name = "endDate")
    public void setEndDate(String endDate) {
        this.endDate = endDate != null ? endDate : "";
    }

    /**
     * Accessor for property dateNominationSigned.
     * 
     * @return dateNominationSigned of type String
     */
    public String getDateNominationSigned() {
        return dateNominationSigned;
    }

    /**
     * Mutator for property dateNominationSigned.
     * 
     * @param dateNominationSigned of type String
     */
    @XmlElement(name = "dateNominationSigned")
    public void setDateNominationSigned(String dateNominationSigned) {
        this.dateNominationSigned = dateNominationSigned != null ? dateNominationSigned : "";
    }

    /**
     * Accessor for property splitPercentage.
     * 
     * @return splitPercentage of type String
     */
    public String getSplitPercentage() {
        return splitPercentage;
    }

    /**
     * Mutator for property splitPercentage.
     * 
     * @param splitPercentage of type String
     */
    @XmlElement(name = "splitPercentage")
    public void setSplitPercentage(String splitPercentage) {
        this.splitPercentage = splitPercentage != null ? splitPercentage : "";
    }
}
