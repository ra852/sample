////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code MasterSchemeIdentifierDetails} does this.
 * @author U383847
 * @since 09/02/2016
 * @version 1.0
 */
public class MasterSchemeIdentifierDetails {
    private String id;
    private String name;
    private String displayName;
    private String longName;

    /**
     * Accessor for property id.
     * 
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     * 
     * @param id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id != null ? id : "";
    }

    /**
     * Accessor for property name.
     * 
     * @return name of type String
     */
    public String getName() {
        return name;
    }

    /**
     * Mutator for property name.
     * 
     * @param name of type String
     */
    @XmlElement(name = "name")
    public void setName(String name) {
        this.name = name != null ? name : "";
    }

    /**
     * Accessor for property displayName.
     * 
     * @return displayName of type String
     */
    public String getDisplayName() {
        return displayName;
    }

    /**
     * Mutator for property displayName.
     * 
     * @param displayName of type String
     */
    @XmlElement(name = "displayName")
    public void setDisplayName(String displayName) {
        this.displayName = displayName != null ? displayName : "";
    }

    /**
     * Accessor for property longName.
     * 
     * @return longName of type String
     */
    public String getLongName() {
        return longName;
    }

    /**
     * Mutator for property longName.
     * 
     * @param longName of type String
     */
    @XmlElement(name = "longName")
    public void setLongName(String longName) {
        this.longName = longName != null ? longName : "";
    }
}
