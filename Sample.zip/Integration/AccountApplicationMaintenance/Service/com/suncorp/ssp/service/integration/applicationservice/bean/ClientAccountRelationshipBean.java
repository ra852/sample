////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * The class {@code ClientAccountRelationshipBean} is a java bean consisting of properties related to client relationship details.
 * 
 * @author U384381
 * @since 24/02/2016
 * @version 1.0
 */
@XmlRootElement(name = "clientAccountRelationship")
public class ClientAccountRelationshipBean {
    private String id;
    private ClientDetails client;
    private CodeNameIdentifier relationshipType;
    private String primaryFlag;

    /**
     * Accessor for property id.
     * 
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     * 
     * @param id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id != null ? id : "";
    }

    /**
     * Accessor for property client.
     * 
     * @return client of type ClientDetails
     */
    public ClientDetails getClient() {
        return client;
    }

    /**
     * Mutator for property client.
     * 
     * @param client of type ClientDetails
     */
    @XmlElement(name = "client")
    public void setClient(ClientDetails client) {
        this.client = client;
    }

    /**
     * Accessor for property relationshipType.
     * 
     * @return relationshipType of type CodeNameIdentifier
     */
    public CodeNameIdentifier getRelationshipType() {
        return relationshipType;
    }

    /**
     * Mutator for property relationshipType.
     * 
     * @param relationshipType of type CodeNameIdentifier
     */
    @XmlElement(name = "relationshipType")
    public void setRelationshipType(CodeNameIdentifier relationshipType) {
        this.relationshipType = relationshipType;
    }

    /**
     * Accessor for property primaryFlag.
     * 
     * @return primaryFlag of type String
     */
    public String getPrimaryFlag() {
        return primaryFlag;
    }

    /**
     * Mutator for property primaryFlag.
     * 
     * @param primaryFlag of type String
     */
    @XmlElement(name = "primaryFlag")
    public void setPrimaryFlag(String primaryFlag) {
        this.primaryFlag = primaryFlag != null ? primaryFlag : "";
    }

}
