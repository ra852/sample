////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code ExcludedAssetClassDetails} does this.
 * @author U383847
 * @since 09/02/2016
 * @version 1.0
 */
public class ExcludedAssetClassDetails {
    private CodeIdentifierDetails assetClass;
    private String exclude;
    
    /**
     * Accessor for property assetClass.
     * 
     * @return assetClass of type CodeIdentifierDetails
     */
    public CodeIdentifierDetails getAssetClass() {
        return assetClass;
    }
    
    /**
     * Mutator for property assetClass.
     * 
     * @return assetClass of type CodeIdentifierDetails
     */
    @XmlElement(name = "assetClass")
    public void setAssetClass(CodeIdentifierDetails assetClass) {
        this.assetClass = assetClass;
    }
    
    /**
     * Accessor for property exclude.
     * 
     * @return exclude of type String
     */
    public String getExclude() {
        return exclude;
    }
    
    /**
     * Mutator for property exclude.
     * 
     * @return exclude of type String
     */
    @XmlElement(name = "exclude")
    public void setExclude(String exclude) {
        this.exclude = exclude != null ? exclude : "";
    }
}
