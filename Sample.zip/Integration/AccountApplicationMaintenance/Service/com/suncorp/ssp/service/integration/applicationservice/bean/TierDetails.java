////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code TierDetails} does this.
 * @author U383847
 * @since 09/02/2016
 * @version 1.0
 */
public class TierDetails {
    private String valueRangeTo;
    private String durationRangeTo;
    
    /**
     * Accessor for property valueRangeTo.
     * 
     * @return valueRangeTo of type String
     */
    public String getValueRangeTo() {
        return valueRangeTo;
    }
    
    /**
     * Mutator for property valueRangeTo.
     * 
     * @return valueRangeTo of type String
     */
    @XmlElement(name = "valueRangeTo")
    public void setValueRangeTo(String valueRangeTo) {
        this.valueRangeTo = valueRangeTo != null ? valueRangeTo : "";
    }
    
    /**
     * Accessor for property durationRangeTo.
     * 
     * @return durationRangeTo of type String
     */
    public String getDurationRangeTo() {
        return durationRangeTo;
    }
    
    /**
     * Mutator for property durationRangeTo.
     * 
     * @return durationRangeTo of type String
     */
    @XmlElement(name = "durationRangeTo")
    public void setDurationRangeTo(String durationRangeTo) {
        this.durationRangeTo = durationRangeTo != null ? durationRangeTo : "";
    }
}
