////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code RebalancingBean} does this.
 *
 * @author U383847
 * @since 19/03/2016
 * @version 1.0
 */
public class RebalancingBean {
    private String nextRebalanceDate;
    private String rebalanceImmediately;
    private String includeInRebalance;
    private RebalancingFrequencyBean rebalancingFrequencyBean;
    private CodeIdentifierDetails instructorCategoryCode;

    /**
     * Accessor for property nextRebalanceDate.
     *
     * @return nextRebalanceDate of type String
     */
    public String getNextRebalanceDate() {
        return nextRebalanceDate;
    }
    
    /**
     * Mutator for property nextRebalanceDate.
     *
     * @param nextRebalanceDate of type String
     */
    @XmlElement(name = "nextRebalanceDate")
    public void setNextRebalanceDate(String nextRebalanceDate) {
        this.nextRebalanceDate = nextRebalanceDate != null ? nextRebalanceDate : "";
    }
    
    /**
     * Accessor for property rebalanceImmediately.
     *
     * @return rebalanceImmediately of type String
     */
    public String getRebalanceImmediately() {
        return rebalanceImmediately;
    }
    
    /**
     * Mutator for property rebalanceImmediately.
     *
     * @param rebalanceImmediately of type String
     */
    @XmlElement(name = "rebalanceImmediately")
    public void setRebalanceImmediately(String rebalanceImmediately) {
        this.rebalanceImmediately = rebalanceImmediately != null ? rebalanceImmediately : "";
    }
    
    /**
     * Accessor for property includeInRebalance.
     *
     * @return includeInRebalance of type String
     */
    public String getIncludeInRebalance() {
        return includeInRebalance;
    }
    
    /**
     * Mutator for property includeInRebalance.
     *
     * @param includeInRebalance of type String
     */
    @XmlElement(name = "includeInRebalance")
    public void setIncludeInRebalance(String includeInRebalance) {
        this.includeInRebalance = includeInRebalance != null ? includeInRebalance : "";
    }
    
    /**
     * Accessor for property rebalancingFrequencyBean.
     *
     * @return rebalancingFrequencyBean of type RebalancingFrequencyBean
     */
    public RebalancingFrequencyBean getRebalancingFrequencyBean() {
        return rebalancingFrequencyBean;
    }

    /**
     * Mutator for property rebalancingFrequencyBean.
     *
     * @param rebalancingFrequencyBean of type RebalancingFrequencyBean
     */
    @XmlElement(name = "rebalancingFrequency")
    public void setRebalancingFrequencyBean(RebalancingFrequencyBean rebalancingFrequencyBean) {
        this.rebalancingFrequencyBean = rebalancingFrequencyBean;
    }

    /**
     * Accessor for property instructorCategoryCode.
     *
     * @return instructorCategoryCode of type CodeIdentifierDetails
     */
    public CodeIdentifierDetails getInstructorCategoryCode() {
        return instructorCategoryCode;
    }

    /**
     * Mutator for property instructorCategoryCode.
     *
     * @param instructorCategoryCode of type CodeIdentifierDetails
     */
    @XmlElement(name = "instructorCategoryCode")
    public void setInstructorCategoryCode(CodeIdentifierDetails instructorCategoryCode) {
        this.instructorCategoryCode = instructorCategoryCode;
    }
}
