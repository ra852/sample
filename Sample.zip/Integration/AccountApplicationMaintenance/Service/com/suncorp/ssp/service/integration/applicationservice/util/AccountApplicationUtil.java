////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.util;

import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.ClientIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CodeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.ExternalRefType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.FrequencyIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.GenericReference;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.MasterSchemeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.identifiertype.IdentifierAuditType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.RegularPlanType;
import com.sonatacentral.service.v30.life.application.CreateApplicationRequestType.Client;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.applicationservice.ApplicationServiceConstants;
import com.suncorp.ssp.service.integration.applicationservice.bean.AccountExternalReferenceDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.AccountIdentifierDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.AccountNumberDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.AuditDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.BankAccountIdentifier;
import com.suncorp.ssp.service.integration.applicationservice.bean.ClientDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.CodeIdentifierDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.CodeNameIdentifier;
import com.suncorp.ssp.service.integration.applicationservice.bean.FrequencyIdentifierInfo;
import com.suncorp.ssp.service.integration.applicationservice.bean.IDRefBean;
import com.suncorp.ssp.service.integration.applicationservice.bean.MasterSchemeIdentifierDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.RebalancingBean;
import com.suncorp.ssp.service.integration.applicationservice.bean.RebalancingFrequencyBean;
import com.suncorp.ssp.service.integration.applicationservice.bean.RegularPlanDetails;

/**
 * The class {@code AccountApplicationUtil} does this.
 * 
 * @author U383847
 * @since 10/02/2016
 * @version 1.0
 */
public class AccountApplicationUtil {
    private final String className = "AccountApplicationUtil";

    public AccountApplicationUtil() {

    }

    /**
     * Get Account Identifier Type Details.
     * 
     * @param accountEntityDetails
     * @param accountEntityType
     */
    public void getAccountIdentifierType(AccountIdentifierType account, AccountIdentifierDetails accountIdentifierDetails) {
        if (account != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Account Identifier Type");
            accountIdentifierDetails.setAccountId(account.getId().toString());
            accountIdentifierDetails.setAccountName(account.getName());
            this.getAccountNumberDetails(accountIdentifierDetails, account);
            this.getAccountIdentifierExternalReference(accountIdentifierDetails, account);
            this.getAccountStatusDetails(accountIdentifierDetails, account);
            accountIdentifierDetails.setAudit(this.createAuditInfo(account.getAudit()));
        }
    }

    /**
     * Get Account Client Pointer Reference.
     * 
     * @param clientReferenceId
     * @return
     */
    public ClientIdentifierType getClientPointerReference(Object clientReferenceId) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Account Client Pointer Reference");
        GenericReference genericReference = new GenericReference();
        genericReference.setRef(clientReferenceId);
        ClientIdentifierType client = new ClientIdentifierType();
        client.setClientPointer(genericReference);
        return client;
    }

    /**
     * Get Account Number Details.
     * 
     * @param accountIdentifierDetails
     * @param account
     */
    private void getAccountNumberDetails(AccountIdentifierDetails accountIdentifierDetails, AccountIdentifierType account) {
        AccountNumberDetails accountNumberDetails = new AccountNumberDetails();
        if (account.getAccountNumber() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Account Number Details");
            accountNumberDetails.setAccountNumber(account.getAccountNumber().getAccountNo());
            accountNumberDetails.setProductName(account.getAccountNumber().getProductName());
            accountIdentifierDetails.setAccountNumber(accountNumberDetails);
        } else {
            accountNumberDetails.setAccountNumber("");
            accountNumberDetails.setProductName("");
        }
        accountIdentifierDetails.setAccountNumber(accountNumberDetails);
    }

    /**
     * Get Account Identifier External Reference Details.
     * 
     * @param accountIdentifierDetails
     * @param account
     */
    private void getAccountIdentifierExternalReference(AccountIdentifierDetails accountIdentifierDetails, AccountIdentifierType account) {
        AccountExternalReferenceDetails accountExternalReferenceDetails = new AccountExternalReferenceDetails();
        if (account.getAccountExternalRef() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Account External Reference Details");
            accountExternalReferenceDetails.setExternalReferenceCode(account.getAccountExternalRef().getReferenceCode());
            accountExternalReferenceDetails.setExternalReferenceType(account.getAccountExternalRef().getReference());
        } else {
            accountExternalReferenceDetails.setExternalReferenceCode("");
            accountExternalReferenceDetails.setExternalReferenceType("");
        }
        accountIdentifierDetails.setAccountExternalReference(accountExternalReferenceDetails);
    }

    /**
     * Get Account Status Details.
     * 
     * @param accountIdentifierDetails
     * @param account
     */
    private void getAccountStatusDetails(AccountIdentifierDetails accountIdentifierDetails, AccountIdentifierType account) {
        if (account.getStatusCode() != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Account Status Details");
            CodeIdentifierDetails codeIdentifierDetails = new CodeIdentifierDetails();
            codeIdentifierDetails.setId(account.getStatusCode().getId().toString());
            codeIdentifierDetails.setCode(account.getStatusCode().getCode());
            codeIdentifierDetails.setCodeType(account.getStatusCode().getCodeType());
            codeIdentifierDetails.setCodeDescription(account.getStatusCode().getCodeDescription());
            codeIdentifierDetails.setCodeShortDescription(account.getStatusCode().getCodeShortDescription());
            accountIdentifierDetails.setAccountStatus(codeIdentifierDetails);
        } else {
            accountIdentifierDetails.setAccountStatus(this.createDefaultCodeIdentifierInfo());
        }
    }

    /**
     * Get Client Pointer Details.
     * 
     * @param accountDetails
     * @return
     */
    public Client getClientPointerDetails(RegularPlanDetails regularPlanDetails) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Client Pointer Details");
        if (regularPlanDetails.getClientPointer() != null) {
            Client clientRequestDetailsType = new Client();
            clientRequestDetailsType.setId(regularPlanDetails.getClientPointer());
            return clientRequestDetailsType;
        }
        return null;
    }

    
    /**
     * Set ClientPointer Or Client Id Reference Details.
     * 
     * @param regularPlanType
     * @param regularPlan
     * @param clientObject
     * 
     */
    public void setClientIdClientRefDetails(RegularPlanType regularPlanType, RegularPlanDetails regularPlan, Object clientObject) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Client Id and Client Reference Details");
        if (clientObject != null) {
            regularPlanType.setClient(this.getClientPointerReference(clientObject));
        }

        if (regularPlan.getClient() != null) {
            regularPlanType.setClient(this.setClientInfo(regularPlan.getClient()));
        }

    }
        
    
    /**
     * Set ClientPointer Reference Details.
     * 
     * @param regularPlanType
     * @param clientObject
     * 
     */
    public void setClientRefDetails(RegularPlanType regularPlanType, Object clientObject) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Account Id and Client Reference Details");
        if (clientObject != null) {
            regularPlanType.setClient(this.getClientPointerReference(clientObject));
        }
        
    }
    
    
    /**
     * This method is used to create Default BankAccount Details, with necessary values set.
     * 
     * @return accountIdentifier of type BankAccountIdentifier
     */
    public BankAccountIdentifier createDefaultBankAccount() {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "createDefaultBankAccount()");
        BankAccountIdentifier accountIdentifier = new BankAccountIdentifier();
        accountIdentifier.setAudit(createDefaultAuditInfo());
        accountIdentifier.setBankAccountCurrencyCode(createDefaultBankAccCurrCode());
        accountIdentifier.setBankAccountNumber("");
        accountIdentifier.setBankAccountTypeCode("");
        accountIdentifier.setId("");
        accountIdentifier.setName("");
        return accountIdentifier;
    }

    /**
     * This method is used to create DefaultAuditInfo Details, with necessary values set.
     * 
     * @return auditDetails of type AuditDetails
     */
    public AuditDetails createDefaultAuditInfo() {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "createDefaultAuditInfo()");
        AuditDetails auditDetails = new AuditDetails();
        auditDetails.setDataVersion("");
        auditDetails.setLastUpdated("");
        auditDetails.setLastUpdatedBy("");
        return auditDetails;
    }

    /**
     * This method is used to create DefaultBankAccCurrCode Details, with necessary values set.
     * 
     * @return identifier of type CodeNameIdentifier
     */
    public CodeNameIdentifier createDefaultBankAccCurrCode() {
        CodeNameIdentifier identifier = new CodeNameIdentifier();
        identifier.setCode("");
        return identifier;
    }

    /**
     * This method is used to create AuditInfo, with necessary values set.
     * 
     * @param audit of type IdentifierAuditType
     * @return auditDetails of type AuditDetails
     */
    public AuditDetails createAuditInfo(IdentifierAuditType audit) {
        AuditDetails auditDetails = new AuditDetails();
        if (audit != null) {
            SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting Audit Details");
            if (Long.toString(audit.getDataVersion()) != null) {
                auditDetails.setDataVersion(String.valueOf(audit.getDataVersion()));
            } else {
                auditDetails.setDataVersion("");
            }
            if (audit.getLastUpdated() != null) {
                auditDetails.setLastUpdated(SILUtil.convertXMLGregorianCalendartoString(audit.getLastUpdated(), CommonConstants.DATE_FORMAT));
            } else {
                auditDetails.setLastUpdated("");
            }
            auditDetails.setLastUpdatedBy(audit.getLastUpdatedBy());
        } else {
            return createDefaultAuditInfo();
        }
        return auditDetails;
    }

    /**
     * This method is used to create FrequencyIdentifier Details, with necessary values set.
     * 
     * @param frequency of type FrequencyIdentifierType
     * @return frequencyIdentifierInfo of type FrequencyIdentifierInfo
     */
    public FrequencyIdentifierInfo createFrequencyIdentifier(FrequencyIdentifierType frequency) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Getting FrequencyIdentifier Details");
        FrequencyIdentifierInfo frequencyIdentifierInfo = new FrequencyIdentifierInfo();
        if (frequency != null) {
            if (frequency.getFistId() != null) {
                frequencyIdentifierInfo.setFistId(frequency.getFistId().toString());
            } else {
                frequencyIdentifierInfo.setFistId("");
            }
            frequencyIdentifierInfo.setFreqCode(frequency.getFreqCode());
            frequencyIdentifierInfo.setFreqSetCode(frequency.getFreqSetCode());
            frequencyIdentifierInfo.setId(frequency.getId().toString());
            frequencyIdentifierInfo.setName(frequency.getName());
        } else {
            return createDefaultFrequencyIdentifier();
        }
        return frequencyIdentifierInfo;
    }

    /**
     * This method is used to create Default FrequencyIdentifier, with necessary values set.
     * 
     * @return frequencyIdentifierInfo of type FrequencyIdentifierInfo
     */
    public FrequencyIdentifierInfo createDefaultFrequencyIdentifier() {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Entering createDefaultPaymentFreequency()");
        FrequencyIdentifierInfo frequencyIdentifierInfo = new FrequencyIdentifierInfo();
        frequencyIdentifierInfo.setFistId("");
        frequencyIdentifierInfo.setFreqCode("");
        frequencyIdentifierInfo.setFreqSetCode("");
        frequencyIdentifierInfo.setId("");
        frequencyIdentifierInfo.setName("");
        return frequencyIdentifierInfo;
    }

    /**
     * This method is used to create Default CodeNameIdentifier Details, with necessary values set.
     * 
     * @return identifier of type CodeNameIdentifier
     */
    public CodeNameIdentifier createDefaultCodeNameIdentifier() {
        CodeNameIdentifier identifier = new CodeNameIdentifier();
        identifier.setName("");
        identifier.setId("");
        identifier.setCode("");
        return identifier;
    }

    /**
     * This method is used to create CodeIdentifierInfo, with necessary values set.
     * 
     * @param typeCode of type CodeIdentifierType
     * @return codeIdentifier of type CodeIdentifier
     */
    public CodeIdentifierDetails createCodeIdentifierInfo(CodeIdentifierType typeCode) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "createCodeIdentifierInfo()");
        CodeIdentifierDetails codeIdentifier = new CodeIdentifierDetails();
        if (typeCode != null) {
            codeIdentifier.setCode(typeCode.getCode());
            codeIdentifier.setCodeDescription(typeCode.getCodeDescription());
            codeIdentifier.setCodeShortDescription(typeCode.getCodeShortDescription());
            codeIdentifier.setCodeType(typeCode.getCodeType());
            codeIdentifier.setId(typeCode.getId().toString());
        } else {
            return createDefaultCodeIdentifierInfo();
        }
        return codeIdentifier;
    }

    /**
     * This method is used to create DefaultCodeIdentifierInfo, with necessary values set.
     * 
     * * @return codeIdentifier of type CodeIdentifier
     */
    public CodeIdentifierDetails createDefaultCodeIdentifierInfo() {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "createDefaultCodeIdentifierInfo()");
        CodeIdentifierDetails codeIdentifier = new CodeIdentifierDetails();
        codeIdentifier.setCode("");
        codeIdentifier.setCodeDescription("");
        codeIdentifier.setCodeShortDescription("");
        codeIdentifier.setCodeType("");
        codeIdentifier.setId("");
        return codeIdentifier;
    }

    /**
     * This method is used to create Id, with necessary value set.
     * 
     * @param id of type String
     * @return accountId of type Long
     * @throws SILException
     */
    public Long createId(String id) throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "createId()");
        Long longId;
        try {
            longId = Long.parseLong(id);
        } catch (Exception ex) {
            throw new SILException(ApplicationServiceConstants.INVALID_ID_FORMAT);
        }
        return longId;
    }

    /**
     * This method is used to create CodeIdentifierType, with necessary values set.
     * 
     * @param codeIdentifierDetails of type CodeIdentifierDetails
     * @return codeIdentifierType of type CodeIdentifierType
     */
    public CodeIdentifierType createCodeIdentifierType(CodeIdentifierDetails codeIdentifierDetails) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Entering createCodeIdentifierType()");
        CodeIdentifierType codeIdentifierType = new CodeIdentifierType();
        String code = codeIdentifierDetails.getCode();
        String typeCode = codeIdentifierDetails.getCodeType();
        String shortDesc = codeIdentifierDetails.getCodeShortDescription();
        String longDesc = codeIdentifierDetails.getCodeDescription();
        if (code != null) {
            codeIdentifierType.setCode(code);
        }
        if (typeCode != null) {
            codeIdentifierType.setCodeType(typeCode);
        }
        if (shortDesc != null) {
            codeIdentifierType.setCodeShortDescription(shortDesc);
        }
        if (longDesc != null) {
            codeIdentifierType.setCodeDescription(longDesc);
        }
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Exiting createCodeIdentifierType()");
        return codeIdentifierType;
    }

    /**
     * This method is use to set CLient Info.
     * 
     * @param accountRequestDetailsType
     * @param pensionPaymentSplitDetails
     * @throws SILException
     */
    public ClientIdentifierType setClientInfo(ClientDetails client) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "setClient");
        ClientIdentifierType clientIdentifierType = new ClientIdentifierType();
        clientIdentifierType.setId(Long.valueOf(client.getClientId()));
        return clientIdentifierType;
    }

    /**
     * This method is used to create GenericReference, with necessary values set.
     * 
     * @param idRefBean of type IDRefBean
     * @return genericReference of type GenericReference
     */
    public GenericReference createClientPointer(IDRefBean idRefBean) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Entering createClientPointer()");
        GenericReference genericReference = new GenericReference();
        if (idRefBean != null) {
            genericReference.setId(idRefBean.getId());
            if (idRefBean.getReference() != null) {
                Client clientRequestDetailsType = new Client();
                clientRequestDetailsType.setId(idRefBean.getReference());
                genericReference.setRef(clientRequestDetailsType);
            }
        }
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Exiting createClientPointer()");
        return genericReference;
    }

    /**
     * This method is used to create clientPointer for response object, with necessary values set.
     * 
     * @param clientPointer of type GenericReference
     * @return outboundIDRefBean of type IDRefBean
     */
    public IDRefBean createClientPointer(GenericReference clientPointer) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Entering createClientPointer()");
        IDRefBean outboundIDRefBean = null;
        if (clientPointer != null) {
            outboundIDRefBean = new IDRefBean();
            outboundIDRefBean.setId(clientPointer.getId());
            outboundIDRefBean.setReference(clientPointer.getRef() != null ? ((Client) clientPointer.getRef()).getId() : "");
        } else {
            return createDefaultClientPointer();
        }
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Exiting createClientPointer()");
        return outboundIDRefBean;
    }

    /**
     * This method is used to create IDRefBean for clientPointer as response, with default values set.
     * 
     * @param genericReference of type GenericReference
     * @return outboundIDRefBean of type IDRefBean
     */
    public IDRefBean createDefaultClientPointer() {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Entering createDefaultClientPointer()");
        IDRefBean outboundIDRefBean = new IDRefBean();
        outboundIDRefBean.setId("");
        outboundIDRefBean.setReference("");
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Exiting createDefaultClientPointer()");
        return outboundIDRefBean;
    }

    /**
     * This method is used to create clientRef for response object, with necessary values set.
     * 
     * @param clientExtRef of type ExternalRefType
     * @return idRefbean of type IDRefBean
     */
    public IDRefBean createClientRef(ExternalRefType clientExtRef) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Entering createClientRef()");
        IDRefBean outboundIDRefBean = null;
        if (clientExtRef != null) {
            outboundIDRefBean = new IDRefBean();
            outboundIDRefBean.setReference(clientExtRef.getReference());
            outboundIDRefBean.setReferenceCode(clientExtRef.getReferenceCode());
        } else {
            return createDefaultClientRef();
        }
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Exiting createClientRef()");
        return outboundIDRefBean;
    }

    /**
     * This method is used to create clientRef for response object, with default values set.
     * 
     * @return outboundIDRefBean of type IDRefBean
     */
    public IDRefBean createDefaultClientRef() {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Entering createDefaultClientRef()");
        IDRefBean outboundIDRefBean = new IDRefBean();
        outboundIDRefBean.setReference("");
        outboundIDRefBean.setReferenceCode("");
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Exiting createDefaultClientRef()");
        return outboundIDRefBean;
    }

    /**
     * Returns a new instance of MasterSchemeBean, with necessary values set.
     * 
     * @return outboundMasterSchemeBean of type outboundMasterSchemeBean
     */
    public MasterSchemeIdentifierDetails createMasterScheme(MasterSchemeIdentifierType masterSchemeIdType) {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Entering createMasterSchemeBean()");
        MasterSchemeIdentifierDetails outboundMasterSchemeBean = null;
        if (masterSchemeIdType != null) {
            outboundMasterSchemeBean = new MasterSchemeIdentifierDetails();
            outboundMasterSchemeBean.setId(masterSchemeIdType.getId() != null ? masterSchemeIdType.getId().toString() : "");
            outboundMasterSchemeBean.setName(masterSchemeIdType.getName());
            outboundMasterSchemeBean.setDisplayName(masterSchemeIdType.getDisplayName());
            outboundMasterSchemeBean.setLongName(masterSchemeIdType.getLongName());
        } else {
            return createDefaultMasterScheme();
        }
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Exiting createMasterSchemeBean()");
        return outboundMasterSchemeBean;
    }

    /**
     * Returns a new instance of MasterSchemeBean, with default values set.
     * 
     * @return outboundMasterSchemeBean of type outboundMasterSchemeBean
     */
    public MasterSchemeIdentifierDetails createDefaultMasterScheme() {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Entering createDefaultMasterScheme()");
        MasterSchemeIdentifierDetails outboundMasterSchemeBean = new MasterSchemeIdentifierDetails();
        outboundMasterSchemeBean.setId("");
        outboundMasterSchemeBean.setName("");
        outboundMasterSchemeBean.setDisplayName("");
        outboundMasterSchemeBean.setLongName("");
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Exiting createDefaultMasterScheme()");
        return outboundMasterSchemeBean;
    }
    
    /**
     * Returns a new instance of RebalancingBean, with default values.
     *
     * @return rebalancingBean of type RebalancingBean
     */
    public RebalancingBean createDefaultRebalancingDetails() {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Entering createDefaultRebalancingDetails()");
        RebalancingBean rebalancingBean = new RebalancingBean();
        rebalancingBean.setNextRebalanceDate("");
        rebalancingBean.setRebalanceImmediately("");
        rebalancingBean.setIncludeInRebalance("");
        rebalancingBean.setInstructorCategoryCode(this.createDefaultCodeIdentifierInfo());
        rebalancingBean.setRebalancingFrequencyBean(this.createDefaultRebalancingFrequencyDetails());
        return rebalancingBean;
    }
    
    /**
     * Returns a new instance of RebalancingFrequencyBean, with default values.
     *
     * @return rebalancingFrequencyBean of type RebalancingFrequencyBean
     */
    public RebalancingFrequencyBean createDefaultRebalancingFrequencyDetails() {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Entering createDefaultRebalancingFrequencyDetails()");
        RebalancingFrequencyBean rebalancingFrequencyBean = new RebalancingFrequencyBean();
        rebalancingFrequencyBean.setId("");
        rebalancingFrequencyBean.setName("");
        rebalancingFrequencyBean.setFistId("");
        rebalancingFrequencyBean.setFreqCode("");
        rebalancingFrequencyBean.setFreqSetCode("");
        rebalancingFrequencyBean.setFreqSetCode("");
        return rebalancingFrequencyBean;
    }
}
