////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code AdvisorSplitDetails} does this.
 * @author U383847
 * @since 04/02/2016
 * @version 1.0
 */
public class AdvisorSplitDetails {
    private String advisorNumber;
    private String advisorForename;
    private String advisorSurname;
    private String advisorClientId;
    private String percentageSplit;
    private String primaryFlag;
    
    /**
     * Accessor for property advisorNumber.
     * 
     * @return advisorNumber of type String
     */
    public String getAdvisorNumber() {
        return advisorNumber;
    }

    /**
     * Mutator for property advisorNumber.
     * 
     * @param advisorNumber of type String
     */
    @XmlElement(name = "advisorNumber")
    public void setAdvisorNumber(String advisorNumber) {
        this.advisorNumber = advisorNumber != null ? advisorNumber : "";
    }

    /**
     * Accessor for property advisorForename.
     * 
     * @return advisorForename of type String
     */
    public String getAdvisorForename() {
        return advisorForename;
    }

    /**
     * Mutator for property advisorForename.
     * 
     * @param advisorForename of type String
     */
    @XmlElement(name = "advisorForename")
    public void setAdvisorForename(String advisorForename) {
        this.advisorForename = advisorForename != null ? advisorForename : "";
    }

    /**
     * Accessor for property advisorSurname.
     * 
     * @return advisorSurname of type String
     */
    public String getAdvisorSurname() {
        return advisorSurname;
    }

    /**
     * Mutator for property advisorSurname.
     * 
     * @param advisorSurname of type String
     */
    @XmlElement(name = "advisorSurname")
    public void setAdvisorSurname(String advisorSurname) {
        this.advisorSurname = advisorSurname != null ? advisorSurname : "";
    }

    /**
     * Accessor for property advisorClientId.
     * 
     * @return advisorClientId of type String
     */
    public String getAdvisorClientId() {
        return advisorClientId;
    }

    /**
     * Mutator for property advisorClientId.
     * 
     * @param advisorClientId of type String
     */
    @XmlElement(name = "advisorClientId")
    public void setAdvisorClientId(String advisorClientId) {
        this.advisorClientId = advisorClientId;
    }    

    /**
     * Accessor for property percentageSplit.
     * 
     * @return percentageSplit of type String
     */
    public String getPercentageSplit() {
        return percentageSplit;
    }

    /**
     * Mutator for property percentageSplit.
     * 
     * @param percentageSplit of type String
     */
    @XmlElement(name = "percentageSplit")
    public void setPercentageSplit(String percentageSplit) {
        this.percentageSplit = percentageSplit != null ? percentageSplit : "";
    }

    /**
     * Accessor for property primaryFlag.
     * 
     * @return primaryFlag of type String
     */
    public String getPrimaryFlag() {
        return primaryFlag;
    }

    /**
     * Mutator for property primaryFlag.
     * 
     * @param primaryFlag of type String
     */
    @XmlElement(name = "primaryFlag")
    public void setPrimaryFlag(String primaryFlag) {
        this.primaryFlag = primaryFlag != null ? primaryFlag : "";
    }
}
