////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code AccountAdvisorDetails} does this.
 * @author U383847
 * @since 03/02/2016
 * @version 1.0
 */
public class AccountAdvisorDetails {
    private String advisorgroupId;
    private String relationshipId;
    private String relationshipCode;
    private String relationshipName;
    private List<AdvisorSplitDetails> advisorSplit;

    /**
     * Accessor for property advisorgroupId.
     * 
     * @return advisorgroupId of type String
     */
    public String getAdvisorgroupId() {
        return advisorgroupId;
    }

    /**
     * Mutator for property advisorgroupId.
     * 
     * @param advisorgroupId of type String
     */
    @XmlElement(name = "advisorgroupId")
    public void setAdvisorgroupId(String advisorgroupId) {
        this.advisorgroupId = advisorgroupId != null ? advisorgroupId : "";
    }

    /**
     * Accessor for property relationshipId.
     * 
     * @return relationshipId of type String
     */
    public String getRelationshipId() {
        return relationshipId;
    }

    /**
     * Mutator for property relationshipId.
     * 
     * @param relationshipId of type String
     */
    @XmlElement(name = "relationshipId")
    public void setRelationshipId(String relationshipId) {
        this.relationshipId = relationshipId != null ? relationshipId : "";
    }

    /**
     * Accessor for property relationshipCode.
     * 
     * @return relationshipCode of type String
     */
    public String getRelationshipCode() {
        return relationshipCode;
    }

    /**
     * Mutator for property relationshipCode.
     * 
     * @param relationshipCode of type String
     */
    @XmlElement(name = "relationshipCode")
    public void setRelationshipCode(String relationshipCode) {
        this.relationshipCode = relationshipCode != null ? relationshipCode : "";
    }
    
    /**
     * Accessor for property relationshipName.
     * 
     * @return relationshipName of type String
     */
    public String getRelationshipName() {
        return relationshipName;
    }

    /**
     * Mutator for property relationshipName.
     * 
     * @return relationshipName of type String
     */
    @XmlElement(name = "relationshipName")
    public void setRelationshipName(String relationshipName) {
        this.relationshipName = relationshipName != null ? relationshipName : "";
    }
    
    /**
     * Accessor for property advisorSplit.
     * 
     * @return advisorSplit of type List<AdvisorSplitDetails>
     */
    public List<AdvisorSplitDetails> getAdvisorSplit() {
        return advisorSplit;
    }

    /**
     * Mutator for property advisorSplit.
     * 
     * @param advisorSplit of type List<AdvisorSplitDetails>
     */
    @XmlElement(name = "advisorSplitDetails")
    public void setAdvisorSplit(List<AdvisorSplitDetails> advisorSplit) {
        this.advisorSplit = advisorSplit;
    }
}
