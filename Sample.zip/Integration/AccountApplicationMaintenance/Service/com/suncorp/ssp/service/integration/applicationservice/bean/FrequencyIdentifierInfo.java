////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code FrequencyIdentifierInfo} does this.
 * 
 * @author U386868
 * @since 10/02/2016
 * @version 1.0
 */
public class FrequencyIdentifierInfo {

    private String id;
    private String name;
    private String fistId;
    private String freqSetCode;
    private String freqCode;

    /**
     * Accessor for property id.
     * 
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     * 
     * @return id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id != null ? id : "";
    }

    /**
     * Accessor for property name.
     * 
     * @return name of type String
     */
    public String getName() {
        return name;
    }

    /**
     * Mutator for property name.
     * 
     * @return name of type String
     */
    @XmlElement(name = "name")
    public void setName(String name) {
        this.name = name != null ? name : "";
    }

    /**
     * Accessor for property fistId.
     * 
     * @return fistId of type String
     */
    public String getFistId() {
        return fistId;
    }

    /**
     * Mutator for property fistId.
     * 
     * @return fistId of type String
     */
    @XmlElement(name = "fistId")
    public void setFistId(String fistId) {
        this.fistId = fistId != null ? fistId : "";
    }

    /**
     * Accessor for property freqSetCode.
     * 
     * @return freqSetCode of type String
     */
    public String getFreqSetCode() {
        return freqSetCode;
    }

    /**
     * Mutator for property freqSetCode.
     * 
     * @return freqSetCode of type String
     */
    @XmlElement(name = "freqSetCode")
    public void setFreqSetCode(String freqSetCode) {
        this.freqSetCode = freqSetCode != null ? freqSetCode : "";
    }

    /**
     * Accessor for property freqCode.
     * 
     * @return freqCode of type String
     */
    public String getFreqCode() {
        return freqCode;
    }

    /**
     * Mutator for property freqCode.
     * 
     * @return freqCode of type String
     */
    @XmlElement(name = "freqCode")
    public void setFreqCode(String freqCode) {
        this.freqCode = freqCode != null ? freqCode : "";
    }

}
