////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code ExpenseLineDetails} does this.
 * 
 * @author U383847
 * @since 09/02/2016
 * @version 1.0
 */
public class ExpenseLineDetails {
    private String id;
    private String override;
    private ExpCalcBasisIdentifierDetails expCalcBasis;
    private List<ExpenseParameterDetails> parameters;
    private String maxConsentAmount;
    private String maxConsentPercentage;
    private List<ExcludedAssetClassDetails> excludedAssetClass;
    private CodeIdentifierDetails chargeBasis;
    private AccountIdentifierDetails feeAccount;
    
    /**
     * Accessor for property id.
     * 
     * @return id of type String
     */
    public String getId() {
        return id;
    }
    
    /**
     * Mutator for property id.
     * 
     * @return id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id != null ? id : "";
    }
    
    /**
     * Accessor for property override.
     * 
     * @return override of type String
     */
    public String getOverride() {
        return override;
    }
    
    /**
     * Mutator for property override.
     * 
     * @return override of type String
     */
    @XmlElement(name = "override")
    public void setOverride(String override) {
        this.override = override != null ? override : "";
    }
    
    /**
     * Accessor for property expCalcBasis.
     * 
     * @return expCalcBasis of type ExpCalcBasisIdentifierDetails
     */
    public ExpCalcBasisIdentifierDetails getExpCalcBasis() {
        return expCalcBasis;
    }

    /**
     * Mutator for property expCalcBasis.
     * 
     * @return expCalcBasis of type ExpCalcBasisIdentifierDetails
     */
    @XmlElement(name = "expCalcBasis")
    public void setExpCalcBasis(ExpCalcBasisIdentifierDetails expCalcBasis) {
        this.expCalcBasis = expCalcBasis;
    }

    /**
     * Accessor for property parameters.
     * 
     * @return parameters of type List<ExpenseParameterDetails>
     */
    public List<ExpenseParameterDetails> getParameters() {
        return parameters;
    }
    
    /**
     * Mutator for property parameters.
     * 
     * @return parameters of type List<ExpenseParameterDetails>
     */
    @XmlElement(name = "parameters")
    public void setParameters(List<ExpenseParameterDetails> parameters) {
        this.parameters = parameters;
    }

    /**
     * Accessor for property maxConsentAmount.
     * 
     * @return maxConsentAmount of type String
     */
    public String getMaxConsentAmount() {
        return maxConsentAmount;
    }

    /**
     * Mutator for property maxConsentAmount.
     * 
     * @return maxConsentAmount of type String
     */
    @XmlElement(name = "maxConsentAmount")
    public void setMaxConsentAmount(String maxConsentAmount) {
        this.maxConsentAmount = maxConsentAmount != null ? maxConsentAmount : "";
    }

    /**
     * Accessor for property maxConsentPercentage.
     * 
     * @return maxConsentPercentage of type String
     */
    public String getMaxConsentPercentage() {
        return maxConsentPercentage;
    }

    /**
     * Mutator for property maxConsentPercentage.
     * 
     * @return maxConsentPercentage of type String
     */
    @XmlElement(name = "maxConsentPercentage")
    public void setMaxConsentPercentage(String maxConsentPercentage) {
        this.maxConsentPercentage = maxConsentPercentage != null ? maxConsentPercentage : "";
    }

    /**
     * Accessor for property excludedAssetClass.
     * 
     * @return excludedAssetClass of type List<ExcludedAssetClassDetails>
     */
    public List<ExcludedAssetClassDetails> getExcludedAssetClass() {
        return excludedAssetClass;
    }

    /**
     * Mutator for property excludedAssetClass.
     * 
     * @return excludedAssetClass of type List<ExcludedAssetClassDetails>
     */
    @XmlElement(name = "excludedAssetClass")
    public void setExcludedAssetClass(List<ExcludedAssetClassDetails> excludedAssetClass) {
        this.excludedAssetClass = excludedAssetClass;
    }

    /**
     * Accessor for property chargeBasis.
     * 
     * @return chargeBasis of type CodeIdentifierDetails
     */
    public CodeIdentifierDetails getChargeBasis() {
        return chargeBasis;
    }

    /**
     * Mutator for property chargeBasis.
     * 
     * @return chargeBasis of type CodeIdentifierDetails
     */
    @XmlElement(name = "chargeBasis")
    public void setChargeBasis(CodeIdentifierDetails chargeBasis) {
        this.chargeBasis = chargeBasis;
    }

    /**
     * Accessor for property feeAccount.
     * 
     * @return feeAccount of type AccountIdentifierDetails
     */
    public AccountIdentifierDetails getFeeAccount() {
        return feeAccount;
    }

    /**
     * Mutator for property feeAccount.
     * 
     * @return feeAccount of type AccountIdentifierDetails
     */
    @XmlElement(name = "feeAccount")
    public void setFeeAccount(AccountIdentifierDetails feeAccount) {
        this.feeAccount = feeAccount;
    }
}
