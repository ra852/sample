////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code ClientDetails} is a java bean consisting of properties related to client details.
 * 
 * @author U383847
 * @since 05/01/2016
 * @version 1.0
 */
public class ClientDetails {
    private String clientId;
    private String surname;
    private String firstName;
    private String middleName;
    private String initials;
    private String salutation;
    private String dateofBirth;
    private String ageAdmitted;
    private String dateofDeath;
    private String countryCode;
    private String countryName;
    private String contactName;
    private String businessName;
    private String workNumber;
    private String homeNumber;
    private String mobileNumber;
    private String occupationId;
    private String occupationCode;
    private String occupationName;
    private String disclaimerSigned;
    private String preferCurrencyCode;
    private String preferCurrencyName;
    private String mailingName;
    private String holdCorrespondence;
    private String canSolicit;
    private String secureSalaryFlag;
    private String plannedRetirementDate;
    private List<ClientAddressDetails> addressTypeList;
    private CountryDetails countryDetails;
    private CodeIdentifierDetails client;
    private CodeIdentifierDetails title;
    private CodeIdentifierDetails gender;
    private CodeIdentifierDetails maritalStatus;
    private CodeIdentifierDetails preferredLanguage;
    private CodeIdentifierDetails status;
    private CodeIdentifierDetails onlineStatus;
    private CodeIdentifierDetails preferredRisk;
    private CodeIdentifierDetails investorTypeCompany;
    private CodeIdentifierDetails investorTypePersonal;
    private CodeIdentifierDetails nationality;
    private CodeIdentifierDetails correspondingViewOption;
    private CodeIdentifierDetails correspondingDeliveryPreference;
    private List<BankAccountDetails> bankAccount;

    // For Add Beneficiary
    private String name;
    private MasterSchemeIdentifierDetails masterScheme;
    private IDRefBean clientPointer;
    private IDRefBean clientRef;
    private String clientSurname;
    private String clientForename;
    private String clientForename2;
    private String clientTFN;
    private AuditDetails audit;
    private String globalIntermediaryIDNumber;
    private List<GenericVariableDetails> genericVariables;
    private String hasWorkDeclaration;

    /**
     * Accessor for property clientId.
     * 
     * @return clientId of type String
     */
    public String getClientId() {
        return clientId;
    }

    /**
     * Mutator for property clientId.
     * 
     * @param clientId of type String
     */
    @XmlElement(name = "clientId")
    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    /**
     * Accessor for property surname.
     * 
     * @return surname of type String
     */
    public String getSurname() {
        return surname;
    }

    /**
     * Mutator for property surname.
     * 
     * @param surname of type String
     */
    @XmlElement(name = "surname")
    public void setSurname(String surname) {
        this.surname = surname != null ? surname : "";
    }

    /**
     * Accessor for property firstName.
     * 
     * @return firstName of type String
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Mutator for property firstName.
     * 
     * @param firstName of type String
     */
    @XmlElement(name = "firstName")
    public void setFirstName(String firstName) {
        this.firstName = firstName != null ? firstName : "";
    }

    /**
     * Accessor for property middleName.
     * 
     * @return middleName of type String
     */
    public String getMiddleName() {
        return middleName;
    }

    /**
     * Mutator for property middleName.
     * 
     * @param middleName of type String
     */
    @XmlElement(name = "middleName")
    public void setMiddleName(String middleName) {
        this.middleName = middleName != null ? middleName : "";
    }

    /**
     * Accessor for property initials.
     * 
     * @return initials of type String
     */
    public String getInitials() {
        return initials;
    }

    /**
     * Mutator for property initials.
     * 
     * @param initials of type String
     */
    @XmlElement(name = "initials")
    public void setInitials(String initials) {
        this.initials = initials != null ? initials : "";
    }

    /**
     * Accessor for property salutation.
     * 
     * @return salutation of type String
     */
    public String getSalutation() {
        return salutation;
    }

    /**
     * Mutator for property salutation.
     * 
     * @param salutation of type String
     */
    @XmlElement(name = "salutation")
    public void setSalutation(String salutation) {
        this.salutation = salutation != null ? salutation : "";
    }

    /**
     * Accessor for property dateofBirth.
     * 
     * @return dateofBirth of type String
     */
    public String getDateofBirth() {
        return dateofBirth;
    }

    /**
     * Mutator for property dateofBirth.
     * 
     * @param dateofBirth of type String
     */
    @XmlElement(name = "dob")
    public void setDateofBirth(String dateofBirth) {
        this.dateofBirth = dateofBirth != null ? dateofBirth : "";
    }

    /**
     * Accessor for property ageAdmitted.
     * 
     * @return ageAdmitted of type String
     */
    public String getAgeAdmitted() {
        return ageAdmitted;
    }

    /**
     * Mutator for property ageAdmitted.
     * 
     * @param ageAdmitted of type String
     */
    @XmlElement(name = "ageAdmitted")
    public void setAgeAdmitted(String ageAdmitted) {
        this.ageAdmitted = ageAdmitted != null ? ageAdmitted : "";
    }

    /**
     * Accessor for property dateofDeath.
     * 
     * @return dateofDeath of type String
     */
    public String getDateofDeath() {
        return dateofDeath;
    }

    /**
     * Mutator for property dateofDeath.
     * 
     * @param dateofDeath of type String
     */
    @XmlElement(name = "dod")
    public void setDateofDeath(String dateofDeath) {
        this.dateofDeath = dateofDeath != null ? dateofDeath : "";
    }

    /**
     * Accessor for property countryCode.
     * 
     * @return countryCode of type String
     */
    public String getCountryCode() {
        return countryCode;
    }

    /**
     * Mutator for property countryCode.
     * 
     * @param countryCode of type String
     */
    @XmlElement(name = "countryCode")
    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode != null ? countryCode : "";
    }

    /**
     * Accessor for property countryName.
     * 
     * @return countryName of type String
     */
    public String getCountryName() {
        return countryName;
    }

    /**
     * Mutator for property countryName.
     * 
     * @param countryName of type String
     */
    @XmlElement(name = "countryName")
    public void setCountryName(String countryName) {
        this.countryName = countryName != null ? countryName : "";
    }

    /**
     * Accessor for property contactName.
     * 
     * @return contactName of type String
     */
    public String getContactName() {
        return contactName;
    }

    /**
     * Mutator for property contactName.
     * 
     * @param contactName of type String
     */
    @XmlElement(name = "contactName")
    public void setContactName(String contactName) {
        this.contactName = contactName != null ? contactName : "";
    }

    /**
     * Accessor for property businessName.
     * 
     * @return businessName of type String
     */
    public String getBusinessName() {
        return businessName;
    }

    /**
     * Mutator for property businessName.
     * 
     * @param businessName of type String
     */
    @XmlElement(name = "businessName")
    public void setBusinessName(String businessName) {
        this.businessName = businessName != null ? businessName : "";
    }

    /**
     * Accessor for property workNumber.
     * 
     * @return workNumber of type String
     */
    public String getWorkNumber() {
        return workNumber;
    }

    /**
     * Mutator for property workNumber.
     * 
     * @param workNumber of type String
     */
    @XmlElement(name = "workNumber")
    public void setWorkNumber(String workNumber) {
        this.workNumber = workNumber != null ? workNumber : "";
    }

    /**
     * Accessor for property homeNumber.
     * 
     * @return homeNumber of type String
     */
    public String getHomeNumber() {
        return homeNumber;
    }

    /**
     * Mutator for property homeNumber.
     * 
     * @param homeNumber of type String
     */
    @XmlElement(name = "homeNumber")
    public void setHomeNumber(String homeNumber) {
        this.homeNumber = homeNumber != null ? homeNumber : "";
    }

    /**
     * Accessor for property mobileNumber.
     * 
     * @return mobileNumber of type String
     */
    public String getMobileNumber() {
        return mobileNumber;
    }

    /**
     * Mutator for property mobileNumber.
     * 
     * @param mobileNumber of type String
     */
    @XmlElement(name = "mobileNumber")
    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber != null ? mobileNumber : "";
    }

    /**
     * Accessor for property occupationId.
     * 
     * @return occupationId of type String
     */
    public String getOccupationId() {
        return occupationId;
    }

    /**
     * Mutator for property occupationId.
     * 
     * @return occupationId of type String
     */
    @XmlElement(name = "occupationId")
    public void setOccupationId(String occupationId) {
        this.occupationId = occupationId;
    }

    /**
     * Accessor for property occupationCode.
     * 
     * @return occupationCode of type String
     */
    public String getOccupationCode() {
        return occupationCode;
    }

    /**
     * Mutator for property occupationCode.
     * 
     * @param occupationCode of type String
     */
    @XmlElement(name = "occupation")
    public void setOccupationCode(String occupationCode) {
        this.occupationCode = occupationCode != null ? occupationCode : "";
    }

    /**
     * Accessor for property occupationName.
     * 
     * @return occupationName of type String
     */
    public String getOccupationName() {
        return occupationName;
    }

    /**
     * Mutator for property occupationName.
     * 
     * @param occupationName of type String
     */
    @XmlElement(name = "occupationName")
    public void setOccupationName(String occupationName) {
        this.occupationName = occupationName != null ? occupationName : "";
    }

    /**
     * Accessor for property disclaimerSigned.
     * 
     * @return disclaimerSigned of type String
     */
    public String getDisclaimerSigned() {
        return disclaimerSigned;
    }

    /**
     * Mutator for property disclaimerSigned.
     * 
     * @param disclaimerSigned of type String
     */
    @XmlElement(name = "disclaimerSigned")
    public void setDisclaimerSigned(String disclaimerSigned) {
        this.disclaimerSigned = disclaimerSigned != null ? disclaimerSigned : "";
    }

    /**
     * Accessor for property preferCurrencyCode.
     * 
     * @return preferCurrencyCode of type String
     */
    public String getPreferCurrencyCode() {
        return preferCurrencyCode;
    }

    /**
     * Mutator for property preferCurrencyCode.
     * 
     * @param preferCurrencyCode of type String
     */
    @XmlElement(name = "preferCurrencyCode")
    public void setPreferCurrencyCode(String preferCurrencyCode) {
        this.preferCurrencyCode = preferCurrencyCode != null ? preferCurrencyCode : "";
    }

    /**
     * Accessor for property preferCurrencyName.
     * 
     * @return preferCurrencyName of type String
     */
    public String getPreferCurrencyName() {
        return preferCurrencyName;
    }

    /**
     * Mutator for property preferCurrencyName.
     * 
     * @param preferCurrencyName of type String
     */
    @XmlElement(name = "preferCurrencyName")
    public void setPreferCurrencyName(String preferCurrencyName) {
        this.preferCurrencyName = preferCurrencyName != null ? preferCurrencyName : "";
    }

    /**
     * Accessor for property mailingName.
     * 
     * @return mailingName of type String
     */
    public String getMailingName() {
        return mailingName;
    }

    /**
     * Mutator for property mailingName.
     * 
     * @param mailingName of type String
     */
    @XmlElement(name = "mailingName")
    public void setMailingName(String mailingName) {
        this.mailingName = mailingName != null ? mailingName : "";
    }

    /**
     * Accessor for property holdCorrespondence.
     * 
     * @return holdCorrespondence of type String
     */
    public String getHoldCorrespondence() {
        return holdCorrespondence;
    }

    /**
     * Mutator for property holdCorrespondence.
     * 
     * @param holdCorrespondence of type String
     */
    @XmlElement(name = "holdCorrespondence")
    public void setHoldCorrespondence(String holdCorrespondence) {
        this.holdCorrespondence = holdCorrespondence != null ? holdCorrespondence : "";
    }

    /**
     * Accessor for property canSolicit.
     * 
     * @return canSolicit of type String
     */
    public String getCanSolicit() {
        return canSolicit;
    }

    /**
     * Mutator for property canSolicit.
     * 
     * @param canSolicit of type String
     */
    @XmlElement(name = "canSolicit")
    public void setCanSolicit(String canSolicit) {
        this.canSolicit = canSolicit != null ? canSolicit : "";
    }

    /**
     * Accessor for property secureSalaryFlag.
     * 
     * @return secureSalaryFlag of type String
     */
    public String getSecureSalaryFlag() {
        return secureSalaryFlag;
    }

    /**
     * Mutator for property secureSalaryFlag.
     * 
     * @param secureSalaryFlag of type String
     */
    @XmlElement(name = "secureSalaryFlag")
    public void setSecureSalaryFlag(String secureSalaryFlag) {
        this.secureSalaryFlag = secureSalaryFlag != null ? secureSalaryFlag : "";
    }

    /**
     * Accessor for property plannedRetirementDate.
     * 
     * @return plannedRetirementDate of type String
     */
    public String getPlannedRetirementDate() {
        return plannedRetirementDate;
    }

    /**
     * Mutator for property plannedRetirementDate.
     * 
     * @param plannedRetirementDate of type String
     */
    @XmlElement(name = "plannedRetirementDate")
    public void setPlannedRetirementDate(String plannedRetirementDate) {
        this.plannedRetirementDate = plannedRetirementDate != null ? plannedRetirementDate : "";
    }

    /**
     * Accessor for property addressTypeList.
     * 
     * @return addressTypeList of type List<ClientAddressDetails>
     */
    public List<ClientAddressDetails> getAddressTypeList() {
        return addressTypeList;
    }

    /**
     * Mutator for property addressTypeList.
     * 
     * @param addressTypeList of type List<ClientAddressDetails>
     */
    @XmlElement(name = "addressDetails")
    public void setAddressTypeList(List<ClientAddressDetails> addressTypeList) {
        this.addressTypeList = addressTypeList;
    }

    /**
     * Accessor for property countryDetails.
     * 
     * @return countryDetails of type CountryDetails
     */
    public CountryDetails getCountryDetails() {
        return countryDetails;
    }

    /**
     * Mutator for property countryDetails.
     * 
     * @param countryDetails of type CountryDetails
     */
    @XmlElement(name = "country")
    public void setCountryDetails(CountryDetails countryDetails) {
        this.countryDetails = countryDetails;
    }

    /**
     * Accessor for property client.
     * 
     * @return client of type CodeIdentifierDetails
     */
    public CodeIdentifierDetails getClient() {
        return client;
    }

    /**
     * Mutator for property client.
     * 
     * @param client of type CodeIdentifierDetails
     */
    @XmlElement(name = "client")
    public void setClient(CodeIdentifierDetails client) {
        this.client = client;
    }

    /**
     * Accessor for property title.
     * 
     * @return title of type CodeIdentifierDetails
     */
    public CodeIdentifierDetails getTitle() {
        return title;
    }

    /**
     * Mutator for property title.
     * 
     * @param title of type CodeIdentifierDetails
     */
    @XmlElement(name = "title")
    public void setTitle(CodeIdentifierDetails title) {
        this.title = title;
    }

    /**
     * Accessor for property gender.
     * 
     * @return gender of type CodeIdentifierDetails
     */
    public CodeIdentifierDetails getGender() {
        return gender;
    }

    /**
     * Mutator for property gender.
     * 
     * @param gender of type CodeIdentifierDetails
     */
    @XmlElement(name = "gender")
    public void setGender(CodeIdentifierDetails gender) {
        this.gender = gender;
    }

    /**
     * Accessor for property maritalStatus.
     * 
     * @return maritalStatus of type CodeIdentifierDetails
     */
    public CodeIdentifierDetails getMaritalStatus() {
        return maritalStatus;
    }

    /**
     * Mutator for property maritalStatus.
     * 
     * @param maritalStatus of type CodeIdentifierDetails
     */
    @XmlElement(name = "maritalStatus")
    public void setMaritalStatus(CodeIdentifierDetails maritalStatus) {
        this.maritalStatus = maritalStatus;
    }

    /**
     * Accessor for property preferredLanguage.
     * 
     * @return preferredLanguage of type CodeIdentifierDetails
     */
    public CodeIdentifierDetails getPreferredLanguage() {
        return preferredLanguage;
    }

    /**
     * Mutator for property preferredLanguage.
     * 
     * @param preferredLanguage of type CodeIdentifierDetails
     */
    @XmlElement(name = "preferredLanguage")
    public void setPreferredLanguage(CodeIdentifierDetails preferredLanguage) {
        this.preferredLanguage = preferredLanguage;
    }

    /**
     * Accessor for property status.
     * 
     * @return status of type CodeIdentifierDetails
     */
    public CodeIdentifierDetails getStatus() {
        return status;
    }

    /**
     * Mutator for property status.
     * 
     * @param status of type CodeIdentifierDetails
     */
    @XmlElement(name = "status")
    public void setStatus(CodeIdentifierDetails status) {
        this.status = status;
    }

    /**
     * Accessor for property onlineStatus.
     * 
     * @return onlineStatus of type CodeIdentifierDetails
     */
    public CodeIdentifierDetails getOnlineStatus() {
        return onlineStatus;
    }

    /**
     * Mutator for property onlineStatus.
     * 
     * @param onlineStatus of type CodeIdentifierDetails
     */
    @XmlElement(name = "onlineStatus")
    public void setOnlineStatus(CodeIdentifierDetails onlineStatus) {
        this.onlineStatus = onlineStatus;
    }

    /**
     * Accessor for property preferredRisk.
     * 
     * @return preferredRisk of type CodeIdentifierDetails
     */
    public CodeIdentifierDetails getPreferredRisk() {
        return preferredRisk;
    }

    /**
     * Mutator for property preferredRisk.
     * 
     * @param preferredRisk of type CodeIdentifierDetails
     */
    @XmlElement(name = "preferredRisk")
    public void setPreferredRisk(CodeIdentifierDetails preferredRisk) {
        this.preferredRisk = preferredRisk;
    }

    /**
     * Accessor for property investorTypeCompany.
     * 
     * @return investorTypeCompany of type CodeIdentifierDetails
     */
    public CodeIdentifierDetails getInvestorTypeCompany() {
        return investorTypeCompany;
    }

    /**
     * Mutator for property investorTypeCompany.
     * 
     * @param investorTypeCompany of type CodeIdentifierDetails
     */
    @XmlElement(name = "investorTypeCompany")
    public void setInvestorTypeCompany(CodeIdentifierDetails investorTypeCompany) {
        this.investorTypeCompany = investorTypeCompany;
    }

    /**
     * Accessor for property investorTypePersonal.
     * 
     * @return investorTypePersonal of type CodeIdentifierDetails
     */
    public CodeIdentifierDetails getInvestorTypePersonal() {
        return investorTypePersonal;
    }

    /**
     * Mutator for property investorTypePersonal.
     * 
     * @param investorTypePersonal of type CodeIdentifierDetails
     */
    @XmlElement(name = "investorTypePersonal")
    public void setInvestorTypePersonal(CodeIdentifierDetails investorTypePersonal) {
        this.investorTypePersonal = investorTypePersonal;
    }

    /**
     * Accessor for property nationality.
     * 
     * @return nationality of type CodeIdentifierDetails
     */
    public CodeIdentifierDetails getNationality() {
        return nationality;
    }

    /**
     * Mutator for property nationality.
     * 
     * @param nationality of type CodeIdentifierDetails
     */
    @XmlElement(name = "nationality")
    public void setNationality(CodeIdentifierDetails nationality) {
        this.nationality = nationality;
    }

    /**
     * Accessor for property correspondingViewOption.
     * 
     * @return correspondingViewOption of type CodeIdentifierDetails
     */
    public CodeIdentifierDetails getCorrespondingViewOption() {
        return correspondingViewOption;
    }

    /**
     * Mutator for property correspondingViewOption.
     * 
     * @param correspondingViewOption of type CodeIdentifierDetails
     */
    @XmlElement(name = "correspondingViewOption")
    public void setCorrespondingViewOption(CodeIdentifierDetails correspondingViewOption) {
        this.correspondingViewOption = correspondingViewOption;
    }

    /**
     * Accessor for property correspondingDeliveryPreference.
     * 
     * @return correspondingDeliveryPreference of type CodeIdentifierDetails
     */
    public CodeIdentifierDetails getCorrespondingDeliveryPreference() {
        return correspondingDeliveryPreference;
    }

    /**
     * Mutator for property correspondingDeliveryPreference.
     * 
     * @param correspondingDeliveryPreference of type CodeIdentifierDetails
     */
    @XmlElement(name = "correspondingDeliveryPreference")
    public void setCorrespondingDeliveryPreference(CodeIdentifierDetails correspondingDeliveryPreference) {
        this.correspondingDeliveryPreference = correspondingDeliveryPreference;
    }

    /**
     * Accessor for property bankAccount.
     * 
     * @return bankAccount of type BankAccountDetails
     */
    public List<BankAccountDetails> getBankAccount() {
        return bankAccount;
    }

    /**
     * Mutator for property bankAccount.
     * 
     * @return bankAccount of type BankAccountDetails
     */
    @XmlElement(name = "bankAccount")
    public void setBankAccount(List<BankAccountDetails> bankAccount) {
        this.bankAccount = bankAccount;
    }

    /**
     * Accessor for property name.
     * 
     * @return name of type String
     */
    public String getName() {
        return name;
    }

    /**
     * Mutator for property name.
     * 
     * @param name of type String
     */
    @XmlElement(name = "name")
    public void setName(String name) {
        this.name = name != null ? name : "";
    }

    /**
     * Accessor for property masterScheme.
     * 
     * @return masterScheme of type MasterSchemeIdentifierDetails
     */
    public MasterSchemeIdentifierDetails getMasterScheme() {
        return masterScheme;
    }

    /**
     * Mutator for property masterScheme.
     * 
     * @param masterScheme of type MasterSchemeIdentifierDetails
     */
    @XmlElement(name = "masterScheme")
    public void setMasterScheme(MasterSchemeIdentifierDetails masterScheme) {
        this.masterScheme = masterScheme;
    }

    /**
     * Accessor for property clientPointer.
     * 
     * @return clientPointer of type ExternalRef
     */
    public IDRefBean getClientPointer() {
        return clientPointer;
    }

    /**
     * Mutator for property clientPointer.
     * 
     * @param clientPointer of type ExternalRef
     */
    @XmlElement(name = "clientPointer")
    public void setClientPointer(IDRefBean clientPointer) {
        this.clientPointer = clientPointer;
    }

    /**
     * Accessor for property clientRef.
     * 
     * @return clientRef of type ExternalRef
     */
    public IDRefBean getClientRef() {
        return clientRef;
    }

    /**
     * Mutator for property clientRef.
     * 
     * @param clientRef of type ExternalRef
     */
    @XmlElement(name = "clientRef")
    public void setClientRef(IDRefBean clientRef) {
        this.clientRef = clientRef;
    }

    /**
     * Accessor for property clientSurname.
     * 
     * @return clientSurname of type String
     */
    public String getClientSurname() {
        return clientSurname;
    }

    /**
     * Mutator for property clientSurname.
     * 
     * @param clientSurname of type String
     */
    @XmlElement(name = "clientSurname")
    public void setClientSurname(String clientSurname) {
        this.clientSurname = clientSurname != null ? clientSurname : "";
    }

    /**
     * Accessor for property clientForename.
     * 
     * @return clientForename of type String
     */
    public String getClientForename() {
        return clientForename;
    }

    /**
     * Mutator for property clientForename.
     * 
     * @param clientForename of type String
     */
    @XmlElement(name = "clientForename")
    public void setClientForename(String clientForename) {
        this.clientForename = clientForename != null ? clientForename : "";
    }

    /**
     * Accessor for property clientForename2.
     * 
     * @return clientForename2 of type String
     */
    public String getClientForename2() {
        return clientForename2;
    }

    /**
     * Mutator for property clientForename2.
     * 
     * @param clientForename2 of type String
     */
    @XmlElement(name = "clientForename2")
    public void setClientForename2(String clientForename2) {
        this.clientForename2 = clientForename2 != null ? clientForename2 : "";
    }

    /**
     * Accessor for property clientTFN.
     * 
     * @return clientTFN of type String
     */
    public String getClientTFN() {
        return clientTFN;
    }

    /**
     * Mutator for property clientTFN.
     * 
     * @param clientTFN of type String
     */
    @XmlElement(name = "clientTFN")
    public void setClientTFN(String clientTFN) {
        this.clientTFN = clientTFN != null ? clientTFN : "";
    }

    /**
     * Accessor for property audit.
     * 
     * @return audit of type AuditDetails
     */
    public AuditDetails getAudit() {
        return audit;
    }

    /**
     * Mutator for property audit.
     * 
     * @param audit of type AuditDetails
     */
    @XmlElement(name = "audit")
    public void setAudit(AuditDetails audit) {
        this.audit = audit;
    }

    /**
     * Accessor for property globalIntermediaryIDNumber.
     * 
     * @return globalIntermediaryIDNumber of type String
     */
    public String getGlobalIntermediaryIDNumber() {
        return globalIntermediaryIDNumber;
    }

    /**
     * Mutator for property globalIntermediaryIDNumber.
     * 
     * @param globalIntermediaryIDNumber of type String
     */
    @XmlElement(name = "globalIntermediaryIDNumber")
    public void setGlobalIntermediaryIDNumber(String globalIntermediaryIDNumber) {
        this.globalIntermediaryIDNumber = globalIntermediaryIDNumber != null ? globalIntermediaryIDNumber : "";
    }

    /**
     * Accessor for property genericVariables.
     *
     * @return genericVariables of type List<GenericVariableDetails>
     */
    public List<GenericVariableDetails> getGenericVariables() {
        return genericVariables;
    }

    /**
     * Mutator for property genericVariables.
     *
     * @param genericVariables of type List<GenericVariableDetails>
     */
    @XmlElement(name = "genericVariables")
    public void setGenericVariables(List<GenericVariableDetails> genericVariables) {
        this.genericVariables = genericVariables;
    }

    /**
     * Accessor for property hasWorkDeclaration.
     *
     * @return hasWorkDeclaration of type String
     */
    public String getHasWorkDeclaration() {
        return hasWorkDeclaration;
    }

    /**
     * Mutator for property hasWorkDeclaration.
     *
     * @param hasWorkDeclaration of type String
     */
    @XmlElement(name = "hasWorkDeclaration")
    public void setHasWorkDeclaration(String hasWorkDeclaration) {
        this.hasWorkDeclaration = hasWorkDeclaration;
    }
    
}
