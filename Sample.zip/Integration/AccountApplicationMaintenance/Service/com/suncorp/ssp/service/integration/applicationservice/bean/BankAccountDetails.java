////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code BankAccountDetails} does this.
 * 
 * @author U386868
 * @since 09/02/2016
 * @version 1.0
 */
public class BankAccountDetails {

    private String id;
    private CodeIdentifierDetails typeCode;
    private String accountNumber;
    private String accountName;
    private ExpiryDateInfo expiryDate;
    private CodeNameIdentifier country;
    private CodeNameIdentifier currency;
    private String bankOtherPayRef;
    private String bankName;
    private String bankBranchName;
    private String bsbNumber;

    /**
     * Accessor for property typeCode.
     * 
     * @return typeCode of type CodeIdentifierDetails
     */
    public CodeIdentifierDetails getTypeCode() {
        return typeCode;
    }

    /**
     * Mutator for property typeCode.
     * 
     * @return typeCode of type CodeIdentifierDetails
     */
    @XmlElement(name = "typeCode")
    public void setTypeCode(CodeIdentifierDetails typeCode) {
        this.typeCode = typeCode;
    }

    /**
     * Accessor for property accountNumber.
     * 
     * @return accountNumber of type String
     */
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * Mutator for property accountNumber.
     * 
     * @return accountNumber of type String
     */
    @XmlElement(name = "accountNumber")
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber != null ? accountNumber : "";
    }

    /**
     * Accessor for property accountName.
     * 
     * @return accountName of type String
     */
    public String getAccountName() {
        return accountName;
    }

    /**
     * Mutator for property accountName.
     * 
     * @return accountName of type String
     */
    @XmlElement(name = "accountName")
    public void setAccountName(String accountName) {
        this.accountName = accountName != null ? accountName : "";
    }

    /**
     * Accessor for property country.
     * 
     * @return country of type CodeNameIdentifier
     */
    public CodeNameIdentifier getCountry() {
        return country;
    }

    /**
     * Mutator for property country.
     * 
     * @return country of type CodeNameIdentifier
     */
    @XmlElement(name = "country")
    public void setCountry(CodeNameIdentifier country) {
        this.country = country;
    }

    /**
     * Accessor for property currency.
     * 
     * @return currency of type CodeNameIdentifier
     */
    public CodeNameIdentifier getCurrency() {
        return currency;
    }

    /**
     * Mutator for property currency.
     * 
     * @return currency of type CodeNameIdentifier
     */
    @XmlElement(name = "currency")
    public void setCurrency(CodeNameIdentifier currency) {
        this.currency = currency;
    }

    /**
     * Accessor for property id.
     * 
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     * 
     * @return id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id != null ? id : "";
    }

    /**
     * Accessor for property expiryDate.
     * 
     * @return expiryDate of type ExpiryDateInfo
     */
    public ExpiryDateInfo getExpiryDate() {
        return expiryDate;
    }

    /**
     * Mutator for property expiryDate.
     * 
     * @return expiryDate of type ExpiryDateInfo
     */
    @XmlElement(name = "expiryDate")
    public void setExpiryDate(ExpiryDateInfo expiryDate) {
        this.expiryDate = expiryDate;
    }

    /**
     * Accessor for property bankOtherPayRef.
     * 
     * @return bankOtherPayRef of type String
     */
    public String getBankOtherPayRef() {
        return bankOtherPayRef;
    }

    /**
     * Mutator for property bankOtherPayRef.
     * 
     * @return bankOtherPayRef of type String
     */
    @XmlElement(name = "bankOtherPayRef")
    public void setBankOtherPayRef(String bankOtherPayRef) {
        this.bankOtherPayRef = bankOtherPayRef != null ? bankOtherPayRef : "";
    }

    /**
     * Accessor for property bankName.
     * 
     * @return bankName of type String
     */
    public String getBankName() {
        return bankName;
    }

    /**
     * Mutator for property bankName.
     * 
     * @return bankName of type String
     */
    @XmlElement(name = "bankName")
    public void setBankName(String bankName) {
        this.bankName = bankName != null ? bankName : "";
    }

    /**
     * Accessor for property bankBranchName.
     * 
     * @return bankBranchName of type String
     */
    public String getBankBranchName() {
        return bankBranchName;
    }

    /**
     * Mutator for property bankBranchName.
     * 
     * @return bankBranchName of type String
     */
    @XmlElement(name = "bankBranchName")
    public void setBankBranchName(String bankBranchName) {
        this.bankBranchName = bankBranchName != null ? bankBranchName : "";
    }

    /**
     * Accessor for property bsbNumber.
     * 
     * @return bsbNumber of type String
     */
    public String getBsbNumber() {
        return bsbNumber;
    }

    /**
     * Mutator for property bsbNumber.
     * 
     * @return bsbNumber of type String
     */
    @XmlElement(name = "bsbNumber")
    public void setBsbNumber(String bsbNumber) {
        this.bsbNumber = bsbNumber != null ? bsbNumber : "";
    }
}
