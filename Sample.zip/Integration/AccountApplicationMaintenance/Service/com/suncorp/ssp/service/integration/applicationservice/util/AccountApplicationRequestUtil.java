////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice.util;

import java.util.List;

import com.sonatacentral.service.v30.wrap.application.AccountApplicationRequestType;
import com.sonatacentral.service.v30.wrap.application.AccountApplicationRequestType.Account;
import com.sonatacentral.service.v30.wrap.application.AccountApplicationRequestType.Client;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.applicationservice.ApplicationServiceConstants;
import com.suncorp.ssp.service.integration.applicationservice.bean.AccountApplicationRequest;
import com.suncorp.ssp.service.integration.applicationservice.bean.AccountDetails;
import com.suncorp.ssp.service.integration.applicationservice.bean.ClientDetails;

/**
 * The class {@code AccountApplicationRequestUtil} is a Utility class with all the properties related to account and client details, to construct
 * request for creating account application external service's request object.
 * 
 * @author U383847
 * @since 06/01/2016
 * @version 1.0
 */
public class AccountApplicationRequestUtil {
    private final String className = "AccountApplicationRequestUtil";
    private AccountApplicationRequest accountApplicationRequest;

    /**
     * Parameterized constructor for properties initialization.
     * 
     * @param accountApplicationRequest of type AccountApplicationRequest
     */
    public AccountApplicationRequestUtil(AccountApplicationRequest accountApplicationRequest) {
        this.accountApplicationRequest = accountApplicationRequest;
    }

    /**
     * Extracts values from all client details from respective objects and set the values to external service's request object.
     * 
     * @param accountApplicationRequestType of type AccountApplicationRequestType
     * @throws SILException
     */
    public void createAccountApplicationRequest(AccountApplicationRequestType accountApplicationRequestType) throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Creating Account Application Request Details");

        List<Client> clientDetailTypeList = accountApplicationRequestType.getClient();
        this.setClientDetailsRequest(this.accountApplicationRequest, clientDetailTypeList);
        List<Account> accountRequestDetailsTypeList = accountApplicationRequestType.getAccount();
        this.setAccountDetailsRequest(this.accountApplicationRequest, accountRequestDetailsTypeList);
    }

    /**
     * Set all client details to external service's request object.
     * 
     * @param accountApplicationRequest
     * @param clientEntityType
     * @param clientDetailTypeList
     * @throws SILException
     */
    private void setClientDetailsRequest(AccountApplicationRequest accountApplicationRequest, List<Client> clientDetailTypeList)
            throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Client Request Details");
        List<ClientDetails> clientDetailsList = accountApplicationRequest.getClientDetails();
        if (clientDetailsList != null) {
            ClientDetailsRequestUtil clientDetailsRequestUtil = new ClientDetailsRequestUtil();
            clientDetailsRequestUtil.setClientDetails(clientDetailsList, clientDetailTypeList);
        }
    }

    /**
     * Set all account details to external service's request object.
     * 
     * @param accountApplicationRequest
     * @param accountEntityType
     * @param accountRequestDetailsTypeList
     * @throws SILException
     */
    private void setAccountDetailsRequest(AccountApplicationRequest accountApplicationRequest,
            List<Account> accountRequestDetailsTypeList) throws SILException {
        SILLogger.debug(ApplicationServiceConstants.CREATE_ACC_APP_LOGGING_FORMAT, className, "Setting Account Request Details");
        List<AccountDetails> accountDetailsList = accountApplicationRequest.getAccountDetails();
        if (accountDetailsList != null) {
            AccountDetailsRequestUtil accountDetailsRequestUtil = new AccountDetailsRequestUtil();
            accountDetailsRequestUtil.setAccountDetails(accountDetailsList, accountRequestDetailsTypeList);
        }
    }
}
