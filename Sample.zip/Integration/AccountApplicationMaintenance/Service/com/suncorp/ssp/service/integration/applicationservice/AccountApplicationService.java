////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.applicationservice;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.cxf.jaxrs.model.wadl.Description;
import org.apache.cxf.jaxrs.model.wadl.Descriptions;
import org.apache.cxf.jaxrs.model.wadl.DocTarget;
import org.apache.cxf.jaxrs.model.wadl.ElementClass;

import com.suncorp.ssp.service.integration.applicationservice.bean.AccountApplicationRequest;

/**
 * The interface {@code AccountApplicationService} does this.
 * 
 * @author U383847
 * @since 19/01/2016
 * @version 1.0
 */
@Path("/applicationservice")
public interface AccountApplicationService {

    /**
     * Fetches new AccountApplicationResponse bean.
     * 
     * @param accountApplicationRequest
     * @return object of type AccountApplicationResponse
     */
    @POST
    @Path("/createaccountapplication")
    @ElementClass(request = AccountApplicationRequest.class, response = Response.class)
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Descriptions({
            @Description(title = "Request Object", value = "AccountApplicationRequest", target = DocTarget.REQUEST),
            @Description(title = "Response Object", value = "Response", target = DocTarget.RESPONSE)
    })
    Response createaccountapplication(AccountApplicationRequest accountApplicationRequest);
}
