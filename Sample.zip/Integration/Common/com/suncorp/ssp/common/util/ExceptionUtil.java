////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package com.suncorp.ssp.common.util;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;

/**
 * The class {@code ClientServiceUtil} is a Utility class for common operations.
 * 
 * @author U383754
 * @since 2015-10-01
 * @version 1.0
 */
public class ExceptionUtil {

    /**
     * Default constructor.
     */
    protected ExceptionUtil() {
    }

    /**
     * This method is used to get fault string from soap fault which is coming from Sonata.
     * 
     * @param doc
     * @throws Exception
     */
    public static void getFault(Document doc) throws SILException {
        NodeList nodeList = doc.getDocumentElement().getChildNodes().item(0).getChildNodes().item(0).getChildNodes();
        int len = 0;
        while (len < nodeList.getLength()) {
            if (nodeList.item(len).getNodeName().equals("faultstring")) {
                SILLogger.debug(CommonConstants.LOGGING_FORMAT, "ExceptionUtil", "Error Occur while parsing fault.");
                throw new SILException(nodeList.item(len).getTextContent());
            }
            len++;
        }
    }

    /**
     * This method is used to validate node values whether they are in soap fault message or not, if there throwing exception else not.
     * 
     * @param doc of type Document
     * @throws Exception
     */
    public static void validateNodeValues(Document doc) throws SILException {
        if (isEnvelopeNull(doc) || isBodyNull(doc) || isFaultNull(doc)) {
            logging("ExceptionUtil", "Exception from SONATA : Failed in Parsing Response from Sonata" + "Exiting from process method");
            throw new SILException(CommonConstants.INVALID_SONATA_RESPONSE);
        }
    }

    /**
     * This method will check whether the Envelope tag is present in message body or not.
     * 
     * @param doc of type Document
     * @return type boolean
     * @throws Exception
     */
    private static boolean isEnvelopeNull(Document doc) {
        if (doc.getDocumentElement() == null || doc.getDocumentElement().getNodeName() == null ||
                doc.getDocumentElement().getNodeName().indexOf("Envelope") == -1) {
            return true;
        }
        return false;
    }

    /**
     * This method will check whether the Body tag is present in message body or not.
     * 
     * @param doc of type Document
     * @return type boolean
     * @throws Exception
     */
    private static boolean isBodyNull(Document doc) {
        if (doc.getDocumentElement().getChildNodes() == null || doc.getDocumentElement().getChildNodes().item(0) == null ||
                doc.getDocumentElement().getChildNodes().item(0).getNodeName().indexOf("Body") == -1) {
            return true;
        }
        return false;
    }

    /**
     * This method will check whether the Fault tag is present in message body or not.
     * 
     * @param doc of type Document
     * @return type boolean
     * @throws Exception
     */
    private static boolean isFaultNull(Document doc) {
        if (doc.getDocumentElement().getChildNodes().item(0).getChildNodes().item(0).getNodeName() == null ||
                doc.getDocumentElement().getChildNodes().item(0).getChildNodes().item(0).getNodeName().indexOf("Fault") == -1) {
            return true;
        }
        return false;
    }

    /**
     * This is the for logging error and debug message.
     * 
     * @param className
     * @param errorLoggerMessage
     */
    private static void logging(String className, String errorLoggerMessage) {
        SILLogger.error(CommonConstants.LOGGING_FORMAT, className, errorLoggerMessage);
    }
}
