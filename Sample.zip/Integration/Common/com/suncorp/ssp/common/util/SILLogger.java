////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.common.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * The class {@code SILLogger} id used to log error, debug and info messages.
 * 
 * @author U383754
 * @since 11/02/2016
 * @version 1.0
 */
public final class SILLogger {

    private static final Logger LOG = LoggerFactory.getLogger(SILLogger.class);

    /**
     * 
     * This is the default constructor of util class.
     */
    private SILLogger() {

    }

    /**
     * This method is used to log the error message.
     * 
     * @param format the format of logger
     * @param consumer the consumer from error occurred
     * @param logMessage the actual log message
     */
    public static void error(String format, String consumer, String logMessage) {
        LOG.error(format, consumer, logMessage);
    }

    /**
     * This method is used to log the debug message.
     * 
     * @param format the format of logger
     * @param consumer the consumer
     * @param logMessage the actual log message
     */
    public static void debug(String format, String consumer, String logMessage) {
        LOG.debug(format, consumer, logMessage);
    }

    /**
     * This method is used to log the info message.
     * 
     * @param format the format of logger
     * @param consumer the consumer
     * @param logMessage the actual log message
     */
    public static void info(String format, String consumer, String logMessage) {
        LOG.info(format, consumer, logMessage);
    }
}
