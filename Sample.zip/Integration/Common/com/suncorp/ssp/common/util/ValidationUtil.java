////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package com.suncorp.ssp.common.util;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;

/**
 * The class is a Utility class for common operations.
 * 
 * @author U383754
 * @since 2015-10-01
 * @version 1.0
 */
public class ValidationUtil {

    /**
     * Default constructor.
     */
    protected ValidationUtil() {
    }

    /**
     * This method is used to get fault string from soap fault which is coming from Sonata.
     * 
     * @param doc
     * @throws Exception
     */
    public static void getMessage(Document doc) throws SILException {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, "ValidationUtil", "Entering getMessage method");
        NodeList nodeList = doc.getDocumentElement().getChildNodes().item(1).getChildNodes().item(0).getChildNodes().item(1).getChildNodes();
        int len = 0;
        while (len < nodeList.getLength()) {
            if (nodeList.item(len).getNodeName().equals("s:message")) {
                SILLogger.debug(CommonConstants.LOGGING_FORMAT, "ValidationUtil", "Error Occur while parsing Validation message.");
                throw new SILException(nodeList.item(len).getTextContent());
            }
            len++;
        }
    }

    /**
     * This method is used to validate node values whether they are in soap fault message or not, if there throwing exception else not.
     * 
     * @param doc of type Document
     * @throws Exception
     */
    public static void validateNodeValues(Document doc) throws SILException {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, "ValidationUtil", "Entering validateNodeValues method");
        if (isEnvelopeNull(doc) || isBodyNull(doc) || isFaultNull(doc)) {
            logging("ValidationUtil", "Exception from SONATA : Failed in Parsing Response from Sonata" + "Exiting from process method");
            throw new SILException(CommonConstants.INVALID_SONATA_RESPONSE);
        }
    }

    /**
     * This method will check whether the Envelope tag is present in message body or not.
     * 
     * @param doc of type Document
     * @return type boolean
     * @throws Exception
     */
    private static boolean isEnvelopeNull(Document doc) {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, "ValidationUtil", "Entering isEnvelopeNull method");
        if (doc.getDocumentElement() == null || doc.getDocumentElement().getNodeName() == null ||
                doc.getDocumentElement().getNodeName().indexOf("Envelope") == -1) {

            return true;
        }
        return false;
    }

    /**
     * This method will check whether the Body tag is present in message body or not.
     * 
     * @param doc of type Document
     * @return type boolean
     * @throws Exception
     */
    private static boolean isBodyNull(Document doc) {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, "ValidationUtil", "Entering isBodyNull method");
        if (doc.getDocumentElement().getChildNodes() == null || doc.getDocumentElement().getChildNodes().item(1) == null ||
                doc.getDocumentElement().getChildNodes().item(1).getNodeName().indexOf("Body") == -1) {
            return true;
        }
        return false;
    }

    /**
     * This method will check whether the Fault tag is present in message body or not.
     * 
     * @param doc of type Document
     * @return type boolean
     * @throws Exception
     */
    private static boolean isFaultNull(Document doc) {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, "ValidationUtil", "Entering isFaultNull method");
        if (doc.getDocumentElement().getChildNodes().item(1).getChildNodes().item(0).getChildNodes().item(1).getNodeName() == null ||
                doc.getDocumentElement().getChildNodes().item(1).getChildNodes().item(0).getChildNodes().item(1).getNodeName()
                        .indexOf("validationMessage") == -1) {
            return true;
        }
        return false;
    }

    /**
     * This is the for logging error and debug message.
     * 
     * @param className
     * @param errorLoggerMessage
     */
    private static void logging(String className, String errorLoggerMessage) {
        SILLogger.error(CommonConstants.LOGGING_FORMAT, className, errorLoggerMessage);
    }
}
