////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.common.util;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringReader;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;

import javax.xml.XMLConstants;
import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.sonatacentral.service.v30.callerdetails.CallerDetails;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.service.constants.communicationservice.CommunicationServiceConstants;
import com.suncorp.ssp.service.constants.rolloverservice.RolloverConstants;

/**
 * The class {@code SILUtil} used as a util class for entire project.
 * 
 * @author U383754
 * @since 17/11/2015
 * @version 1.0
 */
public final class SILUtil {
    private static String cName = "SILUtil";

    /**
     * This is the default constructor of util class.
     */
    private SILUtil() {

    }

    /**
     * 
     * Creates a new instance of {@code CallerDetails}, and sets its properties accordingly.
     * 
     * @param callerDetails of type CallerDetails
     */
    public static CallerDetails createCallerDetails() {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, cName, "Entering createCallerDetails method");
        CallerDetails callerDetails = new CallerDetails();
        callerDetails.setUsername(CommonConstants.USERNAME);
        callerDetails.setCountry(CommonConstants.COUNTRY);
        callerDetails.setLanguage(CommonConstants.LANGUAGE);
        callerDetails.setDatabaseIdentifier(CommonConstants.DATABASE_IDENTIFIER);
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, cName, "Exiting createCallerDetails method");
        return callerDetails;
    }

    /**
     * Converts input String to XMLGregorianCalendar object.
     * 
     * @param inputDate of type String
     * @param datetimeFormat of type String
     * @return xmlCalendar of XMLGregorianCalendar
     * @throws Exception
     */
    public static XMLGregorianCalendar convertStringToXMLGregorianCalendar(String inputDate, String datetimeFormat) throws SILException {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, cName, "Entering convertStringToXMLGregorianCalendar method");
        SimpleDateFormat sdf = new SimpleDateFormat(datetimeFormat);
        try {
            Date date = sdf.parse(inputDate);
            return DatatypeFactory.newInstance().newXMLGregorianCalendar(new SimpleDateFormat(CommonConstants.DATE_TIME_FORMAT).format(date));
        } catch (IllegalArgumentException iArgEx) {
            SILLogger.error(CommonConstants.LOGGING_FORMAT, cName, getReqExMsg(iArgEx));
            throw new SILException(CommonConstants.INVALID_DATE_FORMAT);
        } catch (DatatypeConfigurationException dcException) {
            SILLogger.error(CommonConstants.LOGGING_FORMAT, cName, getReqExMsg(dcException));
            throw new SILException(CommonConstants.INVALID_DATE_FORMAT);
        } catch (ParseException parseEx) {
            SILLogger.error(CommonConstants.LOGGING_FORMAT, cName, getReqExMsg(parseEx));
            throw new SILException(CommonConstants.INVALID_DATE_FORMAT);
        }
    }

    /**
     * Converts input XMLGregorianCalendar object to String.
     * 
     * @param outputDate
     * @param datetimeFormat
     * @return dateString of type String
     */
    public static String convertXMLGregorianCalendartoString(XMLGregorianCalendar outputDate, String datetimeFormat) {
        if (outputDate != null) {
            SILLogger.debug(CommonConstants.LOGGING_FORMAT, cName, "Entering convertXMLGregorianCalendartoString method");
            SimpleDateFormat sdf = new SimpleDateFormat(datetimeFormat);
            Calendar calendar = outputDate.toGregorianCalendar();
            sdf.setTimeZone(calendar.getTimeZone());
            String dateString = sdf.format(calendar.getTime());
            return dateString;
        } else {
            return "";
        }
    }

    /**
     * Converts input Date object to XMLGregorianCalendar.
     * 
     * @param inputDate
     * @param datetimeFormat
     * @return
     * @throws SILException
     */
    public static XMLGregorianCalendar convertDateToXMLGregorianCalendar(Date inputDate, String datetimeFormat) throws SILException {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, cName, "Entering convertDateToXMLGregorianCalendar method");
        try {
            return DatatypeFactory.newInstance().newXMLGregorianCalendar(new SimpleDateFormat(datetimeFormat).format(inputDate));
        } catch (IllegalArgumentException iArgEx) {
            SILLogger.error(CommonConstants.LOGGING_FORMAT, cName, getReqExMsg(iArgEx));
            throw new SILException(CommonConstants.INVALID_DATE_FORMAT);
        } catch (DatatypeConfigurationException dcException) {
            SILLogger.error(CommonConstants.LOGGING_FORMAT, cName, getReqExMsg(dcException));
            throw new SILException(CommonConstants.INVALID_DATE_FORMAT);
        }
    }

    /**
     * Validate Client Id.
     * 
     * @param clientId
     * @return validClientId of type Long
     * @throws SILException
     */
    public static Long validateClientId(String clientId) throws SILException {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, cName, "Entering validateClientId method");
        Long validClientId = null;
        try {
            validClientId = Long.parseLong(clientId);
        } catch (NumberFormatException exception) {
            throw new SILException(CommonConstants.INVALID_CLIENT_ID_MESSAGE);
        }
        return validClientId;
    }

    /**
     * Check for Delete Operation.
     * 
     * @param operation of type String
     * @return boolean type
     */
    public static boolean checkDeleteOperation(String operation) {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, cName, "Checking for Delete Operation");
        if (CommonConstants.DELETE_OPERATION_TYPE.equals(operation)) {
            return true;
        }
        return false;
    }

    /**
     * Calculate Next Rebalance Date.
     * 
     * @param rebalanceDate
     * @param rebalanceFrequency
     * @return
     * @throws SILException
     */
    public static XMLGregorianCalendar calculateNextRebalanceDate(String rebalanceFrequency) throws SILException {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, cName, "Calculating Next Rebalance Date");
        Date date = Calendar.getInstance().getTime();
        XMLGregorianCalendar rebalancingDate = convertDateToXMLGregorianCalendar(date, CommonConstants.DATE_FORMAT);
        int year = rebalancingDate.getYear();
        String yearlyRebalanceDate = new Integer(year) + "-" + CommonConstants.REBALANCE_YEARLY_MONTH_DAY;
        XMLGregorianCalendar yearlyCheckRebalanceDate = convertStringToXMLGregorianCalendar(yearlyRebalanceDate, CommonConstants.DATE_FORMAT);
        String halfYearlyRebalanceDate = new Integer(year) + "-" + CommonConstants.REBALANCE_HALF_YEARLY_MONTH_DAY;
        XMLGregorianCalendar halfYearlyCheckRebalanceDate = convertStringToXMLGregorianCalendar(halfYearlyRebalanceDate, CommonConstants.DATE_FORMAT);
        if (CommonConstants.REBALANCE_YEARLY.equalsIgnoreCase(rebalanceFrequency)) {
            // Calculating Rebalancing for Yearly (E.g. 22/12)
            return calculateNextRebalanceDateOnYearly(yearlyCheckRebalanceDate, rebalancingDate);
        } else if (CommonConstants.REBALANCE_HALF_YEARLY.equalsIgnoreCase(rebalanceFrequency)) {
            // Calculating Rebalancing for Yearly (E.g. 22/06 & 22/12)
            return calculateNextRebalanceDateOnHalfYearly(year, halfYearlyCheckRebalanceDate, rebalancingDate, yearlyCheckRebalanceDate);
        } else if (CommonConstants.REBALANCE_QUARTERLY.equalsIgnoreCase(rebalanceFrequency)) {
            // Calculating Rebalancing for Yearly (E.g. 22/03, 22/06, 22/09 & 22/12)
            return calculateNextRebalanceDateOnQuarterly(year, halfYearlyCheckRebalanceDate, rebalancingDate, yearlyCheckRebalanceDate);
        }
        return rebalancingDate;
    }

    /**
     * Calculate Next Rebalance Date On Yearly.
     * 
     * @param yearlyCheckRebalanceDate
     * @param rebalancingDate
     * @return
     * @throws SILException
     */
    private static XMLGregorianCalendar calculateNextRebalanceDateOnYearly(XMLGregorianCalendar yearlyCheckRebalanceDate,
            XMLGregorianCalendar rebalancingDate) throws SILException {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, cName, "Calculating Next Rebalance Date On Yearly");
        XMLGregorianCalendar nextRebalanceDate = null;
        int result = yearlyCheckRebalanceDate.compare(rebalancingDate);
        if (result > 0) {
            nextRebalanceDate = yearlyCheckRebalanceDate;
        } else {
            String dateString = incrementYear(yearlyCheckRebalanceDate);
            nextRebalanceDate = convertStringToXMLGregorianCalendar(dateString, CommonConstants.DATE_FORMAT);
        }
        return nextRebalanceDate;
    }

    /**
     * Calculate Next Rebalance Date On Half Yearly.
     * 
     * @param year
     * @param halfYearlyCheckRebalanceDate
     * @param rebalancingDate
     * @param yearlyCheckRebalanceDate
     * @return
     * @throws SILException
     */
    private static XMLGregorianCalendar calculateNextRebalanceDateOnHalfYearly(int year, XMLGregorianCalendar halfYearlyCheckRebalanceDate,
            XMLGregorianCalendar rebalancingDate, XMLGregorianCalendar yearlyCheckRebalanceDate) throws SILException {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, cName, "Calculating Next Rebalance Date On Half Yearly");
        int day = rebalancingDate.getDay();
        int month = rebalancingDate.getMonth();
        XMLGregorianCalendar nextRebalanceDate = findRebalanceDateInYearLastWeek(month, day, year, CommonConstants.REBALANCE_HALF_YEARLY_MONTH_DAY);
        if (nextRebalanceDate == null) {
            int result = halfYearlyCheckRebalanceDate.compare(rebalancingDate);
            if (result > 0) {
                nextRebalanceDate = halfYearlyCheckRebalanceDate;
            } else {
                nextRebalanceDate = yearlyCheckRebalanceDate;
            }
        }
        return nextRebalanceDate;
    }

    /**
     * Calculate Next Rebalance Date on Quarterly.
     * 
     * @param year
     * @param halfYearlyCheckRebalanceDate
     * @param rebalancingDate
     * @param yearlyCheckRebalanceDate
     * @return
     * @throws SILException
     */
    private static XMLGregorianCalendar calculateNextRebalanceDateOnQuarterly(int year, XMLGregorianCalendar halfYearlyCheckRebalanceDate,
            XMLGregorianCalendar rebalancingDate, XMLGregorianCalendar yearlyCheckRebalanceDate) throws SILException {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, cName, "Calculating Next Rebalance Date on Quarterly");
        int day = rebalancingDate.getDay();
        int month = rebalancingDate.getMonth();
        XMLGregorianCalendar nextRebalanceDate =
                findRebalanceDateInFirstHalfYear(month, day, year, halfYearlyCheckRebalanceDate, rebalancingDate, yearlyCheckRebalanceDate);

        return nextRebalanceDate;
    }

    /**
     * Increment Year.
     * 
     * @param yearlyCheckRebalanceDate
     * @return
     */
    private static String incrementYear(XMLGregorianCalendar yearlyCheckRebalanceDate) {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, cName, "Incrementing Year");
        Calendar cal = yearlyCheckRebalanceDate.toGregorianCalendar();
        SimpleDateFormat sdf = new SimpleDateFormat(CommonConstants.DATE_FORMAT);
        cal.add(Calendar.YEAR, 1);
        sdf.setTimeZone(cal.getTimeZone());
        return sdf.format(cal.getTime());
    }

    /**
     * Find Rebalance Date In First Half Year.
     * 
     * @param month
     * @param day
     * @param year
     * @param halfYearlyCheckRebalanceDate
     * @param rebalancingDate
     * @param yearlyCheckRebalanceDate
     * @return
     * @throws SILException
     */
    private static XMLGregorianCalendar findRebalanceDateInFirstHalfYear(int month, int day, int year,
            XMLGregorianCalendar halfYearlyCheckRebalanceDate, XMLGregorianCalendar rebalancingDate, XMLGregorianCalendar yearlyCheckRebalanceDate)
            throws SILException {
        XMLGregorianCalendar nextRebalanceDate = null;
        if (month < 6 && day <= 31 || month == 6 && day < 22) {
            SILLogger.debug(CommonConstants.LOGGING_FORMAT, cName, "Finding Rebalance Date In First Half Year");
            String quarterlyRebalanceDate = new Integer(year) + "-" + CommonConstants.REBALANCE_QUARTERLY_MONTH_DAY;
            XMLGregorianCalendar quarterlyCheckRebalanceDate =
                    convertStringToXMLGregorianCalendar(quarterlyRebalanceDate, CommonConstants.DATE_FORMAT);
            int result = quarterlyCheckRebalanceDate.compare(rebalancingDate);
            if (result > 0) {
                nextRebalanceDate = quarterlyCheckRebalanceDate; // Logic for month before 22/03
            } else {
                nextRebalanceDate = halfYearlyCheckRebalanceDate; // Logic for month after 22/03 and before 22/06
            }
        } else {
            nextRebalanceDate = findRebalanceDateInSecondHalfYear(month, day, year, rebalancingDate, yearlyCheckRebalanceDate);
        }
        return nextRebalanceDate;
    }

    /**
     * Find Rebalance Date In Second Half Year.
     * 
     * @param month
     * @param day
     * @param year
     * @param rebalancingDate
     * @param yearlyCheckRebalanceDate
     * @return
     * @throws SILException
     */
    private static XMLGregorianCalendar findRebalanceDateInSecondHalfYear(int month, int day, int year, XMLGregorianCalendar rebalancingDate,
            XMLGregorianCalendar yearlyCheckRebalanceDate) throws SILException {
        XMLGregorianCalendar nextRebalanceDate = null;
        if (month < 12 && day <= 31 || month == 12 && day < 22) {
            SILLogger.debug(CommonConstants.LOGGING_FORMAT, cName, "Finding Rebalance Date In Second Half Year");
            String quarterRebalanceDate = new Integer(year) + "-" + CommonConstants.REBALANCE_QUARTERLY2_MONTH_DAY;
            XMLGregorianCalendar quarterCheckRebalanceDate = convertStringToXMLGregorianCalendar(quarterRebalanceDate, CommonConstants.DATE_FORMAT);
            int result1 = quarterCheckRebalanceDate.compare(rebalancingDate);
            if (result1 > 0) {
                nextRebalanceDate = quarterCheckRebalanceDate; // Logic for month after 22/06 and before 22/09
            } else {
                nextRebalanceDate = yearlyCheckRebalanceDate; // Logic for month after 22/09 and before 22/12
            }
        } else {
            nextRebalanceDate = findRebalanceDateInYearLastWeek(month, day, year, CommonConstants.REBALANCE_QUARTERLY_MONTH_DAY);
        }
        return nextRebalanceDate;
    }

    /**
     * Find Rebalance Date In Year Last Week.
     * 
     * @param month
     * @param day
     * @param year
     * @param rebalanceFrequencyMonthDay
     * @return
     * @throws SILException
     */
    private static XMLGregorianCalendar findRebalanceDateInYearLastWeek(int month, int day, int year, String rebalanceFrequencyMonthDay)
            throws SILException {
        XMLGregorianCalendar nextRebalanceDate = null;
        if (month == 12 && day >= 22 && day <= 31) {
            SILLogger.debug(CommonConstants.LOGGING_FORMAT, cName, "Finding Rebalance Date In Year Last Week");
            int incrementYear = year + 1;
            String nextQuarterRebalanceDate = new Integer(incrementYear) + "-" + rebalanceFrequencyMonthDay;
            XMLGregorianCalendar nextQuarterCheckRebalanceDate =
                    convertStringToXMLGregorianCalendar(nextQuarterRebalanceDate, CommonConstants.DATE_FORMAT);
            nextRebalanceDate = nextQuarterCheckRebalanceDate;
        }
        return nextRebalanceDate;
    }

    /**
     * Returns an string message for exception logging in Exception blocks in Processors.
     * 
     * @param exception of type Exception
     * @return String
     */
    public static String getReqExMsg(Exception exception) {
        return "Exception while creating request : " + exception.getMessage();
    }

    /**
     * Returns an string message for error logging in Exception blocks in Processors.
     * 
     * @param error of type Exception
     * @return String
     */
    public static String getReqErrorMsg(Error error) {
        return "Error while creating request : " + error.getMessage();
    }

    /**
     * Returns an string message for exception logging in Exception blocks in Transformers.
     * 
     * @param exception of type Exception
     * @return String
     */
    public static String getRespExMsg(Exception exception) {
        return "Exception while creating response : " + exception.getMessage();
    }

    /**
     * Returns an string message for exception logging in SILException blocks in Processors.
     * 
     * @param silException of type SILException
     * @return String
     */
    public static String getReqExMsg(SILException silException) {
        return "Exception while creating request : " + silException.getMessage();
    }

    /**
     * Returns an string message for exception logging in SILException blocks in Transformers.
     * 
     * @param silException of type SILException
     * @return String
     */
    public static String getRespExMsg(SILException silException) {
        return "Exception while creating response : " + silException.getMessage();
    }

    /**
     * Returns an string message for exception logging in IOException blocks.
     * 
     * @param ioException of type IOException
     * @return String
     */
    public static String getReqIOExMsg(IOException ioException) {
        return "Exception while reading the file : " + ioException.getMessage();
    }

    /**
     * Checks whether a given collection is null and size > 0.
     * 
     * @param collection of type Collection
     * @return
     */
    public static Boolean isEmpty(Collection<?> collection) {
        if (collection != null && collection.size() > 0) {
            return false;
        }
        return true;
    }

    /**
     * Returns doc after parsing the inbound xml file.
     * 
     * @param inboundFile of type String
     * @return doc of type Document
     * @throws SILException
     */
    public static Document convertXMLFiletoDocument(String inboundFile) throws SILException {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, cName, "convertXMLFiletoDocument");
        SAXReader reader = new SAXReader();
        Document doc = null;
        try {
            if (inboundFile.contains("<header>") && inboundFile.contains("</header>")) {
                String file = inboundFile.substring(inboundFile.indexOf("<header>"), inboundFile.indexOf("</header>")) + "</header>";
                doc = reader.read(new StringReader(file));
                return doc;
            } else {
                throw new SILException(CommunicationServiceConstants.MISSING_HEADER_TAG_EXCEPTION);
            }
        } catch (DocumentException documentException) {
            SILLogger.error(CommonConstants.LOGGING_FORMAT, cName, SILUtil.getReqExMsg(documentException));
            throw new SILException(CommonConstants.INVALID_DOC_FORMAT);
        }
    }

    /**
     * 
     * This method is used to convert org.dom4j.Document to org.w3c.dom.Document.
     * 
     * @param doc
     * @return the object of type {@code org.w3c.dom.Document}
     * @throws SILException
     */
    public static org.w3c.dom.Document convertDom4jToDomDoc(Document doc) throws SILException {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, cName, "Entering convertDom4jToDomDoc()");
        try {
            String xmlSource = doc.asXML();
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setValidating(true);
            factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
            factory.setFeature(CommonConstants.XML_DISALLOW_DOCTYPE_DECL_NS, true);
            factory.setFeature(CommonConstants.XML_EXT_GENERAL_ENTITIES_NS, false);
            factory.setFeature(CommonConstants.XML_EXT_PARAMETER_ENTITIES_NS, false);
            DocumentBuilder builder = factory.newDocumentBuilder();
            builder.setErrorHandler(null);
            return builder.parse(new InputSource(new StringReader(xmlSource)));
        } catch (ParserConfigurationException | SAXException | IOException exc) {
            SILLogger.error(CommonConstants.LOGGING_FORMAT, cName, SILUtil.getReqExMsg(exc));
            throw new SILException(CommonConstants.INVALID_DOC_FORMAT);
        }
    }

    /**
     * Retrieve Customer Age From DOB.
     * 
     * @param customerDOB
     * @return the customer age
     * @throws Exception
     */
    public static int retrieveCustomerAgeFromDOB(String customerDOB) throws SILException {
        XMLGregorianCalendar dob = convertStringToXMLGregorianCalendar(customerDOB, CommonConstants.DATE_FORMAT);
        return Calendar.getInstance().get(Calendar.YEAR) - dob.getYear();
    }

    /**
     * This method will convert SOAPMessage to String object.
     * 
     * @param soapMessage
     * @return
     * @throws IOException
     * @throws SOAPException
     */
    public static String convertSoapMessageToString(SOAPMessage soapMessage) throws SOAPException, IOException, SILException {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, cName, "Entering in convertSoapMessageToString method.");
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        soapMessage.writeTo(out);
        InputStream iStream = new ByteArrayInputStream(out.toByteArray());
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, cName, "Exiting from convertSoapMessageToString method.");
        return getXmlFromInputStream(iStream);
    }

    /**
     * Get XML from InputStream.
     * 
     * @param iStream
     * @param header
     * @throws SILException
     */
    private static String getXmlFromInputStream(InputStream iStream) throws SILException {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, cName, "Entering in getXmlFromInputStream method.");
        BufferedReader bufferedReader = null;
        StringBuffer stringBuffer = new StringBuffer();
        int currentChar;
        try {
            bufferedReader = new BufferedReader(new InputStreamReader(iStream));
            while ((currentChar = bufferedReader.read()) != -1) {
                stringBuffer.append((char) currentChar);
            }
        } catch (IOException e) {
            throw new SILException(e.getMessage());
        } finally {
            close(bufferedReader);
        }
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, cName, "Entering in getXmlFromInputStream method.");
        return stringBuffer.toString();
    }

    /**
     * close bufferedReader.
     * 
     * @param bufferedReader
     * @throws SILException
     */
    private static void close(BufferedReader bufferedReader) {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, cName, "Entering in close method.");
        if (bufferedReader != null) {
            try {
                bufferedReader.close();
            } catch (IOException e) {
                SILLogger.error(CommonConstants.LOGGING_FORMAT, cName, SILUtil.getRespExMsg(e));
            }
        }
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, cName, "Entering in close method.");
    }

    /**
     * XML Element Null Empty Check.
     * 
     * @param xmlElement
     * @param xmlTag
     * @return
     * @throws SILException
     */
    public static String xmlElementNullEmptyCheck(Element xmlElement, String xmlTag) throws SILException {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, cName, "Entering in xmlElementNullEmptyCheck.");
        if (xmlElement.elementText(xmlTag) != null && !xmlElement.elementText(xmlTag).isEmpty()) {
            return xmlElement.elementText(xmlTag);
        } else {
            throw new SILException(CommonConstants.BLANK_XML_TAG_EXCEPTION1 + xmlTag + CommonConstants.BLANK_XML_TAG_EXCEPTION2);
        }
    }

    /**
     * This method is used to convert SQL Date To String.
     * 
     * @param inputDateFormat
     * 
     * @param date
     * @param dateFormat
     * @return
     */
    public static String convertDateToString(java.sql.Date inputdate, String inputDateFormat) {
        DateFormat dateFormat = new SimpleDateFormat(inputDateFormat);
        String dateString = dateFormat.format(inputdate);
        return dateString;
    }

    /**
     * Checks if the given string is null or not. Also checks if it's not equals to the literal null as well. <b>Note: Useful in case when the string
     * is retrieved using the String.valueOf().</b>
     * 
     * @param arg
     * @return
     */
    public static boolean isNotANullString(String arg) {
        return arg != null && !"null".equalsIgnoreCase(arg);
    }

    /**
     * Checks if the given string is null or not. Also checks if it's not equals to the literal null or blank(empty) as well. <b>Note: Useful in case
     * when the string is retrieved using the String.valueOf().</b>
     * 
     * @param arg
     * @return
     */
    public static boolean isNotANullOrEmptyString(String arg) {
        return arg != null && !"null".equalsIgnoreCase(arg) && !CommonConstants.EMPTY_STRING_VALUE.equalsIgnoreCase(arg);
    }

    /**
     * Increments or decrements the given date as string by the count specified. <b>Note: For decrementing, pass the negative equivalent as the
     * count.</b>
     * 
     * @param givenDate
     * @param count
     * @return
     * @throws SILException
     */
    public static String incrementDate(String givenDate, int count) throws SILException {
        SILLogger.debug(RolloverConstants.CREATE_MRR_LOGGING_FORMAT, cName, "Entering endExistingSalaryRecord()");
        String previousDate = null;
        SimpleDateFormat sdf = new SimpleDateFormat(CommonConstants.DATE_FORMAT);
        Calendar cal = Calendar.getInstance();
        try {
            cal.setTime(sdf.parse(givenDate));
        } catch (ParseException parseEx) {
            SILLogger.error(CommonConstants.LOGGING_FORMAT, cName, getReqExMsg(parseEx));
            throw new SILException(CommonConstants.INVALID_DATE_FORMAT);
        }
        cal.add(Calendar.DATE, count);
        previousDate = sdf.format(cal.getTime());
        SILLogger.debug(RolloverConstants.CREATE_MRR_LOGGING_FORMAT, cName, "Exiting endExistingSalaryRecord()");
        return previousDate;
    }
    
    /**
     * Returns the system's current date in the format specified by the argument passed.
     * 
     * @param dateFormat
     * @return
     */
    public static String getCurrentDateAsString(String dateFormat) {
        return new SimpleDateFormat(dateFormat).format(new Date());
    }
}
