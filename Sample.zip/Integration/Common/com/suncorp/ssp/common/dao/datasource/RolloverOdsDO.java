////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.common.dao.datasource;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code RolloverOdsDO} does this.
 * 
 * @author U385424
 * @since 15/09/2017
 * @version 1.0
 */
public class RolloverOdsDO {

    // Get Pending Insurance Account List
    private String accountNo;

    // Get Scheme Category Rank
    private String schemeCategoryRank;
    private String schemeCategoryGroup;
    private String schemeCategorySwitchFlag;
    private String schemeCategoryCode;
    private String schemeCategoryId;
    private String schemeCategoryShortName;

    // Get Special Employer Details
    private String mrrOccupationCode;
    private String mrrSchemeCategory;
    private String createSchemeCategoryCode;
    private String createOccupationCode;
    private String defaultInsuranceFlag;
    private String lifeBenefitLongName;
    private String lifeRider;
    private String lifeRiderFactor;
    private String tpdRider;
    private String tpdRiderFactor;
    private String ipRider;
    private String ipRiderFactor;
    private String waitingPeriod;
    private String benefitPeriod;
    private String loadingFull;
    private String lifeLoading;
    private String lifeFull;
    private String tpdBenefitLongName;
    private String tpdLoading;
    private String tpdFull;
    private String ipBenefitLongName;
    private String ipLoading;
    private String ipFull;
    private String ipWaitingPeriod;
    private String ipBenefitPeriod;
    private String lifeRiderUnits;
    private String tpdRiderUnits;
    private String lifeRiderReviewId;
    private String ipRiderReviewId;
    private String tpdRiderReviewId;

    // Get Employer Details from ODS DB
    private String employerAbn;

    /**
     * Accessor for property accountNo.
     * 
     * @return accountNo of type String
     */
    public String getAccountNo() {
        return accountNo;
    }

    /**
     * Mutator for property accountNo.
     * 
     * @param accountNo of type String
     */
    @XmlElement(name = "accountNo")
    public void setAccountNo(String accountNo) {
        this.accountNo = accountNo;
    }

    /**
     * Accessor for property schemeCategoryRank.
     * 
     * @return schemeCategoryRank of type String
     */
    public String getSchemeCategoryRank() {
        return schemeCategoryRank;
    }

    /**
     * Mutator for property schemeCategoryRank.
     * 
     * @param schemeCategoryRank of type String
     */
    public void setSchemeCategoryRank(String schemeCategoryRank) {
        this.schemeCategoryRank = schemeCategoryRank;
    }

    /**
     * Accessor for property schemeCategoryGroup.
     * 
     * @return schemeCategoryGroup of type String
     */
    public String getSchemeCategoryGroup() {
        return schemeCategoryGroup;
    }

    /**
     * Mutator for property schemeCategoryGroup.
     * 
     * @param schemeCategoryGroup of type String
     */
    public void setSchemeCategoryGroup(String schemeCategoryGroup) {
        this.schemeCategoryGroup = schemeCategoryGroup;
    }

    /**
     * Accessor for property schemeCategorySwitchFlag.
     * 
     * @return schemeCategorySwitchFlag of type String
     */
    public String getSchemeCategorySwitchFlag() {
        return schemeCategorySwitchFlag;
    }

    /**
     * Mutator for property schemeCategorySwitchFlag.
     * 
     * @param schemeCategorySwitchFlag of type String
     */
    public void setSchemeCategorySwitchFlag(String schemeCategorySwitchFlag) {
        this.schemeCategorySwitchFlag = schemeCategorySwitchFlag;
    }

    /**
     * Accessor for property schemeCategoryCode.
     * 
     * @return schemeCategoryCode of type String
     */
    public String getSchemeCategoryCode() {
        return schemeCategoryCode;
    }

    /**
     * Mutator for property schemeCategoryCode.
     * 
     * @param schemeCategoryCode of type String
     */
    public void setSchemeCategoryCode(String schemeCategoryCode) {
        this.schemeCategoryCode = schemeCategoryCode;
    }

    /**
     * Accessor for property schemeCategoryId.
     * 
     * @return schemeCategoryId of type String
     */
    public String getSchemeCategoryId() {
        return schemeCategoryId;
    }

    /**
     * Mutator for property schemeCategoryId.
     * 
     * @param schemeCategoryId of type String
     */
    public void setSchemeCategoryId(String schemeCategoryId) {
        this.schemeCategoryId = schemeCategoryId;
    }

    /**
     * Accessor for property schemeCategoryShortName.
     * 
     * @return schemeCategoryShortName of type String
     */
    public String getSchemeCategoryShortName() {
        return schemeCategoryShortName;
    }

    /**
     * Mutator for property schemeCategoryShortName.
     * 
     * @param schemeCategoryShortName of type String
     */
    public void setSchemeCategoryShortName(String schemeCategoryShortName) {
        this.schemeCategoryShortName = schemeCategoryShortName;
    }

    /**
     * Accessor for property mrrOccupationCode.
     * 
     * @return mrrOccupationCode of type String
     */
    public String getMrrOccupationCode() {
        return mrrOccupationCode;
    }

    /**
     * Mutator for property mrrOccupationCode.
     * 
     * @param mrrOccupationCode of type String
     */
    public void setMrrOccupationCode(String mrrOccupationCode) {
        this.mrrOccupationCode = mrrOccupationCode;
    }

    /**
     * Accessor for property mrrSchemeCategory.
     * 
     * @return mrrSchemeCategory of type String
     */
    public String getMrrSchemeCategory() {
        return mrrSchemeCategory;
    }

    /**
     * Mutator for property mrrSchemeCategory.
     * 
     * @param mrrSchemeCategory of type String
     */
    public void setMrrSchemeCategory(String mrrSchemeCategory) {
        this.mrrSchemeCategory = mrrSchemeCategory;
    }

    /**
     * Accessor for property createSchemeCategoryCode.
     * 
     * @return createSchemeCategoryCode of type String
     */
    public String getCreateSchemeCategoryCode() {
        return createSchemeCategoryCode;
    }

    /**
     * Mutator for property createSchemeCategoryCode.
     * 
     * @param createSchemeCategoryCode of type String
     */
    public void setCreateSchemeCategoryCode(String createSchemeCategoryCode) {
        this.createSchemeCategoryCode = createSchemeCategoryCode;
    }

    /**
     * Accessor for property createOccupationCode.
     * 
     * @return createOccupationCode of type String
     */
    public String getCreateOccupationCode() {
        return createOccupationCode;
    }

    /**
     * Mutator for property createOccupationCode.
     * 
     * @param createOccupationCode of type String
     */
    public void setCreateOccupationCode(String createOccupationCode) {
        this.createOccupationCode = createOccupationCode;
    }

    /**
     * Accessor for property defaultInsuranceFlag.
     * 
     * @return defaultInsuranceFlag of type String
     */
    public String getDefaultInsuranceFlag() {
        return defaultInsuranceFlag;
    }

    /**
     * Mutator for property defaultInsuranceFlag.
     * 
     * @param defaultInsuranceFlag of type String
     */
    public void setDefaultInsuranceFlag(String defaultInsuranceFlag) {
        this.defaultInsuranceFlag = defaultInsuranceFlag;
    }

    /**
     * Accessor for property benefit.
     * 
     * @return benefit of type String
     */
    public String getLifeBenefitLongName() {
        return lifeBenefitLongName;
    }

    /**
     * Mutator for property lifeBenefitlongName.
     * 
     * @param benefit of type String
     */
    public void setLifeBenefitLongName(String lifeBenefitLongName) {
        this.lifeBenefitLongName = lifeBenefitLongName;
    }

    /**
     * Accessor for property lifeRider.
     * 
     * @return lifeRider of type String
     */
    public String getLifeRider() {
        return lifeRider;
    }

    /**
     * Mutator for property lifeRider.
     * 
     * @param lifeRider of type String
     */
    public void setLifeRider(String lifeRider) {
        this.lifeRider = lifeRider;
    }

    /**
     * Accessor for property lifeRiderFactor.
     * 
     * @return lifeRiderFactor of type String
     */
    public String getLifeRiderFactor() {
        return lifeRiderFactor;
    }

    /**
     * Mutator for property lifeRiderFactor.
     * 
     * @param lifeRiderFactor of type String
     */
    public void setLifeRiderFactor(String lifeRiderFactor) {
        this.lifeRiderFactor = lifeRiderFactor;
    }

    /**
     * Accessor for property tpdRider.
     * 
     * @return tpdRider of type String
     */
    public String getTpdRider() {
        return tpdRider;
    }

    /**
     * Mutator for property tpdRider.
     * 
     * @param tpdRider of type String
     */
    public void setTpdRider(String tpdRider) {
        this.tpdRider = tpdRider;
    }

    /**
     * Accessor for property tpdRiderFactor.
     * 
     * @return tpdRiderFactor of type String
     */
    public String getTpdRiderFactor() {
        return tpdRiderFactor;
    }

    /**
     * Mutator for property tpdRiderFactor.
     * 
     * @param tpdRiderFactor of type String
     */
    public void setTpdRiderFactor(String tpdRiderFactor) {
        this.tpdRiderFactor = tpdRiderFactor;
    }

    /**
     * Accessor for property ipRider.
     * 
     * @return ipRider of type String
     */
    public String getIpRider() {
        return ipRider;
    }

    /**
     * Mutator for property ipRider.
     * 
     * @param ipRider of type String
     */
    public void setIpRider(String ipRider) {
        this.ipRider = ipRider;
    }

    /**
     * Accessor for property ipRiderFactor.
     * 
     * @return ipRiderFactor of type String
     */
    public String getIpRiderFactor() {
        return ipRiderFactor;
    }

    /**
     * Mutator for property ipRiderFactor.
     * 
     * @param ipRiderFactor of type String
     */
    public void setIpRiderFactor(String ipRiderFactor) {
        this.ipRiderFactor = ipRiderFactor;
    }

    /**
     * Accessor for property waitingPeriod.
     * 
     * @return waitingPeriod of type String
     */
    public String getWaitingPeriod() {
        return waitingPeriod;
    }

    /**
     * Mutator for property waitingPeriod.
     * 
     * @param waitingPeriod of type String
     */
    public void setWaitingPeriod(String waitingPeriod) {
        this.waitingPeriod = waitingPeriod;
    }

    /**
     * Accessor for property benefitPeriod.
     * 
     * @return benefitPeriod of type String
     */
    public String getBenefitPeriod() {
        return benefitPeriod;
    }

    /**
     * Mutator for property benefitPeriod.
     * 
     * @param benefitPeriod of type String
     */
    public void setBenefitPeriod(String benefitPeriod) {
        this.benefitPeriod = benefitPeriod;
    }

    /**
     * Accessor for property loadingFull.
     * 
     * @return loadingFull of type String
     */
    public String getLoadingFull() {
        return loadingFull;
    }

    /**
     * Mutator for property loadingFull.
     * 
     * @param loadingFull of type String
     */
    public void setLoadingFull(String loadingFull) {
        this.loadingFull = loadingFull;
    }

    /**
     * Accessor for property lifeLoading.
     * 
     * @return lifeLoading of type String
     */
    public String getLifeLoading() {
        return lifeLoading;
    }

    /**
     * Mutator for property lifeLoading.
     * 
     * @param lifeLoading of type String
     */
    public void setLifeLoading(String lifeLoading) {
        this.lifeLoading = lifeLoading;
    }

    /**
     * Accessor for property lifeFull.
     * 
     * @return lifeFull of type String
     */
    public String getLifeFull() {
        return lifeFull;
    }

    /**
     * Mutator for property lifeFull.
     * 
     * @param lifeFull of type String
     */
    public void setLifeFull(String lifeFull) {
        this.lifeFull = lifeFull;
    }

    /**
     * Accessor for property tpdBenefit.
     * 
     * @return tpdBenefit of type String
     */
    public String getTpdBenefitLongName() {
        return tpdBenefitLongName;
    }

    /**
     * Mutator for property tpdBenefit.
     * 
     * @param tpdBenefit of type String
     */
    public void setTpdBenefitLongName(String tpdBenefitLongName) {
        this.tpdBenefitLongName = tpdBenefitLongName;
    }

    /**
     * Accessor for property tpdLoading.
     * 
     * @return tpdLoading of type String
     */
    public String getTpdLoading() {
        return tpdLoading;
    }

    /**
     * Mutator for property tpdLoading.
     * 
     * @param tpdLoading of type String
     */
    public void setTpdLoading(String tpdLoading) {
        this.tpdLoading = tpdLoading;
    }

    /**
     * Accessor for property tpdFull.
     * 
     * @return tpdFull of type String
     */
    public String getTpdFull() {
        return tpdFull;
    }

    /**
     * Mutator for property tpdFull.
     * 
     * @param tpdFull of type String
     */
    public void setTpdFull(String tpdFull) {
        this.tpdFull = tpdFull;
    }

    /**
     * Accessor for property ipBenefitLongName.
     * 
     * @return ipBenefit of type String
     */
    public String getIpBenefitLongName() {
        return ipBenefitLongName;
    }

    /**
     * Mutator for property ipBenefit.
     * 
     * @param ipBenefit of type String
     */
    public void setIpBenefitLongName(String ipBenefitLongName) {
        this.ipBenefitLongName = ipBenefitLongName;
    }

    /**
     * Accessor for property ipLoading.
     * 
     * @return ipLoading of type String
     */
    public String getIpLoading() {
        return ipLoading;
    }

    /**
     * Mutator for property ipLoading.
     * 
     * @param ipLoading of type String
     */
    public void setIpLoading(String ipLoading) {
        this.ipLoading = ipLoading;
    }

    /**
     * Accessor for property ipFull.
     * 
     * @return ipFull of type String
     */
    public String getIpFull() {
        return ipFull;
    }

    /**
     * Mutator for property ipFull.
     * 
     * @param ipFull of type String
     */
    public void setIpFull(String ipFull) {
        this.ipFull = ipFull;
    }

    /**
     * Accessor for property ipWaitingPeriod.
     * 
     * @return ipWaitingPeriod of type String
     */
    public String getIpWaitingPeriod() {
        return ipWaitingPeriod;
    }

    /**
     * Mutator for property ipWaitingPeriod.
     * 
     * @param ipWaitingPeriod of type String
     */
    public void setIpWaitingPeriod(String ipWaitingPeriod) {
        this.ipWaitingPeriod = ipWaitingPeriod;
    }

    /**
     * Accessor for property ipBenefitPeriod.
     * 
     * @return ipBenefitPeriod of type String
     */
    public String getIpBenefitPeriod() {
        return ipBenefitPeriod;
    }

    /**
     * Mutator for property ipBenefitPeriod.
     * 
     * @param ipBenefitPeriod of type String
     */
    public void setIpBenefitPeriod(String ipBenefitPeriod) {
        this.ipBenefitPeriod = ipBenefitPeriod;
    }

    /**
     * Accessor for property lifeRideUnits.
     * 
     * @return lifeRideUnits of type String
     */
    public String getLifeRiderUnits() {
        return lifeRiderUnits;
    }

    /**
     * Mutator for property lifeRideUnits.
     * 
     * @param lifeRideUnits of type String
     */
    public void setLifeRiderUnits(String lifeRiderUnits) {
        this.lifeRiderUnits = lifeRiderUnits;
    }

    /**
     * Accessor for property tpdRiderUnits.
     * 
     * @return tpdRiderUnits of type String
     */
    public String getTpdRiderUnits() {
        return tpdRiderUnits;
    }

    /**
     * Mutator for property tpdRiderUnits.
     * 
     * @param tpdRiderUnits of type String
     */
    public void setTpdRiderUnits(String tpdRiderUnits) {
        this.tpdRiderUnits = tpdRiderUnits;
    }

    /**
     * Accessor for property lifeRiderReviewId.
     * 
     * @return lifeRiderReviewId of type String
     */
    public String getLifeRiderReviewId() {
        return lifeRiderReviewId;
    }

    /**
     * Mutator for property lifeRiderReviewId.
     * 
     * @param lifeRiderReviewId of type String
     */
    public void setLifeRiderReviewId(String lifeRiderReviewId) {
        this.lifeRiderReviewId = lifeRiderReviewId;
    }

    /**
     * Accessor for property ipRiderReviewId.
     * 
     * @return ipRiderReviewId of type String
     */
    public String getIpRiderReviewId() {
        return ipRiderReviewId;
    }

    /**
     * Mutator for property ipRiderReviewId.
     * 
     * @param ipRiderReviewId of type String
     */
    public void setIpRiderReviewId(String ipRiderReviewId) {
        this.ipRiderReviewId = ipRiderReviewId;
    }

    /**
     * Accessor for property tpdRiderReviewId.
     * 
     * @return tpdRiderReviewId of type String
     */
    public String getTpdRiderReviewId() {
        return tpdRiderReviewId;
    }

    /**
     * Mutator for property tpdRiderReviewId.
     * 
     * @param tpdRiderReviewId of type String
     */
    public void setTpdRiderReviewId(String tpdRiderReviewId) {
        this.tpdRiderReviewId = tpdRiderReviewId;
    }

    /**
     * Accessor for property employerAbn.
     * 
     * @return employerAbn of type String
     */
    public String getEmployerAbn() {
        return employerAbn;
    }

    /**
     * Mutator for property employerAbn.
     * 
     * @param employerAbn of type String
     */
    public void setEmployerAbn(String employerAbn) {
        this.employerAbn = employerAbn;
    }
}
