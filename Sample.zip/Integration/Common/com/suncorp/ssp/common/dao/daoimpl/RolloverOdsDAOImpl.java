////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.common.dao.daoimpl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.dao.daointerface.SSPDAO;
import com.suncorp.ssp.common.dao.datasource.OdsDO;
import com.suncorp.ssp.common.dao.datasource.OdsDataSource;
import com.suncorp.ssp.common.dao.datasource.RolloverOdsDO;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;

/**
 * The class {@code RolloverOdsDAOImpl} is a DAO implementation class for rollover service related to ODS.
 * 
 * @author U385424
 * @since 05/06/2017
 * @version 1.0
 */
public class RolloverOdsDAOImpl implements SSPDAO {

    private OdsDataSource dataSource = null;
    private final String className = "RollOverDAOImpl";

    public RolloverOdsDAOImpl() {
        this.dataSource = new OdsDataSource();
    }

    /**
     * This method is used to create ods DB connection.
     * 
     * @param url
     * @param user
     * @param pswd
     * @return
     * @throws SILException
     */
    private Connection odsDBConnection(String url, String user, String pswd) throws SILException {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, className, "Entering odsDBConnection method");
        Connection conn = null;
        try {
            conn = dataSource.getConnection(url, user, pswd);
            SILLogger.debug(CommonConstants.LOGGING_FORMAT, className, "Exiting odsDBConnection method");
        } catch (Exception exception) {
            SILLogger.error(CommonConstants.LOGGING_FORMAT, className, SILUtil.getReqExMsg(exception));
            throw new SILException(CommonConstants.ODS_CONNECTION_FAILED);
        }
        return conn;
    }

    /**
     * Does this.
     * 
     * @param queryParam
     * @param url
     * @param user
     * @param password
     * @return
     * @throws SILException
     */
    @Override
    public List getDetails(List<String> queryParam, String url, String user, String password) throws SILException {
        // TODO Auto-generated method stub
        return null;
    }

    /**
     * This method is used to get details for scheme category.
     * 
     * @param inputParams
     * @param sonataUrl
     * @param sonataUsername
     * @param sonataPswd
     * @return
     * @throws SILException
     */
    public List<OdsDO> getDetailsForMRRSchemeCategory(Map<String, String> inputParams, String url, String user, String pswd) throws SILException {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, className, "Entering getDetailsForMRRSchemeCategory");
        Connection connection = null;
        List<OdsDO> odsDOs = null;
        try {
            connection = odsDBConnection(url, user, pswd);
            odsDOs = dataSource.executeProcGetMRRSchemeCategoryDetails(inputParams, connection);
            odsDOs = checkAndCallSchemecategoryLookup(odsDOs, url, user, pswd);
            SILLogger.debug(CommonConstants.LOGGING_FORMAT, className, "Exiting getDetailsForBenefitPlan method");
        } catch (Exception exception) {
            SILLogger.error(CommonConstants.LOGGING_FORMAT, className, SILUtil.getReqExMsg(exception));
            throw new SILException(CommonConstants.SONATA_DB_TRANSACTION_FAILED);
        } finally {
            closeConnection(connection);
        }
        return odsDOs;
    }

    /**
     * This method is used to check scheme category condition and call proc.
     * 
     * @param outboundList
     * @param odsDOs
     * @param pswd
     * @param user
     * @param url
     * @throws SILException
     */
    private List<OdsDO> checkAndCallSchemecategoryLookup(List<OdsDO> odsDOs, String url, String user, String pswd) throws SILException {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, className, "Entering checkAndCallSchemecategoryLookup");
        if (odsDOs != null &&
                odsDOs.size() > 1 &&
                !odsDOs.get(CommonConstants.SPCL_EMPLOYER_FILE_LOOP_INDEX).getSchemeCategoryGroup()
                        .equalsIgnoreCase(odsDOs.get(CommonConstants.SPCL_EMPLOYER_SONATA_LOOP_INDEX).getSchemeCategoryGroup()) &&
                CommonConstants.FLAG_Y.equalsIgnoreCase(odsDOs.get(CommonConstants.SPCL_EMPLOYER_SONATA_LOOP_INDEX).getSchemeCategorySwitchFlag()) &&
                !odsDOs.get(CommonConstants.SPCL_EMPLOYER_FILE_LOOP_INDEX).getSchemeCategoryRank()
                .equalsIgnoreCase(odsDOs.get(CommonConstants.SPCL_EMPLOYER_SONATA_LOOP_INDEX).getSchemeCategoryRank())) {
            return getLookupDetailsForSchemeCategory(url, user, pswd, odsDOs.get(CommonConstants.SPCL_EMPLOYER_SONATA_LOOP_INDEX)
                    .getSchemeCategoryGroup(), odsDOs.get(CommonConstants.SPCL_EMPLOYER_FILE_LOOP_INDEX).getSchemeCategoryRank());
        } else {
            return odsDOs;
        }
    }

    /**
     * This method is used to get lookup details for scheme category.
     * 
     * @param pswd
     * @param user
     * @param url
     * @param rank
     * @param group
     * @throws SILException
     * 
     */
    private List<OdsDO> getLookupDetailsForSchemeCategory(String url, String user, String pswd, String group, String rank) throws SILException {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, className, "Entering getLookupDetailsForSchemeCategory");
        Connection connection = null;
        List<OdsDO> odsDOs = null;
        try {
            connection = odsDBConnection(url, user, pswd);
            List<String> inputParams = new ArrayList<String>();
            inputParams.add(0, group);
            inputParams.add(1, rank);
            odsDOs = dataSource.executeProcLookupDetailsForSchemeCategory(inputParams, connection);
            SILLogger.debug(CommonConstants.LOGGING_FORMAT, className, "Exiting getDetailsForBenefitPlan method");
        } catch (Exception exception) {
            SILLogger.error(CommonConstants.LOGGING_FORMAT, className, SILUtil.getReqExMsg(exception));
            throw new SILException(CommonConstants.SONATA_DB_TRANSACTION_FAILED);
        } finally {
            closeConnection(connection);
        }
        return odsDOs;
    }

    /**
     * This method is used to get special employer details.
     * 
     * @param inputParams
     * @param sonataUrl
     * @param sonataUsername
     * @param sonataPswd
     * @return
     * @throws SILException
     */
    public List<OdsDO> getDetailsForSpecialEmployerDetails(Map<String, String> inputParams, String url, String user, String pswd) throws SILException
    {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, className, "Entering getDetailsForSpecialEmployerDetails");
        Connection connection = null;
        List<OdsDO> odsDOs = null;
        try {
            connection = odsDBConnection(url, user, pswd);
            odsDOs =
                    dataSource.executeProcGetSpecialEmployerDetails(inputParams.get(CommonConstants.EMPLOYER_NUMBER),
                            inputParams.get(CommonConstants.SCHEMA_NAME), connection);
            SILLogger.debug(CommonConstants.LOGGING_FORMAT, className, "Exiting getDetailsForBenefitPlan method");
        } catch (Exception exception) {
            SILLogger.error(CommonConstants.LOGGING_FORMAT, className, SILUtil.getReqExMsg(exception));
            throw new SILException(CommonConstants.SONATA_DB_TRANSACTION_FAILED);
        } finally {
            closeConnection(connection);
        }
        return odsDOs;
    }

    /**
     * This method is used to get special employer details.
     * 
     * @param sonataUrl
     * @param sonataUsername
     * @param sonataPswd
     * @return
     * @throws SILException
     */
    public List<RolloverOdsDO> getPendingInsuranceAccountList(String url, String user, String pswd)
            throws SILException {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, className, "Entering getDetailsForSpecialEmployerDetails");
        Connection connection = null;
        List<RolloverOdsDO> rolloverOdsDO = null;
        try {
            connection = odsDBConnection(url, user, pswd);
            rolloverOdsDO = dataSource.executeProcGetPendingInsuranceAccountList(connection);
            SILLogger.debug(CommonConstants.LOGGING_FORMAT, className, "Exiting getDetailsForBenefitPlan method");
        } catch (Exception exception) {
            SILLogger.error(CommonConstants.LOGGING_FORMAT, className, SILUtil.getReqExMsg(exception));
            throw new SILException(CommonConstants.SONATA_DB_TRANSACTION_FAILED);
        } finally {
            closeConnection(connection);
        }
        return rolloverOdsDO;
    }

    /**
     * This method is used to get special employer details.
     * 
     * @param inputParams
     * @param sonataUrl
     * @param sonataUsername
     * @param sonataPswd
     * @return
     * @throws SILException
     */
    public List<OdsDO> getDetailsForEmployerDetailsFromDb(Map<String, String> inputParams, String url, String user, String pswd) throws SILException {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, className, "Entering getDetailsForSpecialEmployerDetails");
        Connection connection = null;
        List<OdsDO> odsDOs = null;
        try {
            connection = odsDBConnection(url, user, pswd);
            odsDOs =
                    dataSource.executeProcGetEmployerDetailsFromDb(inputParams.get(CommonConstants.SIL_EMPLOYER_ABN),
                            inputParams.get(CommonConstants.SCHEMA_NAME), connection);
            SILLogger.debug(CommonConstants.LOGGING_FORMAT, className, "Exiting getDetailsForBenefitPlan method");
        } catch (Exception exception) {
            SILLogger.error(CommonConstants.LOGGING_FORMAT, className, SILUtil.getReqExMsg(exception));
            throw new SILException(CommonConstants.SONATA_DB_TRANSACTION_FAILED);
        } finally {
            closeConnection(connection);
        }
        return odsDOs;
    }

    /**
     * This method closes the db connection.
     * 
     * @param connection
     * @throws SILException
     */
    private void closeConnection(Connection connection) {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, className, "Entering closeConnection");
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException sqlException) {
                SILLogger.error(CommonConstants.LOGGING_FORMAT, className, SILUtil.getReqExMsg(sqlException));
            }
        }
    }
}
