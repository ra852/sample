////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.common.dao.daoimpl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.dao.daointerface.SSPDAO;
import com.suncorp.ssp.common.dao.datasource.OdsDO;
import com.suncorp.ssp.common.dao.datasource.OdsDataSource;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;

/**
 * The class {@code InsuranceStatusDAOImpl} does this.
 * 
 * @author U387938
 * @since 06/09/2016
 * @version 1.0
 */
public class InsuranceStatusDAOImpl implements SSPDAO {
    private OdsDataSource dataSource = null;
    private final String className = "InsuranceStatusDAOImpl";

    /**
     * Does this.
     * 
     */
    public InsuranceStatusDAOImpl() {
        this.dataSource = new OdsDataSource();
    }

    /**
     * Does this.
     * 
     * @param url
     * @param user
     * @param pswd
     * @return
     * @throws SILException
     */
    private Connection odsDBConnection(String url, String user, String pswd) throws SILException {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, className, "Entering odsDBConnection method");
        Connection conn = null;
        try {
            conn = dataSource.getConnection(url, user, pswd);
            SILLogger.debug(CommonConstants.LOGGING_FORMAT, className, "Exiting odsDBConnection method");
        } catch (Exception exception) {
            SILLogger.error(CommonConstants.LOGGING_FORMAT, className, SILUtil.getReqExMsg(exception));
            throw new SILException(CommonConstants.ODS_CONNECTION_FAILED);
        }
        return conn;
    }

    /**
     * 
     * This method makes a call to ODS db to fetch pending insurance status for a given advisor ID.
     * 
     * @param queryParam
     * @param url
     * @param user
     * @param pswd
     * @return
     * @throws SILException
     */
    @Override
    public List getDetails(List<String> inputParams, String url, String user, String pswd) throws SILException {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, className, "Entering getDetails method");
        Connection connection = odsDBConnection(url, user, pswd);
        List<OdsDO> odsDOs = null;
        try {
            odsDOs = dataSource.executeProcInsuranceStatus(inputParams, connection);
            SILLogger.debug(CommonConstants.LOGGING_FORMAT, className, "Exiting getDetails method");
        } catch (Exception exception) {
            SILLogger.error(CommonConstants.LOGGING_FORMAT, className, SILUtil.getReqExMsg(exception));
            throw new SILException(CommonConstants.ODS_CONNECTION_FAILED);
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException sqlException) {
                    SILLogger.error(CommonConstants.LOGGING_FORMAT, className, SILUtil.getReqExMsg(sqlException));
                }
            }
        }
        return odsDOs;
    }
}
