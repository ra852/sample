////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.common.dao.daoimpl;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.dao.daointerface.SSPDAO;
import com.suncorp.ssp.common.dao.datasource.SonataDO;
import com.suncorp.ssp.common.dao.datasource.SonataDataSource;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;

/**
 * The class {@code RollOverDAOImpl} does this.
 * 
 * @author U387938
 * @since 06/09/2016
 * @version 1.0
 */
public class RollOverDAOImpl implements SSPDAO {
    private SonataDataSource dataSource = null;
    private final String className = "RollOverDAOImpl";

    public RollOverDAOImpl() {
        this.dataSource = new SonataDataSource();
    }

    /**
     * 
     * This method returns a sonata database connection.
     * 
     * @param url
     * @param user
     * @param pswd
     * @return
     * @throws SILException
     */
    private Connection sonataDBConnection(String url, String user, String pswd) throws SILException {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, className, "Entering sonataDBConnection method");
        Connection conn = null;

        try {
            conn = dataSource.getConnection(url, user, pswd);
            SILLogger.debug(CommonConstants.LOGGING_FORMAT, className, "Exiting sonataDBConnection method");
        } catch (Exception exception) {
            SILLogger.error(CommonConstants.LOGGING_FORMAT, className, SILUtil.getReqExMsg(exception));
            throw new SILException(CommonConstants.SONATA_DB_CONNECTION_FAILED);
        }
        return conn;

    }

    /**
     * 
     * This method executes the sonata DB proc to fetch data. This method is the generic method and needs to add the logic before using it.
     * 
     * @param queryParam
     * @param url
     * @param user
     * @param pswd
     * @return
     * @throws SILException
     */
    @Override
    public List getDetails(List<String> queryParam, String url, String user, String pswd) throws SILException {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, className, "Entering getDetails method");
        Connection connection = null;
        List<SonataDO> sonataDOs = null;
        try {
            connection = sonataDBConnection(url, user, pswd);
            SILLogger.debug(CommonConstants.LOGGING_FORMAT, className, "Exiting getDetails method");
        } catch (Exception exception) {
            SILLogger.error(CommonConstants.LOGGING_FORMAT, className, SILUtil.getReqExMsg(exception));
            throw new SILException(CommonConstants.SONATA_DB_TRANSACTION_FAILED);
        } finally {
            closeConnection(connection);
        }
        return sonataDOs;
    }

    /**
     * 
     * This method executes the sonata DB proc to fetch data.
     * 
     * @param inputParams
     * @param url
     * @param user
     * @param pswd
     * @return sonataDOs
     * @throws SILException
     */
    public List getDetailsForBenefitPlan(Map<String, String> inputParams, String url, String user, String pswd) throws SILException {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, className, "Entering getDetailsForBenefitPlan method");
        Connection connection = null;
        List<SonataDO> sonataDOs = null;
        try {
            connection = sonataDBConnection(url, user, pswd);
            sonataDOs =
                    dataSource.executeProcs(inputParams.get(CommonConstants.EMP_NAME), inputParams.get(CommonConstants.OCCUPATION_CODE),
                            inputParams.get(CommonConstants.CATEGORY_CODE), connection, inputParams.get(CommonConstants.SCHEMA_NAME));
            SILLogger.debug(CommonConstants.LOGGING_FORMAT, className, "Exiting getDetailsForBenefitPlan method");
        } catch (Exception exception) {
            SILLogger.error(CommonConstants.LOGGING_FORMAT, className, SILUtil.getReqExMsg(exception));
            throw new SILException(CommonConstants.SONATA_DB_TRANSACTION_FAILED);
        } finally {
            closeConnection(connection);
        }
        return sonataDOs;
    }

    /**
     * This method closes the db connection.
     * 
     * @param connection
     * @throws SILException
     */
    private void closeConnection(Connection connection) {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException sqlException) {
                SILLogger.error(CommonConstants.LOGGING_FORMAT, className, SILUtil.getReqExMsg(sqlException));
            }
        }
    }

}
