////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.common.dao.datasource;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import oracle.jdbc.OracleTypes;
import oracle.jdbc.pool.OracleDataSource;

import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;

/**
 * The class {@code OdsDataSource} is a Data source used to create connection to ODS DB and fetch required parameters.
 * 
 * @author U387938
 * @since 02/09/2016
 * @version 1.0
 */
public class OdsDataSource {
    private final String className = "OdsDataSource";

    /**
     * ODS connection.
     * 
     * @param args
     * @throws SILException
     */
    public Connection getConnection(String url, String user, String pswd) throws SILException {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, className, "Entering getConnection method");
        Connection result = null;
        try {
            OracleDataSource dataSource = new OracleDataSource();
            dataSource.setURL(url);
            dataSource.setUser(user);
            dataSource.setPassword(pswd);
            result = dataSource.getConnection();
            SILLogger.debug(CommonConstants.LOGGING_FORMAT, className, "Entering getConnection method");
        } catch (SQLException sqlException) {
            SILLogger.error(CommonConstants.LOGGING_FORMAT, className, SILUtil.getReqExMsg(sqlException));
            throw new SILException(CommonConstants.ODS_CONNECTION_FAILED);
        } catch (Exception exception) {
            SILLogger.error(CommonConstants.LOGGING_FORMAT, className, SILUtil.getReqExMsg(exception));
            throw new SILException(CommonConstants.ODS_CONNECTION_FAILED);
        }
        return result;
    }

    /**
     * 
     * This method fetches the data from Sonata db.
     * 
     * @param connection
     * @param inputParam
     * @param categoryCode
     * @return
     * @throws SILException
     */
    public List<OdsDO> executeProc(List<String> inputParams, Connection connection) throws SILException {
        CallableStatement callableStatement = null;
        ResultSet rs = null;
        List<OdsDO> odsDOs = new ArrayList<OdsDO>();
        String getTermsAndConditionsProc = "{call PROC_TERMSANDCONDITIONS(?,?)}";
        try {
            callableStatement = connection.prepareCall(getTermsAndConditionsProc);
            callableStatement.setString("ADVISER_CLIENT_ID", inputParams.get(0));
            callableStatement.registerOutParameter("RETVAL", OracleTypes.CURSOR);
            callableStatement.executeUpdate();
            rs = (ResultSet) callableStatement.getObject("RETVAL");
            while (rs.next()) {
                setOdsDOParams(odsDOs, rs);
            }
        } catch (SQLException sqlException) {
            handleSQLException(sqlException);
        } catch (Exception exception) {
            handleException(exception);
        } finally {
            closeDBObjects(callableStatement, rs);
        }
        return odsDOs;
    }

    /**
     * This method prepares the data object.
     * 
     * @param categoryCode
     * @param sonataDOs
     * @param rs
     * @throws SQLException
     */
    private void setOdsDOParams(List<OdsDO> odsDOs, ResultSet rs) throws SQLException {
        OdsDO odsDO = new OdsDO();
        odsDO.setAdvisorClientId(String.valueOf(rs.getLong(CommonConstants.ADVISOR_CLIENT_ID)));
        odsDO.setMemberClientId(String.valueOf(rs.getLong(CommonConstants.MEMBER_CLIENT_ID)));
        odsDO.setMemberAccountId(String.valueOf(rs.getLong(CommonConstants.MEMBER_ACCOUNT_ID)));
        odsDO.setMemberFirstName(rs.getString(CommonConstants.MEMBER_FIRST_NAME));
        odsDO.setMemberName(rs.getString(CommonConstants.MEMBER_NAME));
        odsDO.setMemberAccountNumber(rs.getString(CommonConstants.MEMBER_ACCOUNT_NUMBER));
        odsDO.setProductName(rs.getString(CommonConstants.PRODUCT_NAME));
        odsDO.setLastUpdated(SILUtil.convertDateToString(rs.getDate(CommonConstants.UPDATE_DATE), CommonConstants.DATE_FORMAT));
        odsDO.setTermsAndConditionValue(rs.getString(CommonConstants.VARIABLE_VALUE));
        odsDOs.add(odsDO);

    }

    /**
     * This method handles Exception.
     * 
     * @param exception
     * @throws SILException
     */
    private void handleException(Exception exception) throws SILException {
        SILLogger.error(CommonConstants.LOGGING_FORMAT, className, exception.getMessage());
        throw new SILException(exception.getMessage());
    }

    /**
     * This method handles SQLException.
     * 
     * @param sqlException
     * @throws SILException
     */
    private void handleSQLException(SQLException sqlException) throws SILException {
        SILLogger.error(CommonConstants.LOGGING_FORMAT, className, sqlException.getMessage());
        throw new SILException(sqlException.getMessage());
    }

    /**
     * This method is used to close DB Object.
     * 
     * @param st
     * @param rs
     * @throws SILException
     */
    private void closeDBObjects(CallableStatement cs, ResultSet rs) {
        closeResultSet(rs);
        closeCallableStatement(cs);
    }

    /**
     * This method is used to close CallableStatement Object.
     * 
     * @param cs
     */
    private void closeCallableStatement(CallableStatement cs) {
        if (cs != null) {
            try {
                cs.close();
            } catch (SQLException eSqlException) {
                SILLogger.error(CommonConstants.LOGGING_FORMAT, className, SILUtil.getReqExMsg(eSqlException));
            }
        }
    }

    /**
     * This method is used to close ResultSet Object.
     * 
     * @param rs
     */
    private void closeResultSet(ResultSet rs) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException sqlException) {
                SILLogger.error(CommonConstants.LOGGING_FORMAT, className, SILUtil.getReqExMsg(sqlException));
            }
        }
    }

    /**
     * 
     * This method fetches the data from Sonata db for Insurance status.
     * 
     * @param connection
     * @param inputParam
     * @param categoryCode
     * @return
     * @throws SILException
     */
    public List<OdsDO> executeProcInsuranceStatus(List<String> inputParams, Connection connection) throws SILException {
        CallableStatement callableStatement = null;
        ResultSet rs = null;
        List<OdsDO> odsDOs = new ArrayList<OdsDO>();
        String getTermsAndConditionsProc = "{call SP_GETINSURANCE_STATUS(?,?)}";
        try {
            callableStatement = connection.prepareCall(getTermsAndConditionsProc);
            callableStatement.setString("ADVISER_CLIENT_ID", inputParams.get(0));
            callableStatement.registerOutParameter("RETVAL", OracleTypes.CURSOR);
            callableStatement.executeUpdate();
            rs = (ResultSet) callableStatement.getObject("RETVAL");
            while (rs.next()) {
                setOdsDOParamsForInsurance(odsDOs, rs);
            }
        } catch (SQLException sqlException) {
            handleSQLException(sqlException);
        } catch (Exception exception) {
            handleException(exception);
        } finally {
            closeDBObjects(callableStatement, rs);
        }
        return odsDOs;
    }

    /**
     * This method prepares the data object for Insurance status call.
     * 
     * @param categoryCode
     * @param sonataDOs
     * @param rs
     * @throws SQLException
     */
    private void setOdsDOParamsForInsurance(List<OdsDO> odsDOs, ResultSet rs) throws SQLException {
        OdsDO odsDO = new OdsDO();
        odsDO.setAdvisorClientId(String.valueOf(rs.getLong(CommonConstants.ADVISOR_CLIENT_ID)));
        odsDO.setMemberClientId(String.valueOf(rs.getLong(CommonConstants.MEMBER_CLIENT_ID)));
        odsDO.setMemberAccountId(String.valueOf(rs.getLong(CommonConstants.MEMBER_ACCOUNT_ID)));
        odsDO.setMemberFirstName(rs.getString(CommonConstants.MEMBER_FIRST_NAME));
        odsDO.setMemberName(rs.getString(CommonConstants.MEMBER_NAME));
        odsDO.setMemberAccountNumber(rs.getString(CommonConstants.MEMBER_ACCOUNT_NUMBER));
        odsDO.setProductName(rs.getString(CommonConstants.PRODUCT_NAME));
        odsDO.setAccountStatus(rs.getString(CommonConstants.STATUS));
        odsDO.setAdvisorFirstName(rs.getString(CommonConstants.ADVISER_FIRST_NAME));
        odsDO.setAdvisorName(rs.getString(CommonConstants.ADVISER_NAME));
        odsDO.setCommenceDate(rs.getString(CommonConstants.COMMENCE_DATE));
        odsDO.setInsuranceDesc(rs.getString(CommonConstants.DESCRIPTION));
        odsDO.setEffectiveDate(rs.getString(CommonConstants.DATE_INSURANCE_ACTIVITY_STATUS));
        odsDOs.add(odsDO);
    }

    /**
     * 
     * This method fetches the data from ODS DB.
     * 
     * @param connection
     * @param inputParam
     * @param categoryCode
     * @return
     * @throws SILException
     */
    public List<OdsDO> executeFamilyLinkingProc(List<String> inputParams, Connection connection) throws SILException {
        CallableStatement callableStatement = null;
        ResultSet rs = null;
        List<OdsDO> odsDOs = new ArrayList<OdsDO>();
        String getFamilyLinkingProc = "{call SP_FML_LINKED_DETAIL(?,?)}";
        try {
            callableStatement = connection.prepareCall(getFamilyLinkingProc);

            callableStatement.registerOutParameter("RETVAL", OracleTypes.CURSOR);
            callableStatement.setString("FML_ACCOUNT_NUMBER", inputParams.get(0));
            callableStatement.executeUpdate();
            rs = (ResultSet) callableStatement.getObject("RETVAL");
            while (rs.next()) {
                setOdsDOParamsForFamilyLinking(odsDOs, rs);
            }
        } catch (SQLException sqlException) {
            handleSQLException(sqlException);
        } catch (Exception exception) {
            handleException(exception);
        } finally {
            closeDBObjects(callableStatement, rs);
        }
        return odsDOs;
    }

    /**
     * This method prepares the data object for Family Linking call.
     * 
     * @param categoryCode
     * @param sonataDOs
     * @param rs
     * @throws SQLException
     */
    private void setOdsDOParamsForFamilyLinking(List<OdsDO> odsDOs, ResultSet rs) throws SQLException {
        OdsDO odsDO = new OdsDO();
        odsDO.setMemberAccountNumber(rs.getString("LINKED_MEM_ACCOUNT_ID"));
        odsDO.setMemberFirstName(rs.getString("MEMBER_FIRST_NAME"));
        odsDO.setMemberLastName(rs.getString("MEMBER_SURNAME"));
        odsDO.setMemberDateOfBirth(SILUtil.convertDateToString(rs.getDate("MEMBER_DATE_OF_BIRTH"), CommonConstants.DATE_FORMAT));
        odsDOs.add(odsDO);
    }

    /**
     * 
     * This method fetches the data from ODS DB for Advisor Report.
     * 
     * @param connection
     * @param inputParam
     * @param categoryCode
     * @return
     * @throws SILException
     */
    public List<OdsDO> executeProcGetAdvisorReport(List<String> inputParams, Connection connection) throws SILException {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, className, "Entering executeProcGetAdvisorReport method");
        CallableStatement callableStatement = null;
        ResultSet rs = null;
        List<OdsDO> odsDOs = new ArrayList<OdsDO>();
        String getAdvisorReportProc = "{call SP_SUNC_DIG_ADV_REPORT(?,?)}";
        try {
            callableStatement = connection.prepareCall(getAdvisorReportProc);
            callableStatement.registerOutParameter("RETVAL", OracleTypes.CURSOR);
            callableStatement.setString("client_id", inputParams.get(0));

            callableStatement.executeUpdate();
            rs = (ResultSet) callableStatement.getObject("RETVAL");
            while (rs.next()) {
                setOdsDOParamsForAdvisorReport(odsDOs, rs);
            }
        } catch (SQLException sqlException) {
            handleSQLException(sqlException);
        } catch (Exception exception) {
            handleException(exception);
        } finally {
            closeDBObjects(callableStatement, rs);
        }
        return odsDOs;
    }

    /**
     * This method prepares the data object for Advisor Report call.
     * 
     * @param odsDOs
     * @param rs
     * @throws SQLException
     */
    private void setOdsDOParamsForAdvisorReport(List<OdsDO> odsDOs, ResultSet rs) throws SQLException {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, className, "Entering setOdsDOParamsForAdvisorReport method");
        OdsDO odsDO = new OdsDO();
        odsDO.setAdvisorClientId(rs.getString("ADVISER_ID"));
        odsDO.setMemberAccountNumber(rs.getString("MEMBER_NUMBER"));
        odsDO.setMemberLastName(rs.getString("MEMBER_SURNAME"));
        odsDO.setEmployerReference(rs.getString("EMPLOYER_REFERENCE"));
        odsDO.setEmployerId(rs.getString("EMPLOYER_ID"));
        odsDO.setEmployerName(rs.getString("EMPLOYER_NAME"));
        odsDO.setMemberGivenName(rs.getString("MEMBER_GIVEN_NAME"));
        odsDO.setAddress(rs.getString("ADDRESS"));
        odsDO.setSuburb(rs.getString("SUBURD"));
        odsDO.setState(rs.getString("STATE"));
        odsDO.setPostCode(rs.getString("POST_CODE"));
        odsDO.setAddressType(rs.getString("ADDRESS_TYPE"));
        odsDO.setHomePhone(rs.getString("HOME_PHONE"));
        odsDO.setWorkPhone(rs.getString("WORK_PHONE"));
        odsDO.setMobileNumber(rs.getString("MOBILE_PHONE"));
        odsDO.setEmail(rs.getString("EMAIL"));
        odsDO.setGender(rs.getString("GENDER"));
        setOtherOdsParamsForAdvisorReport(rs, odsDO);
        setOtherRemainingOdsParamsForAdvisorReport(rs, odsDO);
        odsDOs.add(odsDO);
    }

    /**
     * This method prepares the data object for Advisor Report call.
     * 
     * @param rs
     * @param odsDO
     * @throws SQLException
     */
    private void setOtherOdsParamsForAdvisorReport(ResultSet rs, OdsDO odsDO) throws SQLException {
        odsDO.setAnb(String.valueOf(rs.getInt("ANB")));
        odsDO.setSalary(String.valueOf(rs.getDouble("SALARY")));
        odsDO.setTfn(rs.getString("TFN"));
        odsDO.setSmoker(rs.getString("SMOKER"));
        odsDO.setBeneficiaryType(rs.getString("BENEFICIARY_TYPE"));
        odsDO.setProduct(rs.getString("PRODUCT"));
        odsDO.setCurrentAccountBalance(String.valueOf(rs.getDouble("CURRENT_ACCOUNT_BALANCE")));
        odsDO.setLifeStageFlag(rs.getString("100% LIFE STAGE"));
        odsDO.setIpSumInsured(String.valueOf(rs.getInt("IP_SUM_INSURED")));
        odsDO.setTpdSumInsured(String.valueOf(rs.getInt("TPD_SUM_INSURED")));
        odsDO.setLifeSumInsured(String.valueOf(rs.getInt("LIFE_SUM_INSURED")));
        odsDO.setLifeMonthlyPremium(String.valueOf(rs.getInt("LIFE_MONTHLY_PREMIUM")));
        odsDO.setIpMonthlyPremium(String.valueOf(rs.getInt("IP_MONTHLY_PREMIUM")));
        odsDO.setTpdMonthlyPremium(String.valueOf(rs.getInt("TPD_MONTHLY_PREMIUM")));
    }

    /**
     * This method prepares the data object for Advisor Report call.
     * 
     * @param rs
     * @param odsDO
     * @throws SQLException
     */
    private void setOtherRemainingOdsParamsForAdvisorReport(ResultSet rs, OdsDO odsDO) throws SQLException {
        if (rs.getDate("DOB") != null) {
            odsDO.setMemberDateOfBirth(SILUtil.convertDateToString(rs.getDate("DOB"), CommonConstants.DATE_FORMAT));
        }
        if (rs.getDate("FUND_START_DATE") != null) {
            odsDO.setFundStartDate(SILUtil.convertDateToString(rs.getDate("FUND_START_DATE"), CommonConstants.DATE_FORMAT));
        }
        if (rs.getDate("FUND_END_DATE") != null) {
            odsDO.setFundEndDate(SILUtil.convertDateToString(rs.getDate("FUND_END_DATE"), CommonConstants.DATE_FORMAT));
        }
        if (rs.getDate("EMPLOYMENT_START_DATE") != null) {
            odsDO.setEmploymentStartDate(SILUtil.convertDateToString(rs.getDate("EMPLOYMENT_START_DATE"), CommonConstants.DATE_FORMAT));
        }
        if (rs.getDate("EMPLOYMENT_END_DATE") != null) {
            odsDO.setEmploymentEndDate(SILUtil.convertDateToString(rs.getDate("EMPLOYMENT_END_DATE"), CommonConstants.DATE_FORMAT));
        }

        if (rs.getDate("BALANCE_EFFECTIVE_DATE") != null) {
            odsDO.setBalanceEffectiveDate(SILUtil.convertDateToString(rs.getDate("BALANCE_EFFECTIVE_DATE"), CommonConstants.DATE_FORMAT));
        }
    }

    /**
     * This method fetches the data from sonata db via procedure call.
     * 
     * @param schemaName
     * 
     * @param string
     * @param string2
     * @param connection
     * @return
     */
    public List<OdsDO> executeProcGetMRRSchemeCategoryDetails(Map<String, String> inputParams, Connection connection) throws SILException {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, className, "Entering executeProcGetMRRSchemeCategoryDetails method");
        CallableStatement callableStatement = null;
        List<OdsDO> odsDOs = new ArrayList<OdsDO>();
        String getMRRSchemeCategoryDetailsProc = "{call SP_MRR_SCHEME_CATEGORY_DETAILS(?,?,?,?,?)}";
        try {
            callableStatement = connection.prepareCall(getMRRSchemeCategoryDetailsProc);
            callableStatement.registerOutParameter("RETVAL", OracleTypes.CURSOR);
            checkAndRetrieveResults(inputParams, callableStatement, odsDOs);
        } catch (SQLException sqlException) {
            handleSQLException(sqlException);
        } catch (Exception exception) {
            handleException(exception);
        } finally {
            closeCallableStatement(callableStatement);
        }
        return odsDOs;
    }

    /**
     * This method is used to retrieve results based on sc_code and sc_id.
     * 
     * @param inputParams
     * @param callableStatement
     * @param odsDOs
     * @throws SQLException
     * @throws SILException
     */
    private void checkAndRetrieveResults(Map<String, String> inputParams, CallableStatement callableStatement, List<OdsDO> odsDOs)
            throws SQLException, SILException {
        String sc_code = inputParams.get("scCodeFile");
        String id = inputParams.get("scIdSonata");
        if (id != null) {
            int sc_id = Integer.parseInt(id);
            retrieveResultSet(null, sc_id, 0, 0, callableStatement, odsDOs);
        }
        if (sc_code != null) {
            retrieveResultSet(sc_code, 0, 0, 0, callableStatement, odsDOs);
        }
    }

    /**
     * Does this.
     * 
     * @param inputParams
     * @param callableStatement
     * @param odsDOs
     * @return
     * @throws SQLException
     * @throws SILException
     */
    private void retrieveResultSet(String sc_code, Integer sc_id, Integer key3, Integer key4, CallableStatement callableStatement, List<OdsDO> odsDOs)
            throws SQLException, SILException {
        ResultSet rs = null;
        try {
            callableStatement.setString("sc_code", sc_code);
            callableStatement.setInt("sc_id", sc_id);
            callableStatement.setInt("sc_grp", key3);
            callableStatement.setInt("sc_rnk", key4);
            callableStatement.executeUpdate();
            rs = (ResultSet) callableStatement.getObject("RETVAL");
            while (rs.next()) {
                setMRRSchemeCategoryDetailsParams(odsDOs, rs);
            }
        } catch (SQLException sqlException) {
            handleSQLException(sqlException);
        } catch (Exception exception) {
            handleException(exception);
        } finally {
            closeResultSet(rs);
        }
    }

    /**
     * Does this.
     * 
     * @param odsDOs
     * @param rs
     * @param key
     * @throws SQLException
     */
    private void setMRRSchemeCategoryDetailsParams(List<OdsDO> odsDOs, ResultSet rs) throws SQLException {
        OdsDO odsDO = new OdsDO();
        odsDO.setSchemeCategoryCode(rs.getString("FILE_SC_CODE"));
        odsDO.setSchemeCategoryGroup(rs.getString("SC_GROUP"));
        odsDO.setSchemeCategoryId(rs.getString("FILE_SC_ID"));
        odsDO.setSchemeCategoryRank(rs.getString("SC_RANK"));
        odsDO.setSchemeCategoryShortName(rs.getString("FILE_SC_SHORT_NAME"));
        odsDO.setSchemeCategorySwitchFlag(rs.getString("SC_SWITCH_FLAG"));
        odsDO.setCodeIdentifier("");
        odsDOs.add(odsDO);
    }

    /**
     * This method fetches the data from sonata db via procedure call.
     * 
     * @param string
     * @param string2
     * @param connection
     * @return
     */
    public List<OdsDO> executeProcGetSpecialEmployerDetails(String employerNumber, String schemaName, Connection connection) throws SILException {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, className, "Entering executeProcGetMRRSchemeCategoryDetails method");
        CallableStatement callableStatement = null;
        ResultSet rs = null;
        List<OdsDO> odsDOs = new ArrayList<OdsDO>();
        String getSpecialEmployerDetailsProc = "{call SP_MRR_SPC_EMP_DETAILS(?,?)}";
        try {
            callableStatement = connection.prepareCall(getSpecialEmployerDetailsProc);
            callableStatement.registerOutParameter("RETVAL", OracleTypes.CURSOR);
            callableStatement.setString("EMPLR_ID", employerNumber);
            callableStatement.executeUpdate();
            rs = (ResultSet) callableStatement.getObject("RETVAL");
            while (rs.next()) {
                setSpecialEmployerDetailsParams(odsDOs, rs);
            }
        } catch (SQLException sqlException) {
            handleSQLException(sqlException);
        } catch (Exception exception) {
            handleException(exception);
        } finally {
            closeDBObjects(callableStatement, rs);
        }
        return odsDOs;
    }

    /**
     * Does this.
     * 
     * @param odsDOs
     * @param rs
     * @throws SQLException
     */
    private void setSpecialEmployerDetailsParams(List<OdsDO> odsDOs, ResultSet rs) throws SQLException {
        OdsDO odsDO = new OdsDO();
        odsDO.setEmployerNumber(rs.getString("EMPLOYER_NUM"));
        odsDO.setMrrOccupationCode(rs.getString("MRR_OCCUPATION_CODE"));
        odsDO.setMrrSchemeCategory(rs.getString("MRR_SCHEME_CATEGORY"));
        odsDO.setCreateSchemeCategoryCode(rs.getString("CREATE_SCHEME_CATEGORY_CODE"));
        odsDO.setCreateSchemeCategoryId(rs.getString("CREATE_SCHEME_CATEGORY_ID"));
        odsDO.setCreateOccupationCode(rs.getString("CREATE_OCCUPATION_CODE"));
        odsDO.setDefaultInsuranceFlag(rs.getString("DEFAULT_INSURANCE"));
        odsDO.setLifeBenefitLongName(rs.getString("LIFE_BENEFIT_LONGNAME"));
        odsDO.setLifeRider(rs.getString("LIFE_RIDER"));
        odsDO.setLifeRiderFactor(rs.getString("LIFE_RIDER_FACTOR"));
        odsDO.setTpdRider(rs.getString("TPD_RIDER"));
        odsDO.setTpdRiderFactor(rs.getString("TPD_RIDER_FACTOR"));
        odsDO.setIpRider(rs.getString("IP_RIDER"));
        odsDO.setIpRiderFactor(rs.getString("IP_RIDER_FACTOR"));
        odsDO.setWaitingPeriod(rs.getString("IP_WAITING_PERIOD"));
        odsDO.setBenefitPeriod(rs.getString("IP_BENEFIT_PERIOD"));
        retrieveRemainingSpecialEmployerDetails(rs, odsDO);
        odsDOs.add(odsDO);
    }

    /**
     * Does this.
     * 
     * @param rs
     * @param odsDO
     * @throws SQLException
     */
    private void retrieveRemainingSpecialEmployerDetails(ResultSet rs, OdsDO odsDO) throws SQLException {
        odsDO.setLoadingFull(rs.getString("NSLOADING_FUL"));
        odsDO.setLifeLoading(rs.getString("LIFE_LOADING"));
        odsDO.setLifeFull(rs.getString("LIFE_FUL"));
        odsDO.setTpdBenefitLongName(rs.getString("TPD_BENEFIT_LONGNAME"));
        odsDO.setTpdLoading(rs.getString("TPD_LOADING"));
        odsDO.setTpdFull(rs.getString("TPD_FUL"));
        odsDO.setIpBenefitLongName(rs.getString("IP_BENEFIT_LONGNAME"));
        odsDO.setIpLoading(rs.getString("IP_LOADING"));
        odsDO.setIpFull(rs.getString("IP_FUL"));
        odsDO.setIpWaitingPeriod(rs.getString("IP_WAITING_PERIOD"));
        odsDO.setIpBenefitPeriod(rs.getString("IP_BENEFIT_PERIOD"));
        odsDO.setLifeRiderUnits(rs.getString("LIFE_RIDER_UNITS"));
        odsDO.setTpdRiderUnits(rs.getString("TPD_RIDER_UNITS"));
        odsDO.setLifeSumInsured(rs.getString("LIFE_RIDER_SUMINSURED"));
        odsDO.setIpSumInsured(rs.getString("IP_RIDER_SUMINSURED"));
        odsDO.setTpdSumInsured(rs.getString("TPD_RIDER_SUMINSURED"));
        odsDO.setLifeRiderReviewId(rs.getString("LIFE_RIDER_REVIEWTERM_ID"));
        odsDO.setTpdRiderReviewId(rs.getString("TPD_RIDER_REVIEWTERM_ID"));
        odsDO.setIpRiderReviewId(rs.getString("IP_RIDER_REVIEWTERM_ID"));
    }

    /**
     * Does this.
     * 
     * @param inputParams
     * @param connection
     * @return
     * @throws SILException
     */
    public List<OdsDO> executeProcLookupDetailsForSchemeCategory(List<String> inputParams, Connection connection) throws SILException {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, className, "Entering executeProcGetMRRSchemeCategoryDetails method");
        CallableStatement callableStatement = null;
        ResultSet rs = null;
        List<OdsDO> odsDOs = new ArrayList<OdsDO>();
        String getMRRSchemeCategoryDetailsProc = "{call SP_MRR_SCHEME_CATEGORY_DETAILS(?,?,?,?,?)}";
        try {
            callableStatement = connection.prepareCall(getMRRSchemeCategoryDetailsProc);
            setCallableStatement(inputParams, callableStatement);
            String key = "lookupResult";
            callableStatement.executeUpdate();
            rs = (ResultSet) callableStatement.getObject("RETVAL");
            while (rs.next()) {
                setSchemeCategoryLookupDetailsParams(odsDOs, rs, key);
            }
        } catch (SQLException sqlException) {
            handleSQLException(sqlException);
        } catch (Exception exception) {
            handleException(exception);
        } finally {
            closeDBObjects(callableStatement, rs);
        }
        return odsDOs;
    }

    /**
     * This method is used to set CallableStatement.
     * 
     * @param inputParams
     * @param callableStatement
     * @throws SQLException
     */
    private void setCallableStatement(List<String> inputParams, CallableStatement callableStatement) throws SQLException {
        callableStatement.registerOutParameter("RETVAL", OracleTypes.CURSOR);
        callableStatement.setString("sc_code", null);
        callableStatement.setInt("sc_id", 0);
        callableStatement.setInt("sc_grp", Integer.parseInt(inputParams.get(0)));
        callableStatement.setInt("sc_rnk", Integer.parseInt(inputParams.get(1)));
    }

    /**
     * Does this.
     * 
     * @param odsDOs
     * @param rs
     * @param key
     * @param key
     * @throws SQLException
     */
    private void setSchemeCategoryLookupDetailsParams(List<OdsDO> odsDOs, ResultSet rs, String key) throws SQLException {
        OdsDO odsDO = new OdsDO();
        odsDO.setSchemeCategoryCode(rs.getString("FILE_SC_CODE"));
        odsDO.setSchemeCategoryGroup(rs.getString("SC_GROUP"));
        odsDO.setSchemeCategoryId(rs.getString("FILE_SC_ID"));
        odsDO.setSchemeCategoryRank(rs.getString("SC_RANK"));
        odsDO.setSchemeCategoryShortName(rs.getString("FILE_SC_SHORT_NAME"));
        odsDO.setSchemeCategorySwitchFlag(rs.getString("SC_SWITCH_FLAG"));
        odsDO.setCodeIdentifier(key);
        odsDOs.add(odsDO);
    }

    /**
     * Does this.
     * 
     * @param connection
     * @return
     * @throws SILException
     */
    public List<RolloverOdsDO> executeProcGetPendingInsuranceAccountList(Connection connection) throws SILException {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, className, "Entering executeProcGetPendingInsuranceAccountList method");
        CallableStatement callableStatement = null;
        ResultSet rs = null;
        List<RolloverOdsDO> rolloverOdsDO = new ArrayList<RolloverOdsDO>();
        String getGetPendingInsuranceAccountListProc = "{call SP_MRR_DEFAULT_INS_LIST(?)}";
        try {
            callableStatement = connection.prepareCall(getGetPendingInsuranceAccountListProc);
            callableStatement.registerOutParameter("RETVAL", OracleTypes.CURSOR);
            callableStatement.executeUpdate();
            rs = (ResultSet) callableStatement.getObject("RETVAL");
            while (rs.next()) {
                setPendingInsuranceAccountListParams(rolloverOdsDO, rs);
            }
        } catch (SQLException sqlException) {
            handleSQLException(sqlException);
        } catch (Exception exception) {
            handleException(exception);
        } finally {
            closeDBObjects(callableStatement, rs);
        }
        return rolloverOdsDO;
    }

    /**
     * Does this.
     * 
     * @param rolloverOdsDO
     * @param rs
     * @throws SQLException
     */
    private void setPendingInsuranceAccountListParams(List<RolloverOdsDO> rolloverOdsDOList, ResultSet rs) throws SQLException {
        RolloverOdsDO rolloverOdsDO = new RolloverOdsDO();
        rolloverOdsDO.setAccountNo(rs.getString("ACCOUNT_NUMBER"));
        rolloverOdsDOList.add(rolloverOdsDO);

    }

    /**
     * This method fetches the data from sonata db via procedure call.
     * 
     * @param string
     * @param string2
     * @param connection
     * @return
     */
    public List<OdsDO> executeProcGetEmployerDetailsFromDb(String employerAbn, String schemaName, Connection connection) throws SILException {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, className, "Entering executeProcGetMRRSchemeCategoryDetails method");
        CallableStatement callableStatement = null;
        ResultSet rs = null;
        List<OdsDO> odsDOs = new ArrayList<OdsDO>();
        String getEmployerDetailsFromLookupProc = "{call SP_MRR_GET_EMP_LOOKUP_DETAILS(?,?)}";
        try {
            callableStatement = connection.prepareCall(getEmployerDetailsFromLookupProc);
            callableStatement.registerOutParameter("RETVAL", OracleTypes.CURSOR);
            callableStatement.setString("EMP_ABN", employerAbn);
            callableStatement.executeUpdate();
            rs = (ResultSet) callableStatement.getObject("RETVAL");
            while (rs.next()) {
                setEmployerDetailsFromDbParams(odsDOs, rs);
            }
        } catch (SQLException sqlException) {
            handleSQLException(sqlException);
        } catch (Exception exception) {
            handleException(exception);
        } finally {
            closeDBObjects(callableStatement, rs);
        }
        return odsDOs;
    }

    /**
     * Does this.
     * 
     * @param rolloverOdsDO
     * @param rs
     * @throws SQLException
     */
    private void setEmployerDetailsFromDbParams(List<OdsDO> odsDOList, ResultSet rs) throws SQLException {
        OdsDO odsDo = new OdsDO();
        odsDo.setEmployerAbn(rs.getString("EMPLOYER_ABN"));
        odsDo.setEmployerNumber(rs.getString("EMPLOYER_NUMBER"));
        odsDo.setEmployerName(rs.getString("EMPLOYER_NAME"));
        odsDOList.add(odsDo);
    }
}
