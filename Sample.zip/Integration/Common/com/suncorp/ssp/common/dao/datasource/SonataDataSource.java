////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.common.dao.datasource;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import oracle.jdbc.OracleTypes;
import oracle.jdbc.pool.OracleDataSource;

import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;

/**
 * The class {@code SonataDataSource} does this.
 * 
 * @author U387938
 * @since 02/09/2016
 * @version 1.0
 */
public class SonataDataSource {
    private final String className = "SonataDataSource";

    /**
     * Sonata connection.
     * 
     * @param args
     * @throws SILException
     */
    public Connection getConnection(String url, String user, String pswd) throws SILException {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, className, "Entering getConnection method");
        Connection result = null;
        try {
            OracleDataSource dataSource = new OracleDataSource();
            dataSource.setURL(url);
            dataSource.setUser(user);
            dataSource.setPassword(pswd);
            result = dataSource.getConnection();
            SILLogger.debug(CommonConstants.LOGGING_FORMAT, className, "Entering getConnection method");
        } catch (SQLException sqlException) {
            SILLogger.error(CommonConstants.LOGGING_FORMAT, className, SILUtil.getReqExMsg(sqlException));
            throw new SILException(CommonConstants.SONATA_DB_CONNECTION_FAILED);
        } catch (Exception exception) {
            SILLogger.error(CommonConstants.LOGGING_FORMAT, className, SILUtil.getReqExMsg(exception));
            throw new SILException(CommonConstants.SONATA_DB_CONNECTION_FAILED);
        }
        return result;
    }

    /**
     * 
     * This method execute the sonata procedures.
     * 
     * @param query1
     * @param query2
     * @param empName
     * @param occupCode
     * @param categoryCode
     * @param connection
     * @return
     * @throws SILException
     */
    public List<SonataDO> executeProcs(String empName, String occupCode, String categoryCode, Connection connection, String schemaName)
            throws SILException {
        List<SonataDO> sonataDOs = new ArrayList<SonataDO>();
        List<SonataDO> sonataDOsFinal = new ArrayList<SonataDO>();
        try {
            if (connection != null) {
                sonataDOs = this.executeProc(connection, empName, categoryCode);
                if (sonataDOs != null && sonataDOs.size() > 0 && sonataDOs.get(0).getEpcbCategoryId().equalsIgnoreCase(CommonConstants.FAILED)) {
                    sonataDOsFinal.addAll(sonataDOs);
                } else {
                    sonataDOsFinal.addAll(executeSecondProc(sonataDOs, connection, occupCode));
                }
            }
        } catch (Exception exception) {
            SILLogger.error(CommonConstants.LOGGING_FORMAT, className, SILUtil.getReqExMsg(exception));
            throw new SILException(CommonConstants.SONATA_DB_TRANSACTION_FAILED);
        }
        return sonataDOsFinal;
    }

    /**
     * This method close db objects.
     * 
     * @param rs
     * @param st
     * @throws SILException
     */
    private void closeDBObjects(CallableStatement cs, ResultSet rs) {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, className, "Entering closeDBObjects method");
        if (cs != null) {
            try {
                cs.close();
            } catch (SQLException sqlException) {
                SILLogger.error(CommonConstants.LOGGING_FORMAT, className, SILUtil.getReqExMsg(sqlException));
            }
        }
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException sqlException) {
                SILLogger.error(CommonConstants.LOGGING_FORMAT, className, SILUtil.getReqExMsg(sqlException));
            }
        }
    }

    /**
     * 
     * This method fetches the data from sonata db via procedure call.
     * 
     * @param connection
     * @param inputParam
     * @param categoryCode
     * @return
     * @throws SILException
     */
    private List<SonataDO> executeProc(Connection connection, String inputParam, String categoryCode) throws SILException {
        CallableStatement callableStatement = null;
        ResultSet rs = null;
        List<SonataDO> sonataDOs = new ArrayList<SonataDO>();
        String getBenefitPlanProc = null;
        getBenefitPlanProc = formFirstProc();
        try {
            callableStatement = formFirstProc(connection, inputParam, getBenefitPlanProc);
            rs = (ResultSet) callableStatement.getObject("RETVAL");
            while (rs.next()) {
                setSonataDOParams(categoryCode, sonataDOs, rs);
            }
            if (sonataDOs != null && sonataDOs.size() == 0) {
                setSonataDODefault(sonataDOs, categoryCode);
            }
        } catch (SQLException sqlException) {
            handleSQLException(sqlException);
        } catch (Exception exception) {
            handleException(exception);
        } finally {
            closeDBObjects(callableStatement, rs);
        }
        return sonataDOs;
    }

    /**
     * This method prepares the callable statement.
     * 
     * @param connection
     * @param inputParam
     * @param getBenefitPlanProc
     * @return
     * @throws SQLException
     */
    private CallableStatement formFirstProc(Connection connection, String inputParam, String getBenefitPlanProc) throws SQLException {
        CallableStatement callableStatement;
        callableStatement = connection.prepareCall(getBenefitPlanProc);
        callableStatement.setString("EMP_NAME", inputParam);
        callableStatement.registerOutParameter("RETVAL", OracleTypes.CURSOR);
        callableStatement.executeUpdate();
        return callableStatement;
    }

    /**
     * This method forms the first procedure call statement.
     * 
     * @param schemaName
     * @return
     */
    private String formFirstProc() {
        String getBenefitPlanProc = null;

        getBenefitPlanProc = "{call get_benefit_plan1(?,?)}";
        return getBenefitPlanProc;
    }

    /**
     * 
     * This method fetches the data from sonata db via procedure call.
     * 
     * @param sonataDOs
     * @param connection
     * @param occupCode
     * @return
     * @throws SILException
     */
    private List<SonataDO> executeSecondProc(List<SonataDO> sonataDOs, Connection connection, String occupCode)
            throws SILException {
        CallableStatement callableStatement = null;
        ResultSet rs = null;
        String getBenefitPlanProc = null;
        getBenefitPlanProc = formSecondProc();
        try {
            for (SonataDO sonataDO : sonataDOs) {
                callableStatement = setCallableStatement(connection, getBenefitPlanProc, sonataDO);
                callableStatement.executeUpdate();
                rs = (ResultSet) callableStatement.getObject("RETVAL");
                checkOccupationCode(sonataDO, rs, occupCode);
            }
        } catch (SQLException sqlException) {
            handleSQLException(sqlException);
        } catch (Exception exception) {
            handleException(exception);
        } finally {
            closeDBObjects(callableStatement, rs);
        }
        return sonataDOs;
    }

    /**
     * This method forms the Second procedure call statement.
     * 
     * @param schemaName
     * @return
     */
    private String formSecondProc() {
        String getBenefitPlanProc = null;
        getBenefitPlanProc = "{call get_benefit_plan2(?,?)}";
        return getBenefitPlanProc;
    }

    /**
     * 
     * This methods sets the occupation code.
     * 
     * @param sonataDO
     * @param rs
     * @param occupCode
     * @throws SQLException
     */
    private void checkOccupationCode(SonataDO sonataDO, ResultSet rs, String occupCode) throws SQLException {
        while (rs.next()) {
            if (String.valueOf(rs.getString(CommonConstants.OCCP_CODE)).equalsIgnoreCase(occupCode)) {
                sonataDO.setOccupationFailedFlag("Y");
                break;
            } else {
                sonataDO.setOccupationFailedFlag("N");
            }
        }
    }

    /**
     * This methos handles Exception.
     * 
     * @param exception
     * @throws SILException
     */
    private void handleException(Exception exception) throws SILException {
        SILLogger.error(CommonConstants.LOGGING_FORMAT, className, exception.getMessage());
        throw new SILException(exception.getMessage());
    }

    /**
     * This methos handles SQLException.
     * 
     * @param sqlException
     * @throws SILException
     */
    private void handleSQLException(SQLException sqlException) throws SILException {
        SILLogger.error(CommonConstants.LOGGING_FORMAT, className, sqlException.getMessage());
        throw new SILException(sqlException.getMessage());
    }

    /**
     * This method prepares the callable statement.
     * 
     * @param connection
     * @param getBenefitPlanProc
     * @param sonataDO
     * @return
     * @throws SQLException
     */
    private CallableStatement setCallableStatement(Connection connection, String getBenefitPlanProc, SonataDO sonataDO) throws SQLException {
        CallableStatement callableStatement;
        callableStatement = connection.prepareCall(getBenefitPlanProc);
        callableStatement.setString("rdtp_id", sonataDO.getRdtpId());
        callableStatement.registerOutParameter("RETVAL", OracleTypes.CURSOR);
        return callableStatement;
    }

    /**
     * This method prepares the data object.
     * 
     * @param categoryCode
     * @param sonataDOs
     * @param rs
     * @throws SQLException
     */
    private void setSonataDOParams(String categoryCode, List<SonataDO> sonataDOs, ResultSet rs) throws SQLException {
        if (rs.getString(CommonConstants.CATG_CODE).equalsIgnoreCase(categoryCode) || checkCategoryCodes(rs, categoryCode)) {
            SonataDO sonataDO = new SonataDO();
            sonataDO.setRdtpId(String.valueOf(rs.getLong(CommonConstants.RDTP_ID)));
            sonataDO.setRdtpShortName(rs.getString(CommonConstants.RDTP_SHORT_NAME));
            sonataDO.setEpcbCategoryId(String.valueOf(rs.getLong(CommonConstants.EPCB_CATEGORY_ID)));
            sonataDO.setCategoryDefaulted("N");
            if (rs.getString(CommonConstants.CALC_BOOK) != null &&
                    rs.getString(CommonConstants.CALC_BOOK).toLowerCase().contains(CommonConstants.CHECKINSURANCE_SAL)) {
                sonataDO.setSalRequiredFlag("Y");
            } else {
                sonataDO.setSalRequiredFlag("N");
            }
            sonataDOs.add(sonataDO);
        }
    }

    /**
     * 
     * Set default Sonata DO.
     * 
     * @param sonataDOs
     */
    private void setSonataDODefault(List<SonataDO> sonataDOs, String categoryCode) {
        if (categoryCode.equalsIgnoreCase("AG15")) {
            SonataDO sonataDO = new SonataDO();
            sonataDO.setRdtpId("40000017");
            sonataDO.setEpcbCategoryId("40000001");
            sonataDO.setSalRequiredFlag("N");
            sonataDOs.add(sonataDO);
        } else if (categoryCode.equalsIgnoreCase("AL15")) {
            SonataDO sonataDO = new SonataDO();
            sonataDO.setRdtpId("40000017");
            sonataDO.setEpcbCategoryId("40000002");
            sonataDO.setSalRequiredFlag("N");
            sonataDOs.add(sonataDO);
        } else if (categoryCode.equalsIgnoreCase("ACAS")) {
            setDefaultCategoryForAcas(sonataDOs);
        } else {
            SonataDO sonataDO = new SonataDO();
            sonataDO.setEpcbCategoryId(CommonConstants.FAILED);
            sonataDOs.add(sonataDO);
        }
    }

    /**
     * Does this.
     *
     * @param sonataDOs
     */
    private void setDefaultCategoryForAcas(List<SonataDO> sonataDOs) {
        SonataDO sonataDO = new SonataDO();
        sonataDO.setRdtpId("40000017");
        sonataDO.setEpcbCategoryId("40000003");
        sonataDO.setSalRequiredFlag("N");
        sonataDOs.add(sonataDO);
        SonataDO sonataDO1 = new SonataDO();
        sonataDO1.setRdtpId("40000018");
        sonataDO1.setEpcbCategoryId("40000003");
        sonataDO1.setSalRequiredFlag("N");
        sonataDOs.add(sonataDO1);
    }
    
    /**
     * This method checks the category code for CT employer.
     *
     * @param sonataDOs
     * @throws SQLException 
     */
    private boolean checkCategoryCodes(ResultSet rs, String categoryCode) throws SQLException {
        if (categoryCode.equalsIgnoreCase("ACAS") && rs.getString(CommonConstants.CATG_CODE).equalsIgnoreCase("BCCT")) {
            return true;
        } else if (categoryCode.equalsIgnoreCase("AL15") && rs.getString(CommonConstants.CATG_CODE).equalsIgnoreCase("L15C")) {
            return true;
        } else if (categoryCode.equalsIgnoreCase("AG15") && rs.getString(CommonConstants.CATG_CODE).equalsIgnoreCase("BPCT")) {
            return true;
        }
        return false;
        
    }

}
