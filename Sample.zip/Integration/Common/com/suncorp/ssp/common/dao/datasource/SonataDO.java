////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.common.dao.datasource;

import java.util.ArrayList;
import java.util.List;

/**
 * The class {@code OdsDO} does this.
 * 
 * @author U387938
 * @since 16/09/2016
 * @version 1.0
 */
public class SonataDO {

    private List<String> resultParams;
    private String rdtpId;
    private String rdtpShortName;
    private String salRequiredFlag;
    private String calcBook;
    private String categoryDefaulted;
    private String occupationFailedFlag;
    private String epcbCategoryId;

    /**
     * Accessor for property resultParams.
     * 
     * @return resultParams of type List<String>
     */
    public List<String> getResultParams() {
        if (resultParams == null) {
            resultParams = new ArrayList<String>();
        }
        return resultParams;
    }

    /**
     * Mutator for property resultParams.
     * 
     * @param resultParams of type List<String>
     */
    public void setResultParams(List<String> resultParams) {
        this.resultParams = resultParams;
    }

    /**
     * Accessor for property rdtpId.
     * 
     * @return rdtpId of type String
     */
    public String getRdtpId() {
        return rdtpId;
    }

    /**
     * Mutator for property rdtpId.
     * 
     * @param rdtpId of type String
     */
    public void setRdtpId(String rdtpId) {
        this.rdtpId = rdtpId;
    }

    /**
     * Accessor for property rdtpShortName.
     * 
     * @return rdtpShortName of type String
     */
    public String getRdtpShortName() {
        return rdtpShortName;
    }

    /**
     * Mutator for property rdtpShortName.
     * 
     * @param rdtpShortName of type String
     */
    public void setRdtpShortName(String rdtpShortName) {
        this.rdtpShortName = rdtpShortName;
    }

    /**
     * Accessor for property salRequiredFlag.
     *
     * @return salRequiredFlag of type String
     */
    public String getSalRequiredFlag() {
        return salRequiredFlag;
    }

    /**
     * Mutator for property salRequiredFlag.
     *
     * @param salRequiredFlag of type String
     */
    public void setSalRequiredFlag(String salRequiredFlag) {
        this.salRequiredFlag = salRequiredFlag;
    }

    /**
     * Accessor for property calcBook.
     *
     * @return calcBook of type String
     */
    public String getCalcBook() {
        return calcBook;
    }

    /**
     * Mutator for property calcBook.
     *
     * @param calcBook of type String
     */
    public void setCalcBook(String calcBook) {
        this.calcBook = calcBook;
    }

    /**
     * Accessor for property categoryDefaulted.
     *
     * @return categoryDefaulted of type String
     */
    public String getCategoryDefaulted() {
        return categoryDefaulted;
    }

    /**
     * Mutator for property categoryDefaulted.
     *
     * @param categoryDefaulted of type String
     */
    public void setCategoryDefaulted(String categoryDefaulted) {
        this.categoryDefaulted = categoryDefaulted;
    }

    /**
     * Accessor for property occupationFailedFlag.
     *
     * @return occupationFailedFlag of type String
     */
    public String getOccupationFailedFlag() {
        return occupationFailedFlag;
    }

    /**
     * Mutator for property occupationFailedFlag.
     *
     * @param occupationFailedFlag of type String
     */
    public void setOccupationFailedFlag(String occupationFailedFlag) {
        this.occupationFailedFlag = occupationFailedFlag;
    }

    /**
     * Accessor for property epcbCategoryId.
     *
     * @return epcbCategoryId of type String
     */
    public String getEpcbCategoryId() {
        return epcbCategoryId;
    }

    /**
     * Mutator for property epcbCategoryId.
     *
     * @param epcbCategoryId of type String
     */
    public void setEpcbCategoryId(String epcbCategoryId) {
        this.epcbCategoryId = epcbCategoryId;
    }

    

}
