////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.common.dao.datasource;

/**
 * The class {@code OdsDO} is a JAVA bean.
 * 
 * @author U387938
 * @since 16/09/2016
 * @version 1.0
 */
public class OdsDO extends RolloverOdsDO {

    private String advisorClientId;
    private String memberClientId;
    private String memberName;
    private String memberAccountId;
    private String memberAccountNumber;
    private String productName;
    private String lastUpdated;
    private String termsAndConditionValue;
    private String memberFirstName;
    private String advisorFirstName;
    private String advisorName;
    private String commenceDate;
    private String accountStatus;
    private String insuranceDesc;
    private String effectiveDate;
    private String memberLastName;
    private String memberDateOfBirth;

    // Adding for Advisor report;
    private String employerReference;
    private String employerId;
    private String employerName;
    private String memberSurname;
    private String memberGivenName;
    private String address;
    private String suburb;
    private String state;
    private String postCode;
    private String addressType;
    private String homePhone;
    private String workPhone;
    private String mobileNumber;
    private String email;
    private String gender;
    private String dob;
    private String anb;
    private String salary;
    private String tfn;
    private String smoker;
    private String beneficiaryNominatedDate;
    private String bindingNominationType;
    private String product;
    private String fundStartDate;
    private String fundEndDate;
    private String employmentStartDate;
    private String employmentEndDate;
    private String currentAccountBalance;
    private String balanceEffectiveDate;
    private String lifeStageFlag;
    private String coverType;
    private String lifeSumInsured;
    private String ipSumInsured;
    private String tpdSumInsured;
    private String lifeMonthlyPremium;
    private String ipMonthlyPremium;
    private String tpdMonthlyPremium;
    private String beneficiaryType;

    private String codeIdentifier;
    private String employerNumber;
    private String createSchemeCategoryId;

    /**
     * Accessor for property advisorClientId.
     * 
     * @return advisorClientId of type String
     */
    public String getAdvisorClientId() {
        return advisorClientId;
    }

    /**
     * Mutator for property advisorClientId.
     * 
     * @param advisorClientId of type String
     */
    public void setAdvisorClientId(String advisorClientId) {
        this.advisorClientId = advisorClientId;
    }

    /**
     * Accessor for property memberClientId.
     * 
     * @return memberClientId of type String
     */
    public String getMemberClientId() {
        return memberClientId;
    }

    /**
     * Mutator for property memberClientId.
     * 
     * @param memberClientId of type String
     */
    public void setMemberClientId(String memberClientId) {
        this.memberClientId = memberClientId;
    }

    /**
     * Accessor for property memberName.
     * 
     * @return memberName of type String
     */
    public String getMemberName() {
        return memberName;
    }

    /**
     * Mutator for property memberName.
     * 
     * @param memberName of type String
     */
    public void setMemberName(String memberName) {
        this.memberName = memberName;
    }

    /**
     * Accessor for property memberAccountId.
     * 
     * @return memberAccountId of type String
     */
    public String getMemberAccountId() {
        return memberAccountId;
    }

    /**
     * Mutator for property memberAccountId.
     * 
     * @param memberAccountId of type String
     */
    public void setMemberAccountId(String memberAccountId) {
        this.memberAccountId = memberAccountId;
    }

    /**
     * Accessor for property memberAccountNumber.
     * 
     * @return memberAccountNumber of type String
     */
    public String getMemberAccountNumber() {
        return memberAccountNumber;
    }

    /**
     * Mutator for property memberAccountNumber.
     * 
     * @param memberAccountNumber of type String
     */
    public void setMemberAccountNumber(String memberAccountNumber) {
        this.memberAccountNumber = memberAccountNumber;
    }

    /**
     * Accessor for property productName.
     * 
     * @return productName of type String
     */
    public String getProductName() {
        return productName;
    }

    /**
     * Mutator for property productName.
     * 
     * @param productName of type String
     */
    public void setProductName(String productName) {
        this.productName = productName;
    }

    /**
     * Accessor for property lastUpdated.
     * 
     * @return lastUpdated of type String
     */
    public String getLastUpdated() {
        return lastUpdated;
    }

    /**
     * Mutator for property lastUpdated.
     * 
     * @param lastUpdated of type String
     */
    public void setLastUpdated(String lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    /**
     * Accessor for property termsAndConditionValue.
     * 
     * @return termsAndConditionValue of type String
     */
    public String getTermsAndConditionValue() {
        return termsAndConditionValue;
    }

    /**
     * Mutator for property termsAndConditionValue.
     * 
     * @param termsAndConditionValue of type String
     */
    public void setTermsAndConditionValue(String termsAndConditionValue) {
        this.termsAndConditionValue = termsAndConditionValue;
    }

    /**
     * Accessor for property memberFirstName.
     * 
     * @return memberFirstName of type String
     */
    public String getMemberFirstName() {
        return memberFirstName;
    }

    /**
     * Mutator for property memberFirstName.
     * 
     * @param memberFirstName of type String
     */
    public void setMemberFirstName(String memberFirstName) {
        this.memberFirstName = memberFirstName;
    }

    /**
     * Accessor for property advisorFirstName.
     * 
     * @return advisorFirstName of type String
     */
    public String getAdvisorFirstName() {
        return advisorFirstName;
    }

    /**
     * Mutator for property advisorFirstName.
     * 
     * @param advisorFirstName of type String
     */
    public void setAdvisorFirstName(String advisorFirstName) {
        this.advisorFirstName = advisorFirstName;
    }

    /**
     * Accessor for property advisorName.
     * 
     * @return advisorName of type String
     */
    public String getAdvisorName() {
        return advisorName;
    }

    /**
     * Mutator for property advisorName.
     * 
     * @param advisorName of type String
     */
    public void setAdvisorName(String advisorName) {
        this.advisorName = advisorName;
    }

    /**
     * Accessor for property commenceDate.
     * 
     * @return commenceDate of type String
     */
    public String getCommenceDate() {
        return commenceDate;
    }

    /**
     * Mutator for property commenceDate.
     * 
     * @param commenceDate of type String
     */
    public void setCommenceDate(String commenceDate) {
        this.commenceDate = commenceDate;
    }

    /**
     * Accessor for property accountStatus.
     * 
     * @return accountStatus of type String
     */
    public String getAccountStatus() {
        return accountStatus;
    }

    /**
     * Mutator for property accountStatus.
     * 
     * @param accountStatus of type String
     */
    public void setAccountStatus(String accountStatus) {
        this.accountStatus = accountStatus;
    }

    /**
     * Accessor for property insuranceDesc.
     * 
     * @return insuranceDesc of type String
     */
    public String getInsuranceDesc() {
        return insuranceDesc;
    }

    /**
     * Mutator for property insuranceDesc.
     * 
     * @param insuranceDesc of type String
     */
    public void setInsuranceDesc(String insuranceDesc) {
        this.insuranceDesc = insuranceDesc;
    }

    /**
     * Accessor for property effectiveDate.
     * 
     * @return effectiveDate of type String
     */
    public String getEffectiveDate() {
        return effectiveDate;
    }

    /**
     * Mutator for property effectiveDate.
     * 
     * @param effectiveDate of type String
     */
    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    /**
     * Accessor for property memberLastName.
     * 
     * @return memberLastName of type String
     */
    public String getMemberLastName() {
        return memberLastName;
    }

    /**
     * Mutator for property memberLastName.
     * 
     * @param memberLastName of type String
     */
    public void setMemberLastName(String memberLastName) {
        this.memberLastName = memberLastName;
    }

    /**
     * Accessor for property memberDateOfBirth.
     * 
     * @return memberDateOfBirth of type String
     */
    public String getMemberDateOfBirth() {
        return memberDateOfBirth;
    }

    /**
     * Mutator for property memberDateOfBirth.
     * 
     * @param memberDateOfBirth of type String
     */
    public void setMemberDateOfBirth(String memberDateOfBirth) {
        this.memberDateOfBirth = memberDateOfBirth;
    }

    /**
     * Accessor for property employerReference.
     * 
     * @return employerReference of type String
     */
    public String getEmployerReference() {
        return employerReference;
    }

    /**
     * Mutator for property employerReference.
     * 
     * @param employerReference of type String
     */
    public void setEmployerReference(String employerReference) {
        this.employerReference = employerReference;
    }

    /**
     * Accessor for property employerId.
     * 
     * @return employerId of type String
     */
    public String getEmployerId() {
        return employerId;
    }

    /**
     * Mutator for property employerId.
     * 
     * @param employerId of type String
     */
    public void setEmployerId(String employerId) {
        this.employerId = employerId;
    }

    /**
     * Accessor for property memberSurname.
     * 
     * @return memberSurname of type String
     */
    public String getMemberSurname() {
        return memberSurname;
    }

    /**
     * Mutator for property memberSurname.
     * 
     * @param memberSurname of type String
     */
    public void setMemberSurname(String memberSurname) {
        this.memberSurname = memberSurname;
    }

    /**
     * Accessor for property memberGivenName.
     * 
     * @return memberGivenName of type String
     */
    public String getMemberGivenName() {
        return memberGivenName;
    }

    /**
     * Mutator for property memberGivenName.
     * 
     * @param memberGivenName of type String
     */
    public void setMemberGivenName(String memberGivenName) {
        this.memberGivenName = memberGivenName;
    }

    /**
     * Accessor for property address.
     * 
     * @return address of type String
     */
    public String getAddress() {
        return address;
    }

    /**
     * Mutator for property address.
     * 
     * @param address of type String
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * Accessor for property suburb.
     * 
     * @return suburb of type String
     */
    public String getSuburb() {
        return suburb;
    }

    /**
     * Mutator for property suburb.
     * 
     * @param suburb of type String
     */
    public void setSuburb(String suburb) {
        this.suburb = suburb;
    }

    /**
     * Accessor for property state.
     * 
     * @return state of type String
     */
    public String getState() {
        return state;
    }

    /**
     * Mutator for property state.
     * 
     * @param state of type String
     */
    public void setState(String state) {
        this.state = state;
    }

    /**
     * Accessor for property postCode.
     * 
     * @return postCode of type String
     */
    public String getPostCode() {
        return postCode;
    }

    /**
     * Mutator for property postCode.
     * 
     * @param postCode of type String
     */
    public void setPostCode(String postCode) {
        this.postCode = postCode;
    }

    /**
     * Accessor for property addressType.
     * 
     * @return addressType of type String
     */
    public String getAddressType() {
        return addressType;
    }

    /**
     * Mutator for property addressType.
     * 
     * @param addressType of type String
     */
    public void setAddressType(String addressType) {
        this.addressType = addressType;
    }

    /**
     * Accessor for property homePhone.
     * 
     * @return homePhone of type String
     */
    public String getHomePhone() {
        return homePhone;
    }

    /**
     * Mutator for property homePhone.
     * 
     * @param homePhone of type String
     */
    public void setHomePhone(String homePhone) {
        this.homePhone = homePhone;
    }

    /**
     * Accessor for property workPhone.
     * 
     * @return workPhone of type String
     */
    public String getWorkPhone() {
        return workPhone;
    }

    /**
     * Mutator for property workPhone.
     * 
     * @param workPhone of type String
     */
    public void setWorkPhone(String workPhone) {
        this.workPhone = workPhone;
    }

    /**
     * Accessor for property mobileNumber.
     * 
     * @return mobileNumber of type String
     */
    public String getMobileNumber() {
        return mobileNumber;
    }

    /**
     * Mutator for property mobileNumber.
     * 
     * @param mobileNumber of type String
     */
    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    /**
     * Accessor for property email.
     * 
     * @return email of type String
     */
    public String getEmail() {
        return email;
    }

    /**
     * Mutator for property email.
     * 
     * @param email of type String
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Accessor for property gender.
     * 
     * @return gender of type String
     */
    public String getGender() {
        return gender;
    }

    /**
     * Mutator for property gender.
     * 
     * @param gender of type String
     */
    public void setGender(String gender) {
        this.gender = gender;
    }

    /**
     * Accessor for property dob.
     * 
     * @return dob of type String
     */
    public String getDob() {
        return dob;
    }

    /**
     * Mutator for property dob.
     * 
     * @param dob of type String
     */
    public void setDob(String dob) {
        this.dob = dob;
    }

    /**
     * Accessor for property anb.
     * 
     * @return anb of type String
     */
    public String getAnb() {
        return anb;
    }

    /**
     * Mutator for property anb.
     * 
     * @param anb of type String
     */
    public void setAnb(String anb) {
        this.anb = anb;
    }

    /**
     * Accessor for property salary.
     * 
     * @return salary of type String
     */
    public String getSalary() {
        return salary;
    }

    /**
     * Mutator for property salary.
     * 
     * @param salary of type String
     */
    public void setSalary(String salary) {
        this.salary = salary;
    }

    /**
     * Accessor for property tfn.
     * 
     * @return tfn of type String
     */
    public String getTfn() {
        return tfn;
    }

    /**
     * Mutator for property tfn.
     * 
     * @param tfn of type String
     */
    public void setTfn(String tfn) {
        this.tfn = tfn;
    }

    /**
     * Accessor for property smoker.
     * 
     * @return smoker of type String
     */
    public String getSmoker() {
        return smoker;
    }

    /**
     * Mutator for property smoker.
     * 
     * @param smoker of type String
     */
    public void setSmoker(String smoker) {
        this.smoker = smoker;
    }

    /**
     * Accessor for property beneficiaryNominatedDate.
     * 
     * @return beneficiaryNominatedDate of type String
     */
    public String getBeneficiaryNominatedDate() {
        return beneficiaryNominatedDate;
    }

    /**
     * Mutator for property beneficiaryNominatedDate.
     * 
     * @param beneficiaryNominatedDate of type String
     */
    public void setBeneficiaryNominatedDate(String beneficiaryNominatedDate) {
        this.beneficiaryNominatedDate = beneficiaryNominatedDate;
    }

    /**
     * Accessor for property bindingNominationType.
     * 
     * @return bindingNominationType of type String
     */
    public String getBindingNominationType() {
        return bindingNominationType;
    }

    /**
     * Mutator for property bindingNominationType.
     * 
     * @param bindingNominationType of type String
     */
    public void setBindingNominationType(String bindingNominationType) {
        this.bindingNominationType = bindingNominationType;
    }

    /**
     * Accessor for property product.
     * 
     * @return product of type String
     */
    public String getProduct() {
        return product;
    }

    /**
     * Mutator for property product.
     * 
     * @param product of type String
     */
    public void setProduct(String product) {
        this.product = product;
    }

    /**
     * Accessor for property fundStartDate.
     * 
     * @return fundStartDate of type String
     */
    public String getFundStartDate() {
        return fundStartDate;
    }

    /**
     * Mutator for property fundStartDate.
     * 
     * @param fundStartDate of type String
     */
    public void setFundStartDate(String fundStartDate) {
        this.fundStartDate = fundStartDate;
    }

    /**
     * Accessor for property fundEndDate.
     * 
     * @return fundEndDate of type String
     */
    public String getFundEndDate() {
        return fundEndDate;
    }

    /**
     * Mutator for property fundEndDate.
     * 
     * @param fundEndDate of type String
     */
    public void setFundEndDate(String fundEndDate) {
        this.fundEndDate = fundEndDate;
    }

    /**
     * Accessor for property employmentStartDate.
     * 
     * @return employmentStartDate of type String
     */
    public String getEmploymentStartDate() {
        return employmentStartDate;
    }

    /**
     * Mutator for property employmentStartDate.
     * 
     * @param employmentStartDate of type String
     */
    public void setEmploymentStartDate(String employmentStartDate) {
        this.employmentStartDate = employmentStartDate;
    }

    /**
     * Accessor for property employmentEndDate.
     * 
     * @return employmentEndDate of type String
     */
    public String getEmploymentEndDate() {
        return employmentEndDate;
    }

    /**
     * Mutator for property employmentEndDate.
     * 
     * @param employmentEndDate of type String
     */
    public void setEmploymentEndDate(String employmentEndDate) {
        this.employmentEndDate = employmentEndDate;
    }

    /**
     * Accessor for property currentAccountBalance.
     * 
     * @return currentAccountBalance of type String
     */
    public String getCurrentAccountBalance() {
        return currentAccountBalance;
    }

    /**
     * Mutator for property currentAccountBalance.
     * 
     * @param currentAccountBalance of type String
     */
    public void setCurrentAccountBalance(String currentAccountBalance) {
        this.currentAccountBalance = currentAccountBalance;
    }

    /**
     * Accessor for property balanceEffectiveDate.
     * 
     * @return balanceEffectiveDate of type String
     */
    public String getBalanceEffectiveDate() {
        return balanceEffectiveDate;
    }

    /**
     * Mutator for property balanceEffectiveDate.
     * 
     * @param balanceEffectiveDate of type String
     */
    public void setBalanceEffectiveDate(String balanceEffectiveDate) {
        this.balanceEffectiveDate = balanceEffectiveDate;
    }

    /**
     * Accessor for property lifeStageFlag.
     * 
     * @return lifeStageFlag of type String
     */
    public String getLifeStageFlag() {
        return lifeStageFlag;
    }

    /**
     * Mutator for property lifeStageFlag.
     * 
     * @param lifeStageFlag of type String
     */
    public void setLifeStageFlag(String lifeStageFlag) {
        this.lifeStageFlag = lifeStageFlag;
    }

    /**
     * Accessor for property coverType.
     * 
     * @return coverType of type String
     */
    public String getCoverType() {
        return coverType;
    }

    /**
     * Mutator for property coverType.
     * 
     * @param coverType of type String
     */
    public void setCoverType(String coverType) {
        this.coverType = coverType;
    }

    /**
     * Accessor for property employerName.
     * 
     * @return employerName of type String
     */
    public String getEmployerName() {
        return employerName;
    }

    /**
     * Mutator for property employerName.
     * 
     * @param employerName of type String
     */
    public void setEmployerName(String employerName) {
        this.employerName = employerName;
    }

    /**
     * Accessor for property beneficiaryType.
     * 
     * @return beneficiaryType of type String
     */
    public String getBeneficiaryType() {
        return beneficiaryType;
    }

    /**
     * Mutator for property beneficiaryType.
     * 
     * @param beneficiaryType of type String
     */
    public void setBeneficiaryType(String beneficiaryType) {
        this.beneficiaryType = beneficiaryType;
    }

    /**
     * Accessor for property lifeSumInsured.
     * 
     * @return lifeSumInsured of type String
     */
    public String getLifeSumInsured() {
        return lifeSumInsured;
    }

    /**
     * Mutator for property lifeSumInsured.
     * 
     * @param lifeSumInsured of type String
     */
    public void setLifeSumInsured(String lifeSumInsured) {
        this.lifeSumInsured = lifeSumInsured;
    }

    /**
     * Accessor for property ipSumInsured.
     * 
     * @return ipSumInsured of type String
     */
    public String getIpSumInsured() {
        return ipSumInsured;
    }

    /**
     * Mutator for property ipSumInsured.
     * 
     * @param ipSumInsured of type String
     */
    public void setIpSumInsured(String ipSumInsured) {
        this.ipSumInsured = ipSumInsured;
    }

    /**
     * Accessor for property tpdSumInsured.
     * 
     * @return tpdSumInsured of type String
     */
    public String getTpdSumInsured() {
        return tpdSumInsured;
    }

    /**
     * Mutator for property tpdSumInsured.
     * 
     * @param tpdSumInsured of type String
     */
    public void setTpdSumInsured(String tpdSumInsured) {
        this.tpdSumInsured = tpdSumInsured;
    }

    /**
     * Accessor for property lifeMonthlyPremium.
     * 
     * @return lifeMonthlyPremium of type String
     */
    public String getLifeMonthlyPremium() {
        return lifeMonthlyPremium;
    }

    /**
     * Mutator for property lifeMonthlyPremium.
     * 
     * @param lifeMonthlyPremium of type String
     */
    public void setLifeMonthlyPremium(String lifeMonthlyPremium) {
        this.lifeMonthlyPremium = lifeMonthlyPremium;
    }

    /**
     * Accessor for property ipMonthlyPremium.
     * 
     * @return ipMonthlyPremium of type String
     */
    public String getIpMonthlyPremium() {
        return ipMonthlyPremium;
    }

    /**
     * Mutator for property ipMonthlyPremium.
     * 
     * @param ipMonthlyPremium of type String
     */
    public void setIpMonthlyPremium(String ipMonthlyPremium) {
        this.ipMonthlyPremium = ipMonthlyPremium;
    }

    /**
     * Accessor for property tpdMonthlyPremium.
     * 
     * @return tpdMonthlyPremium of type String
     */
    public String getTpdMonthlyPremium() {
        return tpdMonthlyPremium;
    }

    /**
     * Mutator for property tpdMonthlyPremium.
     * 
     * @param tpdMonthlyPremium of type String
     */
    public void setTpdMonthlyPremium(String tpdMonthlyPremium) {
        this.tpdMonthlyPremium = tpdMonthlyPremium;
    }

    /**
     * Accessor for property codeIdentifier.
     * 
     * @return codeIdentifier of type String
     */
    public String getCodeIdentifier() {
        return codeIdentifier;
    }

    /**
     * Mutator for property codeIdentifier.
     * 
     * @param codeIdentifier of type String
     */
    public void setCodeIdentifier(String codeIdentifier) {
        this.codeIdentifier = codeIdentifier;
    }

    /**
     * Accessor for property employerNumber.
     * 
     * @return employerNumber of type String
     */
    public String getEmployerNumber() {
        return employerNumber;
    }

    /**
     * Mutator for property employerNumber.
     * 
     * @param employerNumber of type String
     */
    public void setEmployerNumber(String employerNumber) {
        this.employerNumber = employerNumber;
    }

    /**
     * Accessor for property createSchemeCategoryId.
     * 
     * @return createSchemeCategoryId of type String
     */
    public String getCreateSchemeCategoryId() {
        return createSchemeCategoryId;
    }

    /**
     * Mutator for property createSchemeCategoryId.
     * 
     * @param createSchemeCategoryId of type String
     */
    public void setCreateSchemeCategoryId(String createSchemeCategoryId) {
        this.createSchemeCategoryId = createSchemeCategoryId;
    }
}
