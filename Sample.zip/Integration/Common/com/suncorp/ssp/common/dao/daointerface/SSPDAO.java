////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.common.dao.daointerface;

import java.util.List;

import com.suncorp.ssp.common.exception.SILException;

/**
 * The class {@code SSPDAO} does this.
 * 
 * @author U387938
 * @since 02/09/2016
 * @version 1.0
 */
public interface SSPDAO {

    List getDetails(List<String> queryParam, String url, String user, String password) throws SILException;

}
