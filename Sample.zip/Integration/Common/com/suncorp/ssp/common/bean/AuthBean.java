////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.common.bean;

import org.apache.camel.Exchange;

import com.suncorp.ssp.common.constants.CommonConstants;

/**
 * The class {@code AuthBean} is used as a Auth bean.
 * 
 * @author U383754
 * @since 26/09/2016
 * @version 1.0
 */
public class AuthBean {
    private String uname;
    private String pwd;

    /**
     * Accessor for property uname.
     * 
     * @return uname of type String
     */
    public String getUname() {
        return uname;
    }

    /**
     * Mutator for property uname.
     * 
     * @return uname of type String
     */
    public void setUname(String uname) {
        this.uname = uname;
    }

    /**
     * Accessor for property pwd.
     * 
     * @return pwd of type String
     */
    public String getPwd() {
        return pwd;
    }

    /**
     * Mutator for property pwd.
     * 
     * @return pwd of type String
     */
    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    /**
     * This method is used to set Auth.
     * 
     * @param exchange
     */
    public void setAuth(Exchange exchange) {
        String authenticationString = this.uname + ":" + this.pwd;
        String authenticationHeaderValue = "Basic " + javax.xml.bind.DatatypeConverter.printBase64Binary(authenticationString.getBytes());
        exchange.setProperty(CommonConstants.AUTH_VALUE, authenticationHeaderValue);
    }
}
