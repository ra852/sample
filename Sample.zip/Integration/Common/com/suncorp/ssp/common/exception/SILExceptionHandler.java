////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package com.suncorp.ssp.common.exception;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import javax.ws.rs.core.Response;

import org.apache.camel.Exchange;

import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.rolloverservice.RolloverConstants;

/**
 * The class {@code SILValidationExceptionHandler} handles the validation exceptions raised inside the SIL.
 * 
 * @author u384380
 * @since 2015-10-01
 * @version 1.0
 */
public class SILExceptionHandler {
    private final String className = "SILExceptionHandler";

    /**
     * Handles the Validation exception raised in the SIL, logs it and returns the error message.
     * 
     * @param exchange of type Exchange
     * @throws SILException
     */
    public void transform(Exchange exchange) throws SILException {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, className, "Entering in transform method");
        try {
            Object object = this.setErrorMessage(exchange);
            exchange.getIn().removeHeader(CommonConstants.RESPONSE_CLASS_NAME);
            Response response = createResponse(exchange, object);
            exchange.getIn().setBody(response);
            SILLogger.debug(CommonConstants.LOGGING_FORMAT, className, "Exiting from transform method");
        } catch (Exception exe) {
            SILLogger.error(CommonConstants.LOGGING_FORMAT, className, exe.getMessage());
            throw new SILException("Exception occur in exception handler :: " + exe.getMessage());
        }
    }

    /**
     * This method is used to set error message in dynamically instantiated response class.
     * 
     * @param exchange
     * @return
     */
    private Object setErrorMessage(Exchange exchange) {
        String errorMessage = exchange.getIn().getHeader(CommonConstants.EXCEPTION_MESSAGE, String.class);
        exchange.getIn().removeHeader(CommonConstants.EXCEPTION_MESSAGE);
        exchange.setProperty(RolloverConstants.CREATE_MRR_ERROR_CSV, (String) exchange.getProperty(RolloverConstants.CREATE_MRR_ERROR_CSV) +
                className + " - " + errorMessage + ";");
        Object object = null;
        if (exchange.getProperty(CommonConstants.RESPONSE_CLASS_NAME) != null) {
            try {
                Class<?> responseClassDefinination = Class.forName((String) exchange.getProperty(CommonConstants.RESPONSE_CLASS_NAME));
                object = responseClassDefinination.newInstance();
                Method method = object.getClass().getMethod(CommonConstants.ERROR_MESSAGE_METHOD_NAME, java.lang.String.class);
                method.invoke(object, errorMessage);
            } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | NoSuchMethodException | SecurityException |
                    IllegalArgumentException | InvocationTargetException e) {
                SILLogger.error(CommonConstants.LOGGING_FORMAT, className, "Exception occur in exception handler.");
                object = null;
            }
        } else {
            SILLogger.error(CommonConstants.LOGGING_FORMAT, className, "Exception : Response class is not added in common constant file");
            object = null;
        }
        return object;
    }

    /**
     * Create Response object
     * 
     * @param exchange of type Exchange
     * @param object of type Object
     */
    private Response createResponse(Exchange exchange, Object object) {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, className, "Entering in createResponse method");
        Response response = null;
        if (exchange.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE) != null) {

            int httpResponseCode = (int) exchange.getIn().getHeader(Exchange.HTTP_RESPONSE_CODE);

            if (httpResponseCode == CommonConstants.HTTP_BAD_REQUEST_CODE) {
                response = Response.status(Response.Status.BAD_REQUEST).entity(object).build();
            } else if (httpResponseCode == CommonConstants.HTTP_SUCCESS_REQUEST_CODE) {
                response = Response.status(Response.Status.OK).entity(object).build();
            } else {
                response = Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(object).build();
            }
        } else {
            response = Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity(object).build();
        }
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, className, "Exiting from createResponse method");
        return response;
    }
}
