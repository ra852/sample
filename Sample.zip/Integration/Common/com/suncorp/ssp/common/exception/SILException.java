////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.common.exception;

/**
 * The class {@code SILException} handles the exceptions raised inside the SIL.
 * 
 * @author U383754
 * @since 2015-10-01
 * @version 1.0
 */
public class SILException extends Exception {
    private static final long serialVersionUID = 1L;

    /**
     * Default constructor.
     */
    public SILException() {
        super();
    }

    /**
     * Parameterised constructor.
     * 
     * @param message
     *            of type String
     */
    public SILException(String message) {
        super(message);
    }

    /**
     * Parameterised constructor.
     * 
     * @param cause
     *            of type Throwable
     */
    public SILException(Throwable cause) {
        super(cause);
    }

    /**
     * Parameterised constructor.
     * 
     * @param message
     *            of type String
     * @param cause
     *            of type Throwable
     */
    public SILException(String messge, Throwable cause) {
        super(messge, cause);
    }
}
