////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.common.constants;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * The interface {@code CommonConstants} holds all the common constants.
 * 
 * @author U383754
 * @since 2015-10-01
 * @version 1.0
 * 
 */
public abstract class CommonConstants {
    public static final String USERNAME = "SSPSILUser"; // malcolm
    public static final String COUNTRY = "AU";
    public static final String LANGUAGE = "EN";
    public static final String DATABASE_IDENTIFIER = "SonataDataSource";

    public static final String RESPONSE_CLASS_NAME = "ResponseClassName";
    public static final String ERROR_MESSAGE_METHOD_NAME = "setErrorMessage";
    public static final String EXCEPTION_MESSAGE = "exceptionMessage";

    public static final String LOGGING_FORMAT = "SILService_{}_".concat(new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat(
            "_{}");

    public static final String DELETE_OPERATION_TYPE = "DELETE";
    public static final String DATEFORMAT_DDMMYYYY = "dd.MM.yyyy";
    public static final String DATE_FORMAT_DDMMYYYY = "dd/MM/yyyy";
    public static final String DATE_FORMAT = "yyyy-MM-dd";
    public static final String DATE_FORMAT_DD_MM_YYYY = "dd-MM-yyyy";
    public static final String DATETIME_FORMAT = "yyyy-MM-dd HH:mm:ss";
    public static final String DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss";
    public static final String SAVE_RESPONSE = "SaveResponse";
    public static final String CAMEL_LOOP_SIZE = "CamelLoopSize";
    public static final String CAMEL_LOOP_INDEX = "CamelLoopIndex";
    public static final String GENERIC_SIL_EXCEPTION = "SIL Internal Error";
    public static final String INVALID_CLIENT_ID_MESSAGE = "Invalid client Id, please provide valid clientId.";
    public static final String INVALID_SONATA_RESPONSE = "Invalid response from Sonata";
    public static final String INVALID_DATE_FORMAT = "Invalid date. Please provide a valid date.";
    public static final String NULL_EXCEPTION_MSG = "Exception Message is NULL";
    public static final String REGEX_NUMERIC = "\\d+";
    public static final String REGEX_ALPHA_UCASE = "[A-Z]+";
    public static final String REGEX_FLOAT = "^(\\d+\\.)?\\d+$";
    public static final String REGEX_UPLOAD_UNIT_PRICE_FILENAME_PATTERN = "UP315_\\d*\\.csv\\b"; // UP315_XXXXXXXXX.csv
    public static final String SUCCESS = "Success";
    public static final String FAILURE = "Failure";
    public static final String SOAP_REQUEST_EXCEPTION_MSG = "Exception while creating SOAP request: ";
    public static final int HTTP_BAD_REQUEST_CODE = 400;
    public static final int HTTP_SUCCESS_REQUEST_CODE = 200;
    public static final String REGEX_CAF_FILENAME_PATTERN = "(?i).*\\.xml";
    public static final String CURRENCY_CODE = "AUD";
    public static final String INVALID_DOC_FORMAT = "Invalid doc. Please provide a valid doc.";
    public static final String INVALID_FILE_FORMAT = "Invalid file. Please provide a valid file.";
    public static final int NEW_LINE_CHARACTER_VALUE = 10;
    public static final String EMPTY_STRING_VALUE = "";

    public static final String REBALANCE_QUARTERLY = "22nd Quarterly";
    public static final String REBALANCE_HALF_YEARLY = "22nd Half Yrly";
    public static final String REBALANCE_YEARLY = "22nd Yearly";
    public static final String REBALANCE_YEARLY_MONTH_DAY = "12-22";
    public static final String REBALANCE_HALF_YEARLY_MONTH_DAY = "06-22";
    public static final String REBALANCE_QUARTERLY_MONTH_DAY = "03-22";
    public static final String REBALANCE_QUARTERLY2_MONTH_DAY = "09-22";

    public static final String XML_EXT_GENERAL_ENTITIES_NS = "http://xml.org/sax/features/external-general-entities";
    public static final String XML_EXT_PARAMETER_ENTITIES_NS = "http://xml.org/sax/features/external-parameter-entities";
    public static final String XML_DISALLOW_DOCTYPE_DECL_NS = "http://apache.org/xml/features/disallow-doctype-decl";
    public static final String XML_FEATURES_VALIDATION_NS = "http://xml.org/sax/features/validation";

    public static final String REGEX_SYNC_MEMBER_FILENAME_PATTERN = "Member_Sync_\\d{8}_\\d{6}\\.csv\\b"; // Member_Sync_20160819_154938.csv
    public static final String REGEX_SYNC_ADVISOR_FILENAME_PATTERN = "Advisor_Extract_\\d{8}_\\d{6}\\.csv\\b"; // Advisor_Extract_20160718_092506.csv
    public static final String REGEX_SYNC_EMPLOYER_FILENAME_PATTERN = "Employer_Sync_\\d{8}_\\d{6}\\.csv\\b"; // Employer_Sync_20160718_092506.csv
    public static final String FLAG_Y = "Y";
    public static final String FLAG_N = "N";
    public static final String FLAG_FAILED = "FAILED";

    public static final String BLANK_XML_TAG_EXCEPTION1 = "Blank ";
    public static final String BLANK_XML_TAG_EXCEPTION2 = ", please provide valid value.";

    public static final String HTTP_GET_METHOD = "GET";
    public static final String HTTP_AUTHORIZATION = "Authorization";

    public static final String PERSONAL_CLIENT_CODE = "PERS";
    public static final String EXCEPTION_OCCURED = "exceptionOccured";

    // Sonata DB
    public static final String SONATA_DB_CONNECTION_FAILED = "Connection to DB failed";
    public static final String SONATA_DB_TRANSACTION_FAILED = "Connection transaction failed";
    public static final String EMP_NAME = "empName";
    public static final String OCCUPATION_CODE = "occupationCode";
    public static final String CATEGORY_CODE = "categoryCode";
    public static final String SCHEMA_NAME = "schemaname";
    public static final String CATG_CODE = "CATG_CODE";
    public static final String RDTP_ID = "RDTP_ID";
    public static final String RDTP_SHORT_NAME = "RDTP_SHORT_NAME";
    public static final String CALC_BOOK = "DV_SUM_INSURED_CALC_BOOK";
    public static final String CHECKINSURANCE_SAL = "sal";
    public static final String OCCP_CODE = "OCCP_CODE";
    public static final String ORACLE_DRIVER = "oracle.jdbc.OracleDriver";
    public static final String AUTH_VALUE = "AUTH_VALUE";
    public static final String EPCB_CATEGORY_ID = "EPCB_CATEGORY_ID";
    public static final String FAILED = "FAILED";

    // ODS
    public static final String ODS_CONNECTION_FAILED = "Connection to DB failed";
    public static final String ADVISOR_CLIENT_ID = "ADVISER_CLIENT_ID";
    public static final String MEMBER_CLIENT_ID = "MEMBER_CLIENT_ID";
    public static final String MEMBER_ACCOUNT_ID = "MEMBER_ACCOUNT_ID";
    public static final String MEMBER_NAME = "MEMBER_NAME";
    public static final String MEMBER_ACCOUNT_NUMBER = "MEMBER_ACCOUNT_NUMBER";
    public static final String PRODUCT_NAME = "PRODUCT_NAME";
    public static final String UPDATE_DATE = "UPDATE_DATETIME";
    public static final String VARIABLE_VALUE = "VARIABLE_VALUE";
    public static final String MEMBER_FIRST_NAME = "MEMBER_FIRST_NAME";
    public static final String ADVISER_FIRST_NAME = "ADVISER_FIRST_NAME";
    public static final String ADVISER_NAME = "ADVISER_NAME";
    public static final String COMMENCE_DATE = "COMMENCE_DATE";
    public static final String DESCRIPTION = "DESCRIPTION";
    public static final String DATE_INSURANCE_ACTIVITY_STATUS = "DATE_INSURANCE_ACTIVITY_STATUS";
    public static final String STATUS = "STATUS";

    public static final String FLAG_NONE = "NONE";
    public static final String FLAG_TRUE = "TRUE";
    public static final String FLAG_FALSE = "FALSE";
    public static final String FLAG_FULL = "FULL";
    public static final String FLAG_PARTIAL = "PARTIAL";
    public static final String SCHEME_CATEGORY_ID = "schemeCategoryId";
    public static final String SCHEME_CATEGORY_RANK = "schemeCategoryRank";
    public static final String SCHEME_CATEGORY_GROUP = "schemeCategoryGroup";
    public static final String EMPLOYER_NUMBER = "employerNumber";
    public static final String SCHEME_CATEGORY_CODE_FILE = "scCodeFile";
    public static final String SCHEME_CATEGORY_ID_SONATA = "scIdSonata";
    public static final int SPCL_EMPLOYER_FILE_LOOP_INDEX = 1;
    public static final int SPCL_EMPLOYER_SONATA_LOOP_INDEX = 0;
    public static final String SIL_EMPLOYER_ABN = "silEmployerABN";
}
