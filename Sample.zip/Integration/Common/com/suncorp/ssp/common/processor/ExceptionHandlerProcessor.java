////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////

package com.suncorp.ssp.common.processor;

import java.io.StringReader;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.ExceptionUtil;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.rolloverservice.RolloverConstants;

/**
 * 
 * The class {@code ExceptionHandlerProcessor} use to handle soap fault as a soap response from Sonata if any.
 * 
 * @author U383754
 * @since 2015-10-01
 * @version 1.0
 */
public class ExceptionHandlerProcessor implements Processor {

    /**
     * This method is check whether soap fault coming from Sonata or not. If any soap fault there, just throwing the Sonata exception.
     * 
     * @param the object of exchange message
     */
    public void process(Exchange exchange) throws SILException {
        SILLogger.debug(CommonConstants.LOGGING_FORMAT, "ExceptionHandlerProcessor", "Entering in process method");
        String sonataResponse = (String) exchange.getIn().getBody();
        checkNullResponse(exchange);
        checkFaultMessage(sonataResponse, exchange);
    }

    /**
     * This method will check whether the body of In message of Exchange is null or not. And will throw exception accordingly
     * 
     * @param exchange
     * @throws Exception
     */
    private void checkNullResponse(Exchange exchange) throws SILException {
        String body = (String) exchange.getIn().getBody();
        if (body == null) {
            logging("ExceptionHandlerProcessor", "Exception from SONATA : No reponse from Sonata" + "Exiting from process method");
            if (exchange.getException().getMessage() != null) {
                throw new SILException(exchange.getException().getMessage());
            } else {
                throw new SILException(CommonConstants.INVALID_SONATA_RESPONSE);
            }
        }
    }

    /**
     * This method will check fault code fault string and will throw SILException with error message came from external system.
     * 
     * @param body
     * @param exchange
     * @throws Exception
     */
    private void checkFaultMessage(String body, Exchange exchange) throws SILException {
        if (body.indexOf("Fault") != -1 && body.indexOf("<faultcode>") != -1 && body.indexOf("<faultstring>") != -1) {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setValidating(true);
            try {
                factory.setFeature(XMLConstants.FEATURE_SECURE_PROCESSING, true);
                factory.setFeature(CommonConstants.XML_DISALLOW_DOCTYPE_DECL_NS, true);
                factory.setFeature(CommonConstants.XML_EXT_GENERAL_ENTITIES_NS, false);
                factory.setFeature(CommonConstants.XML_EXT_PARAMETER_ENTITIES_NS, false);
                DocumentBuilder builder = factory.newDocumentBuilder();
                builder.setErrorHandler(null);
                Document doc = builder.parse(new InputSource(new StringReader(body)));
                ExceptionUtil.validateNodeValues(doc);
                ExceptionUtil.getFault(doc);
            } catch (SILException e) {
                logging("ExceptionHandlerProcessor", "Exception from SONATA : " + e.getMessage() + "Exiting from process method");
                exchange.setProperty(RolloverConstants.CREATE_MRR_ERROR_CSV, (String) exchange.getProperty(RolloverConstants.CREATE_MRR_ERROR_CSV) +
                        "ExceptionHandlerProcessor" + " - " + e.getMessage() + ";");
                throw e;
            } catch (Exception e) {
                logging("ExceptionHandlerProcessor", "Exception : " + e.getMessage() + "Exiting from process method");
                throw new SILException(CommonConstants.GENERIC_SIL_EXCEPTION);
            }
        }
    }

    /**
     * This is the common method to log error and info message.
     * 
     * @param className
     * @param errorLoggerMessage
     */
    private void logging(String className, String errorLoggerMessage) {
        SILLogger.error(CommonConstants.LOGGING_FORMAT, className, errorLoggerMessage);
    }
}
