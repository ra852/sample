////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.communicationservice.bean;

/**
 * The class {@code AdminFeeCodeList} does this.
 * 
 * @author U384380
 * @since 08/06/2017
 * @version 1.0
 */
public enum AdminFeeCodeList {
    TEAC, ADCG, ADCR, RAFL, AFLS, RAFP, EAFP, BFPS, AFPS, ATCO, RICD, RRCD, RAVF, GTTR, RGRT, ICDD, RCDD,
    ICTD, RITD, ICID, RACO, GATC, RGAT, RGTO, RRGT, GICC, RGIC, ZOGD, RZOD, RZOP, ZDTC, ZFTC, RZFT, ZACF, RZAC, XACF, XJHG;
}
