////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.communicationservice.bean;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.suncorp.ssp.common.bean.SILErrorMessage;

/**
 * The class {@code CommunicationServiceResponse} is a java bean consisting of all the properties related to getKycStatus functionality, to be used
 * for constructing response for end-client..
 * 
 * @author u386868
 * @since 08/12/2015
 * @version 1.0
 */
@XmlRootElement(name = "taskResponseAccept")
public class CommunicationServiceResponse extends SILErrorMessage {

    private String taskReference;

    /**
     * Accessor for property taskReference.
     * 
     * @return taskReference of type String
     */
    public String getTaskReference() {
        return taskReference;
    }

    /**
     * Mutator for property taskReference.
     * 
     * @return taskReference of type String
     */
    @XmlElement(name = "taskReference")
    public void setTaskReference(String taskReference) {
        this.taskReference = taskReference;
    }
}
