////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.communicationservice.bean;

/**
 * The class {@code PersonalAdviceFeeOngoingCodeList} does this.
 * 
 * @author U384380
 * @since 09/06/2017
 * @version 1.0
 */
public enum PersonalAdviceFeeOngoingCodeList {
    AARO, ONGA, ZOGP;
}
