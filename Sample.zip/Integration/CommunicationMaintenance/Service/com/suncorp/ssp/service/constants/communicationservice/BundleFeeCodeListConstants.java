////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.constants.communicationservice;

import java.util.ArrayList;
import java.util.List;

/**
 * The class {@code BundleFeeCodeListConstants} does this.
 * 
 * @author U385424
 * @since 20/10/2017
 * @version 1.0
 */
public class BundleFeeCodeListConstants {

    private List<String> adminFeeList;
    private List<String> adminFeeDollarList;
    private List<String> apraLevyFeeList;
    private List<String> rolloverContributionDtrnCodeList;
    private List<String> rolloverContributionActrCodeList;
    private List<String> contributionOrRolloverFeeList;
    private List<String> feeAdjustmentList;
    private List<String> personalAdviceFeeList;
    private List<String> withDrawalFeeList;
    private List<String> insuranceFeeLifeList;
    private List<String> insuFeeAdjustmentLifeList;
    private List<String> insuranceFeeTpdList;
    private List<String> insuFeeAdjustmentTpdList;
    private List<String> insuranceFeeIpList;
    private List<String> insuFeeAdjustmentIpList;
    private List<String> insuranceFeeList;
    private List<String> insuFeeAdjustmentList;
    private List<String> feeTypeFeesList;
    private List<String> feeTypeInsuranceFeesList;
    private List<String> actrCodeList;
    private List<String> dtrnCodeList;

    public BundleFeeCodeListConstants() {
        this.setAdminFeeList();
        this.setAdminFeeDollarList();
        this.setApraLevyFeeList();
        this.setRolloverContributionDtrnCodeList();
        this.setRolloverContributionActrCodeList();
        this.setRolloverOrContributionFeeList();
        this.setFeeAdjustmentList();
        this.setPersonalAdviceFeeList();
        this.setWithDrawalFeeList();
        this.setInsuranceFeeLifeList();
        this.setInsuranceFeeAdjustmentLifeList();
        this.setInsuranceFeeTpdList();
        this.setInsuranceFeeAdjustmentTpdList();
        this.setInsuranceFeeIpList();
        this.setInsuranceFeeAdjustmentIpList();
        this.setInsuranceFeeList();
        this.setInsuranceFeeAdjustmentList();
        this.setFeeTypeFeesList();
        this.setFeeTypeInsuranceFeesList();
        this.setActrCodeList();
        this.setDtrnCodeList();
    }

    /**
     * Accessor for property actrCodeList.
     * 
     * @return actrCodeList of type List<String>
     */
    public List<String> getActrCodeList() {
        return actrCodeList;
    }

    /**
     * Mutator for property actrCodeList.
     * 
     * @param actrCodeList of type List<String>
     */
    public void setActrCodeList() {
        this.actrCodeList = new ArrayList<String>();
        this.actrCodeList.add("CRFE"); // Fees - Fee Adjustment
        this.actrCodeList.add("DRFA");
        this.actrCodeList.add("XACF"); // Fees - Contribution/Rollover fee
        this.actrCodeList.add("IPDC"); // Insurance fee adjustment - Life cover
        this.actrCodeList.add("IPDD");
        this.actrCodeList.add("SDAC");
        this.actrCodeList.add("SDAD");
        this.actrCodeList.add("IPTC"); // Insurance fee adjustment - TPD cover
        this.actrCodeList.add("IATD");
        this.actrCodeList.add("SDTC");
        this.actrCodeList.add("SDTD");
        this.actrCodeList.add("IPIC"); // Insurance fee adjustment - IP cover
        this.actrCodeList.add("IPID");
        this.actrCodeList.add("SDCC");
        this.actrCodeList.add("SDCD");
        this.actrCodeList.add("ZEPC"); // Insurance fee adjustment
        this.actrCodeList.add("ZEPD");
        this.actrCodeList.add("FWPD");
        this.actrCodeList.add("FWPC");
    }

    /**
     * Accessor for property adminFeeList.
     * 
     * @return adminFeeList of type List<String>
     */
    public List<String> getAdminFeeList() {
        return adminFeeList;
    }

    /**
     * Mutator for property adminFeeList.
     * 
     * @param adminFeeList of type List<String>
     */
    public void setAdminFeeList() {
        this.adminFeeList = new ArrayList<String>();
        this.adminFeeList.add("AFLS");
        this.adminFeeList.add("EAFP");
        this.adminFeeList.add("ZDTC");
        this.adminFeeList.add("ZFTC");
        this.adminFeeList.add("ATCO");
    }

    /**
     * Accessor for property adminFeeDollarList.
     * 
     * @return adminFeeDollarList of type List<String>
     */
    public List<String> getAdminFeeDollarList() {
        return adminFeeDollarList;
    }

    /**
     * Mutator for property adminFeeDollarList.
     * 
     * @param adminFeeDollarList of type List<String>
     */
    public void setAdminFeeDollarList() {
        this.adminFeeDollarList = new ArrayList<String>();
        this.adminFeeDollarList.add("AFPS");
    }

    /**
     * Accessor for property apraLevyFeeList.
     * 
     * @return apraLevyFeeList of type List<String>
     */
    public List<String> getApraLevyFeeList() {
        return apraLevyFeeList;
    }

    /**
     * Mutator for property apraLevyFeeList.
     * 
     * @param apraLevyFeeList of type List<String>
     */
    public void setApraLevyFeeList() {
        this.apraLevyFeeList = new ArrayList<String>();
        this.apraLevyFeeList.add("APRB");
    }

    /**
     * Accessor for property rolloverContributionDtrnCodeList.
     * 
     * @return rolloverContributionDtrnCodeList of type List<String>
     */
    public List<String> getRolloverContributionDtrnCodeList() {
        return rolloverContributionDtrnCodeList;
    }

    /**
     * Mutator for property rolloverContributionDtrnCodeList.
     * 
     * @param rolloverContributionDtrnCodeList of type List<String>
     */
    public void setRolloverContributionDtrnCodeList() {
        this.rolloverContributionDtrnCodeList = new ArrayList<String>();
        this.rolloverContributionDtrnCodeList.add("ZACF");
        this.rolloverContributionDtrnCodeList.add("TRNS");
    }

    /**
     * Accessor for property rolloverContributionActrCodeList.
     * 
     * @return rolloverContributionActrCodeList of type List<String>
     */
    public List<String> getRolloverContributionActrCodeList() {
        return rolloverContributionActrCodeList;
    }

    /**
     * Mutator for property rolloverContributionActrCodeList.
     * 
     * @param rolloverContributionActrCodeList of type List<String>
     */
    public void setRolloverContributionActrCodeList() {
        this.rolloverContributionActrCodeList = new ArrayList<String>();
        rolloverContributionActrCodeList.add("XACF");
    }

    /**
     * Accessor for property contributionOrRolloverFeeList.
     * 
     * @return contributionOrRolloverFeeList of type List<String>
     */
    public List<String> getContributionOrRolloverFeeList() {
        return contributionOrRolloverFeeList;
    }

    /**
     * Mutator for property contributionOrRolloverFeeList.
     * 
     * @param contributionOrRolloverFeeList of type List<String>
     */
    public void setRolloverOrContributionFeeList() {
        this.contributionOrRolloverFeeList = new ArrayList<String>();
        this.contributionOrRolloverFeeList.addAll(this.rolloverContributionActrCodeList);
        this.contributionOrRolloverFeeList.addAll(this.rolloverContributionDtrnCodeList);
    }

    /**
     * Accessor for property feeAdjustmentList.
     * 
     * @return feeAdjustmentList of type List<String>
     */
    public List<String> getFeeAdjustmentList() {
        return feeAdjustmentList;
    }

    /**
     * Mutator for property feeAdjustmentList.
     * 
     * @param feeAdjustmentList of type List<String>
     */
    public void setFeeAdjustmentList() {
        this.feeAdjustmentList = new ArrayList<String>();
        this.feeAdjustmentList.add("CRFE");
        this.feeAdjustmentList.add("DRFA");
    }

    /**
     * Accessor for property personalAdviceFeeList.
     * 
     * @return personalAdviceFeeList of type List<String>
     */
    public List<String> getPersonalAdviceFeeList() {
        return personalAdviceFeeList;
    }

    /**
     * Mutator for property personalAdviceFeeList.
     * 
     * @param personalAdviceFeeList of type List<String>
     */
    public void setPersonalAdviceFeeList() {
        this.personalAdviceFeeList = new ArrayList<String>();
        this.personalAdviceFeeList.add("AVFE");
        this.personalAdviceFeeList.add("ZOGD");
        this.personalAdviceFeeList.add("ZOGP");
        this.personalAdviceFeeList.add("ONGA");
    }

    /**
     * Accessor for property withDrawalFeeList.
     * 
     * @return withDrawalFeeList of type List<String>
     */
    public List<String> getWithDrawalFeeList() {
        return withDrawalFeeList;
    }

    /**
     * Mutator for property withDrawalFeeList.
     * 
     * @param withDrawalFeeList of type List<String>
     */
    public void setWithDrawalFeeList() {
        this.withDrawalFeeList = new ArrayList<String>();
        this.withDrawalFeeList.add("WFEE");
    }

    /**
     * Accessor for property insuranceFeeLifeList.
     * 
     * @return insuranceFeeLifeList of type List<String>
     */
    public List<String> getInsuranceFeeLifeList() {
        return insuranceFeeLifeList;
    }

    /**
     * Mutator for property insuranceFeeLifeList.
     * 
     * @param insuranceFeeLifeList of type List<String>
     */
    public void setInsuranceFeeLifeList() {
        this.insuranceFeeLifeList = new ArrayList<String>();
        this.insuranceFeeLifeList.add("INDT");
        this.insuranceFeeLifeList.add("CPDI");
        this.insuranceFeeLifeList.add("MDTI");
        this.insuranceFeeLifeList.add("ITMD");
        this.insuranceFeeLifeList.add("IRDT");
        this.insuranceFeeLifeList.add("CPIR");
        this.insuranceFeeLifeList.add("IRDM");
        this.insuranceFeeLifeList.add("IRTM");
        this.insuranceFeeLifeList.add("ICDC");
        this.insuranceFeeLifeList.add("ICDD");
    }

    /**
     * Accessor for property insuFeeAdjustmentLifeList.
     * 
     * @return insuFeeAdjustmentLifeList of type List<String>
     */
    public List<String> getInsuFeeAdjustmentLifeList() {
        return insuFeeAdjustmentLifeList;
    }

    /**
     * Mutator for property insuFeeAdjustmentLifeList.
     * 
     * @param insuFeeAdjustmentLifeList of type List<String>
     */
    public void setInsuranceFeeAdjustmentLifeList() {
        this.insuFeeAdjustmentLifeList = new ArrayList<String>();
        this.insuFeeAdjustmentLifeList.add("IPDC");
        this.insuFeeAdjustmentLifeList.add("IPDD");
        this.insuFeeAdjustmentLifeList.add("SDAC");
        this.insuFeeAdjustmentLifeList.add("SDAD");
    }

    /**
     * Accessor for property insuranceFeeTpdList.
     * 
     * @return insuranceFeeTpdList of type List<String>
     */
    public List<String> getInsuranceFeeTpdList() {
        return insuranceFeeTpdList;
    }

    /**
     * Mutator for property insuranceFeeTpdList.
     * 
     * @param insuranceFeeTpdList of type List<String>
     */
    public void setInsuranceFeeTpdList() {
        this.insuranceFeeTpdList = new ArrayList<String>();
        this.insuranceFeeTpdList.add("XCPT");
        this.insuranceFeeTpdList.add("IRTP");
        this.insuranceFeeTpdList.add("IMTR");
        this.insuranceFeeTpdList.add("ITTR");
        this.insuranceFeeTpdList.add("INTP");
        this.insuranceFeeTpdList.add("CPTI");
        this.insuranceFeeTpdList.add("MTIP");
        this.insuranceFeeTpdList.add("MTTM");
        this.insuranceFeeTpdList.add("MTTT");
        this.insuranceFeeTpdList.add("STTC");
        this.insuranceFeeTpdList.add("STTD");
        this.insuranceFeeTpdList.add("MTTD");
        this.insuranceFeeTpdList.add("ICTC");
        this.insuranceFeeTpdList.add("ICTD");
    }

    /**
     * Accessor for property insuFeeAdjustmentTpdList.
     * 
     * @return insuFeeAdjustmentTpdList of type List<String>
     */
    public List<String> getInsuFeeAdjustmentTpdList() {
        return insuFeeAdjustmentTpdList;
    }

    /**
     * Mutator for property insuFeeAdjustmentTpdList.
     * 
     * @param insuFeeAdjustmentTpdList of type List<String>
     */
    public void setInsuranceFeeAdjustmentTpdList() {
        this.insuFeeAdjustmentTpdList = new ArrayList<String>();
        this.insuFeeAdjustmentTpdList.add("IPTC");
        this.insuFeeAdjustmentTpdList.add("IATD");
        this.insuFeeAdjustmentTpdList.add("SDTC");
        this.insuFeeAdjustmentTpdList.add("SDTD");
    }

    /**
     * Accessor for property insuranceFeeIpList.
     * 
     * @return insuranceFeeIpList of type List<String>
     */
    public List<String> getInsuranceFeeIpList() {
        return insuranceFeeIpList;
    }

    /**
     * Mutator for property insuranceFeeIpList.
     * 
     * @param insuranceFeeIpList of type List<String>
     */
    public void setInsuranceFeeIpList() {
        this.insuranceFeeIpList = new ArrayList<String>();
        this.insuranceFeeIpList.add("MITI");
        this.insuranceFeeIpList.add("IRIP");
        this.insuranceFeeIpList.add("MIRI");
        this.insuranceFeeIpList.add("TMIP");
        this.insuranceFeeIpList.add("INIP");
        this.insuranceFeeIpList.add("MNIP");
        this.insuranceFeeIpList.add("STIC");
        this.insuranceFeeIpList.add("MLTI");
        this.insuranceFeeIpList.add("STID");
        this.insuranceFeeIpList.add("MTIR");
        this.insuranceFeeIpList.add("ICIC");
        this.insuranceFeeIpList.add("ICID");
    }

    /**
     * Accessor for property insuFeeAdjustmentIpList.
     * 
     * @return insuFeeAdjustmentIpList of type List<String>
     */
    public List<String> getInsuFeeAdjustmentIpList() {
        return insuFeeAdjustmentIpList;
    }

    /**
     * Mutator for property insuFeeAdjustmentIpList.
     * 
     * @param insuFeeAdjustmentIpList of type List<String>
     */
    public void setInsuranceFeeAdjustmentIpList() {
        this.insuFeeAdjustmentIpList = new ArrayList<String>();
        this.insuFeeAdjustmentIpList.add("IPIC");
        this.insuFeeAdjustmentIpList.add("IPID");
        this.insuFeeAdjustmentIpList.add("SDCC");
        this.insuFeeAdjustmentIpList.add("SDCD");
    }

    /**
     * Accessor for property insuranceFeeList.
     * 
     * @return insuranceFeeList of type List<String>
     */
    public List<String> getInsuranceFeeList() {
        return insuranceFeeList;
    }

    /**
     * Mutator for property insuranceFeeList.
     * 
     * @param insuranceFeeList of type List<String>
     */
    public void setInsuranceFeeList() {
        this.insuranceFeeList = new ArrayList<String>();
        this.insuranceFeeList.add("ZPER");
    }

    /**
     * Accessor for property insuFeeAdjustmentList.
     * 
     * @return insuFeeAdjustmentList of type List<String>
     */
    public List<String> getInsuFeeAdjustmentList() {
        return insuFeeAdjustmentList;
    }

    /**
     * Mutator for property insuFeeAdjustmentList.
     * 
     * @param insuFeeAdjustmentList of type List<String>
     */
    public void setInsuranceFeeAdjustmentList() {
        this.insuFeeAdjustmentList = new ArrayList<String>();
        this.insuFeeAdjustmentList.add("ZEPC");
        this.insuFeeAdjustmentList.add("ZEPD");
        this.insuFeeAdjustmentList.add("FWPD");
        this.insuFeeAdjustmentList.add("FWPC");

    }

    /**
     * Accessor for property feeTypeFeesList.
     * 
     * @return feeTypeFeesList of type List<String>
     */
    public List<String> getFeeTypeFeesList() {
        return feeTypeFeesList;
    }

    /**
     * Mutator for property feeTypeFeesList.
     * 
     * @param feeTypeFeesList of type List<String>
     */
    public void setFeeTypeFeesList() {
        this.feeTypeFeesList = new ArrayList<String>();
        this.feeTypeFeesList.add(CommunicationServiceConstants.ADMINISTRATION_FEE);
        this.feeTypeFeesList.add(CommunicationServiceConstants.ADMINISTRATION_FEE_DOLLAR);
        this.feeTypeFeesList.add(CommunicationServiceConstants.APRA_LEVY_FEE);
        this.feeTypeFeesList.add(CommunicationServiceConstants.FEE_ADJUSTMENT);
        this.feeTypeFeesList.add(CommunicationServiceConstants.CONTRIBUTION_ROLLOVER_FEE);
        this.feeTypeFeesList.add(CommunicationServiceConstants.PERSONAL_ADV_FEE);
        this.feeTypeFeesList.add(CommunicationServiceConstants.WITHDRAWAL_FEE);
    }

    /**
     * Accessor for property feeTypeInsuranceFeesList.
     * 
     * @return feeTypeInsuranceFeesList of type List<String>
     */
    public List<String> getFeeTypeInsuranceFeesList() {
        return feeTypeInsuranceFeesList;
    }

    /**
     * Mutator for property feeTypeInsuranceFeesList.
     * 
     * @param feeTypeInsuranceFeesList of type List<String>
     */
    public void setFeeTypeInsuranceFeesList() {
        this.feeTypeInsuranceFeesList = new ArrayList<String>();
        this.feeTypeInsuranceFeesList.add(CommunicationServiceConstants.INSURANCE_FEES_LIFE);
        this.feeTypeInsuranceFeesList.add(CommunicationServiceConstants.INSURANCE_FEES_ADJUSTMENT_LIFE);
        this.feeTypeInsuranceFeesList.add(CommunicationServiceConstants.INSURANCE_FEES_TPD);
        this.feeTypeInsuranceFeesList.add(CommunicationServiceConstants.INSURANCE_FEES_ADJUSTMENT_TPD);
        this.feeTypeInsuranceFeesList.add(CommunicationServiceConstants.INSURANCE_FEES_IP);
        this.feeTypeInsuranceFeesList.add(CommunicationServiceConstants.INSURANCE_FEES_ADJUSTMENT_IP);
        this.feeTypeInsuranceFeesList.add(CommunicationServiceConstants.INSURANCE_FEES);
        this.feeTypeInsuranceFeesList.add(CommunicationServiceConstants.INSURANCE_FEES_ADJUSTMENT);
    }

    /**
     * Accessor for property dtrnCodeList.
     * 
     * @return dtrnCodeList of type List<String>
     */
    public List<String> getDtrnCodeList() {
        return dtrnCodeList;
    }

    /**
     * Mutator for property dtrnCodeList.
     * 
     * @param dtrnCodeList of type List<String>
     */
    public void setDtrnCodeList() {
        this.dtrnCodeList = new ArrayList<String>();
        this.dtrnCodeList.addAll(this.adminFeeList);
        this.dtrnCodeList.addAll(this.adminFeeDollarList);
        this.dtrnCodeList.addAll(this.apraLevyFeeList);
        this.dtrnCodeList.addAll(this.withDrawalFeeList);
        this.dtrnCodeList.addAll(this.personalAdviceFeeList);
        this.dtrnCodeList.addAll(this.rolloverContributionDtrnCodeList);
        this.dtrnCodeList.addAll(this.insuranceFeeLifeList);
        this.dtrnCodeList.addAll(this.insuranceFeeIpList);
        this.dtrnCodeList.addAll(this.insuranceFeeTpdList);
        this.dtrnCodeList.addAll(this.insuranceFeeList);
    }
}
