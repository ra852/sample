////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.communicationservice.bean;

import java.math.BigDecimal;

/**
 * The class {@code FeesDetails} does this.
 * 
 * @author U384380
 * @since 09/06/2017
 * @version 1.0
 */
public class FeesDetails {

    private String effectiveDate;
    private String feesCode;
    private double amount;
    private int feeEffectInd;
    private int balEffectInd;
    private BigDecimal amountBigDeciaml;

    /**
     * Accessor for property effectiveDate.
     * 
     * @return effectiveDate of type String
     */
    public String getEffectiveDate() {
        return effectiveDate;
    }

    /**
     * Mutator for property effectiveDate.
     * 
     * @return effectiveDate of type String
     */
    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    /**
     * Accessor for property feesCode.
     * 
     * @return feesCode of type String
     */
    public String getFeesCode() {
        return feesCode;
    }

    /**
     * Mutator for property feesCode.
     * 
     * @return feesCode of type String
     */
    public void setFeesCode(String feesCode) {
        this.feesCode = feesCode;
    }

    /**
     * Accessor for property amount.
     * 
     * @return amount of type double
     */
    public double getAmount() {
        return amount;
    }

    /**
     * Mutator for property amount.
     * 
     * @return amount of type double
     */
    public void setAmount(double amount) {
        this.amount = amount;
    }

    /**
     * Accessor for property feeEffectInd.
     * 
     * @return feeEffectInd of type int
     */
    public int getFeeEffectInd() {
        return feeEffectInd;
    }

    /**
     * Mutator for property feeEffectInd.
     * 
     * @return feeEffectInd of type int
     */
    public void setFeeEffectInd(int feeEffectInd) {
        this.feeEffectInd = feeEffectInd;
    }

    /**
     * Accessor for property balEffectInd.
     * 
     * @return balEffectInd of type int
     */
    public int getBalEffectInd() {
        return balEffectInd;
    }

    /**
     * Mutator for property balEffectInd.
     * 
     * @return balEffectInd of type int
     */
    public void setBalEffectInd(int balEffectInd) {
        this.balEffectInd = balEffectInd;
    }

    /**
     * Accessor for property amountBigDeciaml.
     * 
     * @return amountBigDeciaml of type BigDecimal
     */
    public BigDecimal getAmountBigDeciaml() {
        return amountBigDeciaml;
    }

    /**
     * Mutator for property amountBigDeciaml.
     * 
     * @param amountBigDeciaml of type BigDecimal
     */
    public void setAmountBigDeciaml(BigDecimal amountBigDeciaml) {
        this.amountBigDeciaml = amountBigDeciaml;
    }

}
