////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.communicationservice.bean;

import org.apache.camel.Exchange;

import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.communicationservice.CommunicationServiceConstants;

/**
 * The class {@code EmployeeAlterationFromEmailBean} does this.
 * 
 * @author U383847
 * @since 27/10/2016
 * @version 1.0
 */
public class EmployeeAlterationFromEmailBean {

    private String fromEmailId;

    /**
     * Accessor for property fromEmailId.
     * 
     * @return fromEmailId of type String
     */
    public String getFromEmailId() {
        return fromEmailId;
    }

    /**
     * Mutator for property fromEmailId.
     * 
     * @param fromEmailId of type String
     */
    public void setFromEmailId(String fromEmailId) {
        this.fromEmailId = fromEmailId;
    }

    /**
     * Set Exchange Properties for From Email.
     *
     * @param exchange
     */
    public void setExchangeProperties(Exchange exchange) {
        SILLogger.debug(CommunicationServiceConstants.COMMUNICATION_SERVICE_LOGGING_FORMAT, "EmployeeAlterationFromEmailBean",
                "Entering in setExchangeProperties method");
        exchange.setProperty(CommunicationServiceConstants.EMPLOYEE_ALTERATION_FROM_EMAIL, this.fromEmailId);
    }
}
