////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.constants.communicationservice;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * The class {@code CommunicationServiceConstants} holds all the constants for CommunicationService.
 * 
 * @author u386868
 * @since 08/12/2015
 * @version 1.0
 */
public abstract class CommunicationServiceConstants {

    // CommunicationService common constants
    public static final String OPERATION_NAMESPACE = "http://suncorp.com.au/services/easydoc/schema/0";
    public static final String COMMUNICATION_SERVICE_LOGGING_FORMAT = "CommunicationService{}_".concat(
            new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat("_{}");
    public static final String SOAPACTION = "SOAPAction";
    public static final String OPERATION_NAME = "submitTask";
    public static final String COMMUNICATION_SERVICE_RESPONCE_CLASS_NAME =
            "com.suncorp.ssp.service.integration.communicationservice.bean.CommunicationServiceResponse";
    public static final String COMMUNICATION_SERVICE_REQUEST_NOT_PROCESSED = "Communication service request could not be processed.";
    public static final String COMMUNICATION_SERVICE_RESPONSE_NOT_PROCESSED = "Communication service response could not be processed.";

    // Get client service Constants
    public static final String GET_CLIENT_OPERATION_NAME = "getClient";
    public static final String GET_CLIENT_OPERATION_NAMESPACE = "http://www.sonatacentral.com/service/v30/common/client";

    // Easy image constants
    public static final String STORE_IMAGE_LOGGING_FORMAT = "EasyImageService_StoreImage_{}_".concat(
            new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat("_{}");
    public static final String CONTENT_ID = "123456789123";
    public static final String ENDPOINT = "endpoint";
    public static final String USER_NAME = "username";
    public static final String PWD = "password";
    public static final String EASY_IMAGE_REQ_SOAP_MESSAGE = "easyImageSoapReqMsg";
    public static final String AUTHORIZATION = "Authorization";
    public static final String BASIC = "Basic ";

    // Commission Statement service constants
    public static final String REGEX_COMMISSION_STATEMENT_CSV_FILENAME_PATTERN = "(?i).*\\.csv";
    public static final String DEALER_NUMBER = "dealerNumber";
    public static final String COMMS_STATEMENT_TEMPLATE = "/SSP/Template/Dealer_Commission_Statement_Email";
    public static final String COMMS_STATEMENT_SUBJECT = "Suncorp Super Commission Statement";
    public static final String EMAIL_ADDRESS = "emailAddress";
    public static final String COMMS_DOC_TYPE = "Commission Statement";
    public static final String HEADER_TAG = "header";
    public static final String DEALER_NAME = "dealerName";
    public static final String NAME_TAG = "name";
    public static final String DEALER_OUTLET_NUMBER_TAG = "dealerOutletNumber";
    public static final String EASY_IMAGE_ID = "easyImageId";
    public static final String GUID_TAG = "GUID";

    // Communication channel
    public static final String EMAIL = "Email";
    public static final String POST = "Post";
    public static final String SMS = "SMS";
    public static final String MAIL = "Mail";
    public static final String DOC_RETURN = "DocReturn";

    // SIL METADATA fields used by FileNet
    public static final String ISSUE_DATE_TIME = "SSP_IssueDateTime";
    public static final String ENVELOPE_ID = "SSP_EnvelopeID";
    public static final String ACCOUNT_ID = "SSP_AccountID";
    public static final String ACCOUNT_TYPE = "SSP_AccountTypeMV";
    public static final String APPLICATION_TYPE = "SSP_ApplicationTypeMV";
    public static final String CHANNEL = "SSP_ChannelMV";
    public static final String DOCUMENT_TYPE = "SSP_DocumentType";
    public static final String SUBJECT = "SSP_SuperEmailSubject";
    public static final String RELATED_ACCOUNT_ID = "SSP_RelatedAccountID";
    public static final String RELATED_ACCOUNT_TYPE = "SSP_RelatedAccountType";

    // SONATA XML Tags used by SIL Communication service
    public static final String LETH_CLIENT_TITLE = "leth_client_title";
    public static final String LETH_CLIENT_FORENAME = "leth_client_forename";
    public static final String LETH_CLIENT_SURNAME = "leth_client_surname";
    public static final String LETH_ACCOUNT_NUMBER = "leth_account_number";
    public static final String LETH_PRIMARY_EMAIL_ADDR = "leth_primary_email_addr";
    public static final String LETH_ADDRESS_LINE_1 = "leth_address_line_1";
    public static final String LETH_ADDRESS_LINE_2 = "leth_address_line_2";
    public static final String LETH_ADDRESS_LINE_3 = "leth_address_line_3";
    public static final String LETH_ADDRESS_LINE_4 = "leth_address_line_4";
    public static final String LETH_BROKER_ADDRESS_LINE_1 = "broker_address_line_1";
    public static final String LETH_BROKER_ADDRESS_LINE_2 = "broker_address_line_2";
    public static final String BROKER_SUBHURB = "broker_suburb";
    public static final String BROKER_CITY = "broker_city";
    public static final String BROKER_POST_CODE = "broker_post_code";
    public static final String BROKER_STATE_NAME = "broker_state_name";
    public static final String LETH_ACCOUNT_STATUS = "leth_account_status";
    public static final String LACR_CLIENT_DOB_TAG = "lacr_client_dob";
    public static final String LPTD_RELEASE_CONDITION_CODE = "lptd_release_condition_code";
    public static final String LETH_CLIENT_NUMBER = "leth_client_number";
    public static final String ACCOUNT_RELATIONSHIPS = "account_relationships";
    public static final String LACR_MOBILE_PHONE = "lacr_mobile_phone";
    public static final String PAYMENT_SUPER = "paymentsuper";
    public static final String LPTD_PAYMENT_TYPE = "lptd_payment_type";
    public static final String LETH_CREATED_DATE = "leth_created_date";
    public static final String LETH_ID = "leth_id";
    public static final String ADVISER_CLIENT_ID = "Adviser_Client_ID";
    public static final String BROKER_CLIENT_ID = "broker_client_id";
    public static final String DEALER_CLIENT_ID = "Dealer_Client_ID";
    public static final String PRODUCT_NAME = "leth_product_external_name";
    public static final String TTR_FLAG = "leth_ttr_flag";
    public static final String LETH_REQUEST_ID = "leth_request_id";
    public static final String BROKER_SURNAME = "broker_surname";
    public static final String BROKER = "broker";
    public static final String BROKER_EXTREF = "brok_extref";
    public static final String BROKER_EMAIL_ADDRESS = "broker_email_address";
    public static final String POLICY = "policy";
    public static final String EXT_REFS = "ext_refs";
    public static final String PROD_EXT_REFS = "prod_extref";
    public static final String LDER_TABLE_CODE = "lder_table_code";
    public static final String LDER_TABLE_ROW_ID = "lder_table_row_id";
    public static final String EXTERNAL_REF_CODE = "external_ref_code";
    public static final String LETH_LETTER_TYPE = "leth_letter_type";
    public static final String ACCOUNT_RELATION = "account_relation";
    public static final String LACR_RELATIONSHIP_CODE = "lacr_relationship_code";
    public static final String BROKER_RELATIONSHIP_CODE = "broker_relationship_code";
    public static final String LACR_TFN_STATUS = "lacr_tfn_status";
    public static final String GEN_VARS = "gen_vars";
    public static final String LDGV_CODE = "ldgv_code";
    public static final String LDGV_VALUE = "ldgv_value";
    public static final String LDER_CODE = "lder_code";
    public static final String LDER_VALUE = "lder_value";
    public static final String VALUE = "value";
    public static final String LETH_CONTACT_NAME = "leth_contact_name";
    public static final String LEHX_EXTERNAL_TEMPLATE_NAME = "lehx_external_template_name";
    public static final String LETH_MAILING_FORENAME = "leth_mailing_forename";
    public static final String LETH_PRODUCT_NAME = "leth_product_name";
    public static final String LETH_TFN_SEARCH_CONSENT = "lacr_tfn_srch_cnsnt";

    public static final String BATCH_RUN_NAME = "LIFESUPERDOCS";
    public static final String EMAIL_FROM = "brightersuper@suncorp.com.au";
    public static final String LIFE_SUPER = "LifeSuper";
    public static final String DO_NOT_REPLY = "DO_NOT_REPLY@suncorp.com.au";
    public static final String NO_ADVISOR = "No Advisor";
    public static final String DOCUMENT_TYPE_WELCOME_EMAIL = "Welcome Email";
    public static final String OUTBOUND = "Outbound";
    public static final String LACR_RELATIONSHIP_CODE_EMPL = "EMPL";
    public static final String LACR_RELATIONSHIP_CODE_OWNR = "OWNR";
    public static final String BROKER_RELATIONSHIP_CODE_INIT = "INIT";
    public static final String EMAIL_ATTACHEMENT_NAME = "Standard_Choice_Form";
    public static final String CLIENT = "client";
    public static final String TFN_VALID = "TFN is Valid";
    public static final String DID_NOT_CODE_TFN = "Didnt Quote TFN";
    public static final String TFN_INVALID = "TFN is Invalid";
    public static final String TFN_VALUE_NOT_PROVIDED = "Not Provided";
    public static final String TFN_VALUE_REFUSED = "Refused";
    public static final String TFN_VALUE_NULL_VALUE = "NULL VALUE";
    public static final String TFN_VALUE_CONSENTED = "Consented";
    public static final String EMPTY_STRING = "";
    public static final String TTR_FLAG_Y = "Y";
    public static final String TTR_FLAG_N = "N";
    public static final String SUNCORP = "Suncorp ";
    public static final String LDER_TABLE_CODE_PROD = "PROD";
    public static final String LDER_TABLE_CODE_PRLK = "PRLK";
    public static final String LDER_TABLE_CODE_CLNT = "CLNT";
    public static final String LDER_CODE_EMAL = "EMAL";
    public static final String ROLLOVER = "Rollover";
    public static final String AUSTRALIA = "Australia";
    public static final String SUNCORP_BRIGHTER_SUPER = "Suncorp Brighter Super";
    public static final String BENEFIT_QUESTIONNAIRE_ATTACHEMENT_NAME = "Benefit Questionnaire";
    public static final String LDER_TABLE_CODE_SPXF = "SPXF";

    // Corro types
    public static final String MEMBER_KEY = "Member";
    public static final String ADVISER_KEY = "Adviser";
    public static final String DEALER_KEY = "Dealer";
    public static final String THIRD_PARTY_KEY = "Third Party";
    public static final String EMPLOYER_KEY = "Employer";

    // Custom exception message thrown by SIL
    public static final String INVALID_ADDRESSEE = "Blank addressee, please provide valid value.";
    public static final String BLANK_EMAIL_FROM_TAG = "Blank Email from tag, please provide valid value";
    public static final String BLANK_GEN_VARS_ELEMENTS = "Blank gen_vars tags, please provide valid values";
    public static final String BLANK_ACCOUNT_RELATION_ELEMENTS =
            "Blank account_relation tag, Communication service request could not be processed for Welcome letters.";
    public static final String INVALID_CUSTOMER_NAME = "Customer name is not there.";
    public static final String BLANK_EMAIL_ADDRESS = "Blank email address, please provide valid value.";
    public static final String BLANK_EXT_REFS_TAG = "Blank ext_refs tag, please provide valid value.";
    public static final String BLANK_PROD_EXT_REFS_TAG = "Blank prod_extrefs tag, please provide valid value.";
    public static final String BLANK_GEN_VARS_TAG = "Blank gen_vars tag, please provide valid value.";
    public static final String BLANK_ACCOUNT_RELATIONTIONSHIPS_TAG = "account_relationships tag is blank, so processing further for email or post.";
    public static final String BLANK_ADDRESS_LINES = "Blank address line, please provide valid value";

    public static final String TYPE_CODE_EMAL = "EMAL";
    public static final String CONTENT_TYPE = "application/csv";
    public static final String DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS";
    public static final String DATETIME = "dateTime";

    public static final String SMS_SUPPLIED_MESSAGE = "Test Confirming your benefit payment";
    public static final String CLIENT_ID = "clientId";
    public static final String BLANK_CLIENT_ID = "Blank clientId, please provide valid value.";
    public static final String CLIENT_RESIDENTIAL_ADDRESS = "clientResidentialAddress";
    public static final String GET_CLIENT_GENERIC_MSG = "Get client residential address functionality could not get processed";
    public static final String EASY_DOC_REQUEST = "easyDocRequest";
    public static final String LETTER_CODE = "letterCode";
    public static final String RESIDENTIAL_ADDRESS_TYPE_CODE = "RESI";
    public static final String RESIDENTIAL_ADDRESS_TAG = "residentialAddress";
    public static final String RESI_ADDRESS_LINE1_TAG = "addr_address_line_1";
    public static final String RESI_ADDRESS_LINE2_TAG = "addr_address_line_2";
    public static final String RESI_ADDRESS_LINE3_TAG = "addr_address_line_3";
    public static final String RESI_ADDRESS_LINE4_TAG = "addr_address_line_4";
    public static final String RESI_ADDRESS_SUBHURB_TAG = "addr_suburb";
    public static final String RESI_ADDRESS_CITY_TAG = "addr_city";
    public static final String RESI_ADDRESS_POST_CODE_TAG = "addr_post_code";
    public static final String RESI_ADDRESS_STATE_CODE_TAG = "addr_state_code";
    public static final String RESI_ADDRESS_COUNTRY_NAME_TAG = "addr_country_name";
    public static final String LPTD_EXIT_TYPE_CODE = "lptd_exit_type_code";
    public static final String LDGV_TABLE_ROW_ID = "ldgv_table_row_id";
    public static final String ROW_ID = "row_id";
    public static final String LETH_MAILING_CLIENT_NUMBER = "leth_mailing_client_number";
    public static final String LETH_ADDRESS_TYPE = "leth_address_type";
    public static final String LETH_PRODUCT_EXTERNAL_NAME = "leth_product_external_name";
    public static final String WORKFLOW_DATA = "workflow_data";
    public static final String WORKFLOW_DATA_TAG = "tag";
    public static final String WORKFLOW_DATA_VALUE = "value";
    public static final String LATEST_ADDRESS_TAG = "lastKnownAddress";

    public static final String WORKFLOW_DATA_VALUE_Y = "Y";
    public static final String NOMINATION100PERCENT_TAG = "nomination100PercentTag";
    public static final String NOMINATIONACCEPTABLE_TAG = "nominationsAcceptableTag";
    public static final String LETH_ADDRESS_TYPE_BUSN = "BUSN";
    public static final String LETH_ADDRESS_TYPE_RESI = "RESI";
    public static final String LPTD_RELEASE_CONDITION_CODE_TTPO = "TTPO";
    public static final String LPTD_RELEASE_CONDITION_CODE_DASP = "DASP";
    public static final String LPTD_RELEASE_CONDITION_CODE_FALS = "FALS";
    public static final String LPTD_RELEASE_CONDITION_CODE_TPD = "TPD";
    public static final String LPTD_RELEASE_CONDITION_CODE_DETH = "DETH";
    public static final String LPTD_RELEASE_CONDITION_CODE_TILL = "TILL";
    public static final String WELCOME = "Welcome";
    public static final String ALTERATION = "Alteration";
    public static final String LPTD_EXIT_TYPE_CODE_ERSF = "ERSF";
    public static final String LPTD_EXIT_TYPE_CODE_DENB = "DENB";
    public static final String LPTD_EXIT_TYPE_CODE_DEST = "DEST";
    public static final String LPTD_EXIT_TYPE_CODE_CASH = "CASH";
    public static final String LPTD_EXIT_TYPE_CODE_EXRO = "EXRO";
    public static final String LETH_ACCOUNT_STATUS_CLOSED = "Closed";
    public static final String LDGV_CODE_CPDM = "CPDM";
    public static final String WORK_FLOW_DATA_VALUE = "Benefit Payment - Hardship";
    public static final String SUSINSUFEVIDENCE_TAG_VALUE_Y = "Y";
    public static final String SUSINSUFEVIDENCE_TAG = "susInsufEvidenceTag";
    public static final String SUSRECENTCLAIM_TAG_VALUE_Y = "Y";
    public static final String SUSRECENTCLAIM_TAG = "susRecentClaimTag";
    public static final String SUSNOTELIGIBLE_TAG_VALUE_Y = "Y";
    public static final String SUSNOTELIGIBLE_TAG = "susNotEligibleTag";
    public static final String SUSNILACCNTBAL_TAG_VALUE_Y = "Y";
    public static final String SUSNILACCNTBAL_TAG = "susNilAccntBalTag";
    public static final String NILACCNTBAL_TAG_VALUE_Y = "Y";
    public static final String NILACCNTBAL_TAG = "nilAccntBalTag";
    public static final String SUSNOFUNDS_TAG_VALUE_Y = "Y";
    public static final String SUSNOFUNDS_TAG = "susNoFundsTag";
    public static final String NOCONDITIONMET_TAG_VALUE_Y = "Y";
    public static final String NOCONDITIONMET_TAG = "noConditionMetTag";
    public static final String LPTD_EXIT_TYPE_CODE_DEDB = "DEDB";
    public static final String LPTD_PAYMENT_NAME_CODE = "lptd_payment_name";
    public static final String LETH_MAILING_NAME_CODE = "leth_mailing_name";
    public static final String IS_PROPER_M902_LETTER = "isProperM902Letter";
    public static final String LETH_SCHEME_CATEGORY_CODE = "leth_scheme_category_code";
    public static final String LETH_SCHEME_CATEGORY_VALUE = "ANMS";
    public static final String LETH_ADDRESS_TYPE_EMAIL = "EMAL";
    public static final String MEMBER_EMAIL_KEY = "Member Email";
    public static final String MEMBER_POST_KEY = "Member Post";
    public static final String LETH_SUBURB = "leth_suburb";
    public static final String LETH_STATE = "leth_state";
    public static final String LETH_POST_CODE = "leth_post_code";
    public static final String LETH_COUNTRY = "leth_country";
    public static final String COUNTRY_AUSTRALIA = "Australia";
    public static final String LACR_RELATIONSHIP_CODE_BENE = "BENE";
    public static final String LACR_FORENAME = "lacr_forename";
    public static final String LACR_SURNAME = "lacr_surname";
    public static final String LACR_TITLE = "lacr_title";
    public static final String SMS_FROM_EMAIL_ADDESS = "smsFromEmailAddress";
    public static final String LACR_DATE_OF_BIRTH = "lacr_date_of_birth";
    public static final String OWNER_DOB_MISSING = "Owner's date of birth is not present";
    public static final String OWNER_ACCOUNT_RELATIONSHIP_MISSING = "Owner's client block is not present";
    public static final String INTERIM_STATEMENT_ATTACHMENT_NAME = "Interim Statement";
    public static final String TAG_FDTRANS = "fdtrans";
    public static final String LDIT_TRAN_TYPE_CODE = "ldit_tran_type_code";
    public static final Object LDIT_TRAN_TYPE_CODE_VALUE = "D293";
    public static final String EMPLOYER_CONOCO = "Conoco";
    public static final String LPTD_EXIT_TYPE_CODE_ATOR = "ATOR";
    public static final String PROCESS_BP_LETTER = "processBPLetter";
    public static final String SUS_NIL_ACCNT_BAL_TAG_VALUE_Y = "Y";
    public static final String SUS_NIL_ACCNT_BAL_TAG = "susnilAccntBalTag";
    public static final String TAG = "tag";
    public static final String VALUE_TAG = "value";
    public static final String PROCESS_LETTER = "processLetter";
    public static final Object PRODUCT_SUNCORP_CLASSIC_PENSION = "Suncorp Classic Pension";
    public static final String PRODUCT_SUNCORP_POOLED_SUPER_TRUST = "Suncorp Pooled Superannuation Trust";
    public static final String LETH_PRODUCT_NAME_VALUE = "lethProductNameValue";
    public static final Object PRODUCT_SUNCORP_ALLOCATED_ANNUITY = "Suncorp Allocated Annuity";
    public static final String ANNUAL_STATEMENT_ATTACHMENT_NAME = "Annual Statement";

    // Rollover letters Email subject lines
    public static final String MEMBER_CONTB_SUBJ_LINE_2 = " " + "-" + " " + "We have received your super contribution";
    public static final String ALTERATION_CONFIRMATION_SUBJ_LINE = " " + "-" + " " + "Alteration confirmation";
    public static final String ROLLOVER_REQ_SUBJ_LINE = " " + "-" + " " + "We have received your request to rollover your super";
    public static final String ROLLOVER_REC_SUBJ_LINE_1 = "Your super is now in your Suncorp ";
    public static final String ROLLOVER_REC_SUBJ_LINE_2 = " Account";

    // Welcome letters Email subject line
    public static final String DIRECT_WELCOME_SUBJ_LINE_1 = ", we need your Tax File Number to finalise things";
    public static final String DIRECT_WELCOME_SUBJ_LINE_2 = ", search now for all your lost super";
    public static final String DIRECT_WELCOME_SUBJ_LINE_3 = ", your super search results should arrive soon";
    public static final String PENSION_WELCOME_SUBJ_LINE_1 = ", managing your super is easy, when you go online";
    public static final String PENSION_WELCOME_SUBJ_LINE_2 = ", managing your retirement income is easy when you go online";
    public static final String EMPLOYER_WELCOME_SUBJ_LINE = ", enjoy a fuss free way of managing your super";
    public static final String EMPLOYEE_WELCOME_SUBJ_LINE = ", managing super is easy when you go online";
    public static final String ADVISED_WELCOME_SUBJ_LINE = ", you're ready to grow your super, now you just need online access";

    // Generic Email subject line
    public static final String MEMBER_EMAIL_GENERIC_SUBJECT_LINE = " - You" + "’" + "ve got mail from Suncorp Super!";

    // Generic Email subject line
    public static final String MEMBER_SMS_GENERIC_MESSAGE_LINE1 = ", you have mail! Go online to see your ";
    public static final String MEMBER_SMS_GENERIC_MESSAGE_LINE2 = " available on Super.suncorp.com.au";

    // Insurance Quote Letter Email subject lines
    public static final String INSURANCE_QUOTE_SUBJ_LINE_1 = "Your ";
    public static final String INSURANCE_QUOTE_SUBJ_LINE_2 = " insurance quote";

    // Employer Alteration Letter Email subject line
    public static final String EMPLOYER_ALTERATION_SUBJ_LINE = ", confirming your change of details";

    // Member SESP Subject Line
    public static final String MEMBER_SESP_SUBJ_LINE = ", managing super is easy when you go online";

    // CTP Confirmation and Benefit Questioner Subject Line
    public static final String CTP_CONFIRMATION_SUBJECT_LINE = "We’ve heard you’ve left your employer";

    // Change Of Advisor Employer Subject Line
    public static final Object CHANGE_OF_ADVISOR_SUBJ_LINE = ", confirming your change of details";

    public static final String EXCEPTION_DIRECTORY_PATH = "/apps/software/fuse/jboss-fuse-6.2.0.redhat-133/data/log/";
    // public static final String EXCEPTION_DIRECTORY_PATH = "C:/Users/U384380";
    public static final String EXCEPTION_FILE_NAME = "OutBoundCorroException";
    public static final String EXCEPTION_FILE_FORMAT = ".txt";
    public static final String EXCEPTION_LOG1 = " leth_request_id: " + " \"";
    public static final String EXCEPTION_LOG2 = " exception is - ";
    public static final String NEXT_LINE = "\n";
    public static final String CUSTOMER_EMAIL_EXCEPTION_MSG = "Customer email id is not present so generating letter for Postal Address.";
    public static final String CUSTOMER_COMMON_EXCEPTION_MSG = "Customer mobile phone, email and postal addresses are not available.";
    public static final String ADVISOR_COMMON_EXCEPTION_MSG = "Advisor email and postal addresses are not available.";
    public static final String ADVISOR_EMAIL_EXCEPTION_MSG = "Advisor email id is not present so generating letter for Postal Address.";
    public static final String EMPLOYEE_WELCOME_LETTER_EXCEPTION_MSG = "As customer email address is not present so not generating email.";
    public static final String WELCOME_LETTER_EXCEPTION_MSG = "No email address found.";
    public static final String MISSING_HEADER_TAG_EXCEPTION = "<header> tag is missing into XML file received from Sonata MQ.";
    public static final String CUSTOMER_SMS_EXCEPTION_MSG = "Customer mobile phone is not present so generating email alert.";
    public static final String CUSTOMER_NOT_OWNR_SMS_EXCEPTION_MSG = "Client is not OWNR mobile so generating email alert.";
    public static final String POSTAL_ADDRESS_EXCEPTION_MESSAGE =
            "Preference delivery method is POST and customer postal addresses is not available so not generating letter.";
    public static final String CUSTOMER_POST_EXCEPTION_MSG = "Customer postal address is not present so not generating letter.";
    public static final String COMMON_EMAIL_EXCEPTION_MSG = "As customer email address is not present so not generating email.";
    public static final String EMAIL_POST_NOT_PRESENT_EXCEPTION_MESSAGE = "Customer mobile phone, email and postal addresses are not available.";

    // Rollover Funds Received templates
    public static final String ROLLOVER_REC_MEMBER_LETTER_TEMPLATE = "/SSP/Template/rollover_funds_received_letter";
    public static final String ROLLOVER_REC_MEMBER_EMAIL_TEMPLATE = "/SSP/Template/rollover_funds_received_email";
    public static final String ROLLOVER_REC_ADVISOR_LETTER_TEMPLATE = "/SSP/Template/rollover_funds_received_adviser_letter";
    public static final String ROLLOVER_REC_ADVISOR_EMAIL_TEMPLATE = "/SSP/Template/rollover_funds_received_adviser_email";

    // Rollover Request Received templates
    public static final String ROLLOVER_REQ_MEMBER_LETTER_TEMPLATE = "/SSP/Template/rollover_request_received_letter";
    public static final String ROLLOVER_REQ_MEMBER_EMAIL_TEMPLATE = "/SSP/Template/rollover_request_received_email";
    public static final String ROLLOVER_REQ_ADVISOR_LETTER_TEMPLATE = "/SSP/Template/rollover_request_received_adviser_letter";
    public static final String ROLLOVER_REQ_ADVISOR_EMAIL_TEMPLATE = "/SSP/Template/rollover_request_received_adviser_email";

    // Member Contribution templates
    public static final String MEMBER_CONTRIBUTION_MEMBER_LETTER_TEMPLATE = "/SSP/Template/member_contribution_confirmation_letter";
    public static final String MEMBER_CONTRIBUTION_MEMBER_EMAIL_TEMPLATE = "/SSP/Template/member_contribution_confirmation_email";
    public static final String MEMBER_CONTRIBUTION_ADVISOR_LETTER_TEMPLATE = "/SSP/Template/member_contribution_confirmation_adviser_letter";
    public static final String MEMBER_CONTRIBUTION_ADVISOR_EMAIL_TEMPLATE = "/SSP/Template/member_contribution_confirmation_adviser_email";

    // Alteration Confirmation templates
    public static final String ALTERATION_CONFIRMATION_MEMBER_LETTER_TEMPLATE = "/SSP/Template/alteration_confirmation_letter";
    public static final String ALTERATION_CONFIRMATION_MEMBER_EMAIL_TEMPLATE = "/SSP/Template/alteration_confirmation_generic_email";

    // Employee Welcome Letter Templates
    public static final String EMPLOYEE_WELCOME_LETTER_EMAIL_TEMPLATE = "/SSP/Template/WelcomePack/employee_welcome_email";
    public static final String EMPLOYEE_WELCOME_LETTER_LETTER_TEMPLATE = "/SSP/Template/WelcomePack/employee_welcome_letter";

    // Direct Welcome Letter Template
    public static final String DIRECT_WELCOME_LETTER_EMAIL_TEMPLATE = "/SSP/Template/WelcomePack/self_direct_welcome_email";

    // Advised Welcome Letter Template
    public static final String ADVISED_WELCOME_LETTER_EMAIL_TEMPLATE = "/SSP/Template/WelcomePack/personal_advised_welcome_email";

    // Employer Welcome Letter Template
    public static final String EMPLOYER_WELCOME_LETTER_EMAIL_TEMPLATE = "/SSP/Template/WelcomePack/employer_welcome_email";

    // Pension Welcome Letter Template
    public static final String PENSION_WELCOME_LETTER_EMAIL_TEMPLATE = "/SSP/Template/WelcomePack/pension_welcome_email";

    // Email Attachment Template
    public static final String EMAIL_ATTACHEMENT_TEMPLATE = "/SSP/Template/Standard_Choice_Form";

    // Benefit Payment Confirmation Templates
    public static final String BENEFIT_PAYMENT_COVER_LETTER_TEMPLATE = "/SSP/Template/benefit_payment_cover_letter";
    public static final String ROLLOVER_BENEFITS_STATEMENT_LETTER_TEMPLATE = "/SSP/Template/rollover_benefits_statement_letter";
    public static final String BENEFITS_PAYMENT_3RD_PARTY_COVER_LETTER_TEMPLATE = "/SSP/Template/benefit_payment_3rd_party_cover_letter";
    public static final String PAYG_SUMMARY_LETTER_TEMPLATE = "/SSP/Template/payg_summary_letter";
    public static final String DASP_PAYMENT_SUMMARY_LETTER_TEMPLATE = "/SSP/Template/dasp_payment_summary_letter";
    public static final String EXIT_STATEMENT_LETTER_TEMPLATE = "/SSP/Template/exit_statement_letter";
    public static final String BENEFITS_PAYMENT_KIWISAVER_LETTER_TEMPLATE = "/SSP/Template/kiwisaver_statement_letter";
    public static final String FAMILY_LAW_MEMBER_SPOUSE_CONFIRMATION_LETTER_TEMPLATE = "/SSP/Template/family_law_member_spouse_confirmation";
    public static final String CLAIMS_COVER_LETTER_TEMPLATE = "/SSP/Template/claims_cover_letter";

    // Generic Email Templates
    public static final String MEMBER_GENERIC_EMAIL_TEMPLATE = "/SSP/Template/generic_member_email";

    // Insurance Letter Template
    public static final String INSURANCE_APPLICATION_LETTER_TEMPLATE = "/SSP/Template/insurance_application_letter";
    public static final String INSURANCE_QUOTE_MEMBER_LETTER_TEMPLATE = "/SSP/Template/insurance_quote_member_email";
    public static final String INSURANCE_QUOTE_ADVISER_LETTER_TEMPLATE = "/SSP/Template/insurance_quote_adviser_email";

    // S290-170 Alteration Confirmation Letter Template
    public static final String S290_170_ALTERATION_CONFIRMATION_LETTER_TEMPLATE = "/SSP/Template/s290-170_alteration_confirmation_letter";

    // Centrelink Schedules Letter Template
    public static final String PENSION_ACTIVATION_LETTER_TEMPLATE = "/SSP/Template/pension_activation_letter";
    public static final String CENTRELINK_SCHEDULES_LETTER_TEMPLATE = "/SSP/Template/centrelink_statement_letter";

    // Reversionary Cover Letter Template
    public static final String REVERSIONARY_COVER_LETTER_TEMPLATE = "/SSP/Template/claims_reversionary_letter";

    // Benefit Payment Decline Template
    public static final String BENEFIT_PAYMENT_DECLINE_LETTER_TEMPLATE = "/SSP/Template/benefit_payment_decline_letter";

    // Switches Assets Template
    public static final String SWITCHES_ASSETS_LETTER_TEMPLATE = "/SSP/Template/switch_confirmation_letter";

    // Insurance Max Age Template
    public static final String INSURANCE_MAX_AGE_LETTER_TEMPLATE = "/SSP/Template/insurance_review_letter";

    // Alteration Confirmation Employer Templates
    public static final String ALTERATION_CONFIRMATION_EMPLOYER_EMAIL_TEMPLATE = "/SSP/Template/employer_alteration_confirmation_email";
    public static final String ALTERATION_CONFIRMATION_EMPLOYER_LETTER_TEMPLATE = "/SSP/Template/employer_alteration_confirmation_letter";

    // Insurance AAL CAP Template
    public static final String INSURANCE_AAL_CAP_LETTER_TEMPLATE = "/SSP/Template/insurance_aal_letter";

    // Suspense template
    public static final String SUSPENSE_REQ_FOR_INFO_LETTER_TEMPLATE = "/SSP/Template/request_for_information";
    public static final String MEMBER_ALTERATION_REJECTION_NOTIFICATIONLETTER_TEMPLATE = "/SSP/Template/request_for_information_close";
    public static final String SUSPENSE_REQ_FOR_INFO_EMPLOYER_LETTER_TEMPLATE = "/SSP/Template/employer_request_for information";
    public static final String EMPLOYER_ALTERATION_REJECTION_NOTIFICATIONLETTER_TEMPLATE = "/SSP/Template/employer_request_for_information_close";

    // Insurance confirmation and decline template
    public static final String INSURANCE_CONFIRMATION_TEMPLATE = "/SSP/Template/insurance_confirmation_letter";
    public static final String INSURANCE_DECLINE_TEMPLATE = "/SSP/Template/insurance_decline_letter";

    // CTP member confirmation
    public static final String CTP_MEMBER_CONFIRMATION_EMAIL_TEMPLATE = "/SSP/Template/Change_of_Employment_Confirmation_email";
    public static final String CTP_MEMBER_CONFIRMATION_LETTER_TEMPLATE = "/SSP/Template/Change_of_Employment_Confirmation_letter";

    // Insurance Alteration confirmation template
    public static final String INSURANCE_ALTERATION_TEMPLATE = "/SSP/Template/insurance_alteration_letter";

    // Brighter Super SESP Template
    public static final String BRIGHTER_SUPER_SESP_LETTER_TEMPLATE = "/SSP/Template/WelcomePack/sesp_welcome_letter";
    public static final String BRIGHTER_SUPER_SESP_EMAIL_TEMPLATE = "/SSP/Template/WelcomePack/sesp_welcome_email";

    // Benefit Payment Family Law NMS Templates
    public static final String BENEFIT_PAYMENT_FAMILY_LAW_NMS_EMAIL_TEMPLATE = "/SSP/Template/WelcomePack/NMS_welcome_email";
    public static final String BENEFIT_PAYMENT_FAMILY_LAW_NMS_LETTER_TEMPLATE = "/SSP/Template/WelcomePack/NMS_welcome_letter";

    // Lapsing First Notice Template
    public static final String LAPSING_FIRST_NOTICE_TEMPLATE = "/SSP/Template/insurance_lapse_first_notice_letter";
    public static final String LAPSING_SECOND_NOTICE_TEMPLATE = "/SSP/Template/insurance_lapse_second_notice_letter";

    // Dishonours Template
    public static final String DISHONOURS_TEMPLATE = "/SSP/Template/financial_correspondence_letter";

    // Benefit Questioner template
    public static final String BENEFIT_QUESTIONNAIRE_TEMPLATE = "/SSP/Template/Benefit_Questionnaire";

    // Refunds Template
    public static final String REFUNDS_TEMPLATE = "/SSP/Template/refund_correspondence_letter";

    // Member Overpayement Template
    public static final String MEMBER_OVERPAYEMENT_TEMPLATE = "/SSP/Template/overpayment_correspondence_letter";

    // Change Of Adviser Confirmations Template
    public static final String CHANGE_OF_ADVISER_CONFIRMATIONS_TEMPLATE = "/SSP/Template/change_of_adviser_letter";

    // Change Of Contribution Switch Template
    public static final String CONTRIBUTION_SWITCH_TEMPLATE = "/SSP/Template/member_contribution_amendment_letter";

    // Annual Statements template
    public static final String ANNUAL_STATEMENTS_TEMPLATE = "/SSP/Template/annual_statement_letter";
    public static final String ANNUAL_STATEMENTS_EMAIL_TEMPLATE = "/SSP/Template/annual_statement_cover_email";

    // Change Of Adviser Employer Confirmations Template
    public static final String CHANGE_OF_ADVISER_EMPLOYER_CONFIRMATIONS_TEMPLATE = "/SSP/Template/change_of_adviser_employer_letter";

    // Account Linking Confirmation Template
    public static final String ACCOUNT_LINKING_CONFIRMATION_TEMPLATE = "/SSP/Template/account_linkage_letter";

    // Pension Payg Payment Summary Template
    public static final String PENSION_PAYG_PAYMENT_SUMMARY_TEMPLATE = "/SSP/Template/incomeStream_payg_summary_letter";

    // Interim Statements Template
    public static final String INTERIM_STATEMENTS_EMAIL_TEMPLATE = "/SSP/Template/interim_statement_cover_email";
    public static final String INTERIM_STATEMENTS_LETTER_TEMPLATE = "/SSP/Template/interim_statement_letter";

    // Excess Tax Form Template
    public static final String EXCESS_TAX_FORM_LETTER_TEMPLATE = "/SSP/Template/excess_tax_form";

    // Conoco Phillips specific template
    public static final String EMPLOYEE_WELCOME_CONOCO_LIFE_POLICY_TEMPLATE = "/SSP/Template/WelcomePack/conoco_corporate_life_policy_insert";
    public static final String EMPLOYEE_WELCOME_CONOCO_COVER_LETTER_TEMPLATE = "/SSP/Template/WelcomePack/conoco_corporate_cover_letter_insert";

    // Email bounce back template
    public static final String EMAIL_BOUNCE_BACK_TEMPLATE = "/SSP/Template/email_bounceback";

    // S290-170 Notice Letter
    public static final String S290_170_NOTICE_LETTER_TEMPLATE = "/SSP/Template/s290_notice_letter";
    
    //Annual Pension Review Letter Template
    public static final String ANNUAL_PENSION_REVIEW_LETTER_TEMPLATE = "/SSP/Template/pension_confirmation_letter";

    // Corro Letter Type used buy SIL internally to add templates
    public static final String ROLLOVER_LETTER_TYPE = "Rollover";
    public static final String ROLLOVER_REC_LETTER_TYPE = "Rollover Funds Received";
    public static final String ROLLOVER_REQ_LETTER_TYPE = "Rollover Request Received";
    public static final String MEMBER_CONTRIBUTION_LETTER_TYPE = "Member Contribution Confirmation";
    public static final String ALTERATION_CONFIRMATION_LETTER_TYPE = "Alteration Confirmation";
    public static final String EMPLOYEE_WELCOME_LETTER_TYPE = "Employee Welcome Letter";
    public static final String DIRECT_WELCOME_LETTER_TYPE = "Direct Welcome Letter";
    public static final String ADVISED_WELCOME_LETTER_TYPE = "Advised Welcome Letter";
    public static final String EMPLOYER_WELCOME_LETTER_TYPE = "Employer Welcome Letter";
    public static final String PENSION_WELCOME_LETTER_TYPE = "Pension Welcome Letter";
    public static final String BENEFIT_PAYMENT_LETTER_TYPE = "Benefit Payment Confirmation";
    public static final String BENEFIT_PAYMENT_DECLINE_LETTER_TYPE = "Benefit Payment Decline Letter";
    public static final String INSURANCE_APPLICATION_LETTER_TYPE = "Insurance Application Letter";
    public static final String BENEFIT_PAYMENT_KIWISAVER_LETTER_TYPE = "Benefit Payment KiwiSaver Letter";
    public static final String S290_170_ALTERATION_CONFIRMATION_LETTER_TYPE = "S290-170 Alteration Confirmation";
    public static final String INSURANCE_QUOTE_LETTER_TYPE = "Insurance Quote Letter";
    public static final String INSURANCE_QUOTE_MEMBER_LETTER_TYPE = "Insurance Quote Member Letter";
    public static final String INSURANCE_QUOTE_ADVISER_LETTER_TYPE = "Insurance Quote Adviser Letter";
    public static final String CENTRELINK_SCHEDULES_LETTER_TYPE = "Centrelink Schedules Letter";
    public static final String REVERSIONARY_COVER_LETTER_TYPE = "Reversionary Cover Letter";
    public static final String CLAIMS_COVER_LETTER_TYPE = "Claims Cover Letter";
    public static final String SWITCHES_ASSETS_LETTER_TYPE = "Switches Assets Letter";
    public static final String INSURANCE_MAX_AGE_LETTER_TYPE = "Insurance Stuffed";
    public static final String ALTERATION_CONFIRMATION_EMPLOYER_LETTER_TYPE = "Alteration Confirmation Employer";
    public static final String INSURANCE_AAL_CAP_LETTER_TYPE = "Insurance Review - AAL Cap";
    public static final String SUSPENSE_REQ_FOR_INFO_LETTER_TYPE = "Suspense Request For Information";
    public static final String MEMBER_ALTERATION_REJECTION_NOTIFICATION_LETTER_TYPE = "Member Alteration Rejection Notification";
    public static final String SUSPENSE_REQ_FOR_INFO_EMPLOYER_LETTER_TYPE = "Suspense Request For Information Employer";
    public static final String EMPLOYER_ALTERATION_REJECTION_NOTIFICATION_LETTER_TYPE = "Employer Alteration Rejection Notification";
    public static final String INSURANCE_CONFIRMATION_LETTER_TYPE = "Insurance Confirmation";
    public static final String INSURANCE_DECLINE_LETTER_TYPE = "Insurance Decline";
    public static final String CTP_MEMBER_CONFIRMATION_LETTER_TYPE = "Change of Employment Confirmation";
    public static final String INSURANCE_ALTERATION_LETTER_TYPE = "Insurance Alteration Confirmation";
    public static final String BRIGHTER_SUPER_SESP_LETTER_TYPE = "Brighter Super SESP";
    public static final String BENEFIT_PAYMENT_FAMILY_LAW_NMS_LETTER_TYPE = "Benefit Payment Family Law NMS";
    public static final String LAPSING_FIRST_NOTICE_LETTER_TYPE = "Lapsing First Notice";
    public static final String DISHONOURS_LETTER_TYPE = "Dishonours";
    public static final String REFUNDS_LETTER_TYPE = "Refunds";
    public static final String MEMBER_OVERPAYEMENT_LETTER_TYPE = "Member Overpayement";
    public static final String INSURANCE_CANCELLATION_AND_ACCOUNT_CLOSURE = "Insurance Cancellation and Account Closure";
    public static final String CHANGE_OF_ADVISER_CONFIRMATIONS = "Change Of Adviser Confirmations";
    public static final String CONTRIBUTION_SWITCH_LETTER = "Contribution Switch Letter";
    public static final String ANNUAL_STATEMENTS_LETTER = "Annual Statements";
    public static final String CHANGE_OF_ADVISER_EMPLOYER_CONFIRMATIONS = "Change Of Adviser Employer Confirmations";
    public static final String ACCOUNT_LINKING_CONFIRMATION = "Account Linking Confirmation";
    public static final String PENSION_PAYG_PAYMENT_SUMMARY = "Pension Payg Payment Summary";
    public static final String INTERIM_STATEMENTS = "Interim Statements";
    public static final String EXCESS_TAX_FORM_LETTER_TYPE = "Excess Tax Form";
    public static final String S290_170_NOTICE = "S290-170 Notice";
    public static final String INTERIM_STATEMENT_ADVISER = "Interim Statement Adviser";
    public static final String ANNUAL_PENSION_REVIEW = "Annual Pension Review";

    // Corro Rollover Letter Type Code
    public static final String LETH_LETTER_TYPE_CODE_M300 = "M300";
    public static final String LETH_LETTER_TYPE_CODE_M301 = "M301";
    public static final String LETH_LETTER_TYPE_CODE_M302 = "M302";
    public static final String LETH_LETTER_TYPE_CODE_M303 = "M303";
    public static final String LETH_LETTER_TYPE_CODE_M305 = "M305";
    public static final String LETH_LETTER_TYPE_CODE_M310 = "M310";
    public static final String LETH_LETTER_TYPE_CODE_M311 = "M311";
    public static final String LETH_LETTER_TYPE_CODE_M312 = "M312";
    public static final String LETH_LETTER_TYPE_CODE_M100 = "M100";
    public static final String LETH_LETTER_TYPE_CODE_E100 = "E100";
    public static final String LETH_LETTER_TYPE_CODE_M101 = "M101";
    public static final String LETH_LETTER_TYPE_CODE_M900 = "M900";
    public static final String LETH_LETTER_TYPE_CODE_M401 = "M401";
    public static final String LETH_LETTER_TYPE_CODE_M902 = "M902";
    public static final String LETH_LETTER_TYPE_CODE_M802 = "M802";
    public static final String LETH_LETTER_TYPE_CODE_M403 = "M403";
    public static final String LETH_LETTER_TYPE_CODE_MCNL = "MCNL";
    public static final String LETH_LETTER_TYPE_CODE_A403 = "A403";
    public static final Object LETH_LETTER_TYPE_CODE_M903 = "M903";
    public static final String LETH_LETTER_TYPE_CODE_M408 = "M408";
    public static final String LETH_LETTER_TYPE_CODE_M314 = "M314";
    public static final String LETH_LETTER_TYPE_CODE_M411 = "M411";
    public static final String LETH_LETTER_TYPE_CODE_M306 = "M306";
    public static final String LETH_LETTER_TYPE_CODE_M307 = "M307";
    public static final String LETH_LETTER_TYPE_CODE_M308 = "M308";
    public static final String LETH_LETTER_TYPE_CODE_M402 = "M402";
    public static final String LETH_LETTER_TYPE_CODE_M404 = "M404";
    public static final String LETH_LETTER_TYPE_CODE_M200 = "M200";
    public static final String LETH_LETTER_TYPE_CODE_M407 = "M407";
    public static final String LETH_LETTER_TYPE_CODE_M104 = "M104";
    public static final String LETH_LETTER_TYPE_CODE_M412 = "M412";
    public static final String LETH_LETTER_TYPE_CODE_M700 = "M700";
    public static final String LETH_LETTER_TYPE_CODE_M702 = "M702";
    public static final String LETH_LETTER_TYPE_CODE_M703 = "M703";
    public static final String LETH_LETTER_TYPE_CODE_M413 = "M413";
    public static final String LETH_LETTER_TYPE_CODE_M600 = "M600";
    public static final String LETH_LETTER_TYPE_CODE_M304 = "M304";
    public static final String LETH_LETTER_TYPE_CODE_ASSP = "ASSP";
    public static final String LETH_LETTER_TYPE_CODE_E600 = "E600";
    public static final String LETH_LETTER_TYPE_CODE_M313 = "M313";
    public static final String LETH_LETTER_TYPE_CODE_PYPP = "PYPP";
    public static final String LETH_LETTER_TYPE_CODE_M805 = "M805";
    public static final String LETH_LETTER_TYPE_CODE_M801 = "M801";
    public static final String LETH_LETTER_TYPE_CODE_M315 = "M315";
    public static final String LETH_LETTER_TYPE_CODE_A805 = "A805";
    public static final String LETH_LETTER_TYPE_CODE_M500 = "M500";

    // SMS target constants
    public static final String DO_NOT_SEND_SMS_BEFORE = "0800";
    public static final String DO_NOT_SEND_SMS_AFTER = "1800";
    public static final String SMS_FROM = "test_brightersuper@suncorp.com.au";

    // Advisor Weekly Letter constants
    public static final String REGEX_ADVISOR_WEEKLY_LETTER_CSV_FILENAME_PATTERN = "(?i).*\\.csv";
    public static final String ADVISOR_CLIENT_ID = "advisorClientId";
    public static final String ADVLETTER_DOC_TYPE = "Weekly Correspondence Report";
    public static final String ADVISOR_WEEKLY_LETTER_SUBJECT = "Suncorp Superannuation Member Correspondence Summary";
    public static final String ADVSIOR_WEEKLY_LETTER_TEMPLATE = "/SSP/Template/adviser_weekly_email";
    public static final String ADVISOR_NAME = "advisorName";
    public static final String ADVISOR_TYPE = "advisorType";
    public static final String PERSONAL_ADVISOR_NAME_TAG = "leth_mailing_forename";
    public static final String COMPANY_ADVISOR_NAME_TAG = "company_contact_name";
    public static final String ADVISOR_CLIENT_ID_TAG = "broker_client_id";
    public static final String ADVISOR_TAG = "broker";
    public static final String ADV_WEEKLY_LETTER_FILE_NAME = "advWeeklyLetterFileName";
    public static final String ADV_WEEKLY_LETTER_EXCEPTION = "Advisor weekly letter could not be processed";
    public static final String EXCEPTION_OCCURED_VALUE = "Yes";
    public static final String COMMISSION_STATEMENT_EXCEPTION = "Commission Statement letter could not be processed";
    public static final String THIRDT_PARTY_CONTROL_DS_ID = "thirdPartyControlDataSourceIds";
    public static final String THIRDT_PARTY_CONTROL_DS_ID_TEMP = "tempThirdPartyControlDataSourceIds";

    // Employee Alteration From Email Id
    public static final String EMPLOYEE_ALTERATION_FROM_EMAIL = "EmployeeAlterationFromEmail";

    public static final String SONATA_OUTBOUND_CORRO_REQUEST_XML = "SonataOutboundCorroRequestXml";
    public static final String IS_BOUNCE_BACK_MAIL_PACK = "isBounceBackMailPack";
    public static final String BOUNCE_BACK_LETTER_TYPE = "Email Bounceback Letter";

    // constants for bundle fees
    public static final String TAG_ACTR = "actr";
    public static final String TAG_DTRN = "dtrn";
    public static final String TAG_LTST_EXPENSE_CODE = "ltst_expense_code";
    public static final String TAG_TRANSINPERIOD = "transinperiod";
    public static final String TAG_TREV = "trev";
    public static final String TAG_LTST_EFFECTIVE_DATE = "ltst_effective_date";
    public static final String TAG_LTST_FEE_EFFECT_IND = "ltst_fee_effect_ind";
    public static final String TAG_LTST_DEDUCTION_AMOUNT = "ltst_deduction_amount";
    public static final String TAG_LTST_BAL_EFFECT_IND = "ltst_bal_effect_ind";
    public static final String TAG_LTST_TRAN_TYPE_CODE = "ltst_tran_type_code";
    public static final String TAG_LTST_AMOUNT = "ltst_amount";
    public static final String CODE_DRFA = "DRFA";
    public static final String CODE_CRFE = "CRFE";
    public static final String FEES_DEATILS_TAG = "feesDetails";
    public static final String FEES_TAG = "fees";
    public static final String FEES_TYPE_TAG = "feesType";
    public static final String FEES_AMOUNT_TAG = "feesAmount";
    public static final String EFFECTIVE_DATE_TAG = "effectiveDate";
    public static final String FEES_EFFECT_IND_TAG = "feesEffectInd";
    public static final String CODE_BFPS = "BFPS";
    public static final String CODE_AFPS = "AFPS";
    public static final String CODE_SKJA = "SKJA";
    public static final String PERSONAL_ADV_FEE_ONGOING = "Personal Advice fee - Ongoing";
    public static final String PERSONAL_ADV_FEE_ONE_OFF = "Personal Advice fee – One Off";
    public static final String FEE_ADJUSTMENT = "Fee Adjustment";
    public static final String CONTRIBUTION_ROLLOVER_FEE = "Contribution/Rollover Fee";
    public static final String CONTRIBITION_ROLLOVER_COMMISSION = "Contribution/Rollover Commission";
    public static final String CONTRIBUTION_FEE = "Contribution Fee";
    public static final String ADMINISTRATION_FEE = "Administration Fee";
    public static final String APRA_LEVY_FEE = "APRA levy";
    public static final String ADMINISTRATION_FEE_DOLLAR = "Administration Fee - Dollar";
    public static final String PERSONAL_ADV_FEE = "Personal advice fee";
    public static final String WITHDRAWAL_FEE = "Withdrawal fee";
    public static final String INSURANCE_FEES_DEATILS_TAG = "InsuranceFeesDetails";
    public static final String INSURANCE_FEES_LIFE = "Insurance fee - Life cover";
    public static final String INSURANCE_FEES_ADJUSTMENT_LIFE = "Insurance fee adjustment - Life cover";
    public static final String INSURANCE_FEES_TPD = "Insurance fee - TPD cover";
    public static final String INSURANCE_FEES_ADJUSTMENT_TPD = "Insurance fee adjustment - TPD cover";
    public static final String INSURANCE_FEES_IP = "Insurance fee - IP cover";
    public static final String INSURANCE_FEES_ADJUSTMENT_IP = "Insurance fee adjustment - IP cover";
    public static final String INSURANCE_FEES = "Insurance fee";
    public static final String INSURANCE_FEES_ADJUSTMENT = "Insurance fee adjustment";
    public static final String FILENAME = "FileName";
    public static final String ANNUAL_STATEMENT_INPUT_FILENAME = "inputFileName";

    // Constants for removing unwanted transaction for interim and annual statement
    public static final String LDGV_DESCRIPTION = "ldgv_description";
    public static final String MIGRATION_DATE = "Migration Date";
    public static final String PRODUCT_EVERYDAY_SUPER = "Everyday Super";
    public static final String MIGRATION_DATE_FORMAT = "MMM d yyyy hh:mmaaa";
    public static final String MIGRATION_DATE_VALUE = "migrationDate";
    public static final String TAG_TRANSDETAILS = "transdetails";
    public static final String LDIT_TRAN_SHORT_DESCRIPTION = "ldit_tran_short_description";
    public static final String DESC_OPENING_BALANCE = "Opening Balance";
    public static final String DESC_CLOSING_BALANCE = "Closing Balance";
    public static final String TRANSACTION_DATE_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS";
    public static final String LDIT_TRAN_EFF_DATE = "ldit_tran_eff_date";
    public static final String ACCOUNT_NUMBER = "accountNumber";
    public static final String CLIENT_ACCOUNT_RELATIONSHIP_LIST = "clientAccountRelationshipList";
    public static final String RELATIONSHIP_END_DATE_TAG = "endDate";
    public static final String RELATIONSHIPS_TAG = "relationships";
    public static final String PRIMARY_TAG = "primary";
    public static final String RELATIONSHIP_TAG = "relationship";
    public static final String CLIENT_TAG = "client";
    public static final String IS_PRIMARY_TAG = "isPrimary";
    public static final String RELATIONSHIP_ID_TAG = "relationshipId";
    public static final String RELATIONSHIP_DETAILS_TAG = "relationshipDetail";
    public static final String RELATIONSHIP_TYPE_TAG = "relationshipType";
    public static final String ID_TAG = "id";
    public static final String CODE_TAG = "code";
    public static final String DATE_JOINED_TAG = "dateJoined";
    
    // Constants for Rate of return calculation
    public static final String TAG_ACCOUNT_SUMMARY = "accountsummary";
    public static final String EXIT_STATEMENT_END_DATE = "statementEndDate";
    public static final String CALCULATED_RATE_OF_RETURN = "recomputed_rate_of_return_value";
    public static final String COMPONENTS_TAG = "components";
    public static final String SONATA_RATE_OF_RETURN_TAG = "rate_of_return_value";
    public static final String EXIT_CUTOFF_DATE = "2017-07-01";
    public static final String LETH_ACCOUNT_EXIT_DATE = "leth_account_exit_date";
    public static final String GV_STATEMENT_START_DATE = "gvStatementStartDate";
    public static final String GV_STATEMENT_START_DATE_FLAG = "gvStatementStartDateFlag";
    public static final String MIGRATION_CODE_VALUE = "MGRD";
    public static final String GV_VALUE_TAG = "ldgv_value";
    public static final String MIGRATION_OPENING_BALANCE_CODE_VALUE = "OB16";
    public static final String GV_OPENING_BALANCE = "gvOpeningBalance";
    public static final String GV_OPENING_BALANCE_FLAG = "gvOpeningBalanceFlag";
    public static final String SONATA_OPENING_BALANCE_CODE = "OBAL";
    public static final String DEFAULT_STATEMENT_START_DATE = "defaultStatementStartDate";
    public static final String DEFAULT_OPENING_BALANCE = "defaultOpeningBalance";

}
