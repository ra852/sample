////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.communicationservice.bean;

import javax.xml.bind.annotation.XmlElement;

import org.apache.camel.Exchange;

import com.suncorp.ssp.service.constants.communicationservice.CommunicationServiceConstants;

/**
 * The class {@code EasyImageEndpointDetailBean} is used to hold the Easy Image Endpoint details.
 * 
 * @author U383754
 * @since 21/06/2016
 * @version 1.0
 */
public class EasyImageEndpointDetailBean {
    private String endpoint;
    private String username;
    private String pwd;

    /**
     * Accessor for property endpoint.
     * 
     * @return endpoint of type String
     */
    public String getEndpoint() {
        return endpoint;
    }

    /**
     * Mutator for property endpoint.
     * 
     * @return endpoint of type String
     */
    @XmlElement(name = "endpoint")
    public void setEndpoint(String endpoint) {
        this.endpoint = endpoint;
    }

    /**
     * Accessor for property username.
     * 
     * @return username of type String
     */
    public String getUsername() {
        return username;
    }

    /**
     * Mutator for property username.
     * 
     * @return username of type String
     */
    @XmlElement(name = "username")
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * Accessor for property pwd.
     * 
     * @return pwd of type String
     */
    public String getPwd() {
        return pwd;
    }

    /**
     * Mutator for property pwd.
     * 
     * @return pwd of type String
     */
    @XmlElement(name = "pwd")
    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    /**
     * 
     * This method is used to set Easy Image Properties.
     * 
     * @param exchange
     */
    public void setEasyImageProperties(Exchange exchange) {
        exchange.setProperty(CommunicationServiceConstants.ENDPOINT, this.endpoint);
        exchange.setProperty(CommunicationServiceConstants.USER_NAME, this.username);
        exchange.setProperty(CommunicationServiceConstants.PWD, this.pwd);
    }
}
