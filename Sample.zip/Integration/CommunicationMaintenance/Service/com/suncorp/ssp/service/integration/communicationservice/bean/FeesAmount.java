////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.communicationservice.bean;

import java.math.BigDecimal;

/**
 * The class {@code FeesAmount} does this.
 * 
 * @author U384380
 * @since 13/06/2017
 * @version 1.0
 */
public class FeesAmount {

    private double totalCreditAmount;
    private double totalDebitAmount;
    private BigDecimal totalCredit;
    private BigDecimal totalDebit;

    /**
     * Default Constructor.
     */
    public FeesAmount() {
        totalCreditAmount = 0.0;
        totalDebitAmount = 0.0;
        this.totalCredit = new BigDecimal(0);
        this.totalDebit = new BigDecimal(0);
    }

    /**
     * Accessor for property totalCreditAmount.
     * 
     * @return totalCreditAmount of type double
     */
    public double getTotalCreditAmount() {
        return totalCreditAmount;
    }

    /**
     * Mutator for property totalCreditAmount.
     * 
     * @return totalCreditAmount of type double
     */
    public void setTotalCreditAmount(double totalCreditAmount) {
        this.totalCreditAmount = totalCreditAmount;
    }

    /**
     * Accessor for property totalDebitAmount.
     * 
     * @return totalDebitAmount of type double
     */
    public double getTotalDebitAmount() {
        return totalDebitAmount;
    }

    /**
     * Mutator for property totalDebitAmount.
     * 
     * @return totalDebitAmount of type double
     */
    public void setTotalDebitAmount(double totalDebitAmount) {
        this.totalDebitAmount = totalDebitAmount;
    }

    /**
     * Accessor for property totalCredit.
     * 
     * @return totalCredit of type BigDecimal
     */
    public BigDecimal getTotalCredit() {
        return totalCredit;
    }

    /**
     * Mutator for property totalCredit.
     * 
     * @param totalCredit of type BigDecimal
     */
    public void setTotalCredit(BigDecimal totalCredit) {
        this.totalCredit = totalCredit;
    }

    /**
     * Accessor for property totalDebit.
     * 
     * @return totalDebit of type BigDecimal
     */
    public BigDecimal getTotalDebit() {
        return totalDebit;
    }

    /**
     * Mutator for property totalDebit.
     * 
     * @param totalDebit of type BigDecimal
     */
    public void setTotalDebit(BigDecimal totalDebit) {
        this.totalDebit = totalDebit;
    }
}
