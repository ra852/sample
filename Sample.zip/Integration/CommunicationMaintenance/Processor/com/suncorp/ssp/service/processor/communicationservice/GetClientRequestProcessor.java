////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.processor.communicationservice;

import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.component.cxf.common.message.CxfConstants;

import com.sonatacentral.service.v30.callerdetails.CallerDetails;
import com.sonatacentral.service.v30.common.client.GetClientRequestType;
import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.ClientIdentifierType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.communicationservice.CommunicationServiceConstants;

/**
 * The class {@code GetClientRequestProcessor} processes/constructs SOAP request for external service.
 * 
 * @author U383754
 * @since 2015-10-01
 * @version 1.0
 */
public class GetClientRequestProcessor implements Processor {
    private final String className = "GetClientRequestProcessor";
    private final String loggerType = CommunicationServiceConstants.COMMUNICATION_SERVICE_LOGGING_FORMAT;

    /**
     * Extracts the values from end client's request and constructs a new request as per the external service's format.
     * 
     * @param exchange of type {@code Exchange}
     * @throws Exception of type {@code Exception}
     */
    @Override
    public void process(Exchange exchange) throws Exception {
        SILLogger.debug(loggerType, className, "Entering in process method.");
        try {
            GetClientRequestType getClientRequestType = this.constructGetClientRequest(exchange);
            this.setHeaderAndBody(exchange, getClientRequestType);
            SILLogger.debug(loggerType, className, "Exiting from process method");
        } catch (SILException silException) {
            SILLogger.error(loggerType, className, "Exception while creating soap request : " + silException.getMessage());
            exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, CommonConstants.HTTP_BAD_REQUEST_CODE);
            throw new SILException(silException.getMessage());
        } catch (Exception exception) {
            SILLogger.error(loggerType, className, "Exception while creating soap request : " + exception.getMessage());
            throw new Exception(CommunicationServiceConstants.GET_CLIENT_GENERIC_MSG);
        }
    }

    /**
     * This method is used to construct get client request.
     * 
     * @param exchange
     * 
     * @return
     * @throws SILException
     */
    private GetClientRequestType constructGetClientRequest(Exchange exchange) throws SILException {
        SILLogger.debug(loggerType, className, "Entering in constructGetClientRequest method.");
        GetClientRequestType getClientRequestType = new GetClientRequestType();
        CallerDetails callerDetails = SILUtil.createCallerDetails();
        ClientIdentifierType clientIdentifierType = new ClientIdentifierType();
        if (exchange.getProperty(CommunicationServiceConstants.CLIENT_ID) != null) {
            Long clientId = Long.parseLong(exchange.getProperty(CommunicationServiceConstants.CLIENT_ID).toString());
            clientIdentifierType.setId(clientId);
        } else {
            throw new SILException(CommunicationServiceConstants.BLANK_CLIENT_ID);
        }
        getClientRequestType.setCallerDetails(callerDetails);
        getClientRequestType.setClient(clientIdentifierType);
        getClientRequestType.setIncludeAddress(true);
        return getClientRequestType;
    }

    /**
     * This method is used to set header and body in the exchange message.
     * 
     * @param exchange
     * @param getClientRequestType
     */
    private void setHeaderAndBody(Exchange exchange, GetClientRequestType getClientRequestType) {
        SILLogger.debug(loggerType, className, "Entering in setHeaderAndBody method.");
        Map<String, Object> mapHeaders = new HashMap<String, Object>();
        mapHeaders.put(CxfConstants.OPERATION_NAME, CommunicationServiceConstants.GET_CLIENT_OPERATION_NAME);
        mapHeaders.put(CxfConstants.OPERATION_NAMESPACE, CommunicationServiceConstants.GET_CLIENT_OPERATION_NAMESPACE);
        exchange.getIn().setHeaders(mapHeaders);
        exchange.getIn().setBody(getClientRequestType);
    }
}
