////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.processor.communicationservice;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.component.cxf.common.message.CxfConstants;
import org.dom4j.Document;
import org.dom4j.Element;

import au.com.suncorp.services.easydoc.schema._0.DataSourceType;
import au.com.suncorp.services.easydoc.schema._0.TaskType;

import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.communicationservice.CommunicationServiceConstants;
import com.suncorp.ssp.service.integration.communicationservice.util.CommunicationServiceLetterRequestUtil;

/**
 * The class {@code BundleFeesRequestProcessor} bundle the fee blocks into Easy Doc request..
 * 
 * @author U385424
 * @since 20/10/2017
 * @version 1.0
 */
public class BundleFeesRequestProcessor implements Processor {
    private final String className = "BundleFeesRequestProcessor";
    private final String loggerType = CommunicationServiceConstants.COMMUNICATION_SERVICE_LOGGING_FORMAT;

    /**
     * Extracts the values from Sonata outbound letter and bundle them into Easy Doc request..
     * 
     * @param exchange
     * @throws Exception
     */
    @Override
    public void process(Exchange exchange) throws Exception {
        SILLogger.debug(loggerType, className, "Entering bundleFeesIntoEasyDocDataSource()");
        TaskType outboundRequest = (TaskType) exchange.getProperty(CommunicationServiceConstants.EASY_DOC_REQUEST);
        List<DataSourceType> dataSourceTypeList = outboundRequest.getDataSource();
        String file = (String) exchange.getProperty(CommunicationServiceConstants.SONATA_OUTBOUND_CORRO_REQUEST_XML);
        Document doc = SILUtil.convertXMLFiletoDocument(file);
        Element rootElement = doc.getDocument().getRootElement();
        new CommunicationServiceLetterRequestUtil().bundleAnnualFeesInDataSource(dataSourceTypeList, exchange, rootElement);
        setHeaderAndBody(exchange, outboundRequest);
        SILLogger.debug(loggerType, className, "Exiting bundleFeesIntoEasyDocDataSource()");
    }

    /**
     * Sets the headers and body into the exchange message.
     * 
     * @param exchange of type Exchange
     * @param outboundRequest of type GetAdvisorRequestType
     */
    private void setHeaderAndBody(Exchange exchange, TaskType outboundRequest) {
        SILLogger.debug(loggerType, className, "Entering setHeaderAndBody()");
        Map<String, Object> headers = new HashMap<String, Object>();
        headers.put(CxfConstants.OPERATION_NAME, CommunicationServiceConstants.OPERATION_NAME);
        headers.put(CxfConstants.OPERATION_NAMESPACE, CommunicationServiceConstants.OPERATION_NAMESPACE);
        headers.put(CommunicationServiceConstants.SOAPACTION, CommunicationServiceConstants.OPERATION_NAME);
        exchange.getIn().setHeaders(headers);
        exchange.getIn().setBody(outboundRequest);
        SILLogger.debug(loggerType, className, "Exiting setHeaderAndBody()");
    }

    /**
     * construct letter status message.
     * 
     * @param exchange
     */
    public void constructLetterStatusMessage(Exchange exchange) {
        SILLogger.debug(loggerType, className, "Entering constructLetterStatusMessage()");
        String letterStatusMessage = null;
        String exceptionMessage = exchange.getIn().getHeader(CommonConstants.EXCEPTION_MESSAGE, String.class);
        String exceptionOccured = exchange.getIn().getHeader(CommonConstants.EXCEPTION_OCCURED, String.class);
        if (exceptionMessage != null) {
            letterStatusMessage =
                    new Date() + " | " + CommunicationServiceConstants.FILENAME + " : " +
                            exchange.getProperty(CommunicationServiceConstants.ANNUAL_STATEMENT_INPUT_FILENAME) + " | " +
                            CommunicationServiceConstants.LETH_REQUEST_ID + " : " +
                            exchange.getProperty(CommunicationServiceConstants.LETH_REQUEST_ID) + " | " + "Failure  |  Exception is - " +
                            exceptionMessage + "\r\n";
        } else if (CommunicationServiceConstants.EXCEPTION_OCCURED_VALUE.equals(exceptionOccured)) {
            letterStatusMessage =
                    new Date() + " | " + CommunicationServiceConstants.FILENAME + " : " +
                            exchange.getProperty(CommunicationServiceConstants.ANNUAL_STATEMENT_INPUT_FILENAME) + " | " +
                            CommunicationServiceConstants.LETH_REQUEST_ID + " : " +
                            exchange.getProperty(CommunicationServiceConstants.LETH_REQUEST_ID) + " | " + "Failure  |  Exception is - " +
                            CommunicationServiceConstants.COMMUNICATION_SERVICE_REQUEST_NOT_PROCESSED + "\r\n";
        } else {
            letterStatusMessage = retrieveSuccessMessage(exchange);
        }
        exchange.getIn().setBody(letterStatusMessage);
    }

    /**
     * Does this.
     *
     * @param exchange
     * @return
     */
    private String retrieveSuccessMessage(Exchange exchange) {
        String letterStatusMessage;
        letterStatusMessage =
                new Date() + " | " + CommunicationServiceConstants.FILENAME + " : " +
                        exchange.getProperty(CommunicationServiceConstants.ANNUAL_STATEMENT_INPUT_FILENAME) + " | " +
                        CommunicationServiceConstants.LETH_REQUEST_ID + " : " +
                        exchange.getProperty(CommunicationServiceConstants.LETH_REQUEST_ID) + " | " + "Success \r\n";
        return letterStatusMessage;
    }

}
