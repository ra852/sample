////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.processor.communicationservice;

import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.component.cxf.common.message.CxfConstants;

import com.sonatacentral.service.v30.callerdetails.CallerDetails;
import com.sonatacentral.service.v30.common.saleschannel.GetAdvisorRequestType;
import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.AdvisorIdentifierType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.communicationservice.CommunicationServiceConstants;
import com.suncorp.ssp.service.constants.saleschannelservice.SalesChannelServiceConstants;

/**
 * The class {@code CommissionStatementRequestProcessor} processes/constructs SOAP request for external service.
 * 
 * @author U386868
 * @since 21/06/2016
 * @version 1.0
 */
public class GetAdvisorDetailsRequestProcessor implements Processor {
    private final String className = "GetAdvisorDetailsRequestProcessor";

    /**
     * Extracts the values from end client's request and constructs a new request as per the external service's format.
     * 
     * @param exchange
     *            of type Exchange
     * @throws Exception
     */
    @Override
    public void process(Exchange exchange) throws SILException {
        SILLogger.debug(CommunicationServiceConstants.COMMUNICATION_SERVICE_LOGGING_FORMAT, className, "Entering process()");
        try {
            exchange.setProperty(CommonConstants.RESPONSE_CLASS_NAME, SalesChannelServiceConstants.GET_ADVISOR_RESPONSE_CLASS_NAME);
            GetAdvisorRequestType getAdvisorRequest = constructGetAdvisorRequest(exchange);
            this.setHeaderAndBody(exchange, getAdvisorRequest);
            SILLogger.debug(CommunicationServiceConstants.COMMUNICATION_SERVICE_LOGGING_FORMAT, className, "Exiting process()");
        } catch (Exception exception) {
            SILLogger.error(CommunicationServiceConstants.COMMUNICATION_SERVICE_LOGGING_FORMAT, className, SILUtil.getReqExMsg(exception));
            throw new SILException(exception.getMessage());
        }
    }

    /**
     * Construct Get Advisor Request.
     * 
     * @param exchange
     * @return
     */
    private GetAdvisorRequestType constructGetAdvisorRequest(Exchange exchange) {
        SILLogger.debug(CommunicationServiceConstants.COMMUNICATION_SERVICE_LOGGING_FORMAT, className, "Entering constructGetAdvisorRequest()");
        CallerDetails callerDetails = SILUtil.createCallerDetails();
        GetAdvisorRequestType getAdvisorRequest = new GetAdvisorRequestType();
        AdvisorIdentifierType advisorIdentifier = new AdvisorIdentifierType();
        if (exchange.getProperty(CommunicationServiceConstants.DEALER_NUMBER) != null) {
            advisorIdentifier.setAdvisorNumber(exchange.getProperty(CommunicationServiceConstants.DEALER_NUMBER).toString());
        } else if (exchange.getProperty(CommunicationServiceConstants.ADVISOR_CLIENT_ID) != null) {
            advisorIdentifier.setClientId(Long.parseLong((String) exchange.getProperty(CommunicationServiceConstants.ADVISOR_CLIENT_ID)));
            getAdvisorRequest.setIncludeAddress(true);
            getAdvisorRequest.setIncludeAdvisorClientDetail(true);
        }
        getAdvisorRequest.setAdvisor(advisorIdentifier);
        getAdvisorRequest.setCallerDetails(callerDetails);
        return getAdvisorRequest;
    }

    /**
     * Sets the headers and body into the exchange message.
     * 
     * @param exchange
     *            of type Exchange
     * @param getAdvisorRequest
     *            of type GetAdvisorRequestType
     */
    private void setHeaderAndBody(Exchange exchange, GetAdvisorRequestType getAdvisorRequest) {
        SILLogger.debug(SalesChannelServiceConstants.GET_ADVISOR_LOGGING_FORMAT, className, "Entering setHeaderAndBody()");
        Map<String, Object> headers = new HashMap<String, Object>();
        headers.put(CxfConstants.OPERATION_NAME, SalesChannelServiceConstants.GET_ADVISOR_OPERATION_NAME);
        headers.put(CxfConstants.OPERATION_NAMESPACE, SalesChannelServiceConstants.OPERATION_NAMESPACE);
        exchange.getIn().setHeaders(headers);
        exchange.getIn().setBody(getAdvisorRequest);
    }
}
