////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.processor.communicationservice;

import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.component.cxf.common.message.CxfConstants;

import au.com.suncorp.services.easydoc.schema._0.TaskType;

import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.communicationservice.CommunicationServiceConstants;
import com.suncorp.ssp.service.integration.communicationservice.util.EasyDocRequestUtil;

/**
 * The class {@code EasyDocRequestProcessor} processes/constructs SOAP request for external service.
 * 
 * @author U386868
 * @since 22/06/2016
 * @version 1.0
 */
public class EasyDocRequestProcessor implements Processor {
    private final String className = "EasyDocRequestProcessor";

    /**
     * Extracts the values from end client's request and constructs a new request as per the external service's format.
     * 
     * @param exchange of type Exchange
     * @throws Exception
     */
    @Override
    public void process(Exchange exchange) throws SILException {
        SILLogger.debug(CommunicationServiceConstants.COMMUNICATION_SERVICE_LOGGING_FORMAT, className, "Entering process()");
        try {
            exchange.setProperty(CommonConstants.RESPONSE_CLASS_NAME, CommunicationServiceConstants.COMMUNICATION_SERVICE_RESPONCE_CLASS_NAME);
            EasyDocRequestUtil requestUtil = new EasyDocRequestUtil();
            TaskType outboundRequest = requestUtil.constructEasyDocRequest(exchange);
            setHeaderAndBody(exchange, outboundRequest);
            SILLogger.debug(CommunicationServiceConstants.COMMUNICATION_SERVICE_LOGGING_FORMAT, className, "Exiting process()");
        } catch (SILException silException) {
            SILLogger.error(CommunicationServiceConstants.COMMUNICATION_SERVICE_LOGGING_FORMAT, className, SILUtil.getReqExMsg(silException));
            throw new SILException(SILUtil.getReqExMsg(silException));
        } catch (Exception exception) {
            SILLogger.error(CommunicationServiceConstants.COMMUNICATION_SERVICE_LOGGING_FORMAT, className, SILUtil.getReqExMsg(exception));
            throw new SILException(exception.getMessage());
        }
    }

    /**
     * Sets the headers and body into the exchange message.
     * 
     * @param exchange of type Exchange
     * @param outboundRequest of type GetAdvisorRequestType
     */
    private void setHeaderAndBody(Exchange exchange, TaskType outboundRequest) {
        SILLogger.debug(CommunicationServiceConstants.COMMUNICATION_SERVICE_LOGGING_FORMAT, className, "Entering setHeaderAndBody()");
        Map<String, Object> headers = new HashMap<String, Object>();
        headers.put(CxfConstants.OPERATION_NAME, CommunicationServiceConstants.OPERATION_NAME);
        headers.put(CxfConstants.OPERATION_NAMESPACE, CommunicationServiceConstants.OPERATION_NAMESPACE);
        headers.put(CommunicationServiceConstants.SOAPACTION, CommunicationServiceConstants.OPERATION_NAME);
        exchange.getIn().setHeaders(headers);
        exchange.getIn().setBody(outboundRequest);
    }
}
