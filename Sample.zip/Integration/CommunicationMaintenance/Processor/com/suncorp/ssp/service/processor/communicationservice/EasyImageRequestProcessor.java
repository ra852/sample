////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.processor.communicationservice;

import java.io.File;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;

import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.communicationservice.CommunicationServiceConstants;
import com.suncorp.ssp.service.integration.communicationservice.util.EasyImageRequestUtil;

/**
 * The class {@code EasyImageRequestProcessor} processes/constructs SOAP request for external service.
 * 
 * @author U386868
 * @since 20/06/2016
 * @version 1.0
 */
public class EasyImageRequestProcessor implements Processor {
    private final String className = "EasyImageRequestProcessor";
    private EasyImageRequestUtil requestUtil = new EasyImageRequestUtil();

    /**
     * Extracts the values from end client's request and constructs a new request as per the external service's format.
     * 
     * @param exchange
     *            of type Exchange
     * @throws Exception
     */
    @Override
    public void process(Exchange exchange) throws SILException {
        SILLogger.debug(CommunicationServiceConstants.COMMUNICATION_SERVICE_LOGGING_FORMAT, className, "Entering process()");
        try {
            File fileContent = exchange.getIn().getBody(File.class);
            if (fileContent.getName().contains("Weekly_Report")) {
                String advisorNumber = fileContent.getName().split("_")[0];
                exchange.setProperty(CommunicationServiceConstants.ADVISOR_CLIENT_ID, advisorNumber);
                exchange.setProperty(CommunicationServiceConstants.ADV_WEEKLY_LETTER_FILE_NAME, fileContent.getName().split(".csv")[0]);
            } else {
                String dealerNumber = fileContent.getName().split("_")[0];
                exchange.setProperty(CommunicationServiceConstants.DEALER_NUMBER, dealerNumber);
            }
            requestUtil.createEasyImageOutboundRequest(exchange, fileContent);
            SILLogger.debug(CommunicationServiceConstants.COMMUNICATION_SERVICE_LOGGING_FORMAT, className, "Exiting process()");
        } catch (SILException silException) {
            SILLogger.error(CommunicationServiceConstants.COMMUNICATION_SERVICE_LOGGING_FORMAT, className, SILUtil.getReqExMsg(silException));
            throw new SILException(SILUtil.getReqExMsg(silException));
        } catch (Exception exception) {
            SILLogger.error(CommunicationServiceConstants.COMMUNICATION_SERVICE_LOGGING_FORMAT, className, SILUtil.getReqExMsg(exception));
            throw new SILException(exception.getMessage());
        }
    }

    /**
     * Extracts the values from end client's request and constructs a new request as per the external service's format.
     * 
     * @param exchange
     *            of type Exchange
     * @throws Exception
     */
    public void processToCallEasyImageService(Exchange exchange) throws SILException {
        SILLogger.debug(CommunicationServiceConstants.COMMUNICATION_SERVICE_LOGGING_FORMAT, className, "Entering process1()");
        try {
            requestUtil.callSOAPMessage(exchange);
            SILLogger.debug(CommunicationServiceConstants.COMMUNICATION_SERVICE_LOGGING_FORMAT, className, "Exiting process1()");
        } catch (Exception exception) {
            SILLogger.error(CommunicationServiceConstants.COMMUNICATION_SERVICE_LOGGING_FORMAT, className, SILUtil.getReqExMsg(exception));
            throw new SILException(exception.getMessage());
        }
    }
}
