////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.processor.accountservice;

import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.component.cxf.common.message.CxfConstants;
import org.apache.cxf.jaxrs.utils.JAXRSUtils;

import com.sonatacentral.service.v30.wrap.account.GetAccountDetailsRequestType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.util.GetAccountDetailsListRequestUtil;

/**
 * The class {@code GetAccountDetailsListRequestProcessor} construct's SOAP request for external service.
 * 
 * @author U387938
 * @since 29/01/2016
 * @version 1.0
 */
public class GetAccountDetailsListRequestProcessor implements Processor {
    private final String className = "GetAccountDetailsListRequestProcessor";

    /**
     * Creates a SOAP request for Sonata's StartJob (GetAccountDetails) service and sets its into the exchange body.
     * 
     * @param exchange
     * @throws Exception
     */
    @Override
    public void process(Exchange exchange) throws Exception {
        SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className, "Entering in process method.");
        try {
            exchange.setProperty(CommonConstants.RESPONSE_CLASS_NAME, AccountServiceConstants.GET_ACC_DETAILS_RESPONSE_CLASS_NAME);

            MultivaluedMap<String, String> inboundRequest =
                    JAXRSUtils.getStructuredParams(exchange.getIn().getHeader(Exchange.HTTP_QUERY, String.class), "&", true, true);
            GetAccountDetailsListRequestUtil requestUtil = new GetAccountDetailsListRequestUtil(inboundRequest);
            GetAccountDetailsRequestType outboundRequest = requestUtil.createOutboundRequest();

            this.setBodyAndHeader(exchange, outboundRequest);
        } catch (SILException silException) {
            SILLogger.error(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className, "Exception while creating soap request" +
                    silException.getMessage());
            exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, CommonConstants.HTTP_BAD_REQUEST_CODE);
            throw new SILException(silException.getMessage());
        } catch (Exception exception) {
            SILLogger.error(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className, "Exception while creating soap request" +
                    exception.getMessage());
            throw new Exception(AccountServiceConstants.GET_ACC_DETAILS_LIST_GENERIC_MSG);
        }
    }

    /**
     * This method is used to set body and header of service in exchange message.
     * 
     * @param exchange
     * @param accountDetailsRequestType
     */
    private void setBodyAndHeader(Exchange exchange, GetAccountDetailsRequestType accountDetailsRequestType) {
        SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className, "Entering in setBodyAndHeader method.");
        Map<String, Object> mapHeaders = new HashMap<String, Object>();
        mapHeaders.put(CxfConstants.OPERATION_NAME, AccountServiceConstants.GET_ACC_DETAILS_LIST_OPERATION_NAME);
        mapHeaders.put(CxfConstants.OPERATION_NAMESPACE, AccountServiceConstants.OPERATION_NAMESPACE);
        exchange.getIn().setHeaders(mapHeaders);
        exchange.getIn().setBody(accountDetailsRequestType);
    }
}
