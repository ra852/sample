////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.processor.accountservice;

import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.component.cxf.common.message.CxfConstants;

import com.sonatacentral.service.v30.wrap.account.SaveRegularContributionPlanRequestType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.SaveRegularContributionPlanRequestBean;
import com.suncorp.ssp.service.integration.accountservice.util.SaveRegularContributionRequestUtil;

/**
 * The class {@code SaveRegularContributionPlanRequestProcessor} is used to construct the request for SONATA.
 * 
 * @author U383754
 * @since 27/05/2016
 * @version 1.0
 */
public class SaveRegularContributionPlanRequestProcessor implements Processor {
    private final String cName = "SaveRegularContributionPlanRequestProcessor";

    /**
     * This method is used to construct request for SONATA.
     * 
     * @param exchange
     * @throws Exception
     */
    @Override
    public void process(Exchange exchange) throws Exception {
        SILLogger.debug(AccountServiceConstants.SAVE_REG_CONT_LOGGING_FORMAT, cName, "Entering process()");
        try {
            exchange.setProperty(CommonConstants.RESPONSE_CLASS_NAME, AccountServiceConstants.SAVE_REG_CONT_RESPONSE_CLASS_NAME);
            SaveRegularContributionPlanRequestBean inbound = exchange.getIn().getBody(SaveRegularContributionPlanRequestBean.class);
            SaveRegularContributionRequestUtil util = new SaveRegularContributionRequestUtil(inbound);
            SaveRegularContributionPlanRequestType saveRegularContributionPlanRequestType = util.getRegularContributionPlanDetails();
            saveRegularContributionPlanRequestType.setCallerDetails(SILUtil.createCallerDetails());
            this.setHeaderAndBody(exchange, saveRegularContributionPlanRequestType);
        } catch (SILException silException) {
            SILLogger.error(AccountServiceConstants.SAVE_REG_CONT_LOGGING_FORMAT, cName, SILUtil.getReqExMsg(silException));
            exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, CommonConstants.HTTP_BAD_REQUEST_CODE);
            throw new SILException(SILUtil.getReqExMsg(silException));
        } catch (Exception exception) {
            SILLogger.error(AccountServiceConstants.SAVE_REG_CONT_LOGGING_FORMAT, cName, SILUtil.getReqExMsg(exception));
            throw new Exception(AccountServiceConstants.SAVE_REG_CONT_GENERIC_MSG);
        }
        SILLogger.debug(AccountServiceConstants.SAVE_REG_CONT_LOGGING_FORMAT, cName, "Exiting process()");
    }

    /**
     * This method is used to set header and body in the exchange message.
     * 
     * @param exchange
     * @param getClientRequestType
     */
    private void setHeaderAndBody(Exchange exchange, SaveRegularContributionPlanRequestType saveRegularContributionPlanRequestType) {
        Map<String, Object> mapHeaders = new HashMap<String, Object>();
        mapHeaders.put(CxfConstants.OPERATION_NAME, AccountServiceConstants.SAVE_REG_CONT_OPERATION_NAME);
        mapHeaders.put(CxfConstants.OPERATION_NAMESPACE, AccountServiceConstants.OPERATION_NAMESPACE);
        exchange.getIn().setHeaders(mapHeaders);
        exchange.getIn().setBody(saveRegularContributionPlanRequestType);
    }
}
