////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.processor.accountservice;

import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.component.cxf.common.message.CxfConstants;

import com.sonatacentral.service.v30.wrap.account.SaveAccountRequestType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.DeleteThirdPartyRelationshipRequest;
import com.suncorp.ssp.service.integration.accountservice.util.DelThirdPartyRelationshipRequestUtil;

/**
 * The class {@code DeleteThirdPartyRelationshipRequestProcessor} processes/constructs SOAP request for external service.
 * 
 * @author u385424
 * @since 17/03/2016
 * @version 1.0
 */
public class DeleteThirdPartyRelationshipRequestProcessor implements Processor {
    private final String className = "DeleteThirdPartyRelationshipRequestProcessor";

    /**
     * Extracts the values from end client's request and constructs a new request as per the external service's format.
     * 
     * @param exchange
     * @throws Exception
     */
    @Override
    public void process(Exchange exchange) throws Exception {
        SILLogger.debug(AccountServiceConstants.DEL_THIRD_PARTY_REL_LOG_FORMAT, className, "Entering process()");
        try {
            exchange.setProperty(CommonConstants.RESPONSE_CLASS_NAME, AccountServiceConstants.DEL_THIRD_PARTY_REL_RESPONSE_CLASS_NAME);
            DeleteThirdPartyRelationshipRequest inboundRequest = exchange.getIn().getBody(DeleteThirdPartyRelationshipRequest.class);
            DelThirdPartyRelationshipRequestUtil requestUtil = new DelThirdPartyRelationshipRequestUtil(inboundRequest);
            SaveAccountRequestType outboundRequest = new SaveAccountRequestType();
            outboundRequest.setCallerDetails(SILUtil.createCallerDetails());
            requestUtil.createOutboundRequest(outboundRequest);
            setHeaderAndBody(exchange, outboundRequest);
            SILLogger.debug(AccountServiceConstants.DEL_THIRD_PARTY_REL_LOG_FORMAT, className, "Exiting process()");
        } catch (SILException silEx) {
            SILLogger.error(AccountServiceConstants.DEL_THIRD_PARTY_REL_LOG_FORMAT, className, SILUtil.getReqExMsg(silEx));
            exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, CommonConstants.HTTP_BAD_REQUEST_CODE);
            throw new SILException(silEx.getMessage());
        } catch (Exception ex) {
            SILLogger.error(AccountServiceConstants.DEL_THIRD_PARTY_REL_LOG_FORMAT, className, SILUtil.getReqExMsg(ex));
            throw new SILException(AccountServiceConstants.DELETE_THIRD_PARTY_RELATIONSHIP_REQUEST_NOT_PROCESSED);
        }
    }

    /**
     * Sets the headers and body into the exchange message.
     * 
     * @param exchange of type Exchange
     * @param outboundRequest of type SaveAccountRequestType
     */
    private void setHeaderAndBody(Exchange exchange, SaveAccountRequestType outboundRequest) {
        Map<String, Object> headers = new HashMap<String, Object>();
        headers.put(CxfConstants.OPERATION_NAME, AccountServiceConstants.DELETE_THIRD_PARTY_RELATIONSHIP_OPERATION_NAME);
        headers.put(CxfConstants.OPERATION_NAMESPACE, AccountServiceConstants.OPERATION_NAMESPACE);
        exchange.getIn().setHeaders(headers);
        exchange.getIn().setBody(outboundRequest);
    }
}
