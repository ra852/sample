////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.processor.accountservice;

import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.component.cxf.common.message.CxfConstants;
import org.apache.cxf.jaxrs.utils.JAXRSUtils;

import com.sonatacentral.service.v30.wrap.account.GetAccountExpenseRequestType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.util.GetAccountExpenseRequestUtil;

/**
 * The class {@code GetAccountExpenseRequestProcessor} construct's SOAP request for external service.
 * 
 * @author U383754
 * @since 29/01/2016
 * @version 1.0
 */
public class GetAccountExpenseRequestProcessor implements Processor {
    private final String className = "GetAccountExpenseRequestProcessor";

    /**
     * Creates a SOAP request for Sonata's StartJob (GetAccountExpense) service and sets its into the exchange body.
     * 
     * @param exchange
     * @throws Exception
     */
    @Override
    public void process(Exchange exchange) throws Exception {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in process method.");
        try {
            exchange.setProperty(CommonConstants.RESPONSE_CLASS_NAME, AccountServiceConstants.GET_ACC_EXPENSE_RESPONSE_CLASS_NAME);
            MultivaluedMap<String, String> inboundRequest =
                    JAXRSUtils.getStructuredParams(exchange.getIn().getHeader(Exchange.HTTP_QUERY, String.class), "&", true, true);
            GetAccountExpenseRequestUtil accountExpenseRequestUtil = new GetAccountExpenseRequestUtil(inboundRequest);
            GetAccountExpenseRequestType outboundRequest = accountExpenseRequestUtil.createOutboundRequest();
            String serviceCheck = accountExpenseRequestUtil.getIsAccountNumberRequest();
            exchange.setProperty(AccountServiceConstants.GET_EXPENSE_SERVICE_CHECK_PARAM, serviceCheck);
            this.setBodyAndHeader(exchange, outboundRequest);
        } catch (SILException silException) {
            SILLogger.error(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className,
                    "Exception while creating soap request" + silException.getMessage());
            exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, CommonConstants.HTTP_BAD_REQUEST_CODE);
            throw new SILException(silException.getMessage());
        } catch (Exception exception) {
            SILLogger.error(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className,
                    "Exception while creating soap request" + exception.getMessage());
            throw new Exception(AccountServiceConstants.GET_ACC_EXPENSE_GENERIC_MSG);
        }
    }

    /**
     * This method is used to set body and header of service in exchange message.
     * 
     * @param exchange
     * @param getAccountExpenseRequestType
     */
    private void setBodyAndHeader(Exchange exchange, GetAccountExpenseRequestType getAccountExpenseRequestType) {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in setBodyAndHeader()");
        Map<String, Object> mapHeaders = new HashMap<String, Object>();
        mapHeaders.put(CxfConstants.OPERATION_NAME, AccountServiceConstants.GET_ACC_EXPENSE_OPERATION_NAME);
        mapHeaders.put(CxfConstants.OPERATION_NAMESPACE, AccountServiceConstants.OPERATION_NAMESPACE);
        exchange.getIn().setHeaders(mapHeaders);
        exchange.getIn().setBody(getAccountExpenseRequestType);
    }
}
