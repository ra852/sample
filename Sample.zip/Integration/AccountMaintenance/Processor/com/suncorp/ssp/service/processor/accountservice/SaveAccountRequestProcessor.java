////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.processor.accountservice;

import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.component.cxf.common.message.CxfConstants;

import com.sonatacentral.service.v30.wrap.account.SaveAccountRequestType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.SaveAccountRequest;
import com.suncorp.ssp.service.integration.accountservice.util.SaveAccountRequestUtil;

/**
 * The class {@code SaveAccountRequestProcessor} does this.
 * 
 * @author U383847
 * @since 29/03/2016
 * @version 1.0
 */
public class SaveAccountRequestProcessor implements Processor {
    private final String className = "SaveAccountRequestProcessor";

    /**
     * Extracts the values from end client's request and constructs a new request as per the external service's format.
     * 
     * @param exchange
     * @throws Exception
     */
    @Override
    public void process(Exchange exchange) throws Exception {
        SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_LOGGING_FORMAT, className, "Entering into process");
        try {
            exchange.setProperty(CommonConstants.RESPONSE_CLASS_NAME, AccountServiceConstants.SAVE_ACCOUNT_RESPONSE_CLASS_NAME);
            SaveAccountRequest saveAccountRequest = exchange.getIn().getBody(SaveAccountRequest.class);
            SaveAccountRequestType saveAccountRequestType = new SaveAccountRequestType();
            if (saveAccountRequest != null) {
                saveAccountRequestType.setCallerDetails(SILUtil.createCallerDetails());
                SaveAccountRequestUtil saveAccountRequestUtil = new SaveAccountRequestUtil(saveAccountRequest);
                saveAccountRequestUtil.setAccountRequestDetails(saveAccountRequestType);
            }
            setHeadersBody(exchange, saveAccountRequestType);
            SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_LOGGING_FORMAT, className, "Exiting from process");
        } catch (SILException silException) {
            SILLogger.error(AccountServiceConstants.SAVE_ACCOUNT_LOGGING_FORMAT, className, SILUtil.getReqExMsg(silException));
            exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, CommonConstants.HTTP_BAD_REQUEST_CODE);
            throw new SILException(SILUtil.getReqExMsg(silException));
        } catch (Exception exception) {
            SILLogger.error(AccountServiceConstants.SAVE_ACCOUNT_LOGGING_FORMAT, className, SILUtil.getReqExMsg(exception));
            throw new SILException(AccountServiceConstants.SAVE_ACCOUNT_GENERIC_MSG);
        }
    }

    /**
     * Set Headers and Body for SOAP Request.
     * 
     * @param exchange
     * @param saveAccountRequestType
     */
    private void setHeadersBody(Exchange exchange, SaveAccountRequestType saveAccountRequestType) {
        SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_LOGGING_FORMAT, className, "Setting Headers and Body for SOAP Request");
        Map<String, Object> mapHeaders = new HashMap<String, Object>();
        mapHeaders.put(CxfConstants.OPERATION_NAME, AccountServiceConstants.SAVE_ACCOUNT_OPERATION_NAME);
        mapHeaders.put(CxfConstants.OPERATION_NAMESPACE, AccountServiceConstants.OPERATION_NAMESPACE);
        exchange.getIn().setHeaders(mapHeaders);
        exchange.getIn().setBody(saveAccountRequestType);
    }
}
