////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.processor.accountservice;

import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.Response;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.component.cxf.common.message.CxfConstants;

import com.sonatacentral.service.v30.callerdetails.CallerDetails;
import com.sonatacentral.service.v30.common.client.GetClientRequestType;
import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.ClientIdentifierType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.constants.clientservice.ClientServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.BeneficiaryDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.GetBeneficiaryResponse;

/**
 * The class {@code TempProcessor} does this.
 * 
 * @author u384380
 * @since 30/10/2015
 * @version 1.0
 */
public class GetBeneficiaryDOBRequestProcessor implements Processor {

    /**
     * This method will construct request object to get DOB of the beneficiary.
     * 
     * @param exchange of type Exchange
     * @throws Exception
     */
    @Override
    public void process(Exchange exchange) throws Exception {
        SILLogger.debug(AccountServiceConstants.GET_BENEFICIARY_LOGGING_FORMAT, "GetBeneficiaryDOBRequestProcessor", "Entering in process method");
        try {
            Response response = (Response) exchange.getProperty(CommonConstants.SAVE_RESPONSE);
            GetBeneficiaryResponse getBeneficiaryResponse = (GetBeneficiaryResponse) response.getEntity();
            int currentLoopIndex = (int) exchange.getProperty(CommonConstants.CAMEL_LOOP_INDEX);
            String clientId = ((BeneficiaryDetails) getBeneficiaryResponse.getBeneficiary().get(currentLoopIndex)).getClientId();
            Map<String, Object> mapHeaders = new HashMap<String, Object>();
            mapHeaders.put(CxfConstants.OPERATION_NAME, ClientServiceConstants.GET_CLIENT_OPERATION_NAME);
            mapHeaders.put(CxfConstants.OPERATION_NAMESPACE, ClientServiceConstants.OPERATION_NAMESPACE);
            exchange.getIn().setHeaders(mapHeaders);
            CallerDetails callerDetails = SILUtil.createCallerDetails();
            ClientIdentifierType clientIdentifierType = new ClientIdentifierType();
            clientIdentifierType.setId(Long.parseLong(clientId));
            GetClientRequestType getClientRequestType = new GetClientRequestType();
            setGetClientRequestParameters(getClientRequestType, clientIdentifierType, callerDetails);
            exchange.getIn().setBody(getClientRequestType);
            SILLogger.debug(AccountServiceConstants.GET_BENEFICIARY_LOGGING_FORMAT, "GetBeneficiaryDOBRequestProcessor",
                    "Exiting from process method");
        } catch (Exception exception) {
            SILLogger.error(AccountServiceConstants.GET_BENEFICIARY_LOGGING_FORMAT, "GetBeneficiaryDOBRequestProcessor",
                    SILUtil.getReqExMsg(exception));
            throw new Exception(AccountServiceConstants.GET_BENEFICIARY_GENERIC_MSG);
        }
    }

    /**
     * This method will set input details for getclient request.
     * 
     * @param getClientRequestType of type GetClientRequestType
     * @param clientIdentifierType of type ClientIdentifierType
     * @param callerdetails of type callerdetails
     */
    private void setGetClientRequestParameters(GetClientRequestType getClientRequestType, ClientIdentifierType clientIdentifierType,
            CallerDetails callerDetails) {
        SILLogger.debug(AccountServiceConstants.GET_BENEFICIARY_LOGGING_FORMAT, "GetBeneficiaryDOBRequestProcessor",
                "Entering in setGetClientRequestParameters method");
        getClientRequestType.setCallerDetails(callerDetails);
        getClientRequestType.setClient(clientIdentifierType);
        getClientRequestType.setIncludeClientDetails(true);
        getClientRequestType.setIncludeAddress(true);
        getClientRequestType.setIncludeBankAccount(true);
        getClientRequestType.setIncludeExternalReference(true);
        getClientRequestType.setIncludeGenericVariable(true);
        getClientRequestType.setIncludeNote(true);
        getClientRequestType.setIncludeClientContext(true);
        getClientRequestType.setIncludeAdvisorGroup(true);
        getClientRequestType.setIncludeNewZealand(true);
        getClientRequestType.setIncludeSouthAfrica(true);
        getClientRequestType.setIncludeAustralia(true);
        getClientRequestType.setIncludeUnitedKingdom(true);
        getClientRequestType.setIncludeWorkDeclaration(true);
        getClientRequestType.setIncludeTaxTreatyDetails(true);
        getClientRequestType.setIncludeCorroDeliveryPreferences(true);
        SILLogger.debug(AccountServiceConstants.GET_BENEFICIARY_LOGGING_FORMAT, "GetBeneficiaryDOBRequestProcessor",
                "Exiting from setGetClientRequestParameters method");
    }
}
