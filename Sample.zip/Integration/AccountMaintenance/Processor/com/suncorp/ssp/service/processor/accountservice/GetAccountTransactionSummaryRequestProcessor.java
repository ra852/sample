////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.processor.accountservice;

import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.camel.Exchange;
import org.apache.camel.component.cxf.common.message.CxfConstants;
import org.apache.cxf.jaxrs.utils.JAXRSUtils;

import com.sonatacentral.service.v30.callerdetails.CallerDetails;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType;
import com.sonatacentral.service.v30.wrap.account.GetAccountTransactionSummaryRequestType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.util.GetAccountTransactionSummaryRequestUtil;

/**
 * The class {@code GetAccountTransactionSummaryRequestProcessor} is used to process request of getAccountTransactionSummary .
 * 
 * @author u385424
 * @since 11/12/2015
 * @version 1.0
 */
public class GetAccountTransactionSummaryRequestProcessor {
    private final String className = "GetAccountTransactionSummaryRequestProcessor";

    /**
     * This method will construct request object for GetAccountTransactionSummary sonata service.
     * 
     * @param exchange
     * @throws Exception
     */
    public void process(Exchange exchange) throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_TRANS_SUMM_LOGGING_FORMAT, className, "Entering process");
        try {
            exchange.setProperty(CommonConstants.RESPONSE_CLASS_NAME, AccountServiceConstants.GET_ACC_TRANS_SUMM_RESPONSE_CLASS_NAME);
            CallerDetails callerDetails = SILUtil.createCallerDetails();
            GetAccountTransactionSummaryRequestType outboundRequest = getAccountTransactionSummaryDetails(exchange, callerDetails);
            setHeaderAndBody(exchange, outboundRequest);
            SILLogger.debug(AccountServiceConstants.GET_ACC_TRANS_SUMM_LOGGING_FORMAT, className, "Exiting process ()");
        } catch (SILException silException) {
            SILLogger.error(AccountServiceConstants.GET_ACC_TRANS_SUMM_LOGGING_FORMAT, className, SILUtil.getReqExMsg(silException));
            exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, CommonConstants.HTTP_BAD_REQUEST_CODE);
            throw new SILException(silException.getMessage());
        } catch (Exception exception) {
            SILLogger.error(AccountServiceConstants.GET_ACC_TRANS_SUMM_LOGGING_FORMAT, className, SILUtil.getReqExMsg(exception));
            throw new SILException(AccountServiceConstants.TRAN_SUMMRY_EXCEPTION_MSG);
        }
    }

    /**
     * This method is used to set data into outbound request .
     * 
     * @param exchange
     * @param callerDetails
     * @returns outboundRequest
     */
    private GetAccountTransactionSummaryRequestType getAccountTransactionSummaryDetails(Exchange exchange, CallerDetails callerDetails)
            throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_TRANS_SUMM_LOGGING_FORMAT, className, "Entering getAccountTransactionSummaryDetails");
        MultivaluedMap<String, String> inboundRequest =
                JAXRSUtils.getStructuredParams(exchange.getIn().getHeader(Exchange.HTTP_QUERY, String.class), "&", true, true);
        GetAccountTransactionSummaryRequestUtil requestUtil = new GetAccountTransactionSummaryRequestUtil(inboundRequest);
        boolean includePricedOnly = requestUtil.createIncludePricedOnly();
        boolean skipTransactionFundGrouping = requestUtil.createSkipTransactionFundGrouping();
        AccountIdentifierType accountIdentifierType = requestUtil.createAccountIdentifierType();
        XMLGregorianCalendar startDate = requestUtil.createStartDate();
        XMLGregorianCalendar endDate = requestUtil.creatEndDate();
        GetAccountTransactionSummaryRequestType outboundRequest =
                requestUtil.createOutboundRequest(callerDetails, includePricedOnly, skipTransactionFundGrouping, accountIdentifierType, startDate,
                        endDate);
        return outboundRequest;
    }

    /**
     * This method is used to set headers and body of search account beneficiary.
     * 
     * @param exchange
     * @param outboundRequest
     */
    private void setHeaderAndBody(Exchange exchange, GetAccountTransactionSummaryRequestType outboundRequest) {
        Map<String, Object> mapHeaders = new HashMap<String, Object>();
        mapHeaders.put(CxfConstants.OPERATION_NAME, AccountServiceConstants.GET_ACC_TRANS_SUMM_OPERATION_NAME);
        mapHeaders.put(CxfConstants.OPERATION_NAMESPACE, AccountServiceConstants.OPERATION_NAMESPACE);
        exchange.getIn().setHeaders(mapHeaders);
        exchange.getIn().setBody(outboundRequest);
    }

}
