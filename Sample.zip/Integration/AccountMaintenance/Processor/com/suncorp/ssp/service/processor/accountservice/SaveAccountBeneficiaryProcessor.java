////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.processor.accountservice;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.component.cxf.common.message.CxfConstants;

import com.sonatacentral.service.v30.callerdetails.CallerDetails;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.BeneficiaryType;
import com.sonatacentral.service.v30.wrap.account.SaveAccountBeneficiaryRequestType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.SaveAccountBeneficiaryRequest;
import com.suncorp.ssp.service.integration.accountservice.util.DeleteAllBeneficiaryRequestUtil;
import com.suncorp.ssp.service.integration.accountservice.util.SaveAccountBeneficiaryRequestUtil;

/**
 * The class {@code SaveAccountBeneficiaryProcessor} processes/constructs SOAP request for SaveAccountBeneficiary's service.
 * 
 * @author U384381
 * @since 09/12/2015
 * @version 1.0
 */
public class SaveAccountBeneficiaryProcessor implements Processor {
    private final String className = "SaveAccountBeneficiaryProcessor";

    /**
     * Extracts the values from end client's request and constructs a new request as per the SaveAccountBeneficiary's service.
     * 
     * @param exchange of type Exchange
     * @throws Exception
     */
    @Override
    public void process(Exchange exchange) throws Exception {
        SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Entering process()");
        try {
            exchange.setProperty(CommonConstants.RESPONSE_CLASS_NAME, AccountServiceConstants.SAVE_ACCOUNT_BENEFICIARY_RESPONSE_CLASS_NAME);
            SaveAccountBeneficiaryRequest inboundRequest = exchange.getIn().getBody(SaveAccountBeneficiaryRequest.class);
            if (exchange.getProperty(AccountServiceConstants.SAVE_BENEFICIARY_DELETEALL_REQUEST) == null) {
                exchange.setProperty(AccountServiceConstants.SAVE_BENEFICIARY_DELETEALL_REQUEST, inboundRequest);
            }
            inboundRequest = (SaveAccountBeneficiaryRequest) exchange.getProperty(AccountServiceConstants.SAVE_BENEFICIARY_DELETEALL_REQUEST);
            SaveAccountBeneficiaryRequestType outboundRequest = new SaveAccountBeneficiaryRequestType();
            CallerDetails callerDetails = SILUtil.createCallerDetails();
            outboundRequest = saveBeneficiaryFlowCheck(exchange, inboundRequest, callerDetails);
            setHeaderAndBody(exchange, outboundRequest);
            SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Exiting process()");
        } catch (SILException silEx) {
            SILLogger.error(AccountServiceConstants.SAVE_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, SILUtil.getReqExMsg(silEx));
            exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, CommonConstants.HTTP_BAD_REQUEST_CODE);
            throw new SILException(silEx.getMessage());
        } catch (Exception ex) {
            SILLogger.error(AccountServiceConstants.SAVE_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, SILUtil.getReqExMsg(ex));
            throw new SILException(AccountServiceConstants.SAVE_ACCOUNT_BENEFICIARY_REQUEST_NOT_PROCESSED);
        }
    }

    /**
     * 
     * This method decides whether the flow is deleteAll flow or savebeneficiary flow.
     *
     * @param exchange
     * @param inboundRequest
     * @param callerDetails
     * @return
     * @throws Exception
     */
    private SaveAccountBeneficiaryRequestType saveBeneficiaryFlowCheck(Exchange exchange, SaveAccountBeneficiaryRequest inboundRequest,
            CallerDetails callerDetails) throws SILException {
        Integer deleteStepCount;
        SaveAccountBeneficiaryRequestType outboundRequest;
        SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Entering saveBeneficiaryFlowCheck()");
        if (inboundRequest.getDeleteAll() != null && Boolean.valueOf(inboundRequest.getDeleteAll())) {
            deleteStepCount = setDeleteAllIterationNo(exchange);
            DeleteAllBeneficiaryRequestUtil deleteAllBeneficiaryRequestUtil =
                    new DeleteAllBeneficiaryRequestUtil(inboundRequest, deleteStepCount);
            AccountIdentifierType account = deleteAllBeneficiaryRequestUtil.createAccountIdentifierType();
            List<BeneficiaryType> beneficiaryList = deleteAllBeneficiaryRequestUtil.createBeneficiaryList();
            outboundRequest = deleteAllBeneficiaryRequestUtil.createOutboundRequest(callerDetails, account, beneficiaryList);
        } else {
            SaveAccountBeneficiaryRequestUtil requestUtil = new SaveAccountBeneficiaryRequestUtil(inboundRequest);
            AccountIdentifierType account = requestUtil.createAccountIdentifierType();
            List<BeneficiaryType> beneficiaryList = requestUtil.createBeneficiaryList();
            outboundRequest = requestUtil.createOutboundRequest(callerDetails, account, beneficiaryList);
        }
        SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Exiting saveBeneficiaryFlowCheck()");
        return outboundRequest;
    }

    /**
     * This method sets the iteration number in exchange.
     *
     * @param exchange
     * @return
     */
    private Integer setDeleteAllIterationNo(Exchange exchange) {
        Integer deleteStepCount;
        SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Entering setDeleteAllIterationNo()");
        if (exchange.getProperty(AccountServiceConstants.SAVE_BENEFICIARY_DELETEALL_FLAG) == null) {
            deleteStepCount = 1;
            exchange.setProperty(AccountServiceConstants.SAVE_BENEFICIARY_DELETEALL_FLAG, deleteStepCount);
        } else {
            deleteStepCount = 2;
            exchange.setProperty(AccountServiceConstants.SAVE_BENEFICIARY_DELETEALL_FLAG, deleteStepCount);
        }
        SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Exiting setDeleteAllIterationNo()");
        return deleteStepCount;
    }

    /**
     * Sets the headers and body into the exchange message.
     * 
     * @param exchange of type Exchange
     * @param outboundRequest of type SaveAccountBeneficiaryRequestType
     */
    private void setHeaderAndBody(Exchange exchange, SaveAccountBeneficiaryRequestType outboundRequest) {
        Map<String, Object> headers = new HashMap<String, Object>();
        headers.put(CxfConstants.OPERATION_NAME, AccountServiceConstants.SAVE_ACCOUNT_BENEFICIARY_OPERATION_NAME);
        headers.put(CxfConstants.OPERATION_NAMESPACE, AccountServiceConstants.OPERATION_NAMESPACE);
        exchange.getIn().setHeaders(headers);
        exchange.getIn().setBody(outboundRequest);
    }
}
