////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.processor.accountservice;

import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.component.cxf.common.message.CxfConstants;
import org.apache.cxf.jaxrs.utils.JAXRSUtils;

import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType.AccountNumber;
import com.sonatacentral.service.v30.wrap.account.GetAccountUnitHoldingDetailRequestType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;

/**
 * The class {@code GetAccountUnitHoldingRequestProcessor} processes/constructs SOAP request for external service.
 * 
 * @author U385424
 * @since 26/10/2016
 * @version 1.0
 */
public class GetAccountUnitHoldingRequestProcessor implements Processor {
    private final String className = "GetAccountUnitHoldingRequestProcessor";

    /**
     * Extracts the values from end client's request and constructs a new request as per the external service's format.
     * 
     * @param exchange of type Exchange
     * @throws Exception
     */
    @Override
    public void process(Exchange exchange) throws Exception {
        SILLogger.debug(AccountServiceConstants.ACCOUNT_HOLDINGS_LOGGING_FORMAT, className, "Entering process()");
        try {
            exchange.setProperty(CommonConstants.RESPONSE_CLASS_NAME, AccountServiceConstants.GET_ACCOUNT_UNIT_HOLDINGS_RESPONSE_CLASS_NAME);
            MultivaluedMap<String, String> inboundRequest =
                    JAXRSUtils.getStructuredParams(exchange.getIn().getHeader(Exchange.HTTP_QUERY, String.class), "&", true, true);
            GetAccountUnitHoldingDetailRequestType outboundRequest = new GetAccountUnitHoldingDetailRequestType();
            outboundRequest.setCallerDetails(SILUtil.createCallerDetails());
            outboundRequest.setAccount(retrieveAccountIdentifier(inboundRequest));
            setHeaderAndBody(exchange, outboundRequest);
            SILLogger.debug(AccountServiceConstants.ACCOUNT_HOLDINGS_LOGGING_FORMAT, className, "Exiting process()");
        } catch (SILException silEx) {
            SILLogger.error(AccountServiceConstants.ACCOUNT_HOLDINGS_LOGGING_FORMAT, className, SILUtil.getReqExMsg(silEx));
            exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, CommonConstants.HTTP_BAD_REQUEST_CODE);
            throw new SILException(silEx.getMessage());
        } catch (Exception exception) {
            SILLogger.error(AccountServiceConstants.ACCOUNT_HOLDINGS_LOGGING_FORMAT, className, SILUtil.getReqExMsg(exception));
            throw new SILException(AccountServiceConstants.GET_ACCOUNT_UNIT_HOLDINGS_REQ_NOT_PROCESSED);
        }
    }

    /**
     * This method is used to retrieve query string and set it to outbound request.
     * 
     * @param inboundRequest
     * @return
     * @throws SILException
     */
    private AccountIdentifierType retrieveAccountIdentifier(MultivaluedMap<String, String> inboundRequest) throws SILException {
        AccountIdentifierType accountIdentifierType = new AccountIdentifierType();
        if (inboundRequest.containsKey("accountNumber") && inboundRequest.get("accountNumber").get(0) != null) {
            AccountNumber accountNumber = new AccountNumber();
            accountNumber.setAccountNo(inboundRequest.get("accountNumber").get(0));
            accountIdentifierType.setAccountNumber(accountNumber);
        } else {
            throw new SILException(AccountServiceConstants.INVALID_ACCOUNTNUMBER_MESSAGE);
        }
        return accountIdentifierType;
    }

    /**
     * Sets the headers and body into the exchange message.
     * 
     * @param exchange of type Exchange
     * @param outboundRequest of type GetAccountTransactionListRequestType
     */
    private void setHeaderAndBody(Exchange exchange, GetAccountUnitHoldingDetailRequestType outboundRequest) {
        SILLogger.debug(AccountServiceConstants.ACCOUNT_HOLDINGS_LOGGING_FORMAT, className, "Entering setHeaderAndBody()");
        Map<String, Object> headers = new HashMap<String, Object>();
        headers.put(CxfConstants.OPERATION_NAME, AccountServiceConstants.GET_ACCOUNT_UNIT_HOLDINGS_OPERATION_NAME);
        headers.put(CxfConstants.OPERATION_NAMESPACE, AccountServiceConstants.OPERATION_NAMESPACE);
        exchange.getIn().setHeaders(headers);
        exchange.getIn().setBody(outboundRequest);
    }
}
