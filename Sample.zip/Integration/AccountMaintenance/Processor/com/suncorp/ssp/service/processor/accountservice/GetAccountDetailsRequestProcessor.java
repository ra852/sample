////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.processor.accountservice;

import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.component.cxf.common.message.CxfConstants;
import org.apache.cxf.jaxrs.utils.JAXRSUtils;

import com.sonatacentral.service.v30.callerdetails.CallerDetails;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType;
import com.sonatacentral.service.v30.service.ServiceRequestType;
import com.sonatacentral.service.v30.wrap.account.GetAccountDetailsRequestType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;

/**
 * The class {@code GetAccountDetailsRequestProcessor} does this.
 * 
 * @author u386898
 * @since 15/12/2015
 * @version 1.0
 */
public class GetAccountDetailsRequestProcessor implements Processor {
    private final String className = "GetAccountDetailsRequestProcessor";

    /**
     * This method will construct request object for getAccpountDetails sonata service.
     * 
     * @param exchange of type Exchange
     * @throws Exception
     */
    @Override
    public void process(Exchange exchange) throws Exception {
        try {
            SILLogger.debug(AccountServiceConstants.GET_ACCOUNTDETAILS_LOGGING_FORMAT, className, "Entered in process method");
            exchange.setProperty(CommonConstants.RESPONSE_CLASS_NAME, AccountServiceConstants.GET_ACCOUNTDETAILS_RESPONSE_CLASS_NAME);
            String entertedAccountNumber = null;
            entertedAccountNumber = validateInputParameters(exchange);
            GetAccountDetailsRequestType getAccountDetailsRequestType = new GetAccountDetailsRequestType();
            setRequestParameterForGetAccountDetails(getAccountDetailsRequestType, entertedAccountNumber);
            setHeaderParameters(exchange);
            exchange.getIn().setBody(getAccountDetailsRequestType);
        } catch (NumberFormatException numberFormatException) {
            logging(className, "Exception while parsing account number." + "Exiting from process method");
            exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, CommonConstants.HTTP_BAD_REQUEST_CODE);
            throw new SILException(AccountServiceConstants.INVALID_ACCOUNT_NUMBER_MESSAGE);
        } catch (SILException silException) {
            logging(className, "Exception while creating soap request : " + silException.getMessage() + "Exiting from process method");
            exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, CommonConstants.HTTP_BAD_REQUEST_CODE);
            throw new SILException(silException.getMessage());
        } catch (Exception exception) {
            logging(className, "Exception while creating soap request : " + AccountServiceConstants.INVALID_ACCOUNT_NUMBER_MESSAGE +
                    "Exiting from process method");
            throw new SILException(AccountServiceConstants.INVALID_ACCOUNT_NUMBER_MESSAGE);
        }
    }

    /**
     * This method will set input parameters required for sonata service calling.
     * 
     * @param getAccountDetailsRequestType of type GetAccountDetailsRequestType
     * @param enteredAccountNo of type String
     */
    private void setRequestParameterForGetAccountDetails(GetAccountDetailsRequestType getAccountDetailsRequestType, String enteredAccountNo) {
        SILLogger.debug(AccountServiceConstants.GET_ACCOUNTDETAILS_LOGGING_FORMAT, className,
                "Entering in setRequestParameterForGetAccountDetails method");
        CallerDetails callerDetails = SILUtil.createCallerDetails();

        ServiceRequestType serviceRequestType = new ServiceRequestType();
        serviceRequestType.setCallerDetails(callerDetails);

        AccountIdentifierType accountIdentifierType = new AccountIdentifierType();
        AccountIdentifierType.AccountNumber accountNumber = new AccountIdentifierType.AccountNumber();
        accountNumber.setAccountNo(enteredAccountNo);
        accountIdentifierType.setAccountNumber(accountNumber);

        GetAccountDetailsRequestType.AccountDetails accountDetails = new GetAccountDetailsRequestType.AccountDetails();
        accountDetails.setAccount(accountIdentifierType);
        getAccountDetailsRequestType.getAccountDetails().add(accountDetails);
        // TODO: includeExternalReference flag has set always 'true' for retrieving data related only externalReference
        getAccountDetailsRequestType.setIncludeExternalReference(true);

        getAccountDetailsRequestType.setCallerDetails(callerDetails);

        SILLogger.debug(AccountServiceConstants.GET_ACCOUNTDETAILS_LOGGING_FORMAT, className,
                "Exiting from setRequestParameterForGetAccountDetails method");
    }

    /**
     * This method will validate input parameter to SIL service.
     * 
     * @param exchange of type Exchange
     */
    private String validateInputParameters(Exchange exchange) throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACCOUNTDETAILS_LOGGING_FORMAT, className, "Entering in validateInputParameters method");
        String entertedAccountNumber = null;
        String getAccountDetailsString = exchange.getIn().getHeader(Exchange.HTTP_QUERY, String.class);
        MultivaluedMap<String, String> getAccountDetailsQueryMap = JAXRSUtils.getStructuredParams(getAccountDetailsString, "&", true, true);

        if (getAccountDetailsQueryMap.containsKey(AccountServiceConstants.ACCOUNT_NUMBER) &&
                getAccountDetailsQueryMap.get(AccountServiceConstants.ACCOUNT_NUMBER).get(0) != null) {
            entertedAccountNumber = new String(getAccountDetailsQueryMap.get(AccountServiceConstants.ACCOUNT_NUMBER).get(0));
        } else {
            throw new SILException(AccountServiceConstants.INVALID_REQUEST_MESSAGE);
        }
        SILLogger.debug(AccountServiceConstants.GET_ACCOUNTDETAILS_LOGGING_FORMAT, className, "Exiting from validateInputParameters method");
        return entertedAccountNumber;
    }

    /**
     * This method will set header parameters required for calling sonata service.
     * 
     * @param exchange of type Exchange
     */
    private void setHeaderParameters(Exchange exchange) {
        SILLogger.debug(AccountServiceConstants.GET_BENEFICIARY_LOGGING_FORMAT, "GetBeneficiaryRequestProcessor",
                "Entering in setHeaderParameters method");
        Map<String, Object> mapHeaders = new HashMap<String, Object>();
        mapHeaders.put(CxfConstants.OPERATION_NAME, AccountServiceConstants.GET_ACCOUNTDETAILS_OPERATION_NAME);
        mapHeaders.put(CxfConstants.OPERATION_NAMESPACE, AccountServiceConstants.OPERATION_NAMESPACE);
        exchange.getIn().setHeaders(mapHeaders);
        SILLogger.debug(AccountServiceConstants.GET_ACCOUNTDETAILS_LOGGING_FORMAT, className, "Exiting from setHeaderParameters method");
    }

    /**
     * This is the common method to log error and info message for this class.
     * 
     * @param className
     * @param errorLoggerMessage
     */
    private void logging(String className, String errorLoggerMessage) {
        SILLogger.error(AccountServiceConstants.GET_ACCOUNTDETAILS_LOGGING_FORMAT, className, errorLoggerMessage);
    }

}
