////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.processor.accountservice;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.core.MultivaluedMap;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.spi.Registry;
import org.apache.cxf.jaxrs.utils.JAXRSUtils;

import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.GetFamilyLinkingDetailsResponse;
import com.suncorp.ssp.service.integration.accountservice.bo.GetFamilyLinkingDetailsRequestBO;
import com.suncorp.ssp.service.integration.termsandconditionservice.bean.OdsDBProperties;

/**
 * The class {@code GetFamilyLinkingDetailsProcessor} does this.
 *
 * @author U385424
 * @since 15/11/2016
 * @version 1.0
 */
public class GetFamilyLinkingDetailsProcessor implements Processor {
    private final String className = "GetFamilyLinkingDetailsProcessor";
    private OdsDBProperties odsDBProperties;

    /**
     * Extracts the values from end client's request and constructs a new request to fetch data from ODS database.
     * 
     * @param exchange of type Exchange
     * @throws Exception
     */
    @Override
    public void process(Exchange exchange) throws Exception {
        SILLogger.debug(AccountServiceConstants.GET_FAMILY_LINKING_DETAILS_LOGGING_FORMAT, className, "Entering in process method.");
        try {
            exchange.setProperty(CommonConstants.RESPONSE_CLASS_NAME, AccountServiceConstants.GET_FAMILY_LINKING_DETAILS_RESPONSE_CLASS_NAME);
            String accountNumber = getAccountNumberFromQueryString(exchange);
            GetFamilyLinkingDetailsResponse outboundResponseList = injectPropertiesForOdsDb(exchange, accountNumber);
            exchange.getIn().setBody(outboundResponseList);
            SILLogger.debug(AccountServiceConstants.GET_FAMILY_LINKING_DETAILS_LOGGING_FORMAT, className, "Exiting from process method");
        } catch (SILException silException) {
            SILLogger.error(AccountServiceConstants.GET_FAMILY_LINKING_DETAILS_LOGGING_FORMAT, className,
                    "Exception while creating soap request : " + silException.getMessage());
            exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, CommonConstants.HTTP_BAD_REQUEST_CODE);
            throw new SILException(silException.getMessage());
        } catch (Exception exception) {
            SILLogger.error(AccountServiceConstants.GET_FAMILY_LINKING_DETAILS_LOGGING_FORMAT, className,
                    "Exception while creating soap request" + exception.getMessage());
            throw new Exception(AccountServiceConstants.GET_FAMILY_LINKING_DETAILS_GENERIC_MSG);
        }
    }

    /**
     * 
     * This method is used to get the client Id from query string.
     * 
     * @param exchange
     * @return the client Id
     * @throws SILException
     */
    private String getAccountNumberFromQueryString(Exchange exchange) throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_FAMILY_LINKING_DETAILS_LOGGING_FORMAT, className, "Entering getAccountNumberFromQueryString");
        String accountNumber = null;
        String getFamilyLinkingQryString = exchange.getIn().getHeader(Exchange.HTTP_QUERY, String.class);
        MultivaluedMap<String, String> getFamilyLinkingQryMap = JAXRSUtils.getStructuredParams(getFamilyLinkingQryString, "&", true, true);
        if (getFamilyLinkingQryMap.containsKey(AccountServiceConstants.ACCOUNT_NUMBER) &&
                getFamilyLinkingQryMap.get(AccountServiceConstants.ACCOUNT_NUMBER).get(0) != null) {
            accountNumber = getFamilyLinkingQryMap.get(AccountServiceConstants.ACCOUNT_NUMBER).get(0);
        } else {
            throw new SILException(AccountServiceConstants.INVALID_REQUEST_MESSAGE);
        }
        return accountNumber;
    }

    /**
     * 
     * This method is used to inject Properties For Ods Db.
     * 
     * @param exchange
     * @param advisorId
     * @return
     * @throws SILException
     */
    public GetFamilyLinkingDetailsResponse injectPropertiesForOdsDb(Exchange exchange, String accountNumber) throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_FAMILY_LINKING_DETAILS_LOGGING_FORMAT, className, "Entering injectPropertiesForOdsDb()");
        Registry registry = exchange.getContext().getRegistry();
        this.odsDBProperties = (OdsDBProperties) registry.lookupByName("odsDbBean");
        GetFamilyLinkingDetailsResponse outboundResponseList = null;
        GetFamilyLinkingDetailsRequestBO conditionRequestBO = new GetFamilyLinkingDetailsRequestBO();
        List<String> inputParams = new ArrayList<String>();
        if (this.odsDBProperties != null) {
            inputParams.add(0, accountNumber);
            inputParams.add(1, this.odsDBProperties.getOdsSchema());
            outboundResponseList =
                    conditionRequestBO.getFamilyLinkingDetailsDaoCall(inputParams, this.odsDBProperties.getOdsUrl(),
                            this.odsDBProperties.getOdsUsername(), this.odsDBProperties.getOdsPswd());
        }
        SILLogger.debug(AccountServiceConstants.GET_FAMILY_LINKING_DETAILS_LOGGING_FORMAT, className, "Exiting injectPropertiesForOdsDb()");
        return outboundResponseList;
    }
}
