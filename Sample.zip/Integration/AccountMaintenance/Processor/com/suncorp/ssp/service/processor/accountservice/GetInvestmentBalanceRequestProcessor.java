////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.processor.accountservice;

import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;
import javax.xml.datatype.XMLGregorianCalendar;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.component.cxf.common.message.CxfConstants;
import org.apache.cxf.jaxrs.utils.JAXRSUtils;

import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType;
import com.sonatacentral.service.v30.wrap.account.GetAccountTransactionSummaryRequestType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.util.GetInvestmentBalanceRequestUtil;

/**
 * The class {@code GetInvestmentBalanceRequestProcessor} processes/constructs SOAP request for external service.
 * 
 * @author U384381
 * @since 28/12/2015
 * @version 1.0
 */
public class GetInvestmentBalanceRequestProcessor implements Processor {
    private final String className = "GetInvestmentBalanceRequestProcessor";

    /**
     * Extracts the values from end client's request and constructs a new request as per the external service's format.
     * 
     * @param exchange of type Exchanges
     * @throws Exception
     */
    public void process(Exchange exchange) throws Exception {
        SILLogger.debug(AccountServiceConstants.GET_INVESTMENT_BAL_LOG_FORMAT, className, "Entering process()");
        try {
            exchange.setProperty(CommonConstants.RESPONSE_CLASS_NAME, AccountServiceConstants.GET_INVESTMENT_BALANCE_RESPONSE_CLASS_NAME);
            MultivaluedMap<String, String> inboundRequest =
                    JAXRSUtils.getStructuredParams(exchange.getIn().getHeader(Exchange.HTTP_QUERY, String.class), "&", true, true);
            GetInvestmentBalanceRequestUtil requestUtil = new GetInvestmentBalanceRequestUtil(inboundRequest);
            AccountIdentifierType accountIdentifierType = requestUtil.createAccountIdentifierType();
            Boolean skipTransactionFundGrouping = requestUtil.createSkipTransactionFundGrouping();
            XMLGregorianCalendar startDate = requestUtil.createStartDate();
            XMLGregorianCalendar endDate = requestUtil.creatEndDate();
            exchange.setProperty(AccountServiceConstants.START_DATE, startDate.toString().split("T")[0]);
            GetAccountTransactionSummaryRequestType outboundRequest =
                    requestUtil.createOutboundRequest(accountIdentifierType, startDate, endDate, skipTransactionFundGrouping);
            setHeaderAndBody(exchange, outboundRequest);
            SILLogger.debug(AccountServiceConstants.GET_INVESTMENT_BAL_LOG_FORMAT, className, "Exiting process()");
        } catch (SILException silEx) {
            SILLogger.error(AccountServiceConstants.GET_INVESTMENT_BAL_LOG_FORMAT, className, SILUtil.getReqExMsg(silEx));
            exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, CommonConstants.HTTP_BAD_REQUEST_CODE);
            throw new SILException(silEx.getMessage());
        } catch (Exception ex) {
            SILLogger.error(AccountServiceConstants.GET_INVESTMENT_BAL_LOG_FORMAT, className, SILUtil.getReqExMsg(ex));
            throw new SILException(AccountServiceConstants.GET_INVESTMENT_BALANCE_REQUEST_NOT_PROCESSED);
        }
    }

    /**
     * Sets the headers and body into the exchange message.
     * 
     * @param exchange of type Exchange
     * @param outboundRequest of type GetAccountTransactionSummaryRequestType
     */
    private void setHeaderAndBody(Exchange exchange, GetAccountTransactionSummaryRequestType outboundRequest) {
        SILLogger.debug(AccountServiceConstants.GET_INVESTMENT_BAL_LOG_FORMAT, className, "Entering setHeaderAndBody()");
        Map<String, Object> mapHeaders = new HashMap<String, Object>();
        mapHeaders.put(CxfConstants.OPERATION_NAME, AccountServiceConstants.GET_ACC_TRANS_SUMM_OPERATION_NAME);
        mapHeaders.put(CxfConstants.OPERATION_NAMESPACE, AccountServiceConstants.OPERATION_NAMESPACE);
        exchange.getIn().setHeaders(mapHeaders);
        exchange.getIn().setBody(outboundRequest);
        SILLogger.debug(AccountServiceConstants.GET_INVESTMENT_BAL_LOG_FORMAT, className, "Exiting setHeaderAndBody()");
    }
}
