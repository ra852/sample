////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.processor.accountservice;

import java.util.HashMap;
import java.util.Map;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.component.cxf.common.message.CxfConstants;

import com.sonatacentral.service.v30.wrap.account.SaveAccountExpenseRequestType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.SaveAccountExpenseRequest;
import com.suncorp.ssp.service.integration.accountservice.util.SaveAccountExpenseRequestUtil;
/**
 * The class {@code SaveAccountExpenseRequestProcessor} construct's SOAP request for external service.
 * 
 * @author U387938
 * @since 20/03/2016
 * @version 1.0
 */
public class SaveAccountExpenseRequestProcessor implements Processor {
    private final String className = "SaveAccountExpenseRequestProcessor";

    /**
     * Creates a SOAP request for Sonata's StartJob (SaveAccountExpense) service and sets its into the exchange body.
     * 
     * @param exchange
     * @throws Exception
     */
    @Override
    public void process(Exchange exchange) throws Exception {
        SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_EXPENSE_LOGGING_FORMAT, className, "Entering in process method.");
        try {
            exchange.setProperty(CommonConstants.RESPONSE_CLASS_NAME, AccountServiceConstants.SAVE_ACCOUNT_EXPENSE_RESPONSE_CLASS_NAME);
            SaveAccountExpenseRequest inboundRequest = exchange.getIn().getBody(SaveAccountExpenseRequest.class);
            SaveAccountExpenseRequestUtil saveAccountExpenseRequestUtil = new SaveAccountExpenseRequestUtil(inboundRequest);
            SaveAccountExpenseRequestType outboundRequest = saveAccountExpenseRequestUtil.createOutboundRequest();
            this.setBodyAndHeader(exchange, outboundRequest);
 
        } catch (SILException silException) {
            SILLogger.error(AccountServiceConstants.SAVE_ACCOUNT_EXPENSE_LOGGING_FORMAT, className, SILUtil.getReqExMsg(silException));
            exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, CommonConstants.HTTP_BAD_REQUEST_CODE);
            throw new SILException(silException.getMessage());
        } catch (Exception exception) {
            SILLogger.error(AccountServiceConstants.SAVE_ACCOUNT_EXPENSE_LOGGING_FORMAT, className, SILUtil.getReqExMsg(exception));
            throw new Exception(AccountServiceConstants.SAVE_ACCOUNT_EXPENSE_GENERIC_MSG);
        }
    }

    /**
     * This method is used to set body and header of service in exchange message.
     * 
     * @param exchange
     * @param accountDetailsRequestType
     */
    private void setBodyAndHeader(Exchange exchange, SaveAccountExpenseRequestType saveAccountExpenseRequestType) {
        SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_EXPENSE_LOGGING_FORMAT, className, "Entering in setBodyAndHeader method.");
        Map<String, Object> mapHeaders = new HashMap<String, Object>();
        mapHeaders.put(CxfConstants.OPERATION_NAME, AccountServiceConstants.SAVE_ACCOUNT_EXPENSE_OPERATION_NAME);
        mapHeaders.put(CxfConstants.OPERATION_NAMESPACE, AccountServiceConstants.OPERATION_NAMESPACE);
        exchange.getIn().setHeaders(mapHeaders);
        exchange.getIn().setBody(saveAccountExpenseRequestType);
    }
}
