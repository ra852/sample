////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.processor.accountservice;

import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.MultivaluedMap;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.component.cxf.common.message.CxfConstants;
import org.apache.cxf.jaxrs.utils.JAXRSUtils;

import com.sonatacentral.service.v30.callerdetails.CallerDetails;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType;
import com.sonatacentral.service.v30.service.ServiceRequestType;
import com.sonatacentral.service.v30.wrap.account.GetAccountBeneficiaryRequestType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;

/**
 * The class {@code GetBeneficiaryRequestProcessor} does this.
 * 
 * @author u384380
 * @since 28/10/2015
 * @version 1.0
 */
public class GetBeneficiaryRequestProcessor implements Processor {

    /**
     * This method will construct request object for getBeneficiary sonata service.
     * 
     * @param exchange of type Exchange
     * @throws Exception
     */
    @Override
    public void process(Exchange exchange) throws Exception {
        SILLogger.debug(AccountServiceConstants.GET_BENEFICIARY_LOGGING_FORMAT, "GetBeneficiaryRequestProcessor", "Entering in process method");
        try {
            exchange.setProperty(CommonConstants.RESPONSE_CLASS_NAME, AccountServiceConstants.RESPONSE_CLASS_NAME);
            String entertedAccountNumber = null;
            entertedAccountNumber = validateInputParameters(exchange);
            GetAccountBeneficiaryRequestType getAccountBeneficiaryRequestType = new GetAccountBeneficiaryRequestType();
            setRequestParameterForGetBeneficiary(getAccountBeneficiaryRequestType, entertedAccountNumber);
            setHeaderParameters(exchange);
            exchange.getIn().setBody(getAccountBeneficiaryRequestType);
            SILLogger.debug(AccountServiceConstants.GET_BENEFICIARY_LOGGING_FORMAT, "GetBeneficiaryRequestProcessor", "Exiting from process method");
        } catch (SILException silException) {
            SILLogger.error(AccountServiceConstants.GET_BENEFICIARY_LOGGING_FORMAT, "GetBeneficiaryRequestProcessor",
                    "Exception while creating soap request : " + silException.getMessage());
            exchange.getIn().setHeader(Exchange.HTTP_RESPONSE_CODE, CommonConstants.HTTP_BAD_REQUEST_CODE);
            throw new SILException(silException.getMessage());
        } catch (Exception exception) {
            SILLogger.error(AccountServiceConstants.GET_BENEFICIARY_LOGGING_FORMAT, "GetBeneficiaryRequestProcessor",
                    "Exception while creating soap request : " + exception.getMessage());
            throw new Exception(AccountServiceConstants.GET_BENEFICIARY_GENERIC_MSG);
        }
    }

    /**
     * This method will set input parameters required for sonata service calling.
     * 
     * @param getAccountBeneficiaryRequestType of type GetAccountBeneficiaryRequestType
     * @param enteredAccountNo of type String
     */
    private void setRequestParameterForGetBeneficiary(GetAccountBeneficiaryRequestType getAccountBeneficiaryRequestType, String enteredAccountNo) {
        SILLogger.debug(AccountServiceConstants.GET_BENEFICIARY_LOGGING_FORMAT, "GetBeneficiaryRequestProcessor",
                "Entering in setRequestParameterForGetBeneficiary method");
        CallerDetails callerDetails = SILUtil.createCallerDetails();

        ServiceRequestType serviceRequestType = new ServiceRequestType();
        serviceRequestType.setCallerDetails(callerDetails);

        AccountIdentifierType accountIdentifierType = new AccountIdentifierType();
        AccountIdentifierType.AccountNumber accountNumber = new AccountIdentifierType.AccountNumber();
        accountNumber.setAccountNo(enteredAccountNo);
        accountIdentifierType.setAccountNumber(accountNumber);

        getAccountBeneficiaryRequestType.setAccount(accountIdentifierType);
        getAccountBeneficiaryRequestType.setCallerDetails(callerDetails);
        SILLogger.debug(AccountServiceConstants.GET_BENEFICIARY_LOGGING_FORMAT, "GetBeneficiaryRequestProcessor",
                "Exiting from setRequestParameterForGetBeneficiary method");
    }

    /**
     * This method will validate input parameter to SIL service.
     * 
     * @param exchange of type Exchange
     */
    private String validateInputParameters(Exchange exchange) throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_BENEFICIARY_LOGGING_FORMAT, "GetBeneficiaryRequestProcessor",
                "Entering in validateInputParameters method");
        String entertedAccountNumber = null;
        String getBeneficiaryqueryString = exchange.getIn().getHeader(Exchange.HTTP_QUERY, String.class);
        MultivaluedMap<String, String> getBeneficiaryQueryMap = JAXRSUtils.getStructuredParams(getBeneficiaryqueryString, "&", true, true);

        if (getBeneficiaryQueryMap.containsKey(AccountServiceConstants.ACCOUNT_NUMBER) &&
                getBeneficiaryQueryMap.get(AccountServiceConstants.ACCOUNT_NUMBER).get(0) != null) {
            entertedAccountNumber = new String(getBeneficiaryQueryMap.get(AccountServiceConstants.ACCOUNT_NUMBER).get(0));
        } else {
            throw new SILException(AccountServiceConstants.INVALID_REQUEST_MESSAGE);
        }
        SILLogger.debug(AccountServiceConstants.GET_BENEFICIARY_LOGGING_FORMAT, "GetBeneficiaryRequestProcessor",
                "Exiting from validateInputParameters method");
        return entertedAccountNumber;
    }

    /**
     * This method will set header parameters required for calling sonata service.
     * 
     * @param exchange of type Exchange
     */
    private void setHeaderParameters(Exchange exchange) {
        SILLogger.debug(AccountServiceConstants.GET_BENEFICIARY_LOGGING_FORMAT, "GetBeneficiaryRequestProcessor",
                "Entering in setHeaderParameters method");
        Map<String, Object> mapHeaders = new HashMap<String, Object>();
        mapHeaders.put(CxfConstants.OPERATION_NAME, AccountServiceConstants.GET_BENEFICIARY_OPERATION_NAME);
        mapHeaders.put(CxfConstants.OPERATION_NAMESPACE, AccountServiceConstants.OPERATION_NAMESPACE);
        exchange.getIn().setHeaders(mapHeaders);
        SILLogger.debug(AccountServiceConstants.GET_BENEFICIARY_LOGGING_FORMAT, "GetBeneficiaryRequestProcessor",
                "Exiting from setHeaderParameters method");
    }
}
