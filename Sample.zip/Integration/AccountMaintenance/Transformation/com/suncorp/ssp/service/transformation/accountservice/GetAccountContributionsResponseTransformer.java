////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.transformation.accountservice;

import javax.ws.rs.core.Response;

import org.apache.camel.Exchange;

import com.sonatacentral.service.v30.wrap.account.GetAccountContributionsResponseType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.GetAccountContributionsResponse;
import com.suncorp.ssp.service.integration.accountservice.util.GetAccountContributionsResponseUtil;

/**
 * The class {@code GetAccountContributionsResponseTransformer} transforms the response received from external service, to a specified format for
 * end-client.
 * 
 * @author U201468
 * @since 19/09/2017
 * @version 1.0
 */
public class GetAccountContributionsResponseTransformer {
    private String className = "GetAccountContributionsResponseTransformer";

    /**
     * Extracts the values from external service's response, to forward to the end client.
     * 
     * @param exchange
     * @throws Exception
     */
    public void transform(Exchange exchange) throws SILException {
        try {
            SILLogger.debug(AccountServiceConstants.GET_ACCOUNT_CONTRIBUTIONS_LOGGING_FORMAT, className, "transform()");
            GetAccountContributionsResponseType inboundResponse = exchange.getIn().getBody(GetAccountContributionsResponseType.class);
            GetAccountContributionsResponseUtil responseUtil = new GetAccountContributionsResponseUtil(inboundResponse);
            GetAccountContributionsResponse outboundResponse = responseUtil.createOutboundResponse();
            Response response = Response.status(Response.Status.OK).entity(outboundResponse).build();
            exchange.getIn().setBody(response);
        } catch (Exception exception) {
            SILLogger.error(AccountServiceConstants.GET_ACCOUNT_CONTRIBUTIONS_LOGGING_FORMAT, className, SILUtil.getRespExMsg(exception));
            throw new SILException(AccountServiceConstants.DELETE_THIRD_PARTY_RELATIONSHIP_RESPONSE_NOT_PROCESSED);
        }
    }
}
