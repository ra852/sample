////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.transformation.accountservice;

import javax.ws.rs.core.Response;

import org.apache.camel.Exchange;

import com.sonatacentral.service.v30.wrap.account.SaveRegularContributionPlanResponseType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.SaveRegularContributionPlanResponseBean;
import com.suncorp.ssp.service.integration.accountservice.util.SaveRegularContributionResponseUtil;

/**
 * The class {@code SaveRegularContributionPlanResponseTransformer} is used to transform the response for external System.
 * 
 * @author U383754
 * @since 30/05/2016
 * @version 1.0
 */
public class SaveRegularContributionPlanResponseTransformer {

    private final String cName = "SaveRegularContributionPlanResponseTransformer";

    /**
     * This method is used to extract the required values for consumer system.
     * 
     * @param exchange
     * @throws SILException
     */
    public void transform(Exchange exchange) throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_REG_CONT_LOGGING_FORMAT, cName, "Entering transform()");
        try {
            SaveRegularContributionPlanResponseType planResponseType = exchange.getIn().getBody(SaveRegularContributionPlanResponseType.class);
            SaveRegularContributionResponseUtil util = new SaveRegularContributionResponseUtil(planResponseType);
            SaveRegularContributionPlanResponseBean outbound = util.getOutboundResponse();
            Response response = Response.status(Response.Status.OK).entity(outbound).build();
            exchange.getIn().setBody(response);
            SILLogger.debug(AccountServiceConstants.SAVE_REG_CONT_LOGGING_FORMAT, cName, "Exiting transform()");
        } catch (SILException silException) {
            SILLogger.error(AccountServiceConstants.SAVE_REG_CONT_LOGGING_FORMAT, cName, SILUtil.getRespExMsg(silException));
            throw new SILException(SILUtil.getRespExMsg(silException));
        } catch (Exception exc) {
            SILLogger.error(AccountServiceConstants.SAVE_REG_CONT_LOGGING_FORMAT, cName, SILUtil.getRespExMsg(exc));
            throw new SILException(SILUtil.getRespExMsg(exc));
        }
    }
}
