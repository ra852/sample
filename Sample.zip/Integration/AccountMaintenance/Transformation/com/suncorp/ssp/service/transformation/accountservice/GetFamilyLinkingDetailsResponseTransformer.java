////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.transformation.accountservice;

import javax.ws.rs.core.Response;

import org.apache.camel.Exchange;

import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.termsandconditionservice.bean.GetTermsAndConditionStatusResponse;

/**
 * The class {@code GetFamilyLinkingDetailsResponseTransformer} does this.
 * 
 * @author U385424
 * @since 15/11/2016
 * @version 1.0
 */
public class GetFamilyLinkingDetailsResponseTransformer {
    private final String className = "GetFamilyLinkingDetailsResponseTransformer";

    /**
     * 
     * Extracts the values from external service's response, to forward to the end-client.
     * 
     * @param exchange
     * @throws Exception
     */
    public void transform(Exchange exchange) throws SILException {
        try {
            SILLogger.debug(AccountServiceConstants.GET_FAMILY_LINKING_DETAILS_LOGGING_FORMAT, className, "Entering transform()");
            GetTermsAndConditionStatusResponse outboundResponseList = exchange.getIn().getBody(GetTermsAndConditionStatusResponse.class);
            Response response = Response.status(Response.Status.OK).entity(outboundResponseList).build();
            exchange.getIn().setBody(response);
            SILLogger.debug(AccountServiceConstants.GET_FAMILY_LINKING_DETAILS_LOGGING_FORMAT, className, "Exiting transform()");
        } catch (Exception exception) {
            SILLogger.error(AccountServiceConstants.GET_FAMILY_LINKING_DETAILS_LOGGING_FORMAT, className, SILUtil.getRespExMsg(exception));
            throw new SILException(AccountServiceConstants.GET_FAMILY_LINKING_DETAILS_GENERIC_MSG);
        }

    }
}
