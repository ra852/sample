////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.transformation.accountservice;

import javax.ws.rs.core.Response;

import org.apache.camel.Exchange;

import com.sonatacentral.service.v30.wrap.account.GetAccountDetailsResponseType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.GetPensionDetailsResponse;
import com.suncorp.ssp.service.integration.accountservice.util.GetPensionDetailsResponseUtil;

/**
 * The class {@code GetPensionDetailsResponseTransformer} transforms the response received from external service, to a specified format for
 * end-client.
 * 
 * @author U386868
 * @since 02/04/2016
 * @version 1.0
 */
public class GetPensionDetailsResponseTransformer {
    private final String className = "GetPensionDetailsResponseTransformer";

    /**
     * 
     * Extracts the values from external service's response, to forward to the end-client.
     * 
     * @param exchange
     * @throws Exception
     */
    public void transform(Exchange exchange) throws SILException {
        try {
            SILLogger.debug(AccountServiceConstants.GET_PENSION_DETAILS_LOGGING_FORMAT, className, "Entering transform()");
            GetAccountDetailsResponseType inboundResponse = exchange.getIn().getBody(GetAccountDetailsResponseType.class);
            GetPensionDetailsResponseUtil accountDetailsListResponseUtil = new GetPensionDetailsResponseUtil(inboundResponse);
            GetPensionDetailsResponse outboundResponse = accountDetailsListResponseUtil.createOutboundResponse();
            setExchangeResponse(exchange, outboundResponse);
            SILLogger.debug(AccountServiceConstants.GET_PENSION_DETAILS_LOGGING_FORMAT, className, "Exiting transform()");
        } catch (Exception exception) {
            SILLogger.error(AccountServiceConstants.GET_PENSION_DETAILS_LOGGING_FORMAT, className, SILUtil.getRespExMsg(exception));
            throw new SILException(AccountServiceConstants.GET_ACC_DETAILS_LIST_GENERIC_MSG);
        }

    }

    /**
     * Sets the response into exchange message.
     * 
     * @param exchange of type Exchange
     * @param outboundResponse of type GetPensionDetailsResponse
     */
    private void setExchangeResponse(Exchange exchange, GetPensionDetailsResponse outboundResponse) {
        SILLogger.debug(AccountServiceConstants.GET_PENSION_DETAILS_LOGGING_FORMAT, className, "Entering setExchangeResponse()");
        Response response = Response.status(Response.Status.OK).entity(outboundResponse).build();
        exchange.getIn().setBody(response);
    }
}
