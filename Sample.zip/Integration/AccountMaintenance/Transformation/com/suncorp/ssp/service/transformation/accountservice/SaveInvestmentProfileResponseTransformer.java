////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.transformation.accountservice;

import javax.ws.rs.core.Response;

import org.apache.camel.Exchange;

import com.sonatacentral.service.v30.wrap.account.SaveInvestmentProfileResponseType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.SaveInvestmentProfileResponse;
import com.suncorp.ssp.service.integration.accountservice.util.SaveInvestmentProfileResponseUtil;
/**
 * The class {@code SaveInvestmentProfileResponseTransformer} does this.
 * 
 * @author U387938
 * @since 26/07/2016
 * @version 1.0
 */
public class SaveInvestmentProfileResponseTransformer {

    private final String className = "SaveInvestmentProfileResponseTransformer";

    /**
     * Extracts the values from external service's response, to forward to the Consumer.
     * 
     * @param exchange
     * @throws Exception
     */
    public void transform(Exchange exchange) throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_PROFILE_LOGGING_FORMAT, className, "Entering in transform method");
        try {
            SaveInvestmentProfileResponseType saveInvestmentProfileResponseType = exchange.getIn().getBody(SaveInvestmentProfileResponseType.class);
            SaveInvestmentProfileResponse investmentProfileResponse = new SaveInvestmentProfileResponse();
            SaveInvestmentProfileResponseUtil saveInvestmentProfileResponseUtil =
                    new SaveInvestmentProfileResponseUtil(saveInvestmentProfileResponseType);
            saveInvestmentProfileResponseUtil.setSaveInvestmentProfileResponse(investmentProfileResponse);
            Response response = Response.status(Response.Status.OK).entity(investmentProfileResponse).build();
            exchange.getIn().setBody(response);
            SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_PROFILE_LOGGING_FORMAT, className, "Exiting from transform method");
        } catch (SILException silEx) {
            SILLogger.error(AccountServiceConstants.SAVE_INVESTMENT_PROFILE_LOGGING_FORMAT, className, SILUtil.getRespExMsg(silEx));
            throw new SILException(silEx.getMessage());
        } catch (Exception exception) {
            SILLogger.error(AccountServiceConstants.SAVE_INVESTMENT_PROFILE_LOGGING_FORMAT, className, SILUtil.getRespExMsg(exception));
            throw new SILException(exception.getMessage());
        }
    }

}
