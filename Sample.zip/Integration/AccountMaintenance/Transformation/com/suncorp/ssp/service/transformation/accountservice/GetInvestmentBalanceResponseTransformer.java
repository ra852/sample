////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.transformation.accountservice;

import javax.ws.rs.core.Response;

import org.apache.camel.Exchange;

import com.sonatacentral.service.v30.wrap.account.GetAccountTransactionSummaryResponseType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.GetInvestmentBalanceResponseBean;
import com.suncorp.ssp.service.integration.accountservice.util.GetInvestmentBalanceResponseUtil;

/**
 * The class {@code GetInvestmentBalanceResponseTransformer} transforms the response received from external service, to a specified format for
 * end-client.
 * 
 * @author U384381
 * @since 30/12/2015
 * @version 1.0
 */
public class GetInvestmentBalanceResponseTransformer {
    private String className = "GetInvestmentBalanceResponseTransformer";

    public void transform(Exchange exchange) throws SILException {
        try {
            SILLogger.debug(AccountServiceConstants.GET_INVESTMENT_BAL_LOG_FORMAT, className, "Entering transform()");
            GetAccountTransactionSummaryResponseType inboundResponse = exchange.getIn().getBody(GetAccountTransactionSummaryResponseType.class);
            GetInvestmentBalanceResponseUtil responseUtil = new GetInvestmentBalanceResponseUtil(inboundResponse);
            responseUtil.setUnitPriceEffDate(exchange.getProperty(AccountServiceConstants.START_DATE).toString());
            GetInvestmentBalanceResponseBean outboundResponse = responseUtil.createOutboundResponse();
            // exchange.getIn().setBody(outboundResponse);
            Response response = Response.status(Response.Status.OK).entity(outboundResponse).build();
            exchange.getIn().setBody(response);
            SILLogger.debug(AccountServiceConstants.GET_INVESTMENT_BAL_LOG_FORMAT, className, "Exiting transform()");
        } catch (SILException silEx) {
            SILLogger.error(AccountServiceConstants.GET_INVESTMENT_BAL_LOG_FORMAT, className, SILUtil.getReqExMsg(silEx));
            throw new SILException(silEx.getMessage());
        } catch (Exception exception) {
            SILLogger.error(AccountServiceConstants.GET_INVESTMENT_BAL_LOG_FORMAT, className, SILUtil.getRespExMsg(exception));
            throw new SILException(AccountServiceConstants.GET_INVESTMENT_BALANCE_RESPONSE_NOT_PROCESSED);
        }
    }
}
