////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.transformation.accountservice;

import javax.ws.rs.core.Response;

import org.apache.camel.Exchange;

import com.sonatacentral.service.v30.wrap.account.GetAccountBeneficiaryResponseType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.GetBeneficiaryResponse;
import com.suncorp.ssp.service.integration.accountservice.util.GetBeneficiaryDetailsUtil;

/**
 * The class {@code GetBeneficiaryResponseTransformer} does this.
 * 
 * @author u384380
 * @since 28/10/2015
 * @version 1.0
 */
public class GetBeneficiaryResponseTransformer {

    /**
     * Extracts the values from external service's response, to forward to the end client.
     * 
     * @param exchange of type Exchange
     * @throws Exception of type Exception
     */
    public void tranform(Exchange exchange) throws SILException {
        try {
            SILLogger.debug(AccountServiceConstants.GET_BENEFICIARY_LOGGING_FORMAT, "GetBeneficiaryResponseTransformer", "Entering transform()");
            GetAccountBeneficiaryResponseType getAccountBeneficiaryResponseType = exchange.getIn().getBody(GetAccountBeneficiaryResponseType.class);
            GetBeneficiaryResponse getBeneficiaryResponse = new GetBeneficiaryResponse();

            GetBeneficiaryDetailsUtil getBeneficiaryDetailsUtil = new GetBeneficiaryDetailsUtil(getAccountBeneficiaryResponseType);
            getBeneficiaryDetailsUtil.setGetBeneficiaryResponse(getBeneficiaryResponse);
            exchange.setProperty(AccountServiceConstants.NO_OF_BENEFICIARY, new Integer(getBeneficiaryDetailsUtil.getNumberOfBeneficiary()));
            Response response = Response.status(Response.Status.OK).entity(getBeneficiaryResponse).build();
            exchange.getIn().setBody(response);
            exchange.setProperty(CommonConstants.SAVE_RESPONSE, exchange.getIn().getBody());
            SILLogger.debug(AccountServiceConstants.GET_BENEFICIARY_LOGGING_FORMAT, "GetBeneficiaryResponseTransformer", "Exiting transform()");
        } catch (Exception exception) {
            SILLogger.error(AccountServiceConstants.GET_BENEFICIARY_LOGGING_FORMAT, "GetBeneficiaryDOBResponseTransformer",
                    "Exception while constructing response:" + exception.getMessage());
            throw new SILException(AccountServiceConstants.GET_BENEFICIARY_GENERIC_MSG);
        }
    }
}
