////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.transformation.accountservice;

import javax.ws.rs.core.Response;

import org.apache.camel.Exchange;

import com.sonatacentral.service.v30.wrap.account.SearchAccountResponseType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.SearchAccountResponse;
import com.suncorp.ssp.service.integration.accountservice.util.SearchAccountsUtil;

/**
 * The class {@code SearchAccountResponseTransformer} transforms the response received from external service, to a specified format for end-client.
 * 
 * @author U384381
 * @since 03/11/2015
 * @version 1.0
 */
public class SearchAccountResponseTransformer {

    /**
     * Extracts the values from external service's response, to forward to the end client.
     */
    public void tranform(Exchange exchange) throws SILException {
        try {
            SILLogger.debug(AccountServiceConstants.SRCH_ACCNT_LOGGING_FORMAT, "SearchAccountResponseTransformer", "Entering transform()");
            SearchAccountResponseType searchAccountResponseType = exchange.getIn().getBody(SearchAccountResponseType.class);
            SearchAccountResponse searchAccountResponse = new SearchAccountResponse();
            new SearchAccountsUtil(searchAccountResponseType).setSearchAccountResponse(searchAccountResponse);
            Response response = Response.status(Response.Status.OK).entity(searchAccountResponse).build();
            exchange.getIn().setBody(response);
            SILLogger.debug(AccountServiceConstants.SRCH_ACCNT_LOGGING_FORMAT, "SearchAccountResponseTransformer", "Exiting transform()");
        } catch (SILException silEx) {
            SILLogger.error(AccountServiceConstants.SRCH_ACCNT_LOGGING_FORMAT, "SearchAccountResponseTransformer", SILUtil.getRespExMsg(silEx));
            throw new SILException(silEx.getMessage());
        } catch (Exception exception) {
            SILLogger.error(AccountServiceConstants.SRCH_ACCNT_LOGGING_FORMAT, "SearchAccountResponseTransformer",
                    "Exception while constructing response:" + exception.getMessage());
            throw new SILException(AccountServiceConstants.SEARCH_ACCT_GENERIC_EXCEPTION_MSG);
        }
    }
}
