////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.transformation.accountservice;

import javax.ws.rs.core.Response;

import org.apache.camel.Exchange;

import com.sonatacentral.service.v30.wrap.account.GetAccountDetailsResponseType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.GetAccountDetailsResponse;
import com.suncorp.ssp.service.integration.accountservice.util.GetAccountDetailsResponseUtil;

/**
 * The class {@code GetAccountDetailsResponseTransformer} does this.
 * 
 * @author u386898
 * @since 16/12/2015
 * @version 1.0
 */
public class GetAccountDetailsResponseTransformer {

    /**
     * Extracts the values from external service's response and forward to the end client.
     */
    public void transform(Exchange exchange) throws SILException {
        try {
            SILLogger
                    .debug(AccountServiceConstants.GET_ACCOUNTDETAILS_LOGGING_FORMAT, "GetAccountDetailsResponseTransformer", "Entering transform()");
            GetAccountDetailsResponseType getAccountDetailsResponseType = exchange.getIn().getBody(GetAccountDetailsResponseType.class);
            GetAccountDetailsResponse getAccountDetailsResponse = new GetAccountDetailsResponse();
            GetAccountDetailsResponseUtil getAccountDetailsUtil = new GetAccountDetailsResponseUtil(getAccountDetailsResponseType);
            getAccountDetailsUtil.setAccountDetailResponse(getAccountDetailsResponse);
            // exchange.getIn().setBody(getAccountDetailsResponse);
            Response response = Response.status(Response.Status.OK).entity(getAccountDetailsResponse).build();
            exchange.getIn().setBody(response);
            SILLogger.debug(AccountServiceConstants.GET_ACCOUNTDETAILS_LOGGING_FORMAT, "GetAccountDetailsResponseTransformer", "Exiting transform()");
        } catch (Exception exception) {
            SILLogger.error(AccountServiceConstants.GET_ACCOUNTDETAILS_LOGGING_FORMAT, "GetAccountDetailsResponseTransformer",
                    "Exception while constructing response.");
            throw new SILException(exception.getMessage());
        }
    }

}
