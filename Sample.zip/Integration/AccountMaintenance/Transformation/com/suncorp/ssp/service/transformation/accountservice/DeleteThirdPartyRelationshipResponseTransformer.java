////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.transformation.accountservice;

import javax.ws.rs.core.Response;

import org.apache.camel.Exchange;

import com.sonatacentral.service.v30.wrap.account.SaveAccountResponseType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.DeleteThirdPartyRelationshipResponse;
import com.suncorp.ssp.service.integration.accountservice.util.DeleteThirdPartyRelationshipResponseUtil;

/**
 * The class {@code DeleteThirdPartyRelationshipResponseTransformer} transforms the response received from external service, to a specified format for
 * end-client.
 * 
 * @author u385424
 * @since 17/03/2016
 * @version 1.0
 */
public class DeleteThirdPartyRelationshipResponseTransformer {
    private String className = "DeleteThirdPartyRelationshipResponseTransformer";

    /**
     * Extracts the values from external service's response, to forward to the end client.
     *
     * @param exchange
     * @throws Exception
     */
    public void transform(Exchange exchange) throws SILException {
        try {
            SILLogger.debug(AccountServiceConstants.DEL_THIRD_PARTY_REL_LOG_FORMAT, className, "transform()");
            SaveAccountResponseType inboundResponse = exchange.getIn().getBody(SaveAccountResponseType.class);
            DeleteThirdPartyRelationshipResponseUtil responseUtil = new DeleteThirdPartyRelationshipResponseUtil(inboundResponse);
            DeleteThirdPartyRelationshipResponse outboundResponse = responseUtil.createOutboundResponse();
            Response response = Response.status(Response.Status.OK).entity(outboundResponse).build();
            exchange.getIn().setBody(response);
        } catch (Exception exception) {
            SILLogger.error(AccountServiceConstants.DEL_THIRD_PARTY_REL_LOG_FORMAT, className, SILUtil.getRespExMsg(exception));
            throw new SILException(AccountServiceConstants.DELETE_THIRD_PARTY_RELATIONSHIP_RESPONSE_NOT_PROCESSED);
        }
    }
}
