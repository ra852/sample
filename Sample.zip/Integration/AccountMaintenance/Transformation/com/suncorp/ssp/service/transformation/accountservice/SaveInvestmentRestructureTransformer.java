////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.transformation.accountservice;

import javax.ws.rs.core.Response;

import org.apache.camel.Exchange;

import com.sonatacentral.service.v30.wrap.account.SaveInvestmentRestructureResponseType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.SaveInvestmentRestuctureResponse;
import com.suncorp.ssp.service.integration.accountservice.util.SaveInvestmentRestructureResponseUtil;

/**
 * The class {@code SaveInvestmentRestructureTransformer} construct's SOAP request for external service.
 * 
 * @author U387938
 * @since 20/03/2016
 * @version 1.0
 */
public class SaveInvestmentRestructureTransformer {
    private final String className = "SaveInvestmentRestructureTransformer";

   /**
    * 
    * Extracts the values from external service's response and forward to the end client.
    *
    * @param exchange
    * @throws Exception
    */
    public void transform(Exchange exchange) throws SILException {
        try {
            SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_RESTRUCTURE_LOGGING_FORMAT, className, "Entering transform()");
            SaveInvestmentRestructureResponseType saveInvestmentRestructureResponseType =
                    exchange.getIn().getBody(SaveInvestmentRestructureResponseType.class);
            SaveInvestmentRestuctureResponse saveInvestmentRestuctureResponse = new SaveInvestmentRestuctureResponse();
            SaveInvestmentRestructureResponseUtil saveInvestmentRestructureResponseUtil =
                    new SaveInvestmentRestructureResponseUtil(saveInvestmentRestructureResponseType);
            saveInvestmentRestructureResponseUtil.setSaveInvestmentRestructureResponse(saveInvestmentRestuctureResponse);
            Response response = Response.status(Response.Status.OK).entity(saveInvestmentRestuctureResponse).build();
            exchange.getIn().setBody(response);
            SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_RESTRUCTURE_LOGGING_FORMAT, className, "Exiting transform()");
        } catch (SILException silEx) {
            SILLogger.error(AccountServiceConstants.SAVE_INVESTMENT_RESTRUCTURE_LOGGING_FORMAT, className, SILUtil.getRespExMsg(silEx));
            throw new SILException(silEx.getMessage());
        } catch (Exception exception) {
            SILLogger.error(AccountServiceConstants.SAVE_INVESTMENT_RESTRUCTURE_LOGGING_FORMAT, className, SILUtil.getRespExMsg(exception));
            throw new SILException(exception.getMessage());
        }
    }

}
