////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.transformation.accountservice;

import javax.ws.rs.core.Response;

import org.apache.camel.Exchange;

import com.sonatacentral.service.v30.wrap.account.GetAccountEmploymentResponseType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.GetAccountEmploymentResponseBean;
import com.suncorp.ssp.service.integration.accountservice.util.GetAccountEmploymentResponseUtil;

/**
 * The class {@code GetAccountEmploymentResponseTransformer} transforms the response received from external service, to a specified format for
 * end-client.
 * 
 * @author u387938
 * @since 12/09/2016
 * @version 1.0
 */
public class GetAccountEmploymentResponseTransformer {
    private final String className = "GetAccountEmploymentResponseTransformer";

    /**
     * Extracts the values from external service's response, to forward to the end client.
     * 
     * @param exchange of type Exchange
     * @throws SILException
     */
    public void transform(Exchange exchange) throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACCOUNT_EMPLOYMENT_LOGGING_FORMAT, className, "Entering transform()");
        try {
            GetAccountEmploymentResponseType inboundResponse = exchange.getIn().getBody(GetAccountEmploymentResponseType.class);
            GetAccountEmploymentResponseUtil respUtil = new GetAccountEmploymentResponseUtil(inboundResponse);
            GetAccountEmploymentResponseBean outboundResponse = respUtil.createOutboundResponse();
            setExchangeResponse(exchange, outboundResponse);
            SILLogger.debug(AccountServiceConstants.GET_ACCOUNT_EMPLOYMENT_LOGGING_FORMAT, className, "Exiting transform()");
        } catch (SILException silEx) {
            SILLogger.error(AccountServiceConstants.GET_ACCOUNT_EMPLOYMENT_LOGGING_FORMAT, className, SILUtil.getRespExMsg(silEx));
            throw new SILException(silEx.getMessage());
        } catch (Exception exception) {
            SILLogger.error(AccountServiceConstants.GET_ACCOUNT_EMPLOYMENT_LOGGING_FORMAT, className, SILUtil.getRespExMsg(exception));
            throw new SILException(AccountServiceConstants.GET_ACCOUNT_EMPLOYMENT_RES_NOT_PROCESSED);
        }
    }

   /**
    * 
    * Sets the response into exchange message.
    *
    * @param exchange
    * @param outboundResponse
    */
    private void setExchangeResponse(Exchange exchange, GetAccountEmploymentResponseBean outboundResponse) {
        SILLogger.debug(AccountServiceConstants.GET_ACCOUNT_EMPLOYMENT_LOGGING_FORMAT, className, "Entering setExchangeResponse()");
        Response response = Response.status(Response.Status.OK).entity(outboundResponse).build();
        exchange.getIn().setBody(response);
    }
}
