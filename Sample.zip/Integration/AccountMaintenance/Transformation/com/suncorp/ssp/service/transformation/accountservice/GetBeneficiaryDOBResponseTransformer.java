////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.transformation.accountservice;

import javax.ws.rs.core.Response;

import org.apache.camel.Exchange;

import com.sonatacentral.service.v30.common.client.GetClientResponseType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.GetBeneficiaryResponse;

/**
 * The class {@code GetBeneficiaryTransformer} does this.
 * 
 * @author u384380
 * @since 30/10/2015
 * @version 1.0
 */
public class GetBeneficiaryDOBResponseTransformer {
    private final String className = "GetInvestmentBalanceRequestProcessor";

    /**
     * Extracts DOB of the beneficiary from Stub object and put it into GetBeneficiary Response to send to consumer.
     * 
     * @param exchange of type Exchange
     * @throws Exception
     */
    public void tranform(Exchange exchange) throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_BENEFICIARY_LOGGING_FORMAT, className, "Entering transform()");
        try {
            GetClientResponseType getClientResponseType = exchange.getIn().getBody(GetClientResponseType.class);
            Response response = (Response) exchange.getProperty(CommonConstants.SAVE_RESPONSE);
            GetBeneficiaryResponse getBeneficiaryResponse = (GetBeneficiaryResponse) response.getEntity();
            if (getClientResponseType.getClientDetails() != null && getClientResponseType.getClientDetails().getDateOfBirth() != null &&
                    getClientResponseType.getClientDetails().getDateOfBirth().toGregorianCalendar() != null) {
                getBeneficiaryResponse
                        .getBeneficiary()
                        .get((int) exchange.getProperty(CommonConstants.CAMEL_LOOP_INDEX))
                        .setDateOfBirth(
                                SILUtil.convertXMLGregorianCalendartoString(getClientResponseType.getClientDetails().getDateOfBirth(),
                                        CommonConstants.DATE_FORMAT_DDMMYYYY));
            } else {
                getBeneficiaryResponse.getBeneficiary().get((int) exchange.getProperty(CommonConstants.CAMEL_LOOP_INDEX)).setDateOfBirth("");
            }
            response = Response.status(Response.Status.OK).entity(getBeneficiaryResponse).build();
            exchange.getIn().setBody(response);
            SILLogger.debug(AccountServiceConstants.GET_BENEFICIARY_LOGGING_FORMAT, className, "Exiting transform()");
        } catch (Exception exception) {
            SILLogger.error(AccountServiceConstants.GET_BENEFICIARY_LOGGING_FORMAT, className, SILUtil.getReqExMsg(exception));
            throw new SILException(AccountServiceConstants.GET_BENEFICIARY_GENERIC_MSG);
        }
    }
}
