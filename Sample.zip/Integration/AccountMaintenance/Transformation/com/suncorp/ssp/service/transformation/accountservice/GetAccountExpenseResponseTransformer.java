////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.transformation.accountservice;

import javax.ws.rs.core.Response;

import org.apache.camel.Exchange;

import com.sonatacentral.service.v30.wrap.account.GetAccountExpenseResponseType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.GetAccountExpenseResponse;
import com.suncorp.ssp.service.integration.accountservice.util.GetAccountExpenseUtil;

/**
 * The class {@code GetAccountExpenseResponseTransformer} transforms the response received from external service, to a specified format for
 * end-client.
 * 
 * @author U383754
 * @since 29/01/2016
 * @version 1.0
 */
public class GetAccountExpenseResponseTransformer {
    private final String className = "GetAccountExpenseResponseTransformer";

    /**
     * 
     * Extracts the values from external service's response, to forward to the end-client.
     * 
     * @param exchange
     * @throws Exception
     */
    public void transform(Exchange exchange) throws SILException {
        try {
            SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering transform()");
            GetAccountExpenseResponseType getAccountExpenseResponseType = exchange.getIn().getBody(GetAccountExpenseResponseType.class);
            GetAccountExpenseResponse getAccountExpenseResponse = new GetAccountExpenseResponse();
            GetAccountExpenseUtil getAccountExpenseUtil = new GetAccountExpenseUtil(getAccountExpenseResponseType);
            String serviceCheck = (String) exchange.getProperty(AccountServiceConstants.GET_EXPENSE_SERVICE_CHECK_PARAM);
            if (serviceCheck.equalsIgnoreCase(AccountServiceConstants.IS_ACCOUNT_NUMBER_REQUEST_FALSE)) {
                getAccountExpenseUtil.setAccountExpenseResponse(getAccountExpenseResponse);
            } else {
                getAccountExpenseUtil.setExpenseLineResponse(getAccountExpenseResponse);
            }
            Response response = Response.status(Response.Status.OK).entity(getAccountExpenseResponse).build();
            exchange.getIn().setBody(response);
            SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting transform()");
        } catch (Exception exception) {
            SILLogger.error(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, SILUtil.getRespExMsg(exception));
            throw new SILException(AccountServiceConstants.GET_ACC_EXPENSE_GENERIC_MSG);
        }

    }
}
