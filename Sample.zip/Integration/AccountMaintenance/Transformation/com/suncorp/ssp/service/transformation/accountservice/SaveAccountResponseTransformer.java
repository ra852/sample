////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.transformation.accountservice;

import javax.ws.rs.core.Response;

import org.apache.camel.Exchange;

import com.sonatacentral.service.v30.wrap.account.SaveAccountResponseType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.SaveAccountResponse;
import com.suncorp.ssp.service.integration.accountservice.util.SaveAccountResponseUtil;

/**
 * The class {@code SaveAccountResponseTransformer} does this.
 *
 * @author U383847
 * @since 30/03/2016
 * @version 1.0
 */
public class SaveAccountResponseTransformer {
    private final String className = "SaveAccountResponseTransformer";
    
    /**
     * Extracts the values from end client's request and constructs a new request as per the SaveAccount service.
     *
     * @param exchange
     * @throws Exception
     */
    public void transform(Exchange exchange) throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_LOGGING_FORMAT, className, "Entering into transform");
        try {
            SaveAccountResponseType saveAccountResponseType = exchange.getIn().getBody(SaveAccountResponseType.class);
            SaveAccountResponse saveAccountResponse = new SaveAccountResponse();
            if (saveAccountResponseType != null) {
                SaveAccountResponseUtil saveAccountResponseUtil = new SaveAccountResponseUtil(saveAccountResponseType);
                saveAccountResponseUtil.saveAccountResponseDetails(saveAccountResponse);
            }
            Response response = Response.status(Response.Status.OK).entity(saveAccountResponse).build();
            exchange.getIn().setBody(response);
            SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_LOGGING_FORMAT, className, "Exiting from transform");
        } catch (SILException silException) {
            SILLogger.error(AccountServiceConstants.SAVE_ACCOUNT_LOGGING_FORMAT, className, SILUtil.getRespExMsg(silException));
            throw new SILException(SILUtil.getRespExMsg(silException));
        } catch (Exception exception) {
            SILLogger.error(AccountServiceConstants.SAVE_ACCOUNT_LOGGING_FORMAT, className, SILUtil.getRespExMsg(exception));
            throw new SILException(SILUtil.getRespExMsg(exception));
        }
    }
}
