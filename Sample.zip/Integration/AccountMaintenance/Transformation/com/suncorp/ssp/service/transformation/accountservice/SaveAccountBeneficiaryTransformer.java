////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.transformation.accountservice;

import javax.ws.rs.core.Response;

import org.apache.camel.Exchange;

import com.sonatacentral.service.v30.wrap.account.SaveAccountBeneficiaryResponseType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.SaveAccountBeneficiaryResponse;
import com.suncorp.ssp.service.integration.accountservice.util.SaveAccountBeneficiaryResponseUtil;

/**
 * The class {@code SaveAccountBeneficiaryTransformer} transforms the response received from external service, to a specified format for end-client.
 * 
 * @author U384381
 * @since 12/11/2015
 * @version 1.0
 */
public class SaveAccountBeneficiaryTransformer {
    private final String className = "SaveAccountBeneficiaryTransformer";

    /**
     * Extracts the values from external service's response, to forward to the end client.
     * 
     * @param exchange of type Exchange
     * @throws SILException
     */
    public void tranform(Exchange exchange) throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Entering transform()");
        try {
            SaveAccountBeneficiaryResponseType inboundResponse = exchange.getIn().getBody(SaveAccountBeneficiaryResponseType.class);
            SaveAccountBeneficiaryResponseUtil respUtil = new SaveAccountBeneficiaryResponseUtil(inboundResponse);
            SaveAccountBeneficiaryResponse outboundResponse = respUtil.createOutboundResponse();
            setExchangeResponse(exchange, outboundResponse);
            SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Exiting transform()");
        } catch (Exception ex) {
            SILLogger.error(AccountServiceConstants.SAVE_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, SILUtil.getRespExMsg(ex));
            throw new SILException(AccountServiceConstants.SAVE_ACCOUNT_BENEFICIARY_RESPONSE_NOT_PROCESSED);
        }
    }

    /**
     * Sets the response into exchange message.
     * 
     * @param exchange of type Exchange
     * @param searchAccountResponse of type SearchAccountResponse
     */
    private void setExchangeResponse(Exchange exchange, SaveAccountBeneficiaryResponse outboundResponse) {
        Response response = Response.status(Response.Status.OK).entity(outboundResponse).build();
        exchange.getIn().setBody(response);
    }
}
