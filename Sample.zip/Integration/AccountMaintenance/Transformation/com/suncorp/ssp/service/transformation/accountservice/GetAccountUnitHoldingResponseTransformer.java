////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.transformation.accountservice;

import javax.ws.rs.core.Response;

import org.apache.camel.Exchange;

import com.sonatacentral.service.v30.wrap.account.GetAccountUnitHoldingDetailResponseType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.GetAccountUnitHoldingsResponse;
import com.suncorp.ssp.service.integration.accountservice.util.GetAccountUnitHoldingResponseUtil;

/**
 * The class {@code GetAccountUnitHoldingResponseTransformer} transforms the response received from external service, to a specified format for
 * end-client.
 * 
 * @author U385424
 * @since 26/10/2016
 * @version 1.0
 */
public class GetAccountUnitHoldingResponseTransformer {
    private final String className = "GetAccountUnitHoldingResponseTransformer";

    /**
     * Extracts the values from external service's response, to forward to the end client.
     * 
     * @param exchange of type Exchange
     * @throws SILException
     */
    public void transform(Exchange exchange) throws SILException {
        SILLogger.debug(AccountServiceConstants.ACCOUNT_HOLDINGS_LOGGING_FORMAT, className, "Entering transform()");
        try {
            GetAccountUnitHoldingDetailResponseType inboundResponse = exchange.getIn().getBody(GetAccountUnitHoldingDetailResponseType.class);
            GetAccountUnitHoldingResponseUtil responseUtil = new GetAccountUnitHoldingResponseUtil(inboundResponse);
            GetAccountUnitHoldingsResponse outboundResponse = responseUtil.createOutboundResponse();
            setExchangeResponse(exchange, outboundResponse);
            SILLogger.debug(AccountServiceConstants.ACCOUNT_HOLDINGS_LOGGING_FORMAT, className, "Exiting transform()");
        } catch (SILException silEx) {
            SILLogger.error(AccountServiceConstants.ACCOUNT_HOLDINGS_LOGGING_FORMAT, className, SILUtil.getRespExMsg(silEx));
            throw new SILException(silEx.getMessage());
        } catch (Exception exception) {
            SILLogger.error(AccountServiceConstants.ACCOUNT_HOLDINGS_LOGGING_FORMAT, className, SILUtil.getRespExMsg(exception));
            throw new SILException(AccountServiceConstants.GET_ACCOUNT_UNIT_HOLDINGS_RES_NOT_PROCESSED);
        }
    }

    /**
     * 
     * Sets the response into exchange message.
     * 
     * @param exchange
     * @param outboundResponse
     */
    private void setExchangeResponse(Exchange exchange, GetAccountUnitHoldingsResponse outboundResponse) {
        SILLogger.debug(AccountServiceConstants.ACCOUNT_HOLDINGS_LOGGING_FORMAT, className, "Entering setExchangeResponse()");
        Response response = Response.status(Response.Status.OK).entity(outboundResponse).build();
        exchange.getIn().setBody(response);
    }
}
