////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.transformation.accountservice;

import javax.ws.rs.core.Response;

import org.apache.camel.Exchange;

import com.sonatacentral.service.v30.wrap.account.GetAccountTransactionSummaryResponseType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.GetAccountTransactionSummaryResponse;
import com.suncorp.ssp.service.integration.accountservice.util.GetAccountTransactionSummaryResponseUtil;

/**
 * The class {@code GetAccountTransactionSummaryResponseTransformer} process the Inbound response to create Outbound response.
 * 
 * @author u385424
 * @since 15/12/2015
 * @version 1.0
 */
public class GetAccountTransactionSummaryResponseTransformer {
    private String className = "GetAccountTransactionSummaryResponseTransformer";

    public void tranform(Exchange exchange) throws SILException {
        try {
            SILLogger.debug(AccountServiceConstants.GET_ACC_TRANS_SUMM_LOGGING_FORMAT, className, "Entering in transform method");
            GetAccountTransactionSummaryResponseType inboundResponse = exchange.getIn().getBody(GetAccountTransactionSummaryResponseType.class);
            GetAccountTransactionSummaryResponseUtil responseUtil = new GetAccountTransactionSummaryResponseUtil(inboundResponse);
            GetAccountTransactionSummaryResponse outboundResponse = responseUtil.createOutboundResponse();
            // exchange.getIn().setBody(outboundResponse);
            Response response = Response.status(Response.Status.OK).entity(outboundResponse).build();
            exchange.getIn().setBody(response);
            SILLogger.debug(AccountServiceConstants.GET_ACC_TRANS_SUMM_LOGGING_FORMAT, className, "Exiting transform");
        } catch (Exception exception) {
            SILLogger.error(AccountServiceConstants.GET_ACC_TRANS_SUMM_LOGGING_FORMAT, className, SILUtil.getReqExMsg(exception));
            throw new SILException(AccountServiceConstants.TRAN_SUMMRY_EXCEPTION_MSG);
        }
    }

}
