////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.suncorp.ssp.common.bean.SILErrorMessage;

/**
 * The class {@code GetAccountUnitHoldings} is a response java bean for GetAccountunitHoldings.
 * 
 * @author U385424
 * @since 26/10/2016
 * @version 1.0
 */
@XmlRootElement(name = "GetAccountUnitHoldingsResponse")
public class GetAccountUnitHoldingsResponse extends SILErrorMessage {

    private AccountDetails account;
    private List<FundBalanceDetails> fundBalance;

    /**
     * Accessor for property account.
     * 
     * @return account of type AccountDetails
     */
    public AccountDetails getAccount() {
        return account;
    }

    /**
     * Mutator for property account.
     * 
     * @param account of type AccountDetails
     */
    @XmlElement(name = "account")
    public void setAccount(AccountDetails account) {
        this.account = account;
    }

    /**
     * Accessor for property fundbalance.
     * 
     * @return fundbalance of type List<FundBalanceDetails>
     */
    public List<FundBalanceDetails> getFundBalance() {
        return fundBalance;
    }

    /**
     * Mutator for property fundbalance.
     * 
     * @param fundbalance of type List<FundBalanceDetails>
     */
    @XmlElement(name = "fundBalance")
    public void setFundBalance(List<FundBalanceDetails> fundbalance) {
        this.fundBalance = fundbalance;
    }

}
