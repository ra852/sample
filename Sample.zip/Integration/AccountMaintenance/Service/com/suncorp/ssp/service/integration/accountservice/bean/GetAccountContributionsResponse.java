////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.suncorp.ssp.common.bean.SILErrorMessage;

/**
 * The class {@code GetAccountContributionsResponse} is a java bean consisting of all the properties related to GetAccountContributions functionality,
 * to be used for constructing response for end-client.
 * 
 * @author U201468
 * @since 19/09/2017
 * @version 1.0
 */
@XmlRootElement(name = "GetAccountContributionsResponse")
public class GetAccountContributionsResponse extends SILErrorMessage {

    private List<GetAccountContributionDetails> getAccountContributionDetails;

    /**
     * Accessor for property getAccountContributionDetails.
     * 
     * @return getAccountContributionDetails of type List<GetAccountContributionDetails>
     */
    public List<GetAccountContributionDetails> getGetAccountContributionDetails() {
        return getAccountContributionDetails;
    }

    /**
     * Mutator for property getAccountContributionDetails.
     * 
     * @param getAccountContributionDetails of type List<GetAccountContributionDetails>
     */
    @XmlElement(name = "getAccountContributionDetails")
    public void setGetAccountContributionDetails(List<GetAccountContributionDetails> getAccountContributionDetails) {
        this.getAccountContributionDetails = getAccountContributionDetails;
    }

}
