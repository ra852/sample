////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code TransactionEventInvestmentTransDetails} is a pure java bean consisting of properties related to
 * TransactionEventInvestmentTransDetails.
 * 
 * @author U385424
 * @since 23/01/2017
 * @version 1.0
 */
public class TransactionEventInvestmentTransDetails {
    private String id;
    private String balanceType;
    private FundShortTypeDetails fundName;
    private FundShortTypeDetails smpName;
    private String effectiveAmount;
    private String effectiveUnits;
    private String priceApplied;
    private String pricedDate;
    private String ascValue;
    private String effectiveDeduction;
    private String amountMaster;
    private String effectiveDate;
    private String percentage;
    private String priceType;
    private String priceAdjRate;
    private String grossInterest;
    private LastUpdatedDetail lastUpdated;
    private List<FundLevelExpenseDetails> fundLevelExpense;
    private String balanceId;
    private String partialFill;

    /**
     * Accessor for property id.
     * 
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     * 
     * @param id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id != null ? id : "";
    }

    /**
     * Accessor for property balanceType.
     * 
     * @return balanceType of type String
     */
    public String getBalanceType() {
        return balanceType;
    }

    /**
     * Mutator for property balanceType.
     * 
     * @param balanceType of type String
     */
    @XmlElement(name = "balanceType")
    public void setBalanceType(String balanceType) {
        this.balanceType = balanceType != null ? balanceType : "";
    }

    /**
     * Accessor for property fundName.
     * 
     * @return fundName of type FundShortTypeDetails
     */
    public FundShortTypeDetails getFundName() {
        return fundName;
    }

    /**
     * Mutator for property fundName.
     * 
     * @param fundName of type FundShortTypeDetails
     */
    @XmlElement(name = "fundName")
    public void setFundName(FundShortTypeDetails fundName) {
        this.fundName = fundName;
    }

    /**
     * Accessor for property smpName.
     * 
     * @return smpName of type FundShortTypeDetails
     */
    public FundShortTypeDetails getSmpName() {
        return smpName;
    }

    /**
     * Mutator for property smpName.
     * 
     * @param smpName of type FundShortTypeDetails
     */
    @XmlElement(name = "smpName")
    public void setSmpName(FundShortTypeDetails smpName) {
        this.smpName = smpName;
    }

    /**
     * Accessor for property effectiveAmount.
     * 
     * @return effectiveAmount of type String
     */
    public String getEffectiveAmount() {
        return effectiveAmount;
    }

    /**
     * Mutator for property effectiveAmount.
     * 
     * @param effectiveAmount of type String
     */
    @XmlElement(name = "effectiveAmount")
    public void setEffectiveAmount(String effectiveAmount) {
        this.effectiveAmount = effectiveAmount != null ? effectiveAmount : "";
    }

    /**
     * Accessor for property effectiveUnits.
     * 
     * @return effectiveUnits of type String
     */
    public String getEffectiveUnits() {
        return effectiveUnits;
    }

    /**
     * Mutator for property effectiveUnits.
     * 
     * @param effectiveUnits of type String
     */
    @XmlElement(name = "effectiveUnits")
    public void setEffectiveUnits(String effectiveUnits) {
        this.effectiveUnits = effectiveUnits != null ? effectiveUnits : "";
    }

    /**
     * Accessor for property priceApplied.
     * 
     * @return priceApplied of type String
     */
    public String getPriceApplied() {
        return priceApplied;
    }

    /**
     * Mutator for property priceApplied.
     * 
     * @param priceApplied of type String
     */
    @XmlElement(name = "priceApplied")
    public void setPriceApplied(String priceApplied) {
        this.priceApplied = priceApplied != null ? priceApplied : "";
    }

    /**
     * Accessor for property pricedDate.
     * 
     * @return pricedDate of type String
     */
    public String getPricedDate() {
        return pricedDate;
    }

    /**
     * Mutator for property pricedDate.
     * 
     * @param pricedDate of type String
     */
    @XmlElement(name = "pricedDate")
    public void setPricedDate(String pricedDate) {
        this.pricedDate = pricedDate != null ? pricedDate : "";
    }

    /**
     * Accessor for property ascValue.
     * 
     * @return ascValue of type String
     */
    public String getAscValue() {
        return ascValue;
    }

    /**
     * Mutator for property ascValue.
     * 
     * @param ascValue of type String
     */
    @XmlElement(name = "ascValue")
    public void setAscValue(String ascValue) {
        this.ascValue = ascValue != null ? ascValue : "";
    }

    /**
     * Accessor for property effectiveDeduction.
     * 
     * @return effectiveDeduction of type String
     */
    public String getEffectiveDeduction() {
        return effectiveDeduction;
    }

    /**
     * Mutator for property effectiveDeduction.
     * 
     * @param effectiveDeduction of type String
     */
    @XmlElement(name = "effectiveDeduction")
    public void setEffectiveDeduction(String effectiveDeduction) {
        this.effectiveDeduction = effectiveDeduction != null ? effectiveDeduction : "";
    }

    /**
     * Accessor for property amountMaster.
     * 
     * @return amountMaster of type String
     */
    public String getAmountMaster() {
        return amountMaster;
    }

    /**
     * Mutator for property amountMaster.
     * 
     * @param amountMaster of type String
     */
    @XmlElement(name = "amountMaster")
    public void setAmountMaster(String amountMaster) {
        this.amountMaster = amountMaster != null ? amountMaster : "";
    }

    /**
     * Accessor for property effectiveDate.
     * 
     * @return effectiveDate of type String
     */
    public String getEffectiveDate() {
        return effectiveDate;
    }

    /**
     * Mutator for property effectiveDate.
     * 
     * @param effectiveDate of type String
     */
    @XmlElement(name = "effectiveDate")
    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate != null ? effectiveDate : "";
    }

    /**
     * Accessor for property percentage.
     * 
     * @return percentage of type String
     */
    public String getPercentage() {
        return percentage;
    }

    /**
     * Mutator for property percentage.
     * 
     * @param percentage of type String
     */
    @XmlElement(name = "percentage")
    public void setPercentage(String percentage) {
        this.percentage = percentage != null ? percentage : "";
    }

    /**
     * Accessor for property priceType.
     * 
     * @return priceType of type String
     */
    public String getPriceType() {
        return priceType;
    }

    /**
     * Mutator for property priceType.
     * 
     * @param priceType of type String
     */
    @XmlElement(name = "priceType")
    public void setPriceType(String priceType) {
        this.priceType = priceType != null ? priceType : "";
    }

    /**
     * Accessor for property priceAdjRate.
     * 
     * @return priceAdjRate of type String
     */
    public String getPriceAdjRate() {
        return priceAdjRate;
    }

    /**
     * Mutator for property priceAdjRate.
     * 
     * @param priceAdjRate of type String
     */
    @XmlElement(name = "priceAdjRate")
    public void setPriceAdjRate(String priceAdjRate) {
        this.priceAdjRate = priceAdjRate != null ? priceAdjRate : "";
    }

    /**
     * Accessor for property grossInterest.
     * 
     * @return grossInterest of type String
     */
    public String getGrossInterest() {
        return grossInterest;
    }

    /**
     * Mutator for property grossInterest.
     * 
     * @param grossInterest of type String
     */
    @XmlElement(name = "grossInterest")
    public void setGrossInterest(String grossInterest) {
        this.grossInterest = grossInterest != null ? grossInterest : "";
    }

    /**
     * Accessor for property lastUpdated.
     * 
     * @return lastUpdated of type LastUpdatedDetail
     */
    public LastUpdatedDetail getLastUpdated() {
        return lastUpdated;
    }

    /**
     * Mutator for property lastUpdated.
     * 
     * @param lastUpdated of type LastUpdatedDetail
     */
    @XmlElement(name = "lastUpdated")
    public void setLastUpdated(LastUpdatedDetail lastUpdated) {
        this.lastUpdated = lastUpdated;
    }

    /**
     * Accessor for property fundLevelExpense.
     * 
     * @return fundLevelExpense of type List<FundLevelExpenseDetails>
     */
    public List<FundLevelExpenseDetails> getFundLevelExpense() {
        return fundLevelExpense;
    }

    /**
     * Mutator for property fundLevelExpense.
     * 
     * @param fundLevelExpense of type List<FundLevelExpenseDetails>
     */
    @XmlElement(name = "fundLevelExpense")
    public void setFundLevelExpense(List<FundLevelExpenseDetails> fundLevelExpense) {
        this.fundLevelExpense = fundLevelExpense;
    }

    /**
     * Accessor for property balanceId.
     * 
     * @return balanceId of type String
     */
    public String getBalanceId() {
        return balanceId;
    }

    /**
     * Mutator for property balanceId.
     * 
     * @param balanceId of type String
     */
    @XmlElement(name = "balanceId")
    public void setBalanceId(String balanceId) {
        this.balanceId = balanceId != null ? balanceId : "";
    }

    /**
     * Accessor for property partialFill.
     * 
     * @return partialFill of type String
     */
    public String getPartialFill() {
        return partialFill;
    }

    /**
     * Mutator for property partialFill.
     * 
     * @param partialFill of type String
     */
    @XmlElement(name = "partialFill")
    public void setPartialFill(String partialFill) {
        this.partialFill = partialFill != null ? partialFill : "";
    }
}
