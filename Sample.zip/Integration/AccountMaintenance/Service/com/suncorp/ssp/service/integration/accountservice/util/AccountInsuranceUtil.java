////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.sonatacentral.service.v30.globaltypes.life.policy.policygrouptype.AllowableReviewTypeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.life.policy.policygrouptype.BenefitIdentifierType;
import com.sonatacentral.service.v30.globaltypes.life.policy.policygrouptype.BenefitTemplateIdentifierType;
import com.sonatacentral.service.v30.globaltypes.life.policy.policygrouptype.ReviewTermIdentifierType;
import com.sonatacentral.service.v30.globaltypes.life.policy.policygrouptype.ReviewTermType;
import com.sonatacentral.service.v30.globaltypes.life.policy.policygrouptype.ReviewTypeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.life.policy.policygrouptype.RiderParameterType;
import com.sonatacentral.service.v30.globaltypes.life.policy.policygrouptype.RiderTemplateDetailsType;
import com.sonatacentral.service.v30.globaltypes.life.policy.policygrouptype.RiderTemplateIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.ExclusionDetailType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.LoadingDetailType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.RiderDetailType;
import com.sonatacentral.service.v30.globaltypes.wrap.product.productgrouptype.ProductIdentifierType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.AllowableReviewIdentifierDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.BenefitIdentifierDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.BenefitTemplateIdentifierDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.ExclusionDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.LoadingDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.ProductDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.ReferenceIdentifier;
import com.suncorp.ssp.service.integration.accountservice.bean.ReviewTermDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.ReviewTermIdentifierDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.ReviewTypeIdentifierDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.RiderDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.RiderParameterDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.RiderTemplate;
import com.suncorp.ssp.service.integration.accountservice.bean.RiderTemplateDetails;

/**
 * The class {@code AccountInsuranceUtil} does this.
 * 
 * @author U385424
 * @since 17/02/2018
 * @version 1.0
 */
public class AccountInsuranceUtil {
    private final String className = "AccountInsuranceUtil";
    private final String loggerType = AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT;
    private AccountServiceUtil commonUtil;

    public AccountInsuranceUtil() {
        this.commonUtil = new AccountServiceUtil();
    }

    /**
     * Retrieve Insurance Details List.
     * 
     * @param insuranceTypeList
     * @param commonUtil
     * @return
     * @throws SILException
     */
    public List<RiderDetails> retrieveInsuranceDetails(List<RiderDetailType> insuranceTypeList) throws SILException {
        SILLogger.debug(loggerType, className, "Entering retrieveInsuranceDetailsList()");
        List<RiderDetails> insuranceList = new ArrayList<RiderDetails>();
        for (RiderDetailType insuranceType : insuranceTypeList) {
            if (insuranceType != null) {
                RiderDetails insurance = new RiderDetails();
                insurance = retrieveInsuranceparams(insuranceType, insurance);
                insuranceList.add(insurance);
            }
        }
        return insuranceList;
    }

    /**
     * Retrieve Insurance Details.
     * 
     * @param detailType
     * @param commonUtil
     * @param insurance
     * @throws SILException
     */
    private RiderDetails retrieveInsuranceparams(RiderDetailType detailType, RiderDetails insurance) throws SILException {
        insurance.setId(commonUtil.retrieveLongValue(detailType.getId(), loggerType));
        insurance.setRiderTemplate(retrieveRiderTemplate(detailType.getRiderTemplate()));
        insurance.setRiderTemplateDetails(retrieveRiderTemplateDetails(detailType.getRiderTemplateDetails()));
        insurance.setDateOfBirth(commonUtil.retrieveDateValue(detailType.getDateOfBirth(), loggerType));
        insurance.setStatus(commonUtil.retrieveCode(detailType.getStatus(), loggerType));
        insurance.setSex(commonUtil.retrieveCode(detailType.getSex(), loggerType));
        insurance.setSumInsured(commonUtil.retrieveBigDecimalValue(detailType.getSumInsured(), loggerType));
        insurance.setReviewTerm(retrieveReviewTerm(detailType.getReviewTerm()));
        insurance.setAllowableReviewType(retrieveAllowableReviewDetails(detailType.getAllowableReviewType()));
        insurance.setCoverReason(commonUtil.retrieveCode(detailType.getCoverReason(), loggerType));
        insurance.setFutureInsure(detailType.getFutureInsure());
        insurance.setSmokeStatus(commonUtil.retrieveCode(detailType.getSmokerStatus(), loggerType));
        insurance.setOccupationCategory(commonUtil.retrieveCode(detailType.getOccupationCategory(), loggerType));
        insurance.setRiskCommenceDate(commonUtil.retrieveDateValue(detailType.getRiskCommenceDate(), loggerType));
        insurance.setNextReviewDate(commonUtil.retrieveDateValue(detailType.getNextReviewDate(), loggerType));
        insurance.setBenefit(retrieveBenefitDetails(detailType.getBenefit()));
        this.retrieveInsuranceDetailsContd(detailType, insurance);
        return insurance;
    }

    /**
     * This method is used to retrieve retrieveBenefitDetails.
     * 
     * @param commonUtil
     * 
     * @param benefit
     * @return
     * @throws SILException
     */
    private BenefitIdentifierDetails retrieveBenefitDetails(BenefitIdentifierType benefitType) throws SILException {
        BenefitIdentifierDetails benefitIdentifierDetails = new BenefitIdentifierDetails();
        if (benefitType != null) {
            benefitIdentifierDetails.setId(commonUtil.retrieveLongValue(benefitType.getId(), loggerType));
            benefitIdentifierDetails.setName(benefitType.getName());
            benefitIdentifierDetails.setBenefitSequence(commonUtil.retrieveBigIntegerValue(benefitType.getBenefitSequence(), loggerType));
            benefitIdentifierDetails.setBenefitTemplate(retrieveBenefitTemplate(benefitType.getBenefitTemplate()));
        } else {
            benefitIdentifierDetails = retrieveEmptyBenefitDetails();
        }
        return benefitIdentifierDetails;
    }

    /**
     * Retrieve Benefit Template.
     * 
     * @param benefitTemplate
     * @param commonUtil
     * @return
     * @throws SILException
     */
    private BenefitTemplateIdentifierDetails retrieveBenefitTemplate(BenefitTemplateIdentifierType benefitTemplate) throws SILException {
        SILLogger.debug(loggerType, className, "Entering retrieveBenefitTemplate()");
        BenefitTemplateIdentifierDetails benefitTemplateDetails = new BenefitTemplateIdentifierDetails();
        if (benefitTemplate != null) {
            benefitTemplateDetails.setId(commonUtil.retrieveLongValue(benefitTemplate.getId(), loggerType));
            benefitTemplateDetails.setLongName(benefitTemplate.getLongName());
            benefitTemplateDetails.setName(benefitTemplate.getName());
            benefitTemplateDetails.setProduct(retrieveInsuranceProductDetails(benefitTemplate.getProduct()));
        }
        return benefitTemplateDetails;
    }

    /**
     * Retrieve Rider Template Details.
     * 
     * @param riderTemplateType
     * @param commonUtil
     * @return
     * @throws SILException
     */
    private RiderTemplateDetails retrieveRiderTemplateDetails(RiderTemplateDetailsType riderTemplateType) throws SILException {
        SILLogger.debug(loggerType, className, "Entering retrieveRiderTemplateDetails()");
        RiderTemplateDetails riderTemplate = new RiderTemplateDetails();
        if (riderTemplateType != null) {
            riderTemplate.setRiderType(commonUtil.retrieveCode(riderTemplateType.getRiderType(), loggerType));
        }
        return riderTemplate;
    }

    /**
     * Retrieve Product Details.
     * 
     * @param product
     * @param commonUtil
     * @return
     * @throws SILException
     */
    private ProductDetails retrieveInsuranceProductDetails(ProductIdentifierType product) throws SILException {
        SILLogger.debug(loggerType, className, "Entering retrieveProductDetails()");
        ProductDetails productDetails = new ProductDetails();
        if (product != null) {
            productDetails.setId(commonUtil.retrieveLongValue(product.getId(), loggerType));
            productDetails.setName(product.getName());
            productDetails.setProductRef(commonUtil.retrieveExternalRef(product.getProductExternalRef(), loggerType));
        }
        return productDetails;
    }

    /**
     * Retrieve Insurance Details Contd.
     * 
     * @param detailType
     * @param commonUtil
     * @param insurance
     * @throws SILException
     */
    private void retrieveInsuranceDetailsContd(RiderDetailType detailType, RiderDetails insurance) throws SILException {
        SILLogger.debug(loggerType, className, "Entering retrieveInsuranceDetailsContd()");
        insurance.setRiskCeaseDate(commonUtil.retrieveDateValue(detailType.getRiskCeaseDate(), loggerType));
        insurance.setIsAgeAdjusted(commonUtil.retrieveBooleanValue(detailType.isIsAgeAdjusted(), loggerType));
        insurance.setBenefitPeriod(detailType.getBenefitPeriod());
        insurance.setWaitPeriod(detailType.getWaitPeriod());
        insurance.setRiskTerm(commonUtil.retrieveLongValue(detailType.getRiskTerm(), loggerType));
        insurance.setPremiumTerm(commonUtil.retrieveLongValue(detailType.getPremiumTerm(), loggerType));
        insurance.setRiskTermAge(commonUtil.retrieveLongValue(detailType.getRiskTermAge(), loggerType));
        insurance.setPremiumTermAge(commonUtil.retrieveLongValue(detailType.getPremiumTermAge(), loggerType));
        insurance.setTotalLoadings(commonUtil.retrieveBigDecimalValue(detailType.getTotalLoadings(), loggerType));
        insurance.setAnnualPremium(commonUtil.retrieveBigDecimalValue(detailType.getAnnualPremium(), loggerType));
        insurance.setInstalmentPremium(commonUtil.retrieveBigDecimalValue(detailType.getInstalmentPremium(), loggerType));
        insurance.setAnnualPremiumExLoadings(commonUtil.retrieveBigDecimalValue(detailType.getAnnualPremiumExLoadings(), loggerType));
        insurance.setLastRenewalDate(commonUtil.retrieveDateValue(detailType.getLastRenewalDate(), loggerType));
        insurance.setSalaryFactor(commonUtil.retrieveBigDecimalValue(detailType.getSalaryFactor(), loggerType));
        insurance.setUnitsOfSI(commonUtil.retrieveBigDecimalValue(detailType.getUnitsOfSI(), loggerType));
        insurance.setEmploymentSalary(commonUtil.retrieveBigDecimalValue(detailType.getEmploymentSalary(), loggerType));
        insurance.setInsuranceSalary(commonUtil.retrieveBigDecimalValue(detailType.getInsuranceSalary(), loggerType));
        this.retrieveInsuranceDetailsContd2(detailType, insurance);
    }

    /**
     * Retrieve Insurance Details Contd2.
     * 
     * @param detailType
     * @param commonUtil
     * @param insurance
     * @throws SILException
     */
    private void retrieveInsuranceDetailsContd2(RiderDetailType detailType, RiderDetails insurance) throws SILException {
        SILLogger.debug(loggerType, className, "Entering retrieveInsuranceDetailsContd2()");
        insurance.setParameterType(this.retrieveParameterDetails(detailType.getParameterType()));
        insurance.setRiskRule(commonUtil.retrieveCode(detailType.getRiskRule(), loggerType));
        insurance.setLoading(retrieveLoadingDetails(detailType.getLoading()));
        insurance.setExclusion(this.retrieveExclusionDetails(detailType.getExclusion()));
        insurance.setClaimReviewType(this.retrieveClaimReviewDetails(detailType.getClaimReviewType()));
        insurance.setRevPercentageRate(commonUtil.retrieveBigDecimalValue(detailType.getRevPercentageRate(), loggerType));
        insurance.setReviewAmount(commonUtil.retrieveBigDecimalValue(detailType.getReviewAmount(), loggerType));
        insurance.setRiderRatio(commonUtil.retrieveBigDecimalValue(detailType.getRiderRatio(), loggerType));
        insurance.setModalPremium(commonUtil.retrieveBigDecimalValue(detailType.getModalPremium(), loggerType));
        insurance.setIsQuote(commonUtil.retrieveBooleanValue(detailType.isIsQuote(), loggerType));
    }

    /**
     * Retrieve Exclusion Details.
     * 
     * @param exclusionTypeList
     * @param commonUtil
     * @return
     * @throws SILException
     */
    private List<ExclusionDetails> retrieveExclusionDetails(List<ExclusionDetailType> exclusionTypeList) throws SILException {
        SILLogger.debug(loggerType, className, "Entering retrieveExclusionDetails()");
        List<ExclusionDetails> exclusionList = new ArrayList<ExclusionDetails>();
        if (exclusionTypeList != null && exclusionTypeList.size() > 0) {
            ExclusionDetails exclusion = new ExclusionDetails();
            for (ExclusionDetailType exclusionType : exclusionTypeList) {
                exclusion.setReviewTerm(commonUtil.retrieveLongValue(exclusionType.getReviewTerm(), loggerType));
                exclusion.setLongDescription(exclusionType.getLongDescription());
                exclusion.setExclusionFullText(exclusionType.getExclusionFullText());
                exclusion.setShortDescription(exclusionType.getShortDescription());
                exclusion.setCategory(commonUtil.retrieveCode(exclusionType.getCategory(), loggerType));
                exclusionList.add(exclusion);
            }
        }
        return exclusionList;
    }

    /**
     * Retrieve Claim Review Details.
     * 
     * @param claimReviewType
     * @param commonUtil
     * @return
     * @throws SILException
     */
    private ReviewTypeIdentifierDetails retrieveClaimReviewDetails(ReviewTypeIdentifierType claimReviewType) throws SILException {
        SILLogger.debug(loggerType, className, "Entering retrieveClaimReviewDetails()");
        ReviewTypeIdentifierDetails reviewTypeIdentifierDetails = new ReviewTypeIdentifierDetails();
        if (claimReviewType != null) {
            reviewTypeIdentifierDetails.setLongName(claimReviewType.getLongName());
        } else {
            reviewTypeIdentifierDetails = retrieveEmptyReviewType();
        }
        return reviewTypeIdentifierDetails;
    }

    /**
     * Retrieve Loading Details.
     * 
     * @param typeList
     * @param commonUtil
     * @return
     * @throws SILException
     */
    private List<LoadingDetails> retrieveLoadingDetails(List<LoadingDetailType> typeList) throws SILException {
        SILLogger.debug(loggerType, className, "Entering retrieveLoadingDetails()");
        List<LoadingDetails> loadingList = new ArrayList<LoadingDetails>();
        if (loadingList != null && loadingList.size() > 0) {
            LoadingDetails loading = new LoadingDetails();
            for (LoadingDetailType loadingType : typeList) {
                loading.setDollarAmount(commonUtil.retrieveBigDecimalValue(loadingType.getDollarAmount(), loggerType));
                loading.setEndDate(commonUtil.retrieveDateValue(loadingType.getEndDate(), loggerType));
                loading.setFixedLoadAmount(commonUtil.retrieveBigDecimalValue(loadingType.getFixedLoadAmount(), loggerType));
                loading.setPartialTerm(commonUtil.retrieveBigIntegerValue(loadingType.getPartialTerm(), loggerType));
                loading.setPercLoadAmount(commonUtil.retrieveBigDecimalValue(loadingType.getPercLoadAmount(), loggerType));
                loading.setPremium(commonUtil.retrieveBigDecimalValue(loadingType.getPremium(), loggerType));
                loading.setReason(commonUtil.retrieveCode(loadingType.getReason(), loggerType));
                loading.setStartDate(commonUtil.retrieveDateValue(loadingType.getStartDate(), loggerType));
                loading.setStatus(commonUtil.retrieveCode(loadingType.getStatus(), loggerType));
                loading.setType(loadingType.getType());
                loadingList.add(loading);
            }
        }
        return loadingList;
    }

    /**
     * Retrieve Parameter Details.
     * 
     * @param riderParameterTypeList
     * @param commonUtil
     * @return
     * @throws SILException
     */
    private List<RiderParameterDetails> retrieveParameterDetails(List<RiderParameterType> riderParameterTypeList) throws SILException {
        SILLogger.debug(loggerType, className, "Entering retrieveParameterDetails()");
        List<RiderParameterDetails> riderParameterList = new ArrayList<RiderParameterDetails>();
        RiderParameterDetails riderParameter = new RiderParameterDetails();
        if (riderParameterTypeList != null && riderParameterTypeList.size() > 0) {
            for (RiderParameterType riderParameterType : riderParameterTypeList) {
                riderParameter.setId(commonUtil.retrieveLongValue(riderParameterType.getId(), loggerType));
                riderParameter.setName(riderParameterType.getName());
                riderParameter.setValue(riderParameterType.getValue());
                riderParameterList.add(riderParameter);
            }
        } else {
            riderParameterList = retrieveEmptyParameterDetails();
        }
        return riderParameterList;
    }

    /**
     * Retrieve Allowable Review Details.
     * 
     * @param allowableReviewType
     * @param commonUtil
     * @return allowableReview
     */
    private AllowableReviewIdentifierDetails retrieveAllowableReviewDetails(AllowableReviewTypeIdentifierType allowableReviewType) {
        SILLogger.debug(loggerType, className, "Entering retrieveAllowableReviewDetails()");
        AllowableReviewIdentifierDetails allowableReview = new AllowableReviewIdentifierDetails();
        ReviewTypeIdentifierDetails reviewType = new ReviewTypeIdentifierDetails();
        if (allowableReviewType != null && allowableReviewType.getReviewType() != null) {
            reviewType.setLongName(allowableReviewType.getReviewType().getLongName());
            allowableReview.setReviewType(reviewType);
        } else {
            allowableReview = retrieveEmptyAllowableReview();
        }
        return allowableReview;
    }

    /**
     * Retrieve Review Term.
     * 
     * @param reviewTerm
     * @param commonUtil
     * @return
     * @throws SILException
     */
    private ReviewTermIdentifierDetails retrieveReviewTerm(ReviewTermIdentifierType reviewTerm) throws SILException {
        SILLogger.debug(loggerType, className, "Entering retrieveReviewTerm()");
        ReviewTermIdentifierDetails reviewTermIdentifierDetails = new ReviewTermIdentifierDetails();
        if (reviewTerm != null) {
            reviewTermIdentifierDetails.setTermToTime(retrieveReviewTermDetails(reviewTerm.getTermToAge(), loggerType));
            reviewTermIdentifierDetails.setTermToAge(retrieveReviewTermDetails(reviewTerm.getTermToAge(), loggerType));
        } else {
            reviewTermIdentifierDetails = retrieveEmptyReviewTerm();
        }
        return reviewTermIdentifierDetails;
    }

    /**
     * Retrieve Review Term Details.
     * 
     * @param termToAge
     * @param loggerType
     * @return
     * @throws SILException
     */
    public ReviewTermDetails retrieveReviewTermDetails(ReviewTermType termToAge, String loggerType) throws SILException {
        SILLogger.debug(loggerType, className, "Entering in retrieveReviewTermDetails method");
        ReviewTermDetails reviewTermDetails = new ReviewTermDetails();
        if (termToAge != null) {
            reviewTermDetails.setReviewTerm(retrieveBigIntegerValue(termToAge.getReviewTerm(), loggerType));
            reviewTermDetails.setSubseqReviewTerm(retrieveBigIntegerValue(termToAge.getSubseqReviewTerm(), loggerType));
        }
        return reviewTermDetails;
    }

    /**
     * This method convert Big Integer value to String object.
     * 
     * @return String
     */
    public String retrieveBigIntegerValue(BigInteger value, String loggerType) throws SILException {
        SILLogger.debug(loggerType, className, "Entering in retrieveBigIntegerValue method");
        if (value != null) {
            return value.toString();
        } else {
            return AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING;
        }
    }

    /**
     * Retrieve Rider Template.
     * 
     * @param riderTemplateType
     * @param commonUtil
     * 
     * @return
     * @throws SILException
     */
    private RiderTemplate retrieveRiderTemplate(RiderTemplateIdentifierType riderTemplateType) throws SILException {
        SILLogger.debug(loggerType, className, "Entering retrieveRiderTemplate()");
        RiderTemplate riderTemplate = new RiderTemplate();
        if (riderTemplateType != null) {
            riderTemplate.setId(commonUtil.retrieveLongValue(riderTemplateType.getId(), loggerType));
            riderTemplate.setName(riderTemplateType.getName());
            riderTemplate.setBenefitTemplate(retrieveBenefitTemplate(riderTemplateType.getBenefitTemplate()));
            riderTemplate.setShortName(riderTemplateType.getShortName());
        } else {
            riderTemplate = retrieveEmptyRiderTemplate();
        }
        return riderTemplate;
    }

    /**
     * Retrieve Empty Rider Template.
     * 
     * @param loggerType
     * 
     * @return
     */
    public RiderTemplate retrieveEmptyRiderTemplate() {
        SILLogger.debug(loggerType, className, "Entering in retrieveEmptyRiderTemplate method");
        RiderTemplate riderTemplate = new RiderTemplate();
        riderTemplate.setId("");
        riderTemplate.setName("");
        riderTemplate.setBenefitTemplate(retrieveEmptyBenefitTemplate());
        riderTemplate.setShortName("");
        return riderTemplate;
    }

    /**
     * Retrieve Empty Benefit Template.
     * 
     * @param loggerType
     * @return
     */
    public BenefitTemplateIdentifierDetails retrieveEmptyBenefitTemplate() {
        SILLogger.debug(loggerType, className, "Entering in retrieveEmptyBenefitTemplate method");
        BenefitTemplateIdentifierDetails benefitTemplateIdentifierDetails = new BenefitTemplateIdentifierDetails();
        benefitTemplateIdentifierDetails.setId("");
        benefitTemplateIdentifierDetails.setLongName("");
        benefitTemplateIdentifierDetails.setName("");
        benefitTemplateIdentifierDetails.setProduct(retrieveEmptyProductDetails());
        return benefitTemplateIdentifierDetails;
    }

    /**
     * Retrieve Empty Product Details.
     * 
     * @param loggerType
     * @return
     */
    public ProductDetails retrieveEmptyProductDetails() {
        SILLogger.debug(loggerType, className, "Entering in retrieveEmptyProductDetails method");
        ProductDetails productIdentifierDetails = new ProductDetails();
        productIdentifierDetails.setId("");
        productIdentifierDetails.setName("");
        productIdentifierDetails.setProductRef(retrieveEmptyExternalRef());
        productIdentifierDetails.setShortName("");
        return productIdentifierDetails;
    }

    /**
     * Retrieve Empty External Ref.
     * 
     * @param loggerType
     * @return
     */
    private ReferenceIdentifier retrieveEmptyExternalRef() {
        SILLogger.debug(loggerType, className, "Entering in retrieveEmptyBenefitTemplate method");
        ReferenceIdentifier externalReference = new ReferenceIdentifier();
        externalReference.setReference("");
        externalReference.setReferenceCode("");
        return externalReference;
    }

    /**
     * Retrieve Empty Review Term.
     * 
     * @param loggerType
     * @return
     */
    public ReviewTermIdentifierDetails retrieveEmptyReviewTerm() {
        SILLogger.debug(loggerType, className, "Entering in retrieveEmptyReviewTerm method");
        ReviewTermIdentifierDetails reviewTerm = new ReviewTermIdentifierDetails();
        reviewTerm.setTermToAge(retrieveEmptyReviewIdentifierTerm());
        reviewTerm.setTermToTime(retrieveEmptyReviewIdentifierTerm());
        return reviewTerm;
    }

    /**
     * Retrieve Empty Review Identifier Term.
     * 
     * @param loggerType
     * @return
     */
    private ReviewTermDetails retrieveEmptyReviewIdentifierTerm() {
        SILLogger.debug(loggerType, className, "Entering in retrieveEmptyReviewTerm method");
        ReviewTermDetails reviewTermDetails = new ReviewTermDetails();
        reviewTermDetails.setReviewTerm("");
        reviewTermDetails.setSubseqReviewTerm("");
        return reviewTermDetails;
    }

    /**
     * Retrieve Empty Allowable Review Details.
     * 
     * @param loggerType
     * @return
     */
    public AllowableReviewIdentifierDetails retrieveEmptyAllowableReviewDetails() {
        SILLogger.debug(loggerType, className, "Entering in retrieveEmptyAllowableReviewDetails method");
        AllowableReviewIdentifierDetails allowableReview = new AllowableReviewIdentifierDetails();
        allowableReview.setReviewType(retrieveEmptyReviewType());
        return allowableReview;
    }

    /**
     * Retrieve Empty Review Type.
     * 
     * @param loggerType
     * @return
     */
    public ReviewTypeIdentifierDetails retrieveEmptyReviewType() {
        SILLogger.debug(loggerType, className, "Entering in retrieveEmptyReviewType method");
        ReviewTypeIdentifierDetails reviewType = new ReviewTypeIdentifierDetails();
        reviewType.setLongName("");
        return reviewType;
    }

    /**
     * Retrieve Empty Allowable Review.
     * 
     * @param loggerType
     * @return
     */
    public AllowableReviewIdentifierDetails retrieveEmptyAllowableReview() {
        SILLogger.debug(loggerType, className, "Entering retrieveAllowableReviewDetails()");
        AllowableReviewIdentifierDetails allowableReview = new AllowableReviewIdentifierDetails();
        ReviewTypeIdentifierDetails reviewType = new ReviewTypeIdentifierDetails();
        reviewType.setLongName("");
        allowableReview.setReviewType(reviewType);
        return allowableReview;
    }

    /**
     * This method is used to retrieve empty retrieveBenefitDetails.
     * 
     * @param commonUtil
     * 
     * @return
     */
    private BenefitIdentifierDetails retrieveEmptyBenefitDetails() {
        BenefitIdentifierDetails benefitIdentifierDetails = new BenefitIdentifierDetails();
        benefitIdentifierDetails.setId("");
        benefitIdentifierDetails.setName("");
        benefitIdentifierDetails.setBenefitSequence("");
        benefitIdentifierDetails.setBenefitTemplate(retrieveEmptyBenefitTemplate());
        return benefitIdentifierDetails;
    }

    /**
     * Retrieve Empty Parameter Details.
     * 
     * @param loggerType
     * 
     * @return
     */
    public List<RiderParameterDetails> retrieveEmptyParameterDetails() {
        SILLogger.debug(loggerType, className, "Entering in retrieveEmptyParameterDetails method");
        List<RiderParameterDetails> parameterDetailsList = new ArrayList<RiderParameterDetails>();
        RiderParameterDetails riderParameterDetails = new RiderParameterDetails();
        riderParameterDetails.setId("");
        riderParameterDetails.setName("");
        riderParameterDetails.setValue("");
        parameterDetailsList.add(riderParameterDetails);
        return parameterDetailsList;
    }
}
