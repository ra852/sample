////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import com.sonatacentral.service.v30.wrap.account.SaveInvestmentRestructureResponseType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.SaveInvestmentRestuctureResponse;

/**
 * The class {@code SaveInvestmentRestructureResponseUtil} construct's SOAP request for external service.
 * 
 * @author U387938
 * @since 20/03/2016
 * @version 1.0
 */
public class SaveInvestmentRestructureResponseUtil {
    private final String className = "SaveInvestmentRestructureResponseUtil";
    private SaveInvestmentRestructureResponseType saveInvestmentRestructureResponseType;

    public SaveInvestmentRestructureResponseUtil(SaveInvestmentRestructureResponseType saveInvestmentRestructureResponseType) {
        this.saveInvestmentRestructureResponseType = saveInvestmentRestructureResponseType;
    }

    /**
     * 
     * This method constructs SaveInvestmentRestuctureResponse object from response.
     * 
     * @param saveInvestmentRestuctureResponse
     * @throws SILException
     */
    public void setSaveInvestmentRestructureResponse(SaveInvestmentRestuctureResponse saveInvestmentRestuctureResponse) throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_RESTRUCTURE_LOGGING_FORMAT, className,
                "Entering setSaveInvestmentRestructureResponse");
        if (saveInvestmentRestructureResponseType != null) {
            if (saveInvestmentRestructureResponseType.getTransactionEventId() != null) {
                saveInvestmentRestuctureResponse.setTransactionEventId(String.valueOf(saveInvestmentRestructureResponseType.getTransactionEventId()));
            } else {
                saveInvestmentRestuctureResponse.setStatus(AccountServiceConstants.SAVE_INVESTMENT_RESTRUCTURE_SUCCESS_MSG);
            }
        } else {
            throw new SILException(AccountServiceConstants.INVALID_RESPONSE_FROM_SONATA);
        }
    }

}
