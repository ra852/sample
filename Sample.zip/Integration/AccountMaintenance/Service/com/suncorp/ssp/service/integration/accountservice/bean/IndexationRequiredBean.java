////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;
/**
 * The class {@code IndexationRequiredBean} does this.
 * 
 * @author U387938
 * @since 02/02/2016
 * @version 1.0
 */
public class IndexationRequiredBean {

    private String indexationDate; 
    private String indexationRate;
    private String indexationRunDate;
    private String indexationDeclined;
    /**
     * Accessor for property indexationDate.
     *
     * @return indexationDate of type String
     */
    public String getIndexationDate() {
        return indexationDate;
    }
    /**
     * Mutator for property indexationDate.
     *
     * @param indexationDate of type String
     */
    @XmlElement(name = "indexationDate")
    public void setIndexationDate(String indexationDate) {
        this.indexationDate = indexationDate != null ? indexationDate : "";
    }
    /**
     * Accessor for property indexationRate.
     *
     * @return indexationRate of type String
     */
    public String getIndexationRate() {
        return indexationRate;
    }
    /**
     * Mutator for property indexationRate.
     *
     * @param indexationRate of type String
     */
    @XmlElement(name = "indexationRate")
    public void setIndexationRate(String indexationRate) {
        this.indexationRate = indexationRate != null ? indexationRate : "";
    }
    /**
     * Accessor for property indexationRunDate.
     *
     * @return indexationRunDate of type String
     */
    public String getIndexationRunDate() {
        return indexationRunDate;
    }
    /**
     * Mutator for property indexationRunDate.
     *
     * @param indexationRunDate of type String
     */
    @XmlElement(name = "indexationRunDate")
    public void setIndexationRunDate(String indexationRunDate) {
        this.indexationRunDate = indexationRunDate != null ? indexationRunDate : "";
    }
    /**
     * Accessor for property indexationDeclined.
     *
     * @return indexationDeclined of type String
     */
    public String getIndexationDeclined() {
        return indexationDeclined;
    }
    /**
     * Mutator for property indexationDeclined.
     *
     * @param indexationDeclined of type String
     */
    @XmlElement(name = "indexationDeclined")
    public void setIndexationDeclined(String indexationDeclined) {
        this.indexationDeclined = indexationDeclined != null ? indexationDeclined : "";
    } 
    
    
}
