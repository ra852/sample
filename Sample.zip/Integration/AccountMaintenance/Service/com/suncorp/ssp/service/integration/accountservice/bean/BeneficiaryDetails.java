////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * The class {@code BeneficiaryDetails} does this.
 * 
 * @author u384380
 * @since 28/10/2015
 * @version 1.0
 */
@XmlRootElement(name = "beneficiary")
public class BeneficiaryDetails {
    private String clientId;
    private String clientAccountRelationshipName;
    private String clientAccountRelationshipCode;
    private String beneficiaryId;
    private String firstName;
    private String middleName;
    private String lastName;
    private String dateOfBirth;
    private String categoryCode;
    private String categoryCodeType;
    private String categoryCodeShortDescription;
    private String categoryCodeDescription;
    private String typeCode;
    private String typeCodeType;
    private String typeCodeShortDescription;
    private String typeCodeDescription;
    private String relationshipCode;
    private String relationshipCodeType;
    private String relationshipCodeShortDescription;
    private String relationshipCodeDescription;
    private String adviceReceived;
    private String endDate;
    private String dateNominationSigned;
    private String allocation;
    private String deleteFlag;
    
    private ClientAccountRelationshipIdentifierBean clientAccountRelationship;
    private String id;
    private CodeIdentifier category;
    private CodeIdentifier type;
    private CodeIdentifier relationship;
    private String splitPercentage;
    private AdvisorDetails distributionOutlet;

    /**
     * Accessor for property clientId.
     * 
     * @return clientId of type String
     */
    public String getClientId() {
        return clientId;
    }

    /**
     * Mutator for property clientId.
     * 
     * @return clientId of type String
     */
    @XmlElement(name = "clientId")
    public void setClientId(String clientId) {
        this.clientId = clientId != null ? clientId : "";
    }

    /**
     * Accessor for property clientAccountRelationshipName.
     * 
     * @return clientAccountRelationshipName of type String
     */
    public String getClientAccountRelationshipName() {
        return clientAccountRelationshipName;
    }

    /**
     * Mutator for property clientAccountRelationshipName.
     * 
     * @return clientAccountRelationshipName of type String
     */
    @XmlElement(name = "clientAccountRelationshipName")
    public void setClientAccountRelationshipName(String clientAccountRelationshipName) {
        this.clientAccountRelationshipName = clientAccountRelationshipName != null ? clientAccountRelationshipName : "";
    }

    /**
     * Accessor for property clientAccountRelationshipCode.
     * 
     * @return clientAccountRelationshipCode of type String
     */
    public String getClientAccountRelationshipCode() {
        return clientAccountRelationshipCode;
    }

    /**
     * Mutator for property clientAccountRelationshipCode.
     * 
     * @return clientAccountRelationshipCode of type String
     */
    @XmlElement(name = "clientAccountRelationshipCode")
    public void setClientAccountRelationshipCode(String clientAccountRelationshipCode) {
        this.clientAccountRelationshipCode = clientAccountRelationshipCode != null ? clientAccountRelationshipCode : "";
    }

    /**
     * Accessor for property beneficiaryId.
     * 
     * @return beneficiaryId of type String
     */
    public String getBeneficiaryId() {
        return beneficiaryId;
    }

    /**
     * Mutator for property beneficiaryId.
     * 
     * @return beneficiaryId of type String
     */
    @XmlElement(name = "beneficiaryId")
    public void setBeneficiaryId(String beneficiaryId) {
        this.beneficiaryId = beneficiaryId != null ? beneficiaryId : "";
    }

    /**
     * Accessor for property firstName.
     * 
     * @return firstName of type String
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Mutator for property firstName.
     * 
     * @return firstName of type String
     */
    @XmlElement(name = "firstName")
    public void setFirstName(String firstName) {
        this.firstName = firstName != null ? firstName : "";
    }

    /**
     * Accessor for property middleName.
     * 
     * @return middleName of type String
     */
    public String getMiddleName() {
        return middleName;
    }

    /**
     * Mutator for property middleName.
     * 
     * @return middleName of type String
     */
    @XmlElement(name = "middleName")
    public void setMiddleName(String middleName) {
        this.middleName = middleName != null ? middleName : "";
    }

    /**
     * Accessor for property lastName.
     * 
     * @return lastName of type String
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Mutator for property lastName.
     * 
     * @return lastName of type String
     */
    @XmlElement(name = "lastName")
    public void setLastName(String lastName) {
        this.lastName = lastName != null ? lastName : "";
    }

    /**
     * Accessor for property dateOfBirth.
     * 
     * @return dateOfBirth of type String
     */
    public String getDateOfBirth() {
        return dateOfBirth;
    }

    /**
     * Mutator for property dateOfBirth.
     * 
     * @return dateOfBirth of type String
     */
    @XmlElement(name = "dob")
    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth != null ? dateOfBirth : "";
    }

    /**
     * Accessor for property categoryCode.
     * 
     * @return categoryCode of type String
     */
    public String getCategoryCode() {
        return categoryCode;
    }

    /**
     * Mutator for property categoryCode.
     * 
     * @return categoryCode of type String
     */
    @XmlElement(name = "categoryCode")
    public void setCategoryCode(String categoryCode) {
        this.categoryCode = categoryCode != null ? categoryCode : "";
    }

    /**
     * Accessor for property categoryCodeType.
     * 
     * @return categoryCodeType of type String
     */
    public String getCategoryCodeType() {
        return categoryCodeType;
    }

    /**
     * Mutator for property categoryCodeType.
     * 
     * @return categoryCodeType of type String
     */
    @XmlElement(name = "categoryCodeType")
    public void setCategoryCodeType(String categoryCodeType) {
        this.categoryCodeType = categoryCodeType != null ? categoryCodeType : "";
    }

    /**
     * Accessor for property categoryCodeShortDescription.
     * 
     * @return categoryCodeShortDescription of type String
     */
    public String getCategoryCodeShortDescription() {
        return categoryCodeShortDescription;
    }

    /**
     * Mutator for property categoryCodeShortDescription.
     * 
     * @return categoryCodeShortDescription of type String
     */
    @XmlElement(name = "categoryCodeShortDescription")
    public void setCategoryCodeShortDescription(String categoryCodeShortDescription) {
        this.categoryCodeShortDescription = categoryCodeShortDescription != null ? categoryCodeShortDescription : "";
    }

    /**
     * Accessor for property categoryCodeDescription.
     * 
     * @return categoryCodeDescription of type String
     */
    public String getCategoryCodeDescription() {
        return categoryCodeDescription;
    }

    /**
     * Mutator for property categoryCodeDescription.
     * 
     * @return categoryCodeDescription of type String
     */
    @XmlElement(name = "categoryCodeDescription")
    public void setCategoryCodeDescription(String categoryCodeDescription) {
        this.categoryCodeDescription = categoryCodeDescription != null ? categoryCodeDescription : "";
    }

    /**
     * Accessor for property typeCode.
     * 
     * @return typeCode of type String
     */
    public String getTypeCode() {
        return typeCode;
    }

    /**
     * Mutator for property typeCode.
     * 
     * @return typeCode of type String
     */
    @XmlElement(name = "typeCode")
    public void setTypeCode(String typeCode) {
        this.typeCode = typeCode != null ? typeCode : "";
    }

    /**
     * Accessor for property typeCodeType.
     * 
     * @return typeCodeType of type String
     */
    public String getTypeCodeType() {
        return typeCodeType;
    }

    /**
     * Mutator for property typeCodeType.
     * 
     * @return typeCodeType of type String
     */
    @XmlElement(name = "typeCodeType")
    public void setTypeCodeType(String typeCodeType) {
        this.typeCodeType = typeCodeType != null ? typeCodeType : "";
    }

    /**
     * Accessor for property typeCodeShortDescription.
     * 
     * @return typeCodeShortDescription of type String
     */
    public String getTypeCodeShortDescription() {
        return typeCodeShortDescription;
    }

    /**
     * Mutator for property typeCodeShortDescription.
     * 
     * @return typeCodeShortDescription of type String
     */
    @XmlElement(name = "typeCodeShortDescription")
    public void setTypeCodeShortDescription(String typeCodeShortDescription) {
        this.typeCodeShortDescription = typeCodeShortDescription != null ? typeCodeShortDescription : "";
    }

    /**
     * Accessor for property typeCodeDescription.
     * 
     * @return typeCodeDescription of type String
     */
    public String getTypeCodeDescription() {
        return typeCodeDescription;
    }

    /**
     * Mutator for property typeCodeDescription.
     * 
     * @return typeCodeDescription of type String
     */
    @XmlElement(name = "typeCodeDescription")
    public void setTypeCodeDescription(String typeCodeDescription) {
        this.typeCodeDescription = typeCodeDescription != null ? typeCodeDescription : "";
    }

    /**
     * Accessor for property relationshipCode.
     * 
     * @return relationshipCode of type String
     */
    public String getRelationshipCode() {
        return relationshipCode;
    }

    /**
     * Mutator for property relationshipCode.
     * 
     * @return relationshipCode of type String
     */
    @XmlElement(name = "relationshipCode")
    public void setRelationshipCode(String relationshipCode) {
        this.relationshipCode = relationshipCode != null ? relationshipCode : "";
    }

    /**
     * Accessor for property relationshipCodeType.
     * 
     * @return relationshipCodeType of type String
     */
    public String getRelationshipCodeType() {
        return relationshipCodeType;
    }

    /**
     * Mutator for property relationshipCodeType.
     * 
     * @return relationshipCodeType of type String
     */
    @XmlElement(name = "relationshipCodeType")
    public void setRelationshipCodeType(String relationshipCodeType) {
        this.relationshipCodeType = relationshipCodeType != null ? relationshipCodeType : "";
    }

    /**
     * Accessor for property relationshipCodeShortDescription.
     * 
     * @return relationshipCodeShortDescription of type String
     */
    public String getRelationshipCodeShortDescription() {
        return relationshipCodeShortDescription;
    }

    /**
     * Mutator for property relationshipCodeShortDescription.
     * 
     * @return relationshipCodeShortDescription of type String
     */
    @XmlElement(name = "relationshipCodeShortDescription")
    public void setRelationshipCodeShortDescription(String relationshipCodeShortDescription) {
        this.relationshipCodeShortDescription = relationshipCodeShortDescription != null ? relationshipCodeShortDescription : "";
    }

    /**
     * Accessor for property relationshipCodeDescription.
     * 
     * @return relationshipCodeDescription of type String
     */
    public String getRelationshipCodeDescription() {
        return relationshipCodeDescription;
    }

    /**
     * Mutator for property relationshipCodeDescription.
     * 
     * @return relationshipCodeDescription of type String
     */
    @XmlElement(name = "relationshipCodeDescription")
    public void setRelationshipCodeDescription(String relationshipCodeDescription) {
        this.relationshipCodeDescription = relationshipCodeDescription != null ? relationshipCodeDescription : "";
    }

    /**
     * Accessor for property adviceReceived.
     * 
     * @return adviceReceived of type String
     */
    public String getAdviceReceived() {
        return adviceReceived;
    }

    /**
     * Mutator for property adviceReceived.
     * 
     * @return adviceReceived of type String
     */
    @XmlElement(name = "adviceReceived")
    public void setAdviceReceived(String adviceReceived) {
        this.adviceReceived = adviceReceived != null ? adviceReceived : "";
    }

    /**
     * Accessor for property endDate.
     * 
     * @return endDate of type String
     */
    public String getEndDate() {
        return endDate;
    }

    /**
     * Mutator for property endDate.
     * 
     * @return endDate of type String
     */
    @XmlElement(name = "endDate")
    public void setEndDate(String endDate) {
        this.endDate = endDate != null ? endDate : "";
    }

    /**
     * Accessor for property dateNominationSigned.
     * 
     * @return dateNominationSigned of type String
     */
    public String getDateNominationSigned() {
        return dateNominationSigned;
    }

    /**
     * Mutator for property dateNominationSigned.
     * 
     * @return dateNominationSigned of type String
     */
    @XmlElement(name = "dateNominationSigned")
    public void setDateNominationSigned(String dateNominationSigned) {
        this.dateNominationSigned = dateNominationSigned != null ? dateNominationSigned : "";
    }

    /**
     * Accessor for property allocation.
     * 
     * @return allocation of type String
     */
    public String getAllocation() {
        return allocation;
    }

    /**
     * Mutator for property allocation.
     * 
     * @return allocation of type String
     */
    @XmlElement(name = "allocation")
    public void setAllocation(String allocation) {
        this.allocation = allocation != null ? allocation : "";
    }

    /**
     * Accessor for property deleteFlag.
     * 
     * @return deleteFlag of type String
     */
    public String getDeleteFlag() {
        return deleteFlag;
    }

    /**
     * Mutator for property deleteFlag.
     * 
     * @return deleteFlag of type String
     */
    @XmlElement(name = "deleteFlag")
    public void setDeleteFlag(String deleteFlag) {
        this.deleteFlag = deleteFlag != null ? deleteFlag : "";
    }

    

    /**
     * Accessor for property clientAccountRelationship.
     *
     * @return clientAccountRelationship of type ClientAccountRelationshipIdentifierBean
     */
    public ClientAccountRelationshipIdentifierBean getClientAccountRelationship() {
        return clientAccountRelationship;
    }

    /**
     * Mutator for property clientAccountRelationship.
     *
     * @param clientAccountRelationship of type ClientAccountRelationshipIdentifierBean
     */
    @XmlElement(name = "clientAccountRelationship")
    public void setClientAccountRelationship(ClientAccountRelationshipIdentifierBean clientAccountRelationship) {
        this.clientAccountRelationship = clientAccountRelationship;
    }

    /**
     * Accessor for property id.
     *
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     *
     * @param id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id != null ? id : "";
    }

    /**
     * Accessor for property category.
     *
     * @return category of type CodeIdentifier
     */
    public CodeIdentifier getCategory() {
        return category;
    }

    /**
     * Mutator for property category.
     *
     * @param category of type CodeIdentifier
     */
    @XmlElement(name = "category")
    public void setCategory(CodeIdentifier category) {
        this.category = category;
    }

    /**
     * Accessor for property type.
     *
     * @return type of type CodeIdentifier
     */
    public CodeIdentifier getType() {
        return type;
    }

    /**
     * Mutator for property type.
     *
     * @param type of type CodeIdentifier
     */
    @XmlElement(name = "type")
    public void setType(CodeIdentifier type) {
        this.type = type;
    }

    

    /**
     * Accessor for property relationship.
     *
     * @return relationship of type CodeIdentifier
     */
    public CodeIdentifier getRelationship() {
        return relationship;
    }

    /**
     * Mutator for property relationship.
     *
     * @param relationship of type CodeIdentifier
     */
    @XmlElement(name = "relationship")
    public void setRelationship(CodeIdentifier relationship) {
        this.relationship = relationship;
    }

    /**
     * Accessor for property splitPercentage.
     *
     * @return splitPercentage of type String
     */
    public String getSplitPercentage() {
        return splitPercentage;
    }

    /**
     * Mutator for property splitPercentage.
     *
     * @param splitPercentage of type String
     */
    @XmlElement(name = "splitPercentage")
    public void setSplitPercentage(String splitPercentage) {
        this.splitPercentage = splitPercentage != null ? splitPercentage : "";
    }

    /**
     * Accessor for property distributionOutlet.
     *
     * @return distributionOutlet of type AdvisorDetails
     */
    public AdvisorDetails getDistributionOutlet() {
        return distributionOutlet;
    }

    /**
     * Mutator for property distributionOutlet.
     *
     * @param distributionOutlet of type AdvisorDetails
     */
    @XmlElement(name = "distributionOutlet")
    public void setDistributionOutlet(AdvisorDetails distributionOutlet) {
        this.distributionOutlet = distributionOutlet;
    }

   
    
}
