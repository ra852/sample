////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import javax.ws.rs.core.MultivaluedMap;

import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType.AccountNumber;
import com.sonatacentral.service.v30.wrap.account.GetAccountDetailsRequestType;
import com.sonatacentral.service.v30.wrap.account.GetAccountDetailsRequestType.AccountDetails;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;

/**
 * The class {@code GetAccountDetailsListRequestUtil} is used as a util class for preparing GetAccountDetailsList request.
 * 
 * @author u387938
 * @since 23/12/2015
 * @version 1.0
 */
public class GetAccountDetailsListRequestUtil {
    private final String className = "GetAccountDetailsListRequestUtil";
    private GetAccountDetailsRequestType outboundRequest;
    private MultivaluedMap<String, String> inboundRequest;

    /**
     * Initializes class properties,viz., inbound and outbound request types.
     * 
     * @param inboundRequest of type MultivaluedMap
     */
    public GetAccountDetailsListRequestUtil(MultivaluedMap<String, String> inboundRequest) {
        this.inboundRequest = inboundRequest;
        this.outboundRequest = new GetAccountDetailsRequestType();
    }

    /**
     * 
     * Create Oubound(GetAccountDetailsRequestType) request.
     * 
     * @return
     * @throws Exception
     */
    public GetAccountDetailsRequestType createOutboundRequest() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACCOUNT_TRANS_LIST_LOGGING_FORMAT, className, "Entering createOutboundRequest()");
        this.outboundRequest.setCallerDetails(SILUtil.createCallerDetails());

        AccountDetails accountDetails = new AccountDetails();
        accountDetails.setAccount(constructAccountIdentifierType());

        outboundRequest.getAccountDetails().add(accountDetails);
        constructAccountDetailsIncludeParamsFirst();
        constructAccountDetailsIncludeParamsSecond();
        constructAccountDetailsIncludeParamsThird();
        constructAccountDetailsIncludeParamsFourth();
        constructAccountDetailsIncludeParamsFifth();
        constructAccountDetailsIncludeParamsSixth();

        return this.outboundRequest;
    }

    /**
     * 
     * Creates AccountIdentifierType accountNumber and product name.
     * 
     * @return
     * @throws SILException
     */
    private AccountIdentifierType constructAccountIdentifierType() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className, "Entering in constructAccountIdentifierType method.");
        AccountIdentifierType accountIdentifierType = new AccountIdentifierType();
        AccountNumber accountNumber = new AccountNumber();
        if (inboundRequest.containsKey("accountNumber") && inboundRequest.get("accountNumber").get(0) != null) {
            accountNumber.setAccountNo(inboundRequest.get("accountNumber").get(0));
        } else {
            throw new SILException(AccountServiceConstants.INVALID_ACCOUNTNUMBER_MESSAGE);
        }

        if (inboundRequest.containsKey("productName") && inboundRequest.get("productName").get(0) != null) {
            accountNumber.setProductName(inboundRequest.get("productName").get(0));
        }
        accountIdentifierType.setAccountNumber(accountNumber);

        constructAccountIdName(accountIdentifierType);
        return accountIdentifierType;
    }

    /**
     * 
     * Sets AccountId and account name in AccountIdentifierType.
     * 
     * @param accountIdentifierType
     */

    private void constructAccountIdName(AccountIdentifierType accountIdentifierType) throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className, "Entering in constructAccountIdName method.");
        if (inboundRequest.containsKey("accountId") && inboundRequest.get("accountId").get(0) != null) {
            accountIdentifierType.setId(Long.valueOf(inboundRequest.get("accountId").get(0)));
        }

        if (inboundRequest.containsKey("accountName") && inboundRequest.get("accountName").get(0) != null) {
            accountIdentifierType.setName(inboundRequest.get("accountName").get(0));
        }
        if (inboundRequest.containsKey("includeSchemeLocationHistory") && inboundRequest.get("includeSchemeLocationHistory").get(0) != null) {
            outboundRequest.setIncludeSchemeLocationHistory(Boolean.valueOf(inboundRequest.get("includeSchemeLocationHistory").get(0)));
        }
    }

    /**
     * 
     * Sets include parameters in GetAccountDetailsRequestType from request query params received
     * 
     * @throws SILException
     */
    private void constructAccountDetailsIncludeParamsFirst() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className,
                "Entering in constructAccountDetailsIncludeParamsFirst method.");
        if (inboundRequest.containsKey("includeAccountDetail") && inboundRequest.get("includeAccountDetail").get(0) != null) {
            outboundRequest.setIncludeAccountDetail(Boolean.valueOf(inboundRequest.get("includeAccountDetail").get(0)));
        }
        if (inboundRequest.containsKey("includeProduct") && inboundRequest.get("includeProduct").get(0) != null) {
            outboundRequest.setIncludeProduct(Boolean.valueOf(inboundRequest.get("includeProduct").get(0)));
        }
        if (inboundRequest.containsKey("includeScheme") && inboundRequest.get("includeScheme").get(0) != null) {
            outboundRequest.setIncludeScheme(Boolean.valueOf(inboundRequest.get("includeScheme").get(0)));
        }

    }

    /**
     * 
     * Sets include parameters in GetAccountDetailsRequestType from request query params received
     * 
     * @throws SILException
     */
    private void constructAccountDetailsIncludeParamsSecond() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className,
                "Entering in constructAccountDetailsIncludeParamsSecond method.");
        if (inboundRequest.containsKey("includeSchemeCategory") && inboundRequest.get("includeSchemeCategory").get(0) != null) {
            outboundRequest.setIncludeSchemeCategory(Boolean.valueOf(inboundRequest.get("includeSchemeCategory").get(0)));
        }
        if (inboundRequest.containsKey("includeMarketingCampaign") && inboundRequest.get("includeMarketingCampaign").get(0) != null) {
            outboundRequest.setIncludeMarketingCampaign(Boolean.valueOf(inboundRequest.get("includeMarketingCampaign").get(0)));
        }
        if (inboundRequest.containsKey("includeCurrentExpenseGroup") && inboundRequest.get("includeCurrentExpenseGroup").get(0) != null) {
            outboundRequest.setIncludeCurrentExpenseGroup(Boolean.valueOf(inboundRequest.get("includeCurrentExpenseGroup").get(0)));
        }

    }

    /***
     * 
     * Sets include parameters in GetAccountDetailsRequestType from request query params received
     * 
     * @throws SILException
     */
    private void constructAccountDetailsIncludeParamsThird() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className,
                "Entering in constructAccountDetailsIncludeParamsThird method.");
        if (inboundRequest.containsKey("includeClientAccountRelationship") && inboundRequest.get("includeClientAccountRelationship").get(0) != null) {
            outboundRequest.setIncludeClientAccountRelationship(Boolean.valueOf(inboundRequest.get("includeClientAccountRelationship").get(0)));
        }
        if (inboundRequest.containsKey("includeSchemeLocation") && inboundRequest.get("includeSchemeLocation").get(0) != null) {
            outboundRequest.setIncludeSchemeLocation(Boolean.valueOf(inboundRequest.get("includeSchemeLocation").get(0)));
        }
        if (inboundRequest.containsKey("includeInvestmentProfile") && inboundRequest.get("includeInvestmentProfile").get(0) != null) {
            outboundRequest.setIncludeInvestmentProfile(Boolean.valueOf(inboundRequest.get("includeInvestmentProfile").get(0)));
        }
    }

    /**
     * 
     * Sets include parameters in GetAccountDetailsRequestType from request query params received
     * 
     * @throws SILException
     */
    private void constructAccountDetailsIncludeParamsFourth() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className,
                "Entering in constructAccountDetailsIncludeParamsFourth method.");
        if (inboundRequest.containsKey("includeAdvisorGroup") && inboundRequest.get("includeAdvisorGroup").get(0) != null) {
            outboundRequest.setIncludeAdvisorGroup(Boolean.valueOf(inboundRequest.get("includeAdvisorGroup").get(0)));
        }
        if (inboundRequest.containsKey("includeBeneficary") && inboundRequest.get("includeBeneficary").get(0) != null) {
            outboundRequest.setIncludeBeneficary(Boolean.valueOf(inboundRequest.get("includeBeneficary").get(0)));
        }
        if (inboundRequest.containsKey("includeBalance") && inboundRequest.get("includeBalance").get(0) != null) {
            outboundRequest.setIncludeBalance(Boolean.valueOf(inboundRequest.get("includeBalance").get(0)));
        }
    }

    /**
     * 
     * Sets include parameters in GetAccountDetailsRequestType from request query params received
     * 
     * @throws SILException
     */
    private void constructAccountDetailsIncludeParamsFifth() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className,
                "Entering in constructAccountDetailsIncludeParamsFifth method.");
        if (inboundRequest.containsKey("includeGenericVariable") && inboundRequest.get("includeGenericVariable").get(0) != null) {
            outboundRequest.setIncludeGenericVariable(Boolean.valueOf(inboundRequest.get("includeGenericVariable").get(0)));
        }
        if (inboundRequest.containsKey("includeNote") && inboundRequest.get("includeNote").get(0) != null) {
            outboundRequest.setIncludeNote(Boolean.valueOf(inboundRequest.get("includeNote").get(0)));
        }
        if (inboundRequest.containsKey("includeRegularContributionPlan") && inboundRequest.get("includeRegularContributionPlan").get(0) != null) {
            outboundRequest.setIncludeReqularContributionPlan(Boolean.valueOf(inboundRequest.get("includeRegularContributionPlan").get(0)));
        }
    }

    /**
     * Sets include parameters in GetAccountDetailsRequestType from request query params received.
     */
    private void constructAccountDetailsIncludeParamsSixth() {
        SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className,
                "Entering in constructAccountDetailsIncludeParamsSixth method.");
        if (inboundRequest.containsKey("includeFamilyGroup") && inboundRequest.get("includeFamilyGroup").get(0) != null) {
            outboundRequest.setIncludeFamilyGroup(Boolean.valueOf(inboundRequest.get("includeFamilyGroup").get(0)));
        }
        if (inboundRequest.containsKey("includeRestriction") && inboundRequest.get("includeRestriction").get(0) != null) {
            outboundRequest.setIncludeRestriction(Boolean.valueOf(inboundRequest.get("includeRestriction").get(0)));
        }
        if (inboundRequest.containsKey("includeExternalReference") && inboundRequest.get("includeExternalReference").get(0) != null) {
            outboundRequest.setIncludeExternalReference(Boolean.valueOf(inboundRequest.get("includeExternalReference").get(0)));
        }
        constructAccountDetailsIncludeParamsSeventh();
        SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className,
                "Entering in constructAccountDetailsIncludeParamsSixth method.");

    }

    /**
     * Sets include parameters in GetAccountDetailsRequestType from request query params received.
     * 
     */
    private void constructAccountDetailsIncludeParamsSeventh() {
        if (inboundRequest.containsKey("includeInsurance") && inboundRequest.get("includeInsurance").get(0) != null) {
            outboundRequest.setIncludeInsurance(Boolean.valueOf(inboundRequest.get("includeInsurance").get(0)));
        }
    }
}
