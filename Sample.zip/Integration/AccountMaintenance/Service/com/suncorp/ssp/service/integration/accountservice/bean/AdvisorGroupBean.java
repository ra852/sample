////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
/**
 * The class {@code AdvisorGroupBean} does this.
 * 
 * @author U387938
 * @since 02/02/2016
 * @version 1.0
 */
public class AdvisorGroupBean {
    private String id;
    private RelationshipIdentifierBean relationshipType;
    private String effectiveDate;
    private List<AdvisorSplitsBean> advisorSplits;
    /**
     * Accessor for property id.
     *
     * @return id of type String
     */
    public String getId() {
        return id;
    }
    /**
     * Mutator for property id.
     *
     * @param id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id != null ? id : "";
    }
    /**
     * Accessor for property relationshipType.
     *
     * @return relationshipType of type RelationshipIdentifierBean
     */
    public RelationshipIdentifierBean getRelationshipType() {
        return relationshipType;
    }
    /**
     * Mutator for property relationshipType.
     *
     * @param relationshipType of type RelationshipIdentifierBean
     */
    @XmlElement(name = "relationshipType")
    public void setRelationshipType(RelationshipIdentifierBean relationshipType) {
        this.relationshipType = relationshipType;
    }
    /**
     * Accessor for property effectiveDate.
     *
     * @return effectiveDate of type String
     */
    public String getEffectiveDate() {
        return effectiveDate;
    }
    /**
     * Mutator for property effectiveDate.
     *
     * @param effectiveDate of type String
     */
    @XmlElement(name = "effectiveDate")
    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate != null ? effectiveDate : "";
    }
    /**
     * Accessor for property advisorSplits.
     *
     * @return advisorSplits of type List<AdvisorSplitsBean>
     */
    public List<AdvisorSplitsBean> getAdvisorSplits() {
        return advisorSplits;
    }
    /**
     * Mutator for property advisorSplits.
     *
     * @param advisorSplits of type List<AdvisorSplitsBean>
     */
    @XmlElement(name = "advisorSplits")
    public void setAdvisorSplits(List<AdvisorSplitsBean> advisorSplits) {
        this.advisorSplits = advisorSplits;
    }
    
    

}
