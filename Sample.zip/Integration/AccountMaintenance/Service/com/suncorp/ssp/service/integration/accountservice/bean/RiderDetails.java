////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code RiderDetails} is a java bean consisting of properties related to RiderDetails.
 * 
 * @author U385424
 * @since 17/02/2018
 * @version 1.0
 */
public class RiderDetails {
    private String id;
    private RiderTemplate riderTemplate;
    private RiderTemplateDetails riderTemplateDetails;
    private String dateOfBirth;
    private CodeIdentifier status;
    private CodeIdentifier sex;
    private String sumInsured;
    private ReviewTermIdentifierDetails reviewTerm;
    private AllowableReviewIdentifierDetails allowableReviewType;
    private CodeIdentifier coverReason;
    private String futureInsure;
    private CodeIdentifier smokeStatus;
    private CodeIdentifier occupationCategory;
    private String riskCommenceDate;
    private String nextReviewDate;
    private String riskCeaseDate;
    private String isAgeAdjusted;
    private String benefitPeriod;
    private String waitPeriod;
    private String riskTerm;
    private String premiumTerm;
    private String riskTermAge;
    private String premiumTermAge;
    private String totalLoadings;
    private String annualPremium;
    private String instalmentPremium;
    private String annualPremiumExLoadings;
    private String lastRenewalDate;
    private String salaryFactor;
    private String unitsOfSI;
    private String employmentSalary;
    private String insuranceSalary;
    private List<RiderParameterDetails> parameterType;
    private CodeIdentifier riskRule;
    private List<LoadingDetails> loading;
    private List<ExclusionDetails> exclusion;
    private ReviewTypeIdentifierDetails claimReviewType;
    private String revPercentageRate;
    private String reviewAmount;
    private String riderRatio;
    private String modalPremium;
    private String isQuote;
    private BenefitIdentifierDetails benefit;

    /**
     * Accessor for property occupationCategory.
     * 
     * @return occupationCategory of type CodeIdentifier
     */
    public CodeIdentifier getOccupationCategory() {
        return occupationCategory;
    }

    /**
     * Mutator for property occupationCategory.
     * 
     * @param occupationCategory of type CodeIdentifier
     */
    @XmlElement(name = "occupationCategory")
    public void setOccupationCategory(CodeIdentifier occupationCategory) {
        this.occupationCategory = occupationCategory;
    }

    /**
     * Accessor for property riderTemplate.
     * 
     * @return riderTemplate of type RiderTemplate
     */
    public RiderTemplate getRiderTemplate() {
        return riderTemplate;
    }

    /**
     * Mutator for property riderTemplate.
     * 
     * @param riderTemplate of type RiderTemplate
     */
    @XmlElement(name = "riderTemplate")
    public void setRiderTemplate(RiderTemplate riderTemplate) {
        this.riderTemplate = riderTemplate;
    }

    /**
     * Accessor for property sex.
     * 
     * @return sex of type CodeIdentifier
     */
    public CodeIdentifier getSex() {
        return sex;
    }

    /**
     * Mutator for property sex.
     * 
     * @param sex of type CodeIdentifier
     */
    @XmlElement(name = "sex")
    public void setSex(CodeIdentifier sex) {
        this.sex = sex;
    }

    /**
     * Accessor for property smokeStatus.
     * 
     * @return smokeStatus of type CodeIdentifier
     */
    public CodeIdentifier getSmokeStatus() {
        return smokeStatus;
    }

    /**
     * Mutator for property smokeStatus.
     * 
     * @param smokeStatus of type CodeIdentifier
     */
    @XmlElement(name = "smokeStatus")
    public void setSmokeStatus(CodeIdentifier smokeStatus) {
        this.smokeStatus = smokeStatus;
    }

    /**
     * Accessor for property unitsOfSI.
     * 
     * @return unitsOfSI of type String
     */
    public String getUnitsOfSI() {
        return unitsOfSI;
    }

    /**
     * Mutator for property unitsOfSI.
     * 
     * @param unitsOfSI of type String
     */
    @XmlElement(name = "unitsOfSI")
    public void setUnitsOfSI(String unitsOfSI) {
        this.unitsOfSI = unitsOfSI != null ? unitsOfSI : "";
    }

    /**
     * Accessor for property isAgeAdjusted.
     * 
     * @return isAgeAdjusted of type String
     */
    public String getIsAgeAdjusted() {
        return isAgeAdjusted;
    }

    /**
     * Mutator for property isAgeAdjusted.
     * 
     * @param isAgeAdjusted of type String
     */
    @XmlElement(name = "isAgeAdjusted")
    public void setIsAgeAdjusted(String isAgeAdjusted) {
        this.isAgeAdjusted = isAgeAdjusted != null ? isAgeAdjusted : "";
    }

    /**
     * Accessor for property sumInsured.
     * 
     * @return sumInsured of type String
     */
    public String getSumInsured() {
        return sumInsured;
    }

    /**
     * Mutator for property sumInsured.
     * 
     * @param sumInsured of type String
     */
    @XmlElement(name = "sumInsured")
    public void setSumInsured(String sumInsured) {
        this.sumInsured = sumInsured != null ? sumInsured : "";
    }

    /**
     * Accessor for property id.
     * 
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     * 
     * @param id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id != null ? id : "";
    }

    /**
     * Accessor for property dateOfBirth.
     * 
     * @return dateOfBirth of type String
     */
    public String getDateOfBirth() {
        return dateOfBirth;
    }

    /**
     * Mutator for property dateOfBirth.
     * 
     * @param dateOfBirth of type String
     */
    @XmlElement(name = "dateOfBirth")
    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth != null ? dateOfBirth : "";
    }

    /**
     * Accessor for property coverReason.
     * 
     * @return coverReason of type CodeIdentifier
     */
    public CodeIdentifier getCoverReason() {
        return coverReason;
    }

    /**
     * Mutator for property coverReason.
     * 
     * @param coverReason of type CodeIdentifier
     */
    @XmlElement(name = "coverReason")
    public void setCoverReason(CodeIdentifier coverReason) {
        this.coverReason = coverReason;
    }

    /**
     * Accessor for property futureInsure.
     * 
     * @return futureInsure of type String
     */
    public String getFutureInsure() {
        return futureInsure;
    }

    /**
     * Mutator for property futureInsure.
     * 
     * @param futureInsure of type String
     */
    @XmlElement(name = "futureInsure")
    public void setFutureInsure(String futureInsure) {
        this.futureInsure = futureInsure != null ? futureInsure : "";
    }

    /**
     * Accessor for property riskCommenceDate.
     * 
     * @return riskCommenceDate of type String
     */
    public String getRiskCommenceDate() {
        return riskCommenceDate;
    }

    /**
     * Mutator for property riskCommenceDate.
     * 
     * @param riskCommenceDate of type String
     */
    @XmlElement(name = "riskCommenceDate")
    public void setRiskCommenceDate(String riskCommenceDate) {
        this.riskCommenceDate = riskCommenceDate != null ? riskCommenceDate : "";
    }

    /**
     * Accessor for property nextReviewDate.
     * 
     * @return nextReviewDate of type String
     */
    public String getNextReviewDate() {
        return nextReviewDate;
    }

    /**
     * Mutator for property nextReviewDate.
     * 
     * @param nextReviewDate of type String
     */
    @XmlElement(name = "nextReviewDate")
    public void setNextReviewDate(String nextReviewDate) {
        this.nextReviewDate = nextReviewDate != null ? nextReviewDate : "";
    }

    /**
     * Accessor for property riskCeaseDate.
     * 
     * @return riskCeaseDate of type String
     */
    public String getRiskCeaseDate() {
        return riskCeaseDate;
    }

    /**
     * Mutator for property riskCeaseDate.
     * 
     * @param riskCeaseDate of type String
     */
    @XmlElement(name = "riskCeaseDate")
    public void setRiskCeaseDate(String riskCeaseDate) {
        this.riskCeaseDate = riskCeaseDate != null ? riskCeaseDate : "";
    }

    /**
     * Accessor for property benefitPeriod.
     * 
     * @return benefitPeriod of type String
     */
    public String getBenefitPeriod() {
        return benefitPeriod;
    }

    /**
     * Mutator for property benefitPeriod.
     * 
     * @param benefitPeriod of type String
     */
    @XmlElement(name = "benefitPeriod")
    public void setBenefitPeriod(String benefitPeriod) {
        this.benefitPeriod = benefitPeriod != null ? benefitPeriod : "";
    }

    /**
     * Accessor for property waitPeriod.
     * 
     * @return waitPeriod of type String
     */
    public String getWaitPeriod() {
        return waitPeriod;
    }

    /**
     * Mutator for property waitPeriod.
     * 
     * @param waitPeriod of type String
     */
    @XmlElement(name = "waitPeriod")
    public void setWaitPeriod(String waitPeriod) {
        this.waitPeriod = waitPeriod != null ? waitPeriod : "";
    }

    /**
     * Accessor for property riskTerm.
     * 
     * @return riskTerm of type String
     */
    public String getRiskTerm() {
        return riskTerm;
    }

    /**
     * Mutator for property riskTerm.
     * 
     * @param riskTerm of type String
     */
    @XmlElement(name = "riskTerm")
    public void setRiskTerm(String riskTerm) {
        this.riskTerm = riskTerm != null ? riskTerm : "";
    }

    /**
     * Accessor for property premiumTerm.
     * 
     * @return premiumTerm of type String
     */
    public String getPremiumTerm() {
        return premiumTerm;
    }

    /**
     * Mutator for property premiumTerm.
     * 
     * @param premiumTerm of type String
     */
    @XmlElement(name = "premiumTerm")
    public void setPremiumTerm(String premiumTerm) {
        this.premiumTerm = premiumTerm != null ? premiumTerm : "";
    }

    /**
     * Accessor for property riskTermAge.
     * 
     * @return riskTermAge of type String
     */
    public String getRiskTermAge() {
        return riskTermAge;
    }

    /**
     * Mutator for property riskTermAge.
     * 
     * @param riskTermAge of type String
     */
    @XmlElement(name = "riskTermAge")
    public void setRiskTermAge(String riskTermAge) {
        this.riskTermAge = riskTermAge != null ? riskTermAge : "";
    }

    /**
     * Accessor for property premiumTermAge.
     * 
     * @return premiumTermAge of type String
     */
    public String getPremiumTermAge() {
        return premiumTermAge;
    }

    /**
     * Mutator for property premiumTermAge.
     * 
     * @param premiumTermAge of type String
     */
    @XmlElement(name = "premiumTermAge")
    public void setPremiumTermAge(String premiumTermAge) {
        this.premiumTermAge = premiumTermAge != null ? premiumTermAge : "";
    }

    /**
     * Accessor for property annualPremium.
     * 
     * @return annualPremium of type String
     */
    public String getAnnualPremium() {
        return annualPremium;
    }

    /**
     * Mutator for property annualPremium.
     * 
     * @param annualPremium of type String
     */
    @XmlElement(name = "annualPremium")
    public void setAnnualPremium(String annualPremium) {
        this.annualPremium = annualPremium != null ? annualPremium : "";
    }

    /**
     * Accessor for property instalmentPremium.
     * 
     * @return instalmentPremium of type String
     */
    public String getInstalmentPremium() {
        return instalmentPremium;
    }

    /**
     * Mutator for property instalmentPremium.
     * 
     * @param instalmentPremium of type String
     */
    @XmlElement(name = "instalmentPremium")
    public void setInstalmentPremium(String instalmentPremium) {
        this.instalmentPremium = instalmentPremium != null ? instalmentPremium : "";
    }

    /**
     * Accessor for property annualPremiumExLoadings.
     * 
     * @return annualPremiumExLoadings of type String
     */
    public String getAnnualPremiumExLoadings() {
        return annualPremiumExLoadings;
    }

    /**
     * Mutator for property annualPremiumExLoadings.
     * 
     * @param annualPremiumExLoadings of type String
     */
    @XmlElement(name = "annualPremiumExLoadings")
    public void setAnnualPremiumExLoadings(String annualPremiumExLoadings) {
        this.annualPremiumExLoadings = annualPremiumExLoadings != null ? annualPremiumExLoadings : "";
    }

    /**
     * Accessor for property lastRenewalDate.
     * 
     * @return lastRenewalDate of type String
     */
    public String getLastRenewalDate() {
        return lastRenewalDate;
    }

    /**
     * Mutator for property lastRenewalDate.
     * 
     * @param lastRenewalDate of type String
     */
    @XmlElement(name = "lastRenewalDate")
    public void setLastRenewalDate(String lastRenewalDate) {
        this.lastRenewalDate = lastRenewalDate != null ? lastRenewalDate : "";
    }

    /**
     * Accessor for property riderTemplateDetails.
     * 
     * @return riderTemplateDetails of type CodeIdentifier
     */
    public RiderTemplateDetails getRiderTemplateDetails() {
        return riderTemplateDetails;
    }

    /**
     * Mutator for property riderTemplateDetails.
     * 
     * @return riderTemplateDetails of type RiderTemplateDetails
     */
    @XmlElement(name = "riderTemplateDetails")
    public void setRiderTemplateDetails(RiderTemplateDetails riderTemplateDetails) {
        this.riderTemplateDetails = riderTemplateDetails;
    }

    /**
     * Accessor for property status.
     * 
     * @return status of type CodeIdentifier
     */
    public CodeIdentifier getStatus() {
        return status;
    }

    /**
     * Mutator for property status.
     * 
     * @return status of type CodeIdentifier
     */
    @XmlElement(name = "status")
    public void setStatus(CodeIdentifier status) {
        this.status = status;
    }

    /**
     * Accessor for property reviewTerm.
     * 
     * @return reviewTerm of type ReviewTermIdentifierDetails
     */
    public ReviewTermIdentifierDetails getReviewTerm() {
        return reviewTerm;
    }

    /**
     * Mutator for property reviewTerm.
     * 
     * @return reviewTerm of type ReviewTermIdentifierDetails
     */
    @XmlElement(name = "reviewTerm")
    public void setReviewTerm(ReviewTermIdentifierDetails reviewTerm) {
        this.reviewTerm = reviewTerm;
    }

    /**
     * Accessor for property allowableReviewType.
     * 
     * @return allowableReviewType of type AllowableReviewIdentifierDetails
     */
    public AllowableReviewIdentifierDetails getAllowableReviewType() {
        return allowableReviewType;
    }

    /**
     * Mutator for property allowableReviewType.
     * 
     * @return allowableReviewType of type AllowableReviewIdentifierDetails
     */
    @XmlElement(name = "allowableReviewType")
    public void setAllowableReviewType(AllowableReviewIdentifierDetails allowableReviewType) {
        this.allowableReviewType = allowableReviewType;
    }

    /**
     * Accessor for property employmentSalary.
     * 
     * @return employmentSalary of type String
     */
    public String getEmploymentSalary() {
        return employmentSalary;
    }

    /**
     * Mutator for property employmentSalary.
     * 
     * @return employmentSalary of type String
     */
    @XmlElement(name = "employmentSalary")
    public void setEmploymentSalary(String employmentSalary) {
        this.employmentSalary = employmentSalary != null ? employmentSalary : "";
    }

    /**
     * Accessor for property insuranceSalary.
     * 
     * @return insuranceSalary of type String
     */
    public String getInsuranceSalary() {
        return insuranceSalary;
    }

    /**
     * Mutator for property insuranceSalary.
     * 
     * @return insuranceSalary of type String
     */
    @XmlElement(name = "insuranceSalary")
    public void setInsuranceSalary(String insuranceSalary) {
        this.insuranceSalary = insuranceSalary != null ? insuranceSalary : "";
    }

    /**
     * Accessor for property parameterType.
     * 
     * @return parameterType of type List<RiderParameterDetails>
     */
    public List<RiderParameterDetails> getParameterType() {
        return parameterType;
    }

    /**
     * Mutator for property parameterType.
     * 
     * @return parameterType of type List<RiderParameterDetails>
     */
    @XmlElement(name = "parameterType")
    public void setParameterType(List<RiderParameterDetails> parameterType) {
        this.parameterType = parameterType;
    }

    /**
     * Accessor for property riskRule.
     * 
     * @return riskRule of type CodeIdentifier
     */
    public CodeIdentifier getRiskRule() {
        return riskRule;
    }

    /**
     * Mutator for property riskRule.
     * 
     * @return riskRule of type CodeIdentifier
     */
    @XmlElement(name = "riskRule")
    public void setRiskRule(CodeIdentifier riskRule) {
        this.riskRule = riskRule;
    }

    /**
     * Accessor for property loading.
     * 
     * @return loading of type List<LoadingDetails>
     */
    public List<LoadingDetails> getLoading() {
        return loading;
    }

    /**
     * Mutator for property loading.
     * 
     * @return loading of type List<LoadingDetails>
     */
    @XmlElement(name = "loading")
    public void setLoading(List<LoadingDetails> loading) {
        this.loading = loading;
    }

    /**
     * Accessor for property exclusion.
     * 
     * @return exclusion of type List<ExclusionDetails>
     */
    public List<ExclusionDetails> getExclusion() {
        return exclusion;
    }

    /**
     * Mutator for property exclusion.
     * 
     * @return exclusion of type List<ExclusionDetails>
     */
    @XmlElement(name = "exclusion")
    public void setExclusion(List<ExclusionDetails> exclusion) {
        this.exclusion = exclusion;
    }

    /**
     * Accessor for property claimReviewType.
     * 
     * @return claimReviewType of type ReviewTypeIdentifierDetails
     */
    public ReviewTypeIdentifierDetails getClaimReviewType() {
        return claimReviewType;
    }

    /**
     * Mutator for property claimReviewType.
     * 
     * @return claimReviewType of type ReviewTypeIdentifierDetails
     */
    @XmlElement(name = "claimReviewType")
    public void setClaimReviewType(ReviewTypeIdentifierDetails claimReviewType) {
        this.claimReviewType = claimReviewType;
    }

    /**
     * Accessor for property revPercentageRate.
     * 
     * @return revPercentageRate of type String
     */
    public String getRevPercentageRate() {
        return revPercentageRate;
    }

    /**
     * Mutator for property revPercentageRate.
     * 
     * @return revPercentageRate of type String
     */
    @XmlElement(name = "revPercentageRate")
    public void setRevPercentageRate(String revPercentageRate) {
        this.revPercentageRate = revPercentageRate != null ? revPercentageRate : "";
    }

    /**
     * Accessor for property reviewAmount.
     * 
     * @return reviewAmount of type String
     */
    public String getReviewAmount() {
        return reviewAmount;
    }

    /**
     * Mutator for property reviewAmount.
     * 
     * @return reviewAmount of type String
     */
    @XmlElement(name = "reviewAmount")
    public void setReviewAmount(String reviewAmount) {
        this.reviewAmount = reviewAmount != null ? reviewAmount : "";
    }

    /**
     * Accessor for property riderRatio.
     * 
     * @return riderRatio of type String
     */
    public String getRiderRatio() {
        return riderRatio;
    }

    /**
     * Mutator for property riderRatio.
     * 
     * @return riderRatio of type String
     */
    @XmlElement(name = "riderRatio")
    public void setRiderRatio(String riderRatio) {
        this.riderRatio = riderRatio != null ? riderRatio : "";
    }

    /**
     * Accessor for property modalPremium.
     * 
     * @return modalPremium of type String
     */
    public String getModalPremium() {
        return modalPremium;
    }

    /**
     * Mutator for property modalPremium.
     * 
     * @return modalPremium of type String
     */
    @XmlElement(name = "modalPremium")
    public void setModalPremium(String modalPremium) {
        this.modalPremium = modalPremium != null ? modalPremium : "";
    }

    /**
     * Accessor for property isQuote.
     * 
     * @return isQuote of type String
     */
    public String getIsQuote() {
        return isQuote;
    }

    /**
     * Mutator for property isQuote.
     * 
     * @return isQuote of type String
     */
    @XmlElement(name = "isQuote")
    public void setIsQuote(String isQuote) {
        this.isQuote = isQuote != null ? isQuote : "";
    }

    /**
     * Accessor for property totalLoadings.
     * 
     * @return totalLoadings of type String
     */
    public String getTotalLoadings() {
        return totalLoadings;
    }

    /**
     * Mutator for property totalLoadings.
     * 
     * @return totalLoadings of type String
     */
    @XmlElement(name = "totalLoadings")
    public void setTotalLoadings(String totalLoadings) {
        this.totalLoadings = totalLoadings != null ? totalLoadings : "";
    }

    /**
     * Accessor for property salaryFactor.
     * 
     * @return salaryFactor of type String
     */
    public String getSalaryFactor() {
        return salaryFactor;
    }

    /**
     * Mutator for property salaryFactor.
     * 
     * @return salaryFactor of type String
     */
    @XmlElement(name = "salaryFactor")
    public void setSalaryFactor(String salaryFactor) {
        this.salaryFactor = salaryFactor != null ? salaryFactor : "";
    }

    /**
     * Accessor for property benefit.
     * 
     * @return benefit of type BenefitIdentifierDetails
     */
    public BenefitIdentifierDetails getBenefit() {
        return benefit;
    }

    /**
     * Mutator for property benefit.
     * 
     * @param benefit of type BenefitIdentifierDetails
     */
    @XmlElement(name = "benefit")
    public void setBenefit(BenefitIdentifierDetails benefit) {
        this.benefit = benefit;
    }
}
