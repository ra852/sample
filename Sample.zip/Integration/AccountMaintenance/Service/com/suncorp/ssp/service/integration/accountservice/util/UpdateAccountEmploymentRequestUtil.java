////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CodeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.scheme.schemegrouptype.EmploymentType;
import com.sonatacentral.service.v30.globaltypes.common.scheme.schemegrouptype.EmploymentType.History;
import com.sonatacentral.service.v30.globaltypes.common.scheme.schemegrouptype.EmploymentType.Salary;
import com.sonatacentral.service.v30.globaltypes.common.scheme.schemegrouptype.SchemeLocationIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType.AccountNumber;
import com.sonatacentral.service.v30.wrap.account.SaveAccountEmploymentRequestType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.AccountIdentifierDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.CodeIdentifier;
import com.suncorp.ssp.service.integration.accountservice.bean.EmployerDetailsBean;
import com.suncorp.ssp.service.integration.accountservice.bean.EmploymentDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.HistoryDetailsBean;
import com.suncorp.ssp.service.integration.accountservice.bean.SalaryDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.UpdateAccountEmploymentRequest;

/**
 * The class {@code UpdateAccountEmploymentRequestUtil} construct's SOAP request for external service.
 * 
 * @author U387938
 * @since 13/09/2016
 * @version 1.0
 */
public class UpdateAccountEmploymentRequestUtil {

    private final String className = "UpdateAccountEmploymentRequestUtil";
    private SaveAccountEmploymentRequestType outboundRequest;
    private UpdateAccountEmploymentRequest inboundRequest;

    public UpdateAccountEmploymentRequestUtil(UpdateAccountEmploymentRequest inboundRequest) {
        this.inboundRequest = inboundRequest;
        outboundRequest = new SaveAccountEmploymentRequestType();
    }

    /**
     * 
     * Create Oubound(SaveAccountEmploymentRequestType) request.
     * 
     * @return outboundRequest
     * @throws Exception
     */
    public SaveAccountEmploymentRequestType createOutboundRequest() throws SILException {
        SILLogger.debug(AccountServiceConstants.UPDATE_ACCOUNT_EMP_LOGGING_FORMAT, className, "Entering createOutboundRequest()");
        this.outboundRequest.setCallerDetails(SILUtil.createCallerDetails());
        if (inboundRequest.getAccount() != null) {
            constructAccountIdentifierType(inboundRequest.getAccount());
        }
        if (inboundRequest.getEmployment() != null) {
            constructEmploymentDetails(inboundRequest.getEmployment());
        }

        return this.outboundRequest;
    }

    /**
     * 
     * Creates AccountIdentifierType accountNumber name.
     * 
     * @param accountIdentifierDetails
     * @throws SILException
     */
    private void constructAccountIdentifierType(AccountIdentifierDetails accountIdentifierDetails) throws SILException {
        SILLogger.debug(AccountServiceConstants.UPDATE_ACCOUNT_EMP_LOGGING_FORMAT, className, "Entering in constructAccountIdentifierType method.");

        if (accountIdentifierDetails != null && accountIdentifierDetails.getAccountNumber() != null &&
                accountIdentifierDetails.getAccountNumber().getAccountNo() != null) {
            AccountIdentifierType accountIdentifierType = new AccountIdentifierType();
            AccountNumber accountNumber = new AccountNumber();
            accountNumber.setAccountNo(accountIdentifierDetails.getAccountNumber().getAccountNo());
            accountIdentifierType.setAccountNumber(accountNumber);
            this.outboundRequest.setAccount(accountIdentifierType);

        }

    }

    /**
     * 
     * This method construct EmploymentType List.
     * 
     * @param employmentDetails
     * @throws SILException
     */
    private void constructEmploymentDetails(List<EmploymentDetails> employmentDetails) throws SILException {
        SILLogger.debug(AccountServiceConstants.UPDATE_ACCOUNT_EMP_LOGGING_FORMAT, className, "Entering in constructAccountIdentifierType method.");
        List<EmploymentType> employmentTypeList = new ArrayList<EmploymentType>();
        if (employmentDetails != null && employmentDetails.size() > 0) {
            for (EmploymentDetails employmentDetail : employmentDetails) {
                employmentTypeList.add(constructEmploymentType(employmentDetail));
            }
            this.outboundRequest.getEmployment().addAll(employmentTypeList);
        }
    }

    /**
     * 
     * This method construct EmploymentType.
     * 
     * @param employmentDetail
     * @return employmentType
     * @throws SILException
     */
    private EmploymentType constructEmploymentType(EmploymentDetails employmentDetail) throws SILException {
        SILLogger.debug(AccountServiceConstants.UPDATE_ACCOUNT_EMP_LOGGING_FORMAT, className, "Entering in constructEmploymentType method.");
        EmploymentType employmentType = new EmploymentType();
        if (employmentDetail != null) {
            setEmplymentTypeParamsFirst(employmentDetail, employmentType);
            setEmplymentTypeParamsSecond(employmentDetail, employmentType);
            setEmplymentTypeParamsThird(employmentDetail, employmentType);
        }
        return employmentType;
    }

    /**
     * Does this.
     * 
     * @param employmentDetail
     * @param employmentType
     * @throws SILException
     */
    private void setEmplymentTypeParamsFirst(EmploymentDetails employmentDetail, EmploymentType employmentType) throws SILException {
        if (employmentDetail.getId() != null) {
            employmentType.setId(Long.valueOf(employmentDetail.getId()));
        }
        if (employmentDetail.getStartDate() != null && !("").equalsIgnoreCase(employmentDetail.getStartDate())) {
            employmentType.setStartDate(SILUtil.convertStringToXMLGregorianCalendar(employmentDetail.getStartDate(), CommonConstants.DATE_FORMAT));
        }
        if (employmentDetail.getEndDate() != null && !("").equalsIgnoreCase(employmentDetail.getEndDate())) {
            employmentType.setEndDate(SILUtil.convertStringToXMLGregorianCalendar(employmentDetail.getEndDate(), CommonConstants.DATE_FORMAT));
        }
        if (employmentDetail.getPayrollId() != null) {
            employmentType.setPayrollId(employmentDetail.getPayrollId());
        }
    }

    /**
     * This method construct EmploymentType.
     * 
     * @param employmentDetail
     * @param employmentType
     * @throws SILException
     */
    private void setEmplymentTypeParamsSecond(EmploymentDetails employmentDetail, EmploymentType employmentType) throws SILException {
        if (employmentDetail.getPrimaryEmployer() != null) {
            employmentType.setPrimaryEmployer(Boolean.valueOf(employmentDetail.getPrimaryEmployer()));
        }
        if (employmentDetail.getSalaries() != null && employmentDetail.getSalaries().size() > 0) {
            SILLogger.debug(AccountServiceConstants.UPDATE_ACCOUNT_EMP_LOGGING_FORMAT, className, "Setting Employment Type Params.");
            List<EmploymentType.Salary> salaryList = employmentType.getSalary();
            constructSalaryDetails(salaryList, employmentDetail.getSalaries());
        }
        if (employmentDetail.getEmploymentType() != null) {
            employmentType.setEmploymentType(setCodeIdentifier(employmentDetail.getEmploymentType()));
        }
        if (employmentDetail.getEmploymentRecordType() != null) {
            employmentType.setEmploymentRecordType(setCodeIdentifier(employmentDetail.getEmploymentRecordType()));
        }
    }

    /**
     * Does this.
     * 
     * @param employmentDetail
     * @param employmentType
     * @throws SILException
     */
    private void setEmploymentHistoryDetails(EmploymentDetails employmentDetail, EmploymentType employmentType) throws SILException {
        SILLogger.debug(AccountServiceConstants.UPDATE_ACCOUNT_EMP_LOGGING_FORMAT, className, "Entering setEmploymentHistoryDetails()");
        List<HistoryDetailsBean> inboundHistoryList = employmentDetail.getHistory();
        List<History> outboundHistoryList = employmentType.getHistory();

        for (HistoryDetailsBean inboundHistory : inboundHistoryList) {
            History history = createHistoryDetails(inboundHistory);
            outboundHistoryList.add(history);
        }
        SILLogger.debug(AccountServiceConstants.UPDATE_ACCOUNT_EMP_LOGGING_FORMAT, className, "Exiting setEmploymentHistoryDetails()");
    }

    /**
     * Does this.
     * 
     * @param inboundHistory
     * @return
     * @throws SILException
     */
    private History createHistoryDetails(HistoryDetailsBean inboundHistory) throws SILException {
        SILLogger.debug(AccountServiceConstants.UPDATE_ACCOUNT_EMP_LOGGING_FORMAT, className, "Entering createHistoryDetails()");
        History outboundHistory = new History();
        if (inboundHistory.getId() != null) {
            outboundHistory.setId(Long.valueOf(inboundHistory.getId()));
        }
        if (inboundHistory.getEmploymentStatus() != null) {
            outboundHistory.setEmploymentStatus(setCodeIdentifier(inboundHistory.getEmploymentStatus()));
        }
        if (inboundHistory.getStartDate() != null && !("").equalsIgnoreCase(inboundHistory.getStartDate())) {
            outboundHistory.setStartDate(SILUtil.convertStringToXMLGregorianCalendar(inboundHistory.getStartDate(), CommonConstants.DATE_FORMAT));
        }
        setHistoryExtraDetails(inboundHistory, outboundHistory);
        SILLogger.debug(AccountServiceConstants.UPDATE_ACCOUNT_EMP_LOGGING_FORMAT, className, "Exiting createHistoryDetails()");
        return outboundHistory;
    }

    /**
     * Does this.
     * 
     * @param inboundHistory
     * @param outboundHistory
     * @throws SILException
     */
    private void setHistoryExtraDetails(HistoryDetailsBean inboundHistory, History outboundHistory) throws SILException {
        SILLogger.debug(AccountServiceConstants.UPDATE_ACCOUNT_EMP_LOGGING_FORMAT, className, "Entering setHistoryExtraDetails()");
        if (inboundHistory.getNotificationDate() != null && !("").equalsIgnoreCase(inboundHistory.getNotificationDate())) {
            outboundHistory.setNotificationDate(SILUtil.convertStringToXMLGregorianCalendar(inboundHistory.getNotificationDate(),
                    CommonConstants.DATE_FORMAT));
        }
        if (inboundHistory.getEndDate() != null && !("").equalsIgnoreCase(inboundHistory.getEndDate())) {
            outboundHistory.setEndDate(SILUtil.convertStringToXMLGregorianCalendar(inboundHistory.getEndDate(), CommonConstants.DATE_FORMAT));
        }
        if (inboundHistory.getSuspenseReason() != null) {
            outboundHistory.setSuspenseReason(setCodeIdentifier(inboundHistory.getSuspenseReason()));
        }
        SILLogger.debug(AccountServiceConstants.UPDATE_ACCOUNT_EMP_LOGGING_FORMAT, className, "Exiting setHistoryExtraDetails()");
    }

    /**
     * Does this.
     * 
     * @param employmentDetail
     * @param employmentType
     * @throws SILException
     */
    private void setEmplymentTypeParamsThird(EmploymentDetails employmentDetail, EmploymentType employmentType) throws SILException {
        SILLogger.debug(AccountServiceConstants.UPDATE_ACCOUNT_EMP_LOGGING_FORMAT, className, "Entering setEmplymentTypeParamsThird()");
        if (employmentDetail.getEmployer() != null) {
            employmentType.setEmployer(setEmployerDetails(employmentDetail.getEmployer()));
        }
        if (employmentDetail.getParticipating() != null) {
            employmentType.setParticipating(Boolean.valueOf(employmentDetail.getParticipating()));
        }
        if (employmentDetail.getHistory() != null && employmentDetail.getHistory().size() > 0) {
            setEmploymentHistoryDetails(employmentDetail, employmentType);
        }
        SILLogger.debug(AccountServiceConstants.UPDATE_ACCOUNT_EMP_LOGGING_FORMAT, className, "Exiting setEmplymentTypeParamsThird()");
    }

    /**
     * 
     * This method is used to set Salary Type List.
     * 
     * @param salaryDetails
     * @return salaryList
     * @throws SILException
     */
    private List<Salary> constructSalaryDetails(List<EmploymentType.Salary> salaryList, List<SalaryDetails> salaryDetails) throws SILException {
        if (salaryDetails != null && salaryDetails.size() > 0) {
            SILLogger.debug(AccountServiceConstants.UPDATE_ACCOUNT_EMP_LOGGING_FORMAT, className, "Entering constructSalaryDetails method.");
            for (SalaryDetails salaryDetail : salaryDetails) {
                salaryList.add(constructSalaryType(salaryDetail));
            }
        }
        return salaryList;
    }

    /**
     * 
     * This method is used to set Salary Type.
     * 
     * @param salaryDetail
     * @return salary
     * @throws SILException
     */
    private Salary constructSalaryType(SalaryDetails salaryDetail) throws SILException {
        SILLogger.debug(AccountServiceConstants.UPDATE_ACCOUNT_EMP_LOGGING_FORMAT, className, "Entering in constructSalaryType method.");
        Salary salary = new Salary();
        if (salaryDetail != null && salaryDetail.getSalary() != null) {
            if (salaryDetail.getId() != null && !("").equalsIgnoreCase(salaryDetail.getId())) {
                salary.setId(Long.valueOf(salaryDetail.getId()));
            }
            if (salaryDetail.getSalaryType() != null) {
                salary.setSalaryType(setCodeIdentifier(salaryDetail.getSalaryType()));
            }
            setSalaryTypeParams(salaryDetail, salary);
            SILLogger.debug(AccountServiceConstants.UPDATE_ACCOUNT_EMP_LOGGING_FORMAT, className, "Exiting in constructSalaryType method.");
        }
        return salary;
    }

    /**
     * Does this.
     * 
     * @param salaryDetail
     * @param salary
     * @throws SILException
     */
    private void setSalaryTypeParams(SalaryDetails salaryDetail, Salary salary) throws SILException {
        if (salaryDetail.getSalary() != null) {
            salary.setSalary(BigDecimal.valueOf(Double.valueOf(salaryDetail.getSalary())));
        }
        if (salaryDetail.getEffectiveFrom() != null && !("").equalsIgnoreCase(salaryDetail.getEffectiveFrom())) {
            salary.setEffectiveFrom(SILUtil.convertStringToXMLGregorianCalendar(salaryDetail.getEffectiveFrom(), CommonConstants.DATE_FORMAT));
        }
        if (salaryDetail.getEffectiveTo() != null && !("").equalsIgnoreCase(salaryDetail.getEffectiveTo())) {
            salary.setEffectiveTo(SILUtil.convertStringToXMLGregorianCalendar(salaryDetail.getEffectiveTo(), CommonConstants.DATE_FORMAT));
        }
    }

    /**
     * This method used to set code .
     * 
     * @param inbound
     * @return codeIdentifierType
     */
    private CodeIdentifierType setCodeIdentifier(CodeIdentifier codeIdentifier) {
        SILLogger.debug(AccountServiceConstants.UPDATE_ACCOUNT_EMP_LOGGING_FORMAT, className, "Entering setCodeIdentifier()");
        CodeIdentifierType codeIdentifierType = new CodeIdentifierType();
        if (codeIdentifier.getId() != null) {
            codeIdentifierType.setId(Long.valueOf(codeIdentifier.getId()));
        }
        if (codeIdentifier.getCode() != null) {
            codeIdentifierType.setCode(codeIdentifier.getCode());
        }
        if (codeIdentifier.getCodeType() != null) {
            codeIdentifierType.setCodeType(codeIdentifier.getCodeType());
        }
        return codeIdentifierType;
    }

    /**
     * This method used to set EmployerDetails .
     * 
     * @param employerDetailsBean
     * @return schemeLocationIdentifierType
     */
    private SchemeLocationIdentifierType setEmployerDetails(EmployerDetailsBean employerDetailsBean) {
        SILLogger.debug(AccountServiceConstants.UPDATE_ACCOUNT_EMP_LOGGING_FORMAT, className, "Entering setEmployerDetails()");
        SchemeLocationIdentifierType schemeLocationIdentifierType = new SchemeLocationIdentifierType();
        if (employerDetailsBean.getId() != null) {
            schemeLocationIdentifierType.setId(Long.valueOf(employerDetailsBean.getId()));
        }
        if (employerDetailsBean.getNumber() != null) {
            schemeLocationIdentifierType.setNumber(employerDetailsBean.getNumber());
        }
        SILLogger.debug(AccountServiceConstants.UPDATE_ACCOUNT_EMP_LOGGING_FORMAT, className, "Exiting setEmployerDetails()");
        return schemeLocationIdentifierType;
    }
}
