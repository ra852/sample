////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import java.util.ArrayList;
import java.util.List;

import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.RegularPlanType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.RegularPlanType.BalanceTypeSplit;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.RegularPlanType.ContributionTypeSplit;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.RegularPlanType.FundSplit;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.RegularPlanType.IndexationRequired;
import com.sonatacentral.service.v30.globaltypes.wrap.transaction.transactiongrouptype.InvestmentRequesterType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.BalanceTypeSplitsBean;
import com.suncorp.ssp.service.integration.accountservice.bean.ContributionTypeSplitsBean;
import com.suncorp.ssp.service.integration.accountservice.bean.FundSplitsBean;
import com.suncorp.ssp.service.integration.accountservice.bean.IndexationRequiredBean;
import com.suncorp.ssp.service.integration.accountservice.bean.InvestmentRequesterBean;
import com.suncorp.ssp.service.integration.accountservice.bean.RegularPlanBean;

/**
 * The class {@code RegularPlanDetailsResponseUtil} is a Utility class with all the properties related to RegularPlanDetails to construct response for
 * end client.
 * 
 * @author U383847
 * @since 30/05/2016
 * @version 1.0
 */
public class RegularPlanDetailsResponseUtil {
    private final String className = "RegularPlanDetailsResponseUtil";

    /**
     * This method is used to get regular contribution plan details.
     *
     * @param regularPlanType
     * @return
     * @throws SILException
     */
    public RegularPlanBean getRegularContributionPlanDetails(RegularPlanType regularPlanType) throws SILException {
        String loggerType = AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT;
        SILLogger.debug(loggerType, className, "Entering getRegularContributionPlanDetails()");
        RegularPlanBean regularPlanBean = new RegularPlanBean();
        AccountServiceUtil accountServiceUtil = new AccountServiceUtil();
        if (regularPlanType != null) {
            regularPlanBean.setRegularPlanId(accountServiceUtil.retrieveLongValue(regularPlanType.getRegularPlanId(), loggerType));
            regularPlanBean.setRelationshipType(accountServiceUtil.retrieveRelationshipIdentifierDetails(regularPlanType.getRelationshipType(),
                    loggerType));
            regularPlanBean.setClient(accountServiceUtil.retrieveClientDetails(regularPlanType.getClient(), loggerType));
            regularPlanBean.setStatus(accountServiceUtil.retrieveCode(regularPlanType.getStatus(), loggerType));
            regularPlanBean.setSavingsPlan(accountServiceUtil.retrieveLongValue(regularPlanType.getSavingsPlan(), loggerType));
            regularPlanBean.setPaymentMethod(accountServiceUtil.retrieveCode(regularPlanType.getPaymentMethod(), loggerType));
            regularPlanBean.setFrequency(accountServiceUtil.retrieveFrequencyIdentifier(regularPlanType.getFrequency(), loggerType));
            regularPlanBean.setBankAccount(accountServiceUtil.retrieveBankAccountDetails(regularPlanType.getBankAccount(), loggerType));
            regularPlanBean.setAmount(accountServiceUtil.retrieveBigDecimalValue(regularPlanType.getAmount(), loggerType));
            regularPlanBean.setUseNaturalIncome(accountServiceUtil.retrieveBooleanValue(regularPlanType.isUseNaturalIncome(), loggerType));
            getRegularContributionPlanAdditionalDetails(regularPlanType, loggerType, regularPlanBean, accountServiceUtil);
        }
        return regularPlanBean;
    }

    /**
     * Does this.
     *
     * @param regularPlanType
     * @param loggerType
     * @param regularPlanBean
     * @param accountServiceUtil
     * @throws SILException
     */
    private void getRegularContributionPlanAdditionalDetails(RegularPlanType regularPlanType, String loggerType, RegularPlanBean regularPlanBean,
            AccountServiceUtil accountServiceUtil) throws SILException {
        regularPlanBean.setAmountCurrencyCode(accountServiceUtil.retrieveCurrencyIdentifierDetails(regularPlanType.getAmountCurrencyCode(),
                loggerType));
        regularPlanBean.setIndexationRequired(retrieveIndexationRequiredDetails(regularPlanType.getIndexationRequired(), accountServiceUtil,
                loggerType));
        regularPlanBean.setNextDueDate(accountServiceUtil.retrieveDateValue(regularPlanType.getNextDueDate(), loggerType));
        regularPlanBean.setPayerReference(regularPlanType.getPayerReference());
        regularPlanBean.setSourceOfWealth(accountServiceUtil.retrieveCode(regularPlanType.getSourceOfWealth(), loggerType));
        regularPlanBean.setSourceOfWealthText(regularPlanType.getSourceOfWealthText());
        regularPlanBean.setLinkedToProfile(accountServiceUtil.retrieveBooleanValue(regularPlanType.isLinkedToProfile(), loggerType));
        regularPlanBean.setFundSplits(retrieveFundSplitsDetailsList(regularPlanType.getFundSplit(), accountServiceUtil, loggerType));
        regularPlanBean.setContributionTypeSplits(retrieveContributionTypeDetailsList(regularPlanType.getContributionTypeSplit(),
                accountServiceUtil, loggerType));
        regularPlanBean
                .setBalanceTypeSplits(retrieveBalanceTypeDetailsList(regularPlanType.getBalanceTypeSplit(), accountServiceUtil, loggerType));
        regularPlanBean.setInvestmentRequester(retrieveInvestmentRequesterDetails(regularPlanType.getInvestmentRequester(), accountServiceUtil,
                loggerType));
        regularPlanBean.setInstructorCategoryCode(accountServiceUtil.retrieveCode(regularPlanType.getInstructorCategoryCode(), loggerType));
    }

    /**
     * This method is used to get indexation required details.
     *
     * @param indexationRequired
     * @param accountServiceUtil
     * @param loggerType
     * @return
     * @throws SILException
     */
    private IndexationRequiredBean retrieveIndexationRequiredDetails(IndexationRequired indexationRequired, AccountServiceUtil accountServiceUtil,
            String loggerType) throws SILException {
        IndexationRequiredBean indexationRequiredBean = new IndexationRequiredBean();
        if (indexationRequired != null) {
            indexationRequiredBean.setIndexationDate(accountServiceUtil.retrieveDateValue(indexationRequired.getIndexationDate(), loggerType));
            indexationRequiredBean.setIndexationDeclined(accountServiceUtil.retrieveBooleanValue(indexationRequired.isIndexationDeclined(),
                    loggerType));
            indexationRequiredBean.setIndexationRate(accountServiceUtil.retrieveBigDecimalValue(indexationRequired.getIndexationRate(), loggerType));
            indexationRequiredBean.setIndexationRunDate(accountServiceUtil.retrieveDateValue(indexationRequired.getIndexationRunDate(), loggerType));
        } else {
            retrieveEmptyIndexationRequiredDetails(indexationRequiredBean);
        }
        return indexationRequiredBean;
    }

    /**
     * This method is used to get empty indexation required details.
     *
     * @param indexationRequiredBean
     */
    private void retrieveEmptyIndexationRequiredDetails(IndexationRequiredBean indexationRequiredBean) {
        indexationRequiredBean.setIndexationDate(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        indexationRequiredBean.setIndexationDeclined(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        indexationRequiredBean.setIndexationRate(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        indexationRequiredBean.setIndexationRunDate(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
    }

    /**
     * This method is used to get fund splits details list.
     *
     * @param fundSplitsList
     * @param accountServiceUtil
     * @param loggerType
     * @return
     * @throws SILException
     */
    private List<FundSplitsBean> retrieveFundSplitsDetailsList(List<FundSplit> fundSplitsList, AccountServiceUtil accountServiceUtil,
            String loggerType) throws SILException {
        List<FundSplitsBean> fundSplitsBeansList = new ArrayList<FundSplitsBean>();
        if (fundSplitsList != null && fundSplitsList.size() > 0) {
            for (FundSplit fundSplitType : fundSplitsList) {
                fundSplitsBeansList.add(retrieveFundSplitsDetails(fundSplitType, accountServiceUtil, loggerType));
            }
        }
        return fundSplitsBeansList;
    }

    /**
     * This method is used to get fund splits details.
     *
     * @param fundSplitType
     * @param accountServiceUtil
     * @param loggerType
     * @return
     * @throws SILException
     */
    private FundSplitsBean retrieveFundSplitsDetails(FundSplit fundSplitType, AccountServiceUtil accountServiceUtil, String loggerType)
            throws SILException {
        FundSplitsBean fundSplitsBean = new FundSplitsBean();
        if (fundSplitType != null) {
            fundSplitsBean.setAmount(accountServiceUtil.retrieveBigDecimalValue(fundSplitType.getAmount(), loggerType));
            fundSplitsBean.setPercentage(accountServiceUtil.retrieveBigDecimalValue(fundSplitType.getPercentage(), loggerType));
            fundSplitsBean.setAmountCurrencyCode(accountServiceUtil.retrieveCurrencyIdentifierDetails(fundSplitType.getAmountCurrencyCode(),
                    loggerType));
            fundSplitsBean.setFund(accountServiceUtil.retrieveFundIdentifier(fundSplitType.getFund(), loggerType));
        }
        return fundSplitsBean;
    }

    /**
     * This method is used to get contribution type details list.
     *
     * @param contributionTypeSplitsList
     * @param accountServiceUtil
     * @param loggerType
     * @return
     * @throws SILException
     */
    private List<ContributionTypeSplitsBean> retrieveContributionTypeDetailsList(List<ContributionTypeSplit> contributionTypeSplitsList,
            AccountServiceUtil accountServiceUtil, String loggerType) throws SILException {
        List<ContributionTypeSplitsBean> contributionTypeSplitsBeansList = new ArrayList<ContributionTypeSplitsBean>();
        if (contributionTypeSplitsList != null && contributionTypeSplitsList.size() > 0) {
            for (ContributionTypeSplit contributionTypeSplit : contributionTypeSplitsList) {
                contributionTypeSplitsBeansList.add(retrieveContributionTypeDetails(contributionTypeSplit, accountServiceUtil, loggerType));
            }
        }
        return contributionTypeSplitsBeansList;
    }

    /**
     * This method is used to get contribution type details.
     *
     * @param contributionTypeSplitType
     * @param accountServiceUtil
     * @param loggerType
     * @return
     * @throws SILException
     */
    private ContributionTypeSplitsBean retrieveContributionTypeDetails(ContributionTypeSplit contributionTypeSplitType,
            AccountServiceUtil accountServiceUtil, String loggerType) throws SILException {
        ContributionTypeSplitsBean contributionTypeSplitsBean = new ContributionTypeSplitsBean();
        if (contributionTypeSplitType != null) {
            contributionTypeSplitsBean.setAmount(accountServiceUtil.retrieveBigDecimalValue(contributionTypeSplitType.getAmount(), loggerType));
            contributionTypeSplitsBean.setAmountCurrencyCode(accountServiceUtil.retrieveCurrencyIdentifierDetails(
                    contributionTypeSplitType.getAmountCurrencyCode(), loggerType));
            contributionTypeSplitsBean.setContributionTypeCode(accountServiceUtil.retrieveCode(contributionTypeSplitType.getContributionTypeCode(),
                    loggerType));
            contributionTypeSplitsBean
                    .setPercentage(accountServiceUtil.retrieveBigDecimalValue(contributionTypeSplitType.getPercentage(), loggerType));
        }
        return contributionTypeSplitsBean;
    }

    /**
     * This method is used to get balance type details list.
     *
     * @param balanceTypeSplitsList
     * @param accountServiceUtil
     * @param loggerType
     * @return
     * @throws SILException
     */
    private List<BalanceTypeSplitsBean> retrieveBalanceTypeDetailsList(List<BalanceTypeSplit> balanceTypeSplitsList,
            AccountServiceUtil accountServiceUtil, String loggerType) throws SILException {
        List<BalanceTypeSplitsBean> balanceTypeSplitsBeansList = new ArrayList<BalanceTypeSplitsBean>();
        if (balanceTypeSplitsList != null && balanceTypeSplitsList.size() > 0) {
            for (BalanceTypeSplit balanceTypeSplit : balanceTypeSplitsList) {
                balanceTypeSplitsBeansList.add(retrieveBalanceTypeDetails(balanceTypeSplit, accountServiceUtil, loggerType));
            }
        } else {
            BalanceTypeSplitsBean balanceTypeSplitsBean = new BalanceTypeSplitsBean();
            retrieveEmptyBalanceTypeDetails(balanceTypeSplitsBean, accountServiceUtil, loggerType);
            balanceTypeSplitsBeansList.add(balanceTypeSplitsBean);
        }
        return balanceTypeSplitsBeansList;
    }

    /**
     * This method is used to get balance type details.
     *
     * @param balanceTypeSplit
     * @param accountServiceUtil
     * @param loggerType
     * @return
     * @throws SILException
     */
    private BalanceTypeSplitsBean retrieveBalanceTypeDetails(BalanceTypeSplit balanceTypeSplit, AccountServiceUtil accountServiceUtil,
            String loggerType) throws SILException {
        BalanceTypeSplitsBean balanceTypeSplitsBean = new BalanceTypeSplitsBean();
        if (balanceTypeSplit != null) {
            balanceTypeSplitsBean.setAmount(accountServiceUtil.retrieveBigDecimalValue(balanceTypeSplit.getAmount(), loggerType));
            balanceTypeSplitsBean.setAmountCurrencyCode(accountServiceUtil.retrieveCurrencyIdentifierDetails(
                    balanceTypeSplit.getAmountCurrencyCode(), loggerType));
            balanceTypeSplitsBean.setBalanceTypeCode(accountServiceUtil.retrieveCode(balanceTypeSplit.getBalanceTypeCode(), loggerType));
            balanceTypeSplitsBean.setPercentage(accountServiceUtil.retrieveBigDecimalValue(balanceTypeSplit.getPercentage(), loggerType));
        } else {
            retrieveEmptyBalanceTypeDetails(balanceTypeSplitsBean, accountServiceUtil, loggerType);
        }
        return balanceTypeSplitsBean;
    }

    /**
     * This method is used to get empty balance type details.
     *
     * @param balanceTypeSplitBean
     * @param accountServiceUtil
     * @param loggerType
     * @throws SILException
     */
    private void retrieveEmptyBalanceTypeDetails(BalanceTypeSplitsBean balanceTypeSplitBean, AccountServiceUtil accountServiceUtil, String loggerType)
            throws SILException {
        balanceTypeSplitBean.setAmount(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        balanceTypeSplitBean.setAmountCurrencyCode(accountServiceUtil.retrieveEmptyCurrencyIdentifierDetails(loggerType));
        balanceTypeSplitBean.setBalanceTypeCode(accountServiceUtil.retrieveEmptyCode(loggerType));
        balanceTypeSplitBean.setPercentage(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
    }

    /**
     * This method is used to get investment requester details.
     *
     * @param investmentRequesterType
     * @param accountServiceUtil
     * @param loggerType
     * @return
     * @throws SILException
     */
    public InvestmentRequesterBean retrieveInvestmentRequesterDetails(InvestmentRequesterType investmentRequesterType,
            AccountServiceUtil accountServiceUtil, String loggerType) throws SILException {
        InvestmentRequesterBean investmentRequesterBean = new InvestmentRequesterBean();
        if (investmentRequesterType != null) {
            investmentRequesterBean.setAdvisor(accountServiceUtil.retrieveAdvisorDetails(investmentRequesterType.getAdvisor(), loggerType));
            investmentRequesterBean.setClient(accountServiceUtil.retrieveClientDetails(investmentRequesterType.getClient(), loggerType));
        } else {
            investmentRequesterBean.setAdvisor(accountServiceUtil.retrieveEmptyAdvisor(loggerType));
            investmentRequesterBean.setClient(accountServiceUtil.retrieveEmptyClientDetails(loggerType));
        }
        return investmentRequesterBean;
    }
}
