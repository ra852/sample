////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code NoteCategoryBean} is used to hold category.
 * 
 * @author U383754
 * @since 24/05/2016
 * @version 1.0
 */
public class NoteCategoryBean {

    private String id;
    private String name;
    private String code;
    private AuditIdentifier audit;

    /**
     * Accessor for property id.
     * 
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     * 
     * @return id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id;
    }

    /**
     * Accessor for property name.
     * 
     * @return name of type String
     */
    public String getName() {
        return name;
    }

    /**
     * Mutator for property name.
     * 
     * @return name of type String
     */
    @XmlElement(name = "name")
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Accessor for property code.
     * 
     * @return code of type String
     */
    public String getCode() {
        return code;
    }

    /**
     * Mutator for property code.
     * 
     * @return code of type String
     */
    @XmlElement(name = "code")
    public void setCode(String code) {
        this.code = code;
    }

    /**
     * Accessor for property audit.
     * 
     * @return audit of type AuditIdentifier
     */
    public AuditIdentifier getAudit() {
        return audit;
    }

    /**
     * Mutator for property audit.
     * 
     * @return audit of type AuditIdentifier
     */
    @XmlElement(name = "audit")
    public void setAudit(AuditIdentifier audit) {
        this.audit = audit;
    }

}
