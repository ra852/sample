////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code PensionPaymentInstruction} does this.
 * 
 * @author U387938
 * @since 02/02/2016
 * @version 1.0
 */
public class PensionPaymentInstruction {
    private String id;
    private String nextReviewDate;
    private FrequencyIdentifierBean paymentFrequency;
    private CodeIdentifier reviewType;
    private String annualNominatedPercent;
    private String annualNominatedAmount;
    private String used;

    /**
     * Accessor for property id.
     * 
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     * 
     * @param id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id != null ? id : "";
    }

    /**
     * Accessor for property nextReviewDate.
     * 
     * @return nextReviewDate of type String
     */
    public String getNextReviewDate() {
        return nextReviewDate;
    }

    /**
     * Mutator for property nextReviewDate.
     * 
     * @param nextReviewDate of type String
     */
    @XmlElement(name = "nextReviewDate")
    public void setNextReviewDate(String nextReviewDate) {
        this.nextReviewDate = nextReviewDate != null ? nextReviewDate : "";
    }

    /**
     * Accessor for property paymentFrequency.
     * 
     * @return paymentFrequency of type FrequencyIdentifierBean
     */
    public FrequencyIdentifierBean getPaymentFrequency() {
        return paymentFrequency;
    }

    /**
     * Mutator for property paymentFrequency.
     * 
     * @param paymentFrequency of type FrequencyIdentifierBean
     */
    @XmlElement(name = "paymentFrequency")
    public void setPaymentFrequency(FrequencyIdentifierBean paymentFrequency) {
        this.paymentFrequency = paymentFrequency;
    }

    /**
     * Accessor for property reviewType.
     * 
     * @return reviewType of type CodeIdentifier
     */
    public CodeIdentifier getReviewType() {
        return reviewType;
    }

    /**
     * Mutator for property reviewType.
     * 
     * @param reviewType of type CodeIdentifier
     */
    @XmlElement(name = "reviewType")
    public void setReviewType(CodeIdentifier reviewType) {
        this.reviewType = reviewType;
    }

    /**
     * Accessor for property annualNominatedPercent.
     * 
     * @return annualNominatedPercent of type String
     */
    public String getAnnualNominatedPercent() {
        return annualNominatedPercent;
    }

    /**
     * Mutator for property annualNominatedPercent.
     * 
     * @param annualNominatedPercent of type String
     */
    @XmlElement(name = "annualNominatedPercent")
    public void setAnnualNominatedPercent(String annualNominatedPercent) {
        this.annualNominatedPercent = annualNominatedPercent != null ? annualNominatedPercent : "";
    }

    /**
     * Accessor for property annualNominatedAmount.
     * 
     * @return annualNominatedAmount of type String
     */
    public String getAnnualNominatedAmount() {
        return annualNominatedAmount;
    }

    /**
     * Mutator for property annualNominatedAmount.
     * 
     * @param annualNominatedAmount of type String
     */
    @XmlElement(name = "annualNominatedAmount")
    public void setAnnualNominatedAmount(String annualNominatedAmount) {
        this.annualNominatedAmount = annualNominatedAmount != null ? annualNominatedAmount : "";
    }

    /**
     * Accessor for property used.
     * 
     * @return used of type String
     */
    public String getUsed() {
        return used;
    }

    /**
     * Mutator for property used.
     * 
     * @param used of type String
     */
    @XmlElement(name = "used")
    public void setUsed(String used) {
        this.used = used != null ? used : "";
    }
}
