////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;


/**
 * The class {@code AllowableReviewIdentifierDetails} does this.
 *
 * @author U385424
 * @since 17/02/2018
 * @version 1.0
 */
public class AllowableReviewIdentifierDetails {
    private ReviewTypeIdentifierDetails reviewType;
    private String name;

    /**
     * Accessor for property reviewType.
     * 
     * @return reviewType of type ReviewTypeIdentifierDetails
     */
    public ReviewTypeIdentifierDetails getReviewType() {
        return reviewType;
    }

    /**
     * Mutator for property reviewType.
     * 
     * @return reviewType of type ReviewTypeIdentifierDetails
     */
    @XmlElement(name = "reviewType")
    public void setReviewType(ReviewTypeIdentifierDetails reviewType) {
        this.reviewType = reviewType;
    }

    /**
     * Accessor for property name.
     * 
     * @return name of type String
     */
    public String getName() {
        return name;
    }

    /**
     * Mutator for property name.
     * 
     * @param name of type String
     */
    @XmlElement(name = "name")
    public void setName(String name) {
        this.name = name;
    }
}
