////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code AccountDetailsList} does this.
 * 
 * @author U387938
 * @since 02/02/2016
 * @version 1.0
 */
public class AccountDetailsList {
    private AccountDetails account;
    private AccountDetailBean accountDetail;
    private ProductDetails product;
    private SchemeIdentifier scheme;
    private SchemeCategoryBean schemeCategory;
    private MarketingCampaignDetails marketingCampaign;
    private IdentityIdentifier currentExpenseGroup;
    private List<ClientAccountRelationshipBean> clientAccountRelationships;
    private SchemeLocationIdentifier schemeLocation;
    private List<InvestmentProfileDetails> investmentProfiles;
    private List<AdvisorGroupBean> advisorGroups;
    private List<BeneficiaryDetails> beneficiaries;
    private String accountBalance;
    private List<SchemeLocationHistoryBean> schemeLocationHistories;
    private AccountTaxDetails accountTaxDetail;
    private PensionPaymentAmountDetails pensionPaymentAmountDetail;
    private List<PensionPaymentInstruction> pensionPaymentInstruction;
    private List<PensionPaymentSplitDetails> pensionPaymentSplit;
    private PensionDrawdownDetail pensionDrawdownDetail;
    private List<PensionProtectionDetails> pensionProtection;
    private List<GenericVariableBean> genericVariables;
    private List<NoteBean> notes;
    private List<RegularPlanBean> regularContributionPlans;
    private CurrentAccountExpenseGroupBean currentAccountExpenseGroup;
    private List<FamilyGroupDetails> familyGroupDetail;
    private List<RestrictionBean> restriction;
    private List<ExternalReference> externalReferences;
    private List<RiderDetails> insurances;

    /**
     * Accessor for property familyGroupDetail.
     * 
     * @return familyGroupDetail of type List<FamilyGroupDetails>
     */
    public List<FamilyGroupDetails> getFamilyGroupDetail() {
        return familyGroupDetail;
    }

    /**
     * Mutator for property familyGroupDetail.
     * 
     * @return familyGroupDetail of type List<FamilyGroupDetails>
     */
    @XmlElement(name = "familyGroupDetail")
    public void setFamilyGroupDetail(List<FamilyGroupDetails> familyGroupDetail) {
        this.familyGroupDetail = familyGroupDetail;
    }

    /**
     * Accessor for property account.
     * 
     * @return account of type AccountDetails
     */
    public AccountDetails getAccount() {
        return account;
    }

    /**
     * Mutator for property account.
     * 
     * @param account
     *            of type AccountDetails
     */
    @XmlElement(name = "account")
    public void setAccount(AccountDetails account) {
        this.account = account;
    }

    /**
     * Accessor for property accountDetail.
     * 
     * @return accountDetail of type AccountDetailBean
     */
    public AccountDetailBean getAccountDetail() {
        return accountDetail;
    }

    /**
     * Mutator for property accountDetail.
     * 
     * @param accountDetail
     *            of type AccountDetailBean
     */
    @XmlElement(name = "accountDetail")
    public void setAccountDetail(AccountDetailBean accountDetail) {
        this.accountDetail = accountDetail;
    }

    /**
     * Accessor for property product.
     * 
     * @return product of type ProductDetails
     */
    public ProductDetails getProduct() {
        return product;
    }

    /**
     * Mutator for property product.
     * 
     * @param product
     *            of type ProductDetails
     */
    @XmlElement(name = "product")
    public void setProduct(ProductDetails product) {
        this.product = product;
    }

    /**
     * Accessor for property scheme.
     * 
     * @return scheme of type SchemeIdentifier
     */
    public SchemeIdentifier getScheme() {
        return scheme;
    }

    /**
     * Mutator for property scheme.
     * 
     * @param scheme
     *            of type SchemeIdentifier
     */
    @XmlElement(name = "scheme")
    public void setScheme(SchemeIdentifier scheme) {
        this.scheme = scheme;
    }

    /**
     * Accessor for property schemeCategory.
     * 
     * @return schemeCategory of type SchemeCategoryBean
     */
    public SchemeCategoryBean getSchemeCategory() {
        return schemeCategory;
    }

    /**
     * Mutator for property schemeCategory.
     * 
     * @param schemeCategory
     *            of type SchemeCategoryBean
     */
    @XmlElement(name = "schemeCategory")
    public void setSchemeCategory(SchemeCategoryBean schemeCategory) {
        this.schemeCategory = schemeCategory;
    }

    /**
     * Accessor for property marketingCampaign.
     * 
     * @return marketingCampaign of type MarketingCampaignDetails
     */
    public MarketingCampaignDetails getMarketingCampaign() {
        return marketingCampaign;
    }

    /**
     * Mutator for property marketingCampaign.
     * 
     * @param marketingCampaign
     *            of type MarketingCampaignDetails
     */
    @XmlElement(name = "marketingCampaign")
    public void setMarketingCampaign(MarketingCampaignDetails marketingCampaign) {
        this.marketingCampaign = marketingCampaign;
    }

    /**
     * Accessor for property currentExpenseGroup.
     * 
     * @return currentExpenseGroup of type IdentityIdentifier
     */
    public IdentityIdentifier getCurrentExpenseGroup() {
        return currentExpenseGroup;
    }

    /**
     * Mutator for property currentExpenseGroup.
     * 
     * @param currentExpenseGroup
     *            of type IdentityIdentifier
     */
    @XmlElement(name = "currentExpenseGroup")
    public void setCurrentExpenseGroup(IdentityIdentifier currentExpenseGroup) {
        this.currentExpenseGroup = currentExpenseGroup;
    }

    /**
     * Accessor for property clientAccountRelationships.
     * 
     * @return clientAccountRelationships of type List<ClientAccountRelationshipBean>
     */
    public List<ClientAccountRelationshipBean> getClientAccountRelationships() {
        return clientAccountRelationships;
    }

    /**
     * Mutator for property clientAccountRelationships.
     * 
     * @param clientAccountRelationships
     *            of type List<ClientAccountRelationshipBean>
     */
    @XmlElement(name = "clientAccountRelationships")
    public void setClientAccountRelationships(List<ClientAccountRelationshipBean> clientAccountRelationships) {
        this.clientAccountRelationships = clientAccountRelationships;
    }

    /**
     * Accessor for property schemeLocation.
     * 
     * @return schemeLocation of type SchemeLocationIdentifier
     */
    public SchemeLocationIdentifier getSchemeLocation() {
        return schemeLocation;
    }

    /**
     * Mutator for property schemeLocation.
     * 
     * @param schemeLocation
     *            of type SchemeLocationIdentifier
     */
    @XmlElement(name = "schemeLocation")
    public void setSchemeLocation(SchemeLocationIdentifier schemeLocation) {
        this.schemeLocation = schemeLocation;
    }

    /**
     * Accessor for property investmentProfiles.
     * 
     * @return investmentProfiles of type List<InvestmentProfileDetails>
     */
    public List<InvestmentProfileDetails> getInvestmentProfiles() {
        return investmentProfiles;
    }

    /**
     * Mutator for property investmentProfiles.
     * 
     * @param investmentProfiles
     *            of type List<InvestmentProfileDetails>
     */
    @XmlElement(name = "investmentProfiles")
    public void setInvestmentProfiles(List<InvestmentProfileDetails> investmentProfiles) {
        this.investmentProfiles = investmentProfiles;
    }

    /**
     * Accessor for property advisorGroups.
     * 
     * @return advisorGroups of type List<AdvisorGroupBean>
     */
    public List<AdvisorGroupBean> getAdvisorGroups() {
        return advisorGroups;
    }

    /**
     * Mutator for property advisorGroups.
     * 
     * @param advisorGroups
     *            of type List<AdvisorGroupBean>
     */
    @XmlElement(name = "advisorGroups")
    public void setAdvisorGroups(List<AdvisorGroupBean> advisorGroups) {
        this.advisorGroups = advisorGroups;
    }

    /**
     * Accessor for property beneficiaries.
     * 
     * @return beneficiaries of type List<BeneficiaryDetails>
     */
    public List<BeneficiaryDetails> getBeneficiaries() {
        return beneficiaries;
    }

    /**
     * Mutator for property beneficiaries.
     * 
     * @param beneficiaries
     *            of type List<BeneficiaryDetails>
     */
    @XmlElement(name = "beneficiaries")
    public void setBeneficiaries(List<BeneficiaryDetails> beneficiaries) {
        this.beneficiaries = beneficiaries;
    }

    /**
     * Accessor for property accountBalance.
     * 
     * @return accountBalance of type String
     */
    public String getAccountBalance() {
        return accountBalance;
    }

    /**
     * Mutator for property accountBalance.
     * 
     * @param accountBalance
     *            of type String
     */
    @XmlElement(name = "accountBalance")
    public void setAccountBalance(String accountBalance) {
        this.accountBalance = accountBalance != null ? accountBalance : "";
    }

    /**
     * Accessor for property schemeLocationHistories.
     * 
     * @return schemeLocationHistories of type List<SchemeLocationHistoryBean>
     */
    public List<SchemeLocationHistoryBean> getSchemeLocationHistories() {
        return schemeLocationHistories;
    }

    /**
     * Mutator for property schemeLocationHistories.
     * 
     * @param schemeLocationHistories
     *            of type List<SchemeLocationHistoryBean>
     */
    @XmlElement(name = "schemeLocationHistories")
    public void setSchemeLocationHistories(List<SchemeLocationHistoryBean> schemeLocationHistories) {
        this.schemeLocationHistories = schemeLocationHistories;
    }

    /**
     * Accessor for property accountTaxDetail.
     * 
     * @return accountTaxDetail of type AccountTaxDetails
     */
    public AccountTaxDetails getAccountTaxDetail() {
        return accountTaxDetail;
    }

    /**
     * Mutator for property accountTaxDetail.
     * 
     * @return accountTaxDetail of type AccountTaxDetails
     */
    @XmlElement(name = "accountTaxDetail")
    public void setAccountTaxDetail(AccountTaxDetails accountTaxDetail) {
        this.accountTaxDetail = accountTaxDetail;
    }

    /**
     * Accessor for property pensionPaymentAmountDetail.
     * 
     * @return pensionPaymentAmountDetail of type PensionPaymentAmountDetails
     */
    public PensionPaymentAmountDetails getPensionPaymentAmountDetail() {
        return pensionPaymentAmountDetail;
    }

    /**
     * Mutator for property pensionPaymentAmountDetail.
     * 
     * @return pensionPaymentAmountDetail of type PensionPaymentAmountDetails
     */
    @XmlElement(name = "pensionPaymentAmountDetail")
    public void setPensionPaymentAmountDetail(PensionPaymentAmountDetails pensionPaymentAmountDetail) {
        this.pensionPaymentAmountDetail = pensionPaymentAmountDetail;
    }

    /**
     * Accessor for property pensionPaymentInstruction.
     * 
     * @return pensionPaymentInstruction of type List<PensionPaymentInstruction>
     */
    public List<PensionPaymentInstruction> getPensionPaymentInstruction() {
        return pensionPaymentInstruction;
    }

    /**
     * Mutator for property pensionPaymentInstruction.
     * 
     * @return pensionPaymentInstruction of type List<PensionPaymentInstruction>
     */
    @XmlElement(name = "pensionPaymentInstructions")
    public void setPensionPaymentInstruction(List<PensionPaymentInstruction> pensionPaymentInstruction) {
        this.pensionPaymentInstruction = pensionPaymentInstruction;
    }

    /**
     * Accessor for property pensionPaymentSplit.
     * 
     * @return pensionPaymentSplit of type List<PensionPaymentSplitDetails>
     */
    public List<PensionPaymentSplitDetails> getPensionPaymentSplit() {
        return pensionPaymentSplit;
    }

    /**
     * Mutator for property pensionPaymentSplit.
     * 
     * @return pensionPaymentSplit of type List<PensionPaymentSplitDetails>
     */
    @XmlElement(name = "pensionPaymentSplits")
    public void setPensionPaymentSplit(List<PensionPaymentSplitDetails> pensionPaymentSplit) {
        this.pensionPaymentSplit = pensionPaymentSplit;
    }

    /**
     * Accessor for property pensionDrawdownDetail.
     * 
     * @return pensionDrawdownDetail of type PensionDrawdownDetail
     */
    public PensionDrawdownDetail getPensionDrawdownDetail() {
        return pensionDrawdownDetail;
    }

    /**
     * Mutator for property pensionDrawdownDetail.
     * 
     * @return pensionDrawdownDetail of type PensionDrawdownDetail
     */
    @XmlElement(name = "pensionDrawdownDetail")
    public void setPensionDrawdownDetail(PensionDrawdownDetail pensionDrawdownDetail) {
        this.pensionDrawdownDetail = pensionDrawdownDetail;
    }

    /**
     * Accessor for property pensionProtection.
     * 
     * @return pensionProtection of type List<PensionProtectionDetails>
     */
    public List<PensionProtectionDetails> getPensionProtection() {
        return pensionProtection;
    }

    /**
     * Mutator for property pensionProtection.
     * 
     * @return pensionProtection of type List<PensionProtectionDetails>
     */
    @XmlElement(name = "pensionProtections")
    public void setPensionProtection(List<PensionProtectionDetails> pensionProtection) {
        this.pensionProtection = pensionProtection;
    }

    /**
     * Accessor for property genericVariables.
     * 
     * @return genericVariables of type List<GenericVariableBean>
     */
    public List<GenericVariableBean> getGenericVariables() {
        return genericVariables;
    }

    /**
     * Mutator for property genericVariables.
     * 
     * @param genericVariables
     *            of type List<GenericVariableBean>
     */
    @XmlElement(name = "genericVariables")
    public void setGenericVariables(List<GenericVariableBean> genericVariables) {
        this.genericVariables = genericVariables;
    }

    /**
     * Accessor for property notes.
     * 
     * @return notes of type List<NoteBean>
     */
    public List<NoteBean> getNotes() {
        return notes;
    }

    /**
     * Mutator for property notes.
     * 
     * @return notes of type List<NoteBean>
     */
    @XmlElement(name = "notes")
    public void setNotes(List<NoteBean> notes) {
        this.notes = notes;
    }

    /**
     * Accessor for property regularContributionPlans.
     * 
     * @return regularContributionPlans of type List<RegularPlanBean>
     */
    public List<RegularPlanBean> getRegularContributionPlans() {
        return regularContributionPlans;
    }

    /**
     * Mutator for property regularContributionPlans.
     * 
     * @param regularContributionPlans
     *            of type List<RegularPlanBean>
     */
    @XmlElement(name = "regularContributionPlans")
    public void setRegularContributionPlans(List<RegularPlanBean> regularContributionPlans) {
        this.regularContributionPlans = regularContributionPlans;
    }

    /**
     * Accessor for property currentAccountExpenseGroup.
     * 
     * @return currentAccountExpenseGroup of type CurrentAccountExpenseGroupBean
     */
    public CurrentAccountExpenseGroupBean getCurrentAccountExpenseGroup() {
        return currentAccountExpenseGroup;
    }

    /**
     * Mutator for property currentAccountExpenseGroup.
     * 
     * @param currentAccountExpenseGroup
     *            of type CurrentAccountExpenseGroupBean
     */
    @XmlElement(name = "currentAccountExpenseGroup")
    public void setCurrentAccountExpenseGroup(CurrentAccountExpenseGroupBean currentAccountExpenseGroup) {
        this.currentAccountExpenseGroup = currentAccountExpenseGroup;
    }

    /**
     * Accessor for property restriction.
     *
     * @return restriction of type List<RestrictionBean>
     */
    public List<RestrictionBean> getRestriction() {
        return restriction;
    }

    /**
     * Mutator for property restriction.
     *
     * @param restriction of type List<RestrictionBean>
     */
    @XmlElement(name = "restriction")
    public void setRestriction(List<RestrictionBean> restriction) {
        this.restriction = restriction;
    }

    /**
     * Accessor for property externalReferences.
     * 
     * @return externalReferences of type List<ExternalReference>
     */
    public List<ExternalReference> getExternalReferences() {
        return externalReferences;
    }

    /**
     * Mutator for property externalReferences.
     * 
     * @param externalReferences of type List<ExternalReference>
     */
    @XmlElement(name = "externalReferences")
    public void setExternalReferences(List<ExternalReference> externalReferences) {
        this.externalReferences = externalReferences;
    }

    /**
     * Accessor for property insurances.
     * 
     * @return insurances of type List<RiderDetails>
     */
    public List<RiderDetails> getInsurances() {
        return insurances;
    }

    /**
     * Mutator for property insurances.
     * 
     * @param insurances of type List<RiderDetails>
     */
    @XmlElement(name = "insurances")
    public void setInsurances(List<RiderDetails> insurances) {
        this.insurances = insurances;
    }
    
}
