////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code TransSummaryDetail} is an entity POJO for GetAccountTransactionSummary service.
 * 
 * @author U384381
 * @since 30/12/2015
 * @version 1.0
 */
public class TransSummaryDetail {
    private String id;
    private String fundFullName;
    private String unitPriceEffectiveDate;
    private String closingPercentage;
    private String openingBalanceAmount;
    private String closingBalanceAmount;
    private String openingPrice;
    private String closingPrice;
    private String openingUnits;
    private String closingUnits;

    /**
     * Accessor for property id.
     * 
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     * 
     * @return id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id;
    }

    /**
     * Accessor for property fundFullName.
     * 
     * @return fundFullName of type String
     */
    public String getFundFullName() {
        return fundFullName;
    }

    /**
     * Mutator for property fundFullName.
     * 
     * @return fundFullName of type String
     */
    @XmlElement(name = "fundFullName")
    public void setFundFullName(String fundFullName) {
        this.fundFullName = fundFullName;
    }

    /**
     * Accessor for property unitPriceEffectiveDate.
     * 
     * @return unitPriceEffectiveDate of type String
     */
    public String getUnitPriceEffectiveDate() {
        return unitPriceEffectiveDate;
    }

    /**
     * Mutator for property unitPriceEffectiveDate.
     * 
     * @return unitPriceEffectiveDate of type String
     */
    @XmlElement(name = "unitPriceEffectiveDate")
    public void setUnitPriceEffectiveDate(String unitPriceEffectiveDate) {
        this.unitPriceEffectiveDate = unitPriceEffectiveDate;
    }

    /**
     * Accessor for property percentage.
     * 
     * @return percentage of type String
     */
    public String getPercentage() {
        return closingPercentage;
    }

    /**
     * Mutator for property percentage.
     * 
     * @return percentage of type String
     */
    @XmlElement(name = "percentage")
    public void setPercentage(String percentage) {
        this.closingPercentage = percentage;
    }

    /**
     * Accessor for property openingBalanceAmount.
     * 
     * @return openingBalanceAmount of type String
     */
    public String getOpeningBalanceAmount() {
        return openingBalanceAmount;
    }

    /**
     * Mutator for property openingBalanceAmount.
     * 
     * @return openingBalanceAmount of type String
     */
    @XmlElement(name = "openingBalanceAmount")
    public void setOpeningBalanceAmount(String openingBalanceAmount) {
        this.openingBalanceAmount = openingBalanceAmount;
    }

    /**
     * Accessor for property closingBalanceAmount.
     * 
     * @return closingBalanceAmount of type String
     */
    public String getClosingBalanceAmount() {
        return closingBalanceAmount;
    }

    /**
     * Mutator for property closingBalanceAmount.
     * 
     * @return closingBalanceAmount of type String
     */
    @XmlElement(name = "closingBalanceAmount")
    public void setClosingBalanceAmount(String closingBalanceAmount) {
        this.closingBalanceAmount = closingBalanceAmount;
    }

    /**
     * Accessor for property openingPrice.
     * 
     * @return openingPrice of type String
     */
    public String getOpeningPrice() {
        return openingPrice;
    }

    /**
     * Mutator for property openingPrice.
     * 
     * @return openingPrice of type String
     */
    @XmlElement(name = "openingPrice")
    public void setOpeningPrice(String openingPrice) {
        this.openingPrice = openingPrice;
    }

    /**
     * Accessor for property closingPrice.
     * 
     * @return closingPrice of type String
     */
    public String getClosingPrice() {
        return closingPrice;
    }

    /**
     * Mutator for property closingPrice.
     * 
     * @return closingPrice of type String
     */
    @XmlElement(name = "closingPrice")
    public void setClosingPrice(String closingPrice) {
        this.closingPrice = closingPrice;
    }

    /**
     * Accessor for property openingUnits.
     * 
     * @return openingUnits of type String
     */
    public String getOpeningUnits() {
        return openingUnits;
    }

    /**
     * Mutator for property openingUnits.
     * 
     * @return openingUnits of type String
     */
    @XmlElement(name = "openingUnits")
    public void setOpeningUnits(String openingUnits) {
        this.openingUnits = openingUnits;
    }

    /**
     * Accessor for property closingUnits.
     * 
     * @return closingUnits of type String
     */
    public String getClosingUnits() {
        return closingUnits;
    }

    /**
     * Mutator for property closingUnits.
     * 
     * @return closingUnits of type String
     */
    @XmlElement(name = "closingUnits")
    public void setClosingUnits(String closingUnits) {
        this.closingUnits = closingUnits;
    }
}
