////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.suncorp.ssp.common.bean.SILErrorMessage;

/**
 * The class {@code GetAccountExpenseResponse} does this.
 * 
 * @author U383754
 * @since 29/01/2016
 * @version 1.0
 */
@XmlRootElement(name = "GetAccountExpenseResponse")
public class GetAccountExpenseResponse extends SILErrorMessage {
    private AdvisorDetails advisor;
    private ProductDetails product;
    private MarketingCampaignDetails marketingCampaign;
    private AccountDetails account;
    private ExpenseGroupDetails expenseGroup;
    private List<ExpenseLineDetails> expenseLine;

    /**
     * Accessor for property advisor.
     * 
     * @return advisor of type AdvisorDetails
     */
    public AdvisorDetails getAdvisor() {
        return advisor;
    }

    /**
     * Mutator for property advisor.
     * 
     * @return advisor of type AdvisorDetails
     */
    @XmlElement(name = "advisor")
    public void setAdvisor(AdvisorDetails advisor) {
        this.advisor = advisor;
    }

    /**
     * Accessor for property product.
     * 
     * @return product of type ProductDetails
     */
    public ProductDetails getProduct() {
        return product;
    }

    /**
     * Mutator for property product.
     * 
     * @return product of type ProductDetails
     */
    @XmlElement(name = "product")
    public void setProduct(ProductDetails product) {
        this.product = product;
    }

    /**
     * Accessor for property marketingCampaign.
     * 
     * @return marketingCampaign of type MarketingCampaignDetails
     */
    public MarketingCampaignDetails getMarketingCampaign() {
        return marketingCampaign;
    }

    /**
     * Mutator for property marketingCampaign.
     * 
     * @return marketingCampaign of type MarketingCampaignDetails
     */
    @XmlElement(name = "marketingCampaign")
    public void setMarketingCampaign(MarketingCampaignDetails marketingCampaign) {
        this.marketingCampaign = marketingCampaign;
    }

    /**
     * Accessor for property account.
     * 
     * @return account of type AccountDetails
     */
    public AccountDetails getAccount() {
        return account;
    }

    /**
     * Mutator for property account.
     * 
     * @return account of type AccountDetails
     */
    @XmlElement(name = "account")
    public void setAccount(AccountDetails account) {
        this.account = account;
    }

    /**
     * Accessor for property expenseGroup.
     * 
     * @return expenseGroup of type ExpenseGroupDetails
     */
    public ExpenseGroupDetails getExpenseGroup() {
        return expenseGroup;
    }

    /**
     * Mutator for property expenseGroup.
     * 
     * @return expenseGroup of type ExpenseGroupDetails
     */
    @XmlElement(name = "expenseGroup")
    public void setExpenseGroup(ExpenseGroupDetails expenseGroup) {
        this.expenseGroup = expenseGroup;
    }

    /**
     * Accessor for property expenseLine.
     * 
     * @return expenseLine of type List<ExpenseLineDetails>
     */
    public List<ExpenseLineDetails> getExpenseLine() {
        return expenseLine;
    }

    /**
     * Mutator for property expenseLine.
     * 
     * @return expenseLine of type List<ExpenseLineDetails>
     */
    @XmlElement(name = "expenseLines")
    public void setExpenseLine(List<ExpenseLineDetails> expenseLine) {
        this.expenseLine = expenseLine;
    }
}
