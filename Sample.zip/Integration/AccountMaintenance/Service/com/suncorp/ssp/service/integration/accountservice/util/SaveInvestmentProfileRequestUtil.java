////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType.AccountNumber;
import com.sonatacentral.service.v30.wrap.account.SaveInvestmentProfileRequestType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.AccountIdentifierDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.AccountNumberInfo;
import com.suncorp.ssp.service.integration.accountservice.bean.SaveInvestmentProfileRequest;

/**
 * The class {@code SaveInvesmentProfileRequestUtil} does this.
 * 
 * @author U387938
 * @since 25/07/2016
 * @version 1.0
 */
public class SaveInvestmentProfileRequestUtil {
    private final String className = "CreateSwitchRequestUtil";
    private SaveInvestmentProfileRequest investmentProfileRequest;

    
    public SaveInvestmentProfileRequestUtil() {
    }

    public SaveInvestmentProfileRequestUtil(SaveInvestmentProfileRequest investmentProfileRequest) {
        this.investmentProfileRequest = investmentProfileRequest;
    }

    /**
     * 
     * Create Sonata request object for saveInvesmentProfile request.
     * 
     * @param createSwitchRequestType
     * @throws SILException
     */
    public void saveInvestmentProfileInboundRequest(SaveInvestmentProfileRequestType saveInvestmentProfileRequestType) throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_PROFILE_LOGGING_FORMAT, className, "entering createSwitchInboundRequest()");
        if (investmentProfileRequest != null) {
            InvestmentProfileRequestUtil investmentProfileRequestUtil = new InvestmentProfileRequestUtil();
            if (investmentProfileRequest.getAccount() != null) {
                saveInvestmentProfileRequestType.setAccount(setAccountDetails(investmentProfileRequest.getAccount()));
            }
            if (investmentProfileRequest.getInvestmentProfiles() != null && investmentProfileRequest.getInvestmentProfiles().size() > 0) {
                saveInvestmentProfileRequestType.getInvestmentProfile().addAll(
                        investmentProfileRequestUtil.setInvestmentProfileDetails(investmentProfileRequest.getInvestmentProfiles()));
            }
            SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_PROFILE_LOGGING_FORMAT, className, "exiting createSwitchInboundRequest()");
        } else {
            throw new SILException(AccountServiceConstants.SAVE_INVESTMENT_PROFILE_INVALID_REQUEST);
        }
    }

    /**
     * 
     * Set accountIdentifierType in sonata saveInvesmentProfile request.
     * 
     * @param accountIdentifierDetails
     * @return accountIdentifierType
     */
    private AccountIdentifierType setAccountDetails(AccountIdentifierDetails accountIdentifierDetails) {
        SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_PROFILE_LOGGING_FORMAT, className, "entering setAccountDetails()");
        AccountIdentifierType accountIdentifierType = null;
        if (accountIdentifierDetails != null) {
            accountIdentifierType = new AccountIdentifierType();
            if (accountIdentifierDetails.getAccountNumber() != null) {
                accountIdentifierType.setAccountNumber(setAccountNumber(accountIdentifierDetails.getAccountNumber()));
            }
            SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_PROFILE_LOGGING_FORMAT, className, "exiting setAccountDetails()");
        }
        return accountIdentifierType;
    }

    /**
     * 
     * Set account Number in sonata saveInvesmentProfile request.
     * 
     * @param accountNumberDetail
     * @return accountNumber
     */
    private AccountNumber setAccountNumber(AccountNumberInfo accountNumberDetail) {
        SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_PROFILE_LOGGING_FORMAT, className, "entering setAccountNumber()");
        AccountNumber accountNumber = null;
        if (accountNumberDetail != null && accountNumberDetail.getAccountNo() != null) {
            accountNumber = new AccountNumber();
            accountNumber.setAccountNo(accountNumberDetail.getAccountNo());
            SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_PROFILE_LOGGING_FORMAT, className, "exiting setAccountNumber()");
        }
        return accountNumber;
    }

}
