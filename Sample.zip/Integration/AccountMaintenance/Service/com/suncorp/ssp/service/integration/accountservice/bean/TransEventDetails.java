////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code TransEventDetails} is a pure java bean consisting of properties related to GetAccountTransactionList response.
 * 
 * @author u386868
 * @since 23/12/2015
 * @version 1.0
 */
public class TransEventDetails {

    private TransEvent transEvent;
    private List<TransEventAccountTransaction> accountTransactions;

    /**
     * Accessor for property transEvent.
     * 
     * @return transEvent of type TransEvent
     */
    public TransEvent getTransEvent() {
        return transEvent;
    }

    /**
     * Mutator for property transEvent.
     * 
     * @return transEvent of type TransEvent
     */
    @XmlElement(name = "transEvt")
    public void setTransEvent(TransEvent transEvent) {
        this.transEvent = transEvent;
    }

    /**
     * Accessor for property accountTransactions.
     *
     * @return accountTransactions of type List<TransEventAccountTransaction>
     */
    public List<TransEventAccountTransaction> getAccountTransactions() {
        return accountTransactions;
    }

    /**
     * Mutator for property accountTransactions.
     *
     * @param accountTransactions of type List<TransEventAccountTransaction>
     */
    @XmlElement(name = "accountTransactions")
    public void setAccountTransactions(List<TransEventAccountTransaction> accountTransactions) {
        this.accountTransactions = accountTransactions;
    }
}
