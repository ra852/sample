////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import java.util.ArrayList;
import java.util.List;

import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.ExternalRefType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountTaxType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AcctPensionProtectionDetailType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.PensionDrawdownDetailType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.PensionPaymentAmountDetailType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.PensionPaymentInstructionType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.PensionPaymentSplitType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.PensionPaymentSplitType.PaymentSplit;
import com.sonatacentral.service.v30.wrap.account.GetAccountDetailsResponseType;
import com.sonatacentral.service.v30.wrap.account.GetAccountDetailsResponseType.AccountDetails;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.AccountDetailsList;
import com.suncorp.ssp.service.integration.accountservice.bean.AccountIdentifierDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.AccountTaxDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.GetPensionDetailsResponse;
import com.suncorp.ssp.service.integration.accountservice.bean.PaymentIdentifier;
import com.suncorp.ssp.service.integration.accountservice.bean.PensionDrawdownDetail;
import com.suncorp.ssp.service.integration.accountservice.bean.PensionPaymentAmountDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.PensionPaymentInstruction;
import com.suncorp.ssp.service.integration.accountservice.bean.PensionPaymentSplitDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.PensionProtectionDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.ReferenceIdentifier;

/**
 * The class {@code GetPensionDetailsResponseUtil} is used as a util class for preparing GetPensionDetails service response.
 * 
 * @author U386868
 * @since 02/04/2016
 * @version 1.0
 */
public class GetPensionDetailsResponseUtil {
    private final String className = "GetPensionDetailsResponseUtil";
    private final String loggerType = AccountServiceConstants.GET_PENSION_DETAILS_LOGGING_FORMAT;
    private AccountServiceUtil accountServiceUtil = new AccountServiceUtil();
    private GetAccountDetailsResponseType inboundResponse;
    private GetPensionDetailsResponse outboundResponse;

    /**
     * Initializes class properties,viz., inbound and outbound response types.
     * 
     * @param inboundResponse
     */
    public GetPensionDetailsResponseUtil(GetAccountDetailsResponseType inboundResponse) {
        this.inboundResponse = inboundResponse;
        this.outboundResponse = new GetPensionDetailsResponse();
    }

    /**
     * create the outbound response, with necessary values set.
     * 
     * @return outboundResponse of type GetPensionDetailsResponse
     * @throws SILException
     */
    public GetPensionDetailsResponse createOutboundResponse() throws SILException {
        if (this.inboundResponse != null) {
            SILLogger.debug(loggerType, className, "Entering createOutboundResponse()");
            List<AccountDetails> accountDetailsListType = inboundResponse.getAccountDetails();
            List<AccountDetailsList> accountDetailsList = new ArrayList<AccountDetailsList>();
            if (accountDetailsListType != null && accountDetailsListType.size() > 0) {
                for (AccountDetails accountDetailsType : accountDetailsListType) {
                    this.createAccountDetailsList(accountDetailsList, accountDetailsType);
                }
                this.outboundResponse.setAccountDetailsList(accountDetailsList);
            }
        } else {
            throw new SILException(AccountServiceConstants.INVALID_RESPONSE_FROM_SONATA);
        }
        return this.outboundResponse;
    }

    /**
     * This method is used to create Account Details List, with necessary values set.
     * 
     * @param accountDetailsList of type List<AccountDetailsList>
     * @param accountDetailsType of type AccountDetails
     * @throws SILException
     */
    private void createAccountDetailsList(List<AccountDetailsList> accountDetailsList, AccountDetails accountDetailsType) throws SILException {
        SILLogger.debug(loggerType, className, "Entering in setAccountDetails");
        AccountDetailsList accountDetails = new AccountDetailsList();
        if (accountDetailsType != null) {
            this.retrievePensionDetails(accountDetailsType, accountDetails);
            accountDetails.setAccount(retrieveAccount(accountDetailsType.getAccount()));
            if (accountDetailsType.getAccountTaxDetail() != null) {
                accountDetails.setAccountTaxDetail(retrieveAccountTaxDetail(accountDetailsType.getAccountTaxDetail()));
            }
            accountDetailsList.add(accountDetails);
        }
    }

    /**
     * Does this.
     * 
     * @param accountDetailsType
     * @param accountDetails
     * @throws SILException
     */
    private void retrievePensionDetails(AccountDetails accountDetailsType, AccountDetailsList accountDetails) throws SILException {
        if (accountDetailsType.getPensionDrawdownDetail() != null) {
            accountDetails.setPensionDrawdownDetail(retrievePensionDrawdownDetails(accountDetailsType.getPensionDrawdownDetail()));
        }
        if (accountDetailsType.getPensionPaymentAmountDetail() != null) {
            accountDetails.setPensionPaymentAmountDetail(retrievePensionPaymentAmountDetails(accountDetailsType.getPensionPaymentAmountDetail()));
        }
        if (accountDetailsType.getPensionPaymentInstruction() != null) {
            accountDetails.setPensionPaymentInstruction(retrievePensionPaymentInstructionDetailsList(accountDetailsType
                    .getPensionPaymentInstruction()));
        }
        if (accountDetailsType.getPensionProtection() != null) {
            accountDetails.setPensionProtection(retrievePensionProtectionsDetailsList(accountDetailsType.getPensionProtection()));
        }
        if (accountDetailsType.getPensionPaymentSplit() != null) {
            accountDetails.setPensionPaymentSplit(retrievePensionPaymentSplitDetailsList(accountDetailsType.getPensionPaymentSplit()));
        }
    }

    /**
     * 
     * This method is used to retrieve Pension Payment Split Details List, with necessary values set.
     * 
     * @param paymentSplitTypeList of type List<PensionPaymentSplitType>
     * @return paymentSplitList of type List<PensionPaymentSplitDetails>
     * @throws SILException
     */
    public List<PensionPaymentSplitDetails> retrievePensionPaymentSplitDetailsList(List<PensionPaymentSplitType> paymentSplitTypeList)
            throws SILException {
        List<PensionPaymentSplitDetails> paymentSplitList = new ArrayList<PensionPaymentSplitDetails>();
        if (paymentSplitTypeList != null && paymentSplitTypeList.size() > 0) {
            for (PensionPaymentSplitType paymentSplitType : paymentSplitTypeList) {
                paymentSplitList.add(retrievePensionPaymentSplitDetails(paymentSplitType));
            }
        }
        return paymentSplitList;
    }

    /**
     * 
     * This method is used to retrieve Pension Payment Split Details, with necessary values set.
     * 
     * @param pensionPaymentSplitType of type PensionPaymentSplitType
     * @return pensionPaymentSplit of type PensionPaymentSplitDetails
     * @throws SILException
     */
    public PensionPaymentSplitDetails retrievePensionPaymentSplitDetails(PensionPaymentSplitType pensionPaymentSplitType) throws SILException {
        PensionPaymentSplitDetails pensionPaymentSplit = new PensionPaymentSplitDetails();
        if (pensionPaymentSplitType != null) {
            pensionPaymentSplit.setEffectiveDate(accountServiceUtil.retrieveDateValue(pensionPaymentSplitType.getEffectiveDate(), loggerType));
            pensionPaymentSplit.setId(accountServiceUtil.retrieveLongValue(pensionPaymentSplitType.getId(), loggerType));
            pensionPaymentSplit.setClient(accountServiceUtil.retrieveClientDetails(pensionPaymentSplitType.getClient(), loggerType));
            pensionPaymentSplit.setFixedAmount(accountServiceUtil.retrieveBooleanValue(pensionPaymentSplitType.isFixedAmount(), loggerType));
            pensionPaymentSplit.setDefaultPayee(accountServiceUtil.retrieveBooleanValue(pensionPaymentSplitType.isDefaultPayee(), loggerType));
            pensionPaymentSplit.setPaymentSplit(retrievePaymentIdentifierDetails(pensionPaymentSplitType.getPaymentSplit()));
            pensionPaymentSplit.setPaymentMethodCode(accountServiceUtil.retrieveCode(pensionPaymentSplitType.getPaymentMethodCode(), loggerType));
            pensionPaymentSplit.setBankAccountCardNumber(pensionPaymentSplitType.getBankAccountCardNumber());
            pensionPaymentSplit.setReinvestToAccount(retrieveFeeAccountDetails(pensionPaymentSplitType.getReinvestToAccount(), loggerType));
        }
        return pensionPaymentSplit;
    }

    /**
     * This method constructs the FeeAccount object from response, with necessary values set.
     * 
     * @param accountIdentifierType of type AccountIdentifierType
     * @param loggerType of type String
     * @return accountIdentifierDetails of type AccountIdentifierDetails
     * @throws SILException
     */
    public AccountIdentifierDetails retrieveFeeAccountDetails(AccountIdentifierType accountIdentifierType, String loggerType) throws SILException {
        AccountIdentifierDetails accountIdentifierDetails = new AccountIdentifierDetails();
        if (accountIdentifierType != null) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveFeeAccountDetails method");
            accountIdentifierDetails.setId(accountServiceUtil.retrieveLongValue(accountIdentifierType.getId(), loggerType));
            accountIdentifierDetails.setName(accountIdentifierType.getName());
            accountIdentifierDetails.setAccountNumber(accountServiceUtil.retrieveAccountNumberDetails(accountIdentifierType.getAccountNumber(),
                    loggerType));
            accountIdentifierDetails.setAccountRef(retrieveReferenceIdentifier(accountIdentifierType.getAccountExternalRef(), loggerType));
            accountIdentifierDetails.setStatusCode(accountServiceUtil.retrieveCode(accountIdentifierType.getStatusCode(), loggerType));
            accountIdentifierDetails.setAudit(accountServiceUtil.retrieveAudit(accountIdentifierType.getAudit(), loggerType));
            accountIdentifierDetails.setAccountPointer(accountServiceUtil.retrieveAccountPointerDetails(accountIdentifierType.getAccountPointer(),
                    loggerType));
            accountIdentifierDetails.setMasterScheme(accountServiceUtil.retrieveMasterSchemeDetails(accountIdentifierType.getMasterScheme(),
                    loggerType));
        } else {
            accountIdentifierDetails = retrieveEmptyFeeAccountDetails();
        }
        SILLogger.debug(loggerType, className, "Exiting in retrieveFeeAccountDetails method");
        return accountIdentifierDetails;
    }

    /**
     * This method constructs the Empty FeeAccount object from response.
     * 
     * @return accountIdentifierDetails of type AccountIdentifierDetails
     * @throws SILException
     */
    public AccountIdentifierDetails retrieveEmptyFeeAccountDetails() throws SILException {
        SILLogger.debug(loggerType, className, "Entering in retrieveEmptyFeeAccountDetails method");
        AccountIdentifierDetails accountIdentifierDetails = new AccountIdentifierDetails();
        accountIdentifierDetails.setId(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        accountIdentifierDetails.setName(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        accountIdentifierDetails.setAccountNumber(accountServiceUtil.retrieveEmptyAccountNumberDetails(loggerType));
        accountIdentifierDetails.setAccountRef(retrieveEmptyReferenceIdentifier());
        accountIdentifierDetails.setStatusCode(accountServiceUtil.retrieveEmptyCode(loggerType));
        accountIdentifierDetails.setAudit(accountServiceUtil.retrieveEmptyAudit(loggerType));
        accountIdentifierDetails.setAccountPointer(accountServiceUtil.retrieveEmptyAccountPointer(loggerType));
        accountIdentifierDetails.setMasterScheme(accountServiceUtil.retrieveEmptyMasterSchemeDetails(loggerType));
        return accountIdentifierDetails;
    }

    /**
     * This method constructs ReferenceIdentifier object from the response.
     * 
     * @param externalRefType of type ExternalRefType
     * @param loggerType of type String
     * @return referenceIdentifier of type ReferenceIdentifier
     * @throws SILException
     */
    public ReferenceIdentifier retrieveReferenceIdentifier(ExternalRefType externalRefType, String loggerType) throws SILException {
        ReferenceIdentifier referenceIdentifier = new ReferenceIdentifier();
        if (externalRefType != null) {
            SILLogger.debug(loggerType, className, "Entering in retrieveReferenceIdentifier method");
            referenceIdentifier.setReference(externalRefType.getReference());
            referenceIdentifier.setReferenceCode(externalRefType.getReferenceCode());
        } else {
            referenceIdentifier = retrieveEmptyReferenceIdentifier();
        }
        return referenceIdentifier;
    }

    /**
     * This method constructs Empty ReferenceIdentifier object.
     * 
     * @return referenceIdentifier of type ReferenceIdentifier
     * @throws SILException
     */
    public ReferenceIdentifier retrieveEmptyReferenceIdentifier() throws SILException {
        SILLogger.debug(loggerType, className, "Entering in retrieveEmptyReferenceIdentifier method");
        ReferenceIdentifier referenceIdentifier = new ReferenceIdentifier();
        referenceIdentifier.setReference(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        referenceIdentifier.setReferenceCode(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        return referenceIdentifier;
    }

    /**
     * 
     * This method is used to retrieve Payment Identifier Details, with necessary values set.
     * 
     * @param paymentSplitType of type PaymentSplit
     * @return paymentIdentifier of type PaymentIdentifier
     * @throws SILException
     */
    public PaymentIdentifier retrievePaymentIdentifierDetails(PaymentSplit paymentSplitType) throws SILException {
        SILLogger.debug(loggerType, className, "Entering in retrievePaymentIdentifierDetails method");
        PaymentIdentifier paymentIdentifier = new PaymentIdentifier();
        if (paymentSplitType != null) {
            paymentIdentifier.setAmount(accountServiceUtil.retrieveBigDecimalValue(paymentSplitType.getAmount(), loggerType));
            paymentIdentifier.setPercentage(accountServiceUtil.retrieveBigDecimalValue(paymentSplitType.getPercentage(), loggerType));
        }
        return paymentIdentifier;
    }

    /**
     * 
     * This method is used to retrieve Pension Protection Detail List, with necessary values set.
     * 
     * @param acctPensionProtectionDetailTypeList of type List<AcctPensionProtectionDetailType>
     * @return pensionProtectionBeanList of type List<PensionProtectionDetails>
     * @throws SILException
     */
    public List<PensionProtectionDetails> retrievePensionProtectionsDetailsList(
            List<AcctPensionProtectionDetailType> acctPensionProtectionDetailTypeList) throws SILException {
        SILLogger.debug(loggerType, className, "Entering in retrievePensionProtectionsDetailsList method");
        List<PensionProtectionDetails> pensionProtectionBeanList = new ArrayList<PensionProtectionDetails>();
        if (acctPensionProtectionDetailTypeList != null && acctPensionProtectionDetailTypeList.size() > 0) {
            for (AcctPensionProtectionDetailType acctPensionProtectionDetailType : acctPensionProtectionDetailTypeList) {
                pensionProtectionBeanList.add(retrievePensionProtectionsDetails(acctPensionProtectionDetailType));
            }
        }
        return pensionProtectionBeanList;
    }

    /**
     * 
     * This method is used to retrieve Pension Protection Details, with necessary values set.
     * 
     * @param acctPensionProtectionDetailType of type AcctPensionProtectionDetailType
     * @return pensionProtection of type PensionProtectionDetails
     * @throws SILException
     */
    public PensionProtectionDetails retrievePensionProtectionsDetails(AcctPensionProtectionDetailType acctPensionProtectionDetailType)
            throws SILException {
        SILLogger.debug(loggerType, className, "Entering in retrievePensionProtectionsDetails method");
        PensionProtectionDetails pensionProtection = new PensionProtectionDetails();
        if (acctPensionProtectionDetailType != null) {
            pensionProtection.setClient(accountServiceUtil.retrieveClientDetails(acctPensionProtectionDetailType.getClient(), loggerType));
            pensionProtection.setProtectionType(accountServiceUtil.retrieveOutlet(acctPensionProtectionDetailType.getProtectionType(), loggerType));
            pensionProtection.setPltaValue(accountServiceUtil.retrieveBigDecimalValue(acctPensionProtectionDetailType.getPltaValue(), loggerType));
            pensionProtection.setPltaFactor(accountServiceUtil.retrieveBigDecimalValue(acctPensionProtectionDetailType.getPltaFactor(), loggerType));
            pensionProtection.setPpclValueAmount(accountServiceUtil.retrieveBigDecimalValue(acctPensionProtectionDetailType.getPpclValueAmount(),
                    loggerType));
            pensionProtection.setPpclValuePercent(accountServiceUtil.retrieveBigDecimalValue(acctPensionProtectionDetailType.getPpclValuePercent(),
                    loggerType));
            pensionProtection.setCertificationNumber(acctPensionProtectionDetailType.getCertificationNumber());
            pensionProtection.setEffectiveDate(accountServiceUtil.retrieveDateValue(acctPensionProtectionDetailType.getEffectiveDate(), loggerType));
            pensionProtection.setEndDate(accountServiceUtil.retrieveObjectValue(acctPensionProtectionDetailType.getEndDate(), loggerType));
            pensionProtection.setStatusCode(accountServiceUtil.retrieveCode(acctPensionProtectionDetailType.getStatusCode(), loggerType));
        }
        return pensionProtection;
    }

    /**
     * 
     * This method is used to retrieve Pension Payment Instruction Details List, with necessary values set.
     * 
     * @param pensionPaymentInstructionTypeList of type List<PensionPaymentInstructionType>
     * @return paymentInstructionList of type List<PensionPaymentInstruction>
     * @throws SILException
     */
    public List<PensionPaymentInstruction> retrievePensionPaymentInstructionDetailsList(
            List<PensionPaymentInstructionType> pensionPaymentInstructionTypeList) throws SILException {
        SILLogger.debug(loggerType, className, "Entering in retrievePensionPaymentInstructionDetailsList method");
        List<PensionPaymentInstruction> paymentInstructionList = new ArrayList<PensionPaymentInstruction>();
        if (pensionPaymentInstructionTypeList != null && pensionPaymentInstructionTypeList.size() > 0) {
            for (PensionPaymentInstructionType pensionPaymentInstructionType : pensionPaymentInstructionTypeList) {
                paymentInstructionList.add(retrievePensionPaymentInstructionDetails(pensionPaymentInstructionType));
            }
        }
        return paymentInstructionList;
    }

    /**
     * 
     * This method is used to retrieve Pension Payment Instruction Details, with necessary values set.
     * 
     * @param paymentInstructionType of type PensionPaymentInstructionType
     * @return paymentInstruction of type PensionPaymentInstruction
     * @throws SILException
     */
    public PensionPaymentInstruction retrievePensionPaymentInstructionDetails(PensionPaymentInstructionType paymentInstructionType)
            throws SILException {
        SILLogger.debug(loggerType, className, "Entering in retrievePensionPaymentInstructionDetails method");
        PensionPaymentInstruction paymentInstruction = new PensionPaymentInstruction();
        if (paymentInstructionType != null) {
            paymentInstruction.setId(accountServiceUtil.retrieveLongValue(paymentInstructionType.getId(), loggerType));
            paymentInstruction.setNextReviewDate(accountServiceUtil.retrieveDateValue(paymentInstructionType.getNextReviewDate(), loggerType));
            paymentInstruction.setPaymentFrequency(accountServiceUtil.retrieveFrequencyIdentifier(paymentInstructionType.getPaymentFrequency(),
                    loggerType));
            paymentInstruction.setReviewType(accountServiceUtil.retrieveCode(paymentInstructionType.getReviewType(), loggerType));
            paymentInstruction.setAnnualNominatedAmount(accountServiceUtil.retrieveBigDecimalValue(paymentInstructionType.getAnnualNominatedAmount(),
                    loggerType));
            paymentInstruction.setAnnualNominatedPercent(accountServiceUtil.retrieveBigDecimalValue(
                    paymentInstructionType.getAnnualNominatedPercent(), loggerType));
            paymentInstruction.setUsed(accountServiceUtil.retrieveBooleanValue(paymentInstructionType.isUsed(), loggerType));
        }
        return paymentInstruction;
    }

    /**
     * This method is used to retrieve Pension Payment Amount Details, with necessary values set.
     * 
     * @param paymentAmountDetailType of type PensionPaymentAmountDetailType
     * @return paymentAmountDetail of type PensionPaymentAmountDetails
     * @throws SILException
     */
    public PensionPaymentAmountDetails retrievePensionPaymentAmountDetails(PensionPaymentAmountDetailType paymentAmountDetailType)
            throws SILException {
        SILLogger.debug(loggerType, className, "Entering in retrievepensionPaymentAmountDetails method");
        PensionPaymentAmountDetails paymentAmountDetail = new PensionPaymentAmountDetails();
        if (paymentAmountDetailType != null) {
            getPensionPaymentAmtDetailsFirstPart(paymentAmountDetailType, paymentAmountDetail);
            getPensionPaymentAmtDetailsSecondPart(paymentAmountDetailType, paymentAmountDetail);
            getPensionPaymentAmtDetailsThirdPart(paymentAmountDetailType, paymentAmountDetail);
        }
        return paymentAmountDetail;
    }

    /**
     * This method is used to retrieve Pension Payment Amount Details, with necessary values set.
     * 
     * @param paymentAmountDetailType of type PensionPaymentAmountDetailType
     * @param paymentAmountDetail of type PensionPaymentAmountDetails
     * @throws SILException
     */
    private void getPensionPaymentAmtDetailsSecondPart(PensionPaymentAmountDetailType paymentAmountDetailType,
            PensionPaymentAmountDetails paymentAmountDetail) throws SILException {
        paymentAmountDetail.setPaymentDate1(accountServiceUtil.retrieveBigIntegerValue(paymentAmountDetailType.getPaymentDate1(), loggerType));
        paymentAmountDetail.setPaymentDate2(accountServiceUtil.retrieveBigIntegerValue(paymentAmountDetailType.getPaymentDate2(), loggerType));
        paymentAmountDetail.setNextPaymentDue(accountServiceUtil.retrieveDateValue(paymentAmountDetailType.getNextPaymentDue(), loggerType));
        paymentAmountDetail.setNominatedIndexRate(accountServiceUtil.retrieveBigDecimalValue(paymentAmountDetailType.getNominatedIndexRate(),
                loggerType));
        paymentAmountDetail.setAdditionalTax(accountServiceUtil.retrieveBigDecimalValue(paymentAmountDetailType.getAdditionalTax(), loggerType));
        paymentAmountDetail.setNextReviewDate(accountServiceUtil.retrieveDateValue(paymentAmountDetailType.getNextReviewDate(), loggerType));
        paymentAmountDetail.setTaxFreeProportion(accountServiceUtil.retrieveBigDecimalValue(paymentAmountDetailType.getTaxFreeProportion(),
                loggerType));
        paymentAmountDetail.setAnnualNominatedPercent(accountServiceUtil.retrieveBigDecimalValue(paymentAmountDetailType.getAnnualNominatedPercent(),
                loggerType));
        paymentAmountDetail.setClaimRebate(accountServiceUtil.retrieveBooleanValue(paymentAmountDetailType.isClaimRebate(), loggerType));
        paymentAmountDetail.setClaimDeductible(accountServiceUtil.retrieveBooleanValue(paymentAmountDetailType.isClaimDeductible(), loggerType));
        paymentAmountDetail.setCarryForwardDeductible(accountServiceUtil.retrieveBooleanValue(paymentAmountDetailType.isCarryForwardDeductible(),
                loggerType));
        paymentAmountDetail.setTtr(accountServiceUtil.retrieveBooleanValue(paymentAmountDetailType.isTtr(), loggerType));
    }

    /**
     * This method is used to retrieve Pension Payment Amount Details, with necessary values set.
     * 
     * @param paymentAmountDetailType of type PensionPaymentAmountDetailType
     * @param paymentAmountDetail of type PensionPaymentAmountDetails
     * @throws SILException
     */
    private void getPensionPaymentAmtDetailsFirstPart(PensionPaymentAmountDetailType paymentAmountDetailType,
            PensionPaymentAmountDetails paymentAmountDetail) throws SILException {
        paymentAmountDetail.setEffectiveDate(accountServiceUtil.retrieveDateValue(paymentAmountDetailType.getEffectiveDate(), loggerType));
        paymentAmountDetail.setPensionStatus(accountServiceUtil.retrieveCode(paymentAmountDetailType.getPensionStatus(), loggerType));
        paymentAmountDetail.setPaymentFrequency(accountServiceUtil.retrieveFrequencyIdentifier(paymentAmountDetailType.getPaymentFrequency(),
                loggerType));
        paymentAmountDetail.setNumberOfPayments(accountServiceUtil.retrieveLongValue(paymentAmountDetailType.getNumberOfPayments(), loggerType));
        paymentAmountDetail.setPensionPaymentRule(accountServiceUtil.retrieveCode(paymentAmountDetailType.getPensionPaymentRule(), loggerType));
        paymentAmountDetail.setReviewType(accountServiceUtil.retrieveCode(paymentAmountDetailType.getReviewType(), loggerType));
        paymentAmountDetail.setReviewFrequency(accountServiceUtil.retrieveFrequencyIdentifier(paymentAmountDetailType.getReviewFrequency(),
                loggerType));
        paymentAmountDetail.setTaxOverridePercent(accountServiceUtil.retrieveBigDecimalValue(paymentAmountDetailType.getTaxOverridePercent(),
                loggerType));
        paymentAmountDetail.setTaxFreeMethod(accountServiceUtil.retrieveCode(paymentAmountDetailType.getTaxFreeMethod(), loggerType));
        paymentAmountDetail.setRevAnnuitantRelationship(accountServiceUtil.retrieveCode(paymentAmountDetailType.getRevAnnuitantRelationship(),
                loggerType));
        paymentAmountDetail.setPensionStartDate(accountServiceUtil.retrieveDateValue(paymentAmountDetailType.getPensionStartDate(), loggerType));
    }

    /**
     * This method is used to retrieve Pension Payment Amount Details, with necessary values set.
     * 
     * @param paymentAmountDetailType of type PensionPaymentAmountDetailType
     * @param paymentAmountDetail of type PensionPaymentAmountDetails
     * @throws SILException
     */
    private void getPensionPaymentAmtDetailsThirdPart(PensionPaymentAmountDetailType paymentAmountDetailType,
            PensionPaymentAmountDetails paymentAmountDetail) throws SILException {
        paymentAmountDetail.setAnnualPension(accountServiceUtil.retrieveBigDecimalValue(paymentAmountDetailType.getAnnualPension(), loggerType));
        paymentAmountDetail.setRegularPension(accountServiceUtil.retrieveBigDecimalValue(paymentAmountDetailType.getRegularPension(), loggerType));
        paymentAmountDetail.setPurchasePrice(accountServiceUtil.retrieveBigDecimalValue(paymentAmountDetailType.getPurchasePrice(), loggerType));
        paymentAmountDetail.setMinimumAnnualPension(accountServiceUtil.retrieveBigDecimalValue(paymentAmountDetailType.getMinimumAnnualPension(),
                loggerType));
        paymentAmountDetail.setMaximumAnnualPension(accountServiceUtil.retrieveBigDecimalValue(paymentAmountDetailType.getMaximumAnnualPension(),
                loggerType));
        paymentAmountDetail.setGrossAnnualisedIncome(accountServiceUtil.retrieveBigDecimalValue(paymentAmountDetailType.getGrossAnnualisedIncome(),
                loggerType));
        paymentAmountDetail.setYtdGrossPaidAmount(accountServiceUtil.retrieveBigDecimalValue(paymentAmountDetailType.getYtdGrossPaidAmount(),
                loggerType));
        paymentAmountDetail
                .setYtdNetPaidAmount(accountServiceUtil.retrieveBigDecimalValue(paymentAmountDetailType.getYtdNetPaidAmount(), loggerType));
        paymentAmountDetail.setSetAmount(accountServiceUtil.retrieveBigDecimalValue(paymentAmountDetailType.getSetAmount(), loggerType));
        paymentAmountDetail.setRemainingTerm(accountServiceUtil.retrieveBigIntegerValue(paymentAmountDetailType.getRemainingTerm(), loggerType));
        paymentAmountDetail
                .setNewMinimumAmount(accountServiceUtil.retrieveBigDecimalValue(paymentAmountDetailType.getNewMinimumAmount(), loggerType));
        paymentAmountDetail
                .setNewMaximumAmount(accountServiceUtil.retrieveBigDecimalValue(paymentAmountDetailType.getNewMaximumAmount(), loggerType));
        paymentAmountDetail.setDepositBalance(accountServiceUtil.retrieveBigDecimalValue(paymentAmountDetailType.getDepositBalance(), loggerType));
    }

    /**
     * 
     * This method is used to retrieve Pension Draw-down Details, with necessary values set.
     * 
     * @param drawdownDetailType of type PensionDrawdownDetailType
     * @return drawdownDetail of type PensionDrawdownDetail
     * @throws SILException
     */
    public PensionDrawdownDetail retrievePensionDrawdownDetails(PensionDrawdownDetailType drawdownDetailType) throws SILException {
        SILLogger.debug(loggerType, className, "Entering in retrievePensionDrawdownDetails method");
        PensionDrawdownDetail drawdownDetail = new PensionDrawdownDetail();
        if (drawdownDetailType != null) {
            drawdownDetail.setAccountLTA(accountServiceUtil.retrieveBigDecimalValue(drawdownDetailType.getAccountLTA(), loggerType));
            drawdownDetail.setTotalLTA(accountServiceUtil.retrieveBigDecimalValue(drawdownDetailType.getTotalLTA(), loggerType));
        }
        return drawdownDetail;
    }

    /**
     * 
     * This method is used to retrieve Account Tax Detail, with necessary values set.
     * 
     * @param accountTaxType of type AccountTaxType
     * @return accountTaxDetail of type AccountTaxDetails
     * @throws SILException
     */
    private AccountTaxDetails retrieveAccountTaxDetail(AccountTaxType accountTaxType) throws SILException {
        SILLogger.debug(loggerType, className, "Entering in retrieveAccountDetail method");
        AccountTaxDetails accountTaxDetail = new AccountTaxDetails();
        if (accountTaxType != null) {
            accountTaxDetail.setTaxScale(accountServiceUtil.retrieveCode(accountTaxType.getTaxScale(), loggerType));
            accountTaxDetail.setIncludeInvalidity(accountServiceUtil.retrieveBooleanValue(accountTaxType.isIncludeInvalidity(), loggerType));
            accountTaxDetail.setRebatableProportion(accountServiceUtil.retrieveBigDecimalValue(accountTaxType.getRebatableProportion(), loggerType));
            accountTaxDetail.setTaxOffsetAmount(accountServiceUtil.retrieveBigDecimalValue(accountTaxType.getTaxOffsetAmount(), loggerType));
            accountTaxDetail.setDeductMedicareSurcharge(accountServiceUtil.retrieveBooleanValue(accountTaxType.isDeductMedicareSurcharge(),
                    loggerType));
            accountTaxDetail.setMedicareLevyReduction(accountServiceUtil.retrieveBooleanValue(accountTaxType.isMedicareLevyReduction(), loggerType));
            accountTaxDetail.setDependantSpouse(accountServiceUtil.retrieveBooleanValue(accountTaxType.isDependantSpouse(), loggerType));
            accountTaxDetail.setNumberOfDependantChildren(accountServiceUtil.retrieveLongValue(accountTaxType.getNumberOfDependantChildren(),
                    loggerType));
        }
        return accountTaxDetail;

    }

    /**
     * This method constructs the Account object from response.
     * 
     * @param accountIdentifierType of type AccountIdentifierType
     * @return accountDetails of type com.suncorp.ssp.service.integration.accountservice.bean.AccountDetails
     * @throws SILException
     */
    private com.suncorp.ssp.service.integration.accountservice.bean.AccountDetails retrieveAccount(AccountIdentifierType accountIdentifierType)
            throws SILException {
        SILLogger.debug(loggerType, className, "Entering in retrieveAccount method");
        com.suncorp.ssp.service.integration.accountservice.bean.AccountDetails accountDetails =
                new com.suncorp.ssp.service.integration.accountservice.bean.AccountDetails();
        if (accountIdentifierType != null) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className, "Entering in retrieveAccount method");
            accountDetails.setId(accountServiceUtil.retrieveLongValue(accountIdentifierType.getId(), loggerType));
            accountDetails.setName(accountIdentifierType.getName());
            accountDetails.setAccountNumber(accountServiceUtil.retrieveAccountNumberDetails(accountIdentifierType.getAccountNumber(), loggerType));
            accountDetails.setAccountExternalRef(accountServiceUtil.retrieveExternalRef(accountIdentifierType.getAccountExternalRef(), loggerType));
            accountDetails.setStatusCode(accountServiceUtil.retrieveCode(accountIdentifierType.getStatusCode(), loggerType));
            accountDetails.setAudit(accountServiceUtil.retrieveAudit(accountIdentifierType.getAudit(), loggerType));
            accountDetails.setAccountPointer(accountServiceUtil.retrieveAccountPointerDetails(accountIdentifierType.getAccountPointer(), loggerType));
            accountDetails.setMasterScheme(accountServiceUtil.retrieveMasterSchemeDetails(accountIdentifierType.getMasterScheme(), loggerType));
        } else {
            accountDetails = retrieveEmptyAccount();
        }
        return accountDetails;
    }

    /**
     * This method constructs Empty AccountDetails object.
     * 
     * @return accountDetails of type com.suncorp.ssp.service.integration.accountservice.bean.AccountDetails
     */
    private com.suncorp.ssp.service.integration.accountservice.bean.AccountDetails retrieveEmptyAccount() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className, "Entering in retrieveEmptyAccount method");
        com.suncorp.ssp.service.integration.accountservice.bean.AccountDetails accountDetails =
                new com.suncorp.ssp.service.integration.accountservice.bean.AccountDetails();
        accountDetails.setId(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        accountDetails.setName(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        accountDetails.setAccountNumber(accountServiceUtil.retrieveEmptyAccountNumberDetails(loggerType));
        accountDetails.setAccountExternalRef(accountServiceUtil.retrieveEmptyExternalRef(loggerType));
        accountDetails.setStatusCode(accountServiceUtil.retrieveEmptyCode(loggerType));
        accountDetails.setAudit(accountServiceUtil.retrieveEmptyAudit(loggerType));
        accountDetails.setAccountPointer(accountServiceUtil.retrieveEmptyAccountPointer(loggerType));
        accountDetails.setMasterScheme(accountServiceUtil.retrieveEmptyMasterSchemeDetails(loggerType));
        SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className, "Exiting in retrieveEmptyAccount method");
        return accountDetails;
    }
}
