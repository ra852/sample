////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * The class {@code SaveAccountSchemeCategoryRequest} does this.
 * 
 * @author u385424
 * @since 20/09/2016
 * @version 1.0
 */
@XmlRootElement(name = "SaveAccountSchemeCategoryRequest")
public class SaveAccountSchemeCategoryRequest {
    private AccountDetails account;
    private SchemeCategoryBean schemeCategory;

    /**
     * Accessor for property account.
     * 
     * @return account of type AccountDetails
     */
    public AccountDetails getAccount() {
        return account;
    }

    /**
     * Mutator for property account.
     * 
     * @param account of type AccountDetails
     */
    @XmlElement(name = "account")
    public void setAccount(AccountDetails account) {
        this.account = account;
    }

    /**
     * Accessor for property schemeCategory.
     * 
     * @return schemeCategory of type SchemeCategoryBean
     */
    public SchemeCategoryBean getSchemeCategory() {
        return schemeCategory;
    }

    /**
     * Mutator for property schemeCategory.
     * 
     * @param schemeCategory of type SchemeCategoryBean
     */
    @XmlElement(name = "schemeCategory")
    public void setSchemeCategory(SchemeCategoryBean schemeCategory) {
        this.schemeCategory = schemeCategory;
    }
}
