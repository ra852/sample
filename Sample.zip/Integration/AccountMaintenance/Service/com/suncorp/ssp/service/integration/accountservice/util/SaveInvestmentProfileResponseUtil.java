////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import com.sonatacentral.service.v30.wrap.account.SaveInvestmentProfileResponseType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.SaveInvestmentProfileResponse;

/**
 * The class {@code SaveInvestmentProfileResponseUtil} construct's SOAP request for external service.
 * 
 * @author U387938
 * @since 20/03/2016
 * @version 1.0
 */
public class SaveInvestmentProfileResponseUtil {
    private final String className = "SaveInvestmentProfileResponseUtil";
    private SaveInvestmentProfileResponseType saveInvestmentProfileResponseType;

    /**
     * Does this.
     * 
     * @param saveInvestmentProfileResponseType
     */
    public SaveInvestmentProfileResponseUtil(SaveInvestmentProfileResponseType saveInvestmentProfileResponseType) {
        this.saveInvestmentProfileResponseType = saveInvestmentProfileResponseType;
    }

    /**
     * 
     * This method constructs SaveInvestmentProfileResponse object from response.
     * 
     * @param saveInvestmentProfileResponse
     * @throws SILException
     */
    public void setSaveInvestmentProfileResponse(SaveInvestmentProfileResponse saveInvestmentProfileResponse) throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_RESTRUCTURE_LOGGING_FORMAT, className, 
                "Entering setSaveInvestmentProfileResponse");

        if (saveInvestmentProfileResponseType != null) {
            saveInvestmentProfileResponse.setResponse(AccountServiceConstants.SAVE_INVESTMENT_PROFILE_SUCCESS_MSG);
        } else {

            throw new SILException(AccountServiceConstants.INVALID_RESPONSE_FROM_SONATA);
        }
    }

}
