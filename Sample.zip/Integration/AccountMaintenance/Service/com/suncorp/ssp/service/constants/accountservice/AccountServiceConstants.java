////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.constants.accountservice;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * The class {@code GetBeneficiaryConstants} does this.
 * 
 * @author u384380
 * @since 28/10/2015
 * @version 1.0
 */
public abstract class AccountServiceConstants {
    // Account service constants
    public static final String OPERATION_NAMESPACE = "http://www.sonatacentral.com/service/v30/wrap/account";
    public static final String DATE_TIME_FORMAT = "dd/MM/yyyy";
    public static final String REGULAR_EXPRESSION = "\\d+";
    public static final String ACCOUNT_NO = "accountNumber";
    public static final String INVALID_RESPONSE_FROM_SONATA = "Invalid Response from Sonata ";
    public static final String SEVERITY_ERROR = "ERROR";
    public static final String SEVERITY_DEBUG = "DEBUG";
    public static final String SEVERITY_FATAL = "FATAL";
    public static final String SEVERITY_INFO = "INFO";
    public static final String ACCOUNT_NUMBER = "accountNumber";
    public static final String INVALID_REQUEST_MESSAGE = "Invalid Request.Please provide accountNumber as a query parameter.";
    public static final String TRUE = "TRUE";

    // Get beneficiary constants
    public static final String GET_BENEFICIARY_LOGGING_FORMAT = "AccountService_GetBeneficiary_{}_".concat(
            new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat("_{}");
    public static final String GET_BENEFICIARY_OPERATION_NAME = "getAccountBeneficiary";
    public static final String RESPONSE_CLASS_NAME = "com.suncorp.ssp.service.integration.accountservice.bean.GetBeneficiaryResponse";
    public static final String BENEFICIARY_TYPE = "BENE";
    public static final String NO_OF_BENEFICIARY = "NoOfBeneficiary";
    public static final String INVALID_ACCOUNT_NUMBER_MESSAGE = "Invalid account number, please provide valid account number.";
    public static final String GET_BENEFICIARY_GENERIC_MSG = "Get Beneficiary functionality could not get processed";

    // Search Account constants
    public static final String SRCH_ACCNT_OP_NAME = "searchAccount";
    public static final String SRCH_ACCNT_LOGGING_FORMAT = "AccountService_SearchAccount_{}_".concat(
            new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat("_{}");
    public static final String SEARCH_ACCNT_RESPONSE_CLASS_NAME = "com.suncorp.ssp.service.integration.accountservice.bean.SearchAccountResponse";
    public static final String SRCH_ACCNT_INV_REQ_MSG = "INVALID_REQUEST_MESSAGE";
    public static final String SEARCH_ACCOUNT_OWNER_CODE = "OWNR";
    public static final String SEARCH_ACCOUNT_ADVISOR_NUMBER = "advisorNumber";
    public static final String SEARCH_ACCOUNT_ADVISOR_CLIENT_ID = "advisorClientId";
    public static final String SEARCH_ACCOUNT_ADVISOR_FORENAME = "advisorForename";
    public static final String SEARCH_ACCOUNT_ADVISOR_SURNAME = "advisorSurname";
    public static final String SEARCH_ACCOUNT_MEMBER_CLIENT_ID = "memberClientId";
    public static final String SEARCH_ACCOUNT_MEMBER_FORENAME = "memberForename";
    public static final String SEARCH_ACCOUNT_MEMBER_SURNAME = "memberSurname";
    public static final String SEARCH_ACCOUNT_MEMBER_DATE_OF_BIRTH = "memberDateOfBirth";
    public static final String SEARCH_ACCOUNT_PRODUCT_ID = "productId";
    public static final String SEARCH_ACCOUNT_PRODUCT_NAME = "productName";
    public static final String SEARCH_ACCOUNT_FIRST_RESULT = "firstResult";
    public static final String SEARCH_ACCOUNT_RESULTS_PER_PAGE = "resultsPerPage";
    public static final String SEARCH_ACCOUNT_PERCENT_SYMBOL = "%";
    public static final String SEARCH_ACCOUNT_INVALID_REQUEST_MESSAGE = "Invalid Request.Please provide Client Id as a query parameter.";
    public static final String SEARCH_ACCOUNT_INVALID_ADVISOR_CLIENT_ID_MESSAGE = "Invalid Client Id, please provide valid Client Id.";
    public static final String SEARCH_ACCT_GENERIC_EXCEPTION_MSG = "ViewMemberList request can't be processed.";
    public static final String NO_RECORDS_FOUND = "No records were found with your given criteria.";
    public static final Object SEARCH_ACCOUNT_ACTIVE_STATUS_CODE_FLAG = "activeStatusFlag";
    public static final Object SEARCH_ACCOUNT_PENDING_STATUS_CODE_FLAG = "pendingStatusFlag";
    public static final String SEARCH_ACCOUNT_OWNER_RLSHP_FLAG = "ownerRelationshipFlag";

    // Save Account Beneficiary
    public static final String SAVE_ACCOUNT_BENEFICIARY_LOG_FORMAT = "AccountService_SaveAccountBeneficiary_{}_".concat(
            new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat("_{}");
    public static final String SAVE_ACCOUNT_BENEFICIARY_OPERATION_NAME = "saveAccountBeneficiary";
    public static final Object SAVE_ACCOUNT_BENEFICIARY_RESPONSE_CLASS_NAME =
            "com.suncorp.ssp.service.integration.accountservice.bean.SaveAccountBeneficiaryResponse";
    public static final String SAVE_ACCOUNT_BENEFICIARY_REQUEST_NOT_PROCESSED = "SaveAccountBeneficiary request could not be processed.";
    public static final String SAVE_ACCOUNT_BENEFICIARY_RESPONSE_NOT_PROCESSED = "SaveAccountBeneficiary response could not be processed.";
    public static final String SAVE_ACCOUNT_INVALID_ACCOUNT_MSG = "Invalid account number. Please provide valid account number.";
    public static final String SAVE_ACCOUNT_INVALID_BENEFICIARY_ID_MSG = "Invalid beneficiary id. Please provide valid beneficiary id.";
    public static final String SAVE_ACCOUNT_INVALID_STATUS_ID_MSG = "Invalid status id. Please provide valid status id.";
    public static final String SAVE_ACCOUNT_INVALID_CLIENT_ID_MSG = "Invalid client id. Please provide valid client id.";
    public static final String SAVE_ACCOUNT_INVALID_ALLOCATION_MSG = "Invalid allocation. Please provide valid allocation.";
    public static final String SAVE_BENEFICIARY_DELETEALL_REQUEST = "SAVE_BENEFICIARY_DELETEALL_REQUEST";
    public static final String SAVE_BENEFICIARY_DELETEALL_FLAG = "DeleteAllFLow";
    public static final String DELETEALL_ACCOUNT_BENEFICIARY_LOG_FORMAT = "AccountService_DeleteAllBeneficiary_{}_".concat(
            new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat("_{}");

    // GetAccountDetails constants
    public static final String GET_ACCOUNTDETAILS_LOGGING_FORMAT = "AccountService_GetAccountDetails_{}_".concat(
            new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat("_{}");
    public static final String GET_ACCOUNTDETAILS_RESPONSE_CLASS_NAME =
            "com.suncorp.ssp.service.integration.accountservice.bean.GetAccountDetailsResponse";
    public static final String GET_ACCOUNTDETAILS_OPERATION_NAME = "getAccountDetails";
    public static final String GET_ACCT_BPAY_CODE = "BPAY";
    public static final String GET_ACCOUNTDETAILS_NONE_BPAY_RESPONSE_MESSAGE = "This account number does not contain any BPAY data.";

    // Get Account Transaction Summary
    public static final String GET_ACC_TRANS_SUMM_LOGGING_FORMAT = "AccountService_Get_Account_Transaction_Summary_{}_".concat(
            new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat("_{}");
    public static final Object GET_ACC_TRANS_SUMM_RESPONSE_CLASS_NAME =
            "com.suncorp.ssp.service.integration.accountservice.bean.GetAccountTransactionSummaryResponse";
    public static final String GET_ACC_TRANS_SUMM_OPERATION_NAME = "getAccountTransactionSummary";
    public static final String START_DATE = "startDate";
    public static final String END_DATE = "endDate";
    public static final String INCLUDE_PRICED_ONLY = "includePricedOnly";
    public static final String SKIP_TRANSACTION_FUND_GROUPING = "skipTransactionFundGrouping";
    public static final String ACCOUNT_NAME = "accountName";
    public static final String EXTERNAL_REFERENCE = "externalReference";
    public static final String EXTERNAL_REFERENCE_CODE = "externalReferenceCode";
    public static final String TRAN_SUMMRY_EXCEPTION_MSG = "Get Account Transaction Summary functionality could not get processed.";

    // GetAccountTransactionList constants
    public static final String GET_ACCOUNT_TRANS_LIST_LOGGING_FORMAT = "AccountService_GetAccountTransactionList_{}_".concat(
            new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat("_{}");
    public static final String GET_ACCOUNT_TRANS_LIST_RESPONSE_CLASS_NAME =
            "com.suncorp.ssp.service.integration.accountservice.bean.GetAccountTransactionListResponseBean";
    public static final String GET_ACCOUNT_TRANS_LIST_OPERATION_NAME = "getAccountTransactionList";
    public static final String INCLUDE_UNPRICED_ONLY = "includeUnpricedOnly";
    public static final String INCLUDE_TERM_DEPOSIT_DETAILS = "includeTermDepositDetails";
    public static final String TRANSACTION_TYPE_CODE = "transTypeCode";
    public static final String CATEGORY_CODE = "categoryCode";
    public static final String CATEGORY_CODE_TYPE = "categoryCodeType";
    public static final String FIRST_RESULT = "firstResult";
    public static final String RESULT_PER_PAGE = "resultsPerPage";
    public static final String GET_ACC_TRANS_LIST_REQ_NOT_PROCESSED = "GetAccountTransactionList request could not be processed.";
    public static final String GET_ACC_TRANS_LIST_RES_NOT_PROCESSED = "GetAccountTransactionList response could not be processed.";
    public static final String GETACC_TRANS_LIST_RECORD_NOT_EXIST = "No transaction found for the given criteria";
    public static final String INVALID_REQUEST_MESSAGE_FOR_TRASACTION_LIST =
            "Invalid Request.Please provide accountNumber or accountExternalReference details as a query parameter.";
    public static final Object STATUS_CODE = "statusCode";
    public static final Object STATUS_CODE_TYPE = "statusCodeType";

    // Get Investment Balance constants
    public static final String GET_INVESTMENT_BAL_LOG_FORMAT = "AccountService_GetInvestmentBalance_{}_".concat(
            new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat("_{}");
    public static final String GET_INVESTMENT_BALANCE_RESPONSE_CLASS_NAME =
            "com.suncorp.ssp.service.integration.accountservice.bean.GetInvestmentBalanceResponseBean";
    public static final String GET_INVESTMENT_BALANCE_REQUEST_NOT_PROCESSED = "GetInvestmentBalance request could not be processed.";
    public static final String GET_INVESTMENT_BALANCE_RESPONSE_NOT_PROCESSED = "GetInvestmentBalance response could not be processed.";
    public static final String GET_INVESTMENT_BALANCE_INVALID_ACCOUNT_NO = "Invalid Request. Please provide accountNumber as a query parameter.";
    public static final String GET_INVESTMENT_BALANCE_INVALID_START_DATE = "Invalid Request. Please provide startDate as a query parameter.";
    public static final String GET_INVESTMENT_BAL_RECORD_NOT_EXIST = "No transactions found for the given account";

    // Get Account Expense
    public static final String GET_ACC_EXPENSE_LOGGING_FORMAT = "AccountService_GetAccountExpense_{}_".concat(
            new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat("_{}");
    public static final String GET_ACC_EXPENSE_RESPONSE_CLASS_NAME =
            "com.suncorp.ssp.service.integration.accountservice.bean.GetAccountExpenseResponse";
    public static final String GET_ACC_EXPENSE_OPERATION_NAME = "getAccountExpense";
    public static final String ADVISOR_PRODUCT_ID = "advisorClientId";
    public static final String INVALID_CLIENT_MESSAGE = "Invalid Request. Please provide advisorClientId as a query parameter.";
    public static final String PRODUCT_NAME = "productName";
    public static final String INVALID_PRODUCT_MESSAGE = "Invalid Request. Please provide productName as a query parameter.";
    public static final String MARKETING_CAMPAIGN_ID = "marketingCampaignId";
    public static final String INVALID_MKT_CAMPAIGN_ID_MESSAGE = "Invalid Request. Please provide marketingCampaignId as a query parameter.";
    public static final String SPACE_REG = "%20";
    public static final String GET_ACC_EXPENSE_GENERIC_MSG = "GetAccountExpense functionality could not get processed.";
    public static final String GET_ACC_EXPENSE_EMPTY_STRING = "";
    public static final String IS_ACCOUNT_NUMBER_REQUEST_TRUE = "true";
    public static final String IS_ACCOUNT_NUMBER_REQUEST_FALSE = "false";
    public static final String GET_EXPENSE_SERVICE_CHECK_PARAM = "serviceCheck";

    // Get Account Details List
    public static final String GET_ACC_DETAILS_LIST_LOGGING_FORMAT = "AccountService_GetAccountDetailsList_{}_".concat(
            new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat("_{}");
    public static final String GET_ACC_DETAILS_LIST_GENERIC_MSG = "GetAccountDetails functionality could not get processed.";
    public static final String INVALID_ACCOUNTNUMBER_MESSAGE = "Invalid Request. Please provide Account Number as a query parameter.";
    public static final String GET_ACC_DETAILS_RESPONSE_CLASS_NAME =
            "com.suncorp.ssp.service.integration.accountservice.bean.GetAccountDetailsResponse";
    public static final String GET_ACC_DETAILS_LIST_OPERATION_NAME = "getAccountDetails";
    public static final String SOURCE_SYSTEM_SNT = "SNT";

    public static final String GET_ACC_SERVICE_UTIL_LOGGING_FORMAT = "AccountService_AccountServiceUtil_{}_".concat(
            new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat("_{}");

    // Delete Third Party Relationship
    public static final String DEL_THIRD_PARTY_REL_LOG_FORMAT = "AccountService_DeleteThirdPartyRelationship_{}_".concat(
            new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat("_{}");
    public static final Object DEL_THIRD_PARTY_REL_RESPONSE_CLASS_NAME =
            "com.suncorp.ssp.service.integration.accountservice.bean.DeleteThirdPartyRelationshipResponse";
    public static final String DELETE_THIRD_PARTY_RELATIONSHIP_RESPONSE_NOT_PROCESSED =
            "DeleteThirdPartyRelationship response could not be processed.";
    public static final String DELETE_THIRD_PARTY_RELATIONSHIP_REQUEST_NOT_PROCESSED = "DeleteThirdPartyRelationship request could not be processed";
    public static final String DELETE_THIRD_PARTY_RELATIONSHIP_OPERATION_NAME = "saveAccount";

    // Save InvestmentRestructure
    public static final String SAVE_INVESTMENT_RESTRUCTURE_OPERATION_NAME = "saveInvestmentRestructure";
    public static final String SAVE_INVESTMENT_RESTRUCTURE_LOGGING_FORMAT = "AccountService_SaveInvestmentRestructure_{}_".concat(
            new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat("_{}");
    public static final String SAVE_INVESTMENT_RESTRUCTURE_RESPONSE_CLASS_NAME =
            "com.suncorp.ssp.service.integration.accountservice.bean.SaveInvestmentRestuctureResponse";
    public static final String SAVE_INVESTMENT_RESTRUCTURE_GENERIC_MSG = "SaveInvestmentRestucture functionality could not get processed.";
    public static final String SAVE_INVESTMENT_RESTRUCTURE_SUCCESS_MSG = "Successful";

    // Save Account Rebalance
    public static final String SAVE_ACCOUNT_LOGGING_FORMAT = "AccountService_SaveAccount_{}_".concat(
            new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat("_{}");
    public static final String SAVE_ACCOUNT_RESPONSE_CLASS_NAME = "com.suncorp.ssp.service.integration.accountservice.bean.SaveAccountResponse";
    public static final String SAVE_ACCOUNT_OPERATION_NAME = "saveAccount";
    public static final String SAVE_ACCOUNT_GENERIC_MSG = "SaveAccount functionality could not get processed.";

    // Get Pension Details Constants
    public static final String GET_PENSION_DETAILS_LOGGING_FORMAT = "AccountService_GetPensionDetails_{}_".concat(
            new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat("_{}");
    public static final String GET_PENSION_DETAILS_GENERIC_MSG = "GetPensionDetails functionality could not get processed.";
    public static final String GET_PENSION_DETAILS_RESPONSE_CLASS_NAME =
            "com.suncorp.ssp.service.integration.accountservice.bean.GetPensionDetailsResponse";
    public static final String GET_PENSION_DETAILS_OPERATION_NAME = "getPensionDetails";

    // Save regular contribution plang
    public static final String SAVE_REG_CONT_LOGGING_FORMAT = "AccountService_SaveRegularContributionPlan_{}_".concat(
            new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat("_{}");
    public static final String SAVE_REG_CONT_OPERATION_NAME = "saveRegularContributionPlan";
    public static final String SAVE_REG_CONT_GENERIC_MSG = "SaveRegularContributionPlan functionality could not get processed.";
    public static final String SAVE_REG_CONT_RESPONSE_CLASS_NAME =
            "com.suncorp.ssp.service.integration.accountservice.bean.SaveRegularContributionPlanResponseBean";
    public static final String SAVE_REG_CONT_RES_NULL = "SaveRegularContributionPlan's response is NULL.";

    // saveInvestmentProfile
    public static final String SAVE_INVESTMENT_PROFILE_LOGGING_FORMAT = "AccountService_SaveInvestmentProfile_{}_".concat(
            new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat("_{}");
    public static final String SAVE_INVESTMENT_PROFILE_GENERIC_MSG = "SaveInvesmentProfile functionality could not get processed.";
    public static final String SAVE_INVESTMENT_PROFILE_INVALID_REQUEST = "Invalid Request, please send required parameters";
    public static final String SAVE_INVESTMENT_PROFILE_RESPONSE_CLASS_NAME =
            "com.suncorp.ssp.service.integration.accountservice.bean.SaveInvestmentProfileResponse";
    public static final String SAVE_INVESTMENT_PROFILE_OPERATION_NAME = "saveInvestmentProfile";
    public static final String SAVE_INVESTMENT_PROFILE_SUCCESS_MSG = "Successful";

    // Get Switch Status
    public static final String GET_SWITCH_STATUS_RESPONSE_CLASS_NAME =
            "com.suncorp.ssp.service.integration.accountservice.bean.GetSwitchStatusResponseBean";

    public static final String GET_SWITCH_STATUS_LOGGING_FORMAT = "AccountService_GetAccountTransactionList_{}_".concat(
            new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat("_{}");
    public static final String GET_SWITCH_STATUS_OPERATION_NAME = "geSwitchStatus";
    public static final String GET_SWITCH_STATUS_REQ_NOT_PROCESSED = "GetSwitchStatus request could not be processed.";
    public static final String GET_SWITCH_STATUS_RES_NOT_PROCESSED = "GetSwitchStatus response could not be processed.";
    public static final String STATUS_CODE_PENDING = "PEND";
    public static final String STATUS_CODE_TRANSACTION = "TRST";
    public static final String STATUS_CODE_UNCAPPED = "UNCP";
    public static final String STATUS_CODE_UNCONFIRM = "UNCF";
    public static final String SWITCH = "SWIT";
    public static final String TECT = "TECT";
    public static final String SWIT_INCLUDE_UNPRICED_FLAG = "includeUnpricedOnlyFlag";
    public static final Object FILTER_REVERSE_TRANS_FLAG = "filterReverseTransFlag";
    public static final String GET_SWITCH_REVERSE_CODE = "REVS";

    // saveAccountExpense
    public static final String SAVE_ACCOUNT_EXPENSE_LOGGING_FORMAT = "AccountService_SaveAccountExpense_{}_".concat(
            new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat("_{}");
    public static final String SAVE_ACCOUNT_EXPENSE_GENERIC_MSG = "Save Account expense functionality could not get processed.";
    public static final String SAVE_ACCOUNT_EXPENSE_INVALID_REQUEST = "Invalid Request, please send required parameters";
    public static final String SAVE_ACCOUNT_EXPENSE_RESPONSE_CLASS_NAME =
            "com.suncorp.ssp.service.integration.accountservice.bean.SaveAccountExpenseResponse";
    public static final String SAVE_ACCOUNT_EXPENSE_OPERATION_NAME = "saveAccountExpense";
    public static final String SAVE_ACCOUNT_EXPENSE_SUCCESS_MSG = "Successful";

    // Get Account Employment
    public static final String GET_ACCOUNT_EMPLOYMENT_RESPONSE_CLASS_NAME =
            "com.suncorp.ssp.service.integration.accountservice.bean.GetAccountEmploymentResponseBean";

    public static final String GET_ACCOUNT_EMPLOYMENT_LOGGING_FORMAT = "AccountService_GetAccountEmployment_{}_".concat(
            new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat("_{}");
    public static final String GET_ACCOUNT_EMPLOYMENT_OPERATION_NAME = "getAccountEmployment";
    public static final String GET_ACCOUNT_EMPLOYMENT_REQ_NOT_PROCESSED = "GetAccountEmployment request could not be processed.";
    public static final String GET_ACCOUNT_EMPLOYMENT_RES_NOT_PROCESSED = "GetAccountEmployment response could not be processed.";
    public static final String GET_ACC_EMPLOYMENT_EMPTY_STRING = "";

    // updateAccountEmployment
    public static final String UPDATE_ACCOUNT_EMP_LOGGING_FORMAT = "AccountService_UpdateAccountEmployment_{}_".concat(
            new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat("_{}");
    public static final String UPDATE_ACCOUNT_EMP_GENERIC_MSG = "Update Account employment functionality could not get processed.";
    public static final String UPDATE_ACCOUNT_EMP_INVALID_REQUEST = "Invalid Request, please send required parameters";
    public static final String UPDATE_ACCOUNT_EMP_RESPONSE_CLASS_NAME =
            "com.suncorp.ssp.service.integration.accountservice.bean.UpdateAccountEmploymentResponse";
    public static final String UPDATE_ACCOUNT_EMP_OPERATION_NAME = "saveAccountEmployment";
    public static final String UPDATE_ACCOUNT_EMP_SUCCESS_MSG = "Successful";

    // SaveAccountSchemeCategory
    public static final String SAVE_ACCOUNT_SCHEME_CATEGORY_LOGGING_FORMAT = "AccountService_SaveAccountSchemeCategory_{}_".concat(
            new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat("_{}");
    public static final String SAVE_ACCOUNT_SCHEME_CATEGORY_GENERIC_MSG = "Save Account Scheme Category functionality could not get processed.";
    public static final String SAVE_ACCOUNT_SCHEME_CATEGORY_RESPONSE_CLASS_NAME =
            "com.suncorp.ssp.service.integration.accountservice.bean.SaveAccountSchemeCategoryResponse";
    public static final String SAVE_ACCOUNT_SCHEME_CATEGORY_OPERATION_NAME = "saveAccountSchemeCategory";
    public static final String SAVE_ACCOUNT_SCHEME_CATEGORY_SUCCESS_MSG = "Successful";

    // GetAccountUnitHoldings
    public static final String ACCOUNT_HOLDINGS_LOGGING_FORMAT = "AccountService_GetAccountUnitHoldings_{}_".concat(
            new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat("_{}");
    public static final String GET_ACCOUNT_UNIT_HOLDINGS_RESPONSE_CLASS_NAME =
            "com.suncorp.ssp.service.integration.accountservice.bean.GetAccountUnitHoldingsResponse";
    public static final String GET_ACCOUNT_UNIT_HOLDINGS_OPERATION_NAME = "getAccountUnitHoldingDetail";
    public static final String GET_ACCOUNT_UNIT_HOLDINGS_REQ_NOT_PROCESSED = "GetAccountUnitHoldings request could not be processed.";
    public static final String GET_ACCOUNT_UNIT_HOLDINGS_RES_NOT_PROCESSED = "GetAccountUnitHoldings response could not be processed.";
    public static final String EMPTY_VALUE = "";

    // GetFamilyLinkingDetails
    public static final String GET_FAMILY_LINKING_DETAILS_LOGGING_FORMAT = "AccountService_GetFamilyLinkingDetails_{}_".concat(
            new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat("_{}");
    public static final Object GET_FAMILY_LINKING_DETAILS_RESPONSE_CLASS_NAME =
            "com.suncorp.ssp.service.integration.accountservice.bean.GetFamilyLinkingDetailsResponse";
    public static final String GET_FAMILY_LINKING_DETAILS_GENERIC_MSG = "Get Family Linking Details functionality could not get processed";
    public static final String NO_RECORD_FOUND = "No Record found for given Advisor";
    
    // GetAccountContributions
    public static final String GET_ACCOUNT_CONTRIBUTIONS_LOGGING_FORMAT = "AccountService_GetAccountContributions_{}_".concat(
            new SimpleDateFormat("E, dd MMM yyyy HH:mm:ss z").format(new Date())).concat("_{}");
    public static final String GET_ACCOUNT_CONTRIBUTIONS_RESPONSE_CLASS_NAME =
            "com.suncorp.ssp.service.integration.accountservice.bean.GetAccountContributionsResponse";
    public static final String GET_ACCOUNT_CONTRIBUTIONS_GENERIC_MSG = "Get Account Contributions functionality could not get processed";
    public static final String CONTRIBUTION_PERIOD_FROM = "contributionPeriodFrom";
    public static final String CONTRIBUTION_PERIOD_TO = "contributionPeriodTo";
    public static final String INCLUDE_ALL_CONTRIBUTIONS_FLAG = "includeAllContributionsFlag";
    public static final String GET_ACCOUNT_CONTRIBUTIONS_OPERATION_NAME = "getAccountContributions";

}
