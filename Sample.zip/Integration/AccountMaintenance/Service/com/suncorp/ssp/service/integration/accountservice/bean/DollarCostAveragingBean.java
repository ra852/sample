////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;
/**
 * The class {@code DollarCostAveragingBean} does this.
 * 
 * @author U387938
 * @since 02/02/2016
 * @version 1.0
 */
public class DollarCostAveragingBean {

    private FrequencyIdentifierBean frequency;
    private String nextDueDate;
    private String switchAmount;
    private FundIdentifierDetails sourceFund;
    private CodeIdentifier instructorCategoryCode;
    /**
     * Accessor for property frequency.
     *
     * @return frequency of type FrequencyIdentifierBean
     */
    public FrequencyIdentifierBean getFrequency() {
        return frequency;
    }
    /**
     * Mutator for property frequency.
     *
     * @param frequency of type FrequencyIdentifierBean
     */
    @XmlElement(name = "frequency")
    public void setFrequency(FrequencyIdentifierBean frequency) {
        this.frequency = frequency;
    }
    /**
     * Accessor for property nextDueDate.
     *
     * @return nextDueDate of type String
     */
    public String getNextDueDate() {
        return nextDueDate;
    }
    /**
     * Mutator for property nextDueDate.
     *
     * @param nextDueDate of type String
     */
    @XmlElement(name = "nextDueDate")
    public void setNextDueDate(String nextDueDate) {
        this.nextDueDate = nextDueDate != null ? nextDueDate : "";
    }
    /**
     * Accessor for property switchAmount.
     *
     * @return switchAmount of type String
     */
    public String getSwitchAmount() {
        return switchAmount;
    }
    /**
     * Mutator for property switchAmount.
     *
     * @param switchAmount of type String
     */
    @XmlElement(name = "switchAmount")
    public void setSwitchAmount(String switchAmount) {
        this.switchAmount = switchAmount != null ? switchAmount : "";
    }
   
    /**
     * Accessor for property sourceFund.
     *
     * @return sourceFund of type FundIdentifierDetails
     */
    public FundIdentifierDetails getSourceFund() {
        return sourceFund;
    }
    /**
     * Mutator for property sourceFund.
     *
     * @param sourceFund of type FundIdentifierDetails
     */
    @XmlElement(name = "sourceFund")
    public void setSourceFund(FundIdentifierDetails sourceFund) {
        this.sourceFund = sourceFund;
    }
    /**
     * Accessor for property instructorCategoryCode.
     *
     * @return instructorCategoryCode of type CodeIdentifier
     */
    public CodeIdentifier getInstructorCategoryCode() {
        return instructorCategoryCode;
    }
    /**
     * Mutator for property instructorCategoryCode.
     *
     * @param instructorCategoryCode of type CodeIdentifier
     */
    @XmlElement(name = "instructorCategoryCode")
    public void setInstructorCategoryCode(CodeIdentifier instructorCategoryCode) {
        this.instructorCategoryCode = instructorCategoryCode;
    } 
    
    
}
