////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.BeneficiaryType;
import com.sonatacentral.service.v30.wrap.account.GetAccountBeneficiaryResponseType;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.constants.clientservice.ClientServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.BeneficiaryDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.ClientAccountRelationshipIdentifierBean;
import com.suncorp.ssp.service.integration.accountservice.bean.GetBeneficiaryResponse;

/**
 * The class {@code GetBeneficiaryDetailsUtil} is used as a util class for getting beneficiary details.
 * 
 * @author U383754
 * @since 19/11/2015
 * @version 1.0
 */
public class GetBeneficiaryDetailsUtil {
    private BeneficiaryType beneficiaryType;
    private int numberOfBeneficiary;
    private GetAccountBeneficiaryResponseType getAccountBeneficiaryResponseType;

    /**
     * 
     * Does this.
     * 
     * @param getAccountBeneficiaryResponseType
     */
    public GetBeneficiaryDetailsUtil(GetAccountBeneficiaryResponseType getAccountBeneficiaryResponseType) {
        this.getAccountBeneficiaryResponseType = getAccountBeneficiaryResponseType;
    }

    /**
     * 
     * This method constructs beneficiaryList object from response.
     * 
     * @param getBeneficiaryResponse
     */
    public void setGetBeneficiaryResponse(GetBeneficiaryResponse getBeneficiaryResponse) {
        // setting account details
        this.setAccountDetails(getBeneficiaryResponse);
        List<BeneficiaryDetails> beneficiary = new ArrayList<BeneficiaryDetails>();
        if (this.getAccountBeneficiaryResponseType != null && this.getAccountBeneficiaryResponseType.getBeneficiary() != null &&
                this.getAccountBeneficiaryResponseType.getBeneficiary().size() > 0) {
            List<BeneficiaryType> beneficiaryList = getAccountBeneficiaryResponseType.getBeneficiary();
            // setting number of beneficiary
            this.numberOfBeneficiary = beneficiaryList.size();
            Iterator<BeneficiaryType> iterator = beneficiaryList.iterator();
            while (iterator.hasNext()) {
                this.beneficiaryType = iterator.next();
                String code = beneficiaryType.getClientAccountRelationship().getRelationshipType().getCode();
                if (code.equals(AccountServiceConstants.BENEFICIARY_TYPE)) {
                    BeneficiaryDetails beneficiaryDetails = new BeneficiaryDetails();
                    this.setBeneficiaryDetails(beneficiaryDetails, beneficiary);
                }
            }
            getBeneficiaryResponse.setBeneficiary(beneficiary);
        } else {
            BeneficiaryDetails beneficiaryDetails = new BeneficiaryDetails();
            this.setDummyBeneficiary(beneficiaryDetails, beneficiary);
            getBeneficiaryResponse.setBeneficiary(beneficiary);
        }
    }

    /**
     * This method constructs Account Details object from response.
     * 
     * @param getBeneficiaryResponse
     */
    private void setAccountDetails(GetBeneficiaryResponse getBeneficiaryResponse) {
        if (this.getAccountBeneficiaryResponseType != null && this.getAccountBeneficiaryResponseType.getAccount() != null) {
            getBeneficiaryResponse.setAccountNumber(this.getAccountNumber());
            getBeneficiaryResponse.setProductName(this.getProductName());
            getBeneficiaryResponse.setAccountExtReference(this.getAccountExtReference());
            getBeneficiaryResponse.setAccountExtReferenceCode(this.getAccountExtReferenceCode());
            getBeneficiaryResponse.setStatusId(this.getStatusId());
            getBeneficiaryResponse.setStatusCode(this.getStatusCode());
            getBeneficiaryResponse.setStatusCodeType(this.getStatusCodeType());
            getBeneficiaryResponse.setStatusCodeShortDescription(this.getStatusCodeShortDescription());
            getBeneficiaryResponse.setStatusCodeDescription(this.getStatusCodeDescription());
            getBeneficiaryResponse.setMasterSchemeDisplayName(this.getMasterSchemeDisplayName());
            getBeneficiaryResponse.setMasterSchemeLongName(this.getMasterSchemeLongName());
        } else {
            this.setDummyAccountValues(getBeneficiaryResponse);
        }
    }

    /**
     * This method constructs dummy Account Details object.
     * 
     * @param getBeneficiaryResponse
     */
    private void setDummyAccountValues(GetBeneficiaryResponse getBeneficiaryResponse) {
        getBeneficiaryResponse.setAccountNumber("");
        getBeneficiaryResponse.setProductName("");
        getBeneficiaryResponse.setAccountExtReference("");
        getBeneficiaryResponse.setAccountExtReferenceCode("");
        getBeneficiaryResponse.setStatusId("");
        getBeneficiaryResponse.setStatusCode("");
        getBeneficiaryResponse.setStatusCodeType("");
        getBeneficiaryResponse.setStatusCodeShortDescription("");
        getBeneficiaryResponse.setStatusCodeDescription("");
        getBeneficiaryResponse.setMasterSchemeDisplayName("");
        getBeneficiaryResponse.setMasterSchemeLongName("");
    }

    /**
     * 
     * This method is used to set the beneficiary.
     * 
     * @param beneficiaryDetails
     * @param beneficiary
     */
    public void setBeneficiaryDetails(BeneficiaryDetails beneficiaryDetails, List<BeneficiaryDetails> beneficiary) {
        SILLogger.debug(AccountServiceConstants.GET_BENEFICIARY_LOGGING_FORMAT, "GetBeneficiaryDetailsUtil", "Entering in setBenefiicary method.");
        beneficiaryDetails.setClientId(this.getClientId());
        beneficiaryDetails.setClientAccountRelationshipName(this.getClientAccountRelationshipName());
        beneficiaryDetails.setClientAccountRelationshipCode(this.getClientAccountRelationshipCode());
        beneficiaryDetails.setBeneficiaryId(this.getBeneficiaryId());
        beneficiaryDetails.setFirstName(this.getFirstName());
        beneficiaryDetails.setMiddleName(this.getMiddleName());
        beneficiaryDetails.setLastName(this.getLastName());
        beneficiaryDetails.setCategoryCode(this.getCategoryCode());
        beneficiaryDetails.setCategoryCodeType(this.getCategoryCodeType());
        beneficiaryDetails.setCategoryCodeShortDescription(this.getCategoryCodeShortDescription());
        beneficiaryDetails.setCategoryCodeDescription(this.getCategoryCodeDescription());
        beneficiaryDetails.setClientAccountRelationship(retrieveClientAccountRelationshipidentifier());
        this.setBeneficiaryDetails(beneficiaryDetails);
        beneficiary.add(beneficiaryDetails);
        SILLogger.debug(AccountServiceConstants.GET_BENEFICIARY_LOGGING_FORMAT, "GetBeneficiaryDetailsUtil", "Exiting from setBenefiicary method.");
    }

    /**
     * 
     * This method is used to set beneficiary details.
     * 
     * @param beneficiaryDetails
     */
    private void setBeneficiaryDetails(BeneficiaryDetails beneficiaryDetails) {
        beneficiaryDetails.setTypeCode(this.getTypeCode());
        beneficiaryDetails.setTypeCodeType(this.getTypeCodeType());
        beneficiaryDetails.setTypeCodeShortDescription(this.getTypeCodeShortDescription());
        beneficiaryDetails.setTypeCodeDescription(this.getTypeCodeDescription());
        beneficiaryDetails.setRelationshipCode(this.getRelationshipCode());
        beneficiaryDetails.setRelationshipCodeType(this.getRelationshipCodeType());
        beneficiaryDetails.setRelationshipCodeShortDescription(this.getRelationshipCodeShortDescription());
        beneficiaryDetails.setRelationshipCodeDescription(this.getRelationshipCodeDescription());
        beneficiaryDetails.setAdviceReceived(this.getAdviceReceived());
        beneficiaryDetails.setEndDate(this.getEndDate());
        beneficiaryDetails.setDateNominationSigned(this.getDateNominationSigned());
        beneficiaryDetails.setAllocation(this.getAllocation());
    }

    /**
     * This method will populate blank value in Beneficiary object when no beneficiary object present for the given client.
     * 
     * @param beneficiaryDetails of type BeneficiaryDetails
     * @param beneficiaryType of type BeneficiaryType
     * @param beneficiary of type List of BeneficiaryDetails
     */
    private void setDummyBeneficiary(BeneficiaryDetails beneficiaryDetails, List<BeneficiaryDetails> beneficiary) {
        SILLogger
                .debug(AccountServiceConstants.GET_BENEFICIARY_LOGGING_FORMAT, "GetBeneficiaryDetailsUtil", "Entering in setDummyBeneficiary method");
        beneficiaryDetails.setClientId("");
        beneficiaryDetails.setClientAccountRelationshipName("");
        beneficiaryDetails.setClientAccountRelationshipCode("");
        beneficiaryDetails.setBeneficiaryId("");
        beneficiaryDetails.setFirstName("");
        beneficiaryDetails.setMiddleName("");
        beneficiaryDetails.setLastName("");
        beneficiaryDetails.setDateOfBirth("");
        beneficiaryDetails.setCategoryCode("");
        beneficiaryDetails.setCategoryCodeType("");
        beneficiaryDetails.setCategoryCodeShortDescription("");
        beneficiaryDetails.setCategoryCodeDescription("");
        beneficiaryDetails.setClientAccountRelationship(retrieveEmptyClientAccountRelationshipidentifier());
        this.setDummyBeneficiary(beneficiaryDetails);
        beneficiary.add(beneficiaryDetails);
        SILLogger.debug(AccountServiceConstants.GET_BENEFICIARY_LOGGING_FORMAT, "GetBeneficiaryDetailsUtil",
                "Exiting from setDummyBeneficiary method");
    }

    /**
     * 
     * This method is used to set default values of beneficiary.
     * 
     * @param beneficiaryDetails
     */
    private void setDummyBeneficiary(BeneficiaryDetails beneficiaryDetails) {
        beneficiaryDetails.setTypeCode("");
        beneficiaryDetails.setTypeCodeType("");
        beneficiaryDetails.setTypeCodeShortDescription("");
        beneficiaryDetails.setTypeCodeDescription("");
        beneficiaryDetails.setRelationshipCode("");
        beneficiaryDetails.setRelationshipCodeType("");
        beneficiaryDetails.setRelationshipCodeShortDescription("");
        beneficiaryDetails.setRelationshipCodeDescription("");
        beneficiaryDetails.setAdviceReceived("");
        beneficiaryDetails.setEndDate("");
        beneficiaryDetails.setDateNominationSigned("");
        beneficiaryDetails.setAllocation("");
    }

    /**
     * Accessor for property numberOfBeneficiary.
     * 
     * @return numberOfBeneficiary of type int
     */
    public int getNumberOfBeneficiary() {
        return numberOfBeneficiary;
    }

    /**
     * Accessor for property accountNumber.
     * 
     * @return accountNumber of type String
     */
    private String getAccountNumber() {
        if (this.getAccountBeneficiaryResponseType.getAccount().getAccountNumber() != null) {
            return this.getAccountBeneficiaryResponseType.getAccount().getAccountNumber().getAccountNo();
        }
        return "";
    }

    /**
     * Accessor for property productName.
     * 
     * @return productName of type String
     */
    private String getProductName() {
        if (this.getAccountBeneficiaryResponseType.getAccount().getAccountNumber() != null) {
            return this.getAccountBeneficiaryResponseType.getAccount().getAccountNumber().getProductName();
        }
        return "";
    }

    /**
     * Accessor for property accountExtReference.
     * 
     * @return accountExtReference of type String
     */
    private String getAccountExtReference() {
        if (this.getAccountBeneficiaryResponseType.getAccount().getAccountExternalRef() != null) {
            return this.getAccountBeneficiaryResponseType.getAccount().getAccountExternalRef().getReference();
        }
        return "";
    }

    /**
     * Accessor for property accountExtReferenceCode.
     * 
     * @return accountExtReferenceCode of type String
     */
    private String getAccountExtReferenceCode() {
        if (this.getAccountBeneficiaryResponseType.getAccount().getAccountExternalRef() != null) {
            return this.getAccountBeneficiaryResponseType.getAccount().getAccountExternalRef().getReferenceCode();
        }
        return "";
    }

    /**
     * Accessor for property statusId.
     * 
     * @return statusId of type String
     */
    private String getStatusId() {
        if (this.getAccountBeneficiaryResponseType.getAccount().getStatusCode() != null) {
            return String.valueOf(this.getAccountBeneficiaryResponseType.getAccount().getStatusCode().getId());
        }
        return "";
    }

    /**
     * Accessor for property statusCode.
     * 
     * @return statusCode of type String
     */
    private String getStatusCode() {
        if (this.getAccountBeneficiaryResponseType.getAccount().getStatusCode() != null) {
            return this.getAccountBeneficiaryResponseType.getAccount().getStatusCode().getCode();
        }
        return "";
    }

    /**
     * Accessor for property statusCodeType.
     * 
     * @return statusCodeType of type String
     */
    private String getStatusCodeType() {
        if (this.getAccountBeneficiaryResponseType.getAccount().getStatusCode() != null) {
            return this.getAccountBeneficiaryResponseType.getAccount().getStatusCode().getCodeType();
        }
        return "";
    }

    /**
     * Accessor for property statusCodeShortDescription.
     * 
     * @return statusCodeShortDescription of type String
     */
    private String getStatusCodeShortDescription() {
        if (this.getAccountBeneficiaryResponseType.getAccount().getStatusCode() != null) {
            return this.getAccountBeneficiaryResponseType.getAccount().getStatusCode().getCodeShortDescription();
        }
        return "";
    }

    /**
     * Accessor for property statusCodeDescription.
     * 
     * @return statusCodeDescription of type String
     */
    private String getStatusCodeDescription() {
        if (this.getAccountBeneficiaryResponseType.getAccount().getStatusCode() != null) {
            return this.getAccountBeneficiaryResponseType.getAccount().getStatusCode().getCodeDescription();
        }
        return "";
    }

    /**
     * Accessor for property masterSchemeDisplayName.
     * 
     * @return masterSchemeDisplayName of type String
     */
    private String getMasterSchemeDisplayName() {
        if (this.getAccountBeneficiaryResponseType.getAccount().getMasterScheme() != null) {
            return this.getAccountBeneficiaryResponseType.getAccount().getMasterScheme().getDisplayName();
        }
        return "";
    }

    /**
     * Accessor for property masterSchemeLongName.
     * 
     * @return masterSchemeLongName of type String
     */
    private String getMasterSchemeLongName() {
        if (this.getAccountBeneficiaryResponseType.getAccount().getMasterScheme() != null) {
            return this.getAccountBeneficiaryResponseType.getAccount().getMasterScheme().getLongName();
        }
        return "";
    }

    /**
     * Accessor for property clientId.
     * 
     * @return clientId of type String
     */
    private String getClientId() {
        if (this.beneficiaryType != null && this.beneficiaryType.getClientAccountRelationship() != null &&
                this.beneficiaryType.getClientAccountRelationship().getClient() != null) {
            return String.valueOf(this.beneficiaryType.getClientAccountRelationship().getClient().getId());
        }
        return "";
    }

    /**
     * Accessor for property clientAccountRelationshipName.
     * 
     * @return clientAccountRelationshipName of type String
     */
    private String getClientAccountRelationshipName() {
        if (this.beneficiaryType != null && this.beneficiaryType.getClientAccountRelationship() != null &&
                this.beneficiaryType.getClientAccountRelationship().getRelationshipType() != null) {
            return this.beneficiaryType.getClientAccountRelationship().getRelationshipType().getName();
        }
        return "";
    }

    /**
     * Accessor for property clientAccountRelationshipCode.
     * 
     * @return clientAccountRelationshipCode of type String
     */
    private String getClientAccountRelationshipCode() {
        if (this.beneficiaryType != null && this.beneficiaryType.getClientAccountRelationship() != null &&
                this.beneficiaryType.getClientAccountRelationship().getRelationshipType() != null) {
            return this.beneficiaryType.getClientAccountRelationship().getRelationshipType().getCode();
        }
        return "";
    }

    /**
     * Accessor for property beneficiaryId.
     * 
     * @return beneficiaryId of type String
     */
    private String getBeneficiaryId() {
        if (this.beneficiaryType != null && this.beneficiaryType.getClientAccountRelationship() != null) {
            return String.valueOf(this.beneficiaryType.getClientAccountRelationship().getId());
        }
        return "";
    }

    /**
     * Accessor for property firstName.
     * 
     * @return firstName of type String
     */
    private String getFirstName() {
        if (this.beneficiaryType != null && this.beneficiaryType.getClientAccountRelationship() != null &&
                this.beneficiaryType.getClientAccountRelationship().getClient() != null) {
            return this.beneficiaryType.getClientAccountRelationship().getClient().getClientForename();
        }
        return "";
    }

    /**
     * Accessor for property middleName.
     * 
     * @return middleName of type String
     */
    private String getMiddleName() {
        if (this.beneficiaryType != null && this.beneficiaryType.getClientAccountRelationship() != null &&
                this.beneficiaryType.getClientAccountRelationship().getClient() != null) {
            return this.beneficiaryType.getClientAccountRelationship().getClient().getClientForename2();
        }
        return "";
    }

    /**
     * Accessor for property lastName.
     * 
     * @return lastName of type String
     */
    private String getLastName() {
        if (this.beneficiaryType != null && this.beneficiaryType.getClientAccountRelationship() != null &&
                this.beneficiaryType.getClientAccountRelationship().getClient() != null) {
            return this.beneficiaryType.getClientAccountRelationship().getClient().getClientSurname();
        }
        return "";
    }

    /**
     * Accessor for property categoryCode.
     * 
     * @return categoryCode of type String
     */
    private String getCategoryCode() {
        if (this.beneficiaryType != null && this.beneficiaryType.getCategory() != null) {
            return this.beneficiaryType.getCategory().getCode();
        }
        return "";
    }

    /**
     * Accessor for property categoryCodeType.
     * 
     * @return categoryCodeType of type String
     */
    private String getCategoryCodeType() {
        if (this.beneficiaryType != null && this.beneficiaryType.getCategory() != null) {
            return this.beneficiaryType.getCategory().getCodeType();
        }
        return "";
    }

    /**
     * Accessor for property categoryCodeShortDescription.
     * 
     * @return categoryCodeShortDescription of type String
     */
    private String getCategoryCodeShortDescription() {
        if (this.beneficiaryType != null && this.beneficiaryType.getCategory() != null) {
            return this.beneficiaryType.getCategory().getCodeShortDescription();
        }
        return "";
    }

    /**
     * Accessor for property categoryCodeDescription.
     * 
     * @return categoryCodeDescription of type String
     */
    private String getCategoryCodeDescription() {
        if (this.beneficiaryType != null && this.beneficiaryType.getCategory() != null) {
            return this.beneficiaryType.getCategory().getCodeDescription();
        }
        return "";
    }

    /**
     * Accessor for property typeCode.
     * 
     * @return typeCode of type String
     */
    private String getTypeCode() {
        if (this.beneficiaryType != null && this.beneficiaryType.getType() != null) {
            return this.beneficiaryType.getType().getCode();
        }
        return "";
    }

    /**
     * Accessor for property typeCodeType.
     * 
     * @return typeCodeType of type String
     */
    private String getTypeCodeType() {
        if (this.beneficiaryType != null && this.beneficiaryType.getType() != null) {
            return this.beneficiaryType.getType().getCodeType();
        }
        return "";
    }

    /**
     * Accessor for property typeCodeShortDescription.
     * 
     * @return typeCodeShortDescription of type String
     */
    private String getTypeCodeShortDescription() {
        if (this.beneficiaryType != null && this.beneficiaryType.getType() != null) {
            return this.beneficiaryType.getType().getCodeShortDescription();
        }
        return "";
    }

    /**
     * Accessor for property typeCodeDescription.
     * 
     * @return typeCodeDescription of type String
     */
    private String getTypeCodeDescription() {
        if (this.beneficiaryType != null && this.beneficiaryType.getType() != null) {
            return this.beneficiaryType.getType().getCodeDescription();
        }
        return "";
    }

    /**
     * Accessor for property relationshipCode.
     * 
     * @return relationshipCode of type String
     */
    private String getRelationshipCode() {
        if (this.beneficiaryType != null && this.beneficiaryType.getRelationship() != null) {
            return this.beneficiaryType.getRelationship().getCode();
        }
        return "";
    }

    /**
     * Accessor for property relationshipCodeType.
     * 
     * @return relationshipCodeType of type String
     */
    private String getRelationshipCodeType() {
        if (this.beneficiaryType != null && this.beneficiaryType.getRelationship() != null) {
            return this.beneficiaryType.getRelationship().getCodeType();
        }
        return "";
    }

    /**
     * Accessor for property relationshipCodeShortDescription.
     * 
     * @return relationshipCodeShortDescription of type String
     */
    private String getRelationshipCodeShortDescription() {
        if (this.beneficiaryType != null && this.beneficiaryType.getRelationship() != null) {
            return this.beneficiaryType.getRelationship().getCodeShortDescription();
        }
        return "";
    }

    /**
     * Accessor for property relationshipCodeDescription.
     * 
     * @return relationshipCodeDescription of type String
     */
    private String getRelationshipCodeDescription() {
        if (this.beneficiaryType != null && this.beneficiaryType.getRelationship() != null) {
            return this.beneficiaryType.getRelationship().getCodeDescription();
        }
        return "";
    }

    /**
     * Accessor for property adviceReceived.
     * 
     * @return adviceReceived of type String
     */
    private String getAdviceReceived() {
        if (this.beneficiaryType != null && this.beneficiaryType.isAdviceReceived() != null) {
            return Boolean.toString(this.beneficiaryType.isAdviceReceived());
        }
        return "";
    }

    /**
     * Accessor for property endDate.
     * 
     * @return endDate of type String
     */
    private String getEndDate() {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(ClientServiceConstants.DATE_TIME_FORMAT);
        if (this.beneficiaryType != null && this.beneficiaryType.getEndDate() != null) {
            return simpleDateFormat.format(this.beneficiaryType.getEndDate().toGregorianCalendar().getTime());
        }
        return "";
    }

    /**
     * Accessor for property dateNominationSigned.
     * 
     * @return dateNominationSigned of type String
     */
    private String getDateNominationSigned() {
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(ClientServiceConstants.DATE_TIME_FORMAT);
        if (this.beneficiaryType != null && this.beneficiaryType.getDateNominationSigned() != null) {
            return simpleDateFormat.format(this.beneficiaryType.getDateNominationSigned().toGregorianCalendar().getTime());
        }
        return "";
    }

    /**
     * Accessor for property allocation.
     * 
     * @return allocation of type String
     */
    private String getAllocation() {
        if (this.beneficiaryType != null && this.beneficiaryType.getSplitPercentage() != null) {
            return String.valueOf(this.beneficiaryType.getSplitPercentage().doubleValue());
        }
        return "";
    }

    /**
     * 
     * This method constructs ClientAccountRelationshipidentifier object from response.
     *
     * @return
     */
    public ClientAccountRelationshipIdentifierBean retrieveClientAccountRelationshipidentifier() {
        ClientAccountRelationshipIdentifierBean accountRelationshipIdentifierBean = new ClientAccountRelationshipIdentifierBean();
        if (this.beneficiaryType != null && this.beneficiaryType.getClientAccountRelationship() != null) {
            SILLogger.debug(AccountServiceConstants.GET_BENEFICIARY_LOGGING_FORMAT, "GetBeneficiaryDetailsUtil",
                    "Entering in retrieveClientAccountRelationshipidentifier()");
            accountRelationshipIdentifierBean.setPrimary(String.valueOf(this.beneficiaryType.getClientAccountRelationship().isPrimary()));

        } else {
            accountRelationshipIdentifierBean = retrieveEmptyClientAccountRelationshipidentifier();
        }
        return accountRelationshipIdentifierBean;
    }

    /**
     * This method constructs empty ClientAccountRelationshipidentifier object.
     * 
     * @return accountRelationshipIdentifierBean
     * 
     */
    public ClientAccountRelationshipIdentifierBean retrieveEmptyClientAccountRelationshipidentifier() {

        ClientAccountRelationshipIdentifierBean accountRelationshipIdentifierBean = new ClientAccountRelationshipIdentifierBean();
        SILLogger.debug(AccountServiceConstants.GET_BENEFICIARY_LOGGING_FORMAT, "GetBeneficiaryDetailsUtil",
                "Entering in retrieveEmptyClientAccountRelationshipidentifier()");

        accountRelationshipIdentifierBean.setPrimary(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);

        return accountRelationshipIdentifierBean;
    }
}
