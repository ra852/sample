////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;
/**
 * The class {@code ContributionBean} does this.
 * 
 * @author U387938
 * @since 02/02/2016
 * @version 1.0
 */
public class ContributionBean {

    private CodeIdentifier contributionType;
    private CodeIdentifier taxStatus;
    private String amount;
    private CodeIdentifier contributionCapGroup;
    /**
     * Accessor for property contributionType.
     *
     * @return contributionType of type CodeIdentifier
     */
    public CodeIdentifier getContributionType() {
        return contributionType;
    }
    /**
     * Mutator for property contributionType.
     *
     * @param contributionType of type CodeIdentifier
     */
    @XmlElement(name = "contributionType")
    public void setContributionType(CodeIdentifier contributionType) {
        this.contributionType = contributionType;
    }
    /**
     * Accessor for property taxStatus.
     *
     * @return taxStatus of type CodeIdentifier
     */
    public CodeIdentifier getTaxStatus() {
        return taxStatus;
    }
    /**
     * Mutator for property taxStatus.
     *
     * @param taxStatus of type CodeIdentifier
     */
    @XmlElement(name = "taxStatus")
    public void setTaxStatus(CodeIdentifier taxStatus) {
        this.taxStatus = taxStatus;
    }
    /**
     * Accessor for property amount.
     *
     * @return amount of type String
     */
    public String getAmount() {
        return amount;
    }
    /**
     * Mutator for property amount.
     *
     * @param amount of type String
     */
    @XmlElement(name = "amount")
    public void setAmount(String amount) {
        this.amount = amount != null ? amount : "";
    }
    /**
     * Accessor for property contributionCapGroup.
     *
     * @return contributionCapGroup of type CodeIdentifier
     */
    public CodeIdentifier getContributionCapGroup() {
        return contributionCapGroup;
    }
    /**
     * Mutator for property contributionCapGroup.
     *
     * @param contributionCapGroup of type CodeIdentifier
     */
    @XmlElement(name = "contributionCapGroup")
    public void setContributionCapGroup(CodeIdentifier contributionCapGroup) {
        this.contributionCapGroup = contributionCapGroup;
    }
    
    
}
