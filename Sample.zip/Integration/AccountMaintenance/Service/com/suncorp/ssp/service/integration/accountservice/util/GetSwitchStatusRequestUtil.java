////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import java.util.List;

import javax.ws.rs.core.MultivaluedMap;
import javax.xml.datatype.XMLGregorianCalendar;

import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CodeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.PagingRangeType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType.AccountNumber;
import com.sonatacentral.service.v30.globaltypes.wrap.transaction.transactiongrouptype.TransactionTypeIdentifierType;
import com.sonatacentral.service.v30.wrap.account.GetAccountTransactionListRequestType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;

/**
 * The class {@code GetSwitchStatusRequestUtil} is used as a util class for preparing GetSwitchStatus request.
 * 
 * @author u385424
 * @since 28/07/2016
 * @version 1.0
 */
public class GetSwitchStatusRequestUtil {
    private final String className = "GetSwitchStatusRequestUtil";
    private GetAccountTransactionListRequestType outboundRequest;
    private MultivaluedMap<String, String> inboundRequest;

    /**
     * Initializes class properties,viz., inbound and outbound request types.
     * 
     * @param inboundRequest of type MultivaluedMap
     */
    public GetSwitchStatusRequestUtil(MultivaluedMap<String, String> inboundRequest) {
        this.inboundRequest = inboundRequest;
        this.outboundRequest = new GetAccountTransactionListRequestType();
    }

    /**
     * Create Oubound request.
     * 
     * @throws Exception
     * @return outboundRequest of type GetAccountTransactionListRequestType
     */
    public GetAccountTransactionListRequestType createOutboundRequest() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_SWITCH_STATUS_LOGGING_FORMAT, className, "Entering createOutboundRequest()");
        this.outboundRequest.setCallerDetails(SILUtil.createCallerDetails());
        this.outboundRequest.setAccount(createAccountIdentifierType());
        this.outboundRequest.getTransactionType().add(createTransactionTypeIdentifierType());
        createStatus();
        this.outboundRequest.setStartDateTime(createStartDate());
        this.outboundRequest.setEndDateTime(creatEndDate());
        this.outboundRequest.setPagingRange(createPagingRangeType());
        setIncludePricedOnlyFlag();
        setExcludeStatusList();
        return this.outboundRequest;
    }

    /**
     * This method is used to set exclude status list.
     * 
     */
    private void setExcludeStatusList() {
        SILLogger.debug(AccountServiceConstants.GET_SWITCH_STATUS_LOGGING_FORMAT, className, "Entering setExcludeStatusList()");
        if (this.inboundRequest.containsKey(AccountServiceConstants.FILTER_REVERSE_TRANS_FLAG) &&
                this.inboundRequest.get(AccountServiceConstants.FILTER_REVERSE_TRANS_FLAG).get(0).equalsIgnoreCase(AccountServiceConstants.TRUE)) {
            List<CodeIdentifierType> excludeStatusList = this.outboundRequest.getExcludeStatusList();
            CodeIdentifierType excludeStatus = new CodeIdentifierType();
            excludeStatus.setCode(AccountServiceConstants.GET_SWITCH_REVERSE_CODE);
            excludeStatus.setCodeType(AccountServiceConstants.STATUS_CODE_TRANSACTION);
            excludeStatusList.add(excludeStatus);
        }
        SILLogger.debug(AccountServiceConstants.GET_SWITCH_STATUS_LOGGING_FORMAT, className, "Exiting setExcludeStatusList()");
    }

    /**
     * Add status code and status type in request.
     */
    private void createStatus() {
        SILLogger.debug(AccountServiceConstants.GET_SWITCH_STATUS_LOGGING_FORMAT, className, "Entering createStatus()");
        if (this.inboundRequest.containsKey(AccountServiceConstants.STATUS_CODE) &&
                this.inboundRequest.containsKey(AccountServiceConstants.STATUS_CODE_TYPE)) {
            List<CodeIdentifierType> statusList = this.outboundRequest.getIncludeStatusList();
            CodeIdentifierType status = new CodeIdentifierType();
            if (this.inboundRequest.containsKey(AccountServiceConstants.STATUS_CODE)) {
                status.setCode(this.inboundRequest.get(AccountServiceConstants.STATUS_CODE).get(0));
            }
            if (this.inboundRequest.containsKey(AccountServiceConstants.STATUS_CODE_TYPE)) {
                status.setCodeType(this.inboundRequest.get(AccountServiceConstants.STATUS_CODE_TYPE).get(0));
            }
            statusList.add(status);
        }
        SILLogger.debug(AccountServiceConstants.GET_SWITCH_STATUS_LOGGING_FORMAT, className, "Exiting createStatus()");
    }

    /**
     * Create a new instance of AccountIdentifierType, with necessary values set.
     * 
     * @return accountIdentifierType of type AccountIdentifierType
     * @throws SILException
     */
    public AccountIdentifierType createAccountIdentifierType() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_SWITCH_STATUS_LOGGING_FORMAT, className, "Entering createAccountIdentifierType()");
        AccountIdentifierType accountIdentifierType = new AccountIdentifierType();
        AccountNumber accountNumber = new AccountNumber();
        if (this.inboundRequest.containsKey(AccountServiceConstants.ACCOUNT_NO)) {
            accountNumber.setAccountNo(this.inboundRequest.get(AccountServiceConstants.ACCOUNT_NO).get(0));
        }
        accountIdentifierType.setAccountNumber(accountNumber);
        return accountIdentifierType;
    }

    /**
     * Create a new instance of startDate, with necessary value set.
     * 
     * @return startDate of type XMLGregorianCalendar
     * @throws SILException
     */
    public XMLGregorianCalendar createStartDate() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_SWITCH_STATUS_LOGGING_FORMAT, className, "Entering createStartDate()");
        XMLGregorianCalendar startDate = null;
        if (this.inboundRequest.containsKey(AccountServiceConstants.START_DATE)) {
            String datetime = this.inboundRequest.get(AccountServiceConstants.START_DATE).get(0) + " 00:00:00";
            startDate = SILUtil.convertStringToXMLGregorianCalendar(datetime, CommonConstants.DATETIME_FORMAT);
        }
        return startDate;
    }

    /**
     * Create a new instance of endDate, with necessary value set.
     * 
     * @return endDate of type XMLGregorianCalendar
     * @throws SILException
     */
    public XMLGregorianCalendar creatEndDate() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_SWITCH_STATUS_LOGGING_FORMAT, className, "Entering creatEndDate()");
        XMLGregorianCalendar endDate = null;
        if (this.inboundRequest.containsKey(AccountServiceConstants.END_DATE)) {
            String datetime = this.inboundRequest.get(AccountServiceConstants.END_DATE).get(0) + " 23:59:59";
            endDate = SILUtil.convertStringToXMLGregorianCalendar(datetime, CommonConstants.DATETIME_FORMAT);
        }
        return endDate;
    }

    /**
     * Create a new instance of TransactionTypeIdentifierType, with necessary values set.
     * 
     * @return transTypeIdentifierCode of type TransactionTypeIdentifierType
     * @throws SILException
     */
    public TransactionTypeIdentifierType createTransactionTypeIdentifierType() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_SWITCH_STATUS_LOGGING_FORMAT, className, "Entering createTransactionTypeIdentifierType()");
        TransactionTypeIdentifierType transTypeIdentifierCode = new TransactionTypeIdentifierType();
        transTypeIdentifierCode.setCode(AccountServiceConstants.SWITCH);
        transTypeIdentifierCode.setCategory(createCodeIdentifierType());
        return transTypeIdentifierCode;
    }

    /**
     * Create a new instance of CodeIdentifierType, with necessary values set.
     * 
     * @return codeIdentifierType of type CodeIdentifierType
     * @throws SILException
     */

    public CodeIdentifierType createCodeIdentifierType() throws SILException {
        CodeIdentifierType codeIdentifierType = new CodeIdentifierType();
        codeIdentifierType.setCode(AccountServiceConstants.SWITCH);
        codeIdentifierType.setCodeType(AccountServiceConstants.TECT);
        return codeIdentifierType;
    }

    /**
     * Create a new instance of PagingRangeType, with necessary values set.
     * 
     * @return pagingRangeType of type PagingRangeType
     * @throws SILException
     */
    public PagingRangeType createPagingRangeType() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_SWITCH_STATUS_LOGGING_FORMAT, className, "Entering createPagingRangeType() ");
        PagingRangeType pagingRangeType = new PagingRangeType();
        if (this.inboundRequest.containsKey(AccountServiceConstants.FIRST_RESULT)) {
            pagingRangeType.setFirstResult(Integer.parseInt(this.inboundRequest.get(AccountServiceConstants.FIRST_RESULT).get(0)));
        } else {
            pagingRangeType.setFirstResult(0);
        }
        if (this.inboundRequest.containsKey(AccountServiceConstants.RESULT_PER_PAGE)) {
            pagingRangeType.setResultsPerPage(Integer.parseInt(this.inboundRequest.get(AccountServiceConstants.RESULT_PER_PAGE).get(0)));
        } else {
            pagingRangeType.setResultsPerPage(0);
        }
        return pagingRangeType;
    }

    /**
     * 
     * Set the includeUnpricedFlagt in the sonata request.
     * 
     * @throws SILException
     */
    public void setIncludePricedOnlyFlag() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_SWITCH_STATUS_LOGGING_FORMAT, className, "Entering setIncludePricedOnlyFlag()");

        if (this.inboundRequest.containsKey(AccountServiceConstants.SWIT_INCLUDE_UNPRICED_FLAG) &&
                inboundRequest.get(AccountServiceConstants.SWIT_INCLUDE_UNPRICED_FLAG).get(0) != null) {
            this.outboundRequest.setIncludeUnpricedOnly(Boolean.valueOf(this.inboundRequest.get(AccountServiceConstants.SWIT_INCLUDE_UNPRICED_FLAG)
                    .get(0)));
        }
    }
}
