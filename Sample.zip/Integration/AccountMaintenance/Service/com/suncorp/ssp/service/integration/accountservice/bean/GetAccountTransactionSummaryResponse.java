////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import java.math.BigDecimal;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.suncorp.ssp.common.bean.SILErrorMessage;

/**
 * The class {@code GetAccountTransactionSummaryResponse} java bean consisting of all the properties related to account transaction summary details,
 * to be used for constructing response for GetAccountTransactionSummary service.
 *
 * @author u383753
 * @since 24/12/2015
 * @version 1.0
 */
@XmlRootElement(name = "GetAccountTransactionSummaryResponse")
public class GetAccountTransactionSummaryResponse extends SILErrorMessage {
    private BigDecimal openingBalanceAmount;
    private BigDecimal closingBalanceAmount;
    private BigDecimal investmentEarningsAmount;
    private List<TransSummaryItemTypeList> transSummaryItemType;

    /**
     * Accessor for property openingBalanceAmount.
     * 
     * @return openingBalanceAmount of type BigDecimal
     */
    public BigDecimal getOpeningBalanceAmount() {
        return openingBalanceAmount;
    }

    /**
     * Mutator for property openingBalanceAmount.
     * 
     * @param openingBalanceAmount of type BigDecimal
     */
    @XmlElement(name = "openingBalanceAmount")
    public void setOpeningBalanceAmount(BigDecimal openingBalanceAmount) {
        this.openingBalanceAmount = openingBalanceAmount;
    }

    /**
     * Accessor for property closingBalanceAmount.
     * 
     * @return closingBalanceAmount of type BigDecimal
     */
    public BigDecimal getClosingBalanceAmount() {
        return closingBalanceAmount;
    }

    /**
     * Mutator for property closingBalanceAmount.
     * 
     * @param closingBalanceAmount of type String
     */
    @XmlElement(name = "closingBalanceAmount")
    public void setClosingBalanceAmount(BigDecimal closingBalanceAmount) {
        this.closingBalanceAmount = closingBalanceAmount;
    }

    /**
     * Accessor for property investmentEarningsAmount.
     * 
     * @return investmentEarningsAmount of type BigDecimal
     */
    public BigDecimal getInvestmentEarningsAmount() {
        return investmentEarningsAmount;
    }

    /**
     * Mutator for property investmentEarningsAmount.
     * 
     * @return investmentEarningsAmount of type String
     */
    @XmlElement(name = "investmentEarningsAmount")
    public void setInvestmentEarningsAmount(BigDecimal investmentEarningsAmount) {
        this.investmentEarningsAmount = investmentEarningsAmount;
    }

    /**
     * Accessor for property transSummaryItemType.
     * 
     * @return transSummaryItemType of type List
     */
    public List<TransSummaryItemTypeList> getTransSummaryItemType() {
        return transSummaryItemType;
    }

    /**
     * Mutator for property transSummaryItemType.
     * 
     * @param transSummaryItemType of type List
     */
    @XmlElement(name = "transSummaryItemType")
    public void setTransSummaryItemType(List<TransSummaryItemTypeList> transSummaryItemType) {
        this.transSummaryItemType = transSummaryItemType;
    }
}
