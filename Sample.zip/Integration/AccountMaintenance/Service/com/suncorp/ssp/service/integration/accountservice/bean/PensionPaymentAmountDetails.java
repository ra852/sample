////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code PensionPaymentAmountDetails} does this.
 * 
 * @author U387938
 * @since 02/02/2016
 * @version 1.0
 */
public class PensionPaymentAmountDetails {

    private String effectiveDate;
    private CodeIdentifier pensionStatus;
    private FrequencyIdentifierBean paymentFrequency;
    private String numberOfPayments;
    private CodeIdentifier pensionPaymentRule;
    private CodeIdentifier reviewType;
    private FrequencyIdentifierBean reviewFrequency;
    private String taxOverridePercent;
    private CodeIdentifier taxFreeMethod;
    private CodeIdentifier revAnnuitantRelationship;
    private String pensionStartDate;
    private String paymentDate1;
    private String paymentDate2;
    private String nextPaymentDue;
    private String nominatedIndexRate;
    private String additionalTax;
    private String nextReviewDate;
    private String taxFreeProportion;
    private String annualNominatedPercent;
    private String claimRebate;
    private String claimDeductible;
    private String carryForwardDeductible;
    private String ttr;
    private String annualPension;
    private String regularPension;
    private String purchasePrice;
    private String minimumAnnualPension;
    private String maximumAnnualPension;
    private String grossAnnualisedIncome;
    private String ytdGrossPaidAmount;
    private String ytdNetPaidAmount;
    private String setAmount;
    private String remainingTerm;
    private String newMinimumAmount;
    private String newMaximumAmount;
    private String depositBalance;

    /**
     * Accessor for property effectiveDate.
     * 
     * @return effectiveDate of type String
     */
    public String getEffectiveDate() {
        return effectiveDate;
    }

    /**
     * Mutator for property effectiveDate.
     * 
     * @return effectiveDate of type String
     */
    @XmlElement(name = "effectiveDate")
    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate != null ? effectiveDate : "";
    }

    /**
     * Accessor for property pensionStatus.
     * 
     * @return pensionStatus of type CodeIdentifier
     */
    public CodeIdentifier getPensionStatus() {
        return pensionStatus;
    }

    /**
     * Mutator for property pensionStatus.
     * 
     * @return pensionStatus of type CodeIdentifier
     */
    @XmlElement(name = "pensionStatus")
    public void setPensionStatus(CodeIdentifier pensionStatus) {
        this.pensionStatus = pensionStatus;
    }

    /**
     * Accessor for property paymentFrequency.
     * 
     * @return paymentFrequency of type FrequencyIdentifierBean
     */
    public FrequencyIdentifierBean getPaymentFrequency() {
        return paymentFrequency;
    }

    /**
     * Mutator for property paymentFrequency.
     * 
     * @return paymentFrequency of type FrequencyIdentifierBean
     */
    @XmlElement(name = "paymentFrequency")
    public void setPaymentFrequency(FrequencyIdentifierBean paymentFrequency) {
        this.paymentFrequency = paymentFrequency;
    }

    /**
     * Accessor for property numberOfPayments.
     * 
     * @return numberOfPayments of type String
     */
    public String getNumberOfPayments() {
        return numberOfPayments;
    }

    /**
     * Mutator for property numberOfPayments.
     * 
     * @return numberOfPayments of type String
     */
    @XmlElement(name = "numberOfPayments")
    public void setNumberOfPayments(String numberOfPayments) {
        this.numberOfPayments = numberOfPayments != null ? numberOfPayments : "";
    }

    /**
     * Accessor for property pensionPaymentRule.
     * 
     * @return pensionPaymentRule of type CodeIdentifier
     */
    public CodeIdentifier getPensionPaymentRule() {
        return pensionPaymentRule;
    }

    /**
     * Mutator for property pensionPaymentRule.
     * 
     * @return pensionPaymentRule of type CodeIdentifier
     */
    @XmlElement(name = "pensionPaymentRule")
    public void setPensionPaymentRule(CodeIdentifier pensionPaymentRule) {
        this.pensionPaymentRule = pensionPaymentRule;
    }

    /**
     * Accessor for property reviewType.
     * 
     * @return reviewType of type CodeIdentifier
     */
    public CodeIdentifier getReviewType() {
        return reviewType;
    }

    /**
     * Mutator for property reviewType.
     * 
     * @return reviewType of type CodeIdentifier
     */
    @XmlElement(name = "reviewType")
    public void setReviewType(CodeIdentifier reviewType) {
        this.reviewType = reviewType;
    }

    /**
     * Accessor for property reviewFrequency.
     * 
     * @return reviewFrequency of type FrequencyIdentifierBean
     */
    public FrequencyIdentifierBean getReviewFrequency() {
        return reviewFrequency;
    }

    /**
     * Mutator for property reviewFrequency.
     * 
     * @return reviewFrequency of type FrequencyIdentifierBean
     */
    @XmlElement(name = "reviewFrequency")
    public void setReviewFrequency(FrequencyIdentifierBean reviewFrequency) {
        this.reviewFrequency = reviewFrequency;
    }

    /**
     * Accessor for property taxOverridePercent.
     * 
     * @return taxOverridePercent of type String
     */
    public String getTaxOverridePercent() {
        return taxOverridePercent;
    }

    /**
     * Mutator for property taxOverridePercent.
     * 
     * @return taxOverridePercent of type String
     */
    @XmlElement(name = "taxOverridePercent")
    public void setTaxOverridePercent(String taxOverridePercent) {
        this.taxOverridePercent = taxOverridePercent != null ? taxOverridePercent : "";
    }

    /**
     * Accessor for property taxFreeMethod.
     * 
     * @return taxFreeMethod of type CodeIdentifier
     */
    public CodeIdentifier getTaxFreeMethod() {
        return taxFreeMethod;
    }

    /**
     * Mutator for property taxFreeMethod.
     * 
     * @return taxFreeMethod of type CodeIdentifier
     */
    @XmlElement(name = "taxFreeMethod")
    public void setTaxFreeMethod(CodeIdentifier taxFreeMethod) {
        this.taxFreeMethod = taxFreeMethod;
    }

    /**
     * Accessor for property revAnnuitantRelationship.
     * 
     * @return revAnnuitantRelationship of type CodeIdentifier
     */
    public CodeIdentifier getRevAnnuitantRelationship() {
        return revAnnuitantRelationship;
    }

    /**
     * Mutator for property revAnnuitantRelationship.
     * 
     * @return revAnnuitantRelationship of type CodeIdentifier
     */
    @XmlElement(name = "revAnnuitantRelationship")
    public void setRevAnnuitantRelationship(CodeIdentifier revAnnuitantRelationship) {
        this.revAnnuitantRelationship = revAnnuitantRelationship;
    }

    /**
     * Accessor for property pensionStartDate.
     * 
     * @return pensionStartDate of type String
     */
    public String getPensionStartDate() {
        return pensionStartDate;
    }

    /**
     * Mutator for property pensionStartDate.
     * 
     * @return pensionStartDate of type String
     */
    @XmlElement(name = "pensionStartDate")
    public void setPensionStartDate(String pensionStartDate) {
        this.pensionStartDate = pensionStartDate != null ? pensionStartDate : "";
    }

    /**
     * Accessor for property paymentDate1.
     * 
     * @return paymentDate1 of type String
     */
    public String getPaymentDate1() {
        return paymentDate1;
    }

    /**
     * Mutator for property paymentDate1.
     * 
     * @return paymentDate1 of type String
     */
    @XmlElement(name = "paymentDate1")
    public void setPaymentDate1(String paymentDate1) {
        this.paymentDate1 = paymentDate1 != null ? paymentDate1 : "";
    }

    /**
     * Accessor for property paymentDate2.
     * 
     * @return paymentDate2 of type String
     */
    public String getPaymentDate2() {
        return paymentDate2;
    }

    /**
     * Mutator for property paymentDate2.
     * 
     * @return paymentDate2 of type String
     */
    @XmlElement(name = "paymentDate2")
    public void setPaymentDate2(String paymentDate2) {
        this.paymentDate2 = paymentDate2 != null ? paymentDate2 : "";
    }

    /**
     * Accessor for property nextPaymentDue.
     * 
     * @return nextPaymentDue of type String
     */
    public String getNextPaymentDue() {
        return nextPaymentDue;
    }

    /**
     * Mutator for property nextPaymentDue.
     * 
     * @return nextPaymentDue of type String
     */
    @XmlElement(name = "nextPaymentDue")
    public void setNextPaymentDue(String nextPaymentDue) {
        this.nextPaymentDue = nextPaymentDue != null ? nextPaymentDue : "";
    }

    /**
     * Accessor for property nominatedIndexRate.
     * 
     * @return nominatedIndexRate of type String
     */
    public String getNominatedIndexRate() {
        return nominatedIndexRate;
    }

    /**
     * Mutator for property nominatedIndexRate.
     * 
     * @return nominatedIndexRate of type String
     */
    @XmlElement(name = "nominatedIndexRate")
    public void setNominatedIndexRate(String nominatedIndexRate) {
        this.nominatedIndexRate = nominatedIndexRate != null ? nominatedIndexRate : "";
    }

    /**
     * Accessor for property additionalTax.
     * 
     * @return additionalTax of type String
     */
    public String getAdditionalTax() {
        return additionalTax;
    }

    /**
     * Mutator for property additionalTax.
     * 
     * @return additionalTax of type String
     */
    @XmlElement(name = "additionalTax")
    public void setAdditionalTax(String additionalTax) {
        this.additionalTax = additionalTax != null ? additionalTax : "";
    }

    /**
     * Accessor for property nextReviewDate.
     * 
     * @return nextReviewDate of type String
     */
    public String getNextReviewDate() {
        return nextReviewDate;
    }

    /**
     * Mutator for property nextReviewDate.
     * 
     * @return nextReviewDate of type String
     */
    @XmlElement(name = "nextReviewDate")
    public void setNextReviewDate(String nextReviewDate) {
        this.nextReviewDate = nextReviewDate != null ? nextReviewDate : "";
    }

    /**
     * Accessor for property taxFreeProportion.
     * 
     * @return taxFreeProportion of type String
     */
    public String getTaxFreeProportion() {
        return taxFreeProportion;
    }

    /**
     * Mutator for property taxFreeProportion.
     * 
     * @return taxFreeProportion of type String
     */
    @XmlElement(name = "taxFreeProportion")
    public void setTaxFreeProportion(String taxFreeProportion) {
        this.taxFreeProportion = taxFreeProportion != null ? taxFreeProportion : "";
    }

    /**
     * Accessor for property annualNominatedPercent.
     * 
     * @return annualNominatedPercent of type String
     */
    public String getAnnualNominatedPercent() {
        return annualNominatedPercent;
    }

    /**
     * Mutator for property annualNominatedPercent.
     * 
     * @return annualNominatedPercent of type String
     */
    @XmlElement(name = "annualNominatedPercent")
    public void setAnnualNominatedPercent(String annualNominatedPercent) {
        this.annualNominatedPercent = annualNominatedPercent != null ? annualNominatedPercent : "";
    }

    /**
     * Accessor for property claimRebate.
     * 
     * @return claimRebate of type String
     */
    public String getClaimRebate() {
        return claimRebate;
    }

    /**
     * Mutator for property claimRebate.
     * 
     * @return claimRebate of type String
     */
    @XmlElement(name = "claimRebate")
    public void setClaimRebate(String claimRebate) {
        this.claimRebate = claimRebate != null ? claimRebate : "";
    }

    /**
     * Accessor for property claimDeductible.
     * 
     * @return claimDeductible of type String
     */
    public String getClaimDeductible() {
        return claimDeductible;
    }

    /**
     * Mutator for property claimDeductible.
     * 
     * @return claimDeductible of type String
     */
    @XmlElement(name = "claimDeductible")
    public void setClaimDeductible(String claimDeductible) {
        this.claimDeductible = claimDeductible != null ? claimDeductible : "";
    }

    /**
     * Accessor for property carryForwardDeductible.
     * 
     * @return carryForwardDeductible of type String
     */
    public String getCarryForwardDeductible() {
        return carryForwardDeductible;
    }

    /**
     * Mutator for property carryForwardDeductible.
     * 
     * @return carryForwardDeductible of type String
     */
    @XmlElement(name = "carryForwardDeductible")
    public void setCarryForwardDeductible(String carryForwardDeductible) {
        this.carryForwardDeductible = carryForwardDeductible != null ? carryForwardDeductible : "";
    }

    /**
     * Accessor for property ttr.
     * 
     * @return ttr of type String
     */
    public String getTtr() {
        return ttr;
    }

    /**
     * Mutator for property ttr.
     * 
     * @return ttr of type String
     */
    @XmlElement(name = "ttr")
    public void setTtr(String ttr) {
        this.ttr = ttr != null ? ttr : "";
    }

    /**
     * Accessor for property annualPension.
     * 
     * @return annualPension of type String
     */
    public String getAnnualPension() {
        return annualPension;
    }

    /**
     * Mutator for property annualPension.
     * 
     * @param annualPension of type String
     */
    @XmlElement(name = "annualPension")
    public void setAnnualPension(String annualPension) {
        this.annualPension = annualPension != null ? annualPension : "";
    }

    /**
     * Accessor for property regularPension.
     * 
     * @return regularPension of type String
     */
    public String getRegularPension() {
        return regularPension;
    }

    /**
     * Mutator for property regularPension.
     * 
     * @param regularPension of type String
     */
    @XmlElement(name = "regularPension")
    public void setRegularPension(String regularPension) {
        this.regularPension = regularPension != null ? regularPension : "";
    }

    /**
     * Accessor for property purchasePrice.
     * 
     * @return purchasePrice of type String
     */
    public String getPurchasePrice() {
        return purchasePrice;
    }

    /**
     * Mutator for property purchasePrice.
     * 
     * @param purchasePrice of type String
     */
    @XmlElement(name = "purchasePrice")
    public void setPurchasePrice(String purchasePrice) {
        this.purchasePrice = purchasePrice != null ? purchasePrice : "";
    }

    /**
     * Accessor for property minimumAnnualPension.
     * 
     * @return minimumAnnualPension of type String
     */
    public String getMinimumAnnualPension() {
        return minimumAnnualPension;
    }

    /**
     * Mutator for property minimumAnnualPension.
     * 
     * @param minimumAnnualPension of type String
     */
    @XmlElement(name = "minimumAnnualPension")
    public void setMinimumAnnualPension(String minimumAnnualPension) {
        this.minimumAnnualPension = minimumAnnualPension != null ? minimumAnnualPension : "";
    }

    /**
     * Accessor for property maximumAnnualPension.
     * 
     * @return maximumAnnualPension of type String
     */
    public String getMaximumAnnualPension() {
        return maximumAnnualPension;
    }

    /**
     * Mutator for property maximumAnnualPension.
     * 
     * @param maximumAnnualPension of type String
     */
    @XmlElement(name = "maximumAnnualPension")
    public void setMaximumAnnualPension(String maximumAnnualPension) {
        this.maximumAnnualPension = maximumAnnualPension != null ? maximumAnnualPension : "";
    }

    /**
     * Accessor for property grossAnnualisedIncome.
     * 
     * @return grossAnnualisedIncome of type String
     */
    public String getGrossAnnualisedIncome() {
        return grossAnnualisedIncome;
    }

    /**
     * Mutator for property grossAnnualisedIncome.
     * 
     * @param grossAnnualisedIncome of type String
     */
    @XmlElement(name = "grossAnnualisedIncome")
    public void setGrossAnnualisedIncome(String grossAnnualisedIncome) {
        this.grossAnnualisedIncome = grossAnnualisedIncome != null ? grossAnnualisedIncome : "";
    }

    /**
     * Accessor for property ytdGrossPaidAmount.
     * 
     * @return ytdGrossPaidAmount of type String
     */
    public String getYtdGrossPaidAmount() {
        return ytdGrossPaidAmount;
    }

    /**
     * Mutator for property ytdGrossPaidAmount.
     * 
     * @param ytdGrossPaidAmount of type String
     */
    @XmlElement(name = "ytdGrossPaidAmount")
    public void setYtdGrossPaidAmount(String ytdGrossPaidAmount) {
        this.ytdGrossPaidAmount = ytdGrossPaidAmount != null ? ytdGrossPaidAmount : "";
    }

    /**
     * Accessor for property ytdNetPaidAmount.
     * 
     * @return ytdNetPaidAmount of type String
     */
    public String getYtdNetPaidAmount() {
        return ytdNetPaidAmount;
    }

    /**
     * Mutator for property ytdNetPaidAmount.
     * 
     * @param ytdNetPaidAmount of type String
     */
    @XmlElement(name = "ytdNetPaidAmount")
    public void setYtdNetPaidAmount(String ytdNetPaidAmount) {
        this.ytdNetPaidAmount = ytdNetPaidAmount != null ? ytdNetPaidAmount : "";
    }

    /**
     * Accessor for property setAmount.
     * 
     * @return setAmount of type String
     */
    public String getSetAmount() {
        return setAmount;
    }

    /**
     * Mutator for property setAmount.
     * 
     * @param setAmount of type String
     */
    @XmlElement(name = "setAmount")
    public void setSetAmount(String setAmount) {
        this.setAmount = setAmount != null ? setAmount : "";
    }

    /**
     * Accessor for property remainingTerm.
     * 
     * @return remainingTerm of type String
     */
    public String getRemainingTerm() {
        return remainingTerm;
    }

    /**
     * Mutator for property remainingTerm.
     * 
     * @param remainingTerm of type String
     */
    @XmlElement(name = "remainingTerm")
    public void setRemainingTerm(String remainingTerm) {
        this.remainingTerm = remainingTerm != null ? remainingTerm : "";
    }

    /**
     * Accessor for property newMinimumAmount.
     * 
     * @return newMinimumAmount of type String
     */
    public String getNewMinimumAmount() {
        return newMinimumAmount;
    }

    /**
     * Mutator for property newMinimumAmount.
     * 
     * @param newMinimumAmount of type String
     */
    @XmlElement(name = "newMinimumAmount")
    public void setNewMinimumAmount(String newMinimumAmount) {
        this.newMinimumAmount = newMinimumAmount != null ? newMinimumAmount : "";
    }

    /**
     * Accessor for property newMaximumAmount.
     * 
     * @return newMaximumAmount of type String
     */
    public String getNewMaximumAmount() {
        return newMaximumAmount;
    }

    /**
     * Mutator for property newMaximumAmount.
     * 
     * @param newMaximumAmount of type String
     */
    @XmlElement(name = "newMaximumAmount")
    public void setNewMaximumAmount(String newMaximumAmount) {
        this.newMaximumAmount = newMaximumAmount != null ? newMaximumAmount : "";
    }

    /**
     * Accessor for property depositBalance.
     * 
     * @return depositBalance of type String
     */
    public String getDepositBalance() {
        return depositBalance;
    }

    /**
     * Mutator for property depositBalance.
     * 
     * @param depositBalance of type String
     */
    @XmlElement(name = "depositBalance")
    public void setDepositBalance(String depositBalance) {
        this.depositBalance = depositBalance != null ? depositBalance : "";
    }
}
