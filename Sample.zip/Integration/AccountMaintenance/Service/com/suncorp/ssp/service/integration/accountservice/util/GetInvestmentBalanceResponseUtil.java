////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

import com.sonatacentral.service.v30.globaltypes.wrap.transaction.transactiongrouptype.TransSummaryDetailType;
import com.sonatacentral.service.v30.wrap.account.GetAccountTransactionSummaryResponseType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.GetInvestmentBalanceResponseBean;
import com.suncorp.ssp.service.integration.accountservice.bean.TransSummaryDetail;

/**
 * The class {@code GetInvestmentBalanceResponseUtil} is a Utility class with all the properties related to GetInvestmentBalanceResponse to construct
 * response for end client.
 * 
 * @author U384381
 * @since 30/12/2015
 * @version 1.0
 */
public class GetInvestmentBalanceResponseUtil {
    private final String className = "GetInvestmentBalanceResponseUtil";

    private GetAccountTransactionSummaryResponseType inboundResponse;
    private GetInvestmentBalanceResponseBean outboundResponse;

    private TransSummaryDetailType transSummaryDetailType;
    private String unitPriceEffDate;
    private BigDecimal totalOpeningBalance;
    private BigDecimal totalClosingBalance;

    /**
     * Initialises class properties, viz., inbound and outbound request types.
     * 
     * @param inboundResponse of type GetAccountTransactionSummaryResponseType
     */

    public GetInvestmentBalanceResponseUtil(GetAccountTransactionSummaryResponseType inboundResponse) {
        this.inboundResponse = inboundResponse;
        this.outboundResponse = new GetInvestmentBalanceResponseBean();
    }

    /**
     * Returns the outbound response object after setting the applicable parameters.
     * 
     * @return outboundResponse of type GetInvestmentBalanceResponseBean
     * @throws SILException
     */
    public GetInvestmentBalanceResponseBean createOutboundResponse() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_INVESTMENT_BAL_LOG_FORMAT, className, "Entering createOutboundResponse()");
        this.outboundResponse.setTransSummaryDetails(createTransSummaryDetailList());
        this.outboundResponse.setTotalOpeningBalance(createTotalOpeningBalance());
        this.outboundResponse.setTotalClosingBalance(createTotalClosingBalance());
        SILLogger.debug(AccountServiceConstants.GET_INVESTMENT_BAL_LOG_FORMAT, className, "Exiting createOutboundResponse()");
        return outboundResponse;
    }

    /**
     * Creates an outbound ArrayList with values extracted from the external service's response. Iterates over the list received in the response and
     * feeds those values to the outbound list. If the list received in response is empty, it just returns a default list with blank values.
     * 
     * @return outboundList of type List<TransSummaryDetail>
     * @throws SILException
     */
    private List<TransSummaryDetail> createTransSummaryDetailList() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_INVESTMENT_BAL_LOG_FORMAT, className, "Entering createTransSummaryDetailList()");
        List<TransSummaryDetail> outboundList = null;
        List<TransSummaryDetailType> inboundList = this.inboundResponse.getTransSummDetail();
        if (!SILUtil.isEmpty(this.inboundResponse.getTransSummDetail())) {
            this.totalOpeningBalance = BigDecimal.ZERO;
            this.totalClosingBalance = BigDecimal.ZERO;
            outboundList = new ArrayList<TransSummaryDetail>();
            int inboundListSize = inboundList.size();
            for (int index = 0; index < inboundListSize; index++) {
                this.transSummaryDetailType = inboundList.get(index);
                this.totalOpeningBalance = this.totalOpeningBalance.add(this.transSummaryDetailType.getOpeningBalanceAmount());
                this.totalClosingBalance = this.totalClosingBalance.add(this.transSummaryDetailType.getClosingBalanceAmount());
                addTransSummaryDetailToList(outboundList);
            }
            addFundPercentageToList(outboundList);
        } else {
            throw new SILException(AccountServiceConstants.GET_INVESTMENT_BAL_RECORD_NOT_EXIST);
        }
        SILLogger.debug(AccountServiceConstants.GET_INVESTMENT_BAL_LOG_FORMAT, className, "Exiting createTransSummaryDetailList()");
        return outboundList;
    }

    /**
     * Adds the percentage of the individual funds by calculating it, to the outbound response list. The percentage for the last element is derived by
     * subtracting the sum of all the percentages upto (n-1) funds from 100.
     * 
     * @param outboundList of type List<TransSummaryDetail>
     */
    private void addFundPercentageToList(List<TransSummaryDetail> outboundList) {
        SILLogger.debug(AccountServiceConstants.GET_INVESTMENT_BAL_LOG_FORMAT, className, "Entering addFundPercentageToList()");
        BigDecimal closingBalance = BigDecimal.ZERO;
        BigDecimal closingPercent = BigDecimal.ZERO;
        BigDecimal totalClosingPercent = BigDecimal.ZERO;
        int outboundListSize = outboundList.size();

        for (int index = 0; index < outboundListSize; index++) {
            closingBalance = new BigDecimal(outboundList.get(index).getClosingBalanceAmount());
            closingPercent = closingBalance.divide(this.totalClosingBalance, 4, RoundingMode.HALF_DOWN).multiply(new BigDecimal(100));
            outboundList.get(index).setPercentage(String.valueOf(closingPercent));
            totalClosingPercent = index < outboundListSize - 1 ? totalClosingPercent.add(closingPercent) : totalClosingPercent;
        }
        outboundList.get(outboundListSize - 1).setPercentage(String.valueOf(new BigDecimal(100).subtract(totalClosingPercent)));
        SILLogger.debug(AccountServiceConstants.GET_INVESTMENT_BAL_LOG_FORMAT, className, "Exiting addFundPercentageToList()");
    }

    /**
     * Creates a new TransSummaryDetail and adds it to the outbound ArrayList with values extracted from the external service's response.
     * 
     * @param index of type int
     * @param inboundListSize of type int
     * @param outboundList of type List<TransSummaryDetail>
     */
    private void addTransSummaryDetailToList(List<TransSummaryDetail> outboundList) {
        SILLogger.debug(AccountServiceConstants.GET_INVESTMENT_BAL_LOG_FORMAT, className, "Entering createTransSummaryDetailList()");
        TransSummaryDetail outboundTransDetail = new TransSummaryDetail();
        outboundTransDetail.setId(getId());
        outboundTransDetail.setFundFullName(getFundFullName());
        outboundTransDetail.setUnitPriceEffectiveDate(getUnitPriceEffectiveDate());
        outboundTransDetail.setOpeningBalanceAmount(getOpeningBalanceAmount());
        outboundTransDetail.setClosingBalanceAmount(getClosingBalanceAmount());
        outboundTransDetail.setOpeningPrice(getOpeningPrice());
        outboundTransDetail.setClosingPrice(getClosingPrice());
        outboundTransDetail.setOpeningUnits(getOpeningUnits());
        outboundTransDetail.setClosingUnits(getClosingUnits());
        outboundList.add(outboundTransDetail);
        SILLogger.debug(AccountServiceConstants.GET_INVESTMENT_BAL_LOG_FORMAT, className, "Exiting createTransSummaryDetailList()");
    }

    /**
     * Sets the unitPriceEffDate which would be inserted later into the response object. This is because we do not get this date from the external
     * service's response, hence we are inserting the same one which was passed into the request.
     * 
     * @param unitPriceEffDate of type String
     */
    public void setUnitPriceEffDate(String unitPriceEffDate) {
        this.unitPriceEffDate = unitPriceEffDate;
    }

    /**
     * Accessor for property id.
     * 
     * @return id of type String
     */
    private String getId() {
        return this.transSummaryDetailType.getFund().getId() != null ? String.valueOf(this.transSummaryDetailType.getFund().getId()) : "";
    }

    /**
     * Accessor for property fundFullName.
     * 
     * @return fundFullName of type String
     */
    private String getFundFullName() {
        return this.transSummaryDetailType.getFund().getFundFullName() != null ? String.valueOf(this.transSummaryDetailType.getFund()
                .getFundFullName()) : "";
    }

    /**
     * Accessor for property unitPriceEffectiveDate.
     * 
     * @return unitPriceEffectiveDate of type String
     */
    private String getUnitPriceEffectiveDate() {
        return this.unitPriceEffDate != null ? this.unitPriceEffDate : "";
    }

    /**
     * Accessor for property openingBalanceAmount.
     * 
     * @return openingBalanceAmount of type String
     */
    private String getOpeningBalanceAmount() {
        return this.transSummaryDetailType.getOpeningBalanceAmount() != null ? this.transSummaryDetailType.getOpeningBalanceAmount().toString() : "";
    }

    /**
     * Accessor for property closingBalanceAmount.
     * 
     * @return closingBalanceAmount of type String
     */
    private String getClosingBalanceAmount() {
        return this.transSummaryDetailType.getClosingBalanceAmount() != null ? this.transSummaryDetailType.getClosingBalanceAmount().toString() : "";
    }

    /**
     * Accessor for property openingPrice.
     * 
     * @return openingPrice of type String
     */
    private String getOpeningPrice() {
        return this.transSummaryDetailType.getOpeningPrice() != null ? this.transSummaryDetailType.getOpeningPrice().toString() : "";
    }

    /**
     * Accessor for property closingPrice.
     * 
     * @return closingPrice of type String
     */
    private String getClosingPrice() {
        return this.transSummaryDetailType.getClosingPrice() != null ? this.transSummaryDetailType.getClosingPrice().toString() : "";
    }

    /**
     * Accessor for property openingUnits.
     * 
     * @return openingUnits of type String
     */
    private String getOpeningUnits() {
        return this.transSummaryDetailType.getOpeningUnits() != null ? this.transSummaryDetailType.getOpeningUnits().toString() : "";
    }

    /**
     * Accessor for property closingUnits.
     * 
     * @return closingUnits of type String
     */
    private String getClosingUnits() {
        return this.transSummaryDetailType.getClosingUnits() != null ? this.transSummaryDetailType.getClosingUnits().toString() : "";
    }

    /**
     * Accessor for property totalOpeningBalance.
     * 
     * @return totalOpeningBalance of type String
     */
    private String createTotalOpeningBalance() {
        return this.totalOpeningBalance != null ? this.totalOpeningBalance.toString() : "";
    }

    /**
     * Accessor for property totalClosingBalance.
     * 
     * @return totalClosingBalance of type String
     */
    private String createTotalClosingBalance() {
        return this.totalClosingBalance != null ? this.totalClosingBalance.toString() : "";
    }
}
