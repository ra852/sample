////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
* The class {@code DefaultInsuranceStatus} does this.
* 
* @author U385424
* @since 11/09/2017
* @version 1.0
*/
public class DefaultInsuranceStatusDetail {
private String optOut;
private RiderTemplate riderTemplate;

/**
* Accessor for property optOut.
* 
* @return optOut of type String
*/
public String getOptOut() {
return optOut;
}

/**
* Mutator for property optOut.
* 
* @param optOut of type String
*/
@XmlElement(name = "optOut")
public void setOptOut(String optOut) {
this.optOut = optOut;
}

/**
* Accessor for property riderTemplate.
* 
* @return riderTemplate of type RiderTemplate
*/
public RiderTemplate getRiderTemplate() {
return riderTemplate;
}

/**
* Mutator for property riderTemplate.
* 
* @param riderTemplate of type RiderTemplate
*/
@XmlElement(name = "riderTemplate")
public void setRiderTemplate(RiderTemplate riderTemplate) {
this.riderTemplate = riderTemplate;
}

}
