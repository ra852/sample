////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.suncorp.ssp.common.bean.SILErrorMessage;

/**
 * The class {@code GetSwitchStatusResponseBean} is a java bean consisting of all the properties related to GetSwitchSttaus
 * functionality, to be used for constructing response for end-client.
 * 
 * @author u385424
 * @since 28/07/2016
 * @version 1.0
 */
@XmlRootElement(name = "GetSwitchStatusResponse")
public class GetSwitchStatusResponseBean extends SILErrorMessage {

    private List<TransEventDetails> transEvtDetail;
    private PagingRange pagingRange;

    /**
     * Accessor for property transEvtDetail.
     * 
     * @return transEvtDetail of type List<TransEventDetails>
     */
    public List<TransEventDetails> getTransEvtDetail() {
        return transEvtDetail;
    }

    /**
     * Mutator for property transEvtDetail.
     * 
     * @return transEvtDetail of type List<TransEventDetails>
     */
    @XmlElement(name = "transEvtDetail")
    public void setTransEvtDetail(List<TransEventDetails> transEvtDetail) {
        this.transEvtDetail = transEvtDetail;
    }

    /**
     * Accessor for property pagingRange.
     * 
     * @return pagingRange of type PagingRange
     */
    public PagingRange getPagingRange() {
        return pagingRange;
    }

    /**
     * Mutator for property pagingRange.
     * 
     * @return pagingRange of type PagingRange
     */
    @XmlElement(name = "pagingRangeType")
    public void setPagingRange(PagingRange pagingRange) {
        this.pagingRange = pagingRange;
    }

}
