////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code BenefitIdentifierDetails} is a java bean consisting of properties related to BenefitIdentifierDetails.
 * 
 * @author U385424
 * @since 17/02/2018
 * @version 1.0
 */
public class BenefitIdentifierDetails {

    private String id;
    private String name;
    private String benefitSequence;
    private BenefitTemplateIdentifierDetails benefitTemplate;

    /**
     * Accessor for property id.
     * 
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     * 
     * @param id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id != null ? id : "";
    }

    /**
     * Accessor for property name.
     * 
     * @return name of type String
     */
    public String getName() {
        return name;
    }

    /**
     * Mutator for property name.
     * 
     * @param name of type String
     */
    @XmlElement(name = "name")
    public void setName(String name) {
        this.name = name != null ? name : "";
    }

    /**
     * Accessor for property benefitSequence.
     * 
     * @return benefitSequence of type String
     */
    public String getBenefitSequence() {
        return benefitSequence;
    }

    /**
     * Mutator for property benefitSequence.
     * 
     * @param benefitSequence of type String
     */
    @XmlElement(name = "benefitSequence")
    public void setBenefitSequence(String benefitSequence) {
        this.benefitSequence = benefitSequence != null ? benefitSequence : "";
    }

    /**
     * Accessor for property benefitTemplate.
     * 
     * @return benefitTemplate of type BenefitTemplateIdentifierDetails
     */
    public BenefitTemplateIdentifierDetails getBenefitTemplate() {
        return benefitTemplate;
    }

    /**
     * Mutator for property benefitTemplate.
     * 
     * @param benefitTemplate of type BenefitTemplateIdentifierDetails
     */
    @XmlElement(name = "benefitTemplate")
    public void setBenefitTemplate(BenefitTemplateIdentifierDetails benefitTemplate) {
        this.benefitTemplate = benefitTemplate;
    }
}
