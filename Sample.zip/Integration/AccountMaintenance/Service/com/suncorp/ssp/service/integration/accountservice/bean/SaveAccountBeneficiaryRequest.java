////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * The class {@code SaveAccountBeneficiaryRequest} is used as request bean of save account beneficiary.
 * 
 * @author U383754
 * @since 10/11/2015
 * @version 1.0
 */
@XmlRootElement(name = "SaveAccountBeneficiaryRequest")
public class SaveAccountBeneficiaryRequest {
    private String accountNumber;
    private String productName;
    private String accountExtReference;
    private String accountExtReferenceCode;
    private String accountExtReferenceDeleteFlag;
    private String statusId;
    private String statusCode;
    private String statusCodeType;
    private String statusCodeShortDescription;
    private String statusCodeDescription;
    private String masterSchemeDisplayName;
    private String masterSchemeLongName;
    private List<BeneficiaryDetails> beneficiary;
    private String deleteAll;

    /**
     * Accessor for property accountNumber.
     * 
     * @return accountNumber of type String
     */
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * Mutator for property accountNumber.
     * 
     * @return accountNumber of type String
     */
    @XmlElement(name = "accountNumber")
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber != null ? accountNumber : "";
    }

    /**
     * Accessor for property productName.
     * 
     * @return productName of type String
     */
    public String getProductName() {
        return productName;
    }

    /**
     * Mutator for property productName.
     * 
     * @return productName of type String
     */
    @XmlElement(name = "productName")
    public void setProductName(String productName) {
        this.productName = productName != null ? productName : "";
    }

    /**
     * Accessor for property accountExtReference.
     * 
     * @return accountExtReference of type String
     */
    public String getAccountExtReference() {
        return accountExtReference;
    }

    /**
     * Mutator for property accountExtReference.
     * 
     * @return accountExtReference of type String
     */
    @XmlElement(name = "accountExtReference")
    public void setAccountExtReference(String accountExtReference) {
        this.accountExtReference = accountExtReference != null ? accountExtReference : "";
    }

    /**
     * Accessor for property accountExtReferenceCode.
     * 
     * @return accountExtReferenceCode of type String
     */
    public String getAccountExtReferenceCode() {
        return accountExtReferenceCode;
    }

    /**
     * Mutator for property accountExtReferenceCode.
     * 
     * @return accountExtReferenceCode of type String
     */
    @XmlElement(name = "accountExtReferenceCode")
    public void setAccountExtReferenceCode(String accountExtReferenceCode) {
        this.accountExtReferenceCode = accountExtReferenceCode != null ? accountExtReferenceCode : "";
    }

    /**
     * Accessor for property accountExtReferenceDeleteFlag.
     * 
     * @return accountExtReferenceDeleteFlag of type String
     */
    public String getAccountExtReferenceDeleteFlag() {
        return accountExtReferenceDeleteFlag;
    }

    /**
     * Mutator for property accountExtReferenceDeleteFlag.
     * 
     * @return accountExtReferenceDeleteFlag of type String
     */
    @XmlElement(name = "accountExtReferenceDeleteFlag")
    public void setAccountExtReferenceDeleteFlag(String accountExtReferenceDeleteFlag) {
        this.accountExtReferenceDeleteFlag = accountExtReferenceDeleteFlag != null ? accountExtReferenceDeleteFlag : "";
    }

    /**
     * Accessor for property statusId.
     * 
     * @return statusId of type String
     */
    public String getStatusId() {
        return statusId;
    }

    /**
     * Mutator for property statusId.
     * 
     * @return statusId of type String
     */
    @XmlElement(name = "statusId")
    public void setStatusId(String statusId) {
        this.statusId = statusId != null ? statusId : "";
    }

    /**
     * Accessor for property statusCode.
     * 
     * @return statusCode of type String
     */
    public String getStatusCode() {
        return statusCode;
    }

    /**
     * Mutator for property statusCode.
     * 
     * @return statusCode of type String
     */
    @XmlElement(name = "statusCode")
    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode != null ? statusCode : "";
    }

    /**
     * Accessor for property statusCodeType.
     * 
     * @return statusCodeType of type String
     */
    public String getStatusCodeType() {
        return statusCodeType;
    }

    /**
     * Mutator for property statusCodeType.
     * 
     * @return statusCodeType of type String
     */
    @XmlElement(name = "statusCodeType")
    public void setStatusCodeType(String statusCodeType) {
        this.statusCodeType = statusCodeType != null ? statusCodeType : "";
    }

    /**
     * Accessor for property statusCodeShortDescription.
     * 
     * @return statusCodeShortDescription of type String
     */
    public String getStatusCodeShortDescription() {
        return statusCodeShortDescription;
    }

    /**
     * Mutator for property statusCodeShortDescription.
     * 
     * @return statusCodeShortDescription of type String
     */
    @XmlElement(name = "statusCodeShortDescription")
    public void setStatusCodeShortDescription(String statusCodeShortDescription) {
        this.statusCodeShortDescription = statusCodeShortDescription != null ? statusCodeShortDescription : "";
    }

    /**
     * Accessor for property statusCodeDescription.
     * 
     * @return statusCodeDescription of type String
     */
    public String getStatusCodeDescription() {
        return statusCodeDescription;
    }

    /**
     * Mutator for property statusCodeDescription.
     * 
     * @return statusCodeDescription of type String
     */
    @XmlElement(name = "statusCodeDescription")
    public void setStatusCodeDescription(String statusCodeDescription) {
        this.statusCodeDescription = statusCodeDescription != null ? statusCodeDescription : "";
    }

    /**
     * Accessor for property masterSchemeDisplayName.
     * 
     * @return masterSchemeDisplayName of type String
     */
    public String getMasterSchemeDisplayName() {
        return masterSchemeDisplayName;
    }

    /**
     * Mutator for property masterSchemeDisplayName.
     * 
     * @return masterSchemeDisplayName of type String
     */
    @XmlElement(name = "masterSchemeDisplayName")
    public void setMasterSchemeDisplayName(String masterSchemeDisplayName) {
        this.masterSchemeDisplayName = masterSchemeDisplayName != null ? masterSchemeDisplayName : "";
    }

    /**
     * Accessor for property masterSchemeLongName.
     * 
     * @return masterSchemeLongName of type String
     */
    public String getMasterSchemeLongName() {
        return masterSchemeLongName;
    }

    /**
     * Mutator for property masterSchemeLongName.
     * 
     * @return masterSchemeLongName of type String
     */
    @XmlElement(name = "masterSchemeLongName")
    public void setMasterSchemeLongName(String masterSchemeLongName) {
        this.masterSchemeLongName = masterSchemeLongName != null ? masterSchemeLongName : "";
    }

    /**
     * Accessor for property beneficiary.
     * 
     * @return beneficiary of type List<BeneficiaryDetails>
     */
    public List<BeneficiaryDetails> getBeneficiary() {
        return beneficiary;
    }

    /**
     * Mutator for property beneficiary.
     * 
     * @return beneficiary of type List<BeneficiaryDetails>
     */
    @XmlElement(name = "beneficiary")
    public void setBeneficiary(List<BeneficiaryDetails> beneficiary) {
        this.beneficiary = beneficiary;
    }

    /**
     * Accessor for property deleteAll.
     *
     * @return deleteAll of type String
     */
    public String getDeleteAll() {
        return deleteAll;
    }

    /**
     * Mutator for property deleteAll.
     *
     * @param deleteAll of type String
     */
    @XmlElement(name = "deleteAll")
    public void setDeleteAll(String deleteAll) {
        this.deleteAll = deleteAll;
    }
    
}
