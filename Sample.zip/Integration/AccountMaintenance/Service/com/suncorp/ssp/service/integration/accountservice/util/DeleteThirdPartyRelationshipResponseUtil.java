////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import com.sonatacentral.service.v30.wrap.account.SaveAccountResponseType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.DeleteThirdPartyRelationshipResponse;

/**
 * The class {@code DeleteThirdPartyRelationshipResponseUtil} is used as a util class for preparing DeleteThirdPartyRelationship response.
 * 
 * @author u385424
 * @since 17/03/2016
 * @version 1.0
 */
public class DeleteThirdPartyRelationshipResponseUtil {
    private final String className = "DeleteThirdPartyRelationshipResponseUtil";
    private SaveAccountResponseType inboundResponse;
    private DeleteThirdPartyRelationshipResponse outboundResponse;

    /**
     * Initialises class properties,viz., inbound and outbound response types.
     * 
     * @param inboundResponse of type SaveAccountResponseType
     */
    public DeleteThirdPartyRelationshipResponseUtil(SaveAccountResponseType inboundResponse) {
        this.inboundResponse = inboundResponse;
        this.outboundResponse = new DeleteThirdPartyRelationshipResponse();
    }

    /**
     * Returns the outbound response object after setting the parameters.
     * 
     * @return outboundResponse of type DeleteThirdPartyRelationshipResponse
     */
    public DeleteThirdPartyRelationshipResponse createOutboundResponse() {
        SILLogger.debug(AccountServiceConstants.DEL_THIRD_PARTY_REL_LOG_FORMAT, className, "createOutboundResponse()");
        if (inboundResponse != null && inboundResponse.getAccount() != null && inboundResponse.getAccount().getAccountNumber() != null &&
                inboundResponse.getAccount().getAccountNumber().getAccountNo() != null) {
            outboundResponse.setStatus(CommonConstants.SUCCESS);
        }
        return outboundResponse;
    }

}
