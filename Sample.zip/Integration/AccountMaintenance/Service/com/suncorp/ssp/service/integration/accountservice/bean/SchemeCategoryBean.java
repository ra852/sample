////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;
/**
 * The class {@code SchemeCategoryBean} does this.
 * 
 * @author U387938
 * @since 02/02/2016
 * @version 1.0
 */
public class SchemeCategoryBean {

    private String id;
    private String name;
    private SchemeIdentifier scheme;
    private String longName;
    private AuditIdentifier audit;
    /**
     * Accessor for property id.
     *
     * @return id of type String
     */
    public String getId() {
        return id;
    }
    /**
     * Mutator for property id.
     *
     * @param id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id != null ? id : "";
    }
    /**
     * Accessor for property name.
     *
     * @return name of type String
     */
    public String getName() {
        return name;
    }
    /**
     * Mutator for property name.
     *
     * @param name of type String
     */
    @XmlElement(name = "name")
    public void setName(String name) {
        this.name = name != null ? name : "";
    }
    /**
     * Accessor for property scheme.
     *
     * @return scheme of type SchemeIdentifier
     */
    public SchemeIdentifier getScheme() {
        return scheme;
    }
    /**
     * Mutator for property scheme.
     *
     * @param scheme of type SchemeIdentifier
     */
    @XmlElement(name = "scheme")
    public void setScheme(SchemeIdentifier scheme) {
        this.scheme = scheme;
    }
    /**
     * Accessor for property longName.
     *
     * @return longName of type String
     */
    public String getLongName() {
        return longName;
    }
    /**
     * Mutator for property longName.
     *
     * @param longName of type String
     */
    @XmlElement(name = "longName")
    public void setLongName(String longName) {
        this.longName = longName != null ? longName : "";
    }
    /**
     * Accessor for property audit.
     *
     * @return audit of type AuditIdentifier
     */
    public AuditIdentifier getAudit() {
        return audit;
    }
    /**
     * Mutator for property audit.
     *
     * @param audit of type AuditIdentifier
     */
    @XmlElement(name = "audit")
    public void setAudit(AuditIdentifier audit) {
        this.audit = audit;
    }
    
    
}
