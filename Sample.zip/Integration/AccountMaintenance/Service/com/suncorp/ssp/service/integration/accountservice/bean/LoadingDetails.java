////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code LoadingDetails} does this.
 * 
 * @author U385424
 * @since 17/02/2018
 * @version 1.0
 */
public class LoadingDetails {

    private String partialTerm;
    private CodeIdentifier reason;
    private String type;
    private String dollarAmount;
    private String fixedLoadAmount;
    private String percLoadAmount;
    private String premium;
    private CodeIdentifier status;
    private String startDate;
    private String endDate;

    /**
     * Accessor for property partialTerm.
     * 
     * @return partialTerm of type String
     */
    public String getPartialTerm() {
        return partialTerm;
    }

    /**
     * Mutator for property partialTerm.
     * 
     * @return partialTerm of type String
     */
    @XmlElement(name = "partialTerm")
    public void setPartialTerm(String partialTerm) {
        this.partialTerm = partialTerm != null ? partialTerm : "";
    }

    /**
     * Accessor for property reason.
     * 
     * @return reason of type CodeIdentifier
     */
    public CodeIdentifier getReason() {
        return reason;
    }

    /**
     * Mutator for property reason.
     * 
     * @return reason of type CodeIdentifier
     */
    @XmlElement(name = "reason")
    public void setReason(CodeIdentifier reason) {
        this.reason = reason;
    }

    /**
     * Accessor for property type.
     * 
     * @return type of type String
     */
    public String getType() {
        return type;
    }

    /**
     * Mutator for property type.
     * 
     * @return type of type String
     */
    @XmlElement(name = "type")
    public void setType(String type) {
        this.type = type != null ? type : "";
    }

    /**
     * Accessor for property dollarAmount.
     * 
     * @return dollarAmount of type String
     */
    public String getDollarAmount() {
        return dollarAmount;
    }

    /**
     * Mutator for property dollarAmount.
     * 
     * @return dollarAmount of type String
     */
    @XmlElement(name = "dollarAmount")
    public void setDollarAmount(String dollarAmount) {
        this.dollarAmount = dollarAmount != null ? dollarAmount : "";
    }

    /**
     * Accessor for property fixedLoadAmount.
     * 
     * @return fixedLoadAmount of type String
     */
    public String getFixedLoadAmount() {
        return fixedLoadAmount;
    }

    /**
     * Mutator for property fixedLoadAmount.
     * 
     * @return fixedLoadAmount of type String
     */
    @XmlElement(name = "fixedLoadAmount")
    public void setFixedLoadAmount(String fixedLoadAmount) {
        this.fixedLoadAmount = fixedLoadAmount != null ? fixedLoadAmount : "";
    }

    /**
     * Accessor for property percLoadAmount.
     * 
     * @return percLoadAmount of type String
     */
    public String getPercLoadAmount() {
        return percLoadAmount;
    }

    /**
     * Mutator for property percLoadAmount.
     * 
     * @return percLoadAmount of type String
     */
    @XmlElement(name = "percLoadAmount")
    public void setPercLoadAmount(String percLoadAmount) {
        this.percLoadAmount = percLoadAmount != null ? percLoadAmount : "";
    }

    /**
     * Accessor for property premium.
     * 
     * @return premium of type String
     */
    public String getPremium() {
        return premium;
    }

    /**
     * Mutator for property premium.
     * 
     * @return premium of type String
     */
    @XmlElement(name = "premium")
    public void setPremium(String premium) {
        this.premium = premium != null ? premium : "";
    }

    /**
     * Accessor for property status.
     * 
     * @return status of type CodeIdentifier
     */
    public CodeIdentifier getStatus() {
        return status;
    }

    /**
     * Mutator for property status.
     * 
     * @return status of type CodeIdentifier
     */
    @XmlElement(name = "status")
    public void setStatus(CodeIdentifier status) {
        this.status = status;
    }

    /**
     * Accessor for property startDate.
     * 
     * @return startDate of type String
     */
    public String getStartDate() {
        return startDate;
    }

    /**
     * Mutator for property startDate.
     * 
     * @return startDate of type String
     */
    @XmlElement(name = "startDate")
    public void setStartDate(String startDate) {
        this.startDate = startDate != null ? startDate : "";
    }

    /**
     * Accessor for property endDate.
     * 
     * @return endDate of type String
     */
    public String getEndDate() {
        return endDate;
    }

    /**
     * Mutator for property endDate.
     * 
     * @return endDate of type String
     */
    @XmlElement(name = "endDate")
    public void setEndDate(String endDate) {
        this.endDate = endDate != null ? endDate : "";
    }
}
