////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code ExclusionDetails} does this.
 * 
 * @author U385424
 * @since 17/02/2018
 * @version 1.0
 */
public class ExclusionDetails {

    private CodeIdentifier category;
    private String shortDescription;
    private String longDescription;
    private String reviewTerm;
    private String exclusionFullText;

    /**
     * Accessor for property category.
     * 
     * @return category of type CodeIdentifier
     */
    public CodeIdentifier getCategory() {
        return category;
    }

    /**
     * Mutator for property category.
     * 
     * @return category of type CodeIdentifier
     */
    @XmlElement(name = "category")
    public void setCategory(CodeIdentifier category) {
        this.category = category;
    }

    /**
     * Accessor for property shortDescription.
     * 
     * @return shortDescription of type String
     */
    public String getShortDescription() {
        return shortDescription;
    }

    /**
     * Mutator for property shortDescription.
     * 
     * @return shortDescription of type String
     */
    @XmlElement(name = "shortDescription")
    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription != null ? shortDescription : "";
    }

    /**
     * Accessor for property longDescription.
     * 
     * @return longDescription of type String
     */
    public String getLongDescription() {
        return longDescription;
    }

    /**
     * Mutator for property longDescription.
     * 
     * @return longDescription of type String
     */
    @XmlElement(name = "longDescription")
    public void setLongDescription(String longDescription) {
        this.longDescription = longDescription != null ? longDescription : "";
    }

    /**
     * Accessor for property reviewTerm.
     * 
     * @return reviewTerm of type String
     */
    public String getReviewTerm() {
        return reviewTerm;
    }

    /**
     * Mutator for property reviewTerm.
     * 
     * @return reviewTerm of type String
     */
    @XmlElement(name = "reviewTerm")
    public void setReviewTerm(String reviewTerm) {
        this.reviewTerm = reviewTerm != null ? reviewTerm : "";
    }

    /**
     * Accessor for property exclusionFullText.
     * 
     * @return exclusionFullText of type String
     */
    public String getExclusionFullText() {
        return exclusionFullText;
    }

    /**
     * Mutator for property exclusionFullText.
     * 
     * @return exclusionFullText of type String
     */
    @XmlElement(name = "exclusionFullText")
    public void setExclusionFullText(String exclusionFullText) {
        this.exclusionFullText = exclusionFullText != null ? exclusionFullText : "";
    }
}
