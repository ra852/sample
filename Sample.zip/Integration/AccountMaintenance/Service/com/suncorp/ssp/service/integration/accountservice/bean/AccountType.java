////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code AccountType} does this.
 * 
 * @author U384381
 * @since 03/11/2015
 * @version 1.0
 */
public class AccountType {
    private String clientId;
    private String firstName;
    private String surname;
    private String accountNumber;
    private String productName;
    private CodeIdentifier status;
    
    /**
     * Accessor for property clientId.
     * 
     * @return clientId of type String
     */
    public String getClientId() {
        return clientId;
    }

    /**
     * Mutator for property clientId.
     * 
     * @return clientId of type String
     */
    public void setClientId(String clientId) {
        this.clientId = clientId;
    }

    /**
     * Accessor for property firstName.
     * 
     * @return firstName of type String
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Mutator for property firstName.
     * 
     * @return firstName of type String
     */
    @XmlElement(name = "firstName")
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * Accessor for property surname.
     * 
     * @return surname of type String
     */
    public String getSurname() {
        return surname;
    }

    /**
     * Mutator for property surname.
     * 
     * @return surname of type String
     */
    @XmlElement(name = "surname")
    public void setSurname(String surname) {
        this.surname = surname;
    }

    /**
     * Accessor for property accountNumber.
     * 
     * @return accountNumber of type String
     */
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * Mutator for property accountNumber.
     * 
     * @return accountNumber of type String
     */
    @XmlElement(name = "accountNumber")
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    /**
     * Accessor for property productName.
     * 
     * @return productName of type String
     */
    public String getProductName() {
        return productName;
    }

    /**
     * Mutator for property productName.
     * 
     * @return productName of type String
     */
    @XmlElement(name = "productName")
    public void setProductName(String productName) {
        this.productName = productName;
    }

    /**
     * Accessor for property status.
     *
     * @return status of type CodeIdentifier
     */
    public CodeIdentifier getStatus() {
        return status;
    }

    /**
     * Mutator for property status.
     *
     * @param status of type CodeIdentifier
     */
    @XmlElement(name = "status")
    public void setStatus(CodeIdentifier status) {
        this.status = status;
    }
}
