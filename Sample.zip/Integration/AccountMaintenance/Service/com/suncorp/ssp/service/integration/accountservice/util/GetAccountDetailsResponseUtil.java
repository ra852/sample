////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import java.util.Iterator;
import java.util.List;

import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.ExternalRefType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType;
import com.sonatacentral.service.v30.wrap.account.GetAccountDetailsResponseType;
import com.sonatacentral.service.v30.wrap.account.GetAccountDetailsResponseType.AccountDetails;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.GetAccountDetailsResponse;

/**
 * The class {@code GetAccountDetailsUtil} does this.
 * 
 * @author u386898
 * @since 17/12/2015
 * @version 1.0
 */
public class GetAccountDetailsResponseUtil {

    private GetAccountDetailsResponseType getAccountDetailsResponseType;

    /**
     * Initializes the instance variable getAccountDetailsResponse with the one passed to the constructor.
     * 
     * @param getAccountDetailsResponseType * of the type GetAccountDetailsResponseType
     */
    public GetAccountDetailsResponseUtil(GetAccountDetailsResponseType getAccountDetailsResponseType) {
        this.getAccountDetailsResponseType = getAccountDetailsResponseType;
    }

    /**
     * Sets a {getAccountDetailsResponse GetAccountDetailsResponse} into the GetAccountDetailsResponse.
     * 
     * @param getAccountDetailsResponse of type GetAccountDetailsResponse
     * @throws SILException
     */
    public void setAccountDetailResponse(GetAccountDetailsResponse getAccountDetailsResponse) throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACCOUNTDETAILS_LOGGING_FORMAT, "GetAccountDetailsUtil", "Entering setAccountDetailResponse()");
        if (this.getAccountDetailsResponseType != null) {
            List<GetAccountDetailsResponseType.AccountDetails> accountDetails = this.getAccountDetailsResponseType.getAccountDetails();
            if (accountDetails != null && accountDetails.size() > 0) {
                this.getAccountDetailsResponseBpay(getAccountDetailsResponse, accountDetails);
            }
        }
    }

    /**
     * Does this.
     * 
     * @param getAccountDetailsResponse
     * @param accountDetails
     */
    private void getAccountDetailsResponseBpay(GetAccountDetailsResponse getAccountDetailsResponse, List<AccountDetails> accountDetails)
            throws SILException {
        boolean isBpayCodeFound = false;
        Iterator<GetAccountDetailsResponseType.AccountDetails> accountDetailsIterator = accountDetails.iterator();
        while (accountDetailsIterator.hasNext()) {
            GetAccountDetailsResponseType.AccountDetails accountDetailsObj = accountDetailsIterator.next();
            List<ExternalRefType> externalRefTypes = accountDetailsObj.getExternalReference();
            Iterator<ExternalRefType> eIterator = externalRefTypes.iterator();
            while (eIterator.hasNext()) {
                ExternalRefType externalRefTypeObj = eIterator.next();
                if (externalRefTypeObj.getReferenceCode().equalsIgnoreCase(AccountServiceConstants.GET_ACCT_BPAY_CODE)) {
                    isBpayCodeFound = true;
                    AccountIdentifierType accountIdentifierType = accountDetailsObj.getAccount();
                    getAccountDetailsResponse.setAccountNumber(accountIdentifierType.getAccountNumber().getAccountNo());
                    getAccountDetailsResponse.setExternalReference(externalRefTypeObj.getReference());
                    getAccountDetailsResponse.setExternalReferenceCode(externalRefTypeObj.getReferenceCode());
                    break;
                }
            }
        }
        if (!isBpayCodeFound) {
            throw new SILException(AccountServiceConstants.GET_ACCOUNTDETAILS_NONE_BPAY_RESPONSE_MESSAGE);
        }
    }

}
