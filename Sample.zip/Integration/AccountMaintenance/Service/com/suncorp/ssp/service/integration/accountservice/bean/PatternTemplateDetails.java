////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code PatternTemplateDetails} does this.
 * @author U383847
 * @since 28/01/2016
 * @version 1.0
 */
public class PatternTemplateDetails {
    private String id;
    private String name;
    private String patternHeaderId;
    private String reference;
    private String effectiveDate;
    private String templateName;
    private AuditIdentifier audit;
    
    /**
     * Accessor for property id.
     * 
     * @return id of type String
     */
    public String getId() {
        return id;
    }
    
    /**
     * Mutator for property id.
     * 
     * @return id of type String
     */
    @XmlElement(name = "patternTemplateId")
    public void setId(String id) {
        this.id = id != null ? id : "";
    }
    
    /**
     * Accessor for property name.
     * 
     * @return name of type String
     */
    public String getName() {
        return name;
    }
    
    /**
     * Mutator for property name.
     * 
     * @return name of type String
     */
    @XmlElement(name = "patternName")
    public void setName(String name) {
        this.name = name != null ? name : "";
    }
    
    

    /**
     * Accessor for property reference.
     * 
     * @return reference of type String
     */
    public String getReference() {
        return reference;
    }

    /**
     * Mutator for property reference.
     * 
     * @return reference of type String
     */
    @XmlElement(name = "patternTemplateReference")
    public void setReference(String reference) {
        this.reference = reference != null ? reference : "";
    }

    /**
     * Accessor for property effectiveDate.
     * 
     * @return effectiveDate of type String
     */
    public String getEffectiveDate() {
        return effectiveDate;
    }

    /**
     * Mutator for property effectiveDate.
     * 
     * @return effectiveDate of type String
     */
    @XmlElement(name = "patternTemplateEffectiveDate")
    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate != null ? effectiveDate : "";
    }

    /**
     * Accessor for property templateName.
     * 
     * @return templateName of type String
     */
    public String getTemplateName() {
        return templateName;
    }

    /**
     * Mutator for property templateName.
     * 
     * @return templateName of type String
     */
    @XmlElement(name = "patternTemplateName")
    public void setTemplateName(String templateName) {
        this.templateName = templateName != null ? templateName : "";
    }

    /**
     * Accessor for property patternHeaderId.
     *
     * @return patternHeaderId of type String
     */
    public String getPatternHeaderId() {
        return patternHeaderId;
    }

    /**
     * Mutator for property patternHeaderId.
     *
     * @param patternHeaderId of type String
     */
    @XmlElement(name = "patternHeaderId")
    public void setPatternHeaderId(String patternHeaderId) {
        this.patternHeaderId = patternHeaderId != null ? patternHeaderId : "";
    }

    /**
     * Accessor for property audit.
     *
     * @return audit of type AuditIdentifier
     */
    public AuditIdentifier getAudit() {
        return audit;
    }

    /**
     * Mutator for property audit.
     *
     * @param audit of type AuditIdentifier
     */
    @XmlElement(name = "audit")
    public void setAudit(AuditIdentifier audit) {
        this.audit = audit;
    }

    

    
}
