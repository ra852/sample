////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import javax.ws.rs.core.MultivaluedMap;
import javax.xml.datatype.XMLGregorianCalendar;

import com.sonatacentral.service.v30.callerdetails.CallerDetails;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.ExternalRefType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType.AccountNumber;
import com.sonatacentral.service.v30.wrap.account.GetAccountTransactionSummaryRequestType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;

/**
 * The class {@code GetInvestmentBalanceRequestUtil} is a Utility class of GetInvestmentBalance functionality, for construction of outbound request.
 * 
 * @author U384381
 * @since 29/12/2015
 * @version 1.0
 */
public class GetInvestmentBalanceRequestUtil {
    private final String className = "GetInvestmentBalanceRequestUtil";
    private GetAccountTransactionSummaryRequestType outboundRequest;
    private MultivaluedMap<String, String> inboundRequest;

    /**
     * Initialises class properties,viz., inbound and outbound request types.
     * 
     * @param inboundRequest of type MultivaluedMap<String, String>
     */
    public GetInvestmentBalanceRequestUtil(MultivaluedMap<String, String> inboundRequest) {
        SILLogger.debug(AccountServiceConstants.GET_ACC_TRANS_SUMM_LOGGING_FORMAT, className, "Entering GetInvestmentBalanceRequestUtil()");
        this.inboundRequest = inboundRequest;
        this.outboundRequest = new GetAccountTransactionSummaryRequestType();
        SILLogger.debug(AccountServiceConstants.GET_ACC_TRANS_SUMM_LOGGING_FORMAT, className, "Exiting GetInvestmentBalanceRequestUtil()");
    }

    /**
     * Returns a new instance of AccountIdentifierType, with necessary values set.
     * 
     * @return accountIdentifierType of type AccountIdentifierType
     * @throws SILException
     */
    public AccountIdentifierType createAccountIdentifierType() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_INVESTMENT_BAL_LOG_FORMAT, className, "Entering createAccountIdentifierType()");
        AccountIdentifierType accountIdentifierType = new AccountIdentifierType();
        if (this.inboundRequest.containsKey(AccountServiceConstants.ACCOUNT_NO)) {
            accountIdentifierType.setAccountNumber(createAccountNumber());
        } else {
            throw new SILException(AccountServiceConstants.GET_INVESTMENT_BALANCE_INVALID_ACCOUNT_NO);
        }
        if (this.inboundRequest.containsKey(AccountServiceConstants.EXTERNAL_REFERENCE) ||
                this.inboundRequest.containsKey(AccountServiceConstants.EXTERNAL_REFERENCE_CODE)) {
            accountIdentifierType.setAccountExternalRef(createExternalRefType());
        }
        if (this.inboundRequest.containsKey(AccountServiceConstants.ACCOUNT_NAME)) {
            accountIdentifierType.setName(this.inboundRequest.get(AccountServiceConstants.ACCOUNT_NAME).get(0));
        }
        SILLogger.debug(AccountServiceConstants.GET_INVESTMENT_BAL_LOG_FORMAT, className, "Exiting createAccountIdentifierType()");
        return accountIdentifierType;
    }

    /**
     * Returns a new instance of AccountNumber, with necessary values set.
     * 
     * @return accountNumber of type AccountNumber
     * @throws SILException
     */
    private AccountNumber createAccountNumber() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_INVESTMENT_BAL_LOG_FORMAT, className, "Entering createAccountNumber()");
        AccountNumber accountNumber = new AccountNumber();
        accountNumber.setAccountNo(this.inboundRequest.get(AccountServiceConstants.ACCOUNT_NO).get(0));
        SILLogger.debug(AccountServiceConstants.GET_INVESTMENT_BAL_LOG_FORMAT, className, "Exiting createAccountNumber()");
        return accountNumber;
    }

    /**
     * Returns a new instance of ExternalRefType, with necessary values set.
     * 
     * @return externalRefType of type ExternalRefType
     */
    private ExternalRefType createExternalRefType() {
        SILLogger.debug(AccountServiceConstants.GET_INVESTMENT_BAL_LOG_FORMAT, className, "Entering createExternalRefType()");
        ExternalRefType externalRefType = new ExternalRefType();

        if (this.inboundRequest.containsKey(AccountServiceConstants.EXTERNAL_REFERENCE)) {
            externalRefType.setReference(this.inboundRequest.get(AccountServiceConstants.EXTERNAL_REFERENCE).get(0));
        }
        if (this.inboundRequest.containsKey(AccountServiceConstants.EXTERNAL_REFERENCE_CODE)) {
            externalRefType.setReferenceCode(this.inboundRequest.get(AccountServiceConstants.EXTERNAL_REFERENCE_CODE).get(0));
        }
        SILLogger.debug(AccountServiceConstants.GET_INVESTMENT_BAL_LOG_FORMAT, className, "Exiting createExternalRefType()");
        return externalRefType;
    }

    /**
     * Checks for the presence of parameter skipTransactionFundGrouping, defaults to false. In case the value passed is true, then only it is set to
     * true.
     * 
     * @return skipTransactionFundGrouping of type Boolean
     * @throws SILException
     */
    public boolean createSkipTransactionFundGrouping() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_INVESTMENT_BAL_LOG_FORMAT, className, "Entering createSkipTransactionFundGrouping()");
        Boolean skipTxnFundGrouping = false;
        if (this.inboundRequest.containsKey(AccountServiceConstants.SKIP_TRANSACTION_FUND_GROUPING)) {
            skipTxnFundGrouping = Boolean.parseBoolean(this.inboundRequest.get(AccountServiceConstants.SKIP_TRANSACTION_FUND_GROUPING).get(0));
        }
        SILLogger.debug(AccountServiceConstants.GET_INVESTMENT_BAL_LOG_FORMAT, className, "Exiting createSkipTransactionFundGrouping()");
        return skipTxnFundGrouping;
    }

    /**
     * This method checks the presence of parameter startDate and converts into XMLGregorianCalendar type.
     * 
     * @return startDate
     * @throws SILException
     */
    public XMLGregorianCalendar createStartDate() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_INVESTMENT_BAL_LOG_FORMAT, className, "Entering createStartDate()");
        XMLGregorianCalendar startDate = null;
        if (this.inboundRequest.containsKey(AccountServiceConstants.START_DATE)) {
            String datetime = this.inboundRequest.get(AccountServiceConstants.START_DATE).get(0) + " 00:00:00";
            startDate = SILUtil.convertStringToXMLGregorianCalendar(datetime, CommonConstants.DATETIME_FORMAT);
        } else {
            throw new SILException(AccountServiceConstants.GET_INVESTMENT_BALANCE_INVALID_START_DATE);
        }
        SILLogger.debug(AccountServiceConstants.GET_INVESTMENT_BAL_LOG_FORMAT, className, "Exiting createStartDate()");
        return startDate;
    }

    /**
     * This method checks the presence of parameter endDate and converts into XMLGregorianCalendar type.
     * 
     * @return endDate
     * @throws SILException
     */
    public XMLGregorianCalendar creatEndDate() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_INVESTMENT_BAL_LOG_FORMAT, className, "Entering creatEndDate()");
        XMLGregorianCalendar endDate = null;
        if (this.inboundRequest.containsKey(AccountServiceConstants.END_DATE)) {
            endDate =
                    SILUtil.convertStringToXMLGregorianCalendar(this.inboundRequest.get(AccountServiceConstants.END_DATE).get(0) + " 23:59:59",
                            CommonConstants.DATETIME_FORMAT);
        } else if (this.inboundRequest.containsKey(AccountServiceConstants.START_DATE)) {
            String datetime = this.inboundRequest.get(AccountServiceConstants.START_DATE).get(0) + " 23:59:59";
            endDate = SILUtil.convertStringToXMLGregorianCalendar(datetime, CommonConstants.DATETIME_FORMAT);
        }
        SILLogger.debug(AccountServiceConstants.GET_INVESTMENT_BAL_LOG_FORMAT, className, "Exiting creatEndDate()");
        return endDate;
    }

    /**
     * Returns the outbound request object after setting the parameters.
     * 
     * @param callerDetails of type CallerDetails
     * @param accountIdentifierType of type AccountIdentifierType
     * @param startDate of type XMLGregorianCalendar
     * @param endDate of type XMLGregorianCalendar
     * @param skipTransactionFundGrouping of type Boolean
     * @return outboundRequest of type GetAccountTransactionSummaryRequestType
     */
    public GetAccountTransactionSummaryRequestType createOutboundRequest(AccountIdentifierType accountIdentifierType, XMLGregorianCalendar startDate,
            XMLGregorianCalendar endDate, Boolean skipTransactionFundGrouping) {
        SILLogger.debug(AccountServiceConstants.GET_INVESTMENT_BAL_LOG_FORMAT, className, "Entering createOutboundRequest()");
        CallerDetails callerDetails = SILUtil.createCallerDetails();
        if (callerDetails != null) {
            this.outboundRequest.setCallerDetails(callerDetails);
        }
        if (this.inboundRequest.containsKey(AccountServiceConstants.ACCOUNT_NO)) {
            this.outboundRequest.setAccountIdentifier(accountIdentifierType);
        }
        if (this.inboundRequest.containsKey(AccountServiceConstants.START_DATE)) {
            this.outboundRequest.setStartDateTime(startDate);
        }
        if (this.inboundRequest.containsKey(AccountServiceConstants.END_DATE) || 
                this.inboundRequest.containsKey(AccountServiceConstants.START_DATE)) {
            this.outboundRequest.setEndDateTime(endDate);
        }
        if (this.inboundRequest.containsKey(AccountServiceConstants.SKIP_TRANSACTION_FUND_GROUPING)) {
            this.outboundRequest.setSkipTransactionFundGrouping(skipTransactionFundGrouping);
        }
        SILLogger.debug(AccountServiceConstants.GET_INVESTMENT_BAL_LOG_FORMAT, className, "Exiting createOutboundRequest()");
        return this.outboundRequest;
    }
}
