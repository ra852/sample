////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice;

import javax.ws.rs.core.Response;

import com.suncorp.ssp.service.integration.accountservice.bean.DeleteThirdPartyRelationshipRequest;
import com.suncorp.ssp.service.integration.accountservice.bean.SaveAccountBeneficiaryRequest;
import com.suncorp.ssp.service.integration.accountservice.bean.SaveAccountExpenseRequest;
import com.suncorp.ssp.service.integration.accountservice.bean.SaveAccountRequest;
import com.suncorp.ssp.service.integration.accountservice.bean.SaveAccountSchemeCategoryRequest;
import com.suncorp.ssp.service.integration.accountservice.bean.SaveInvestmentProfileRequest;
import com.suncorp.ssp.service.integration.accountservice.bean.SaveInvestmentRestructureRequest;
import com.suncorp.ssp.service.integration.accountservice.bean.SaveRegularContributionPlanRequestBean;
import com.suncorp.ssp.service.integration.accountservice.bean.UpdateAccountEmploymentRequest;

/**
 * The class {@code AccountService} implements the operations available for Account Service.
 * 
 * @author U384381
 * @since 03/02/2016
 * @version 1.0
 */
public class AccountServiceImpl implements AccountService {

    /**
     * Default constructor.
     */
    public AccountServiceImpl() {
    }

    /**
     * Fetches new GetClientResponse bean.
     * 
     * @param accountNUmber
     * @return {@link Response}
     */
    public Response getbeneficiary(String accountNUmber) {
        return null;
    }

    /**
     * Fetches new SearchAccountResponse bean.
     * 
     * @param clientId
     * @return {@link Response}
     */
    public Response searchaccount(String advisorClientId, String advisorForename, String advisorSurname, String memberClientId,
            String memberForename, String memberSurname, String memberDateOfBirth, String productId, String productName, String firstResult,
            String resultsPerPage, String pendingStatusFlag, String activeStatusFlag, String ownerRelationshipFlag) {
        return null;
    }

    /**
     * This method is used as a entry point for update and delete beneficiary.
     * 
     * @param saveAccountBeneficiaryRequest
     * @return {@link Response}
     */
    public Response saveaccountbeneficiary(SaveAccountBeneficiaryRequest saveAccountBeneficiaryRequest) {
        return null;
    }

    /**
     * Fetches new GetAccountDetailsResponse bean.
     * 
     * @return {@link Response}
     */
    public Response getaccountdetails(String accountNumber) {
        return null;
    }

    /**
     * This method is used as a entry point for get Account Transaction Summary.
     * 
     * 
     * @return {@link Response}
     */
    public Response getaccounttransactionsummary(String accountNumber, String startDate, String endDate, String includePricedOnly,
            String skipTransactionFundGrouping, String accountName, String externalReference, String externalReferenceCode) {
        return null;
    }

    /**
     * This method is used as a entry point for get Account Transaction List.
     * 
     * 
     * @return {@link Response}
     */
    public Response getaccounttransactionlist(String accountNumber, String transTypeCode, String categoryCode, String categoryCodeType,
            String startDate, String endDate, String accountName, String externalReference, String externalReferenceCode, String firstResult,
            String resultsPerPage, String includePricedOnly, String includeUnpricedOnly, String includeTermDepositDetails) {
        return null;
    }

    /**
     * Acts as the entry point for GetInvestmentBalance service.
     * 
     * 
     * @return {@link Response}
     */
    public Response getinvestmentbalance(String accountNumber, String skipTransactionFundGrouping, String accountName, String startDate,
            String endDate, String externalReference, String externalReferenceCode) {
        return null;
    }

    /**
     * Acts as the entry point for GetAccountExpense service.
     * 
     * 
     * @return {@link Response}
     */
    public Response getaccountexpense(String advisorClientId, String productName, String marketingCampaignId, String accountNumber) {
        return null;
    }

    /**
     * 
     * This service serve as get account details list strategy.
     * 
     * 
     * @return{@link Response}
     */
    public Response getaccountdetailslist(String accountId, String accountName, String accountNumber, String productName,
            String includeAccountDetail, String includeProduct, String includeScheme, String includeSchemeCategory, String includeMarketingCampaign,
            String includeCurrentExpenseGroup, String includeClientAccountRelationship, String includeSchemeLocation,
            String includeInvestmentProfile, String includeAdvisorGroup, String includeBeneficary, String includeBalance,
            String includeSchemeLocationHistory, String includeGenericVariable, String includeNote, String includeRegularContributionPlan,
            String includeFamilyGroup, String includeRestriction, String includeExternalReference, String includeInsurance) {
        return null;
    }

    /**
     * This method is used as a entry point for delete third party relationship.
     * 
     * @param deleteThirdPartyRelRequest
     * @return{@link Response}
     */
    public Response deletethirdpartyrelationship(DeleteThirdPartyRelationshipRequest deleteThirdPartyRelRequest) {
        return null;
    }

    /**
     * 
     * This service serve as entry point for save InvestmentRestructure.
     * 
     * @param saveAccountBeneficiaryRequest
     * @return
     */
    public Response saveInvestmentRestructure(SaveInvestmentRestructureRequest saveInvestmentRestructureRequest) {
        return null;
    }

    /**
     * This method is used as a entry point for update delete account rebalance.
     * 
     * @param saveAccountRequest
     * @return
     */
    public Response updateDeleteAccountRebalance(SaveAccountRequest saveAccountRequest) {
        return null;
    }

    /**
     * Acts as the entry point for GetAccountDetails service to get Pension Details.
     * 
     * @param accountId
     * @param accountName
     * @param accountNumber
     * @param productName
     * @param includeAccountTaxDetail
     * @param includePensionPaymentAmountDetail
     * @param includePensionPaymentInstruction
     * @param includePensionPaymentSplit
     * @param includeDrawdownDetail
     * @param includePensionProtection
     * @return{@link Response}
     */
    @Override
    public Response getPensionDetails(String accountId, String accountName, String accountNumber, String productName, String includeAccountTaxDetail,
            String includePensionPaymentAmountDetail, String includePensionPaymentInstruction, String includePensionPaymentSplit,
            String includeDrawdownDetail, String includePensionProtection) {
        return null;
    }

    /**
     * This method is used as a entry point for save account generic variables.
     * 
     * @param saveAccountRequest
     * @return
     */
    @Override
    public Response saveAccount(SaveAccountRequest saveAccountRequest) {
        return null;
    }

    /**
     * This method is used as a entry point for save regular contribution plan.
     * 
     * @param saveRegularContributionPlanRequestBean
     * @return
     */
    @Override
    public Response saveRegularContributionPlan(SaveRegularContributionPlanRequestBean saveRegularContributionPlanRequestBean) {
        return null;
    }

    /**
     * This method is used as a entry point for saveInvestmentProfile service.
     * 
     * @param saveInvestmentProfileRequest
     * @return
     */
    @Override
    public Response saveInvestmentProfile(SaveInvestmentProfileRequest saveInvestmentProfileRequest) {
        return null;
    }

    /**
     * Fetches new GetSwitchStatusResponse bean.
     * 
     * @return {@link Response}
     */
    public Response getSwitchStatus(String accountNumber, String startDate, String endDate, String firstResult, String resultsPerPage,
            String includeUnpricedOnlyFlag, String statusCode, String statusCodeType, String filterReverseTransFlag) {
        return null;
    }

    /**
     * 
     * This method is used as a entry point for saveAccountExpense service.
     * 
     * @param saveAccountExpenseRequest
     * @return
     */
    @Override
    public Response saveAccountExpense(SaveAccountExpenseRequest saveAccountExpenseRequest) {
        return null;
    }

    /**
     * Fetches Account Employment details.
     * 
     * @return object of type GetAccountEmploymentResponseBean
     */
    @Override
    public Response getaccountemployment(String accountNumber) {
        return null;
    }

    /**
     * This method is used as a entry point for UpdateAccountEmployment service.
     * 
     * @param UpdateAccountEmploymentRequest
     * @return
     */
    @Override
    public Response updateAccountEmployment(UpdateAccountEmploymentRequest updateAccountEmploymentRequest) {
        return null;
    }

    /**
     * This method is used as a entry point for UpdateAccountEmployment service.
     * 
     * @param UpdateAccountEmploymentRequest
     * @return
     */
    @Override
    public Response saveAccountSchemeCategory(SaveAccountSchemeCategoryRequest saveAccountSchemeCategoryRequest) {
        return null;
    }

    /**
     * Fetches new GetAccountUnitHoldingsResponse bean.
     * 
     * @param accountNumber
     * @return {@link Response}
     */
    public Response getAccountUnitHoldings(String accountNumber) {
        return null;
    }

    /**
     * Fetches new GetFamilyLinkingDetailsResponse bean.
     * 
     * @param accountNumber
     * @return {@link Response}
     */
    public Response getFamilyLinkingDetails(String accountNumber) {
        return null;
    }

    /**
     * Does this.
     * 
     * @param accountNumber
     * @param retrievalDateIndicator
     * @param contributionPeriodFrom
     * @param contributionPeriodTo
     * @param includeAllContributionsFlag
     * @return
     */
    @Override
    public Response getaccountcontributions(String accountNumber, String retrievalDateIndicator, String contributionPeriodFrom,
            String contributionPeriodTo, String includeAllContributionsFlag) {
        return null;
    }
}
