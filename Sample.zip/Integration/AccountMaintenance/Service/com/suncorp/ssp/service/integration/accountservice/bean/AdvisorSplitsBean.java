////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;
/**
 * The class {@code AdvisorSplitsBean} does this.
 * 
 * @author U387938
 * @since 02/02/2016
 * @version 1.0
 */
public class AdvisorSplitsBean {
    private String id;
    private AdvisorBean advisor;
    private String percentageSplit;
    private String primary;
    private String reference;
    /**
     * Accessor for property id.
     *
     * @return id of type String
     */
    public String getId() {
        return id;
    }
    /**
     * Mutator for property id.
     *
     * @param id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id != null ? id : "";
    }
    /**
     * Accessor for property advisor.
     *
     * @return advisor of type AdvisorBean
     */
    public AdvisorBean getAdvisor() {
        return advisor;
    }
    /**
     * Mutator for property advisor.
     *
     * @param advisor of type AdvisorBean
     */
    @XmlElement(name = "advisor")
    public void setAdvisor(AdvisorBean advisor) {
        this.advisor = advisor;
    }
    /**
     * Accessor for property percentageSplit.
     *
     * @return percentageSplit of type String
     */
    public String getPercentageSplit() {
        return percentageSplit;
    }
    /**
     * Mutator for property percentageSplit.
     *
     * @param percentageSplit of type String
     */
    @XmlElement(name = "percentageSplit")
    public void setPercentageSplit(String percentageSplit) {
        this.percentageSplit = percentageSplit != null ? percentageSplit : "";
    }
    /**
     * Accessor for property primary.
     *
     * @return primary of type String
     */
    public String getPrimary() {
        return primary;
    }
    /**
     * Mutator for property primary.
     *
     * @param primary of type String
     */
    @XmlElement(name = "primary")
    public void setPrimary(String primary) {
        this.primary = primary != null ? primary : "";
    }
    /**
     * Accessor for property reference.
     *
     * @return reference of type String
     */
    public String getReference() {
        return reference;
    }
    /**
     * Mutator for property reference.
     *
     * @param reference of type String
     */
    @XmlElement(name = "reference")
    public void setReference(String reference) {
        this.reference = reference != null ? reference : "";
    }
    
    
}
