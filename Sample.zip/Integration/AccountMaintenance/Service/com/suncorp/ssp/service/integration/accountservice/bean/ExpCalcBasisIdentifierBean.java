////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;
/**
 * The class {@code ExpCalcBasisIdentifierBean} does this.
 * 
 * @author U387938
 * @since 02/02/2016
 * @version 1.0
 */
public class ExpCalcBasisIdentifierBean {
    private String id;
    private String name;
    private String excbDescription;
    /**
     * Accessor for property id.
     *
     * @return id of type String
     */
    public String getId() {
        return id;
    }
    /**
     * Mutator for property id.
     *
     * @param id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id != null ? id : "";
    }
    /**
     * Accessor for property name.
     *
     * @return name of type String
     */
    public String getName() {
        return name;
    }
    /**
     * Mutator for property name.
     *
     * @param name of type String
     */
    @XmlElement(name = "name")
    public void setName(String name) {
        this.name = name != null ? name : "";
    }
    /**
     * Accessor for property excbDescription.
     *
     * @return excbDescription of type String
     */
    public String getExcbDescription() {
        return excbDescription;
    }
    /**
     * Mutator for property excbDescription.
     *
     * @param excbDescription of type String
     */
    @XmlElement(name = "excbDescription")
    public void setExcbDescription(String excbDescription) {
        this.excbDescription = excbDescription != null ? excbDescription : "";
    }
    
    
}
