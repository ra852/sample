////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code MasterSchemeIdentifier} does this.
 * 
 * @author U383754
 * @since 01/02/2016
 * @version 1.0
 */
public class MasterSchemeIdentifier {
    private String displayName;
    private String longName;

    /**
     * Accessor for property displayName.
     * 
     * @return displayName of type String
     */
    public String getDisplayName() {
        return displayName;
    }

    /**
     * Mutator for property displayName.
     * 
     * @return displayName of type String
     */
    @XmlElement(name = "displayName")
    public void setDisplayName(String displayName) {
        this.displayName = displayName != null ? displayName : "";
    }

    /**
     * Accessor for property longName.
     * 
     * @return longName of type String
     */
    public String getLongName() {
        return longName;
    }

    /**
     * Mutator for property longName.
     * 
     * @return longName of type String
     */
    @XmlElement(name = "longName")
    public void setLongName(String longName) {
        this.longName = longName != null ? longName : "";
    }
}
