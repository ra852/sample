////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.sonatacentral.service.v30.callerdetails.CallerDetails;
import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.ClientIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CodeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.ExternalRefType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.MasterSchemeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.RelationshipTypeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.BeneficiaryType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.ClientAccountRelationshipIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType.AccountNumber;
import com.sonatacentral.service.v30.wrap.account.SaveAccountBeneficiaryRequestType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.BeneficiaryDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.SaveAccountBeneficiaryRequest;

/**
 * The class {@code DeleteAllBeneficiaryRequestUtil} processes/constructs SOAP request for Delete All Beneficiary's service.
 * 
 * @author U387938
 * @since 08/04/2016
 * @version 1.0
 */
public class DeleteAllBeneficiaryRequestUtil {
    private final String className = "SaveAccountBeneficiaryRequestUtil";
    private SaveAccountBeneficiaryRequestType outboundRequest;
    private SaveAccountBeneficiaryRequest inboundRequest;
    private Integer deleteStepCount;

    /**
     * Initialises class properties,viz., inbound and outbound request types.
     * 
     * @param inboundRequest of type SaveAccountBeneficiaryRequest
     */
    public DeleteAllBeneficiaryRequestUtil(SaveAccountBeneficiaryRequest inboundRequest, Integer deleteStepCount) {
        this.inboundRequest = inboundRequest;
        this.outboundRequest = new SaveAccountBeneficiaryRequestType();
        this.deleteStepCount = deleteStepCount;
    }

    /**
     * Returns a new instance of AccountIdentifierType, with necessary values set. Please note that the object is initialised only if the request is
     * proper.
     * 
     * @throws SILException
     */
    public AccountIdentifierType createAccountIdentifierType() throws SILException {
        SILLogger.debug(AccountServiceConstants.DELETEALL_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Entering createAccountIdentifierType()");
        AccountIdentifierType accountIdentifierType = new AccountIdentifierType();
        AccountNumber accountNumber = createAccountNumber();
        ExternalRefType extRefType = createExternalRefType();
        CodeIdentifierType statusCode = createStatusCode();
        MasterSchemeIdentifierType masterScheme = createMasterSchemeIdentifierType();

        if (accountNumber != null) {
            accountIdentifierType.setAccountNumber(accountNumber);
        }
        if (extRefType != null) {
            accountIdentifierType.setAccountExternalRef(extRefType);
        }
        if (statusCode != null) {
            accountIdentifierType.setStatusCode(statusCode);
        }
        if (masterScheme != null) {
            accountIdentifierType.setMasterScheme(masterScheme);
        }
        SILLogger.debug(AccountServiceConstants.DELETEALL_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Exiting createAccountIdentifierType()");
        return accountIdentifierType;
    }

    /**
     * Returns a new instance of List<BeneficiaryType>, with necessary values set.
     * 
     * @throws SILException
     * @throws DatatypeConfigurationException
     */
    public List<BeneficiaryType> createBeneficiaryList() throws SILException {
        SILLogger.debug(AccountServiceConstants.DELETEALL_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Entering createBeneficiaryList()");
        List<BeneficiaryType> outboundBeneficiaryList = null;
        List<BeneficiaryDetails> inboundBeneficiaryList = this.inboundRequest.getBeneficiary();

        if (inboundBeneficiaryList != null && inboundBeneficiaryList.size() > 0) {
            outboundBeneficiaryList = new ArrayList<BeneficiaryType>();

            for (BeneficiaryDetails beneficiaryDetails : inboundBeneficiaryList) {
                if (deleteStepCount == 1) {
                    outboundBeneficiaryList.add(createBeneficiary(beneficiaryDetails));
                } else {
                    if (Boolean.valueOf(beneficiaryDetails.getClientAccountRelationship().getPrimary())) {
                        outboundBeneficiaryList.add(createBeneficiary(beneficiaryDetails));
                    }
                }
            }
        }
        SILLogger.debug(AccountServiceConstants.DELETEALL_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Exiting createBeneficiaryList()");
        return outboundBeneficiaryList;
    }

    /**
     * Returns the outbound request object after setting the parameters.
     * 
     * @param callerDetails
     * @param accountIdentifierType
     * @param beneficiaryList
     * @param saveAccountBeneficiaryRequestType
     */
    public SaveAccountBeneficiaryRequestType createOutboundRequest(CallerDetails callerDetails, AccountIdentifierType accountIdentifierType,
            List<BeneficiaryType> beneficiaryList) {
        SILLogger.debug(AccountServiceConstants.DELETEALL_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Entering createOutboundRequest()");
        this.outboundRequest.setCallerDetails(callerDetails);
        this.outboundRequest.setAccount(accountIdentifierType);
        this.outboundRequest.getBeneficiary().addAll(beneficiaryList);
        SILLogger.debug(AccountServiceConstants.DELETEALL_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Exiting createOutboundRequest()");
        return outboundRequest;
    }

    /**
     * Returns a new instance of AccountNumber, with necessary values set. Please note that the object is initialised only if the request is proper.
     * 
     * @return accountNumber of type AccountNumber
     * @throws SILException
     */
    private AccountNumber createAccountNumber() throws SILException {
        SILLogger.debug(AccountServiceConstants.DELETEALL_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Entering createAccountNumber()");
        AccountNumber accountNumber = new AccountNumber();

        if (this.inboundRequest.getAccountNumber() != null) {
            accountNumber.setAccountNo(this.inboundRequest.getAccountNumber());
        }
        if (this.inboundRequest.getProductName() != null) {
            accountNumber.setProductName(this.inboundRequest.getProductName());
        }
        SILLogger.debug(AccountServiceConstants.DELETEALL_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Exiting createAccountNumber()");
        return accountNumber;
    }

    /**
     * Returns a new instance of ExternalRefType, with necessary values set.
     * 
     * @return externalRefType of type ExternalRefType
     */
    private ExternalRefType createExternalRefType() {
        SILLogger.debug(AccountServiceConstants.DELETEALL_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Entering createExternalRefType()");
        ExternalRefType externalRefType = new ExternalRefType();

        if (this.inboundRequest.getAccountExtReferenceDeleteFlag() != null) {
            externalRefType.setDelete(Boolean.parseBoolean(this.inboundRequest.getAccountExtReferenceDeleteFlag()));
        }
        if (this.inboundRequest.getAccountExtReference() != null) {
            externalRefType.setReference(this.inboundRequest.getAccountExtReference());
        }
        if (this.inboundRequest.getAccountExtReferenceCode() != null) {
            externalRefType.setReferenceCode(this.inboundRequest.getAccountExtReferenceCode());
        }
        SILLogger.debug(AccountServiceConstants.DELETEALL_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Exiting createExternalRefType()");
        return externalRefType;
    }

    /**
     * Returns a new instance of CodeIdentifierType, with necessary values set.
     * 
     * @return statusCode of type CodeIdentifierType
     * @throws SILException
     */
    private CodeIdentifierType createStatusCode() throws SILException {
        SILLogger.debug(AccountServiceConstants.DELETEALL_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Entering createStatusCode()");
        CodeIdentifierType statusCode = new CodeIdentifierType();
        if (this.inboundRequest.getStatusId() != null) {
            statusCode.setId(getStatusId());
        }
        if (this.inboundRequest.getStatusCode() != null) {
            statusCode.setCode(this.inboundRequest.getStatusCode());
        }
        if (this.inboundRequest.getStatusCodeType() != null) {
            statusCode.setCodeType(this.inboundRequest.getStatusCodeType());
        }
        if (this.inboundRequest.getStatusCodeShortDescription() != null) {
            statusCode.setCodeShortDescription(this.inboundRequest.getStatusCodeShortDescription());
        }
        if (this.inboundRequest.getStatusCodeDescription() != null) {
            statusCode.setCodeDescription(this.inboundRequest.getStatusCodeDescription());
        }
        SILLogger.debug(AccountServiceConstants.DELETEALL_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Exiting createStatusCode()");
        return statusCode;
    }

    /**
     * Gets the status id by parsing a String to Long.
     * 
     * @return Long
     * @throws SILException
     */
    private Long getStatusId() throws SILException {
        try {
            return Long.parseLong(this.inboundRequest.getStatusId());
        } catch (NumberFormatException nfe) {
            SILLogger.error(AccountServiceConstants.DELETEALL_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, SILUtil.getReqExMsg(nfe));
            throw new SILException(AccountServiceConstants.SAVE_ACCOUNT_INVALID_STATUS_ID_MSG);
        }
    }

    /**
     * Returns a new instance of MasterSchemeIdentifierType, with necessary values set.
     * 
     * @return masterScheme of type MasterSchemeIdentifierType
     */
    private MasterSchemeIdentifierType createMasterSchemeIdentifierType() {
        SILLogger.debug(AccountServiceConstants.DELETEALL_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Entering createMasterSchemeIdentifierType()");
        MasterSchemeIdentifierType masterScheme = new MasterSchemeIdentifierType();

        if (this.inboundRequest.getMasterSchemeDisplayName() != null) {
            masterScheme.setDisplayName(this.inboundRequest.getMasterSchemeDisplayName());
        }
        if (this.inboundRequest.getMasterSchemeLongName() != null) {
            masterScheme.setLongName(this.inboundRequest.getMasterSchemeLongName());
        }
        SILLogger.debug(AccountServiceConstants.DELETEALL_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Exiting createMasterSchemeIdentifierType()");
        return masterScheme;
    }

    /**
     * Returns a new instance of BeneficiaryType, with necessary values set.
     * 
     * @param inboundBeneficiary of type BeneficiaryDetails
     * @return beneficiary of type BeneficiaryType
     * @throws SILException
     */

    private BeneficiaryType createBeneficiary(BeneficiaryDetails inboundBeneficiary) throws SILException {
        SILLogger.debug(AccountServiceConstants.DELETEALL_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Entering createBeneficiary()");
        BeneficiaryType outboundBeneficiary = new BeneficiaryType();
        ClientAccountRelationshipIdentifierType clientAccoutRel = createClientAccountRelationship(inboundBeneficiary);
        CodeIdentifierType category = createCategory(inboundBeneficiary);
        CodeIdentifierType type = createType(inboundBeneficiary);
        CodeIdentifierType relationship = createRelationship(inboundBeneficiary);
        setBeneficiaryParams(inboundBeneficiary, outboundBeneficiary, clientAccoutRel, category, type, relationship);
        SILLogger.debug(AccountServiceConstants.DELETEALL_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Exiting createBeneficiary()");
        return outboundBeneficiary;
    }

    /**
     * Set parameters inside Beneficiary
     * 
     * @param inboundBeneficiary
     * @param outboundBeneficiary
     * @param clientAccoutRel
     * @param category
     * @param type
     * @param relationship
     * @throws SILException
     */
    private void setBeneficiaryParams(BeneficiaryDetails inboundBeneficiary, BeneficiaryType outboundBeneficiary,
            ClientAccountRelationshipIdentifierType clientAccoutRel, CodeIdentifierType category, CodeIdentifierType type,
            CodeIdentifierType relationship) throws SILException {
        SILLogger.debug(AccountServiceConstants.DELETEALL_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Entering setBeneficiaryParams()");
        if (clientAccoutRel != null) {
            outboundBeneficiary.setClientAccountRelationship(clientAccoutRel);
        }
        if (category != null) {
            outboundBeneficiary.setCategory(category);
        }
        if (type != null) {
            outboundBeneficiary.setType(type);
        }
        if (relationship != null) {
            outboundBeneficiary.setRelationship(relationship);
        }
        if (deleteStepCount == 1) {
            setBeneficiaryDetails(inboundBeneficiary, outboundBeneficiary);
        } else {
            setPrimaryBeneficiaryDetails(inboundBeneficiary, outboundBeneficiary);
        }
        SILLogger.debug(AccountServiceConstants.DELETEALL_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Exiting setBeneficiaryParams()");
    }

    /**
     * Sets the Delete Flag, Advice Received, Allocation properties of the beneficiary.
     * 
     * @param inboundBeneficiary of type BeneficiaryDetails
     * @param outboundBeneficiary of type BeneficiaryType
     * @return outboundBeneficiary of type BeneficiaryType
     * @throws SILException
     */
    private BeneficiaryType setBeneficiaryDetails(BeneficiaryDetails inboundBeneficiary, BeneficiaryType outboundBeneficiary) throws SILException {
        SILLogger.debug(AccountServiceConstants.DELETEALL_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Entering setBeneficiaryDetails()");
        Boolean isPrimaryBeneficiary = Boolean.valueOf(inboundBeneficiary.getClientAccountRelationship().getPrimary());
        if (inboundBeneficiary.getAdviceReceived() != null) {
            outboundBeneficiary.setAdviceReceived(Boolean.parseBoolean(inboundBeneficiary.getAdviceReceived()));
        }
        try {
            if (isPrimaryBeneficiary) {
                outboundBeneficiary.setDelete(false);
                outboundBeneficiary.setSplitPercentage(new BigDecimal("100.00"));
            } else {
                outboundBeneficiary.setDelete(true);
                outboundBeneficiary.setSplitPercentage(new BigDecimal("0.00"));
            }
        } catch (NumberFormatException nfe) {
            SILLogger.error(AccountServiceConstants.DELETEALL_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, SILUtil.getReqExMsg(nfe));
            throw new SILException(AccountServiceConstants.SAVE_ACCOUNT_INVALID_ALLOCATION_MSG);
        }
        setbeneficiaryDates(inboundBeneficiary, outboundBeneficiary);
        SILLogger.debug(AccountServiceConstants.DELETEALL_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Exiting setBeneficiaryDetails()");
        return outboundBeneficiary;
    }

    /**
     * Sets the Delete Flag, Advice Received, Allocation properties of the beneficiary.
     * 
     * @param inboundBeneficiary of type BeneficiaryDetails
     * @param outboundBeneficiary of type BeneficiaryType
     * @return outboundBeneficiary of type BeneficiaryType
     * @throws SILException
     * @throws DatatypeConfigurationException
     */
    private BeneficiaryType setPrimaryBeneficiaryDetails(BeneficiaryDetails inboundBeneficiary, BeneficiaryType outboundBeneficiary)
            throws SILException {
        SILLogger.debug(AccountServiceConstants.DELETEALL_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Entering setBeneficiaryDetails()");
        Boolean isPrimaryBeneficiary = Boolean.valueOf(inboundBeneficiary.getClientAccountRelationship().getPrimary());
        if (isPrimaryBeneficiary) {

            outboundBeneficiary.setDelete(true);
        }

        if (inboundBeneficiary.getAdviceReceived() != null) {
            outboundBeneficiary.setAdviceReceived(Boolean.parseBoolean(inboundBeneficiary.getAdviceReceived()));
        }
        if (isPrimaryBeneficiary) {
            try {
                outboundBeneficiary.setSplitPercentage(new BigDecimal("100.00"));
            } catch (NumberFormatException nfe) {
                SILLogger.error(AccountServiceConstants.DELETEALL_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, SILUtil.getReqExMsg(nfe));
                throw new SILException(AccountServiceConstants.SAVE_ACCOUNT_INVALID_ALLOCATION_MSG);
            }
        }
        setbeneficiaryDates(inboundBeneficiary, outboundBeneficiary);
        SILLogger.debug(AccountServiceConstants.DELETEALL_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Exiting setBeneficiaryDetails()");
        return outboundBeneficiary;
    }

    /**
     * Sets the End date and Nomination signed date properties of the beneficiary.
     * 
     * @param inboundBeneficiary of type BeneficiaryDetails
     * @param outboundBeneficiary of type BeneficiaryType
     * @return outboundBeneficiary of type BeneficiaryType
     * @throws SILException
     */
    private BeneficiaryType setbeneficiaryDates(BeneficiaryDetails inboundBeneficiary, BeneficiaryType outboundBeneficiary) throws SILException {
        if (inboundBeneficiary.getEndDate() != null) {
            outboundBeneficiary
                    .setEndDate(SILUtil.convertStringToXMLGregorianCalendar(inboundBeneficiary.getEndDate(), CommonConstants.DATE_FORMAT));
        }
        if (inboundBeneficiary.getDateNominationSigned() != null) {
            outboundBeneficiary.setDateNominationSigned(SILUtil.convertStringToXMLGregorianCalendar(inboundBeneficiary.getDateNominationSigned(),
                    CommonConstants.DATE_FORMAT));
        }
        return outboundBeneficiary;
    }

    /**
     * Returns a new instance of ClientAccountRelationshipIdentifierType, with necessary values set.
     * 
     * @param inboundBeneficiary of type BeneficiaryDetails
     * @return clientAccountRelationship of type ClientAccountRelationshipIdentifierType
     * @throws SILException
     */
    private ClientAccountRelationshipIdentifierType createClientAccountRelationship(BeneficiaryDetails inboundBeneficiary) throws SILException {
        SILLogger.debug(AccountServiceConstants.DELETEALL_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Entering createClientAccountRelationship()");
        ClientAccountRelationshipIdentifierType clientAccountRelationship = new ClientAccountRelationshipIdentifierType();
        RelationshipTypeIdentifierType relation = createClientAccountRelationshipType(inboundBeneficiary);
        String beneficiaryId = inboundBeneficiary.getBeneficiaryId();
        ClientIdentifierType client = createClientIdentifierType(inboundBeneficiary);
        if (beneficiaryId != null) {
            try {
                clientAccountRelationship.setId(Long.parseLong(inboundBeneficiary.getBeneficiaryId()));
            } catch (NumberFormatException nfe) {
                SILLogger.error(AccountServiceConstants.DELETEALL_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, SILUtil.getReqExMsg(nfe));
                throw new SILException(AccountServiceConstants.SAVE_ACCOUNT_INVALID_BENEFICIARY_ID_MSG);
            }
        }
        if (client != null) {
            clientAccountRelationship.setClient(client);
        }
        if (relation != null) {
            clientAccountRelationship.setRelationshipType(relation);
        }
        SILLogger.debug(AccountServiceConstants.DELETEALL_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Exiting createClientAccountRelationship()");
        return clientAccountRelationship;
    }

    /**
     * Returns a new instance of ClientIdentifierType, with necessary values set.
     * 
     * @param inboundBeneficiary of type BeneficiaryDetails
     * @return client of type ClientIdentifierType
     * @throws SILException
     */
    private ClientIdentifierType createClientIdentifierType(BeneficiaryDetails inboundBeneficiary) throws SILException {
        SILLogger.debug(AccountServiceConstants.DELETEALL_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Entering createClientIdentifierType()");
        ClientIdentifierType client = new ClientIdentifierType();
        String clientId = inboundBeneficiary.getClientId();

        if (clientId != null) {
            try {
                client.setId(Long.parseLong(clientId));
            } catch (NumberFormatException nfe) {
                SILLogger.error(AccountServiceConstants.DELETEALL_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, SILUtil.getReqExMsg(nfe));
                throw new SILException(AccountServiceConstants.SAVE_ACCOUNT_INVALID_CLIENT_ID_MSG);
            }
        }
        SILLogger.debug(AccountServiceConstants.DELETEALL_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Exiting createClientIdentifierType()");
        return client;
    }

    /**
     * Returns a new instance of RelationshipTypeIdentifierType, with necessary values set.
     * 
     * @param inboundBeneficiary of type BeneficiaryDetails
     * @return clientRelationType of type RelationshipTypeIdentifierType
     */
    private RelationshipTypeIdentifierType createClientAccountRelationshipType(BeneficiaryDetails inboundBeneficiary) {
        SILLogger.debug(AccountServiceConstants.DELETEALL_ACCOUNT_BENEFICIARY_LOG_FORMAT, className,
                "Entering createClientAccountRelationshipType()");
        RelationshipTypeIdentifierType clientRelationType = new RelationshipTypeIdentifierType();
        String relationCode = inboundBeneficiary.getClientAccountRelationshipCode();
        String relationName = inboundBeneficiary.getClientAccountRelationshipName();

        if (relationCode != null) {
            clientRelationType.setCode(relationCode);
        }
        if (relationName != null) {
            clientRelationType.setName(relationName);
        }
        SILLogger.debug(AccountServiceConstants.DELETEALL_ACCOUNT_BENEFICIARY_LOG_FORMAT, className,
                "Exiting createClientAccountRelationshipType()");
        return clientRelationType;
    }

    /**
     * Returns a new instance of CodeIdentifierType, with necessary values set.
     * 
     * @param inboundBeneficiary of type BeneficiaryDetails
     * @return category of type CodeIdentifierType
     */
    private CodeIdentifierType createCategory(BeneficiaryDetails inboundBeneficiary) {
        SILLogger.debug(AccountServiceConstants.DELETEALL_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Entering createCategory()");
        CodeIdentifierType category = new CodeIdentifierType();

        if (inboundBeneficiary.getCategoryCode() != null) {
            category.setCode(inboundBeneficiary.getCategoryCode());
        }
        if (inboundBeneficiary.getCategoryCodeType() != null) {
            category.setCodeType(inboundBeneficiary.getCategoryCodeType());
        }
        if (inboundBeneficiary.getCategoryCodeShortDescription() != null) {
            category.setCodeShortDescription(inboundBeneficiary.getCategoryCodeShortDescription());
        }
        if (inboundBeneficiary.getCategoryCodeDescription() != null) {
            category.setCodeDescription(inboundBeneficiary.getCategoryCodeDescription());
        }
        SILLogger.debug(AccountServiceConstants.DELETEALL_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Exiting createCategory()");
        return category;
    }

    /**
     * Returns a new instance of CodeIdentifierType, with necessary values set.
     * 
     * @param inboundBeneficiary of type BeneficiaryDetails
     * @return beneficiaryType of type CodeIdentifierType
     */
    private CodeIdentifierType createType(BeneficiaryDetails inboundBeneficiary) {
        SILLogger.debug(AccountServiceConstants.DELETEALL_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Entering createType()");
        CodeIdentifierType beneficiaryType = new CodeIdentifierType();
        String code = inboundBeneficiary.getTypeCode();
        String typeCode = inboundBeneficiary.getTypeCodeType();
        String shortDesc = inboundBeneficiary.getTypeCodeShortDescription();
        String longDesc = inboundBeneficiary.getTypeCodeDescription();

        if (code != null) {
            beneficiaryType.setCode(code);
        }
        if (typeCode != null) {
            beneficiaryType.setCodeType(typeCode);
        }
        if (shortDesc != null) {
            beneficiaryType.setCodeShortDescription(shortDesc);
        }
        if (longDesc != null) {
            beneficiaryType.setCodeDescription(longDesc);
        }
        SILLogger.debug(AccountServiceConstants.DELETEALL_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Exiting createType()");
        return beneficiaryType;
    }

    /**
     * Returns a new instance of CodeIdentifierType, with necessary values set.
     * 
     * @param inboundBeneficiary of type BeneficiaryDetails
     * @return category of type CodeIdentifierType
     */
    private CodeIdentifierType createRelationship(BeneficiaryDetails inboundBeneficiary) {
        SILLogger.debug(AccountServiceConstants.DELETEALL_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Entering createRelationship()");
        CodeIdentifierType relationship = new CodeIdentifierType();
        String code = inboundBeneficiary.getRelationshipCode();
        String typeCode = inboundBeneficiary.getRelationshipCodeType();
        String shortDesc = inboundBeneficiary.getRelationshipCodeShortDescription();
        String longDesc = inboundBeneficiary.getRelationshipCodeDescription();
        if (code != null) {
            relationship.setCode(code);
        }
        if (typeCode != null) {
            relationship.setCodeType(typeCode);
        }
        if (shortDesc != null) {
            relationship.setCodeShortDescription(shortDesc);
        }
        if (longDesc != null) {
            relationship.setCodeDescription(longDesc);
        }
        SILLogger.debug(AccountServiceConstants.DELETEALL_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Exiting createRelationship()");
        return relationship;
    }
}
