////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import java.util.List;

import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.ClientIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.RelationshipTypeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountEntityType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType.AccountNumber;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.ClientRelationshipType;
import com.sonatacentral.service.v30.wrap.account.SaveAccountRequestType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.AccountDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.ClientAccountRelationshipIdentifierBean;
import com.suncorp.ssp.service.integration.accountservice.bean.DeleteRelationshipDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.DeleteThirdPartyRelationshipRequest;
import com.suncorp.ssp.service.integration.accountservice.bean.RelationshipIdentifierBean;

/**
 * The class {@code DelThirdPartyRelationshipRequestUtil} is used as a util class for preparing DelThirdPartyRelRequest request.
 * 
 * @author u385424
 * @since 17/03/2016
 * @version 1.0
 */
public class DelThirdPartyRelationshipRequestUtil {
    private final String className = "DelThirdPartyRelationshipRequestUtil";
    private DeleteThirdPartyRelationshipRequest inboundRequest;

    /**
     * Initialises class properties,viz., inbound and outbound request types.
     * 
     * @param inboundRequest of type DeleteThirdPartyRelationshipRequest
     */
    public DelThirdPartyRelationshipRequestUtil(DeleteThirdPartyRelationshipRequest inboundRequest) {
        this.inboundRequest = inboundRequest;
    }

    /**
     * create outbound request for external service request for saveAccountRequest.
     * 
     * @param outboundRequest of type SaveAccountRequestType.
     */
    public void createOutboundRequest(SaveAccountRequestType outboundRequest) throws SILException {
        SILLogger.debug(AccountServiceConstants.DEL_THIRD_PARTY_REL_LOG_FORMAT, className, "createOutboundRequest()");
        if (inboundRequest != null && inboundRequest.getThirdPartyDetails() != null) {
            outboundRequest.setAccount(createDelThirdPartyRelRequest(inboundRequest.getThirdPartyDetails()));
        }
    }

    /**
     * set required object for delete third party relationship request for external service request.
     * 
     * @param deleteRelationshipDetails of type DeleteRelationshipDetails
     * 
     * @return accountEntityType of type AccountEntityType
     */
    private AccountEntityType createDelThirdPartyRelRequest(DeleteRelationshipDetails deleteRelationshipDetails) {
        SILLogger.debug(AccountServiceConstants.DEL_THIRD_PARTY_REL_LOG_FORMAT, className, "createDelThirdPartyRelRequest()");
        AccountEntityType accountEntityType = new AccountEntityType();
        if (deleteRelationshipDetails.getAccount() != null && deleteRelationshipDetails.getAccount().getAccountNumber() != null &&
                deleteRelationshipDetails.getAccount().getAccountNumber().getAccountNo() != null) {
            accountEntityType.setAccount(createAccountDetails(inboundRequest.getThirdPartyDetails().getAccount()));
        }
        if (deleteRelationshipDetails.getRelationship() != null && deleteRelationshipDetails.getRelationship().size() > 0) {
            this.setRelationship(accountEntityType, deleteRelationshipDetails);
        }
        return accountEntityType;
    }

    /**
     * set relationship details to the external service request object.
     * 
     * @param accountEntityType of type AccountEntityType.
     * @param deleteRelationshipDetails of type DeleteRelationshipDetails
     */
    private void setRelationship(AccountEntityType accountEntityType, DeleteRelationshipDetails deleteRelationshipDetails) {
        SILLogger.debug(AccountServiceConstants.DEL_THIRD_PARTY_REL_LOG_FORMAT, className, "setRelationship()");
        List<ClientRelationshipType> relationshipTypeList = accountEntityType.getRelationship();
        for (ClientAccountRelationshipIdentifierBean relationshipObj : deleteRelationshipDetails.getRelationship()) {
            ClientRelationshipType clientRelationshipType = new ClientRelationshipType();
            if (relationshipObj.getDelete() != null) {
                clientRelationshipType.setDelete(retrieveBoolean(relationshipObj.getDelete()));
            }
            if (relationshipObj.getClient() != null && relationshipObj.getClient().getId() != null) {
                clientRelationshipType.setClient(createClient(relationshipObj.getClient().getId()));
            }
            this.setRemainingRelationshipDetails(relationshipObj, clientRelationshipType);
            relationshipTypeList.add(clientRelationshipType);
        }
    }

    /**
     * Set Remaining Relationship Details.
     * 
     * @param relationshipObj
     * @param clientRelationshipType
     */
    private void setRemainingRelationshipDetails(ClientAccountRelationshipIdentifierBean relationshipObj,
            ClientRelationshipType clientRelationshipType) {
        if (relationshipObj.getRelationshipType() != null && relationshipObj.getRelationshipType().getCode() != null) {
            clientRelationshipType.setRelationshipType(retrieveRelationshipCode(relationshipObj.getRelationshipType()));
        }
        if (relationshipObj.getPrimary() != null) {
            clientRelationshipType.setPrimary(retrieveBoolean(relationshipObj.getPrimary()));
        }
    }

    /**
     * Set relationshipCode to the external service request object.
     * 
     * @param relationshipIdentifierBean of type RelationshipIdentifierBean.
     * @return relationshipTypeIdentifierType of type RelationshipTypeIdentifierType
     */
    private RelationshipTypeIdentifierType retrieveRelationshipCode(RelationshipIdentifierBean relationshipIdentifierBean) {
        RelationshipTypeIdentifierType relationshipTypeIdentifierType = new RelationshipTypeIdentifierType();
        relationshipTypeIdentifierType.setCode(relationshipIdentifierBean.getCode());
        return relationshipTypeIdentifierType;
    }

    /**
     * Set clientId to the external service request object.
     * 
     * @param id of type String
     * @return clientIdentifierType of type ClientIdentifierType
     */
    private ClientIdentifierType createClient(String id) {
        ClientIdentifierType clientIdentifierType = new ClientIdentifierType();
        clientIdentifierType.setId(Long.parseLong(id));
        return clientIdentifierType;
    }

    /**
     * Retrieve Boolean Default False.
     * 
     * @return defaultValue
     */
    private Boolean retrieveBoolean(String value) {
        Boolean defaultValue = false;
        defaultValue = Boolean.valueOf(value);
        return defaultValue;
    }

    /**
     * Set accountNo to the external service request object.
     * 
     * @param accountDetails of type AccountDetails
     * 
     * @return accountIdentifierType of type AccountIdentifierType
     */
    private AccountIdentifierType createAccountDetails(AccountDetails accountDetails) {
        SILLogger.debug(AccountServiceConstants.DEL_THIRD_PARTY_REL_LOG_FORMAT, className, "createAccountDetails()");
        AccountIdentifierType accountIdentifierType = new AccountIdentifierType();
        AccountNumber accountNumber = new AccountNumber();
        accountNumber.setAccountNo(accountDetails.getAccountNumber().getAccountNo());
        accountIdentifierType.setAccountNumber(accountNumber);
        return accountIdentifierType;
    }

}
