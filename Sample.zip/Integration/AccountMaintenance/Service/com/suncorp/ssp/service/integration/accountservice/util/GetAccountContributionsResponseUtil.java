////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import java.util.ArrayList;
import java.util.List;

import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.GenericContributionType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.GenericContributionType.Contribution;
import com.sonatacentral.service.v30.wrap.account.GetAccountContributionsResponseType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.AccountDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.ContributionBean;
import com.suncorp.ssp.service.integration.accountservice.bean.Contributions;
import com.suncorp.ssp.service.integration.accountservice.bean.GetAccountContributionDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.GetAccountContributionsResponse;

/**
 * The class {@code GetAccountContributionsResponseUtil} does this.
 * 
 * @author U201468
 * @since 19/09/2017
 * @version 1.0
 */
public class GetAccountContributionsResponseUtil {
    private final String className = "GetAccountContributionsResponseUtil";
    private GetAccountContributionsResponseType inboundResponse;
    private GetAccountContributionsResponse outboundResponse;

    /**
     * Does this.
     * 
     * @param inboundResponse
     */
    public GetAccountContributionsResponseUtil(GetAccountContributionsResponseType inboundResponse) {
        this.inboundResponse = inboundResponse;
        this.outboundResponse = new GetAccountContributionsResponse();
    }

    /**
     * Does this.
     * 
     * @return
     */
    public GetAccountContributionsResponse createOutboundResponse() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACCOUNT_CONTRIBUTIONS_LOGGING_FORMAT, className, "Entering createOutboundResponse()");
        if (this.inboundResponse != null && inboundResponse.getAccountDetails() != null && inboundResponse.getAccountDetails().size() > 0) {
            List<GetAccountContributionDetails> accountContributionList = new ArrayList<GetAccountContributionDetails>();
            for (GetAccountContributionsResponseType.AccountDetails accountDetailsType : inboundResponse.getAccountDetails()) {
                GetAccountContributionDetails accountContributions = new GetAccountContributionDetails();
                setAccountContributionsDetails(accountDetailsType, accountContributions);
                accountContributionList.add(accountContributions);
            }
            outboundResponse.setGetAccountContributionDetails(accountContributionList);
        }
        return outboundResponse;
    }

    /**
     * Does this.
     * 
     * @param accountContributions
     * 
     * @param accountDetailsList
     * @throws SILException
     */
    private void setAccountContributionsDetails(GetAccountContributionsResponseType.AccountDetails accountDetailsType,
            GetAccountContributionDetails accountContributions) throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACCOUNT_CONTRIBUTIONS_LOGGING_FORMAT, className, "Entering setAccountContributionsDetails()");
        AccountServiceUtil accountServiceCommonUtil = new AccountServiceUtil();
        List<AccountDetails> accountDetails = new ArrayList<AccountDetails>();
        List<Contributions> contributionsList = new ArrayList<Contributions>();
        for (Object object : accountDetailsType.getAccountOrContributions()) {
            if (object instanceof AccountIdentifierType) {
                setAccountIdentifierDetails(object, accountServiceCommonUtil, accountDetails, accountContributions);
            } else if (object instanceof GenericContributionType) {
                setContributionDetails(object, accountServiceCommonUtil, accountContributions, contributionsList);
            }
        }

    }

    /**
     * Does this.
     * 
     * @param accountDetailsList
     * @param accountServiceCommonUtil
     * @param contributionsList
     * @param accountContributions
     * @throws SILException
     */
    private void setContributionDetails(Object obj, AccountServiceUtil accountServiceCommonUtil, GetAccountContributionDetails accountContributions,
            List<Contributions> contributionsList) throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACCOUNT_CONTRIBUTIONS_LOGGING_FORMAT, className, "Entering setContributionDetails()");
        GenericContributionType genericContributionDetails = (GenericContributionType) obj;
        if (genericContributionDetails != null) {
            Contributions contributions = new Contributions();
            contributions.setTotal(accountServiceCommonUtil.retrieveBigDecimalValue(genericContributionDetails.getTotal(), "loggerType"));
            contributions.setNonConcessionalTotal(accountServiceCommonUtil.retrieveBigDecimalValue(
                    genericContributionDetails.getNonConcessionalTotal(), "loggerType"));
            contributions.setConcessionalTotal(accountServiceCommonUtil.retrieveBigDecimalValue(genericContributionDetails.getConcessionalTotal(),
                    "loggerType"));
            contributions.setNonConcessionalCGTExemptTotal(accountServiceCommonUtil.retrieveBigDecimalValue(
                    genericContributionDetails.getNonConcessionalCGTExemptTotal(), "loggerType"));
            contributions.setContributionDetails(retrieveContributionList(genericContributionDetails.getContribution()));
            contributionsList.add(contributions);
            accountContributions.setContributions(contributionsList);
        }
    }

    /**
     * Does this.
     * 
     * @param accountDetailsList
     * @param accountServiceCommonUtil
     * @param accountDetailsList
     * @param accountContributions
     * @throws SILException
     */
    private void setAccountIdentifierDetails(Object obj, AccountServiceUtil accountServiceCommonUtil, List<AccountDetails> accountDetailsList,
            GetAccountContributionDetails accountContributions) throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACCOUNT_CONTRIBUTIONS_LOGGING_FORMAT, className, "Entering setAccountIdentifierDetails()");
        AccountIdentifierType accountIdentifierDetails = (AccountIdentifierType) obj;
        if (accountIdentifierDetails != null) {
            AccountDetails accountDetails = new AccountDetails();
            accountDetails.setId(accountServiceCommonUtil.retrieveLongValue(accountIdentifierDetails.getId(), "loggerType"));
            accountDetails.setName(accountIdentifierDetails.getName());
            accountDetails.setAccountNumber(accountServiceCommonUtil.retrieveAccountNumberDetails(accountIdentifierDetails.getAccountNumber(),
                    "loggerType"));
            accountDetails.setAccountExternalRef(accountServiceCommonUtil.retrieveExternalRef(accountIdentifierDetails.getAccountExternalRef(),
                    "loggerType"));
            accountDetails.setStatusCode(accountServiceCommonUtil.retrieveCode(accountIdentifierDetails.getStatusCode(), "loggerType"));
            accountDetails.setAudit(accountServiceCommonUtil.retrieveAudit(accountIdentifierDetails.getAudit(), "loggerType"));
            accountDetailsList.add(accountDetails);
            accountContributions.setAccountDetails(accountDetailsList);
        }
    }

    /**
     * Does this.
     * 
     * @param contribution
     * @return
     * @throws SILException
     */
    private List<ContributionBean> retrieveContributionList(List<Contribution> contribution) throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACCOUNT_CONTRIBUTIONS_LOGGING_FORMAT, className, "Entering retrieveContributionList()");
        List<ContributionBean> contributionBeanList = new ArrayList<ContributionBean>();
        if (contribution != null && contribution.size() > 0) {
            for (Contribution contributionList : contribution) {
                AccountServiceUtil accountServiceCommonUtil = new AccountServiceUtil();
                if (contributionList != null) {
                    ContributionBean contributionDet = new ContributionBean();
                    contributionDet.setContributionType(accountServiceCommonUtil.retrieveCode(contributionList.getContributionType(), "loggerType"));
                    contributionDet.setAmount(accountServiceCommonUtil.retrieveBigDecimalValue(contributionList.getAmount(), "loggerType"));
                    contributionBeanList.add(contributionDet);
                }
            }
        }
        return contributionBeanList;
    }

}
