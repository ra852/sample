////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CodeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.PatternTemplateIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.ProfileFunctionIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.fund.fundgrouptype.FundIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.InvestmentProfileType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.InvestmentProfileType.AccountProfileLink;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.InvestmentProfileType.AccountProfileLink.Fund;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.InvestmentProfileType.AccountProfileLink.Profile;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.AccountProfileLinkDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.CodeIdentifier;
import com.suncorp.ssp.service.integration.accountservice.bean.FundDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.FundIdentifierDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.InvestmentProfileDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.PatternTemplateDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.ProfileDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.ProfileFunctionDetails;

/**
 * The class {@code InvestmentProfileRequestUtil} does this.
 * 
 * @author U387938
 * @since 25/07/2016
 * @version 1.0
 */
public class InvestmentProfileRequestUtil {
    private final String className = "InvestmentProfileRequestUtil";

    /**
     * 
     * Set InvestmentProfileDetails in sonata create switch request.
     * 
     * @param switchOutFundDetailsBeans
     * @return switchOutFundDetails
     * @throws SILException
     */
    public List<InvestmentProfileType> setInvestmentProfileDetails(List<InvestmentProfileDetails> investmentProfileDetails) throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_PROFILE_LOGGING_FORMAT, className, "entering setInvestmentProfileDetails()");
        List<InvestmentProfileType> investmentProfileTypes = new ArrayList<InvestmentProfileType>();
        for (InvestmentProfileDetails investmentProfileDetail : investmentProfileDetails) {
            if (investmentProfileDetail != null) {
                InvestmentProfileType investmentProfileType = new InvestmentProfileType();
                if (investmentProfileDetail.getDeleteFlag() != null) {
                    investmentProfileType.setDelete(Boolean.valueOf(investmentProfileDetail.getDeleteFlag()));
                }
                if (investmentProfileDetail.getAccountProfileLinkDetails() != null) {
                    investmentProfileType.setAccountProfileLink(setAccountProfileLinkDetails(investmentProfileDetail.getAccountProfileLinkDetails()));
                }
                if (investmentProfileDetail.getProfileFunctionDetails() != null) {
                    investmentProfileType.getAccountProfileLink().setProfileFunctionIdentifier(
                            setProfileFunctionDetails(investmentProfileDetail.getProfileFunctionDetails()));
                }
                setInvestmentProfileParamsFirst(investmentProfileDetail, investmentProfileType);
                setInvestmentProfileParamsSecond(investmentProfileDetail, investmentProfileType);
                investmentProfileTypes.add(investmentProfileType);
                SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_PROFILE_LOGGING_FORMAT, className, "exiting setInvestmentProfileDetails()");
            }
        }
        return investmentProfileTypes;
    }

    /**
     * set InvestmentProfile Parameters in the sonata request.
     * 
     * @param investmentProfileDetail
     * @param investmentProfileType
     * @throws SILException
     */
    private void setInvestmentProfileParamsFirst(InvestmentProfileDetails investmentProfileDetail, InvestmentProfileType investmentProfileType)
            throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_PROFILE_LOGGING_FORMAT, className, "entering setInvestmentProfileParamsFirst()");
        if (investmentProfileDetail.getProfileDetails() != null) {
            investmentProfileType.getAccountProfileLink().setProfile(setProfileDetails(investmentProfileDetail.getProfileDetails()));
        }
        if (investmentProfileDetail.getSameAsDefaultInvestmentProfile() != null) {
            investmentProfileType.getAccountProfileLink().setSameAsDefaultInvestmentProfile(
                    Boolean.valueOf(investmentProfileDetail.getSameAsDefaultInvestmentProfile()));
        }
        if (investmentProfileDetail.getPatternMethod() != null) {
            investmentProfileType.getAccountProfileLink().setPatternMethodCode(setCodeIdentifierDetails(investmentProfileDetail.getPatternMethod()));
        }
        if (investmentProfileDetail.getOverrideCode() != null) {
            investmentProfileType.getAccountProfileLink().setOverrideCode(setCodeIdentifierDetails(investmentProfileDetail.getOverrideCode()));
        }
        SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_PROFILE_LOGGING_FORMAT, className, "exiting setInvestmentProfileParamsFirst()");
        
    }
    
    /**
     * set InvestmentProfile Parameters in the sonata request.
     * 
     * @param investmentProfileDetail
     * @param investmentProfileType
     * @throws SILException
     */
    private void setInvestmentProfileParamsSecond(InvestmentProfileDetails investmentProfileDetail, InvestmentProfileType investmentProfileType)
            throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_PROFILE_LOGGING_FORMAT, className, "entering setInvestmentProfileParamsSecond()");
        if (investmentProfileDetail.getTotalAmount() != null) {
            BigDecimal totalAmt = new BigDecimal(investmentProfileDetail.getTotalAmount());
            investmentProfileType.getAccountProfileLink().setTotalAmount(totalAmt);
        }
        if (investmentProfileDetail.getClearAllFunds() != null) {
            investmentProfileType.getAccountProfileLink().setClearAllFunds(Boolean.valueOf(investmentProfileDetail.getClearAllFunds()));
        }
        if (investmentProfileDetail.getFundDetails() != null && investmentProfileDetail.getFundDetails().size() > 0) {
            investmentProfileType.getAccountProfileLink().getFund().addAll(setFundDetailList(investmentProfileDetail.getFundDetails()));
        }
        SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_PROFILE_LOGGING_FORMAT, className, "exiting setInvestmentProfileParamsSecond()");
    }

    /**
     * 
     * set AccountProfileLinkDetails in the sonata request.
     * 
     * @param accProfileLinkDetails
     * @return
     * @throws SILException
     */
    public AccountProfileLink setAccountProfileLinkDetails(AccountProfileLinkDetails accProfileLinkDetails) throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_PROFILE_LOGGING_FORMAT, className, "entering setAccountProfileLinkDetails()");
        AccountProfileLink accountProfileLink = null;
        if (accProfileLinkDetails != null) {
            AccountServiceUtil serviceUtil = new AccountServiceUtil();
            String logger = AccountServiceConstants.SAVE_INVESTMENT_PROFILE_LOGGING_FORMAT;
            accountProfileLink = new AccountProfileLink();
            if (accProfileLinkDetails.getEffectiveDate() != null) {
                accountProfileLink.setEffectiveDate(serviceUtil.retrieveDateValueFromString(accProfileLinkDetails.getEffectiveDate(), logger));
            }
        }
        SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_PROFILE_LOGGING_FORMAT, className, "exiting setAccountProfileLinkDetails()");

        return accountProfileLink;
    }

    /**
     * 
     * set ProfileFunctionDetails in the sonata request.
     * 
     * @param profileFunctionDetails
     * @return
     * @throws SILException
     */
    public ProfileFunctionIdentifierType setProfileFunctionDetails(ProfileFunctionDetails profileFunctionDetails) throws SILException {
        ProfileFunctionIdentifierType profileFunctionIdentifierType = null;
        SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_PROFILE_LOGGING_FORMAT, className, "entering setProfileFunctionDetails()");
        if (profileFunctionDetails != null) {
            profileFunctionIdentifierType = new ProfileFunctionIdentifierType();
            if (profileFunctionDetails.getId() != null) {
                profileFunctionIdentifierType.setId(Long.valueOf(profileFunctionDetails.getId()));
            }
            if (profileFunctionDetails.getName() != null) {
                profileFunctionIdentifierType.setName(profileFunctionDetails.getName());
            }
            if (profileFunctionDetails.getCode() != null) {
                profileFunctionIdentifierType.setCode(profileFunctionDetails.getCode());
            }
        }
        SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_PROFILE_LOGGING_FORMAT, className, "exiting setProfileFunctionDetails()");

        return profileFunctionIdentifierType;
    }

    /**
     * 
     * set ProfileDetails in the sonata request.
     * 
     * @param profileDetails
     * @return
     * @throws SILException
     */
    public Profile setProfileDetails(ProfileDetails profileDetails) throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_PROFILE_LOGGING_FORMAT, className, "entering setProfileDetails()");
        Profile profile = null;
        if (profileDetails != null) {
            profile = new Profile();
            if (profileDetails.getPatternTemplateDetails() != null) {
                profile.setPatternTemplate(setPatternTemplateDetails(profileDetails.getPatternTemplateDetails()));
            }
            if (profileDetails.getBeSpokeNew() != null) {
                profile.setBespokeNew(Boolean.valueOf(profileDetails.getBeSpokeNew()));
            }
        }
        SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_PROFILE_LOGGING_FORMAT, className, "exiting setProfileDetails()");
        return profile;
    }

    /**
     * 
     * set PatternTemplateDetails in the sonata request.
     * 
     * @param patternTemplateDetails
     * @return
     * @throws SILException
     */
    public PatternTemplateIdentifierType setPatternTemplateDetails(PatternTemplateDetails patternTemplateDetails) throws SILException {
        PatternTemplateIdentifierType templateIdentifierType = null;
        if (patternTemplateDetails != null) {
            String logger = AccountServiceConstants.SAVE_INVESTMENT_PROFILE_LOGGING_FORMAT;
            AccountServiceUtil serviceUtil = new AccountServiceUtil();
            templateIdentifierType = new PatternTemplateIdentifierType();
            if (patternTemplateDetails.getId() != null) {
                templateIdentifierType.setId(Long.valueOf(patternTemplateDetails.getId()));
            }
            if (patternTemplateDetails.getName() != null) {
                templateIdentifierType.setName(patternTemplateDetails.getName());
            }
            if (patternTemplateDetails.getReference() != null) {
                templateIdentifierType.setReference(patternTemplateDetails.getReference());
            }
            if (patternTemplateDetails.getEffectiveDate() != null) {
                templateIdentifierType.setEffectiveDate(serviceUtil.retrieveDateValueFromString(patternTemplateDetails.getEffectiveDate(), logger));
            }
            if (patternTemplateDetails.getTemplateName() != null) {
                templateIdentifierType.setTemplateName(patternTemplateDetails.getTemplateName());
            }
        }
        SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_PROFILE_LOGGING_FORMAT, className, "exiting setPatternTemplateDetails()");
        return templateIdentifierType;
    }

    /**
     * 
     * set CodeIdentifierDetails in the sonata request.
     * 
     * @param codeIdentifierDetails
     * @return
     * @throws SILException
     */
    public CodeIdentifierType setCodeIdentifierDetails(CodeIdentifier codeIdentifierDetails) throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_PROFILE_LOGGING_FORMAT, className, "entering setCodeIdentifierDetails()");
        CodeIdentifierType codeIdentifierType = null;
        if (codeIdentifierDetails != null) {
            codeIdentifierType = new CodeIdentifierType();
            if (codeIdentifierDetails.getId() != null) {
                codeIdentifierType.setId(Long.valueOf(codeIdentifierDetails.getId()));
            }
            if (codeIdentifierDetails.getCode() != null) {
                codeIdentifierType.setCode(codeIdentifierDetails.getCode());
            }
            if (codeIdentifierDetails.getCodeDescription() != null) {
                codeIdentifierType.setCodeDescription(codeIdentifierDetails.getCodeDescription());
            }
            if (codeIdentifierDetails.getCodeShortDescription() != null) {
                codeIdentifierType.setCodeShortDescription(codeIdentifierDetails.getCodeShortDescription());
            }
            if (codeIdentifierDetails.getCodeType() != null) {
                codeIdentifierType.setCodeType(codeIdentifierDetails.getCodeType());
            }
        }
        SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_PROFILE_LOGGING_FORMAT, className, "exiting setCodeIdentifierDetails()");
        return codeIdentifierType;
    }

    /**
     * 
     * set FundDetail List in the sonata request.
     * 
     * @param fundDetailLst
     * @return
     * @throws SILException
     */
    public List<Fund> setFundDetailList(List<FundDetails> fundDetailLst) throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_PROFILE_LOGGING_FORMAT, className, "entering setFundDetailList()");
        List<Fund> fundsList = new ArrayList<Fund>();
        for (FundDetails fundDetails : fundDetailLst) {
            if (fundDetails != null) {
                Fund fund = new Fund();
                if (fundDetails.getFundIdentifier() != null) {
                    fund.setFundIdentifier(setFundIdentifierDetails(fundDetails.getFundIdentifier()));
                }
                if (fundDetails.getAmount() != null) {
                    BigDecimal amount = new BigDecimal(fundDetails.getAmount());
                    fund.setAmount(amount);
                }
                setFundDetailsListParams(fundDetails, fund);
                fundsList.add(fund);
            }
        }
        SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_PROFILE_LOGGING_FORMAT, className, "exiting setFundDetailList()");
        return fundsList;
    }

    /**
     * set FundDetails list details parameters
     *
     * @param fundDetails
     * @param fund
     */
    private void setFundDetailsListParams(FundDetails fundDetails, Fund fund) {
        SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_PROFILE_LOGGING_FORMAT, className, "entering setFundDetailsListParams()");
        if (fundDetails.getSequence() != null) {
            BigDecimal sequence = new BigDecimal(fundDetails.getSequence());
            fund.setSequence(sequence);
        }
        if (fundDetails.getSplitPercent() != null) {
            BigDecimal splitPercent = new BigDecimal(fundDetails.getSplitPercent());
            fund.setSplitPercent(splitPercent);
        }
        SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_PROFILE_LOGGING_FORMAT, className, "exiting setFundDetailsListParams()");
    }

    /**
     * 
     * set FundIdentifierDetails in the sonata request.
     * 
     * @param fundIdentifierDetails
     * @return
     * @throws SILException
     */
    public FundIdentifierType setFundIdentifierDetails(FundIdentifierDetails fundIdentifierDetails) throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_PROFILE_LOGGING_FORMAT, className, "entering setFundIdentifierDetails()");
        FundIdentifierType fundIdentifierType = null;
        if (fundIdentifierDetails != null) {
            fundIdentifierType = new FundIdentifierType();
            if (fundIdentifierDetails.getId() != null) {
                fundIdentifierType.setId(Long.valueOf(fundIdentifierDetails.getId()));
            }
            if (fundIdentifierDetails.getName() != null) {
                fundIdentifierType.setName(fundIdentifierDetails.getName());
            }
            if (fundIdentifierDetails.getFundFullName() != null) {
                fundIdentifierType.setFundFullName(fundIdentifierDetails.getFundFullName());
            }
            if (fundIdentifierDetails.getFundCorrespondenceName() != null) {
                fundIdentifierType.setFundCorrespondenceName(fundIdentifierDetails.getFundCorrespondenceName());
            }
            if (fundIdentifierDetails.getFundType() != null) {
                fundIdentifierType.setFundType(setCodeIdentifierDetails(fundIdentifierDetails.getFundType()));
            }
        }
        SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_PROFILE_LOGGING_FORMAT, className, "exiting setFundIdentifierDetails()");
        return fundIdentifierType;
    }
}
