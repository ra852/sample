////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;
/**
 * The class {@code AdvisorBean} does this.
 * 
 * @author U387938
 * @since 02/02/2016
 * @version 1.0
 */
public class AdvisorBean {
    private AdvisorDetails is;
    private CodeIdentifier status;
    private CodeIdentifier outletType;
    /**
     * Accessor for property is.
     *
     * @return is of type AdvisorDetails
     */
    public AdvisorDetails getIs() {
        return is;
    }
    /**
     * Mutator for property is.
     *
     * @param is of type AdvisorDetails
     */
    @XmlElement(name = "is")
    public void setIs(AdvisorDetails is) {
        this.is = is;
    }
    /**
     * Accessor for property status.
     *
     * @return status of type CodeIdentifier
     */
    public CodeIdentifier getStatus() {
        return status;
    }
    /**
     * Mutator for property status.
     *
     * @param status of type CodeIdentifier
     */
    @XmlElement(name = "status")
    public void setStatus(CodeIdentifier status) {
        this.status = status;
    }
    /**
     * Accessor for property outletType.
     *
     * @return outletType of type CodeIdentifier
     */
    public CodeIdentifier getOutletType() {
        return outletType;
    }
    /**
     * Mutator for property outletType.
     *
     * @param outletType of type CodeIdentifier
     */
    @XmlElement(name = "outletType")
    public void setOutletType(CodeIdentifier outletType) {
        this.outletType = outletType;
    }
    
    
}
