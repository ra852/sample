////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import com.sonatacentral.service.v30.wrap.account.SaveAccountBeneficiaryResponseType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.SaveAccountBeneficiaryResponse;

/**
 * The class {@code SaveAccountBeneficiaryRequestUtil} is used as a util class for preparing SaveAccountBeneficiary's response.
 * 
 * @author U384381
 * @since 10/12/2015
 * @version 1.0
 */
public class SaveAccountBeneficiaryResponseUtil {
    private final String className = "SaveAccountBeneficiaryResponseUtil";
    private SaveAccountBeneficiaryResponseType inboundResponse;
    private SaveAccountBeneficiaryResponse outboundResponse;

    /**
     * Initialises class properties,viz., inbound and outbound response types.
     * 
     * @param inboundResponse of type SaveAccountBeneficiaryResponse
     */
    public SaveAccountBeneficiaryResponseUtil(SaveAccountBeneficiaryResponseType inboundResponse) {
        this.inboundResponse = inboundResponse;
        this.outboundResponse = new SaveAccountBeneficiaryResponse();
    }

    /**
     * Returns the outbound response object after setting the parameters.
     * 
     * @return outboundResponse of type SaveAccountBeneficiaryResponse
     */
    public SaveAccountBeneficiaryResponse createOutboundResponse() {
        SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Entering createSaveAccountBeneficiaryResponse()");
        this.outboundResponse.setStatus(CommonConstants.FAILURE);
        if (inboundResponse != null && inboundResponse.getAccount() != null && inboundResponse.getBeneficiary() != null &&
                inboundResponse.getBeneficiary().size() >= 0) {
            outboundResponse.setStatus(CommonConstants.SUCCESS);
        }
        SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_BENEFICIARY_LOG_FORMAT, className, "Exiting createSaveAccountBeneficiaryResponse()");
        return this.outboundResponse;
    }
}
