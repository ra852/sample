////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.xml.datatype.XMLGregorianCalendar;

import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.AdvisorIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CodeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.DecimalRangeType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.ExpenseGroupIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.ExpenseLineDetailType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.ExpenseLineDetailType.CalculationBasis;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.ExpenseParameterSetType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.ExpenseParameterType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.ExpenseTypeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.ExternalRefType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.GenericReference;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.MasterSchemeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.fund.fundgrouptype.FundRiderIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.marketing.marketinggrouptype.MarketingCampaignIdentifierType;
import com.sonatacentral.service.v30.globaltypes.identifiertype.IdentifierAuditType;
import com.sonatacentral.service.v30.globaltypes.identifiertype.IdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType.AccountNumber;
import com.sonatacentral.service.v30.globaltypes.wrap.product.productgrouptype.ProductIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.transaction.transactiongrouptype.TransactionTypeIdentifierType;
import com.sonatacentral.service.v30.wrap.account.GetAccountExpenseResponseType;
import com.sonatacentral.service.v30.wrap.account.GetAccountExpenseResponseType.ExpenseGroup;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.AccountDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.AccountIdentifierDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.AccountNumberInfo;
import com.suncorp.ssp.service.integration.accountservice.bean.AccountPointer;
import com.suncorp.ssp.service.integration.accountservice.bean.AdvisorDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.AuditIdentifier;
import com.suncorp.ssp.service.integration.accountservice.bean.CalculationBasisDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.CodeIdentifier;
import com.suncorp.ssp.service.integration.accountservice.bean.DecimalRangeIdentifier;
import com.suncorp.ssp.service.integration.accountservice.bean.ExpenseDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.ExpenseGroupDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.ExpenseLineDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.FundRider;
import com.suncorp.ssp.service.integration.accountservice.bean.GetAccountExpenseResponse;
import com.suncorp.ssp.service.integration.accountservice.bean.IdNameIdentifier;
import com.suncorp.ssp.service.integration.accountservice.bean.IdentityIdentifier;
import com.suncorp.ssp.service.integration.accountservice.bean.MarketingCampaignDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.MasterSchemeIdentifier;
import com.suncorp.ssp.service.integration.accountservice.bean.ParameterDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.ParameterSetDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.ProductDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.ReferenceIdentifier;
import com.suncorp.ssp.service.integration.accountservice.bean.TierDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.TransactionDetails;

/**
 * The class {@code GetAccountExpenseUtil} does this.
 * 
 * @author U387938
 * @since 02/02/2016
 * @version 1.0
 */
public class GetAccountExpenseUtil {
    private final String className = "GetAccountExpenseUtil";
    private GetAccountExpenseResponseType getAccountExpenseResponseType;

    public GetAccountExpenseUtil(GetAccountExpenseResponseType getAccountExpenseResponseType) {
        this.getAccountExpenseResponseType = getAccountExpenseResponseType;
    }

    /**
     * This method constructs the AccountExpenseResponse object from response.
     * 
     * @param getAccountExpenseResponse
     * @throws SILException
     */
    public void setAccountExpenseResponse(GetAccountExpenseResponse getAccountExpenseResponse) throws SILException {
        if (this.getAccountExpenseResponseType != null) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in setAccountExpenseResponse");
            getAccountExpenseResponse.setAdvisor(retrieveAdvisorDetails(this.getAccountExpenseResponseType.getAdvisor()));
            getAccountExpenseResponse.setProduct(retrieveProductDetails(this.getAccountExpenseResponseType.getProduct()));
            getAccountExpenseResponse
                    .setMarketingCampaign(retrieveMarketingCampaignDetails(this.getAccountExpenseResponseType.getMarketingCampaign()));
            getAccountExpenseResponse.setAccount(retrieveAccountDetails(this.getAccountExpenseResponseType.getAccount()));
            getAccountExpenseResponse.setExpenseGroup(retrieveExpenseGroupDetails(this.getAccountExpenseResponseType.getExpenseGroup()));
            getAccountExpenseResponse.setExpenseLine(retrieveExpenseLineList(this.getAccountExpenseResponseType.getExpenseLine()));
        } else {
            throw new SILException(AccountServiceConstants.INVALID_RESPONSE_FROM_SONATA);
        }
    }

    /**
     * This method constructs the AccountExpenseResponse object from response.
     * 
     * @param getAccountExpenseResponse
     * @throws SILException
     */
    public void setExpenseLineResponse(GetAccountExpenseResponse getAccountExpenseResponse) throws SILException {
        if (this.getAccountExpenseResponseType != null) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveAdvisorDetails method");
            getAccountExpenseResponse.setExpenseLine(retrieveExpenseLineList(this.getAccountExpenseResponseType.getExpenseLine()));
        } else {
            throw new SILException(AccountServiceConstants.INVALID_RESPONSE_FROM_SONATA);
        }
    }

    /**
     * This method constructs the Advisor object from response.
     * 
     * @param advisorIdentifierType
     * @return
     * @throws SILException
     */
    private AdvisorDetails retrieveAdvisorDetails(AdvisorIdentifierType advisorIdentifierType) throws SILException {
        AdvisorDetails advisorDetails = new AdvisorDetails();
        if (this.getAccountExpenseResponseType.getAdvisor() != null) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveAdvisorDetails method");
            advisorDetails.setId(retrieveLongValue(advisorIdentifierType.getId()));
            advisorDetails.setName(advisorIdentifierType.getName());
            advisorDetails.setAdvisorNumber(advisorIdentifierType.getAdvisorNumber());
            advisorDetails.setClientId(retrieveLongValue(advisorIdentifierType.getClientId()));
            advisorDetails.setClientExternalRef(retrieveExternalRef(advisorIdentifierType.getClientExternalRef()));
            advisorDetails.setClientForename(advisorIdentifierType.getClientForename());
            advisorDetails.setClientSurname(advisorIdentifierType.getClientSurname());
            advisorDetails.setMasterScheme(retrieveMasterSchemeDetails(advisorIdentifierType.getMasterScheme()));
            advisorDetails.setUsername(advisorIdentifierType.getUsername());
            advisorDetails.setAudit(retrieveAudit(advisorIdentifierType.getAudit()));
        } else {
            advisorDetails = retrieveEmptyAdvisor();
        }
        return advisorDetails;
    }

    /**
     * This method constructs the Product object from response.
     * 
     * @param productIdentifierType
     * @return
     * @throws SILException
     */
    private ProductDetails retrieveProductDetails(ProductIdentifierType productIdentifierType) throws SILException {
        ProductDetails productDetails = new ProductDetails();
        if (this.getAccountExpenseResponseType.getProduct() != null) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveProductDetails method");
            productDetails.setId(retrieveLongValue(productIdentifierType.getId()));
            productDetails.setName(productIdentifierType.getName());
            productDetails.setShortName(productIdentifierType.getShortName());
            productDetails.setProductRef(retrieveExternalRef(productIdentifierType.getProductExternalRef()));
            productDetails.setAudit(retrieveAudit(productIdentifierType.getAudit()));
        } else {
            productDetails = retrieveEmptyProductDetails();
        }

        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveProductDetails()");
        return productDetails;
    }

    /**
     * This method constructs the MarketingCampaign object from response.
     * 
     * @param campaignIdentifierType
     * @return
     * @throws SILException
     */
    private MarketingCampaignDetails retrieveMarketingCampaignDetails(MarketingCampaignIdentifierType campaignIdentifierType) throws SILException {
        MarketingCampaignDetails marketingCampaignDetails = new MarketingCampaignDetails();
        if (this.getAccountExpenseResponseType.getMarketingCampaign() != null) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveMarketingCampaignDetails method");
            marketingCampaignDetails.setId(retrieveLongValue(campaignIdentifierType.getId()));
            marketingCampaignDetails.setName(campaignIdentifierType.getName());
            marketingCampaignDetails.setCode(campaignIdentifierType.getCode());
            marketingCampaignDetails.setDescription(campaignIdentifierType.getDescription());
            marketingCampaignDetails.setAudit(retrieveAudit(campaignIdentifierType.getAudit()));
        } else {
            marketingCampaignDetails = retrieveEmptyMarketingCampaign();
        }
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveMarketingCampaignDetails()");
        return marketingCampaignDetails;
    }

    /**
     * This method constructs the Account object from response.
     * 
     * @param accountIdentifierType
     * @return
     * @throws SILException
     */
    private AccountDetails retrieveAccountDetails(AccountIdentifierType accountIdentifierType) throws SILException {

        AccountDetails accountDetails = new AccountDetails();
        if (this.getAccountExpenseResponseType.getAccount() != null) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveAccountDetails method");
            accountDetails.setId(retrieveLongValue(accountIdentifierType.getId()));
            accountDetails.setName(accountIdentifierType.getName());
            accountDetails.setAccountNumber(retrieveAccountNumberDetails(accountIdentifierType.getAccountNumber()));
            accountDetails.setAccountExternalRef(retrieveExternalRef(accountIdentifierType.getAccountExternalRef()));
            accountDetails.setStatusCode(retrieveCode(accountIdentifierType.getStatusCode()));
            accountDetails.setAudit(retrieveAudit(accountIdentifierType.getAudit()));
            accountDetails.setAccountPointer(retrieveAccountPointerDetails(accountIdentifierType.getAccountPointer()));
            accountDetails.setMasterScheme(retrieveMasterSchemeDetails(accountIdentifierType.getMasterScheme()));
        } else {
            accountDetails = retrieveEmptyAccountDetails();
        }
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveAccountDetails()");
        return accountDetails;
    }

    /**
     * This method constructs the ExpenseGroup object from response.
     * 
     * @param expenseGroup
     * @return
     * @throws SILException
     */
    private ExpenseGroupDetails retrieveExpenseGroupDetails(ExpenseGroup expenseGroup) throws SILException {

        ExpenseGroupDetails expenseGroupDetails = new ExpenseGroupDetails();
        if (this.getAccountExpenseResponseType.getExpenseGroup() != null) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveExpenseGroupDetails method");
            expenseGroupDetails.setExpenseGroup(retrieveExpenseGroup(expenseGroup.getExpenseGroup()));
            expenseGroupDetails.setEffectiveDate(retrieveDateValue(expenseGroup.getEffectiveDate()));
            expenseGroupDetails.setOutlet(retrieveOutlet(expenseGroup.getOutlet()));
            expenseGroupDetails.setConsentDate(retrieveDateValue(expenseGroup.getConsentDate()));
        } else {
            expenseGroupDetails = retrieveEmptyExpenseGroupDetails();
        }
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveExpenseGroupDetails()");
        return expenseGroupDetails;
    }

    /**
     * This method constructs list of type ExpenseLine from response .
     * 
     * @param expenseLineDetailTypesLst
     * @return
     * @throws SILException
     */
    private List<ExpenseLineDetails> retrieveExpenseLineList(List<ExpenseLineDetailType> expenseLineDetailTypesLst) throws SILException {
        List<ExpenseLineDetails> expenseLineDetailsLst = new ArrayList<ExpenseLineDetails>();
        if (expenseLineDetailTypesLst != null && expenseLineDetailTypesLst.size() > 0) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveExpenseLineList method");
            for (ExpenseLineDetailType expenseLineDetailType : expenseLineDetailTypesLst) {
                if (expenseLineDetailType != null) {
                    expenseLineDetailsLst.add(retrieveExpenseLineDetails(expenseLineDetailType));
                }
            }
        } else {
            expenseLineDetailsLst.add(retrieveEmptyExpenseLineDetails());
        }
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveExpenseLineList method");
        return expenseLineDetailsLst;
    }

    /**
     * This method constructs ExternalRefinfo object from the response.
     * @param ExternalRef
     * @return
     * @throws SILException
     */
    private ReferenceIdentifier retrieveExternalRef(ExternalRefType ExternalRef) throws SILException {
        ReferenceIdentifier externalrefinfo = new ReferenceIdentifier();
        if (ExternalRef != null) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveExternalRef()");
            externalrefinfo.setReferenceCode(ExternalRef.getReferenceCode());
            externalrefinfo.setReference(ExternalRef.getReference());
        } else {
            externalrefinfo = retrieveEmptyExternalRef();
        }
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveExternalRef()");
        return externalrefinfo;
    }

    /**
     * This method constructs default ExternalRefinfo object .
     * @param externalrefinfo
     * @throws SILException
     */
    private ReferenceIdentifier retrieveEmptyExternalRef() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveEmptyExternalRef()");
        ReferenceIdentifier externalrefinfo = new ReferenceIdentifier();
        externalrefinfo.setReferenceCode(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        externalrefinfo.setReference(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveEmptyExternalRef()");
        return externalrefinfo;
    }

    /**
     * This method constructs MasterSchema object from the response.
     * 
     * @param masterSchemeIdentifier
     * @return
     * @throws SILException
     */
    private MasterSchemeIdentifier retrieveMasterSchemeDetails(MasterSchemeIdentifierType masterSchemeIdentifierType) throws SILException {
        MasterSchemeIdentifier masterSchemeIdentifier = new MasterSchemeIdentifier();
        if (masterSchemeIdentifierType != null) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveMasterSchemeDetails()");
            masterSchemeIdentifier.setDisplayName(masterSchemeIdentifierType.getDisplayName());
            masterSchemeIdentifier.setLongName(masterSchemeIdentifierType.getLongName());
        } else {
            masterSchemeIdentifier = retrieveEmptyMasterSchemeDetails();
        }
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveMasterSchemeDetails()");
        return masterSchemeIdentifier;
    }

    /**
     * This method constructs Empty MasterSchemeDetails object.
     * 
     * @return
     * @throws SILException
     */
    private MasterSchemeIdentifier retrieveEmptyMasterSchemeDetails() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveEmptyMasterSchemeDetails()");
        MasterSchemeIdentifier masterSchemeIdentifier = new MasterSchemeIdentifier();
        masterSchemeIdentifier.setDisplayName(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        masterSchemeIdentifier.setLongName(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveEmptyMasterSchemeDetails()");
        return masterSchemeIdentifier;
    }

    /**
     * This method constructs the auditinfo object from response.
     * 
     * @param audit
     * @return
     * @throws SILException
     */
    private AuditIdentifier retrieveAudit(IdentifierAuditType audit) throws SILException {
        AuditIdentifier auditIdentifier = new AuditIdentifier();
        if (audit != null) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveAudit method");
            auditIdentifier.setLastUpdated(retrieveDateValue(audit.getLastUpdated()));
            auditIdentifier.setLastUpdatedBy(audit.getLastUpdatedBy());
            auditIdentifier.setDataVersion(retrieveLongValue(audit.getDataVersion()));
        } else {
            auditIdentifier = retrieveEmptyAudit();
        }
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveAudit method");
        return auditIdentifier;
    }

    /**
     * This method constructs default Audit object.
     * 
     * @return codeInfo
     * @throws SILException
     */
    private AuditIdentifier retrieveEmptyAudit() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveEmptyAudit method");
        AuditIdentifier auditIdentifier = new AuditIdentifier();
        auditIdentifier.setLastUpdated(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        auditIdentifier.setLastUpdatedBy(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        auditIdentifier.setDataVersion(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveEmptyAudit method");
        return auditIdentifier;
    }

    /**
     * This method constructs the AccountNumber object from response.
     * @param accountNumber
     * @return
     * @throws SILException
     */
    private AccountNumberInfo retrieveAccountNumberDetails(AccountNumber accountNumber) throws SILException {
        AccountNumberInfo accountNumberInfo = new AccountNumberInfo();
        if (accountNumber != null) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveAccountNumberDetails method");
            accountNumberInfo.setAccountNo(accountNumber.getAccountNo());
            accountNumberInfo.setProductName(accountNumber.getProductName());
        } else {
            accountNumberInfo = retrieveEmptyAccountNumberDetails();
        }
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveAccountNumberDetails method");
        return accountNumberInfo;
    }

    /**
     * This method constructs the Empty AccountNumber object from response.
     * @return accountNumberInfo
     * @throws SILException
     */
    private AccountNumberInfo retrieveEmptyAccountNumberDetails() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveEmptyAccountNumberDetails method");
        AccountNumberInfo accountNumberInfo = new AccountNumberInfo();
        accountNumberInfo.setAccountNo(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        accountNumberInfo.setProductName(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveEmptyAccountNumberDetails method");
        return accountNumberInfo;
    }

    /**
     * This method constructs Decimal RangeIdentifier object from the response.
     * @param decimalRangeType
     * @return deciamlRangeIdentifier
     * @throws SILException
     */
    private DecimalRangeIdentifier retrieveDecimalRangeIdentifier(DecimalRangeType decimalRangeType) throws SILException {
        DecimalRangeIdentifier deciamlRangeIdentifier = new DecimalRangeIdentifier();
        if (decimalRangeType != null) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveDecimalRangeIdentifier method");
            deciamlRangeIdentifier.setMaximum(retrieveBigDecimalValue(decimalRangeType.getMaximum()));
            deciamlRangeIdentifier.setMinimum(retrieveBigDecimalValue(decimalRangeType.getMinimum()));
        } else {
            deciamlRangeIdentifier = retrieveEmptyDecimalRangeIdentifier();
        }
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveDecimalRangeIdentifier method");
        return deciamlRangeIdentifier;
    }

    /**
     * This method constructs Empty DecimalRangeIdentifier object
     * @return deciamlRangeIdentifier
     * @throws SILException
     */
    private DecimalRangeIdentifier retrieveEmptyDecimalRangeIdentifier() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveEmptyDecimalRangeIdentifier method");
        DecimalRangeIdentifier deciamlRangeIdentifier = new DecimalRangeIdentifier();
        deciamlRangeIdentifier.setMaximum(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        deciamlRangeIdentifier.setMinimum(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveEmptyDecimalRangeIdentifier method");
        return deciamlRangeIdentifier;
    }

    /**
     * This method constructs codeInfo object from the response.
     * 
     * @param codedetails
     * @return codeInfo throws SILException
     */
    private CodeIdentifier retrieveCode(CodeIdentifierType codedetails) throws SILException {
        CodeIdentifier codeInfo = new CodeIdentifier();
        if (codedetails != null) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveCode method");
            codeInfo.setId(retrieveLongValue(codedetails.getId()));
            codeInfo.setCode(codedetails.getCode());
            codeInfo.setCodeType(codedetails.getCodeType());
            codeInfo.setCodeShortDescription(codedetails.getCodeShortDescription());
            codeInfo.setCodeDescription(codedetails.getCodeDescription());
        } else {
            codeInfo = retrieveEmptyCode();
        }
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveCode method");
        return codeInfo;
    }

    /**
     * This method constructs default codeInfo object.
     * @return codeInfo throws SILException
     */
    private CodeIdentifier retrieveEmptyCode() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveEmptyCode method");
        CodeIdentifier codeInfo = new CodeIdentifier();
        codeInfo.setId(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        codeInfo.setCode(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        codeInfo.setCodeType(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        codeInfo.setCodeShortDescription(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        codeInfo.setCodeDescription(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveEmptyCode method");
        return codeInfo;
    }

    /**
     * This method constructs the AccountPointer object from response.
     * @param genericReference
     * @return accountPointer
     */
    private AccountPointer retrieveAccountPointerDetails(GenericReference genericReference) throws SILException {
        AccountPointer accountPointer = new AccountPointer();
        if (genericReference != null) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveAccountPointerDetails method");
            accountPointer.setId(genericReference.getId());
            accountPointer.setReference(retrieveObjectValue(genericReference.getRef()));
        } else {
            accountPointer = retrieveEmptyAccountPointer();
        }
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveAccountPointerDetails method");
        return accountPointer;
    }

    /**
     * This method constructs the Empty AccountPointer object.
     * @return accountPointer
     */
    private AccountPointer retrieveEmptyAccountPointer() {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveEmptyAccountPointer method");
        AccountPointer accountPointer = new AccountPointer();
        accountPointer.setId(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        accountPointer.setReference(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveEmptyAccountPointer method");
        return accountPointer;
    }

    /**
     * This method constructs the ExpenseGroup object from response.
     * @param expenseGroupIdentifierType
     * @return identityIdentifier
     * @throws SILException
     */
    private IdentityIdentifier retrieveExpenseGroup(ExpenseGroupIdentifierType expenseGroupIdentifierType) throws SILException {
        IdentityIdentifier identityIdentifier = new IdentityIdentifier();
        if (expenseGroupIdentifierType != null) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveExpenseGroup method");
            identityIdentifier.setId(retrieveLongValue(expenseGroupIdentifierType.getId()));
            identityIdentifier.setName(expenseGroupIdentifierType.getName());
            identityIdentifier.setAudit(retrieveAudit(expenseGroupIdentifierType.getAudit()));
        } else {
            identityIdentifier = retrieveEmptyExpenseGroup();
        }
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveExpenseGroup method");
        return identityIdentifier;
    }

    /**
     * This method constructs the Empty ExpenseGroup object from response.
     * @return identityIdentifier
     * @throws SILException
     */
    private IdentityIdentifier retrieveEmptyExpenseGroup() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveEmptyExpenseGroup method");
        IdentityIdentifier identityIdentifier = new IdentityIdentifier();
        identityIdentifier.setId(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        identityIdentifier.setName(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        identityIdentifier.setAudit(retrieveEmptyAudit());
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveEmptyExpenseGroup method");
        return identityIdentifier;
    }

    /**
     * This method constructs the Outlet object from response.
     * @param identifierType
     * @return idNameIdentifier
     * @throws SILException
     */
    private IdNameIdentifier retrieveOutlet(IdentifierType identifierType) throws SILException {
        IdNameIdentifier idNameIdentifier = new IdNameIdentifier();
        if (identifierType != null) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveOutlet method");
            idNameIdentifier.setId(retrieveLongValue(identifierType.getId()));
            idNameIdentifier.setName(identifierType.getName());
        } else {
            idNameIdentifier = retrieveEmptyOutlet();
        }
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveOutlet method");
        return idNameIdentifier;
    }

    /**
     * This method constructs the Empty Outlet object.
     * @param identifierType
     * @return idNameIdentifier
     * @throws SILException
     */
    private IdNameIdentifier retrieveEmptyOutlet() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveEmptyOutlet method");
        IdNameIdentifier idNameIdentifier = new IdNameIdentifier();
        idNameIdentifier.setId(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        idNameIdentifier.setName(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveEmptyOutlet method");
        return idNameIdentifier;
    }

    /**
     * This method constructs the ExpenseLine object from response.
     * @param expenseLineDetailType
     * @return expenseLineDetails
     * @throws SILException
     */
    private ExpenseLineDetails retrieveExpenseLineDetails(ExpenseLineDetailType expenseLineDetailType) throws SILException {
        ExpenseLineDetails expenseLineDetails = new ExpenseLineDetails();
        if (expenseLineDetailType != null) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveExpenseLine method");
            constructExpenseLine(expenseLineDetailType, expenseLineDetails);
        } else {
            expenseLineDetails = constructEmptyExpenseLine();
        }
        return expenseLineDetails;
    }

    /**
     * This method constructs the Empty ExpenseLineDetails object.
     * @return expenseLineDetails
     * @throws SILException
     */
    private ExpenseLineDetails retrieveEmptyExpenseLineDetails() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveEmptyExpenseLineDetails method");
        ExpenseLineDetails expenseLineDetails = new ExpenseLineDetails();
        expenseLineDetails = constructEmptyExpenseLine();
        return expenseLineDetails;
    }

    /**
     * method constructs the ExpenseLine object for valid response.
     * @param expenseLineDetailType
     * @param expenseLineDetails
     * @throws SILException
     */
    private void constructExpenseLine(ExpenseLineDetailType expenseLineDetailType, ExpenseLineDetails expenseLineDetails) throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in constructExpenseLine method");
        expenseLineDetails.setId(retrieveLongValue(expenseLineDetailType.getId()));
        expenseLineDetails.setName(expenseLineDetailType.getName());
        expenseLineDetails.setTransactionDetails(retrieveTransactionType(expenseLineDetailType.getTransactionType()));
        expenseLineDetails.setProcessName(retrieveCode(expenseLineDetailType.getProcessName()));
        expenseLineDetails.setExpenseDetails(retrieveExpenseType(expenseLineDetailType.getExpenseType()));
        expenseLineDetails.setFundRider(retrieveFundRiderDetails(expenseLineDetailType.getFundRider()));
        expenseLineDetails.setOverrideAllowed(retrieveBooleanValue(expenseLineDetailType.isOverrideAllowed()));
        expenseLineDetails.setOverridden(retrieveBooleanValue(expenseLineDetailType.isOverridden()));
        expenseLineDetails.setOverrideType(retrieveCode(expenseLineDetailType.getOverrideType()));
        expenseLineDetails.setParameterSetDetails(retrieveParameterSetDetails(expenseLineDetailType.getParameterSet()));
        expenseLineDetails.setParameterDetailsLst(retrieveParametersList(expenseLineDetailType.getParameter()));
        expenseLineDetails.setCalculationBasisDetails(retrieveCalculationBasisDetails(expenseLineDetailType.getCalculationBasis()));
        expenseLineDetails.setContributionType(retrieveCode(expenseLineDetailType.getContributionType()));
        expenseLineDetails.setMaxConsentAmount(retrieveBigDecimalValue(expenseLineDetailType.getMaxConsentAmount()));
        expenseLineDetails.setMaxConsentPercentage(retrieveBigDecimalValue(expenseLineDetailType.getMaxConsentPercentage()));
        expenseLineDetails.setExcludedAssetClass(retrieveCodeList(expenseLineDetailType.getExcludedAssetClass()));
        expenseLineDetails.setChargeBasis(retrieveCode(expenseLineDetailType.getChargeBasis()));
        expenseLineDetails.setFeeAccount(retrieveFeeAccountDetails(expenseLineDetailType.getFeeAccount()));
    }

    /**
     * method constructs Empty ExpenseLine object for valid response.
     * @param expenseLineDetailType
     * @param expenseLineDetails
     * @throws SILException
     */
    private ExpenseLineDetails constructEmptyExpenseLine() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in constructEmptyExpenseLine method");
        ExpenseLineDetails expenseLineDetails = new ExpenseLineDetails();
        expenseLineDetails.setId(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        expenseLineDetails.setName(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        expenseLineDetails.setTransactionDetails(retrieveEmptyTransactionType());
        expenseLineDetails.setProcessName(retrieveEmptyCode());
        expenseLineDetails.setExpenseDetails(retrieveEmptyExpenseType());
        expenseLineDetails.setFundRider(retrieveEmptyFundRider());
        expenseLineDetails.setOverrideAllowed(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        expenseLineDetails.setOverridden(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        expenseLineDetails.setOverrideType(retrieveEmptyCode());
        expenseLineDetails.setParameterSetDetails(retrieveEmptyParameterSetDetails());
        expenseLineDetails.setParameterDetailsLst(retrieveEmptyParametersList());
        expenseLineDetails.setCalculationBasisDetails(retrieveEmptyCalculationBasis());
        expenseLineDetails.setContributionType(retrieveEmptyCode());
        expenseLineDetails.setMaxConsentAmount(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        expenseLineDetails.setMaxConsentPercentage(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        expenseLineDetails.setExcludedAssetClass(retrieveEmptyCodeList());
        expenseLineDetails.setChargeBasis(retrieveEmptyCode());
        expenseLineDetails.setFeeAccount(retrieveEmptyFeeAccountDetails());
        return expenseLineDetails;
    }

    /**
     * This method constructs the TransactionType object from response.
     * @param transactionTypeIdentifierType
     * @return transactionDetails
     * @throws SILException
     */
    private TransactionDetails retrieveTransactionType(TransactionTypeIdentifierType transactionTypeIdentifierType) throws SILException {
        TransactionDetails transactionDetails = new TransactionDetails();
        if (transactionTypeIdentifierType != null) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveTransactionType method");
            transactionDetails.setCode(transactionTypeIdentifierType.getCode());
            transactionDetails.setCategoryDetails(retrieveCode(transactionTypeIdentifierType.getCategory()));
        } else {
            transactionDetails = retrieveEmptyTransactionType();
        }
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveTransactionType method");
        return transactionDetails;
    }

    /**
     * This method constructs the Empty TransactionType object.
     * 
     * @return
     * @throws SILException
     */
    private TransactionDetails retrieveEmptyTransactionType() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveEmptyTransactionType method");
        TransactionDetails transactionDetails = new TransactionDetails();
        transactionDetails.setCode(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        transactionDetails.setCategoryDetails(retrieveEmptyCode());
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveEmptyTransactionType method");
        return transactionDetails;
    }

    /**
     * This method constructs the ExpenseType object from response.
     * @param expenseTypeIdentifierType
     * @return expenseDetails
     * @throws SILException
     */
    private ExpenseDetails retrieveExpenseType(ExpenseTypeIdentifierType expenseTypeIdentifierType) throws SILException {
        ExpenseDetails expenseDetails = new ExpenseDetails();
        if (expenseTypeIdentifierType != null) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveExpenseType method");
            expenseDetails.setCode(expenseTypeIdentifierType.getCode());
            expenseDetails.setCategoryDetails(retrieveCode(expenseTypeIdentifierType.getCategory()));
        } else {
            expenseDetails = retrieveEmptyExpenseType();
        }
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveExpenseType method");
        return expenseDetails;
    }

    /**
     * This method constructs the Empty ExpenseType object.
     * @return expenseDetails
     * @throws SILException
     */
    private ExpenseDetails retrieveEmptyExpenseType() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveEmptyExpenseType method");
        ExpenseDetails expenseDetails = new ExpenseDetails();
        expenseDetails.setCode(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        expenseDetails.setCategoryDetails(retrieveEmptyCode());
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveEmptyExpenseType method");
        return expenseDetails;
    }

    /**
     * This method constructs the FundRider object from response.
     * @param fundRiderIdentifierType
     * @return fundRider
     * @throws SILException
     */
    private FundRider retrieveFundRiderDetails(FundRiderIdentifierType fundRiderIdentifierType) throws SILException {
        FundRider fundRider = new FundRider();
        if (fundRiderIdentifierType != null) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveFundRiderDetails method");
            fundRider.setLongName(fundRiderIdentifierType.getLongName());
            fundRider.setSystemCode(retrieveCode(fundRiderIdentifierType.getSystemCode()));
        } else {
            fundRider = retrieveEmptyFundRider();
        }
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveFundRiderDetails method");
        return fundRider;
    }

    /**
     * This method constructs the Empty FundRider object.
     * @return fundRider
     * @throws SILException
     */
    private FundRider retrieveEmptyFundRider() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveEmptyFundRider method");
        FundRider fundRider = new FundRider();
        fundRider.setLongName(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        fundRider.setSystemCode(retrieveEmptyCode());
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveEmptyFundRider method");
        return fundRider;
    }

    /**
     * This method constructs the ParameterSet object from response.
     * @param expenseParameterSetType
     * @return parameterSetDetails
     * @throws SILException
     */
    private ParameterSetDetails retrieveParameterSetDetails(ExpenseParameterSetType expenseParameterSetType) throws SILException {
        ParameterSetDetails parameterSetDetails = new ParameterSetDetails();
        if (expenseParameterSetType != null) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveParameterSetDetails method");
            parameterSetDetails.setCustom(retrieveBooleanValue(expenseParameterSetType.isCustom()));
            parameterSetDetails.setCalculationBook(retrieveCode(expenseParameterSetType.getCalculationBook()));
            parameterSetDetails.setName(expenseParameterSetType.getName());
        } else {
            parameterSetDetails = retrieveEmptyParameterSetDetails();
        }
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveParameterSetDetails method");
        return parameterSetDetails;
    }

    /**
     * This method constructs the Empty ParameterSet object.
     * @return parameterSetDetails
     * @throws SILException
     */
    private ParameterSetDetails retrieveEmptyParameterSetDetails() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveEmptyParameterSetDetails method");
        ParameterSetDetails parameterSetDetails = new ParameterSetDetails();
        parameterSetDetails.setCustom(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        parameterSetDetails.setCalculationBook(retrieveEmptyCode());
        parameterSetDetails.setName(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveEmptyParameterSetDetails method");
        return parameterSetDetails;
    }

    /**
     * This method constructs the List Parameters object from response.
     * @param expenseParameterLst
     * @return parameterDetailsList
     * @throws SILException
     */
    private List<ParameterDetails> retrieveParametersList(List<ExpenseParameterType> expenseParameterLst) throws SILException {
        List<ParameterDetails> parameterDetailsList = new ArrayList<ParameterDetails>();
        if (expenseParameterLst != null && expenseParameterLst.size() > 0) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveParametersList method");
            for (ExpenseParameterType expenseParameterType : expenseParameterLst) {
                if (expenseParameterType != null) {
                    parameterDetailsList.add(retrieveParametersDetails(expenseParameterType));
                }
            }
        } else {
            parameterDetailsList.add(retrieveEmptyParametersDetails());
        }
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveParametersList method");
        return parameterDetailsList;
    }

    /**
     * This method constructs the Empty ParametersList object.
     * @return parameterDetailsList
     * @throws SILException
     */
    private List<ParameterDetails> retrieveEmptyParametersList() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveEmptyParametersList method");
        List<ParameterDetails> parameterDetailsList = new ArrayList<ParameterDetails>();
        parameterDetailsList.add(retrieveEmptyParametersDetails());
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveEmptyParametersList method");
        return parameterDetailsList;
    }

    /**
     * This method constructs the Parameters object from response.
     * @param expenseParameterType
     * @return parameterDetails
     * @throws SILException
     */
    private ParameterDetails retrieveParametersDetails(ExpenseParameterType expenseParameterType) throws SILException {
        ParameterDetails parameterDetails = new ParameterDetails();
        if (expenseParameterType != null) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveParametersDetails method");
            parameterDetails.setTier(retrieveTierDetails(expenseParameterType.getTier()));
            parameterDetails.setAmount(retrieveBigDecimalValue(expenseParameterType.getAmount()));
            parameterDetails.setPercentage(retrieveBigDecimalValue(expenseParameterType.getPercentage()));
            parameterDetails.setAuditIdentifier(retrieveAudit(expenseParameterType.getAudit()));
        } else {
            parameterDetails = retrieveEmptyParametersDetails();
        }
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveParametersDetails method");
        return parameterDetails;
    }

    /**
     * This method constructs the Empty ParametersDetails object.
     * @return parameterDetails
     * @throws SILException
     */
    private ParameterDetails retrieveEmptyParametersDetails() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveEmptyParametersDetails method");
        ParameterDetails parameterDetails = new ParameterDetails();
        parameterDetails.setTier(retrieveEmptyTierDetails());
        parameterDetails.setAmount(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        parameterDetails.setPercentage(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        parameterDetails.setAuditIdentifier(retrieveEmptyAudit());
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveEmptyParametersDetails method");
        return parameterDetails;
    }

    /**
     * This method constructs the Tier object from response.
     * @param tier
     * @return tierDetails
     * @throws SILException
     */
    private TierDetails retrieveTierDetails(ExpenseParameterType.Tier tier) throws SILException {
        TierDetails tierDetails = new TierDetails();
        if (tier != null) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveTierDetails method");
            tierDetails.setDurationRangeTo(retrieveIntegerValue(tier.getDurationRangeTo()));
            tierDetails.setValueRangeTo(retrieveBigDecimalValue(tier.getValueRangeTo()));
        } else {

            tierDetails = retrieveEmptyTierDetails();
        }
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveTierDetails method");
        return tierDetails;
    }

    /**
     * This method constructs the Empty TierDetails object.
     * @return tierDetails
     * @throws SILException
     */
    private TierDetails retrieveEmptyTierDetails() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveEmptyTierDetails method");
        TierDetails tierDetails = new TierDetails();
        tierDetails.setDurationRangeTo(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        tierDetails.setValueRangeTo(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveEmptyTierDetails method");
        return tierDetails;
    }

    /**
     * This method constructs the CalculationBasis object from response.
     * @param calculationBasis
     * @return calculationBasisDetails
     * @throws SILException
     */
    private CalculationBasisDetails retrieveCalculationBasisDetails(CalculationBasis calculationBasis) throws SILException {
        CalculationBasisDetails calculationBasisDetails = new CalculationBasisDetails();
        if (calculationBasis != null) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveCalculationBasisDetails method");
            calculationBasisDetails.setId(retrieveLongValue(calculationBasis.getId()));
            calculationBasisDetails.setCalculationBook(retrieveCode(calculationBasis.getCalculationBook()));
            calculationBasisDetails.setAmount(retrieveDecimalRangeIdentifier(calculationBasis.getAmount()));
            calculationBasisDetails.setPercentage(retrieveDecimalRangeIdentifier(calculationBasis.getPercentage()));
        } else {
            calculationBasisDetails = retrieveEmptyCalculationBasis();
        }

        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveCalculationBasisDetails method");
        return calculationBasisDetails;
    }

    /**
     * This method constructs the Empty CalculationBasis object.
     * @return calculationBasisDetails
     * @throws SILException
     */
    private CalculationBasisDetails retrieveEmptyCalculationBasis() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveEmptyCalculationBasis method");
        CalculationBasisDetails calculationBasisDetails = new CalculationBasisDetails();
        calculationBasisDetails.setId(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        calculationBasisDetails.setCalculationBook(retrieveEmptyCode());
        calculationBasisDetails.setAmount(retrieveEmptyDecimalRangeIdentifier());
        calculationBasisDetails.setPercentage(retrieveEmptyDecimalRangeIdentifier());
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveEmptyCalculationBasis method");
        return calculationBasisDetails;
    }

    /**
     * This method constructs the List of code object from response.
     * @param calculationBasisList
     * @return codeIdentifiersList
     * @throws SILException
     */
    private List<CodeIdentifier> retrieveCodeList(List<CodeIdentifierType> calculationBasisList) throws SILException {

        List<CodeIdentifier> codeIdentifiersList = new ArrayList<CodeIdentifier>();
        if (calculationBasisList != null && calculationBasisList.size() > 0) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveCodeList method");
            for (CodeIdentifierType codeIdentifierType : calculationBasisList) {
                if (codeIdentifierType != null) {
                    codeIdentifiersList.add(retrieveCode(codeIdentifierType));
                }
            }
        } else {
            codeIdentifiersList.add(retrieveEmptyCode());
        }
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveCodeList method");
        return codeIdentifiersList;
    }

    /**
     * This method constructs the EmptyCodeList object.
     * @return codeIdentifiersList
     * @throws SILException
     */
    private List<CodeIdentifier> retrieveEmptyCodeList() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveEmptyCodeList method");
        List<CodeIdentifier> codeIdentifiersList = new ArrayList<CodeIdentifier>();
        codeIdentifiersList.add(retrieveEmptyCode());
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveEmptyCodeList method");
        return codeIdentifiersList;
    }

    /**
     * This method constructs the FeeAccount object from response.
     * @param accountIdentifierType
     * @return accountIdentifierDetails
     * @throws SILException
     */
    private AccountIdentifierDetails retrieveFeeAccountDetails(AccountIdentifierType accountIdentifierType) throws SILException {
        AccountIdentifierDetails accountIdentifierDetails = new AccountIdentifierDetails();
        if (accountIdentifierType != null) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveFeeAccountDetails method");
            accountIdentifierDetails.setId(retrieveLongValue(accountIdentifierType.getId()));
            accountIdentifierDetails.setName(accountIdentifierType.getName());
            accountIdentifierDetails.setAccountNumber(retrieveAccountNumberDetails(accountIdentifierType.getAccountNumber()));
            accountIdentifierDetails.setAccountRef(retrieveReferenceIdentifier(accountIdentifierType.getAccountExternalRef()));
            accountIdentifierDetails.setStatusCode(retrieveCode(accountIdentifierType.getStatusCode()));
            accountIdentifierDetails.setAudit(retrieveAudit(accountIdentifierType.getAudit()));
            accountIdentifierDetails.setAccountPointer(retrieveAccountPointerDetails(accountIdentifierType.getAccountPointer()));
            accountIdentifierDetails.setMasterScheme(retrieveMasterSchemeDetails(accountIdentifierType.getMasterScheme()));
        } else {
            accountIdentifierDetails = retrieveEmptyFeeAccountDetails();
        }
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveFeeAccountDetails method");
        return accountIdentifierDetails;
    }

    /**
     * This method constructs the Empty FeeAccount object from response.
     * @return accountIdentifierDetails
     * @throws SILException
     */
    private AccountIdentifierDetails retrieveEmptyFeeAccountDetails() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveEmptyFeeAccountDetails method");
        AccountIdentifierDetails accountIdentifierDetails = new AccountIdentifierDetails();
        accountIdentifierDetails.setId(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        accountIdentifierDetails.setName(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        accountIdentifierDetails.setAccountNumber(retrieveEmptyAccountNumberDetails());
        accountIdentifierDetails.setAccountRef(retrieveEmptyReferenceIdentifier());
        accountIdentifierDetails.setStatusCode(retrieveEmptyCode());
        accountIdentifierDetails.setAudit(retrieveEmptyAudit());
        accountIdentifierDetails.setAccountPointer(retrieveEmptyAccountPointer());
        accountIdentifierDetails.setMasterScheme(retrieveEmptyMasterSchemeDetails());
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveEmptyFeeAccountDetails method");
        return accountIdentifierDetails;
    }

    /**
     * This method constructs ReferenceIdentifier object from the response.
     * @param externalRefType
     * @return referenceIdentifier
     * @throws SILException
     */
    private ReferenceIdentifier retrieveReferenceIdentifier(ExternalRefType externalRefType) throws SILException {
        ReferenceIdentifier referenceIdentifier = new ReferenceIdentifier();
        if (externalRefType != null) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveReferenceIdentifier method");
            referenceIdentifier.setReference(externalRefType.getReference());
            referenceIdentifier.setReferenceCode(externalRefType.getReferenceCode());
        } else {
            referenceIdentifier = retrieveEmptyReferenceIdentifier();
        }
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveReferenceIdentifier method");
        return referenceIdentifier;
    }

    /**
     * This method constructs Empty ReferenceIdentifier object.
     * @return referenceIdentifier
     * @throws SILException
     */
    private ReferenceIdentifier retrieveEmptyReferenceIdentifier() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveEmptyReferenceIdentifier method");
        ReferenceIdentifier referenceIdentifier = new ReferenceIdentifier();
        referenceIdentifier.setReference(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        referenceIdentifier.setReferenceCode(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveEmptyReferenceIdentifier method");
        return referenceIdentifier;
    }

    /**
     * This method constructs default Advisor object.
     * @return advisorDetails
     * @throws SILException
     */
    private AdvisorDetails retrieveEmptyAdvisor() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveEmptyAdvisor method");
        AdvisorDetails advisorDetails = new AdvisorDetails();
        advisorDetails.setId(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        advisorDetails.setName(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        advisorDetails.setAdvisorNumber(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        advisorDetails.setClientId(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        advisorDetails.setClientExternalRef(retrieveEmptyExternalRef());
        advisorDetails.setClientForename(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        advisorDetails.setClientSurname(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        advisorDetails.setMasterScheme(retrieveEmptyMasterSchemeDetails());
        advisorDetails.setUsername(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        advisorDetails.setAudit(retrieveEmptyAudit());
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveEmptyAdvisor method");
        return advisorDetails;
    }

    /**
     * This method constructs default Product object.
     * @return productDetails
     */
    private ProductDetails retrieveEmptyProductDetails() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveEmptyProductDetails method");
        ProductDetails productDetails = new ProductDetails();
        productDetails.setId(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        productDetails.setName(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        productDetails.setShortName(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        productDetails.setProductRef(retrieveEmptyExternalRef());
        productDetails.setAudit(retrieveEmptyAudit());
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveEmptyProductDetails method");
        return productDetails;
    }

    /**
     * This method constructs default MarketingCampaign object.
     * @return marketingCampaignDetails
     */
    private MarketingCampaignDetails retrieveEmptyMarketingCampaign() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveEmptyMarketingCampaign method");
        MarketingCampaignDetails marketingCampaignDetails = new MarketingCampaignDetails();
        marketingCampaignDetails.setId(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        marketingCampaignDetails.setName(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        marketingCampaignDetails.setCode(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        marketingCampaignDetails.setDescription(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        marketingCampaignDetails.setAudit(retrieveEmptyAudit());
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveEmptyMarketingCampaign method");
        return marketingCampaignDetails;
    }

    /**
     * This method constructs Empty AccountDetails object.
     * @return
     */
    private AccountDetails retrieveEmptyAccountDetails() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveEmptyAccount method");
        AccountDetails accountDetails = new AccountDetails();
        accountDetails.setId(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        accountDetails.setName(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        accountDetails.setAccountNumber(retrieveEmptyAccountNumberDetails());
        accountDetails.setAccountExternalRef(retrieveEmptyExternalRef());
        accountDetails.setStatusCode(retrieveEmptyCode());
        accountDetails.setAudit(retrieveEmptyAudit());
        accountDetails.setAccountPointer(retrieveEmptyAccountPointer());
        accountDetails.setMasterScheme(retrieveEmptyMasterSchemeDetails());
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveEmptyAccount method");
        return accountDetails;
    }

    /**
     * This method constructs Empty ExpenseGroup object.
     * @return
     */
    private ExpenseGroupDetails retrieveEmptyExpenseGroupDetails() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveEmptyExpenseGroupDetails method");
        ExpenseGroupDetails expenseGroupDetails = new ExpenseGroupDetails();
        expenseGroupDetails.setExpenseGroup(retrieveEmptyExpenseGroup());
        expenseGroupDetails.setEffectiveDate(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        expenseGroupDetails.setOutlet(retrieveEmptyOutlet());
        expenseGroupDetails.setConsentDate(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Exiting in retrieveEmptyExpenseGroupDetails method");
        return expenseGroupDetails;
    }

    /**
     * This method convert XMLGregorianCalendar to String.
     * @return
     */
    private String retrieveDateValue(XMLGregorianCalendar gregorianCalendar) throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveDateValue method");
        return (gregorianCalendar != null) ? SILUtil.convertXMLGregorianCalendartoString(gregorianCalendar, CommonConstants.DATE_TIME_FORMAT)
                : AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING;
    }

    /**
     * This method convert Big decimal value to String object.
     * @return
     */
    private String retrieveBigDecimalValue(BigDecimal value) throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveBigDecimalValue method");
        return (value != null) ? value.toString() : AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING;
    }

    /**
     * This method convert Big decimal value to String object.
     * @return
     */
    private String retrieveLongValue(Long value) throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveLongValue method");
        return (value != null) ? String.valueOf(value) : AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING;
    }

    /**
     * This method convert Boolean value to String object.
     * @return
     */
    private String retrieveBooleanValue(Boolean value) throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveBooleanValue method");
        return (value != null) ? String.valueOf(value) : AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING;
    }

    /**
     * This method convert Integer value to String object.
     * @return
     */
    private String retrieveIntegerValue(Integer value) throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveIntegerValue method");
        return (value != null) ? String.valueOf(value) : AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING;
    }

    /**
     * This method convert Object value to String object.
     * @return
     */
    private String retrieveObjectValue(Object value) throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveObjectValue method");
        return (value != null) ? String.valueOf(value) : AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING;
    }
}
