////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code BeneficiaryDetails} does this.
 * 
 * @author u387938
 * @since 28/10/2015
 * @version 1.0
 */
public class ExpenseDetails {

    private String code;
    private CodeIdentifier categoryDetails;

    /**
     * Accessor for property code.
     * 
     * @return code of type String
     */
    public String getCode() {
        return code;
    }

    /**
     * Mutator for property code.
     * 
     * @param code of type String
     */
    @XmlElement(name = "code")
    public void setCode(String code) {
        this.code = code != null ? code : "";
    }

    /**
     * Accessor for property categoryDetails.
     * 
     * @return categoryDetails of type CodeIdentifier
     */
    public CodeIdentifier getCategoryDetails() {
        return categoryDetails;
    }

    /**
     * Mutator for property categoryDetails.
     * 
     * @param categoryDetails of type CodeIdentifier
     */
    @XmlElement(name = "category")
    public void setCategoryDetails(CodeIdentifier categoryDetails) {
        this.categoryDetails = categoryDetails;
    }

}
