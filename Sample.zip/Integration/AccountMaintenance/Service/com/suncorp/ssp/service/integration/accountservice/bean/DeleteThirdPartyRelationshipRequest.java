////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * The class {@code DeleteThirdPartyRelRequest} is used as request bean for Delete Third Party Relationship Request.
 * 
 * @author u385424
 * @since 17/03/2016
 * @version 1.0
 */
@XmlRootElement(name = "DeleteThirdPartyRelationshipRequest")
public class DeleteThirdPartyRelationshipRequest {
    private DeleteRelationshipDetails thirdPartyDetails;

    /**
     * Accessor for property thirdPartyDetails.
     * 
     * @return thirdPartyDetails of type DeleteRelationshipDetails
     */
    public DeleteRelationshipDetails getThirdPartyDetails() {
        return thirdPartyDetails;
    }

    /**
     * Mutator for property thirdPartyDetails.
     * 
     * @param thirdPartyDetails of type DeleteRelationshipDetails
     */
    @XmlElement(name = "thirdPartyDetails")
    public void setThirdPartyDetails(DeleteRelationshipDetails thirdPartyDetails) {
        this.thirdPartyDetails = thirdPartyDetails;
    };

}
