////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code BenefitDetails} does this.
 * 
 * @author U385424
 * @since 23/01/2017
 * @version 1.0
 */
public class BenefitDetails {
    private String id;
    private String name;
    private String riderName;

    /**
     * Accessor for property id.
     * 
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     * 
     * @param id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id != null ? id : "";
    }

    /**
     * Accessor for property name.
     * 
     * @return name of type String
     */
    public String getName() {
        return name;
    }

    /**
     * Mutator for property name.
     * 
     * @param name of type String
     */
    @XmlElement(name = "name")
    public void setName(String name) {
        this.name = name != null ? name : "";
    }

    /**
     * Accessor for property riderName.
     * 
     * @return riderName of type String
     */
    public String getRiderName() {
        return riderName;
    }

    /**
     * Mutator for property riderName.
     * 
     * @param riderName of type String
     */
    @XmlElement(name = "riderName")
    public void setRiderName(String riderName) {
        this.riderName = riderName != null ? riderName : "";
    }
}
