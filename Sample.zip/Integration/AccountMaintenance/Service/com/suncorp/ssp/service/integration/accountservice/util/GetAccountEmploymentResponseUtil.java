////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import java.util.ArrayList;
import java.util.List;

import com.sonatacentral.service.v30.globaltypes.common.scheme.schemegrouptype.EmploymentType;
import com.sonatacentral.service.v30.globaltypes.common.scheme.schemegrouptype.EmploymentType.History;
import com.sonatacentral.service.v30.globaltypes.common.scheme.schemegrouptype.EmploymentType.Salary;
import com.sonatacentral.service.v30.globaltypes.common.scheme.schemegrouptype.SchemeLocationIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType;
import com.sonatacentral.service.v30.wrap.account.GetAccountEmploymentResponseType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.AccountDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.EmployerDetailsBean;
import com.suncorp.ssp.service.integration.accountservice.bean.EmploymentDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.GetAccountEmploymentResponseBean;
import com.suncorp.ssp.service.integration.accountservice.bean.HistoryDetailsBean;
import com.suncorp.ssp.service.integration.accountservice.bean.SalaryDetails;

/**
 * The class {@code GetAccountEmploymentResponseUtil} is used as a util class for preparing GetAccountEmployment response.
 * 
 * @author u387938
 * @since 12/09/2016
 * @version 1.0
 */
public class GetAccountEmploymentResponseUtil {
    private final String className = "GetAccountEmploymentResponseUtil";
    private GetAccountEmploymentResponseType inboundResponse;
    private GetAccountEmploymentResponseBean outboundResponse;

    /**
     * Initializes class properties,viz., inbound and outbound response types.
     * 
     * @param inboundResponse
     */
    public GetAccountEmploymentResponseUtil(GetAccountEmploymentResponseType inboundResponse) {
        this.inboundResponse = inboundResponse;
        this.outboundResponse = new GetAccountEmploymentResponseBean();
    }

    /**
     * create the outbound response.
     * 
     * @return outboundResponse of type GetAccountEmploymentResponseBean
     * @throws SILException
     */
    public GetAccountEmploymentResponseBean createOutboundResponse() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACCOUNT_EMPLOYMENT_LOGGING_FORMAT, className, "Entering createOutboundResponse()");
        if (this.inboundResponse != null) {
            if (this.inboundResponse.getAccount() != null) {
                this.outboundResponse.setAccount(retrieveAccount(this.inboundResponse.getAccount()));
            }
            this.outboundResponse.setEmployment(retrieveEmploymentDetailsLst(this.inboundResponse.getEmployment()));

        } else {
            throw new SILException(AccountServiceConstants.INVALID_RESPONSE_FROM_SONATA);
        }
        return this.outboundResponse;
    }

    /**
     * This method constructs the Account object from response.
     * 
     * @param accountIdentifierType
     * @return accountDetails
     * @throws SILException
     */
    private AccountDetails retrieveAccount(AccountIdentifierType accountIdentifierType) throws SILException {
        AccountDetails accountDetails = new AccountDetails();
        String loggerType = AccountServiceConstants.GET_ACCOUNT_EMPLOYMENT_LOGGING_FORMAT;
        if (accountIdentifierType != null) {
            AccountServiceUtil accountServiceCommonUtil = new AccountServiceUtil();
            SILLogger.debug(AccountServiceConstants.GET_ACCOUNT_EMPLOYMENT_LOGGING_FORMAT, className, "Entering in retrieveAccount method");
            accountDetails.setId(accountServiceCommonUtil.retrieveLongValue(accountIdentifierType.getId(), loggerType));
            accountDetails.setName(accountIdentifierType.getName());
            accountDetails.setAccountNumber(accountServiceCommonUtil.retrieveAccountNumberDetails(accountIdentifierType.getAccountNumber(),
                    loggerType));
            accountDetails.setAccountExternalRef(accountServiceCommonUtil.retrieveExternalRef(accountIdentifierType.getAccountExternalRef(),
                    loggerType));
            accountDetails.setStatusCode(accountServiceCommonUtil.retrieveCode(accountIdentifierType.getStatusCode(), loggerType));
            accountDetails.setAudit(accountServiceCommonUtil.retrieveAudit(accountIdentifierType.getAudit(), loggerType));
            accountDetails.setAccountPointer(accountServiceCommonUtil.retrieveAccountPointerDetails(accountIdentifierType.getAccountPointer(),
                    loggerType));
            accountDetails.setMasterScheme(accountServiceCommonUtil.retrieveMasterSchemeDetails(accountIdentifierType.getMasterScheme(), loggerType));
        } else {
            accountDetails = retrieveEmptyAccount();
        }
        return accountDetails;
    }

    /**
     * This method constructs Empty Account object.
     * 
     * @return accountDetails
     */
    private AccountDetails retrieveEmptyAccount() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACCOUNT_EMPLOYMENT_LOGGING_FORMAT, className, "Entering in retrieveEmptyAccount method");
        AccountServiceUtil accountServiceCommonUtil = new AccountServiceUtil();
        AccountDetails accountDetails = new AccountDetails();
        accountDetails.setId(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        accountDetails.setName(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        accountDetails.setAccountNumber(accountServiceCommonUtil
                .retrieveEmptyAccountNumberDetails(AccountServiceConstants.GET_ACCOUNT_EMPLOYMENT_LOGGING_FORMAT));
        accountDetails.setAccountExternalRef(accountServiceCommonUtil
                .retrieveEmptyExternalRef(AccountServiceConstants.GET_ACCOUNT_EMPLOYMENT_LOGGING_FORMAT));
        accountDetails.setStatusCode(accountServiceCommonUtil.retrieveEmptyCode(AccountServiceConstants.GET_ACCOUNT_EMPLOYMENT_LOGGING_FORMAT));
        accountDetails.setAudit(accountServiceCommonUtil.retrieveEmptyAudit(AccountServiceConstants.GET_ACCOUNT_EMPLOYMENT_LOGGING_FORMAT));
        accountDetails.setAccountPointer(accountServiceCommonUtil
                .retrieveEmptyAccountPointer(AccountServiceConstants.GET_ACCOUNT_EMPLOYMENT_LOGGING_FORMAT));
        accountDetails.setMasterScheme(accountServiceCommonUtil
                .retrieveEmptyMasterSchemeDetails(AccountServiceConstants.GET_ACCOUNT_EMPLOYMENT_LOGGING_FORMAT));
        SILLogger.debug(AccountServiceConstants.GET_ACCOUNT_EMPLOYMENT_LOGGING_FORMAT, className, "Exiting in retrieveEmptyAccount method");
        return accountDetails;
    }

    /**
     * 
     * Retrieve Employment detalis List.
     * 
     * @param employments
     * @return employmentDetailsList
     * @throws SILException
     */
    public List<EmploymentDetails> retrieveEmploymentDetailsLst(List<EmploymentType> employments) throws SILException {
        List<EmploymentDetails> employmentDetailsList = new ArrayList<EmploymentDetails>();
        if (employments != null && employments.size() > 0) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className,
                    "Entering in retrieveAdvisorGroupDetailsLst method");
            for (EmploymentType employmentType : employments) {
                if (employmentType != null) {
                    employmentDetailsList.add(retrieveEmploymentDetails(employmentType));
                }
            }
        } else {
            employmentDetailsList.add(retrieveEmptyEmploymentDetails());
        }
        return employmentDetailsList;
    }

    /**
     * 
     * Retrieve employment details.
     * 
     * @param employmentType
     * @return employmentDetails
     * @throws SILException
     */
    public EmploymentDetails retrieveEmploymentDetails(EmploymentType employmentType) throws SILException {
        EmploymentDetails employmentDetails = new EmploymentDetails();
        String logger = AccountServiceConstants.GET_ACCOUNT_EMPLOYMENT_LOGGING_FORMAT;
        AccountServiceUtil commonUtil = new AccountServiceUtil();
        if (employmentType != null) {
            employmentDetails.setId(commonUtil.retrieveLongValue(employmentType.getId(), logger));
            employmentDetails.setStartDate(commonUtil.retrieveDateValue(employmentType.getStartDate(), logger));
            employmentDetails.setEmploymentType(commonUtil.retrieveCode(employmentType.getEmploymentType(), logger));
            employmentDetails.setPrimaryEmployer(commonUtil.retrieveBooleanValue(employmentType.isPrimaryEmployer(), logger));
            employmentDetails.setEmploymentRecordType(commonUtil.retrieveCode(employmentType.getEmploymentRecordType(), logger));
            employmentDetails.setParticipating(commonUtil.retrieveBooleanValue(employmentType.isParticipating(), logger));
            employmentDetails.setSalaries(retrieveSalaryList(employmentType.getSalary()));
            employmentDetails.setHistory(retrieveHistoryList(employmentType.getHistory()));
            employmentDetails.setEndDate(commonUtil.retrieveDateValue(employmentType.getEndDate(), logger));
            employmentDetails.setPayrollId(employmentType.getPayrollId());
            employmentDetails.setEmployer(retrieveEmployerDetails(employmentType.getEmployer()));
        }
        return employmentDetails;
    }

    /**
     * 
     * Retrieve employment details.
     * 
     * @param employmentType
     * @return employmentDetails
     * @throws SILException
     */
    public EmploymentDetails retrieveEmptyEmploymentDetails() throws SILException {
        EmploymentDetails employmentDetails = new EmploymentDetails();
        String logger = AccountServiceConstants.GET_ACCOUNT_EMPLOYMENT_LOGGING_FORMAT;
        AccountServiceUtil commonUtil = new AccountServiceUtil();
        employmentDetails.setId(AccountServiceConstants.GET_ACC_EMPLOYMENT_EMPTY_STRING);
        employmentDetails.setStartDate(AccountServiceConstants.GET_ACC_EMPLOYMENT_EMPTY_STRING);
        employmentDetails.setEmploymentType(commonUtil.retrieveEmptyCode(logger));
        employmentDetails.setPrimaryEmployer(AccountServiceConstants.GET_ACC_EMPLOYMENT_EMPTY_STRING);
        employmentDetails.setEmploymentRecordType(commonUtil.retrieveEmptyCode(logger));
        employmentDetails.setParticipating(AccountServiceConstants.GET_ACC_EMPLOYMENT_EMPTY_STRING);
        employmentDetails.setSalaries(retrieveEmptySalaryList());
        employmentDetails.setHistory(retrieveEmptyHistoryList());
        employmentDetails.setEndDate(AccountServiceConstants.GET_ACC_EMPLOYMENT_EMPTY_STRING);
        employmentDetails.setPayrollId(AccountServiceConstants.GET_ACC_EMPLOYMENT_EMPTY_STRING);
        employmentDetails.setEmployer(retrieveEmptyEmployerDetails());
        return employmentDetails;
    }

    /**
     * 
     * Retrieve Salary list.
     * 
     * @param salaries
     * @return salaryDetailsList
     * @throws SILException
     */
    public List<SalaryDetails> retrieveSalaryList(List<Salary> salaries) throws SILException {
        List<SalaryDetails> salaryDetailsList = new ArrayList<SalaryDetails>();
        if (salaries != null && salaries.size() > 0) {
            for (Salary salary : salaries) {
                if (salary != null) {
                    salaryDetailsList.add(retrieveSalaryDetails(salary));
                }
            }

        } else {
            salaryDetailsList = retrieveEmptySalaryList();
        }
        return salaryDetailsList;
    }

    /**
     * 
     * Retrieve Empty Salary list.
     * 
     * @param salaries
     * @return salaryDetailsList
     * @throws SILException
     */
    public List<SalaryDetails> retrieveEmptySalaryList() throws SILException {
        List<SalaryDetails> salaryDetailsList = new ArrayList<SalaryDetails>();
        salaryDetailsList.add(retrieveEmptySalaryDetails());
        return salaryDetailsList;
    }

    /**
     * 
     * Retrieve Salary details.
     * 
     * @param salary
     * @return salaryDetails
     * @throws SILException
     */
    public SalaryDetails retrieveSalaryDetails(Salary salary) throws SILException {
        SalaryDetails salaryDetails = new SalaryDetails();
        String logger = AccountServiceConstants.GET_ACCOUNT_EMPLOYMENT_LOGGING_FORMAT;
        AccountServiceUtil commonUtil = new AccountServiceUtil();
        if (salary != null) {
            salaryDetails.setId(commonUtil.retrieveLongValue(salary.getId(), logger));
            //salaryDetails.setServiceFraction(commonUtil.retrieveBigDecimalValue(salary.getServiceFraction(), logger));
            salaryDetails.setEffectiveFrom(commonUtil.retrieveDateValue(salary.getEffectiveFrom(), logger));
            salaryDetails.setSalary(commonUtil.retrieveBigDecimalValue(salary.getSalary(), logger));
            salaryDetails.setSalaryType(commonUtil.retrieveCode(salary.getSalaryType(), logger));
        } else {
            salaryDetails = retrieveEmptySalaryDetails();
        }
        return salaryDetails;
    }

    /**
     * 
     * Retrieve Salary details.
     * 
     * @param salary
     * @return salaryDetails
     * @throws SILException
     */
    public SalaryDetails retrieveEmptySalaryDetails() throws SILException {
        SalaryDetails salaryDetails = new SalaryDetails();
        String logger = AccountServiceConstants.GET_ACCOUNT_EMPLOYMENT_LOGGING_FORMAT;
        AccountServiceUtil commonUtil = new AccountServiceUtil();
        salaryDetails.setId(AccountServiceConstants.GET_ACC_EMPLOYMENT_EMPTY_STRING);
        salaryDetails.setServiceFraction(AccountServiceConstants.GET_ACC_EMPLOYMENT_EMPTY_STRING);
        salaryDetails.setEffectiveFrom(AccountServiceConstants.GET_ACC_EMPLOYMENT_EMPTY_STRING);
        salaryDetails.setSalary(AccountServiceConstants.GET_ACC_EMPLOYMENT_EMPTY_STRING);
        salaryDetails.setSalaryType(commonUtil.retrieveEmptyCode(logger));
        return salaryDetails;
    }

    /**
     * 
     * Retrieve History List.
     * 
     * @param histories
     * @return historyDetailsBeans
     * @throws SILException
     */
    public List<HistoryDetailsBean> retrieveHistoryList(List<History> histories) throws SILException {
        List<HistoryDetailsBean> historyDetailsBeans = new ArrayList<HistoryDetailsBean>();
        if (histories != null && histories.size() > 0) {
            for (History history : histories) {
                if (history != null) {
                    historyDetailsBeans.add(retrieveHistoryDetails(history));
                }
            }

        } else {
            historyDetailsBeans = retrieveEmptyHistoryList();
        }
        return historyDetailsBeans;
    }

    /**
     * 
     * Retrieve Empty History List.
     * 
     * @return historyDetailsBeans
     * @throws SILException
     */
    public List<HistoryDetailsBean> retrieveEmptyHistoryList() throws SILException {
        List<HistoryDetailsBean> historyDetailsBeans = new ArrayList<HistoryDetailsBean>();
        historyDetailsBeans.add(retrieveEmptyHistoryDetails());
        return historyDetailsBeans;
    }

    /**
     * 
     * Retrieve History details.
     * 
     * @param history
     * @return historyDetailsBean
     * @throws SILException
     */
    public HistoryDetailsBean retrieveHistoryDetails(History history) throws SILException {
        HistoryDetailsBean historyDetailsBean = new HistoryDetailsBean();
        String logger = AccountServiceConstants.GET_ACCOUNT_EMPLOYMENT_LOGGING_FORMAT;
        AccountServiceUtil commonUtil = new AccountServiceUtil();
        if (history != null) {
            historyDetailsBean.setId(commonUtil.retrieveLongValue(history.getId(), logger));
            historyDetailsBean.setEmploymentStatus(commonUtil.retrieveCode(history.getEmploymentStatus(), logger));
            historyDetailsBean.setStartDate(commonUtil.retrieveDateValue(history.getStartDate(), logger));
        } else {
            historyDetailsBean = retrieveEmptyHistoryDetails();
        }
        return historyDetailsBean;
    }

    /**
     * 
     * Retrieve Empty History details.
     * 
     * @return historyDetailsBean
     * @throws SILException
     */
    public HistoryDetailsBean retrieveEmptyHistoryDetails() throws SILException {
        HistoryDetailsBean historyDetailsBean = new HistoryDetailsBean();
        String logger = AccountServiceConstants.GET_ACCOUNT_EMPLOYMENT_LOGGING_FORMAT;
        AccountServiceUtil commonUtil = new AccountServiceUtil();
        historyDetailsBean.setId(AccountServiceConstants.GET_ACC_EMPLOYMENT_EMPTY_STRING);
        historyDetailsBean.setEmploymentStatus(commonUtil.retrieveEmptyCode(logger));
        historyDetailsBean.setStartDate(AccountServiceConstants.GET_ACC_EMPLOYMENT_EMPTY_STRING);
        return historyDetailsBean;
    }

    /**
     * Retrieve Employer Details.
     * 
     * @param schemeLocationIdentifierType
     * 
     * @param employer
     * @return
     * @throws SILException
     */
    private EmployerDetailsBean retrieveEmployerDetails(SchemeLocationIdentifierType schemeLocationIdentifierType) throws SILException {
        EmployerDetailsBean employerDetailsBean = new EmployerDetailsBean();
        AccountServiceUtil commonUtil = new AccountServiceUtil();
        if (schemeLocationIdentifierType != null) {
            employerDetailsBean.setId(commonUtil.retrieveLongValue(schemeLocationIdentifierType.getId(),
                    AccountServiceConstants.GET_ACCOUNT_EMPLOYMENT_LOGGING_FORMAT));
        } else {
            employerDetailsBean = retrieveEmptyEmployerDetails();
        }
        return employerDetailsBean;
    }

    /**
     * retrieve Empty Employer Details
     * 
     * @return
     */
    private EmployerDetailsBean retrieveEmptyEmployerDetails() {
        EmployerDetailsBean employerDetailsBean = new EmployerDetailsBean();
        employerDetailsBean.setId(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        return employerDetailsBean;
    }
}
