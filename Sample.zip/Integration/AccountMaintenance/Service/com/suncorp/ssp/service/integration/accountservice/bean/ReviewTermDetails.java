////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code ReviewTermDetails} does this.
 * 
 * @author U385424
 * @since 17/02/2018
 * @version 1.0
 */
public class ReviewTermDetails {

    private String reviewTerm;
    private String subseqReviewTerm;

    /**
     * Accessor for property reviewTerm.
     * 
     * @return reviewTerm of type String
     */
    public String getReviewTerm() {
        return reviewTerm;
    }

    /**
     * Mutator for property reviewTerm.
     * 
     * @return reviewTerm of type String
     */
    @XmlElement(name = "reviewTerm")
    public void setReviewTerm(String reviewTerm) {
        this.reviewTerm = reviewTerm != null ? reviewTerm : "";
    }

    /**
     * Accessor for property subseqReviewTerm.
     * 
     * @return subseqReviewTerm of type String
     */
    public String getSubseqReviewTerm() {
        return subseqReviewTerm;
    }

    /**
     * Mutator for property subseqReviewTerm.
     * 
     * @return subseqReviewTerm of type String
     */
    @XmlElement(name = "subseqReviewTerm")
    public void setSubseqReviewTerm(String subseqReviewTerm) {
        this.subseqReviewTerm = subseqReviewTerm != null ? subseqReviewTerm : "";
    }
}
