////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.apache.cxf.jaxrs.model.wadl.Description;
import org.apache.cxf.jaxrs.model.wadl.Descriptions;
import org.apache.cxf.jaxrs.model.wadl.DocTarget;
import org.apache.cxf.jaxrs.model.wadl.ElementClass;

import com.suncorp.ssp.service.integration.accountservice.bean.DeleteThirdPartyRelationshipRequest;
import com.suncorp.ssp.service.integration.accountservice.bean.SaveAccountBeneficiaryRequest;
import com.suncorp.ssp.service.integration.accountservice.bean.SaveAccountExpenseRequest;
import com.suncorp.ssp.service.integration.accountservice.bean.SaveAccountRequest;
import com.suncorp.ssp.service.integration.accountservice.bean.SaveAccountSchemeCategoryRequest;
import com.suncorp.ssp.service.integration.accountservice.bean.SaveInvestmentProfileRequest;
import com.suncorp.ssp.service.integration.accountservice.bean.SaveInvestmentRestructureRequest;
import com.suncorp.ssp.service.integration.accountservice.bean.SaveRegularContributionPlanRequestBean;
import com.suncorp.ssp.service.integration.accountservice.bean.UpdateAccountEmploymentRequest;

/**
 * The interface {@code AccountService} exposes the operations available for Account Service.
 * 
 * @author U384381
 * @since 03/02/2016
 * @version 1.0
 */
@Path("/accountservice")
public interface AccountService {

    /**
     * Fetches new GetClientResponse bean.
     * 
     * @return object of type GetBeneficiaryResponse
     */
    @GET
    @Path("/getbeneficiary")
    @ElementClass(response = Response.class)
    @Produces(MediaType.APPLICATION_JSON)
    @Description(title = "Response Object", value = "Response", target = DocTarget.RESPONSE)
    Response getbeneficiary(@QueryParam("accountNumber") String accountNUmber);

    /**
     * Fetches new SearchAccountResponse bean.
     * 
     * @return SearchAccountResponse
     */
    @GET
    @Path("/searchaccount")
    @ElementClass(response = Response.class)
    @Produces(MediaType.APPLICATION_JSON)
    @Description(title = "Response Object", value = "Response", target = DocTarget.RESPONSE)
    Response searchaccount(@QueryParam("advisorClientId") String advisorClientId, @QueryParam("advisorForename") String advisorForename,
            @QueryParam("advisorSurname") String advisorSurname, @QueryParam("memberClientId") String memberClientId,
            @QueryParam("memberForename") String memberForename, @QueryParam("memberSurname") String memberSurname,
            @QueryParam("memberDateOfBirth") String memberDateOfBirth, @QueryParam("productId") String productId,
            @QueryParam("productName") String productName, @QueryParam("firstResult") String firstResult,
            @QueryParam("resultsPerPage") String resultsPerPage, @QueryParam("pendingStatusFlag") String pendingStatusFlag,
            @QueryParam("activeStatusFlag") String activeStatusFlag, @QueryParam("ownerRelationshipFlag") String ownerRelationshipFlag);

    /**
     * This method is used as a entry point for update and delete beneficiary.
     * 
     * @param saveAccountBeneficiaryRequest
     * @return the object of {@code SaveAccountBeneficiaryResponse}
     */
    @POST
    @Path("/saveaccountbeneficiary")
    @ElementClass(request = SaveAccountBeneficiaryRequest.class, response = Response.class)
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Descriptions({ @Description(title = "Request Object", value = "SaveAccountBeneficiaryRequest", target = DocTarget.REQUEST),
            @Description(title = "Response Object", value = "Response", target = DocTarget.RESPONSE) })
    Response saveaccountbeneficiary(SaveAccountBeneficiaryRequest saveAccountBeneficiaryRequest);

    /**
     * Fetches new GetAccountDetailsResponse bean.
     * 
     * @return object of type GetAccountDetailsResponse
     */
    @GET
    @Path("/getaccountdetails")
    @ElementClass(response = Response.class)
    @Produces(MediaType.APPLICATION_JSON)
    @Description(title = "Response Object", value = "Response", target = DocTarget.RESPONSE)
    Response getaccountdetails(@QueryParam("accountNumber") String accountNumber);

    /**
     * This method is used as a entry point for get Account Transaction Summary.
     * 
     * 
     * @return the object of GetAccountTransactionSummaryResponse
     */
    @GET
    @Path("/getaccounttransactionsummary")
    @ElementClass(response = Response.class)
    @Produces(MediaType.APPLICATION_JSON)
    @Description(title = "Response Object", value = "Response", target = DocTarget.RESPONSE)
    Response getaccounttransactionsummary(@QueryParam("accountNumber") String accountNumber, @QueryParam("startDate") String startDate,
            @QueryParam("endDate") String endDate, @QueryParam("includePricedOnly") String includePricedOnly,
            @QueryParam("skipTransactionFundGrouping") String skipTransactionFundGrouping, @QueryParam("accountName") String accountName,
            @QueryParam("externalReference") String externalReference, @QueryParam("externalReferenceCode") String externalReferenceCode);

    /**
     * This method is used as a entry point for get Account Transaction List.
     * 
     * 
     * @return the object of GetAccountTransactionListResponseBean
     */
    @GET
    @Path("/getaccounttransactionlist")
    @ElementClass(response = Response.class)
    @Produces(MediaType.APPLICATION_JSON)
    @Description(title = "Response Object", value = "Response", target = DocTarget.RESPONSE)
    Response getaccounttransactionlist(@QueryParam("accountNumber") String accountNumber, @QueryParam("transTypeCode") String transTypeCode,
            @QueryParam("categoryCode") String categoryCode, @QueryParam("categoryCodeType") String categoryCodeType,
            @QueryParam("startDate") String startDate, @QueryParam("endDate") String endDate, @QueryParam("accountName") String accountName,
            @QueryParam("externalReference") String externalReference, @QueryParam("externalReferenceCode") String externalReferenceCode,
            @QueryParam("firstResult") String firstResult, @QueryParam("resultsPerPage") String resultsPerPage,
            @QueryParam("includePricedOnly") String includePricedOnly, @QueryParam("includeUnpricedOnly") String includeUnpricedOnly,
            @QueryParam("includeTermDepositDetails") String includeTermDepositDetails);

    /**
     * Acts as the entry point for GetInvestmentBalance service.
     * 
     * 
     * @return {@code GetInvestmentBalanceResponseBean}
     */
    @GET
    @Path("/getinvestmentbalance")
    @ElementClass(response = Response.class)
    @Produces(MediaType.APPLICATION_JSON)
    @Description(title = "Response Object", value = "Response", target = DocTarget.RESPONSE)
    Response getinvestmentbalance(@QueryParam("accountNumber") String accountNumber,
            @QueryParam("skipTransactionFundGrouping") String skipTransactionFundGrouping, @QueryParam("accountName") String accountName,
            @QueryParam("startDate") String startDate, @QueryParam("endDate") String endDate,
            @QueryParam("externalReference") String externalReference, @QueryParam("externalReferenceCode") String externalReferenceCode);

    /**
     * Acts as the entry point for GetAccountExpense service.
     * 
     * 
     * @return {@code GetAccountExpenseResponse}
     */
    @GET
    @Path("/getaccountexpense")
    @ElementClass(response = Response.class)
    @Produces(MediaType.APPLICATION_JSON)
    @Description(title = "Response Object", value = "Response", target = DocTarget.RESPONSE)
    Response getaccountexpense(@QueryParam("advisorClientId") String advisorClientId, @QueryParam("productName") String productName,
            @QueryParam("marketingCampaignId") String marketingCampaignId, @QueryParam("accountNumber") String accountNumber);

    /**
     * This method is used as a entry point for getAccountdetailsList service.
     * 
     * 
     * @return the object of GetAccountDetailsResponse
     */
    @GET
    @Path("/getaccountlistdetails")
    @ElementClass(response = Response.class)
    @Produces(MediaType.APPLICATION_JSON)
    @Description(title = "Response Object", value = "Response", target = DocTarget.RESPONSE)
    Response getaccountdetailslist(@QueryParam("accountId") String accountId, @QueryParam("accountName") String accountName,
            @QueryParam("accountNumber") String accountNumber, @QueryParam("productName") String productName,
            @QueryParam("includeAccountDetail") String includeAccountDetail, @QueryParam("includeProduct") String includeProduct,
            @QueryParam("includeScheme") String includeScheme, @QueryParam("includeSchemeCategory") String includeSchemeCategory,
            @QueryParam("includeMarketingCampaign") String includeMarketingCampaign,
            @QueryParam("includeCurrentExpenseGroup") String includeCurrentExpenseGroup,
            @QueryParam("includeClientAccountRelationship") String includeClientAccountRelationship,
            @QueryParam("includeSchemeLocation") String includeSchemeLocation,
            @QueryParam("includeInvestmentProfile") String includeInvestmentProfile, @QueryParam("includeAdvisorGroup") String includeAdvisorGroup,
            @QueryParam("includeBeneficary") String includeBeneficary, @QueryParam("includeBalance") String includeBalance,
            @QueryParam("includeSchemeLocationHistory") String includeSchemeLocationHistory,
            @QueryParam("includeGenericVariable") String includeGenericVariable, @QueryParam("includeNote") String includeNote,
            @QueryParam("includeRegularContributionPlan") String includeRegularContributionPlan,
            @QueryParam("includeFamilyGroup") String includeFamilyGroup, @QueryParam("includeRestriction") String includeRestriction,
            @QueryParam("includeExternalReference") String includeExternalReference, @QueryParam("includeInsurance") String includeInsurance);

    /**
     * This method is used as a entry point for delete third party relationship.
     * 
     * @param deleteThirdPartyRelationshipRequest
     * @return the object of {@code DeleteThirdPartyRelationshipResponse}
     */
    @POST
    @Path("/deletethirdpartyrelationship")
    @ElementClass(request = DeleteThirdPartyRelationshipRequest.class, response = Response.class)
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Descriptions({ @Description(title = "Request Object", value = "DeleteThirdPartyRelationshipRequest", target = DocTarget.REQUEST),
            @Description(title = "Response Object", value = "Response", target = DocTarget.RESPONSE) })
    Response deletethirdpartyrelationship(DeleteThirdPartyRelationshipRequest deleteThirdPartyRelationshipRequest);

    /**
     * This method is used as a entry point for update and delete beneficiary.
     * 
     * @param saveAccountBeneficiaryRequest
     * @return the object of {@code SaveAccountBeneficiaryResponse}
     */
    @POST
    @Path("/saveinvestmentrestructure")
    @ElementClass(request = SaveInvestmentRestructureRequest.class, response = Response.class)
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Descriptions({ @Description(title = "Request Object", value = "SaveInvestmentRestructureRequest", target = DocTarget.REQUEST),
            @Description(title = "Response Object", value = "Response", target = DocTarget.RESPONSE) })
    Response saveInvestmentRestructure(SaveInvestmentRestructureRequest saveInvestmentRestructureRequest);

    /**
     * This method is used as a entry point for update delete account rebalance.
     * 
     * @param saveAccountRequest
     * @return
     */
    @POST
    @Path("/updatedeleteaccountrebalance")
    @ElementClass(request = SaveAccountRequest.class, response = Response.class)
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Descriptions({ @Description(title = "Request Object", value = "SaveAccountRequest", target = DocTarget.REQUEST),
            @Description(title = "Response Object", value = "Response", target = DocTarget.RESPONSE) })
    Response updateDeleteAccountRebalance(SaveAccountRequest saveAccountRequest);

    /**
     * This method is used as a entry point for getPensionDetails service.
     * 
     * 
     * @return the object of GetPensionDetailsResponse
     */
    @GET
    @Path("/getpensiondetails")
    @ElementClass(response = Response.class)
    @Produces(MediaType.APPLICATION_JSON)
    @Description(title = "Response Object", value = "Response", target = DocTarget.RESPONSE)
    Response getPensionDetails(@QueryParam("accountId") String accountId, @QueryParam("accountName") String accountName,
            @QueryParam("accountNumber") String accountNumber, @QueryParam("productName") String productName,
            @QueryParam("includeAccountTaxDetail") String includeAccountTaxDetail,
            @QueryParam("includePensionPaymentAmountDetail") String includePensionPaymentAmountDetail,
            @QueryParam("includePensionPaymentInstruction") String includePensionPaymentInstruction,
            @QueryParam("includePensionPaymentSplit") String includePensionPaymentSplit,
            @QueryParam("includeDrawdownDetail") String includeDrawdownDetail, 
            @QueryParam("includePensionProtection") String includePensionProtection);

    /**
     * This method is used as a entry point for saveAccount service.
     * 
     * @param saveAccountRequest
     * @return
     */
    @POST
    @Path("/saveaccount")
    @ElementClass(request = SaveAccountRequest.class, response = Response.class)
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Descriptions({ @Description(title = "Request Object", value = "SaveAccountRequest", target = DocTarget.REQUEST),
            @Description(title = "Response Object", value = "Response", target = DocTarget.RESPONSE) })
    Response saveAccount(SaveAccountRequest saveAccountRequest);

    /**
     * This method is used as a entry point for saveRegularContributionPlanRequestBean service.
     * 
     * 
     * @return the object of Response
     */
    @POST
    @Path("/saveregularcontributionplan")
    @ElementClass(request = SaveRegularContributionPlanRequestBean.class, response = Response.class)
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Descriptions({ @Description(title = "Request Object", value = "SaveRegularContributionPlanRequest", target = DocTarget.REQUEST),
            @Description(title = "Response Object", value = "Response", target = DocTarget.RESPONSE) })
    Response saveRegularContributionPlan(SaveRegularContributionPlanRequestBean saveRegularContributionPlanRequestBean);

    /**
     * This method is used as a entry point for saveinvestmentprofile service.
     * 
     * @param saveInvestmentProfileRequest
     * @return
     */
    @POST
    @Path("/saveinvestmentprofile")
    @ElementClass(request = SaveInvestmentProfileRequest.class, response = Response.class)
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Descriptions({ @Description(title = "Request Object", value = "SaveInvestmentProfileRequest", target = DocTarget.REQUEST),
            @Description(title = "Response Object", value = "Response", target = DocTarget.RESPONSE) })
    Response saveInvestmentProfile(SaveInvestmentProfileRequest saveInvestmentProfileRequest);

    /**
     * This method is used as a entry point for get switch status.
     * 
     * 
     * @return the object of GetSwitchStatusResponseBean
     */
    @GET
    @Path("/getswitchstatus")
    @ElementClass(response = Response.class)
    @Produces(MediaType.APPLICATION_JSON)
    @Description(title = "Response Object", value = "Response", target = DocTarget.RESPONSE)
    Response getSwitchStatus(@QueryParam("accountNumber") String accountNumber, @QueryParam("startDate") String startDate,
            @QueryParam("endDate") String endDate, @QueryParam("firstResult") String firstResult,
            @QueryParam("resultsPerPage") String resultsPerPage, @QueryParam("includeUnpricedOnlyFlag") String includeUnpricedOnlyFlag,
            @QueryParam("statusCode") String statusCode, @QueryParam("statusCodeType") String statusCodeType,
            @QueryParam("filterReverseTransFlag") String filterReverseTransFlag);

    /**
     * This method is used as a entry point for SaveAccountExpense service.
     * 
     * @param SaveAccountExpenseRequest
     * @return
     */
    @POST
    @Path("/updateaccountexpense")
    @ElementClass(request = SaveAccountExpenseRequest.class, response = Response.class)
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Descriptions({ @Description(title = "Request Object", value = "SaveAccountExpenseRequest", target = DocTarget.REQUEST),
            @Description(title = "Response Object", value = "Response", target = DocTarget.RESPONSE) })
    Response saveAccountExpense(SaveAccountExpenseRequest saveAccountExpenseRequest);

    /**
     * Fetches Account Employment details.
     * 
     * @return object of type GetAccountEmploymentResponseBean
     */
    @GET
    @Path("/getaccountemployment")
    @ElementClass(response = Response.class)
    @Produces(MediaType.APPLICATION_JSON)
    @Description(title = "Response Object", value = "Response", target = DocTarget.RESPONSE)
    Response getaccountemployment(@QueryParam("accountNumber") String accountNumber);

    /**
     * This method is used as a entry point for UpdateAccountEmployment service.
     * 
     * @param UpdateAccountEmploymentRequest
     * @return
     */
    @POST
    @Path("/updateaccountemployment")
    @ElementClass(request = UpdateAccountEmploymentRequest.class, response = Response.class)
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Descriptions({ @Description(title = "Request Object", value = "UpdateAccountEmploymentRequest", target = DocTarget.REQUEST),
            @Description(title = "Response Object", value = "Response", target = DocTarget.RESPONSE) })
    Response updateAccountEmployment(UpdateAccountEmploymentRequest updateAccountEmploymentRequest);

    /**
     * This method is used as a entry point for SaveAccountSchemeCategory service.
     * 
     * @param saveAccountSchemeCategoryRequest
     * @return
     */
    @POST
    @Path("/saveaccountschemecategory")
    @ElementClass(request = SaveAccountSchemeCategoryRequest.class, response = Response.class)
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    @Descriptions({ @Description(title = "Request Object", value = "SaveAccountSchemeCategoryRequest", target = DocTarget.REQUEST),
            @Description(title = "Response Object", value = "Response", target = DocTarget.RESPONSE) })
    Response saveAccountSchemeCategory(SaveAccountSchemeCategoryRequest saveAccountSchemeCategoryRequest);

    /**
     * Fetches new GetAccountUnitHoldings bean.
     * 
     * @return GetAccountUnitHoldingsResponse
     */
    @GET
    @Path("/getaccountunitholdings")
    @ElementClass(response = Response.class)
    @Produces(MediaType.APPLICATION_JSON)
    @Description(title = "Response Object", value = "Response", target = DocTarget.RESPONSE)
    Response getAccountUnitHoldings(@QueryParam("accountNumber") String accountNumber);

    /**
     * Fetches linked family members details.
     * 
     * @return GetFamilyLinkingDetailsResponse
     */
    @GET
    @Path("/getfamilylinkingdetails")
    @ElementClass(response = Response.class)
    @Produces(MediaType.APPLICATION_JSON)
    @Description(title = "Response Object", value = "Response", target = DocTarget.RESPONSE)
    Response getFamilyLinkingDetails(@QueryParam("accountNumber") String accountNumber);
    
    /**
     * Fetches new GetAccountContributions bean.
     * 
     * @return GetAccountContributionsResponse
     */
    @GET
    @Path("/getaccountcontributions")
    @ElementClass(response = Response.class)
    @Produces(MediaType.APPLICATION_JSON)
    @Description(title = "Response Object", value = "Response", target = DocTarget.RESPONSE)
    Response getaccountcontributions(@QueryParam("accountNumber") String accountNumber,
            @QueryParam("retrievalDateIndicator") String retrievalDateIndicator, @QueryParam("contributionPeriodFrom") String contributionPeriodFrom,
            @QueryParam("contributionPeriodTo") String contributionPeriodTo,
            @QueryParam("includeAllContributionsFlag") String includeAllContributionsFlag);
}
