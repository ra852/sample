////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code RestrictionBean} does this.
 * 
 * @author U387938
 * @since 13/06/2017
 * @version 1.0
 */
public class RestrictionBean {
    private String id;
    private CodeIdentifier code;
    private String effectiveDate;
    /**
     * Accessor for property id.
     *
     * @return id of type String
     */
    public String getId() {
        return id;
    }
    /**
     * Mutator for property id.
     *
     * @param id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id;
    }
    /**
     * Accessor for property code.
     *
     * @return code of type CodeIdentifier
     */
    public CodeIdentifier getCode() {
        return code;
    }
    /**
     * Mutator for property code.
     *
     * @param code of type CodeIdentifier
     */
    @XmlElement(name = "code")
    public void setCode(CodeIdentifier code) {
        this.code = code;
    }
    /**
     * Accessor for property effectiveDate.
     *
     * @return effectiveDate of type String
     */
    public String getEffectiveDate() {
        return effectiveDate;
    }
    /**
     * Mutator for property effectiveDate.
     *
     * @param effectiveDate of type String
     */
    @XmlElement(name = "effectiveDate")
    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    
}
