////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code Contributions} is a java bean consisting of properties related to Contributions.
 * 
 * @author U201468
 * @since 20/09/2017
 * @version 1.0
 */
public class Contributions {
    private String total;
    private String nonConcessionalTotal;
    private String concessionalTotal;
    private String nonConcessionalCGTExemptTotal;
    private List<ContributionBean> contributionDetails;

    /**
     * Accessor for property total.
     * 
     * @return total of type String
     */
    public String getTotal() {
        return total;
    }

    /**
     * Mutator for property total.
     * 
     * @param total of type String
     */
    @XmlElement(name = "total")
    public void setTotal(String total) {
        this.total = total;
    }

    /**
     * Accessor for property nonConcessionalTotal.
     * 
     * @return nonConcessionalTotal of type String
     */
    public String getNonConcessionalTotal() {
        return nonConcessionalTotal;
    }

    /**
     * Mutator for property nonConcessionalTotal.
     * 
     * @param nonConcessionalTotal of type String
     */
    @XmlElement(name = "nonConcessionalTotal")
    public void setNonConcessionalTotal(String nonConcessionalTotal) {
        this.nonConcessionalTotal = nonConcessionalTotal;
    }

    /**
     * Accessor for property concessionalTotal.
     * 
     * @return concessionalTotal of type String
     */
    public String getConcessionalTotal() {
        return concessionalTotal;
    }

    /**
     * Mutator for property concessionalTotal.
     * 
     * @param concessionalTotal of type String
     */
    @XmlElement(name = "concessionalTotal")
    public void setConcessionalTotal(String concessionalTotal) {
        this.concessionalTotal = concessionalTotal;
    }

    /**
     * Accessor for property nonConcessionalCGTExemptTotal.
     * 
     * @return nonConcessionalCGTExemptTotal of type String
     */
    public String getNonConcessionalCGTExemptTotal() {
        return nonConcessionalCGTExemptTotal;
    }

    /**
     * Mutator for property nonConcessionalCGTExemptTotal.
     * 
     * @param nonConcessionalCGTExemptTotal of type String
     */
    @XmlElement(name = "nonConcessionalCGTExemptTotal")
    public void setNonConcessionalCGTExemptTotal(String nonConcessionalCGTExemptTotal) {
        this.nonConcessionalCGTExemptTotal = nonConcessionalCGTExemptTotal;
    }

    /**
     * Accessor for property contributionDetails.
     * 
     * @return contributionDetails of type List<ContributionBean>
     */
    public List<ContributionBean> getContributionDetails() {
        return contributionDetails;
    }

    /**
     * Mutator for property contributionDetails.
     * 
     * @param contributionDetails of type List<ContributionBean>
     */
    @XmlElement(name = "contributionDetails")
    public void setContributionDetails(List<ContributionBean> contributionDetails) {
        this.contributionDetails = contributionDetails;
    }

}
