////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code SchemeLocationIdentifier} does this.
 * 
 * @author U383754
 * @since 01/02/2016
 * @version 1.0
 */
public class SchemeLocationIdentifier {
    private String id;
    private String name;
    private CodeIdentifier typecode;
    private String number;
    private String shortName;
    private IdNameIdentifier parentLocationIdentifier;

    /**
     * Accessor for property id.
     * 
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     * 
     * @return id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id != null ? id : "";
    }

    /**
     * Accessor for property name.
     * 
     * @return name of type String
     */
    public String getName() {
        return name;
    }

    /**
     * Mutator for property name.
     * 
     * @return name of type String
     */
    @XmlElement(name = "name")
    public void setName(String name) {
        this.name = name != null ? name : "";
    }

    /**
     * Accessor for property typecode.
     * 
     * @return typecode of type CodeIdentifier
     */
    public CodeIdentifier getTypecode() {
        return typecode;
    }

    /**
     * Mutator for property typecode.
     * 
     * @return typecode of type CodeIdentifier
     */
    @XmlElement(name = "typecode")
    public void setTypecode(CodeIdentifier typecode) {
        this.typecode = typecode;
    }

    /**
     * Accessor for property number.
     * 
     * @return number of type String
     */
    public String getNumber() {
        return number;
    }

    /**
     * Mutator for property number.
     * 
     * @return number of type String
     */
    @XmlElement(name = "number")
    public void setNumber(String number) {
        this.number = number != null ? number : "";
    }

    /**
     * Accessor for property shortName.
     * 
     * @return shortName of type String
     */
    public String getShortName() {
        return shortName;
    }

    /**
     * Mutator for property shortName.
     * 
     * @return shortName of type String
     */
    @XmlElement(name = "shortName")
    public void setShortName(String shortName) {
        this.shortName = shortName != null ? shortName : "";
    }

    /**
     * Accessor for property parentLocationIdentifier.
     *
     * @return parentLocationIdentifier of type IdNameIdentifier
     */
    public IdNameIdentifier getParentLocationIdentifier() {
        return parentLocationIdentifier;
    }

    /**
     * Mutator for property parentLocationIdentifier.
     *
     * @param parentLocationIdentifier of type IdNameIdentifier
     */
    @XmlElement(name = "parentLocationIdentifier")
    public void setParentLocationIdentifier(IdNameIdentifier parentLocationIdentifier) {
        this.parentLocationIdentifier = parentLocationIdentifier;
    }

   
}
