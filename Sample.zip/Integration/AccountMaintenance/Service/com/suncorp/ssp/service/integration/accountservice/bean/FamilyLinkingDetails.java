////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code FamilyLinkingDetails} does this.
 * 
 * @author U385424
 * @since 15/11/2016
 * @version 1.0
 */
public class FamilyLinkingDetails {
    private String accountNumber;
    private String firstName;
    private String lastName;
    private String dateOfBirth;

    /**
     * Accessor for property accountNumber.
     * 
     * @return accountNumber of type String
     */
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * Mutator for property accountNumber.
     * 
     * @param accountNumber of type String
     */
    @XmlElement(name = "memberAccountNumber")
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    /**
     * Accessor for property firstName.
     * 
     * @return firstName of type String
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * Mutator for property firstName.
     * 
     * @param firstName of type String
     */
    @XmlElement(name = "memberFirstName")
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * Accessor for property lastName.
     * 
     * @return lastName of type String
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Mutator for property lastName.
     * 
     * @param lastName of type String
     */
    @XmlElement(name = "memberLastName")
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * Accessor for property dateOfBirth.
     * 
     * @return dateOfBirth of type String
     */
    public String getDateOfBirth() {
        return dateOfBirth;
    }

    /**
     * Mutator for property dateOfBirth.
     * 
     * @param dateOfBirth of type String
     */
    @XmlElement(name = "memberDateOfBirth")
    public void setDateOfBirth(String dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }
}
