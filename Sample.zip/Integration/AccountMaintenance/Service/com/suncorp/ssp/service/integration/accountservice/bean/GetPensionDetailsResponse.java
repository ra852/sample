////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.suncorp.ssp.common.bean.SILErrorMessage;

/**
 * The class {@code GetPensionDetailsResponse} does this.
 * 
 * @author U386868
 * @since 02/04/2016
 * @version 1.0
 */
@XmlRootElement(name = "GetPensionDetailsResponse")
public class GetPensionDetailsResponse extends SILErrorMessage {

    private List<AccountDetailsList> accountDetailsList;

    /**
     * Accessor for property accountDetailsList.
     * 
     * @return accountDetailsList of type List<AccountDetailsList>
     */
    public List<AccountDetailsList> getAccountDetailsList() {
        return accountDetailsList;
    }

    /**
     * Mutator for property accountDetailsList.
     * 
     * @param accountDetailsList of type List<AccountDetailsList>
     */
    @XmlElement(name = "accountDetails")
    public void setAccountDetailsList(List<AccountDetailsList> accountDetailsList) {
        this.accountDetailsList = accountDetailsList;
    }
}
