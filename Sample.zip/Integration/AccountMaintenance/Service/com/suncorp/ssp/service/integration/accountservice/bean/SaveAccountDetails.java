////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code SaveAccountDetails} does this.
 * 
 * @author U383847
 * @since 29/03/2016
 * @version 1.0
 */
public class SaveAccountDetails {
    private AccountNumberInfo accountNumber;
    private List<InvestmentProfileDetails> investmentProfiles;
    private AccountDetailBean accountDetail;
    private List<GenericVariableBean> genericVariable;
    private List<NoteBean> notes;
    private String mrrFlag;

    /**
     * Accessor for property accountNumber.
     * 
     * @return accountNumber of type AccountNumberInfo
     */
    public AccountNumberInfo getAccountNumber() {
        return accountNumber;
    }

    /**
     * Mutator for property accountNumber.
     * 
     * @param accountNumber of type AccountNumberInfo
     */
    @XmlElement(name = "accountNumber")
    public void setAccountNumber(AccountNumberInfo accountNumber) {
        this.accountNumber = accountNumber;
    }

    /**
     * Accessor for property investmentProfiles.
     * 
     * @return investmentProfiles of type List<InvestmentProfileDetails>
     */
    public List<InvestmentProfileDetails> getInvestmentProfiles() {
        return investmentProfiles;
    }

    /**
     * Mutator for property investmentProfiles.
     * 
     * @param investmentProfiles of type List<InvestmentProfileDetails>
     */
    @XmlElement(name = "investmentProfiles")
    public void setInvestmentProfiles(List<InvestmentProfileDetails> investmentProfiles) {
        this.investmentProfiles = investmentProfiles;
    }

    /**
     * Accessor for property accountDetail.
     * 
     * @return accountDetail of type AccountDetailBean
     */
    public AccountDetailBean getAccountDetail() {
        return accountDetail;
    }

    /**
     * Mutator for property accountDetail.
     * 
     * @param accountDetail of type AccountDetailBean
     */
    @XmlElement(name = "accountDetail")
    public void setAccountDetail(AccountDetailBean accountDetail) {
        this.accountDetail = accountDetail;
    }

    /**
     * Accessor for property genericVariable.
     * 
     * @return genericVariable of type List<GenericVariableBean>
     */
    public List<GenericVariableBean> getGenericVariable() {
        return genericVariable;
    }

    /**
     * Mutator for property genericVariable.
     * 
     * @return genericVariable of type List<GenericVariableBean>
     */
    @XmlElement(name = "genericVariables")
    public void setGenericVariable(List<GenericVariableBean> genericVariable) {
        this.genericVariable = genericVariable;
    }

    /**
     * Accessor for property notes.
     * 
     * @return notes of type List<NoteBean>
     */
    public List<NoteBean> getNotes() {
        return notes;
    }

    /**
     * Mutator for property notes.
     * 
     * @param notes of type List<NoteBean>
     */
    @XmlElement(name = "notes")
    public void setNotes(List<NoteBean> notes) {
        this.notes = notes;
    }

    /**
     * Accessor for property mrrFlag.
     *
     * @return mrrFlag of type String
     */
    public String getMrrFlag() {
        return mrrFlag;
    }

    /**
     * Mutator for property mrrFlag.
     *
     * @param mrrFlag of type String
     */
    public void setMrrFlag(String mrrFlag) {
        this.mrrFlag = mrrFlag;
    }
}
