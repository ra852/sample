////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType;
import com.sonatacentral.service.v30.wrap.account.SaveRegularContributionPlanResponseType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.AccountIdentifierDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.SaveRegularContributionPlanResponseBean;

/**
 * The class {@code SaveRegularContributionResponseUtil} is used to extract the data from response and sends back to consumer.
 * 
 * @author U383754
 * @since 30/05/2016
 * @version 1.0
 */
public class SaveRegularContributionResponseUtil {
    private final String cName = "SaveRegularContributionResponseUtil";
    private SaveRegularContributionPlanResponseType planResponseType;

    /**
     * Constructor for setting the outbound response object.
     * 
     * @param outbound
     */
    public SaveRegularContributionResponseUtil(SaveRegularContributionPlanResponseType planResponseType) {
        this.planResponseType = planResponseType;
    }

    /**
     * This method is used to get Outbound response.
     * 
     * @return
     * @throws SILException
     */
    public SaveRegularContributionPlanResponseBean getOutboundResponse() throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_REG_CONT_LOGGING_FORMAT, cName, "Entering getOutboundResponse()");
        if (this.planResponseType.getAccount() != null) {
            return this.getAccountDetails(this.planResponseType.getAccount());
        } else {
            throw new SILException(AccountServiceConstants.SAVE_REG_CONT_RES_NULL);
        }
    }

    /**
     * Get Account Details.
     * 
     * @param accountIdentifierType
     * @param outboundResponse
     * @throws SILException
     */
    public SaveRegularContributionPlanResponseBean getAccountDetails(AccountIdentifierType accountIdentifier) throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_REG_CONT_LOGGING_FORMAT, cName, "Entering getAccountDetails()");
        SaveRegularContributionPlanResponseBean outboundResponse = new SaveRegularContributionPlanResponseBean();
        String loggerType = AccountServiceConstants.SAVE_REG_CONT_LOGGING_FORMAT;
        AccountServiceUtil accountServiceCommonUtil = new AccountServiceUtil();
        AccountIdentifierDetails accountIdentifierDetails = new AccountIdentifierDetails();
        accountIdentifierDetails.setId(accountServiceCommonUtil.retrieveLongValue(accountIdentifier.getId(), loggerType));
        accountIdentifierDetails.setName(accountIdentifier.getName());
        accountIdentifierDetails.setAccountNumber(accountServiceCommonUtil.retrieveAccountNumberDetails(accountIdentifier.getAccountNumber(),
                loggerType));
        accountIdentifierDetails.setAccountRef(accountServiceCommonUtil.retrieveExternalRef(accountIdentifier.getAccountExternalRef(), loggerType));
        accountIdentifierDetails.setStatusCode(accountServiceCommonUtil.retrieveCode(accountIdentifier.getStatusCode(), loggerType));
        accountIdentifierDetails.setAudit(accountServiceCommonUtil.retrieveAudit(accountIdentifier.getAudit(), loggerType));
        outboundResponse.setAccount(accountIdentifierDetails);
        return outboundResponse;
    }
}
