////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code AccountType} does this.
 * 
 * @author U387938
 * @since 03/11/2015
 * @version 1.0
 */
public class AccountPointer {
    private String id;
    private String reference;
    /**
     * Accessor for property id.
     *
     * @return id of type String
     */
    public String getId() {
        return id;
    }
    /**
     * Mutator for property id.
     *
     * @param id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id != null ? id : "";
    }
    /**
     * Accessor for property reference.
     *
     * @return reference of type String
     */
    public String getReference() {
        return reference;
    }
    /**
     * Mutator for property reference.
     *
     * @param reference of type String
     */
    @XmlElement(name = "reference")
    public void setReference(String reference) {
        this.reference = reference != null ? reference : "";
    }

    
}
