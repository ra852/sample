////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code TransEventAccountTransaction} is a pure java bean consisting of properties related to GetAccountTransactionList response.
 * 
 * @author U385424
 * @since 23/01/2017
 * @version 1.0
 */
public class TransEventAccountTransaction {
    private TransType transType;
    private String grossAmount;
    private TransEventAccount account;
    private String priceCode;
    private String expenseGroup;
    private List<TransactionEventInvestmentTransDetails> investmentTrans;
    private List<TransactionEventLevelExpenseDetails> transLevelEvent;
    private List<ContributionTypeSplitsBean> contributionDetail;

    /**
     * Accessor for property transType.
     * 
     * @return transType of type TransType
     */
    public TransType getTransType() {
        return transType;
    }

    /**
     * Mutator for property transType.
     * 
     * @param transType of type TransType
     */
    @XmlElement(name = "transType")
    public void setTransType(TransType transType) {
        this.transType = transType;
    }

    /**
     * Accessor for property grossAmount.
     * 
     * @return grossAmount of type String
     */
    public String getGrossAmount() {
        return grossAmount;
    }

    /**
     * Mutator for property grossAmount.
     * 
     * @param grossAmount of type String
     */
    @XmlElement(name = "grossAmount")
    public void setGrossAmount(String grossAmount) {
        this.grossAmount = grossAmount != null ? grossAmount : "";
    }

    /**
     * Accessor for property account.
     * 
     * @return account of type TransEventAccount
     */
    public TransEventAccount getAccount() {
        return account;
    }

    /**
     * Mutator for property account.
     * 
     * @param account of type TransEventAccount
     */
    @XmlElement(name = "account")
    public void setAccount(TransEventAccount account) {
        this.account = account;
    }

    /**
     * Accessor for property priceCode.
     * 
     * @return priceCode of type String
     */
    public String getPriceCode() {
        return priceCode;
    }

    /**
     * Mutator for property priceCode.
     * 
     * @param priceCode of type String
     */
    @XmlElement(name = "priceCode")
    public void setPriceCode(String priceCode) {
        this.priceCode = priceCode != null ? priceCode : "";
    }

    /**
     * Accessor for property expenseGroup.
     * 
     * @return expenseGroup of type String
     */
    public String getExpenseGroup() {
        return expenseGroup;
    }

    /**
     * Mutator for property expenseGroup.
     * 
     * @param expenseGroup of type String
     */
    @XmlElement(name = "expenseGroup")
    public void setExpenseGroup(String expenseGroup) {
        this.expenseGroup = expenseGroup != null ? expenseGroup : "";
    }

    /**
     * Accessor for property investmenttrans.
     * 
     * @return investmenttrans of type List<TransactionEventInvestmentTransDetails>
     */
    public List<TransactionEventInvestmentTransDetails> getInvestmenttrans() {
        return investmentTrans;
    }

    /**
     * Mutator for property investmenttrans.
     * 
     * @param investmenttrans of type List<TransactionEventInvestmentTransDetails>
     */
    @XmlElement(name = "investmentTrans")
    public void setInvestmenttrans(List<TransactionEventInvestmentTransDetails> investmentTrans) {
        this.investmentTrans = investmentTrans;
    }

    /**
     * Accessor for property transLevelEvent.
     * 
     * @return transLevelEvent of type List<TransactionEventLevelExpenseDetails>
     */
    public List<TransactionEventLevelExpenseDetails> getTransLevelEvent() {
        return transLevelEvent;
    }

    /**
     * Mutator for property transLevelEvent.
     * 
     * @param transLevelEvent of type List<TransactionEventLevelExpenseDetails>
     */
    @XmlElement(name = "transLevelEvent")
    public void setTransLevelEvent(List<TransactionEventLevelExpenseDetails> transLevelEvent) {
        this.transLevelEvent = transLevelEvent;
    }

    /**
     * Accessor for property contributionDetail.
     * 
     * @return contributionDetail of type List<ContributionTypeSplitsBean>
     */
    public List<ContributionTypeSplitsBean> getContributionDetail() {
        return contributionDetail;
    }

    /**
     * Mutator for property contributionDetail.
     * 
     * @param contributionDetail of type List<ContributionTypeSplitsBean>
     */
    @XmlElement(name = "contributionDetail")
    public void setContributionDetail(List<ContributionTypeSplitsBean> contributionDetail) {
        this.contributionDetail = contributionDetail;
    }
}
