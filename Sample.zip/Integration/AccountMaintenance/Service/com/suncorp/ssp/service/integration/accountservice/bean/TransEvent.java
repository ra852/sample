////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code TransEvent} is a pure java bean consisting of properties related to GetAccountTransactionList response.
 * 
 * @author u386868
 * @since 27/12/2015
 * @version 1.0
 */
public class TransEvent {
    private String id;
    private TransType transType;
    private String transStatus;
    private String pricedDate;
    private String effectiveDate;
    private String processedDate;
    private String reference;
    private BigDecimal amount;
    private String reasonCode;
    private LastUpdatedDetail lastUpdated;

    /**
     * Accessor for property id.
     * 
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     * 
     * @return id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id != null ? id : "";
    }

    /**
     * Accessor for property transType.
     * 
     * @return transType of type TransType
     */
    public TransType getTransType() {
        return transType;
    }

    /**
     * Mutator for property transType.
     * 
     * @return transType of type TransType
     */
    @XmlElement(name = "transType")
    public void setTransType(TransType transType) {
        this.transType = transType;
    }

    /**
     * Accessor for property transStatus.
     * 
     * @return transStatus of type String
     */
    public String getTransStatus() {
        return transStatus;
    }

    /**
     * Mutator for property transStatus.
     * 
     * @return transStatus of type String
     */
    @XmlElement(name = "transStatus")
    public void setTransStatus(String transStatus) {
        this.transStatus = transStatus != null ? transStatus : "";
    }

    /**
     * Accessor for property pricedDate.
     * 
     * @return pricedDate of type String
     */
    public String getPricedDate() {
        return pricedDate;
    }

    /**
     * Mutator for property pricedDate.
     * 
     * @return pricedDate of type String
     */
    @XmlElement(name = "pricedDate")
    public void setPricedDate(String pricedDate) {
        this.pricedDate = pricedDate != null ? pricedDate : "";
    }

    /**
     * Accessor for property effectiveDate.
     * 
     * @return effectiveDate of type String
     */
    public String getEffectiveDate() {
        return effectiveDate;
    }

    /**
     * Mutator for property effectiveDate.
     * 
     * @return effectiveDate of type String
     */
    @XmlElement(name = "effectiveDate")
    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate != null ? effectiveDate : "";
    }

    /**
     * Accessor for property processedDate.
     * 
     * @return processedDate of type String
     */
    public String getProcessedDate() {
        return processedDate;
    }

    /**
     * Mutator for property processedDate.
     * 
     * @return processedDate of type String
     */
    @XmlElement(name = "processedDate")
    public void setProcessedDate(String processedDate) {
        this.processedDate = processedDate != null ? processedDate : "";
    }

    /**
     * Accessor for property reference.
     * 
     * @return reference of type String
     */
    public String getReference() {
        return reference;
    }

    /**
     * Mutator for property reference.
     * 
     * @return reference of type String
     */
    @XmlElement(name = "reference")
    public void setReference(String reference) {
        this.reference = reference != null ? reference : "";
    }

    /**
     * Accessor for property amount.
     * 
     * @return amount of type BigDecimal
     */
    public BigDecimal getAmount() {
        return amount;
    }

    /**
     * Mutator for property amount.
     * 
     * @return amount of type BigDecimal
     */
    @XmlElement(name = "amount")
    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    /**
     * Accessor for property reasonCode.
     * 
     * @return reasonCode of type String
     */
    public String getReasonCode() {
        return reasonCode;
    }

    /**
     * Mutator for property reasonCode.
     * 
     * @return reasonCode of type String
     */
    @XmlElement(name = "reasonCode")
    public void setReasonCode(String reasonCode) {
        this.reasonCode = reasonCode != null ? reasonCode : "";
    }

    /**
     * Accessor for property lastUpdated.
     * 
     * @return lastUpdated of type LastUpdatedDetail
     */
    public LastUpdatedDetail getLastUpdated() {
        return lastUpdated;
    }

    /**
     * Mutator for property lastUpdated.
     * 
     * @param lastUpdated of type LastUpdatedDetail
     */
    @XmlElement(name = "lastUpdated")
    public void setLastUpdated(LastUpdatedDetail lastUpdated) {
        this.lastUpdated = lastUpdated;
    }
}
