////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.ClientAccountRelationshipIdentifierType;
import com.sonatacentral.service.v30.service.ValidationMessage;
import com.sonatacentral.service.v30.wrap.account.SearchAccountResponseType;
import com.sonatacentral.service.v30.wrap.account.SearchAccountResponseType.Accounts;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.AccountType;
import com.suncorp.ssp.service.integration.accountservice.bean.CodeIdentifier;
import com.suncorp.ssp.service.integration.accountservice.bean.PagingRange;
import com.suncorp.ssp.service.integration.accountservice.bean.SearchAccountResponse;

/**
 * The class {@code SearchAccountsUtil} is a Utility class with all the properties related to searchAccount functionality, to construct response for
 * end-client by extracting values from the external service's response object.
 * 
 * @author U384381
 * @since 03/11/2015
 * @version 1.0
 */
public class SearchAccountsUtil {
    private SearchAccountResponseType searchAccountResponseType;
    private ClientAccountRelationshipIdentifierType clientAccountRelationshipIdentifierTypeObj;
    private Accounts accounts;

    public SearchAccountsUtil(SearchAccountResponseType searchAccountResponseType) {
        this.searchAccountResponseType = searchAccountResponseType;
    }

    /**
     * 
     * Adds an {@code AccountType} with values extracted from external service's response, to an AccountType list. And finally adds that list to the
     * response object.
     * 
     * @param searchAccountResponse of type SearchAccountResponse
     * @throws SILException of type Exception.
     */
    public void setSearchAccountResponse(SearchAccountResponse searchAccountResponse) throws SILException {
        SILLogger.debug(AccountServiceConstants.SRCH_ACCNT_LOGGING_FORMAT, "SearchAccountsUtil", "Entering in getSearchAccountResponse method.");
        List<AccountType> accountTypeList = new ArrayList<AccountType>();
        if (this.searchAccountResponseType != null && this.searchAccountResponseType.getAccounts() != null &&
                this.searchAccountResponseType.getAccounts().size() > 0) {
            List<SearchAccountResponseType.Accounts> accountsList = this.searchAccountResponseType.getAccounts();
            for (SearchAccountResponseType.Accounts accounts : accountsList) {
                setSearchAccountResponseParams(accountTypeList, accounts);
            }
        } else if (this.searchAccountResponseType != null && this.searchAccountResponseType.getValidationMessage() != null) {
            this.sendValidationMessages();
        } else {
            throw new SILException(AccountServiceConstants.NO_RECORDS_FOUND);
        }
        searchAccountResponse.setAccounts(accountTypeList);
        constructPagingRange(searchAccountResponse);
        SILLogger.debug(AccountServiceConstants.SRCH_ACCNT_LOGGING_FORMAT, "SearchAccountsUtil", "Exiting from getSearchAccountResponse method.");
    }

    /**
     * This method set the paging range in searchAccount response.
     *
     * @param searchAccountResponse
     */
    private void constructPagingRange(SearchAccountResponse searchAccountResponse) {
        if (this.searchAccountResponseType != null && this.searchAccountResponseType.getPagingRange() != null) {
            searchAccountResponse.setPagingRange(setPagingRange());
        }
    }

    /**
     * This method set the search account params.
     *
     * @param accountTypeList
     * @param accounts
     */
    private void setSearchAccountResponseParams(List<AccountType> accountTypeList, SearchAccountResponseType.Accounts accounts) {
        this.accounts = accounts;
        this.clientAccountRelationshipIdentifierTypeObj = this.getClientRelationshipTypeObj();
        AccountType accountType = new AccountType();
        accountType.setClientId(this.getClientId());
        accountType.setFirstName(this.getFirstName());
        accountType.setSurname(this.getSurname());
        accountType.setAccountNumber(this.getAccountNumber());
        accountType.setProductName(this.getProductName());
        accountType.setStatus(getAccountStatus());
        accountTypeList.add(accountType);
    }

    /**
     * This method is used to send validation message to the consumer.
     * 
     * @throws SILException
     */
    private void sendValidationMessages() throws SILException {
        List<ValidationMessage> validationMessageList = this.searchAccountResponseType.getValidationMessage();
        for (ValidationMessage validationMessage : validationMessageList) {
            if (validationMessage.getSeverity() != null) {
                if (validationMessage.getSeverity().equalsIgnoreCase(AccountServiceConstants.SEVERITY_ERROR) ||
                        validationMessage.getSeverity().equalsIgnoreCase(AccountServiceConstants.SEVERITY_DEBUG) ||
                        validationMessage.getSeverity().equalsIgnoreCase(AccountServiceConstants.SEVERITY_FATAL)) {
                    throw new SILException(validationMessage.getMessage());
                } else if (validationMessage.getSeverity().equalsIgnoreCase(AccountServiceConstants.SEVERITY_INFO)) {
                    throw new SILException(AccountServiceConstants.NO_RECORDS_FOUND);
                }
            }
        }
    }

    /**
     * Accessor for property firstName.
     * 
     * @return firstName of type String
     */
    private String getClientId() {
        if (this.clientAccountRelationshipIdentifierTypeObj != null && this.clientAccountRelationshipIdentifierTypeObj.getClient() != null &&
                this.clientAccountRelationshipIdentifierTypeObj.getClient().getId() != null) {
            return String.valueOf(this.clientAccountRelationshipIdentifierTypeObj.getClient().getId());
        }
        return "";
    }

    /**
     * Accessor for property firstName.
     * 
     * @return firstName of type String
     */
    private String getFirstName() {
        if (this.clientAccountRelationshipIdentifierTypeObj != null && this.clientAccountRelationshipIdentifierTypeObj.getClient() != null &&
                this.clientAccountRelationshipIdentifierTypeObj.getClient().getClientForename() != null) {
            if (this.clientAccountRelationshipIdentifierTypeObj.getClient().getClientForename2() != null) {
                return this.clientAccountRelationshipIdentifierTypeObj.getClient().getClientForename().concat(" ")
                        .concat(this.clientAccountRelationshipIdentifierTypeObj.getClient().getClientForename2());
            } else {
                return this.clientAccountRelationshipIdentifierTypeObj.getClient().getClientForename();
            }
        }
        return "";
    }

    /**
     * Accessor for property surname.
     * 
     * @return surname of type String
     */
    private String getSurname() {
        if (this.clientAccountRelationshipIdentifierTypeObj != null && this.clientAccountRelationshipIdentifierTypeObj.getClient() != null &&
                this.clientAccountRelationshipIdentifierTypeObj.getClient().getClientSurname() != null) {
            return this.clientAccountRelationshipIdentifierTypeObj.getClient().getClientSurname();
        }
        return "";
    }

    /**
     * Accessor for property accountNumber.
     * 
     * @return accountNumber of type String
     */
    private String getAccountNumber() {
        if (this.accounts != null && this.accounts.getAccountNumber() != null && this.accounts.getAccountNumber().getAccountNo() != null) {
            return this.accounts.getAccountNumber().getAccountNo();
        }
        return "";
    }

    /**
     * Accessor for property productName.
     * 
     * @return productName of type String
     */
    private String getProductName() {
        if (this.accounts != null && this.accounts.getAccountNumber() != null && this.accounts.getAccountNumber().getProductName() != null) {
            return this.accounts.getAccountNumber().getProductName();
        }
        return "";
    }

    /**
     * 
     * Accessor for property Account status.
     * 
     * @return statusCode
     */
    private CodeIdentifier getAccountStatus() {
        CodeIdentifier statusCode = new CodeIdentifier();
        if (this.accounts != null && this.accounts.getStatusCode() != null) {
            statusCode.setCode(this.accounts.getStatusCode().getCode());
            statusCode.setCodeType(this.accounts.getStatusCode().getCodeType());
        } else {
            statusCode.setCode("");
            statusCode.setCodeType("");
        }
        return statusCode;
    }

    /**
     * This method is used to get relationship type object of OWNER.
     * 
     * clientAccountRelationshipIdentifierTypeObj the object of {@code ClientAccountRelationshipIdentifierType}
     */
    private ClientAccountRelationshipIdentifierType getClientRelationshipTypeObj() {
        if (this.accounts.getRelationships() != null) {
            List<ClientAccountRelationshipIdentifierType> clientAccountRelationshipIdentifierTypeList = this.accounts.getRelationships();
            Iterator<ClientAccountRelationshipIdentifierType> iterator = clientAccountRelationshipIdentifierTypeList.iterator();
            while (iterator.hasNext()) {
                ClientAccountRelationshipIdentifierType clientAccountRelationshipIdentifierTypeObj = iterator.next();
                if (clientAccountRelationshipIdentifierTypeObj != null &&
                        clientAccountRelationshipIdentifierTypeObj.getRelationshipType() != null &&
                        clientAccountRelationshipIdentifierTypeObj.getRelationshipType().getCode() != null &&
                        clientAccountRelationshipIdentifierTypeObj.getRelationshipType().getCode()
                                .equalsIgnoreCase(AccountServiceConstants.SEARCH_ACCOUNT_OWNER_CODE)) {
                    return clientAccountRelationshipIdentifierTypeObj;
                }
            }
        }
        return null;
    }
    
    /**
     * 
     * Sets the paging range values.
     *
     * @return pagingRange
     */
    private PagingRange setPagingRange() {
        PagingRange pagingRange = new PagingRange();
        pagingRange.setFirstResult(this.searchAccountResponseType.getPagingRange().getFirstResult());
        pagingRange.setResultsPerPage(this.searchAccountResponseType.getPagingRange().getResultsPerPage());
        if (this.searchAccountResponseType.getPagingRange().getFirstResult() != 0 &&
                this.searchAccountResponseType.getPagingRange().getResultsPerPage() != 0) {
            pagingRange.setTotalResults(this.searchAccountResponseType.getPagingRange().getTotalResults());
        }
        return pagingRange;
    }
}
