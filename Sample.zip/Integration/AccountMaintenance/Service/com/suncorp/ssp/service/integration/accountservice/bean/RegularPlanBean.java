////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code RegularPlanBean} is used to hold the data of regular contribution.
 * 
 * @author U383754
 * @since 27/05/2016
 * @version 1.0
 */
public class RegularPlanBean {
    private String regularPlanId;
    private RelationshipIdentifierBean relationshipType;
    private ClientBean client;
    private CodeIdentifier status;
    private String savingsPlan;
    private CodeIdentifier paymentMethod;
    private FrequencyIdentifierBean frequency;
    private BankAccountIdentifierBean bankAccount;
    private String amount;
    private String useNaturalIncome;
    private CurrencyIdentifierBean amountCurrencyCode;
    private IndexationRequiredBean indexationRequired;
    private String nextDueDate;
    private String endDate;
    private String payerReference;
    private CodeIdentifier sourceOfWealth;
    private String sourceOfWealthText;
    private String linkedToProfile;
    private List<FundSplitsBean> fundSplits;
    private List<ContributionTypeSplitsBean> contributionTypeSplits;
    private List<BalanceTypeSplitsBean> balanceTypeSplits;
    private InvestmentRequesterBean investmentRequester;
    private CodeIdentifier instructorCategoryCode;

    /**
     * Accessor for property regularPlanId.
     * 
     * @return regularPlanId of type String
     */
    public String getRegularPlanId() {
        return regularPlanId;
    }

    /**
     * Mutator for property regularPlanId.
     * 
     * @param regularPlanId of type String
     */
    @XmlElement(name = "regularPlanId")
    public void setRegularPlanId(String regularPlanId) {
        this.regularPlanId = regularPlanId;
    }

    /**
     * Accessor for property relationshipType.
     * 
     * @return relationshipType of type RelationshipIdentifierBean
     */
    public RelationshipIdentifierBean getRelationshipType() {
        return relationshipType;
    }

    /**
     * Mutator for property relationshipType.
     * 
     * @param relationshipType of type RelationshipIdentifierBean
     */
    @XmlElement(name = "relationshipType")
    public void setRelationshipType(RelationshipIdentifierBean relationshipType) {
        this.relationshipType = relationshipType;
    }

    /**
     * Accessor for property client.
     * 
     * @return client of type ClientBean
     */
    public ClientBean getClient() {
        return client;
    }

    /**
     * Mutator for property client.
     * 
     * @param client of type ClientBean
     */
    @XmlElement(name = "client")
    public void setClient(ClientBean client) {
        this.client = client;
    }

    /**
     * Accessor for property status.
     * 
     * @return status of type CodeIdentifier
     */
    public CodeIdentifier getStatus() {
        return status;
    }

    /**
     * Mutator for property status.
     * 
     * @param status of type CodeIdentifier
     */
    @XmlElement(name = "status")
    public void setStatus(CodeIdentifier status) {
        this.status = status;
    }

    /**
     * Accessor for property savingsPlan.
     * 
     * @return savingsPlan of type String
     */
    public String getSavingsPlan() {
        return savingsPlan;
    }

    /**
     * Mutator for property savingsPlan.
     * 
     * @param savingsPlan of type String
     */
    @XmlElement(name = "savingsPlan")
    public void setSavingsPlan(String savingsPlan) {
        this.savingsPlan = savingsPlan;
    }

    /**
     * Accessor for property paymentMethod.
     * 
     * @return paymentMethod of type CodeIdentifier
     */
    public CodeIdentifier getPaymentMethod() {
        return paymentMethod;
    }

    /**
     * Mutator for property paymentMethod.
     * 
     * @param paymentMethod of type CodeIdentifier
     */
    @XmlElement(name = "paymentMethod")
    public void setPaymentMethod(CodeIdentifier paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    /**
     * Accessor for property frequency.
     * 
     * @return frequency of type FrequencyIdentifierBean
     */
    public FrequencyIdentifierBean getFrequency() {
        return frequency;
    }

    /**
     * Mutator for property frequency.
     * 
     * @param frequency of type FrequencyIdentifierBean
     */
    @XmlElement(name = "frequency")
    public void setFrequency(FrequencyIdentifierBean frequency) {
        this.frequency = frequency;
    }

    /**
     * Accessor for property bankAccount.
     * 
     * @return bankAccount of type BankAccountIdentifierBean
     */
    public BankAccountIdentifierBean getBankAccount() {
        return bankAccount;
    }

    /**
     * Mutator for property bankAccount.
     * 
     * @param bankAccount of type BankAccountIdentifierBean
     */
    @XmlElement(name = "bankAccount")
    public void setBankAccount(BankAccountIdentifierBean bankAccount) {
        this.bankAccount = bankAccount;
    }

    /**
     * Accessor for property amount.
     * 
     * @return amount of type String
     */
    public String getAmount() {
        return amount;
    }

    /**
     * Mutator for property amount.
     * 
     * @param amount of type String
     */
    @XmlElement(name = "amount")
    public void setAmount(String amount) {
        this.amount = amount;
    }

    /**
     * Accessor for property useNaturalIncome.
     * 
     * @return useNaturalIncome of type String
     */
    public String getUseNaturalIncome() {
        return useNaturalIncome;
    }

    /**
     * Mutator for property useNaturalIncome.
     * 
     * @param useNaturalIncome of type String
     */
    @XmlElement(name = "useNaturalIncome")
    public void setUseNaturalIncome(String useNaturalIncome) {
        this.useNaturalIncome = useNaturalIncome;
    }

    /**
     * Accessor for property amountCurrencyCode.
     * 
     * @return amountCurrencyCode of type CurrencyIdentifierBean
     */
    public CurrencyIdentifierBean getAmountCurrencyCode() {
        return amountCurrencyCode;
    }

    /**
     * Mutator for property amountCurrencyCode.
     * 
     * @param amountCurrencyCode of type CurrencyIdentifierBean
     */
    @XmlElement(name = "amountCurrencyCode")
    public void setAmountCurrencyCode(CurrencyIdentifierBean amountCurrencyCode) {
        this.amountCurrencyCode = amountCurrencyCode;
    }

    /**
     * Accessor for property indexationRequired.
     * 
     * @return indexationRequired of type IndexationRequiredBean
     */
    public IndexationRequiredBean getIndexationRequired() {
        return indexationRequired;
    }

    /**
     * Mutator for property indexationRequired.
     * 
     * @param indexationRequired of type IndexationRequiredBean
     */
    @XmlElement(name = "indexationRequired")
    public void setIndexationRequired(IndexationRequiredBean indexationRequired) {
        this.indexationRequired = indexationRequired;
    }

    /**
     * Accessor for property nextDueDate.
     * 
     * @return nextDueDate of type String
     */
    public String getNextDueDate() {
        return nextDueDate;
    }

    /**
     * Mutator for property nextDueDate.
     * 
     * @param nextDueDate of type String
     */
    @XmlElement(name = "nextDueDate")
    public void setNextDueDate(String nextDueDate) {
        this.nextDueDate = nextDueDate;
    }

    /**
     * Accessor for property endDate.
     * 
     * @return endDate of type String
     */
    public String getEndDate() {
        return endDate;
    }

    /**
     * Mutator for property endDate.
     * 
     * @param endDate of type String
     */
    @XmlElement(name = "endDate")
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    /**
     * Accessor for property payerReference.
     * 
     * @return payerReference of type String
     */
    public String getPayerReference() {
        return payerReference;
    }

    /**
     * Mutator for property payerReference.
     * 
     * @param payerReference of type String
     */
    @XmlElement(name = "payerReference")
    public void setPayerReference(String payerReference) {
        this.payerReference = payerReference;
    }

    /**
     * Accessor for property sourceOfWealth.
     * 
     * @return sourceOfWealth of type CodeIdentifier
     */
    public CodeIdentifier getSourceOfWealth() {
        return sourceOfWealth;
    }

    /**
     * Mutator for property sourceOfWealth.
     * 
     * @param sourceOfWealth of type CodeIdentifier
     */
    @XmlElement(name = "sourceOfWealth")
    public void setSourceOfWealth(CodeIdentifier sourceOfWealth) {
        this.sourceOfWealth = sourceOfWealth;
    }

    /**
     * Accessor for property sourceOfWealthText.
     * 
     * @return sourceOfWealthText of type String
     */
    public String getSourceOfWealthText() {
        return sourceOfWealthText;
    }

    /**
     * Mutator for property sourceOfWealthText.
     * 
     * @param sourceOfWealthText of type String
     */
    @XmlElement(name = "sourceOfWealthText")
    public void setSourceOfWealthText(String sourceOfWealthText) {
        this.sourceOfWealthText = sourceOfWealthText;
    }

    /**
     * Accessor for property linkedToProfile.
     * 
     * @return linkedToProfile of type String
     */
    public String getLinkedToProfile() {
        return linkedToProfile;
    }

    /**
     * Mutator for property linkedToProfile.
     * 
     * @param linkedToProfile of type String
     */
    @XmlElement(name = "linkedToProfile")
    public void setLinkedToProfile(String linkedToProfile) {
        this.linkedToProfile = linkedToProfile;
    }

    /**
     * Accessor for property fundSplits.
     * 
     * @return fundSplits of type List<FundSplitsBean>
     */
    public List<FundSplitsBean> getFundSplits() {
        return fundSplits;
    }

    /**
     * Mutator for property fundSplits.
     * 
     * @param fundSplits of type List<FundSplitsBean>
     */
    @XmlElement(name = "fundSplits")
    public void setFundSplits(List<FundSplitsBean> fundSplits) {
        this.fundSplits = fundSplits;
    }

    /**
     * Accessor for property contributionTypeSplits.
     * 
     * @return contributionTypeSplits of type List<ContributionTypeSplitsBean>
     */
    public List<ContributionTypeSplitsBean> getContributionTypeSplits() {
        return contributionTypeSplits;
    }

    /**
     * Mutator for property contributionTypeSplits.
     * 
     * @param contributionTypeSplits of type List<ContributionTypeSplitsBean>
     */
    @XmlElement(name = "contributionTypeSplits")
    public void setContributionTypeSplits(List<ContributionTypeSplitsBean> contributionTypeSplits) {
        this.contributionTypeSplits = contributionTypeSplits;
    }

    /**
     * Accessor for property balanceTypeSplits.
     * 
     * @return balanceTypeSplits of type List<BalanceTypeSplitsBean>
     */
    public List<BalanceTypeSplitsBean> getBalanceTypeSplits() {
        return balanceTypeSplits;
    }

    /**
     * Mutator for property balanceTypeSplits.
     * 
     * @param balanceTypeSplits of type List<BalanceTypeSplitsBean>
     */
    @XmlElement(name = "balanceTypeSplits")
    public void setBalanceTypeSplits(List<BalanceTypeSplitsBean> balanceTypeSplits) {
        this.balanceTypeSplits = balanceTypeSplits;
    }

    /**
     * Accessor for property investmentRequester.
     * 
     * @return investmentRequester of type InvestmentRequesterBean
     */
    public InvestmentRequesterBean getInvestmentRequester() {
        return investmentRequester;
    }

    /**
     * Mutator for property investmentRequester.
     * 
     * @param investmentRequester of type InvestmentRequesterBean
     */
    @XmlElement(name = "investmentRequester")
    public void setInvestmentRequester(InvestmentRequesterBean investmentRequester) {
        this.investmentRequester = investmentRequester;
    }

    /**
     * Accessor for property instructorCategoryCode.
     * 
     * @return instructorCategoryCode of type CodeIdentifier
     */
    public CodeIdentifier getInstructorCategoryCode() {
        return instructorCategoryCode;
    }

    /**
     * Mutator for property instructorCategoryCode.
     * 
     * @param instructorCategoryCode of type CodeIdentifier
     */
    @XmlElement(name = "instructorCategoryCode")
    public void setInstructorCategoryCode(CodeIdentifier instructorCategoryCode) {
        this.instructorCategoryCode = instructorCategoryCode;
    }

}
