////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code DeciamlRangeIdentifier} does this.
 *
 * @author u387938
 * @since 09/02/2016
 * @version 1.0
 */
public class DecimalRangeIdentifier {
    
    private String minimum;
    private String maximum;
    /**
     * Accessor for property minimum.
     *
     * @return minimum of type String
     */
    public String getMinimum() {
        return minimum;
    }
    /**
     * Mutator for property minimum.
     *
     * @param minimum of type String
     */
    @XmlElement(name = "minimum")
    public void setMinimum(String minimum) {
        this.minimum = minimum != null ? minimum : "";
    }
    /**
     * Accessor for property maximum.
     *
     * @return maximum of type String
     */
    public String getMaximum() {
        return maximum;
    }
    /**
     * Mutator for property maximum.
     *
     * @param maximum of type String
     */
    @XmlElement(name = "maximum")
    public void setMaximum(String maximum) {
        this.maximum = maximum != null ? maximum : "";
    } 
    
    

}
