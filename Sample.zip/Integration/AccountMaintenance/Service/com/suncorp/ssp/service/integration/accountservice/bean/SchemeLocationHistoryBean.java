////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;
/**
 * The class {@code SchemeLocationHistoryBean} does this.
 * 
 * @author U387938
 * @since 02/02/2016
 * @version 1.0
 */
public class SchemeLocationHistoryBean {

    private String id;
    private String effectiveDate;
    private SchemeLocationIdentifier schemeLocation;
    private CategoryBean category;
    /**
     * Accessor for property id.
     *
     * @return id of type String
     */
    public String getId() {
        return id;
    }
    /**
     * Mutator for property id.
     *
     * @param id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id != null ? id : "";
    }
    /**
     * Accessor for property effectiveDate.
     *
     * @return effectiveDate of type String
     */
    public String getEffectiveDate() {
        return effectiveDate;
    }
    /**
     * Mutator for property effectiveDate.
     *
     * @param effectiveDate of type String
     */
    @XmlElement(name = "effectiveDate")
    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate != null ? effectiveDate : "";
    }
    /**
     * Accessor for property schemeLocation.
     *
     * @return schemeLocation of type SchemeLocationIdentifier
     */
    public SchemeLocationIdentifier getSchemeLocation() {
        return schemeLocation;
    }
    /**
     * Mutator for property schemeLocation.
     *
     * @param schemeLocation of type SchemeLocationIdentifier
     */
    @XmlElement(name = "schemeLocation")
    public void setSchemeLocation(SchemeLocationIdentifier schemeLocation) {
        this.schemeLocation = schemeLocation;
    }
    /**
     * Accessor for property category.
     *
     * @return category of type CategoryBean
     */
    public CategoryBean getCategory() {
        return category;
    }
    /**
     * Mutator for property category.
     *
     * @param category of type CategoryBean
     */
    @XmlElement(name = "category")
    public void setCategory(CategoryBean category) {
        this.category = category;
    }
    
    
}
