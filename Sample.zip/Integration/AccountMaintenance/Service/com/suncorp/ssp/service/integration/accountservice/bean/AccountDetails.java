////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code AccountDetails} does this.
 * 
 * @author U383754
 * @since 02/02/2016
 * @version 1.0
 */
public class AccountDetails {
    private String id;
    private String name;
    private AccountNumberInfo accountNumber;
    private ReferenceIdentifier accountExternalRef;
    private CodeIdentifier statusCode;
    private AuditIdentifier audit;
    private AccountPointer accountPointer;
    private MasterSchemeIdentifier masterScheme;

    /**
     * Accessor for property id.
     * 
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     * 
     * @return id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id != null ? id : "";
    }

    /**
     * Accessor for property name.
     * 
     * @return name of type String
     */
    public String getName() {
        return name;
    }

    /**
     * Mutator for property name.
     * 
     * @return name of type String
     */
    @XmlElement(name = "name")
    public void setName(String name) {
        this.name = name != null ? name : "";
    }

    /**
     * Accessor for property accountExternalRef.
     * 
     * @return accountExternalRef of type ReferenceIdentifier
     */
    public ReferenceIdentifier getAccountExternalRef() {
        return accountExternalRef;
    }

    /**
     * Mutator for property accountExternalRef.
     * 
     * @return accountExternalRef of type ReferenceIdentifier
     */
    @XmlElement(name = "accountExternalRef")
    public void setAccountExternalRef(ReferenceIdentifier accountExternalRef) {
        this.accountExternalRef = accountExternalRef;
    }

    /**
     * Accessor for property statusCode.
     * 
     * @return statusCode of type CodeIdentifier
     */
    public CodeIdentifier getStatusCode() {
        return statusCode;
    }

    /**
     * Mutator for property statusCode.
     * 
     * @return statusCode of type CodeIdentifier
     */
    @XmlElement(name = "statusCode")
    public void setStatusCode(CodeIdentifier statusCode) {
        this.statusCode = statusCode;
    }

    /**
     * Accessor for property audit.
     * 
     * @return audit of type AuditIdentifier
     */
    public AuditIdentifier getAudit() {
        return audit;
    }

    /**
     * Mutator for property audit.
     * 
     * @return audit of type AuditIdentifier
     */
    @XmlElement(name = "audit")
    public void setAudit(AuditIdentifier audit) {
        this.audit = audit;
    }

    /**
     * Accessor for property masterScheme.
     * 
     * @return masterScheme of type MasterSchemeIdentifier
     */
    public MasterSchemeIdentifier getMasterScheme() {
        return masterScheme;
    }

    /**
     * Mutator for property masterScheme.
     * 
     * @return masterScheme of type MasterSchemeIdentifier
     */
    @XmlElement(name = "masterScheme")
    public void setMasterScheme(MasterSchemeIdentifier masterScheme) {
        this.masterScheme = masterScheme;
    }

    /**
     * @return the accountNumber
     */
    public AccountNumberInfo getAccountNumber() {
        return accountNumber;
    }

    /**
     * @param accountNumber the accountNumber to set
     */
    @XmlElement(name = "accountNumber")
    public void setAccountNumber(AccountNumberInfo accountNumber) {
        this.accountNumber = accountNumber;
    }

    /**
     * @return the accoutPointer
     */
    public AccountPointer getAccountPointer() {
        return accountPointer;
    }

    /**
     * @param accountPointer the accoutPointer to set
     */
    @XmlElement(name = "accountPointer")
    public void setAccountPointer(AccountPointer accountPointer) {
        this.accountPointer = accountPointer;
    }

}
