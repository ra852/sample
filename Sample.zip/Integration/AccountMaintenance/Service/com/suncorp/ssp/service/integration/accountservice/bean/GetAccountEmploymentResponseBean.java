////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.suncorp.ssp.common.bean.SILErrorMessage;

/**
 * The class {@code GetAccountEmploymentResponseBean} is a java bean consisting of all the properties related to GetAccountEmployment functionality,
 * to be used for constructing response for end-client.
 * 
 * @author u387938
 * @since 12/09/2016
 * @version 1.0
 */
@XmlRootElement(name = "GetAccountEmploymentResponse")
public class GetAccountEmploymentResponseBean extends SILErrorMessage {

    private AccountDetails account;
    private List<EmploymentDetails> employment;

    /**
     * Accessor for property account.
     * 
     * @return account of type AccountDetails
     */
    public AccountDetails getAccount() {
        return account;
    }

    /**
     * Mutator for property account.
     * 
     * @param account of type AccountDetails
     */
    @XmlElement(name = "account")
    public void setAccount(AccountDetails account) {
        this.account = account;
    }

    /**
     * Accessor for property employment.
     *
     * @return employment of type List<EmploymentDetails>
     */
    public List<EmploymentDetails> getEmployment() {
        return employment;
    }

    /**
     * Mutator for property employment.
     *
     * @param employment of type List<EmploymentDetails>
     */
    @XmlElement(name = "employment")
    public void setEmployment(List<EmploymentDetails> employment) {
        this.employment = employment;
    }

    
}
