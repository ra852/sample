////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code FundShortTypeDetails} is a pure java bean consisting of properties related to FundShortTypeDetails.
 * 
 * @author U385424
 * @since 23/01/2017
 * @version 1.0
 */
public class FundShortTypeDetails {
    private String id;
    private String name;
    private String fundFullName;
    private String fundCorroName;

    /**
     * Accessor for property id.
     * 
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     * 
     * @param id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id != null ? id : "";
    }

    /**
     * Accessor for property name.
     * 
     * @return name of type String
     */
    public String getName() {
        return name;
    }

    /**
     * Mutator for property name.
     * 
     * @param name of type String
     */
    @XmlElement(name = "name")
    public void setName(String name) {
        this.name = name != null ? name : "";
    }

    /**
     * Accessor for property fundFullName.
     * 
     * @return fundFullName of type String
     */
    public String getFundFullName() {
        return fundFullName;
    }

    /**
     * Mutator for property fundFullName.
     * 
     * @param fundFullName of type String
     */
    @XmlElement(name = "fundFullName")
    public void setFundFullName(String fundFullName) {
        this.fundFullName = fundFullName != null ? fundFullName : "";
    }

    /**
     * Accessor for property fundCorroName.
     * 
     * @return fundCorroName of type String
     */
    public String getFundCorroName() {
        return fundCorroName;
    }

    /**
     * Mutator for property fundCorroName.
     * 
     * @param fundCorroName of type String
     */
    @XmlElement(name = "fundCorroName")
    public void setFundCorroName(String fundCorroName) {
        this.fundCorroName = fundCorroName != null ? fundCorroName : "";
    }
}
