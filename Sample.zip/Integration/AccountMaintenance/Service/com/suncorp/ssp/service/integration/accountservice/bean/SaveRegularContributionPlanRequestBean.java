////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * The class {@code SaveRegularContributionPlanRequestBean} is used to hold the data for saving regular contribution plan.
 * 
 * @author U383754
 * @since 27/05/2016
 * @version 1.0
 */
@XmlRootElement(name = "SaveRegularContributionPlanRequest")
public class SaveRegularContributionPlanRequestBean {
    private SaveAccountDetails account;
    private RegularPlanBean regularContributionPlan;

    /**
     * Accessor for property account.
     * 
     * @return account of type SaveAccountDetails
     */
    public SaveAccountDetails getAccount() {
        return account;
    }

    /**
     * Mutator for property account.
     * 
     * @return account of type SaveAccountDetails
     */
    @XmlElement(name = "account")
    public void setAccount(SaveAccountDetails account) {
        this.account = account;
    }

    /**
     * Accessor for property regularContributionPlan.
     * 
     * @return regularContributionPlan of type RegularPlanBean
     */
    public RegularPlanBean getRegularContributionPlan() {
        return regularContributionPlan;
    }

    /**
     * Mutator for property regularContributionPlan.
     * 
     * @return regularContributionPlan of type RegularPlanBean
     */
    @XmlElement(name = "regularContributionPlan")
    public void setRegularContributionPlan(RegularPlanBean regularContributionPlan) {
        this.regularContributionPlan = regularContributionPlan;
    }
}
