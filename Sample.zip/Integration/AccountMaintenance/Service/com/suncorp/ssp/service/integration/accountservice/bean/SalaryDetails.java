////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code SalaryDetails} does this.
 *
 * @author U387938
 * @since 12/09/2016
 * @version 1.0
 */
public class SalaryDetails {

    private String id;
    private CodeIdentifier salaryType;
    private String salary;
    private String serviceFraction;
    private String effectiveFrom;
    private String effectiveTo;
    
    /**
     * Accessor for property id.
     *
     * @return id of type String
     */
    public String getId() {
        return id;
    }
    /**
     * Mutator for property id.
     *
     * @param id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id != null ? id : "";
    }
    /**
     * Accessor for property salaryType.
     *
     * @return salaryType of type CodeIdentifier
     */
    public CodeIdentifier getSalaryType() {
        return salaryType;
    }
    /**
     * Mutator for property salaryType.
     *
     * @param salaryType of type CodeIdentifier
     */
    @XmlElement(name = "salaryType")
    public void setSalaryType(CodeIdentifier salaryType) {
        this.salaryType = salaryType;
    }
    /**
     * Accessor for property salary.
     *
     * @return salary of type String
     */
    public String getSalary() {
        return salary;
    }
    /**
     * Mutator for property salary.
     *
     * @param salary of type String
     */
    @XmlElement(name = "salary")
    public void setSalary(String salary) {
        this.salary = salary != null ? salary : "";
    }
    /**
     * Accessor for property serviceFraction.
     *
     * @return serviceFraction of type String
     */
    public String getServiceFraction() {
        return serviceFraction;
    }
    /**
     * Mutator for property serviceFraction.
     *
     * @param serviceFraction of type String
     */
    @XmlElement(name = "serviceFraction")
    public void setServiceFraction(String serviceFraction) {
        this.serviceFraction = serviceFraction;
    }
    /**
     * Accessor for property effectiveFrom.
     *
     * @return effectiveFrom of type String
     */
    public String getEffectiveFrom() {
        return effectiveFrom;
    }
    /**
     * Mutator for property effectiveFrom.
     *
     * @param effectiveFrom of type String
     */
    @XmlElement(name = "effectiveFrom")
    public void setEffectiveFrom(String effectiveFrom) {
        this.effectiveFrom = effectiveFrom != null ? effectiveFrom : "";
    }
    
    /**
     * Accessor for property effectiveTo.
     *
     * @return effectiveTo of type String
     */
    public String getEffectiveTo() {
        return effectiveTo;
    }
    /**
     * Mutator for property effectiveTo.
     *
     * @param effectiveTo of type String
     */
    @XmlElement(name = "effectiveTo")
    public void setEffectiveTo(String effectiveTo) {
        this.effectiveTo = effectiveTo;
    }
    
}
