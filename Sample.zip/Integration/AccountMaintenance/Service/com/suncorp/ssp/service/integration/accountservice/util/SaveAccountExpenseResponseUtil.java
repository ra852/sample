////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import com.sonatacentral.service.v30.wrap.account.SaveAccountExpenseResponseType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.SaveAccountExpenseResponse;

/**
 * The class {@code SaveInvestmentRestructureResponseUtil} construct's SOAP request for external service.
 * 
 * @author U387938
 * @since 20/03/2016
 * @version 1.0
 */
public class SaveAccountExpenseResponseUtil {
    private final String className = "SaveInvestmentRestructureResponseUtil";
    private SaveAccountExpenseResponseType saveAccountExpenseResponseType;

    public SaveAccountExpenseResponseUtil(SaveAccountExpenseResponseType saveAccountExpenseResponseType) {
        this.saveAccountExpenseResponseType = saveAccountExpenseResponseType;
    }

    /**
     * 
     * This method constructs SaveInvestmentRestuctureResponse object from response.
     * 
     * @param saveInvestmentRestuctureResponse
     * @throws SILException
     */
    public void setSaveInvestmentRestructureResponse(SaveAccountExpenseResponse saveAccountExpenseResponse) throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_EXPENSE_LOGGING_FORMAT, className, "Entering setSaveInvestmentRestructureResponse");
        if (saveAccountExpenseResponseType != null) {
            if (saveAccountExpenseResponseType.getAccount() != null && saveAccountExpenseResponseType.getAccount().getAccountNumber() != null &&
                    saveAccountExpenseResponseType.getAccount().getAccountNumber().getAccountNo() != null) {
                saveAccountExpenseResponse.setResponse(AccountServiceConstants.SAVE_ACCOUNT_EXPENSE_SUCCESS_MSG);
            }
        } else {
            throw new SILException(AccountServiceConstants.INVALID_RESPONSE_FROM_SONATA);
        }
    }

}
