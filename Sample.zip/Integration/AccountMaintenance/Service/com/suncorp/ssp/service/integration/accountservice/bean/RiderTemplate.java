////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;


/**
 * The class {@code RiderTemplate} does this.
 * 
 * @author U385424
 * @since 11/09/2017
 * @version 1.0
 */
public class RiderTemplate {

    private String name;
    private String id;
    private String shortName;
    private BenefitTemplateIdentifierDetails benefitTemplate;

    /**
     * Accessor for property id.
     * 
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     * 
     * @return id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id != null ? id : "";
    }

    /**
     * Accessor for property shortName.
     * 
     * @return shortName of type String
     */
    public String getShortName() {
        return shortName;
    }

    /**
     * Mutator for property shortName.
     * 
     * @param shortName of type String
     */
    @XmlElement(name = "shortName")
    public void setShortName(String shortName) {
        this.shortName = shortName != null ? shortName : "";
    }

    /**
     * Accessor for property benefitTemplate.
     * 
     * @return benefitTemplate of type BenefitTemplateIdentifierDetails
     */
    public BenefitTemplateIdentifierDetails getBenefitTemplate() {
        return benefitTemplate;
    }

    /**
     * Mutator for property benefitTemplate.
     * 
     * @param benefitTemplate of type BenefitTemplateIdentifierDetails
     */
    @XmlElement(name = "benefitTemplate")
    public void setBenefitTemplate(BenefitTemplateIdentifierDetails benefitTemplate) {
        this.benefitTemplate = benefitTemplate;
    }

    /**
     * Accessor for property name.
     * 
     * @return name of type String
     */
    public String getName() {
        return name;
    }

    /**
     * Mutator for property name.
     * 
     * @param name of type String
     */
    @XmlElement(name = "name")
    public void setName(String name) {
        this.name = name;
    }

}
