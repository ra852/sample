////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code CommonIdentifier} does this.
 * 
 * @author U383754
 * @since 01/02/2016
 * @version 1.0
 */
public class TransactionDetails {

    private String code;
    private CodeIdentifier categoryDetails;
    private String receivedDate;
    private String note;
    private CodeIdentifier switchReason;
    private IdentityIdentifier expenseGroup;
    private TransactionTypeIdentifierBean transactionType;

    /**
     * Accessor for property code.
     * 
     * @return code of type String
     */
    public String getCode() {
        return code;
    }

    /**
     * Mutator for property code.
     * 
     * @param code of type String
     */
    @XmlElement(name = "code")
    public void setCode(String code) {
        this.code = code != null ? code : "";
    }

    /**
     * Accessor for property categoryDetails.
     * 
     * @return categoryDetails of type CodeIdentifier
     */
    public CodeIdentifier getCategoryDetails() {
        return categoryDetails;
    }

    /**
     * Mutator for property categoryDetails.
     * 
     * @param categoryDetails of type CodeIdentifier
     */
    @XmlElement(name = "category")
    public void setCategoryDetails(CodeIdentifier categoryDetails) {
        this.categoryDetails = categoryDetails;
    }

    /**
     * Accessor for property receivedDate.
     *
     * @return receivedDate of type String
     */
    public String getReceivedDate() {
        return receivedDate;
    }

    /**
     * Mutator for property receivedDate.
     *
     * @param receivedDate of type String
     */
    @XmlElement(name = "receivedDate")
    public void setReceivedDate(String receivedDate) {
        this.receivedDate = receivedDate;
    }

    /**
     * Accessor for property note.
     *
     * @return note of type String
     */
    public String getNote() {
        return note;
    }

    /**
     * Mutator for property note.
     *
     * @param note of type String
     */
    @XmlElement(name = "note")
    public void setNote(String note) {
        this.note = note;
    }

    /**
     * Accessor for property switchReason.
     *
     * @return switchReason of type CodeIdentifier
     */
    public CodeIdentifier getSwitchReason() {
        return switchReason;
    }

    /**
     * Mutator for property switchReason.
     *
     * @param switchReason of type CodeIdentifier
     */
    @XmlElement(name = "switchReason")
    public void setSwitchReason(CodeIdentifier switchReason) {
        this.switchReason = switchReason;
    }

    /**
     * Accessor for property expenseGroup.
     *
     * @return expenseGroup of type IdentityIdentifier
     */
    public IdentityIdentifier getExpenseGroup() {
        return expenseGroup;
    }

    /**
     * Mutator for property expenseGroup.
     *
     * @param expenseGroup of type IdentityIdentifier
     */
    @XmlElement(name = "expenseGroup")
    public void setExpenseGroup(IdentityIdentifier expenseGroup) {
        this.expenseGroup = expenseGroup;
    }

    /**
     * Accessor for property transactionType.
     *
     * @return transactionType of type TransactionTypeIdentifierBean
     */
    public TransactionTypeIdentifierBean getTransactionType() {
        return transactionType;
    }

    /**
     * Mutator for property transactionType.
     *
     * @param transactionType of type TransactionTypeIdentifierBean
     */
    @XmlElement(name = "transactionType")
    public void setTransactionType(TransactionTypeIdentifierBean transactionType) {
        this.transactionType = transactionType;
    }

}
