////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import javax.ws.rs.core.MultivaluedMap;
import javax.xml.datatype.XMLGregorianCalendar;

import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CodeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.ExternalRefType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.PagingRangeType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType.AccountNumber;
import com.sonatacentral.service.v30.globaltypes.wrap.transaction.transactiongrouptype.TransactionTimeIndicatorType;
import com.sonatacentral.service.v30.globaltypes.wrap.transaction.transactiongrouptype.TransactionTypeIdentifierType;
import com.sonatacentral.service.v30.wrap.account.GetAccountTransactionListRequestType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;

/**
 * The class {@code GetAccountTransactionListRequestUtil} is used as a util class for preparing GetAccountTransactionList request.
 * 
 * @author u386868
 * @since 23/12/2015
 * @version 1.0
 */
public class GetAccountTransactionListRequestUtil {
    private final String className = "GetAccountTransactionListRequestUtil";
    private GetAccountTransactionListRequestType outboundRequest;
    private MultivaluedMap<String, String> inboundRequest;
    private int accountNumberFlag = 0;
    private int externalReferenceFlag = 0;

    /**
     * Initializes class properties,viz., inbound and outbound request types.
     * 
     * @param inboundRequest
     *            of type MultivaluedMap
     */
    public GetAccountTransactionListRequestUtil(MultivaluedMap<String, String> inboundRequest) {
        this.inboundRequest = inboundRequest;
        this.outboundRequest = new GetAccountTransactionListRequestType();
    }

    /**
     * Create Oubound request.
     * 
     * @throws Exception
     * @return outboundRequest of type GetAccountTransactionListRequestType
     */
    public GetAccountTransactionListRequestType createOutboundRequest() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACCOUNT_TRANS_LIST_LOGGING_FORMAT, className, "Entering createOutboundRequest()");
        this.outboundRequest.setCallerDetails(SILUtil.createCallerDetails());
        if (!checkIncludePricedAndUnpricedValue()) {
            this.outboundRequest.setAccount(createAccountIdentifierType());
            if (this.inboundRequest.containsKey(AccountServiceConstants.TRANSACTION_TYPE_CODE)) {
                this.outboundRequest.getTransactionType().add(createTransactionTypeIdentifierType());
            }
        }
        this.outboundRequest.setStartDateTime(createStartDate());
        this.outboundRequest.setEndDateTime(creatEndDate());
        this.outboundRequest.setTimeIndicator(TransactionTimeIndicatorType.fromValue("TREV_EFFECTIVE_DATE"));
        if (this.inboundRequest.containsKey(AccountServiceConstants.INCLUDE_PRICED_ONLY)) {
            this.outboundRequest.setIncludePricedOnly(createIncludePricedOnly());
        }
        if (this.inboundRequest.containsKey(AccountServiceConstants.INCLUDE_UNPRICED_ONLY)) {
            this.outboundRequest.setIncludeUnpricedOnly(createIncludeUnpricedOnly());
        }
        if (this.inboundRequest.containsKey(AccountServiceConstants.INCLUDE_TERM_DEPOSIT_DETAILS)) {
            this.outboundRequest.setIncludeTermDepositDetails(createIncludeTermDepositDetails());
        }
        this.outboundRequest.setPagingRange(createPagingRangeType());

        return this.outboundRequest;
    }

    /**
     * This method is used to check both IncludePriced and Unpriced flags values true or not.
     * 
     * @return boolean of type Boolean
     * @throws SILException
     */
    private boolean checkIncludePricedAndUnpricedValue() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACCOUNT_TRANS_LIST_LOGGING_FORMAT, className, "Entering checkIncludePricedAndUnpricedValue()");
        if (this.inboundRequest.containsKey(AccountServiceConstants.INCLUDE_PRICED_ONLY) &&
                this.inboundRequest.get(AccountServiceConstants.INCLUDE_PRICED_ONLY).get(0).equalsIgnoreCase("true") &&
                this.inboundRequest.containsKey(AccountServiceConstants.INCLUDE_UNPRICED_ONLY) &&
                this.inboundRequest.get(AccountServiceConstants.INCLUDE_UNPRICED_ONLY).get(0).equalsIgnoreCase("true")) {
            this.outboundRequest.setIncludeUnpricedOnly(createIncludeUnpricedOnly());
            this.outboundRequest.setIncludeUnpricedOnly(createIncludeUnpricedOnly());
            return true;
        }
        return false;
    }

    /**
     * Create a new instance of AccountIdentifierType, with necessary values set.
     * 
     * @return accountIdentifierType of type AccountIdentifierType
     * @throws SILException
     */
    public AccountIdentifierType createAccountIdentifierType() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACCOUNT_TRANS_LIST_LOGGING_FORMAT, className, "Entering createAccountIdentifierType()");
        AccountIdentifierType accountIdentifierType = new AccountIdentifierType();
        AccountNumber accountNumber = new AccountNumber();
        if (this.inboundRequest.containsKey(AccountServiceConstants.ACCOUNT_NO)) {
            accountNumber.setAccountNo(this.inboundRequest.get(AccountServiceConstants.ACCOUNT_NO).get(0));
            accountNumberFlag++;
        }
        if (this.inboundRequest.containsKey(AccountServiceConstants.ACCOUNT_NAME)) {
            accountIdentifierType.setName(this.inboundRequest.get(AccountServiceConstants.ACCOUNT_NAME).get(0));
        }
        accountIdentifierType.setAccountNumber(accountNumber);
        accountIdentifierType.setAccountExternalRef(createAccountExternalRefType());
        if (accountNumberFlag == 0 && externalReferenceFlag == 0 || accountNumberFlag == 0 && externalReferenceFlag == 1) {
            throw new SILException(AccountServiceConstants.INVALID_REQUEST_MESSAGE_FOR_TRASACTION_LIST);
        }
        return accountIdentifierType;
    }

    /**
     * Create a new instance of ExternalRefType, with necessary value set.
     * 
     * @return externalRefType of type ExternalRefType
     * @throws SILException
     */
    private ExternalRefType createAccountExternalRefType() throws SILException {
        ExternalRefType externalRefType = new ExternalRefType();
        if (this.inboundRequest.containsKey(AccountServiceConstants.EXTERNAL_REFERENCE)) {
            externalRefType.setReference(this.inboundRequest.get(AccountServiceConstants.EXTERNAL_REFERENCE).get(0));
            externalReferenceFlag++;
        }
        if (this.inboundRequest.containsKey(AccountServiceConstants.EXTERNAL_REFERENCE_CODE)) {
            externalRefType.setReferenceCode(this.inboundRequest.get(AccountServiceConstants.EXTERNAL_REFERENCE_CODE).get(0));
            externalReferenceFlag++;
        }
        return externalRefType;
    }

    /**
     * Create a new instance of startDate, with necessary value set.
     * 
     * @return startDate of type XMLGregorianCalendar
     * @throws SILException
     */
    public XMLGregorianCalendar createStartDate() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACCOUNT_TRANS_LIST_LOGGING_FORMAT, className, "Entering createStartDate()");
        XMLGregorianCalendar startDate = null;
        if (this.inboundRequest.containsKey(AccountServiceConstants.START_DATE)) {
            String datetime = this.inboundRequest.get(AccountServiceConstants.START_DATE).get(0) + " 00:00:00";
            startDate = SILUtil.convertStringToXMLGregorianCalendar(datetime, CommonConstants.DATETIME_FORMAT);
        }
        return startDate;
    }

    /**
     * Create a new instance of endDate, with necessary value set.
     * 
     * @return endDate of type XMLGregorianCalendar
     * @throws SILException
     */
    public XMLGregorianCalendar creatEndDate() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACCOUNT_TRANS_LIST_LOGGING_FORMAT, className, "Entering creatEndDate()");
        XMLGregorianCalendar endDate = null;
        if (this.inboundRequest.containsKey(AccountServiceConstants.END_DATE)) {
            String datetime = this.inboundRequest.get(AccountServiceConstants.END_DATE).get(0) + " 23:59:59";
            endDate = SILUtil.convertStringToXMLGregorianCalendar(datetime, CommonConstants.DATETIME_FORMAT);
        }
        return endDate;
    }

    /**
     * Create a new instance of includePricedOnly, with necessary value set.
     * 
     * @return includePricedOnly of type boolean
     * @throws SILException
     */
    public boolean createIncludePricedOnly() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACCOUNT_TRANS_LIST_LOGGING_FORMAT, className, "Entering createIncludePricedOnly()");
        boolean includePricedOnly = false;
        if (this.inboundRequest.containsKey(AccountServiceConstants.INCLUDE_PRICED_ONLY)) {
            includePricedOnly = Boolean.parseBoolean(this.inboundRequest.get(AccountServiceConstants.INCLUDE_PRICED_ONLY).get(0));
        }
        return includePricedOnly;
    }

    /**
     * Create a new instance of includeUnpricedOnly, with necessary value set.
     * 
     * @return includeUnpricedOnly of type boolean
     * @throws SILException
     */
    public boolean createIncludeUnpricedOnly() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACCOUNT_TRANS_LIST_LOGGING_FORMAT, className, "Entering createIncludeUnpricedOnly()");
        boolean includeUnpricedOnly = false;
        if (this.inboundRequest.containsKey(AccountServiceConstants.INCLUDE_UNPRICED_ONLY)) {
            includeUnpricedOnly = Boolean.parseBoolean(this.inboundRequest.get(AccountServiceConstants.INCLUDE_UNPRICED_ONLY).get(0));
        }
        return includeUnpricedOnly;
    }

    /**
     * Create a new instance of includeTermDepositDetails, with necessary value set.
     * 
     * @return includeTermDepositDetails of type boolean
     * @throws SILException
     */
    public boolean createIncludeTermDepositDetails() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACCOUNT_TRANS_LIST_LOGGING_FORMAT, className, "Entering createIncludeTermDepositDetails()");
        boolean includeTermDepositDetails = false;
        if (this.inboundRequest.containsKey(AccountServiceConstants.INCLUDE_TERM_DEPOSIT_DETAILS)) {
            includeTermDepositDetails = Boolean.parseBoolean(this.inboundRequest.get(AccountServiceConstants.INCLUDE_TERM_DEPOSIT_DETAILS).get(0));
        }
        return includeTermDepositDetails;
    }

    /**
     * Create a new instance of TransactionTypeIdentifierType, with necessary values set.
     * 
     * @return transTypeIdentifierCode of type TransactionTypeIdentifierType
     * @throws SILException
     */
    public TransactionTypeIdentifierType createTransactionTypeIdentifierType() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACCOUNT_TRANS_LIST_LOGGING_FORMAT, className, "Entering createTransactionTypeIdentifierType()");
        TransactionTypeIdentifierType transTypeIdentifierCode = new TransactionTypeIdentifierType();
        if (this.inboundRequest.containsKey(AccountServiceConstants.TRANSACTION_TYPE_CODE)) {
            transTypeIdentifierCode.setCode(this.inboundRequest.get(AccountServiceConstants.TRANSACTION_TYPE_CODE).get(0));
        }
        if (this.inboundRequest.containsKey(AccountServiceConstants.CATEGORY_CODE)) {
            transTypeIdentifierCode.setCategory(createCodeIdentifierType());
        }
        return transTypeIdentifierCode;
    }

    /**
     * Create a new instance of CodeIdentifierType, with necessary values set.
     * 
     * @return codeIdentifierType of type CodeIdentifierType
     * @throws SILException
     */

    public CodeIdentifierType createCodeIdentifierType() throws SILException {
        CodeIdentifierType codeIdentifierType = new CodeIdentifierType();
        if (this.inboundRequest.containsKey(AccountServiceConstants.CATEGORY_CODE)) {
            codeIdentifierType.setCode(this.inboundRequest.get(AccountServiceConstants.CATEGORY_CODE).get(0));
        }
        if (this.inboundRequest.containsKey(AccountServiceConstants.CATEGORY_CODE_TYPE)) {
            codeIdentifierType.setCodeType(this.inboundRequest.get(AccountServiceConstants.CATEGORY_CODE_TYPE).get(0));
        }
        return codeIdentifierType;
    }

    /**
     * Create a new instance of PagingRangeType, with necessary values set.
     * 
     * @return pagingRangeType of type PagingRangeType
     * @throws SILException
     */
    public PagingRangeType createPagingRangeType() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACCOUNT_TRANS_LIST_LOGGING_FORMAT, className, "Entering createPagingRangeType() ");
        PagingRangeType pagingRangeType = new PagingRangeType();
        if (this.inboundRequest.containsKey(AccountServiceConstants.FIRST_RESULT)) {
            pagingRangeType.setFirstResult(Integer.parseInt(this.inboundRequest.get(AccountServiceConstants.FIRST_RESULT).get(0)));
        } else {
            pagingRangeType.setFirstResult(0);
        }
        if (this.inboundRequest.containsKey(AccountServiceConstants.RESULT_PER_PAGE)) {
            pagingRangeType.setResultsPerPage(Integer.parseInt(this.inboundRequest.get(AccountServiceConstants.RESULT_PER_PAGE).get(0)));
        } else {
            pagingRangeType.setResultsPerPage(0);
        }
        return pagingRangeType;
    }
}
