////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import javax.ws.rs.core.MultivaluedMap;

import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType.AccountNumber;
import com.sonatacentral.service.v30.wrap.account.GetAccountEmploymentRequestType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;

/**
 * The class {@code GetAccountEmploymentRequestUtil} is used as a util class for preparing GetAccountEmployment request.
 * 
 * @author u387938
 * @since 12/09/2016
 * @version 1.0
 */
public class GetAccountEmploymentRequestUtil {
    private final String className = "GetAccountEmploymentRequestUtil";
    private GetAccountEmploymentRequestType outboundRequest;
    private MultivaluedMap<String, String> inboundRequest;

    /**
     * Initializes class properties,viz., inbound and outbound request types.
     * 
     * @param inboundRequest of type MultivaluedMap
     */
    public GetAccountEmploymentRequestUtil(MultivaluedMap<String, String> inboundRequest) {
        this.inboundRequest = inboundRequest;
        this.outboundRequest = new GetAccountEmploymentRequestType();
    }

    /**
     * Create Oubound request.
     * 
     * @throws Exception
     * @return outboundRequest of type GetAccountEmploymentRequestType
     */
    public GetAccountEmploymentRequestType createOutboundRequest() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_SWITCH_STATUS_LOGGING_FORMAT, className, "Entering createOutboundRequest()");
        this.outboundRequest.setCallerDetails(SILUtil.createCallerDetails());
        this.outboundRequest.setAccount(createAccountIdentifierType());

        return this.outboundRequest;
    }

    /**
     * Create a new instance of AccountIdentifierType, with necessary values set.
     * 
     * @return accountIdentifierType of type AccountIdentifierType
     * @throws SILException
     */
    public AccountIdentifierType createAccountIdentifierType() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_SWITCH_STATUS_LOGGING_FORMAT, className, "Entering createAccountIdentifierType()");
        AccountIdentifierType accountIdentifierType = new AccountIdentifierType();
        AccountNumber accountNumber = new AccountNumber();
        if (this.inboundRequest.containsKey(AccountServiceConstants.ACCOUNT_NO)) {
            accountNumber.setAccountNo(this.inboundRequest.get(AccountServiceConstants.ACCOUNT_NO).get(0));
        }
        accountIdentifierType.setAccountNumber(accountNumber);
        return accountIdentifierType;
    }

}
