////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code ReviewTypeIdentifierDetails} does this.
 * 
 * @author U385424
 * @since 17/02/2018
 * @version 1.0
 */
public class ReviewTypeIdentifierDetails {

    private String id;
    private String name;
    private String longName;
    private AuditIdentifier audit;

    /**
     * Accessor for property id.
     * 
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     * 
     * @return id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id != null ? id : "";
    }

    /**
     * Accessor for property name.
     * 
     * @return name of type String
     */
    public String getName() {
        return name;
    }

    /**
     * Mutator for property name.
     * 
     * @return name of type String
     */
    @XmlElement(name = "name")
    public void setName(String name) {
        this.name = name != null ? name : "";
    }

    /**
     * Accessor for property longName.
     * 
     * @return longName of type String
     */
    public String getLongName() {
        return longName;
    }

    /**
     * Mutator for property longName.
     * 
     * @return longName of type String
     */
    @XmlElement(name = "longName")
    public void setLongName(String longName) {
        this.longName = longName != null ? longName : "";
    }

    /**
     * Accessor for property audit.
     * 
     * @return audit of type AuditDetails
     */
    public AuditIdentifier getAudit() {
        return audit;
    }

    /**
     * Mutator for property audit.
     * 
     * @return audit of type AuditDetails
     */
    @XmlElement(name = "audit")
    public void setAudit(AuditIdentifier audit) {
        this.audit = audit;
    }
}
