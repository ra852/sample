////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.AccountIdentifierDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.SaveAccountResponse;

/**
 * The class {@code SaveAccountRebalanceResponseUtil} does this.
 * 
 * @author U383847
 * @since 30/03/2016
 * @version 1.0
 */
public class AccountIdentifierResponseUtil {
    private final String className = "SaveAccountRebalanceResponseUtil";

    /**
     * Get Account Identifier Details.
     * 
     * @param accountIdentifierType
     * @param saveAccountResponse
     * @throws SILException
     */
    public void getAccountIdentifierDetails(AccountIdentifierType accountIdentifier, SaveAccountResponse saveAccountResponse) throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_LOGGING_FORMAT, className, "Getting Account Identifier Details");
        String loggerType = AccountServiceConstants.SAVE_ACCOUNT_LOGGING_FORMAT;
        AccountServiceUtil accountServiceCommonUtil = new AccountServiceUtil();
        AccountIdentifierDetails accountIdentifierDetails = new AccountIdentifierDetails();
        accountIdentifierDetails.setId(accountServiceCommonUtil.retrieveLongValue(accountIdentifier.getId(), loggerType));
        accountIdentifierDetails.setName(accountIdentifier.getName());
        accountIdentifierDetails.setAccountNumber(accountServiceCommonUtil.retrieveAccountNumberDetails(accountIdentifier.getAccountNumber(),
                loggerType));
        accountIdentifierDetails.setAccountRef(accountServiceCommonUtil.retrieveExternalRef(accountIdentifier.getAccountExternalRef(), loggerType));
        accountIdentifierDetails.setStatusCode(accountServiceCommonUtil.retrieveCode(accountIdentifier.getStatusCode(), loggerType));
        accountIdentifierDetails.setAudit(accountServiceCommonUtil.retrieveAudit(accountIdentifier.getAudit(), loggerType));
        saveAccountResponse.setAccount(accountIdentifierDetails);
    }
}
