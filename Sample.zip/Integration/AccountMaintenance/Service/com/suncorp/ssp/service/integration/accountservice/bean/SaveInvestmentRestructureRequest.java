////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.suncorp.ssp.common.bean.SILErrorMessage;

/**
 * The class {@code SaveInvestmentRestructureRequest} construct's SOAP request for external service.
 * 
 * @author U387938
 * @since 20/03/2016
 * @version 1.0
 */
@XmlRootElement(name = "SaveInvestmentRestructureRequest")
public class SaveInvestmentRestructureRequest extends SILErrorMessage {

    private AccountIdentifierDetails account;
    private String doBalanceRestructure;
    private String doProfileRestructure;
    private String useSeparateAssetSplits;
    private CodeIdentifier profileMethodId;
    private String effectiveDate;
    private TransactionDetails transactionDetails;
    private List<AssetSplitsBean> balanceAssetSplit;
    private List<AssetSplitsBean> profileAssetSplit;

    /**
     * Accessor for property account.
     * 
     * @return account of type AccountIdentifierDetails
     */
    public AccountIdentifierDetails getAccount() {
        return account;
    }

    /**
     * Mutator for property account.
     * 
     * @param account of type AccountIdentifierDetails
     */
    @XmlElement(name = "account")
    public void setAccount(AccountIdentifierDetails account) {
        this.account = account;
    }

    /**
     * Accessor for property doBalanceRestructure.
     * 
     * @return doBalanceRestructure of type String
     */
    public String getDoBalanceRestructure() {
        return doBalanceRestructure;
    }

    /**
     * Mutator for property doBalanceRestructure.
     * 
     * @param doBalanceRestructure of type String
     */
    @XmlElement(name = "doBalanceRestructure")
    public void setDoBalanceRestructure(String doBalanceRestructure) {
        this.doBalanceRestructure = doBalanceRestructure;
    }

    /**
     * Accessor for property doProfileRestructure.
     * 
     * @return doProfileRestructure of type String
     */
    public String getDoProfileRestructure() {
        return doProfileRestructure;
    }

    /**
     * Mutator for property doProfileRestructure.
     * 
     * @param doProfileRestructure of type String
     */
    @XmlElement(name = "doProfileRestructure")
    public void setDoProfileRestructure(String doProfileRestructure) {
        this.doProfileRestructure = doProfileRestructure;
    }

    /**
     * Accessor for property useSeparateAssetSplits.
     * 
     * @return useSeparateAssetSplits of type String
     */
    public String getUseSeparateAssetSplits() {
        return useSeparateAssetSplits;
    }

    /**
     * Mutator for property useSeparateAssetSplits.
     * 
     * @param useSeparateAssetSplits of type String
     */
    @XmlElement(name = "useSeparateAssetSplits")
    public void setUseSeparateAssetSplits(String useSeparateAssetSplits) {
        this.useSeparateAssetSplits = useSeparateAssetSplits;
    }

    /**
     * Accessor for property profileMethodId.
     * 
     * @return profileMethodId of type CodeIdentifier
     */
    public CodeIdentifier getProfileMethodId() {
        return profileMethodId;
    }

    /**
     * Mutator for property profileMethodId.
     * 
     * @param profileMethodId of type CodeIdentifier
     */
    @XmlElement(name = "profileMethodId")
    public void setProfileMethodId(CodeIdentifier profileMethodId) {
        this.profileMethodId = profileMethodId;
    }

    /**
     * Accessor for property effectiveDate.
     * 
     * @return effectiveDate of type String
     */
    public String getEffectiveDate() {
        return effectiveDate;
    }

    /**
     * Mutator for property effectiveDate.
     * 
     * @param effectiveDate of type String
     */
    @XmlElement(name = "effectiveDate")
    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate;
    }

    /**
     * Accessor for property transactionDetails.
     * 
     * @return transactionDetails of type TransactionDetails
     */
    public TransactionDetails getTransactionDetails() {
        return transactionDetails;
    }

    /**
     * Mutator for property transactionDetails.
     * 
     * @param transactionDetails of type TransactionDetails
     */
    @XmlElement(name = "transactionDetails")
    public void setTransactionDetails(TransactionDetails transactionDetails) {
        this.transactionDetails = transactionDetails;
    }

    /**
     * Accessor for property balanceAssetSplit.
     * 
     * @return balanceAssetSplit of type List<AssetSplitsBean>
     */
    public List<AssetSplitsBean> getBalanceAssetSplit() {
        return balanceAssetSplit;
    }

    /**
     * Mutator for property balanceAssetSplit.
     * 
     * @param balanceAssetSplit of type List<AssetSplitsBean>
     */
    @XmlElement(name = "balanceAssetSplit")
    public void setBalanceAssetSplit(List<AssetSplitsBean> balanceAssetSplit) {
        this.balanceAssetSplit = balanceAssetSplit;
    }

    /**
     * Accessor for property profileAssetSplit.
     * 
     * @return profileAssetSplit of type List<AssetSplitsBean>
     */
    public List<AssetSplitsBean> getProfileAssetSplit() {
        return profileAssetSplit;
    }

    /**
     * Mutator for property profileAssetSplit.
     * 
     * @param profileAssetSplit of type List<AssetSplitsBean>
     */
    @XmlElement(name = "profileAssetSplit")
    public void setProfileAssetSplit(List<AssetSplitsBean> profileAssetSplit) {
        this.profileAssetSplit = profileAssetSplit;
    }

}
