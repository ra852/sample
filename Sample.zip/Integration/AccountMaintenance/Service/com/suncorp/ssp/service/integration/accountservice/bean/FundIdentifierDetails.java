////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code FundIdentifierDetails} does this.
 * @author U383847
 * @since 01/02/2016
 * @version 1.0
 */
public class FundIdentifierDetails {
    private String id;
    private String name;
    private String fundFullName;
    private String fundCorrespondenceName;
    private String amount;
    private String sequence;
    private ReferenceIdentifier fundExternalRef;
    private AuditIdentifier audit;
    private CodeIdentifier fundType;
    
    /**
     * Accessor for property id.
     * 
     * @return id of type String
     */
    public String getId() {
        return id;
    }
    
    /**
     * Mutator for property id.
     * 
     * @return id of type String
     */
    @XmlElement(name = "fundId")
    public void setId(String id) {
        this.id = id != null ? id : "";
    }
    
    /**
     * Accessor for property name.
     * 
     * @return name of type String
     */
    public String getName() {
        return name;
    }

    /**
     * Mutator for property name.
     * 
     * @return name of type String
     */
    @XmlElement(name = "fundName")
    public void setName(String name) {
        this.name = name != null ? name : "";
    }

    /**
     * Accessor for property fundFullName.
     * 
     * @return fundFullName of type String
     */
    public String getFundFullName() {
        return fundFullName;
    }

    /**
     * Mutator for property fundFullName.
     * 
     * @return fundFullName of type String
     */
    @XmlElement(name = "fundFullName")
    public void setFundFullName(String fundFullName) {
        this.fundFullName = fundFullName != null ? fundFullName : "";
    }

    /**
     * Accessor for property funcCorrespondenceName.
     * 
     * @return funcCorrespondenceName of type String
     */
    public String getFundCorrespondenceName() {
        return fundCorrespondenceName;
    }

    /**
     * Mutator for property funcCorrespondenceName.
     * 
     * @return funcCorrespondenceName of type String
     */
    @XmlElement(name = "fundCorrespondenceName")
    public void setFundCorrespondenceName(String fundCorrespondenceName) {
        this.fundCorrespondenceName = fundCorrespondenceName != null ? fundCorrespondenceName : "";
    }

    /**
     * Accessor for property amount.
     * 
     * @return amount of type String
     */
    @XmlElement(name = "fundAmount")
    public String getAmount() {
        return amount;
    }

    /**
     * Mutator for property amount.
     * 
     * @return amount of type String
     */
    public void setAmount(String amount) {
        this.amount = amount != null ? amount : "";
    }

    /**
     * Accessor for property sequence.
     * 
     * @return sequence of type String
     */
    @XmlElement(name = "fundSequence")
    public String getSequence() {
        return sequence;
    }

    /**
     * Mutator for property sequence.
     * @return sequence of type String
     */
    public void setSequence(String sequence) {
        this.sequence = sequence != null ? sequence : "";
    }

    /**
     * Accessor for property fundExternalRef.
     *
     * @return fundExternalRef of type ReferenceIdentifier
     */
    public ReferenceIdentifier getFundExternalRef() {
        return fundExternalRef;
    }

    /**
     * Mutator for property fundExternalRef.
     *
     * @param fundExternalRef of type ReferenceIdentifier
     */
    @XmlElement(name = "fundExternalRef")
    public void setFundExternalRef(ReferenceIdentifier fundExternalRef) {
        this.fundExternalRef = fundExternalRef;
    }

    /**
     * Accessor for property audit.
     *
     * @return audit of type AuditIdentifier
     */
    public AuditIdentifier getAudit() {
        return audit;
    }

    /**
     * Mutator for property audit.
     *
     * @param audit of type AuditIdentifier
     */
    @XmlElement(name = "audit")
    public void setAudit(AuditIdentifier audit) {
        this.audit = audit;
    }

    /**
     * Accessor for property fundType.
     *
     * @return fundType of type CodeIdentifier
     */
    public CodeIdentifier getFundType() {
        return fundType;
    }

    /**
     * Mutator for property fundType.
     *
     * @param fundType of type CodeIdentifier
     */
    @XmlElement(name = "fundType")
    public void setFundType(CodeIdentifier fundType) {
        this.fundType = fundType;
    }
    
   
}
