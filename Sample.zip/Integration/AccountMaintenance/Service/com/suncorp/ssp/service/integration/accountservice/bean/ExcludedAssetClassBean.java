////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;
/**
 * The class {@code ExcludedAssetClassBean} does this.
 * 
 * @author U387938
 * @since 02/02/2016
 * @version 1.0
 */
public class ExcludedAssetClassBean {

    private CodeIdentifier assetClass;
    private String exclude;
   
    /**
     * Accessor for property exclude.
     *
     * @return exclude of type String
     */
    public String getExclude() {
        return exclude;
    }
    /**
     * Mutator for property exclude.
     *
     * @param exclude of type String
     */
    @XmlElement(name = "exclude")
    public void setExclude(String exclude) {
        this.exclude = exclude != null ? exclude : "";
    }
    /**
     * Accessor for property assetClass.
     *
     * @return assetClass of type CodeIdentifier
     */
    public CodeIdentifier getAssetClass() {
        return assetClass;
    }
    /**
     * Mutator for property assetClass.
     *
     * @param assetClass of type CodeIdentifier
     */
    @XmlElement(name = "assetClass")
    public void setAssetClass(CodeIdentifier assetClass) {
        this.assetClass = assetClass;
    }
    
    
}
