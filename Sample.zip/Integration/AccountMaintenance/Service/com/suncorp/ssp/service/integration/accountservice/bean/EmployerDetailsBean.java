////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code EmployerDetailsBean} does this.
 *
 * @author U387938
 * @since 22/09/2016
 * @version 1.0
 */
public class EmployerDetailsBean {
    private String id;
    private String number;

    /**
     * Accessor for property id.
     *
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     *
     * @param id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id;
    }

    /**
     * Accessor for property number.
     *
     * @return number of type String
     */
    public String getNumber() {
        return number;
    }

    /**
     * Mutator for property number.
     *
     * @param number of type String
     */
    @XmlElement(name = "number")
    public void setNumber(String number) {
        this.number = number;
    }
}
