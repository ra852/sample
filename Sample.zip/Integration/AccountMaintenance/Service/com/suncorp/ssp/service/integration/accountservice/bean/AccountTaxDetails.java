////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////    
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code AccountTaxDetails} does this.
 * 
 * @author U387938
 * @since 02/02/2016
 * @version 1.0
 */
public class AccountTaxDetails {
    private CodeIdentifier taxScale;
    private String includeInvalidity;
    private String rebatableProportion;
    private String taxOffsetAmount;
    private String deductMedicareSurcharge;
    private String medicareLevyReduction;
    private String dependantSpouse;
    private String numberOfDependantChildren;

    /**
     * Accessor for property taxScale.
     * 
     * @return taxScale of type CodeIdentifier
     */
    public CodeIdentifier getTaxScale() {
        return taxScale;
    }

    /**
     * Mutator for property taxScale.
     * 
     * @param taxScale of type CodeIdentifier
     */
    @XmlElement(name = "taxScale")
    public void setTaxScale(CodeIdentifier taxScale) {
        this.taxScale = taxScale;
    }

    /**
     * Accessor for property includeInvalidity.
     * 
     * @return includeInvalidity of type String
     */
    public String getIncludeInvalidity() {
        return includeInvalidity;
    }

    /**
     * Mutator for property includeInvalidity.
     * 
     * @param includeInvalidity of type String
     */
    @XmlElement(name = "includeInvalidity")
    public void setIncludeInvalidity(String includeInvalidity) {
        this.includeInvalidity = includeInvalidity != null ? includeInvalidity : "";
    }

    /**
     * Accessor for property rebatableProportion.
     * 
     * @return rebatableProportion of type String
     */
    public String getRebatableProportion() {
        return rebatableProportion;
    }

    /**
     * Mutator for property rebatableProportion.
     * 
     * @param rebatableProportion of type String
     */
    @XmlElement(name = "rebatableProportion")
    public void setRebatableProportion(String rebatableProportion) {
        this.rebatableProportion = rebatableProportion != null ? rebatableProportion : "";
    }

    /**
     * Accessor for property taxOffsetAmount.
     * 
     * @return taxOffsetAmount of type String
     */
    public String getTaxOffsetAmount() {
        return taxOffsetAmount;
    }

    /**
     * Mutator for property taxOffsetAmount.
     * 
     * @param taxOffsetAmount of type String
     */
    @XmlElement(name = "taxOffsetAmount")
    public void setTaxOffsetAmount(String taxOffsetAmount) {
        this.taxOffsetAmount = taxOffsetAmount != null ? taxOffsetAmount : "";
    }

    /**
     * Accessor for property deductMedicareSurcharge.
     * 
     * @return deductMedicareSurcharge of type String
     */
    public String getDeductMedicareSurcharge() {
        return deductMedicareSurcharge;
    }

    /**
     * Mutator for property deductMedicareSurcharge.
     * 
     * @param deductMedicareSurcharge of type String
     */
    @XmlElement(name = "deductMedicareSurcharge")
    public void setDeductMedicareSurcharge(String deductMedicareSurcharge) {
        this.deductMedicareSurcharge = deductMedicareSurcharge != null ? deductMedicareSurcharge : "";
    }

    /**
     * Accessor for property medicareLevyReduction.
     * 
     * @return medicareLevyReduction of type String
     */
    public String getMedicareLevyReduction() {
        return medicareLevyReduction;
    }

    /**
     * Mutator for property medicareLevyReduction.
     * 
     * @param medicareLevyReduction of type String
     */
    @XmlElement(name = "medicareLevyReduction")
    public void setMedicareLevyReduction(String medicareLevyReduction) {
        this.medicareLevyReduction = medicareLevyReduction != null ? medicareLevyReduction : "";
    }

    /**
     * Accessor for property dependantSpouse.
     * 
     * @return dependantSpouse of type String
     */
    public String getDependantSpouse() {
        return dependantSpouse;
    }

    /**
     * Mutator for property dependantSpouse.
     * 
     * @param dependantSpouse of type String
     */
    @XmlElement(name = "dependantSpouse")
    public void setDependantSpouse(String dependantSpouse) {
        this.dependantSpouse = dependantSpouse != null ? dependantSpouse : "";
    }

    /**
     * Accessor for property numberOfDependantChildren.
     * 
     * @return numberOfDependantChildren of type String
     */
    public String getNumberOfDependantChildren() {
        return numberOfDependantChildren;
    }

    /**
     * Mutator for property numberOfDependantChildren.
     * 
     * @param numberOfDependantChildren of type String
     */
    @XmlElement(name = "numberOfDependantChildren")
    public void setNumberOfDependantChildren(String numberOfDependantChildren) {
        this.numberOfDependantChildren = numberOfDependantChildren != null ? numberOfDependantChildren : "";
    }
}
