////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code PagingRange} is a pure java bean consisting of properties related to GetAccountTransactionList response.
 * 
 * @author u386868
 * @since 23/12/2015
 * @version 1.0
 */
public class PagingRange {

    private int firstResult;
    private int resultsPerPage;
    private int totalResults;

    /**
     * Accessor for property firstResult.
     * 
     * @return firstResult of type int
     */
    public int getFirstResult() {
        return firstResult;
    }

    /**
     * Mutator for property firstResult.
     * 
     * @return firstResult of type int
     */
    @XmlElement(name = "firstResult")
    public void setFirstResult(int firstResult) {
        this.firstResult = firstResult;
    }

    /**
     * Accessor for property resultsPerPage.
     * 
     * @return resultsPerPage of type int
     */
    public int getResultsPerPage() {
        return resultsPerPage;
    }

    /**
     * Mutator for property resultsPerPage.
     * 
     * @return resultsPerPage of type int
     */
    @XmlElement(name = "resultsPerPage")
    public void setResultsPerPage(int resultsPerPage) {
        this.resultsPerPage = resultsPerPage;
    }

    /**
     * Accessor for property totalResults.
     * 
     * @return totalResults of type int
     */
    public int getTotalResults() {
        return totalResults;
    }

    /**
     * Mutator for property totalResults.
     * 
     * @return totalResults of type int
     */
    @XmlElement(name = "totalResults")
    public void setTotalResults(int totalResults) {
        this.totalResults = totalResults;
    }

}
