////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;
/**
 * The class {@code BankAccountIdentifierBean} does this.
 * 
 * @author U387938
 * @since 02/02/2016
 * @version 1.0
 */
public class BankAccountIdentifierBean {
    
    private String bankAccountNumber;
    private String bankAccountTypeCode;
    private CurrencyIdentifierBean bankAccountCurrencyCode;
    private AuditIdentifier audit;
    /**
     * Accessor for property bankAccountNumber.
     *
     * @return bankAccountNumber of type String
     */
    public String getBankAccountNumber() {
        return bankAccountNumber;
    }
    /**
     * Mutator for property bankAccountNumber.
     *
     * @param bankAccountNumber of type String
     */
    @XmlElement(name = "bankAccountNumber")
    public void setBankAccountNumber(String bankAccountNumber) {
        this.bankAccountNumber = bankAccountNumber != null ? bankAccountNumber : "";
    }
    /**
     * Accessor for property bankAccountTypeCode.
     *
     * @return bankAccountTypeCode of type String
     */
    public String getBankAccountTypeCode() {
        return bankAccountTypeCode;
    }
    /**
     * Mutator for property bankAccountTypeCode.
     *
     * @param bankAccountTypeCode of type String
     */
    @XmlElement(name = "bankAccountTypeCode")
    public void setBankAccountTypeCode(String bankAccountTypeCode) {
        this.bankAccountTypeCode = bankAccountTypeCode != null ? bankAccountTypeCode : "";
    }
   
    /**
     * Accessor for property bankAccountCurrencyCode.
     *
     * @return bankAccountCurrencyCode of type CurrencyIdentifierBean
     */
    public CurrencyIdentifierBean getBankAccountCurrencyCode() {
        return bankAccountCurrencyCode;
    }
    /**
     * Mutator for property bankAccountCurrencyCode.
     *
     * @param bankAccountCurrencyCode of type CurrencyIdentifierBean
     */
    @XmlElement(name = "bankAccountCurrencyCode")
    public void setBankAccountCurrencyCode(CurrencyIdentifierBean bankAccountCurrencyCode) {
        this.bankAccountCurrencyCode = bankAccountCurrencyCode;
    }
    /**
     * Accessor for property audit.
     *
     * @return audit of type AuditIdentifier
     */
    public AuditIdentifier getAudit() {
        return audit;
    }
    /**
     * Mutator for property audit.
     *
     * @param audit of type AuditIdentifier
     */
    @XmlElement(name = "audit")
    public void setAudit(AuditIdentifier audit) {
        this.audit = audit;
    }
    
    
}
