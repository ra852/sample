////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
/**
 * The class {@code ClientAccountRelationshipBean} does this.
 * 
 * @author U387938
 * @since 02/02/2016
 * @version 1.0
 */
public class ClientAccountRelationshipBean {
    private ClientAccountRelationshipIdentifierBean clientAccountRelationship;
    private String isPrimary;
    private String dateJoined;
    private String endDate;
    private BankAccountIdentifierBean bankaccount;
    private List<DirectDebitAuthorityBean> directDebitAuthorities;
    /**
     * Accessor for property clientAccountRelationship.
     *
     * @return clientAccountRelationship of type ClientAccountRelationshipIdentifierBean
     */
    public ClientAccountRelationshipIdentifierBean getClientAccountRelationship() {
        return clientAccountRelationship;
    }
    /**
     * Mutator for property clientAccountRelationship.
     *
     * @param clientAccountRelationship of type ClientAccountRelationshipIdentifierBean
     */
    @XmlElement(name = "clientAccountRelationship")
    public void setClientAccountRelationship(ClientAccountRelationshipIdentifierBean clientAccountRelationship) {
        this.clientAccountRelationship = clientAccountRelationship;
    }
    /**
     * Accessor for property isPrimary.
     *
     * @return isPrimary of type String
     */
    public String getIsPrimary() {
        return isPrimary;
    }
    /**
     * Mutator for property isPrimary.
     *
     * @param isPrimary of type String
     */
    @XmlElement(name = "isPrimary")
    public void setIsPrimary(String isPrimary) {
        this.isPrimary = isPrimary != null ? isPrimary : "";
    }
    /**
     * Accessor for property dateJoined.
     *
     * @return dateJoined of type String
     */
    public String getDateJoined() {
        return dateJoined;
    }
    /**
     * Mutator for property dateJoined.
     *
     * @param dateJoined of type String
     */
    @XmlElement(name = "dateJoined")
    public void setDateJoined(String dateJoined) {
        this.dateJoined = dateJoined != null ? dateJoined : "";
    }
    /**
     * Accessor for property endDate.
     *
     * @return endDate of type String
     */
    public String getEndDate() {
        return endDate;
    }
    /**
     * Mutator for property endDate.
     *
     * @param endDate of type String
     */
    @XmlElement(name = "endDate")
    public void setEndDate(String endDate) {
        this.endDate = endDate != null ? endDate : "";
    }
    /**
     * Accessor for property bankaccount.
     *
     * @return bankaccount of type BankAccountIdentifierBean
     */
    public BankAccountIdentifierBean getBankaccount() {
        return bankaccount;
    }
    /**
     * Mutator for property bankaccount.
     *
     * @param bankaccount of type BankAccountIdentifierBean
     */
    @XmlElement(name = "bankaccount")
    public void setBankaccount(BankAccountIdentifierBean bankaccount) {
        this.bankaccount = bankaccount;
    }
    /**
     * Accessor for property directDebitAuthorities.
     *
     * @return directDebitAuthorities of type List<DirectDebitAuthorityBean>
     */
    public List<DirectDebitAuthorityBean> getDirectDebitAuthorities() {
        return directDebitAuthorities;
    }
    /**
     * Mutator for property directDebitAuthorities.
     *
     * @param directDebitAuthorities of type List<DirectDebitAuthorityBean>
     */
    @XmlElement(name = "directDebitAuthorities")
    public void setDirectDebitAuthorities(List<DirectDebitAuthorityBean> directDebitAuthorities) {
        this.directDebitAuthorities = directDebitAuthorities;
    }
   
    
    
}
