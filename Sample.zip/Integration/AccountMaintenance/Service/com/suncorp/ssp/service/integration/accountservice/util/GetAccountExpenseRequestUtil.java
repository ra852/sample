////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import javax.ws.rs.core.MultivaluedMap;

import com.sonatacentral.service.v30.callerdetails.CallerDetails;
import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.AdvisorIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.marketing.marketinggrouptype.MarketingCampaignIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType.AccountNumber;
import com.sonatacentral.service.v30.globaltypes.wrap.product.productgrouptype.ProductIdentifierType;
import com.sonatacentral.service.v30.wrap.account.GetAccountExpenseRequestType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;

/**
 * The class {@code GetAccountExpenseRequestUtil} is a util class to create request for Get Account Expense.
 * 
 * @author u385424
 * @since 21/04/2016
 * @version 1.0
 */
public class GetAccountExpenseRequestUtil {
    private String className = "GetAccountExpenseRequestUtil";
    private GetAccountExpenseRequestType outboundRequest;
    private MultivaluedMap<String, String> inboundRequest;
    private String isAccountNumberRequest = "false";

    /**
     * Does this.
     * 
     * @param inboundRequest
     */
    public GetAccountExpenseRequestUtil(MultivaluedMap<String, String> inboundRequest) {
        this.inboundRequest = inboundRequest;
        this.outboundRequest = new GetAccountExpenseRequestType();
    }

    /**
     * This method is use to create outbounf request.
     * 
     * @return outboundRequest
     * @throws SILException
     */
    public GetAccountExpenseRequestType createOutboundRequest() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in createOutboundRequest()");
        CallerDetails callerDetails = SILUtil.createCallerDetails();
        outboundRequest.setCallerDetails(callerDetails);
        createRequestForAccountExpense();
        createRequestForExpenseLineWithAccountNumber();
        return outboundRequest;
    }

    /**
     * This method is use to create outbound request.
     * 
     * @throws SILException
     */
    private void createRequestForAccountExpense() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in createRequestForAccountExpense()");
        if (inboundRequest.containsKey(AccountServiceConstants.ADVISOR_PRODUCT_ID) &&
                inboundRequest.get(AccountServiceConstants.ADVISOR_PRODUCT_ID).get(0) != null) {
            outboundRequest.setAdvisor(constructAdvisorIdentifier(inboundRequest));
        }
        if (inboundRequest.containsKey(AccountServiceConstants.PRODUCT_NAME) &&
                inboundRequest.get(AccountServiceConstants.PRODUCT_NAME).get(0) != null) {
            outboundRequest.setProduct(constructProductIdentifier(inboundRequest));
        }
        if (inboundRequest.containsKey(AccountServiceConstants.MARKETING_CAMPAIGN_ID) &&
                inboundRequest.get(AccountServiceConstants.MARKETING_CAMPAIGN_ID).get(0) != null) {
            outboundRequest.setMarketingCampaign(constructMarketingCampaignIdentifier(inboundRequest));
        }
    }

    /**
     * This method is use to set account Number in request.
     * 
     */
    private void createRequestForExpenseLineWithAccountNumber() {
        if (inboundRequest.containsKey(AccountServiceConstants.ACCOUNT_NO) && inboundRequest.get(AccountServiceConstants.ACCOUNT_NO).get(0) != null) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className,
                    "Entering in createRequestForExpenseLineWithAccountNumber()");
            outboundRequest.setAccount(constructAccountNumber(inboundRequest));
        }
    }

    /**
     * This method is used to set accountNo.
     * 
     * @param inboundRequest
     * @return
     */
    private AccountIdentifierType constructAccountNumber(MultivaluedMap<String, String> inboundRequest) {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in constructAccountNumber()");
        AccountIdentifierType accountIdentifierType = new AccountIdentifierType();
        accountIdentifierType.setAccountNumber(retrieveAccountNumber(inboundRequest));
        return accountIdentifierType;
    }

    /**
     * Set AccountNumber details to the external service request object.
     * 
     * @param inboundRequest of type MultivaluedMap<String, String>
     * @return accountNumber of type AccountNumber.
     */
    private AccountNumber retrieveAccountNumber(MultivaluedMap<String, String> inboundRequest) {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in retrieveAccountNumber method.");
        AccountNumber accountNumber = new AccountNumber();
        accountNumber.setAccountNo(inboundRequest.get(AccountServiceConstants.ACCOUNT_NO).get(0));
        this.setIsAccountNumberRequest(AccountServiceConstants.IS_ACCOUNT_NUMBER_REQUEST_TRUE);
        return accountNumber;
    }

    /**
     * This method is used to construct advisor identifier.
     * 
     * @param inboundRequest
     * 
     * @return the object of type {@code AdvisorIdentifierType}
     * @throws SILException
     */
    private AdvisorIdentifierType constructAdvisorIdentifier(MultivaluedMap<String, String> inboundRequest) throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in constructAdvisorIdentifier method.");
        AdvisorIdentifierType advisorIdentifierType = new AdvisorIdentifierType();
        advisorIdentifierType.setClientId(Long.parseLong(inboundRequest.get(AccountServiceConstants.ADVISOR_PRODUCT_ID).get(0)));
        return advisorIdentifierType;
    }

    /**
     * This method is used to construct product identifier.
     * 
     * @return the object of {@code ProductIdentifierType}
     * @throws SILException
     */
    private ProductIdentifierType constructProductIdentifier(MultivaluedMap<String, String> inboundRequest) throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in constructProductIdentifier()");
        ProductIdentifierType productIdentifierType = new ProductIdentifierType();
        productIdentifierType.setName(inboundRequest.get(AccountServiceConstants.PRODUCT_NAME).get(0));
        return productIdentifierType;
    }

    /**
     * This method is used to construct marketing campaign.
     * 
     * @return the object of {@code MarketingCampaignIdentifierType}
     * @throws SILException
     */
    private MarketingCampaignIdentifierType constructMarketingCampaignIdentifier(MultivaluedMap<String, String> inboundRequest) throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_EXPENSE_LOGGING_FORMAT, className, "Entering in constructMarketingCampaignIdentifier()");
        MarketingCampaignIdentifierType marketingCampaignIdentifierType = new MarketingCampaignIdentifierType();
        marketingCampaignIdentifierType.setId(Long.parseLong(inboundRequest.get(AccountServiceConstants.MARKETING_CAMPAIGN_ID).get(0)));
        return marketingCampaignIdentifierType;
    }

    /**
     * Accessor for property isAccountNumberRequest.
     * 
     * @return isAccountNumberRequest of type String
     */
    public String getIsAccountNumberRequest() {
        return isAccountNumberRequest;
    }

    /**
     * Mutator for property isAccountNumberRequest.
     * 
     * @param isAccountNumberRequest of type String
     */
    public void setIsAccountNumberRequest(String isAccountNumberRequest) {
        this.isAccountNumberRequest = isAccountNumberRequest;
    }
}
