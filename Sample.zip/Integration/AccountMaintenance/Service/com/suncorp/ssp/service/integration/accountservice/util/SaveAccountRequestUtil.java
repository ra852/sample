////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import java.util.List;

import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.NoteCategoryIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.NoteTemplateIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.NoteType;
import com.sonatacentral.service.v30.globaltypes.life.policy.policygrouptype.RiderTemplateIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountEntityType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountEntityType.AccountDetail;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.DefaultInsuranceStatusType;
import com.sonatacentral.service.v30.wrap.account.SaveAccountRequestType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.AccountDetailBean;
import com.suncorp.ssp.service.integration.accountservice.bean.DefaultInsuranceStatusDetail;
import com.suncorp.ssp.service.integration.accountservice.bean.NoteBean;
import com.suncorp.ssp.service.integration.accountservice.bean.NoteTemplateBean;
import com.suncorp.ssp.service.integration.accountservice.bean.RiderTemplate;
import com.suncorp.ssp.service.integration.accountservice.bean.SaveAccountDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.SaveAccountRequest;

/**
 * The class {@code SaveAccountRequestUtil} does this.
 * 
 * @author U383847
 * @since 29/03/2016
 * @version 1.0
 */
public class SaveAccountRequestUtil {
    private final String className = "SaveAccountRequestUtil";
    private SaveAccountRequest saveAccountRequest = null;

    /**
     * Parameterized constructor for properties initialization.
     * 
     * @param saveAccountRequest of type SaveAccountRequest
     */
    public SaveAccountRequestUtil(SaveAccountRequest saveAccountRequest) {
        this.saveAccountRequest = saveAccountRequest;
    }

    /**
     * Set Account Request Details.
     * 
     * @param saveAccountRequestType
     * @throws SILException
     */
    public void setAccountRequestDetails(SaveAccountRequestType saveAccountRequestType) throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_LOGGING_FORMAT, className, "Setting Account Request Details");
        if (saveAccountRequest.getAccount() != null) {
            AccountEntityType accountEntityType = new AccountEntityType();
            SaveAccountDetails saveAccountDetails = saveAccountRequest.getAccount();
            setAccountRequestAdditionalDetails(accountEntityType, saveAccountDetails);
            saveAccountRequestType.setAccount(accountEntityType);
        }
    }

    /**
     * Set Account Request Additional Details.
     *
     * @param accountEntityType
     * @param saveAccountDetails
     * @throws SILException
     */
    private void setAccountRequestAdditionalDetails(AccountEntityType accountEntityType, SaveAccountDetails saveAccountDetails) throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_LOGGING_FORMAT, className, "Setting Account Request Additional Details");
        if (saveAccountDetails.getGenericVariable() != null) {
            this.saveAccountGenericVariable(accountEntityType);
        }
        if (saveAccountDetails.getNotes() != null && saveAccountDetails.getNotes().size() > 0) {
            this.saveAccountNotes(accountEntityType);
        }
        if (saveAccountDetails.getAccountNumber() != null && saveAccountDetails.getAccountNumber().getAccountNo() != null) {
            this.setAccountNumberDetails(saveAccountDetails, accountEntityType);
        }
        if (saveAccountDetails.getAccountDetail() != null) {
            this.setAccountDetails(saveAccountDetails.getAccountDetail(), accountEntityType);
        }
        this.setDefaultInsuranceStatus(accountEntityType, saveAccountDetails);
    }

    /**
     * This method is used to set default insurance details.
     * 
     * @param accountEntityType
     * @param saveAccountDetails
     */
    private void setDefaultInsuranceStatus(AccountEntityType accountEntityType, SaveAccountDetails saveAccountDetails) {
        if (saveAccountDetails.getMrrFlag() != null && saveAccountDetails.getAccountDetail() != null &&
                saveAccountDetails.getAccountDetail().getDefaultInsuranceStatus() != null &&
                saveAccountDetails.getAccountDetail().getDefaultInsuranceStatus().size() > 0) {
            SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_LOGGING_FORMAT, className, "Setting DefaultInsuranceStatus");
            AccountDetail accountDetial = new AccountDetail();
            List<DefaultInsuranceStatusType> outboundList = accountDetial.getDefaultInsuranceStatus();
            for (DefaultInsuranceStatusDetail status : saveAccountDetails.getAccountDetail().getDefaultInsuranceStatus()) {
                if (status != null) {
                    retrieveDefaultInsurance(outboundList, status);
                }
            }
            accountEntityType.setAccountDetail(accountDetial);
        }
    }

    /**
     * This method is used to retrieve default insurance status.
     * 
     * @param outboundList
     * @param status
     */
    private void retrieveDefaultInsurance(List<DefaultInsuranceStatusType> outboundList, DefaultInsuranceStatusDetail status) {
        SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_LOGGING_FORMAT, className, "Entering retrieveDefaultInsurance");
        DefaultInsuranceStatusType defaultInsuranceStatusType = new DefaultInsuranceStatusType();
        if (status.getOptOut() != null) {
            defaultInsuranceStatusType.setOptOut(Boolean.parseBoolean(status.getOptOut()));
        }
        if (status.getRiderTemplate() != null) {
            defaultInsuranceStatusType.setRiderTemplate(retrieveRiderTemplate(status.getRiderTemplate()));
        }
        outboundList.add(defaultInsuranceStatusType);
    }

    /**
     * This method is used to retrieve rider template.
     * 
     * @param riderTemplate
     * 
     * @return riderTemplateIdentifierType
     */
    private RiderTemplateIdentifierType retrieveRiderTemplate(RiderTemplate riderTemplate) {
        SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_LOGGING_FORMAT, className, "Entering retrieveRiderTemplate");
        RiderTemplateIdentifierType riderTemplateIdentifierType = new RiderTemplateIdentifierType();
        if (riderTemplate.getName() != null) {
            riderTemplateIdentifierType.setName(riderTemplate.getName());
        }
        return riderTemplateIdentifierType;
    }

    /**
     * Save Account Generic Variable Details.
     * 
     * @param accountEntityType
     * @throws SILException
     */
    private void saveAccountGenericVariable(AccountEntityType accountEntityType) throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_LOGGING_FORMAT, className, "Saving Account Generic Variable Details");
        SaveAccountGenericVariableRequestUtil saveAccountGenericVariableRequestUtil = new SaveAccountGenericVariableRequestUtil();
        saveAccountGenericVariableRequestUtil.setAccountGenericVariableDetails(saveAccountRequest.getAccount().getGenericVariable(),
                accountEntityType);
    }

    /**
     * Set Account Number Details.
     * 
     * @param saveAccountDetails
     * @param accountEntityType
     */
    private void setAccountNumberDetails(SaveAccountDetails saveAccountDetails, AccountEntityType accountEntityType) {
        SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_LOGGING_FORMAT, className, "Setting Account Number Details");
        AccountIdentifierType accountIdentifierType = new AccountIdentifierType();
        AccountIdentifierType.AccountNumber accountNumber = new AccountIdentifierType.AccountNumber();
        accountNumber.setAccountNo(saveAccountDetails.getAccountNumber().getAccountNo());
        accountIdentifierType.setAccountNumber(accountNumber);
        accountEntityType.setAccount(accountIdentifierType);
    }

    /**
     * Save Account Notes.
     * 
     * @param accountEntityType
     * @throws SILException
     */
    private void saveAccountNotes(AccountEntityType accountEntityType) throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_LOGGING_FORMAT, className, "Entering saveAccountNotes()");
        List<NoteType> noteList = accountEntityType.getNote();
        for (NoteBean noteBean : this.saveAccountRequest.getAccount().getNotes()) {
            NoteType noteType = new NoteType();
            if (noteBean.getNoteTemplate() != null) {
                noteType.setNoteTemplate(createNoteTemplateIdentifierType(noteBean.getNoteTemplate()));
            }
            if (noteBean.getNote() != null) {
                noteType.setNote(noteBean.getNote());
            }
            noteList.add(noteType);
        }
        SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_LOGGING_FORMAT, className, "Exiting saveAccountNotes()");
    }

    /**
     * Return a new instance of NoteTemplateIdentifierType, with necessary values set.
     * 
     * @param noteTemplateBean of type NoteTemplateBean
     * @return noteTemplateIdentifierType of type NoteTemplateIdentifierType
     */
    private NoteTemplateIdentifierType createNoteTemplateIdentifierType(NoteTemplateBean noteTemplateBean) {
        SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_LOGGING_FORMAT, className, "Entering createNoteTemplateIdentifierType()");
        NoteTemplateIdentifierType noteTemplateIdentifierType = new NoteTemplateIdentifierType();
        if (noteTemplateBean.getCode() != null) {
            noteTemplateIdentifierType.setCode(noteTemplateBean.getCode());
        }
        if (noteTemplateBean.getNoteCategory() != null) {
            NoteCategoryIdentifierType noteCategoryIdentifierType = new NoteCategoryIdentifierType();
            noteCategoryIdentifierType.setCode(noteTemplateBean.getNoteCategory().getCode());
            noteTemplateIdentifierType.setNoteCategory(noteCategoryIdentifierType);
        }
        SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_LOGGING_FORMAT, className, "Exiting createNoteTemplateIdentifierType()");
        return noteTemplateIdentifierType;
    }

    private void setAccountDetails(AccountDetailBean accountDetailBean, AccountEntityType accountEntityType) throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_LOGGING_FORMAT, className, "Setting Account Details");
        if (accountDetailBean.getIncludeInRebalancing() != null) {
            SaveAccountRebalanceRequestUtil saveAccountRebalanceUtil = new SaveAccountRebalanceRequestUtil();
            saveAccountRebalanceUtil.setAccountRebalanceDetails(saveAccountRequest.getAccount(), accountEntityType);
        }
    }
}
