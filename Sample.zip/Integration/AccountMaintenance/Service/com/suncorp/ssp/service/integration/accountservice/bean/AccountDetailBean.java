////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code AccountDetailBean} does this.
 * 
 * @author U387938
 * @since 02/02/2016
 * @version 1.0
 */
public class AccountDetailBean {

    private String commencementDate;
    private String accountDesignation;
    private String dateJoinedParticipant;
    private String eligibleServiceDate;
    private String preventWithdrawal;
    private String staff;
    private String allOwnersToSign;
    private IncludeInRebalancingBean includeInRebalancing;
    private DollarCostAveragingBean dollarCostAveraging;
    private CodeIdentifier statusCode;
    private CodeIdentifier adaStatusCode;
    private CodeIdentifier openReason;
    private List<DefaultInsuranceStatusDetail> defaultInsuranceStatus;

    /**
     * Accessor for property commencementDate.
     * 
     * @return commencementDate of type String
     */
    public String getCommencementDate() {
        return commencementDate;
    }

    /**
     * Mutator for property commencementDate.
     * 
     * @param commencementDate of type String
     */
    @XmlElement(name = "commencementDate")
    public void setCommencementDate(String commencementDate) {
        this.commencementDate = commencementDate != null ? commencementDate : "";
    }

    /**
     * Accessor for property accountDesignation.
     * 
     * @return accountDesignation of type String
     */
    public String getAccountDesignation() {
        return accountDesignation;
    }

    /**
     * Mutator for property accountDesignation.
     * 
     * @param accountDesignation of type String
     */
    @XmlElement(name = "accountDesignation")
    public void setAccountDesignation(String accountDesignation) {
        this.accountDesignation = accountDesignation != null ? accountDesignation : "";
    }

    /**
     * Accessor for property dateJoinedParticipant.
     * 
     * @return dateJoinedParticipant of type String
     */
    public String getDateJoinedParticipant() {
        return dateJoinedParticipant;
    }

    /**
     * Mutator for property dateJoinedParticipant.
     * 
     * @param dateJoinedParticipant of type String
     */
    @XmlElement(name = "dateJoinedParticipant")
    public void setDateJoinedParticipant(String dateJoinedParticipant) {
        this.dateJoinedParticipant = dateJoinedParticipant != null ? dateJoinedParticipant : "";
    }

    /**
     * Accessor for property eligibleServiceDate.
     * 
     * @return eligibleServiceDate of type String
     */
    public String getEligibleServiceDate() {
        return eligibleServiceDate;
    }

    /**
     * Mutator for property eligibleServiceDate.
     * 
     * @param eligibleServiceDate of type String
     */
    @XmlElement(name = "eligibleServiceDate")
    public void setEligibleServiceDate(String eligibleServiceDate) {
        this.eligibleServiceDate = eligibleServiceDate != null ? eligibleServiceDate : "";
    }

    /**
     * Accessor for property preventWithdrawal.
     * 
     * @return preventWithdrawal of type String
     */
    public String getPreventWithdrawal() {
        return preventWithdrawal;
    }

    /**
     * Mutator for property preventWithdrawal.
     * 
     * @param preventWithdrawal of type String
     */
    @XmlElement(name = "preventWithdrawal")
    public void setPreventWithdrawal(String preventWithdrawal) {
        this.preventWithdrawal = preventWithdrawal != null ? preventWithdrawal : "";
    }

    /**
     * Accessor for property staff.
     * 
     * @return staff of type String
     */
    public String getStaff() {
        return staff;
    }

    /**
     * Mutator for property staff.
     * 
     * @param staff of type String
     */
    @XmlElement(name = "staff")
    public void setStaff(String staff) {
        this.staff = staff != null ? staff : "";
    }

    /**
     * Accessor for property allOwnersToSign.
     * 
     * @return allOwnersToSign of type String
     */
    public String getAllOwnersToSign() {
        return allOwnersToSign;
    }

    /**
     * Mutator for property allOwnersToSign.
     * 
     * @param allOwnersToSign of type String
     */
    @XmlElement(name = "allOwnersToSign")
    public void setAllOwnersToSign(String allOwnersToSign) {
        this.allOwnersToSign = allOwnersToSign != null ? allOwnersToSign : "";
    }

    /**
     * Accessor for property includeInRebalancing.
     * 
     * @return includeInRebalancing of type IncludeInRebalancingBean
     */
    public IncludeInRebalancingBean getIncludeInRebalancing() {
        return includeInRebalancing;
    }

    /**
     * Mutator for property includeInRebalancing.
     * 
     * @param includeInRebalancing of type IncludeInRebalancingBean
     */
    @XmlElement(name = "includeInRebalancing")
    public void setIncludeInRebalancing(IncludeInRebalancingBean includeInRebalancing) {
        this.includeInRebalancing = includeInRebalancing;
    }

    /**
     * Accessor for property statusCode.
     * 
     * @return statusCode of type CodeIdentifier
     */
    public CodeIdentifier getStatusCode() {
        return statusCode;
    }

    /**
     * Mutator for property statusCode.
     * 
     * @param statusCode of type CodeIdentifier
     */
    @XmlElement(name = "statusCode")
    public void setStatusCode(CodeIdentifier statusCode) {
        this.statusCode = statusCode;
    }

    /**
     * Accessor for property adaStatusCode.
     * 
     * @return adaStatusCode of type CodeIdentifier
     */
    public CodeIdentifier getAdaStatusCode() {
        return adaStatusCode;
    }

    /**
     * Mutator for property adaStatusCode.
     * 
     * @param adaStatusCode of type CodeIdentifier
     */
    @XmlElement(name = "adaStatusCode")
    public void setAdaStatusCode(CodeIdentifier adaStatusCode) {
        this.adaStatusCode = adaStatusCode;
    }

    /**
     * Accessor for property dollarCostAveraging.
     * 
     * @return dollarCostAveraging of type DollarCostAveragingBean
     */
    public DollarCostAveragingBean getDollarCostAveraging() {
        return dollarCostAveraging;
    }

    /**
     * Mutator for property dollarCostAveraging.
     * 
     * @param dollarCostAveraging of type DollarCostAveragingBean
     */
    @XmlElement(name = "dollarCostAveraging")
    public void setDollarCostAveraging(DollarCostAveragingBean dollarCostAveraging) {
        this.dollarCostAveraging = dollarCostAveraging;
    }

    /**
     * Accessor for property openReason.
     * 
     * @return openReason of type CodeIdentifier
     */
    public CodeIdentifier getOpenReason() {
        return openReason;
    }

    /**
     * Mutator for property openReason.
     * 
     * @param openReason of type CodeIdentifier
     */
    @XmlElement(name = "openReason")
    public void setOpenReason(CodeIdentifier openReason) {
        this.openReason = openReason;
    }

    /**
     * Accessor for property defaultInsuranceStatus.
     * 
     * @return defaultInsuranceStatus of type List<DefaultInsuranceStatusDetails>
     */
    public List<DefaultInsuranceStatusDetail> getDefaultInsuranceStatus() {
        return defaultInsuranceStatus;
    }

    /**
     * Mutator for property defaultInsuranceStatus.
     * 
     * @param defaultInsuranceStatus of type List<DefaultInsuranceStatusDetails>
     */
    @XmlElement(name = "defaultInsuranceStatus")
    public void setDefaultInsuranceStatus(List<DefaultInsuranceStatusDetail> defaultInsuranceStatus) {
        this.defaultInsuranceStatus = defaultInsuranceStatus;
    }

}
