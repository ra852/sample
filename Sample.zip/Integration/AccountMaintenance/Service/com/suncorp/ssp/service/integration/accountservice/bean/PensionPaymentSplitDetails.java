////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code PensionPaymentSplitDetails} does this.
 * 
 * @author U387938
 * @since 02/02/2016
 * @version 1.0
 */
public class PensionPaymentSplitDetails {
    private String id;
    private String effectiveDate;
    private ClientBean client;
    private String fixedAmount;
    private String defaultPayee;
    private PaymentIdentifier paymentSplit;
    private CodeIdentifier paymentMethodCode;
    private String bankAccountCardNumber;
    private AccountIdentifierDetails reinvestToAccount;

    /**
     * Accessor for property id.
     * 
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     * 
     * @param id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id != null ? id : "";
    }

    /**
     * Accessor for property effectiveDate.
     * 
     * @return effectiveDate of type String
     */
    public String getEffectiveDate() {
        return effectiveDate;
    }

    /**
     * Mutator for property effectiveDate.
     * 
     * @param effectiveDate of type String
     */
    @XmlElement(name = "effectiveDate")
    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate != null ? effectiveDate : "";
    }

    /**
     * Accessor for property client.
     * 
     * @return client of type ClientBean
     */
    public ClientBean getClient() {
        return client;
    }

    /**
     * Mutator for property client.
     * 
     * @param client of type ClientBean
     */
    @XmlElement(name = "client")
    public void setClient(ClientBean client) {
        this.client = client;
    }

    /**
     * Accessor for property fixedAmount.
     * 
     * @return fixedAmount of type String
     */
    public String getFixedAmount() {
        return fixedAmount;
    }

    /**
     * Mutator for property fixedAmount.
     * 
     * @param fixedAmount of type String
     */
    @XmlElement(name = "fixedAmount")
    public void setFixedAmount(String fixedAmount) {
        this.fixedAmount = fixedAmount != null ? fixedAmount : "";
    }

    /**
     * Accessor for property defaultPayee.
     * 
     * @return defaultPayee of type String
     */
    public String getDefaultPayee() {
        return defaultPayee;
    }

    /**
     * Mutator for property defaultPayee.
     * 
     * @param defaultPayee of type String
     */
    @XmlElement(name = "defaultPayee")
    public void setDefaultPayee(String defaultPayee) {
        this.defaultPayee = defaultPayee != null ? defaultPayee : "";
    }

    /**
     * Accessor for property paymentSplit.
     * 
     * @return paymentSplit of type PaymentIdentifier
     */
    public PaymentIdentifier getPaymentSplit() {
        return paymentSplit;
    }

    /**
     * Mutator for property paymentSplit.
     * 
     * @param paymentSplit of type PaymentIdentifier
     */
    @XmlElement(name = "paymentSplit")
    public void setPaymentSplit(PaymentIdentifier paymentSplit) {
        this.paymentSplit = paymentSplit;
    }

    /**
     * Accessor for property paymentMethodCode.
     * 
     * @return paymentMethodCode of type CodeIdentifier
     */
    public CodeIdentifier getPaymentMethodCode() {
        return paymentMethodCode;
    }

    /**
     * Mutator for property paymentMethodCode.
     * 
     * @param paymentMethodCode of type CodeIdentifier
     */
    @XmlElement(name = "paymentMethodCode")
    public void setPaymentMethodCode(CodeIdentifier paymentMethodCode) {
        this.paymentMethodCode = paymentMethodCode;
    }

    /**
     * Accessor for property bankAccountCardNumber.
     * 
     * @return bankAccountCardNumber of type String
     */
    public String getBankAccountCardNumber() {
        return bankAccountCardNumber;
    }

    /**
     * Mutator for property bankAccountCardNumber.
     * 
     * @param bankAccountCardNumber of type String
     */
    @XmlElement(name = "bankAccountCardNumber")
    public void setBankAccountCardNumber(String bankAccountCardNumber) {
        this.bankAccountCardNumber = bankAccountCardNumber != null ? bankAccountCardNumber : "";
    }

    /**
     * Accessor for property reinvestToAccount.
     * 
     * @return reinvestToAccount of type AccountIdentifierDetails
     */
    public AccountIdentifierDetails getReinvestToAccount() {
        return reinvestToAccount;
    }

    /**
     * Mutator for property reinvestToAccount.
     * 
     * @param reinvestToAccount of type AccountIdentifierDetails
     */
    @XmlElement(name = "reinvestToAccount")
    public void setReinvestToAccount(AccountIdentifierDetails reinvestToAccount) {
        this.reinvestToAccount = reinvestToAccount;
    }
}
