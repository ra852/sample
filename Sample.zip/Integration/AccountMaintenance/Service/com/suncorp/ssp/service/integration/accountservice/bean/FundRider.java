////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code ExpenseParameterDetails} does this.
 * 
 * @author U3837938
 * @since 02/02/2016
 * @version 1.0
 */
public class FundRider {
    
    private String longName;
    private CodeIdentifier systemCode;
    /**
     * Accessor for property longName.
     *
     * @return longName of type String
     */
    public String getLongName() {
        return longName;
    }
    /**
     * Mutator for property longName.
     *
     * @param longName of type String
     */
    @XmlElement(name = "longName")
    public void setLongName(String longName) {
        this.longName = longName != null ? longName : "";
    }
    /**
     * Accessor for property systemCode.
     *
     * @return systemCode of type CodeIdentifier
     */
    public CodeIdentifier getSystemCode() {
        return systemCode;
    }
    /**
     * Mutator for property systemCode.
     *
     * @param systemCode of type CodeIdentifier
     */
    @XmlElement(name = "systemCode")
    public void setSystemCode(CodeIdentifier systemCode) {
        this.systemCode = systemCode;
    }
    
    

}
