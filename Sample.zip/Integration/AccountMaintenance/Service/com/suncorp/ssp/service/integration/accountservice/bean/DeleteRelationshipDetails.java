////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code DeleteRelationshipDetails} is a bean class consisting of account and relationship details.
 * 
 * @author u385424
 * @since 17/03/2016
 * @version 1.0
 */
public class DeleteRelationshipDetails {

    private AccountDetails account;
    private List<ClientAccountRelationshipIdentifierBean> relationship;

    /**
     * Accessor for property account.
     * 
     * @return account of type AccountDetails
     */
    public AccountDetails getAccount() {
        return account;
    }

    /**
     * Mutator for property account.
     * 
     * @param account of type AccountDetails
     */
    @XmlElement(name = "account")
    public void setAccount(AccountDetails account) {
        this.account = account;
    }

    /**
     * Accessor for property relationship.
     * 
     * @return relationship of type List<ClientAccountRelationshipIdentifierBean>
     */
    public List<ClientAccountRelationshipIdentifierBean> getRelationship() {
        return relationship;
    }

    /**
     * Mutator for property relationship.
     * 
     * @param relationship of type List<ClientAccountRelationshipIdentifierBean>
     */
    @XmlElement(name = "relationship")
    public void setRelationship(List<ClientAccountRelationshipIdentifierBean> relationship) {
        this.relationship = relationship;
    }

}
