////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code InvestmentProfileDetails} does this.
 * 
 * @author U383847
 * @since 28/01/2016
 * @version 1.0
 */
public class InvestmentProfileDetails {
    private AccountProfileLinkDetails accountProfileLinkDetails;
    private ProfileFunctionDetails profileFunctionDetails;
    private ProfileDetails profileDetails;
    private String sameAsDefaultInvestmentProfile;
    private CodeIdentifier patternMethod;
    private CodeIdentifier overrideCode;
    private String totalAmount;
    private String clearAllFunds;
    private List<FundDetails> fundDetails;
    private String deleteFlag;

    /**
     * Accessor for property accountProfileLinkDetails.
     * 
     * @return accountProfileLinkDetails of type AccountProfileLinkDetails
     */
    public AccountProfileLinkDetails getAccountProfileLinkDetails() {
        return accountProfileLinkDetails;
    }

    /**
     * Mutator for property accountProfileLinkDetails.
     * 
     * @param accountProfileLinkDetails of type AccountProfileLinkDetails
     */
    @XmlElement(name = "accountProfileLinkDetails")
    public void setAccountProfileLinkDetails(AccountProfileLinkDetails accountProfileLinkDetails) {
        this.accountProfileLinkDetails = accountProfileLinkDetails;
    }

    /**
     * Accessor for property profileFunctionDetails.
     * 
     * @return profileFunctionDetails of type ProfileFunctionDetails
     */
    public ProfileFunctionDetails getProfileFunctionDetails() {
        return profileFunctionDetails;
    }

    /**
     * Mutator for property profileFunctionDetails.
     * 
     * @param profileFunctionDetails of type ProfileFunctionDetails
     */
    @XmlElement(name = "profileFunctionDetails")
    public void setProfileFunctionDetails(ProfileFunctionDetails profileFunctionDetails) {
        this.profileFunctionDetails = profileFunctionDetails;
    }

    /**
     * Accessor for property profileDetails.
     * 
     * @return profileDetails of type ProfileDetails
     */
    public ProfileDetails getProfileDetails() {
        return profileDetails;
    }

    /**
     * Mutator for property profileDetails.
     * 
     * @param profileDetails of type ProfileDetails
     */
    @XmlElement(name = "profileDetails")
    public void setProfileDetails(ProfileDetails profileDetails) {
        this.profileDetails = profileDetails;
    }

    /**
     * Accessor for property sameAsDefaultInvestmentProfile.
     * 
     * @return sameAsDefaultInvestmentProfile of type String
     */
    public String getSameAsDefaultInvestmentProfile() {
        return sameAsDefaultInvestmentProfile;
    }

    /**
     * Mutator for property sameAsDefaultInvestmentProfile.
     * 
     * @param sameAsDefaultInvestmentProfile of type String
     */
    @XmlElement(name = "sameAsDefaultInvestmentProfile")
    public void setSameAsDefaultInvestmentProfile(String sameAsDefaultInvestmentProfile) {
        this.sameAsDefaultInvestmentProfile = sameAsDefaultInvestmentProfile;
    }

    /**
     * Accessor for property patternMethod.
     * 
     * @return patternMethod of type CodeIdentifier
     */
    public CodeIdentifier getPatternMethod() {
        return patternMethod;
    }

    /**
     * Mutator for property patternMethod.
     * 
     * @param patternMethod of type CodeIdentifier
     */
    @XmlElement(name = "patternMethod")
    public void setPatternMethod(CodeIdentifier patternMethod) {
        this.patternMethod = patternMethod;
    }

    /**
     * Accessor for property overrideCode.
     * 
     * @return overrideCode of type CodeIdentifier
     */
    public CodeIdentifier getOverrideCode() {
        return overrideCode;
    }

    /**
     * Mutator for property overrideCode.
     * 
     * @param overrideCode of type CodeIdentifier
     */
    @XmlElement(name = "overrideCode")
    public void setOverrideCode(CodeIdentifier overrideCode) {
        this.overrideCode = overrideCode;
    }

    /**
     * Accessor for property totalAmount.
     * 
     * @return totalAmount of type String
     */
    public String getTotalAmount() {
        return totalAmount;
    }

    /**
     * Mutator for property totalAmount.
     * 
     * @param totalAmount of type String
     */
    @XmlElement(name = "totalAmount")
    public void setTotalAmount(String totalAmount) {
        this.totalAmount = totalAmount;
    }

    /**
     * Accessor for property clearAllFunds.
     * 
     * @return clearAllFunds of type String
     */
    public String getClearAllFunds() {
        return clearAllFunds;
    }

    /**
     * Mutator for property clearAllFunds.
     * 
     * @param clearAllFunds of type String
     */
    @XmlElement(name = "clearAllFunds")
    public void setClearAllFunds(String clearAllFunds) {
        this.clearAllFunds = clearAllFunds;
    }

    /**
     * Accessor for property fundDetails.
     * 
     * @return fundDetails of type List<FundDetails>
     */
    public List<FundDetails> getFundDetails() {
        return fundDetails;
    }

    /**
     * Mutator for property fundDetails.
     * 
     * @param fundDetails of type List<FundDetails>
     */
    @XmlElement(name = "fundDetails")
    public void setFundDetails(List<FundDetails> fundDetails) {
        this.fundDetails = fundDetails;
    }

    /**
     * Accessor for property deleteFlag.
     * 
     * @return deleteFlag of type String
     */
    public String getDeleteFlag() {
        return deleteFlag;
    }

    /**
     * Mutator for property deleteFlag.
     * 
     * @param deleteFlag of type String
     */
    @XmlElement(name = "delete")
    public void setDeleteFlag(String deleteFlag) {
        this.deleteFlag = deleteFlag;
    }
}
