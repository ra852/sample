////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.BankAccountIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.ClientIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CodeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CurrencyIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.FrequencyIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.RelationshipTypeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.fund.fundgrouptype.FundIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.RegularPlanType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.RegularPlanType.ContributionTypeSplit;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.RegularPlanType.FundSplit;
import com.sonatacentral.service.v30.wrap.account.SaveRegularContributionPlanRequestType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.CodeIdentifier;
import com.suncorp.ssp.service.integration.accountservice.bean.ContributionTypeSplitsBean;
import com.suncorp.ssp.service.integration.accountservice.bean.FundIdentifierDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.FundSplitsBean;
import com.suncorp.ssp.service.integration.accountservice.bean.SaveRegularContributionPlanRequestBean;

/**
 * The class {@code SaveRegularContributionRequestUtil} is used as a request util for saving regular contribution.
 * 
 * @author U383754
 * @since 30/05/2016
 * @version 1.0
 */
public class SaveRegularContributionRequestUtil {
    private final String cName = "SaveRegularContributionRequestUtil";
    private SaveRegularContributionPlanRequestBean inbound;

    /**
     * Constructor for setting the save regular contribution plan request type.
     * 
     * @param saveRegularContributionPlanRequestType
     */
    public SaveRegularContributionRequestUtil(SaveRegularContributionPlanRequestBean inbound) {
        this.inbound = inbound;
    }

    /**
     * This method is used to get request object for saving regular contribution plan.
     * 
     * @param inbound
     * @return
     * @throws SILException
     */
    public SaveRegularContributionPlanRequestType getRegularContributionPlanDetails() throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_REG_CONT_LOGGING_FORMAT, cName, "Entering getRegularContributionPlanDetails()");
        SaveRegularContributionPlanRequestType planRequestType = new SaveRegularContributionPlanRequestType();
        AccountIdentifierType account = this.getAccountDetails(this.inbound);
        planRequestType.setAccount(account);
        RegularPlanType regularContributionPlan = this.getRegularContributionPlan(this.inbound);
        planRequestType.setRegularContributionPlan(regularContributionPlan);
        return planRequestType;
    }

    /**
     * This method is used to getRegular Contribution.
     * 
     * @param inbound
     * @return regularPlanType
     * @throws SILException
     */
    private RegularPlanType getRegularContributionPlan(SaveRegularContributionPlanRequestBean inbound) throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_REG_CONT_LOGGING_FORMAT, cName, "Entering getRegularContributionPlan()");
        RegularPlanType regularPlanType = new RegularPlanType();
        if (inbound != null && inbound.getRegularContributionPlan() != null) {
            if (inbound.getRegularContributionPlan().getRelationshipType() != null) {
                RelationshipTypeIdentifierType relationshipType = this.getRelationshipType(inbound);
                regularPlanType.setRelationshipType(relationshipType);
            }
            if (inbound.getRegularContributionPlan().getClient() != null) {
                ClientIdentifierType client = this.getClientDetails(inbound);
                regularPlanType.setClient(client);
            }
            if (inbound.getRegularContributionPlan().getStatus() != null) {
                CodeIdentifierType status = this.getStatusDetails(inbound);
                regularPlanType.setStatus(status);
            }
            if (inbound.getRegularContributionPlan().getPaymentMethod() != null) {
                CodeIdentifierType paymentMethod = this.getPaymentMethodDetails(inbound);
                regularPlanType.setPaymentMethod(paymentMethod);
            }
            setRegularContributionParamsFirst(inbound, regularPlanType);
            setRegularContributionPanParams(inbound, regularPlanType);
        }
        return regularPlanType;
    }

    /**
     * This method sets the input parameters in the sonata request.
     * 
     * @param inbound
     * @param regularPlanType
     */
    private void setRegularContributionParamsFirst(SaveRegularContributionPlanRequestBean inbound, RegularPlanType regularPlanType) {
        SILLogger.debug(AccountServiceConstants.SAVE_REG_CONT_LOGGING_FORMAT, cName, "Entering setRegularContributionParamsFirst()");
        if (inbound.getRegularContributionPlan().getFrequency() != null) {
            FrequencyIdentifierType frequency = this.getFrequencyDetails(inbound);
            regularPlanType.setFrequency(frequency);
        }
        if (inbound.getRegularContributionPlan().getBankAccount() != null) {
            BankAccountIdentifierType bankAccount = this.getBankAccountDetails(inbound);
            regularPlanType.setBankAccount(bankAccount);
        }
        if (inbound.getRegularContributionPlan().getAmountCurrencyCode() != null) {
            CurrencyIdentifierType amountCurrencyCode = this.getAmountCurrencyCodeDetails(inbound);
            regularPlanType.setAmountCurrencyCode(amountCurrencyCode);
        }
        if (inbound.getRegularContributionPlan().getContributionTypeSplits() != null &&
                inbound.getRegularContributionPlan().getContributionTypeSplits().size() > 0) {
            regularPlanType.getContributionTypeSplit().addAll(
                    setcontrbutionTypeSplit(inbound.getRegularContributionPlan().getContributionTypeSplits()));
        }
    }

    /**
     * This method sets the input parameters in the sonata request.
     * 
     * @param inbound
     * @param regularPlanType
     * @throws SILException
     */
    private void setRegularContributionPanParams(SaveRegularContributionPlanRequestBean inbound, RegularPlanType regularPlanType) 
            throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_REG_CONT_LOGGING_FORMAT, cName, "Entering setRegularContributionPanParams()");
        if (inbound.getRegularContributionPlan().getRegularPlanId() != null) {
            regularPlanType.setRegularPlanId(Long.valueOf(inbound.getRegularContributionPlan().getRegularPlanId()));
        }
        if (inbound.getRegularContributionPlan().getAmount() != null) {
            regularPlanType.setAmount(BigDecimal.valueOf(Long.valueOf(inbound.getRegularContributionPlan().getAmount())));
        }
        if (inbound.getRegularContributionPlan().getNextDueDate() != null) {
            regularPlanType.setNextDueDate(SILUtil.convertStringToXMLGregorianCalendar(inbound.getRegularContributionPlan().getNextDueDate(),
                    CommonConstants.DATE_FORMAT));
        }
        if (inbound.getRegularContributionPlan().getLinkedToProfile() != null) {
            regularPlanType.setLinkedToProfile(Boolean.valueOf(inbound.getRegularContributionPlan().getLinkedToProfile()));
        }
        if (inbound.getRegularContributionPlan().getFundSplits() != null && inbound.getRegularContributionPlan().getFundSplits().size() > 0) {
            regularPlanType.getFundSplit().addAll(setFundSplit(inbound.getRegularContributionPlan().getFundSplits()));
        }
    }

    /**
     * This method is used to get currency code details.
     * 
     * @param inbound
     * @return
     */
    private CurrencyIdentifierType getAmountCurrencyCodeDetails(SaveRegularContributionPlanRequestBean inbound) {
        SILLogger.debug(AccountServiceConstants.SAVE_REG_CONT_LOGGING_FORMAT, cName, "Entering getAmountCurrencyCodeDetails()");
        CurrencyIdentifierType currencyIdentifierType = new CurrencyIdentifierType();
        if (inbound.getRegularContributionPlan().getAmountCurrencyCode() != null) {
            currencyIdentifierType.setCode(inbound.getRegularContributionPlan().getAmountCurrencyCode().getCode());
        }
        return currencyIdentifierType;
    }

    /**
     * This method is used to get Bank Account details.
     * 
     * @param inbound
     * @return
     */
    private BankAccountIdentifierType getBankAccountDetails(SaveRegularContributionPlanRequestBean inbound) {
        SILLogger.debug(AccountServiceConstants.SAVE_REG_CONT_LOGGING_FORMAT, cName, "Entering getBankAccountDetails()");
        BankAccountIdentifierType accountIdentifierType = new BankAccountIdentifierType();
        if (inbound.getRegularContributionPlan().getBankAccount().getBankAccountNumber() != null) {
            accountIdentifierType.setBankAccountNumber(inbound.getRegularContributionPlan().getBankAccount().getBankAccountNumber());
        }
        if (inbound.getRegularContributionPlan().getBankAccount().getBankAccountTypeCode() != null) {
            accountIdentifierType.setBankAccountTypeCode(inbound.getRegularContributionPlan().getBankAccount().getBankAccountTypeCode());
        }
        return accountIdentifierType;
    }

    /**
     * This method is used to get frequency details.
     * 
     * @param inbound
     * @return
     */
    private FrequencyIdentifierType getFrequencyDetails(SaveRegularContributionPlanRequestBean inbound) {
        SILLogger.debug(AccountServiceConstants.SAVE_REG_CONT_LOGGING_FORMAT, cName, "Entering getFrequencyDetails()");
        FrequencyIdentifierType frequencyIdentifierType = new FrequencyIdentifierType();
        if (inbound.getRegularContributionPlan().getFrequency().getFreqCode() != null) {
            frequencyIdentifierType.setFreqCode(inbound.getRegularContributionPlan().getFrequency().getFreqCode());
        }
        return frequencyIdentifierType;
    }

    /**
     * This method is used to get method details.
     * 
     * @param inbound
     * @return
     */
    private CodeIdentifierType getPaymentMethodDetails(SaveRegularContributionPlanRequestBean inbound) {
        SILLogger.debug(AccountServiceConstants.SAVE_REG_CONT_LOGGING_FORMAT, cName, "Entering getPaymentMethodDetails()");
        CodeIdentifierType codeIdentifierType = new CodeIdentifierType();
        if (inbound.getRegularContributionPlan().getPaymentMethod().getCode() != null) {
            codeIdentifierType.setCode(inbound.getRegularContributionPlan().getPaymentMethod().getCode());
        }
        if (inbound.getRegularContributionPlan().getPaymentMethod().getCodeType() != null) {
            codeIdentifierType.setCodeType(inbound.getRegularContributionPlan().getPaymentMethod().getCodeType());
        }
        return codeIdentifierType;
    }

    /**
     * This method used to get the status details.
     * 
     * @param inbound
     * @return
     */
    private CodeIdentifierType getStatusDetails(SaveRegularContributionPlanRequestBean inbound) {
        SILLogger.debug(AccountServiceConstants.SAVE_REG_CONT_LOGGING_FORMAT, cName, "Entering getStatusDetails()");
        CodeIdentifierType codeIdentifierType = new CodeIdentifierType();
        if (inbound.getRegularContributionPlan().getStatus().getCode() != null) {
            codeIdentifierType.setCode(inbound.getRegularContributionPlan().getStatus().getCode());
        }
        if (inbound.getRegularContributionPlan().getStatus().getCodeType() != null) {
            codeIdentifierType.setCodeType(inbound.getRegularContributionPlan().getStatus().getCodeType());
        }
        return codeIdentifierType;
    }

    /**
     * This method is used to get client details.
     * 
     * @param inbound
     * @return
     */
    private ClientIdentifierType getClientDetails(SaveRegularContributionPlanRequestBean inbound) {
        SILLogger.debug(AccountServiceConstants.SAVE_REG_CONT_LOGGING_FORMAT, cName, "Entering getClientDetails()");
        ClientIdentifierType clientIdentifierType = new ClientIdentifierType();
        if (inbound.getRegularContributionPlan().getClient().getId() != null) {
            clientIdentifierType.setId(Long.valueOf(inbound.getRegularContributionPlan().getClient().getId()));
        }
        return clientIdentifierType;
    }

    /**
     * This method is used to get relationship type.
     * 
     * @param inbound
     * @return
     */
    private RelationshipTypeIdentifierType getRelationshipType(SaveRegularContributionPlanRequestBean inbound) {
        SILLogger.debug(AccountServiceConstants.SAVE_REG_CONT_LOGGING_FORMAT, cName, "Entering getRelationshipType()");
        RelationshipTypeIdentifierType identifierType = new RelationshipTypeIdentifierType();
        if (inbound.getRegularContributionPlan().getRelationshipType().getId() != null) {
            identifierType.setId(Long.valueOf(inbound.getRegularContributionPlan().getRelationshipType().getId()));
        }
        if (inbound.getRegularContributionPlan().getRelationshipType().getName() != null) {
            identifierType.setName(inbound.getRegularContributionPlan().getRelationshipType().getName());
        }
        if (inbound.getRegularContributionPlan().getRelationshipType().getCode() != null) {
            identifierType.setCode(inbound.getRegularContributionPlan().getRelationshipType().getCode());
        }
        return identifierType;
    }

    /**
     * This method is used to get Account details.
     * 
     * @param inbound
     * @return
     */
    private AccountIdentifierType getAccountDetails(SaveRegularContributionPlanRequestBean inbound) {
        SILLogger.debug(AccountServiceConstants.SAVE_REG_CONT_LOGGING_FORMAT, cName, "Entering getAccountDetails()");
        AccountIdentifierType accountIdentifierType = new AccountIdentifierType();
        AccountIdentifierType.AccountNumber accountNumber = new AccountIdentifierType.AccountNumber();
        accountNumber.setAccountNo(inbound.getAccount().getAccountNumber().getAccountNo());
        accountIdentifierType.setAccountNumber(accountNumber);
        return accountIdentifierType;
    }

    /**
     * This method is used to set contrbutionTypeSplit.
     * 
     * @param inbound
     * @return
     */
    private List<ContributionTypeSplit> setcontrbutionTypeSplit(List<ContributionTypeSplitsBean> splitsBeans) {
        SILLogger.debug(AccountServiceConstants.SAVE_REG_CONT_LOGGING_FORMAT, cName, "Entering setcontrbutionTypeSplit()");
        List<ContributionTypeSplit> contributionTypeSplits = new ArrayList<ContributionTypeSplit>();
        if (splitsBeans != null && splitsBeans.size() > 0) {
            for (ContributionTypeSplitsBean contributionTypeSplitsBean : splitsBeans) {
                ContributionTypeSplit typeSplit = new ContributionTypeSplit();
                if (contributionTypeSplitsBean.getContributionTypeCode() != null) {
                    typeSplit.setContributionTypeCode(setCodeIdentifier(contributionTypeSplitsBean.getContributionTypeCode()));
                }
                if (contributionTypeSplitsBean.getPercentage() != null) {
                    typeSplit.setPercentage(BigDecimal.valueOf(Long.valueOf(contributionTypeSplitsBean.getPercentage())));
                }
                contributionTypeSplits.add(typeSplit);
            }
        }
        return contributionTypeSplits;
    }

    /**
     * This method used to set code .
     * 
     * @param inbound
     * @return codeIdentifierType
     */
    private CodeIdentifierType setCodeIdentifier(CodeIdentifier codeIdentifier) {
        SILLogger.debug(AccountServiceConstants.SAVE_REG_CONT_LOGGING_FORMAT, cName, "Entering setCodeIdentifier()");
        CodeIdentifierType codeIdentifierType = new CodeIdentifierType();
        if (codeIdentifier.getCode() != null) {
            codeIdentifierType.setCode(codeIdentifier.getCode());
        }
        if (codeIdentifier.getCodeType() != null) {
            codeIdentifierType.setCodeType(codeIdentifier.getCodeType());
        }
        return codeIdentifierType;
    }

    /**
     * This method is used to set FundSplit.
     * 
     * @param inbound
     * @return
     */
    private List<FundSplit> setFundSplit(List<FundSplitsBean> fundSplitsBeans) {
        SILLogger.debug(AccountServiceConstants.SAVE_REG_CONT_LOGGING_FORMAT, cName, "Entering setFundSplit()");
        List<FundSplit> fundSplits = new ArrayList<FundSplit>();
        if (fundSplitsBeans != null && fundSplitsBeans.size() > 0) {
            for (FundSplitsBean fundSplitsBean : fundSplitsBeans) {
                FundSplit fundSplit = new FundSplit();
                if (fundSplitsBean.getFund() != null) {
                    fundSplit.setFund(setFundIdentifierType(fundSplitsBean.getFund()));
                }
                if (fundSplitsBean.getPercentage() != null) {
                    fundSplit.setPercentage(BigDecimal.valueOf(Long.valueOf(fundSplitsBean.getPercentage())));
                }
                fundSplits.add(fundSplit);
            }
        }
        return fundSplits;
    }

    /**
     * This method used to set fund Identifier .
     * 
     * @param inbound
     * @return fundIdentifierType
     */
    private FundIdentifierType setFundIdentifierType(FundIdentifierDetails fundIdentifierDetails) {
        SILLogger.debug(AccountServiceConstants.SAVE_REG_CONT_LOGGING_FORMAT, cName, "Entering setFundIdentifierType()");
        FundIdentifierType fundIdentifierType = new FundIdentifierType();
        if (fundIdentifierType.getName() != null) {
            fundIdentifierType.setName(fundIdentifierDetails.getName());
        }
        if (fundIdentifierType.getId() != null) {
            fundIdentifierType.setId(Long.valueOf(fundIdentifierDetails.getId()));
        }
        return fundIdentifierType;
    }
}
