////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import javax.ws.rs.core.MultivaluedMap;

import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType.AccountNumber;
import com.sonatacentral.service.v30.wrap.account.GetAccountDetailsRequestType;
import com.sonatacentral.service.v30.wrap.account.GetAccountDetailsRequestType.AccountDetails;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;

/**
 * The class {@code GetPensionDetailsRequestUtil} does this.
 * 
 * @author U386868
 * @since 02/04/2016
 * @version 1.0
 */
public class GetPensionDetailsRequestUtil {
    private final String className = "GetPensionDetailsRequestUtil";
    private final String getPensionDetailsServiceLogger = AccountServiceConstants.GET_PENSION_DETAILS_LOGGING_FORMAT;
    private GetAccountDetailsRequestType outboundRequest;
    private MultivaluedMap<String, String> inboundRequest;

    /**
     * Initializes class properties,viz., inbound and outbound request types.
     * 
     * @param inboundRequest of type MultivaluedMap
     */
    public GetPensionDetailsRequestUtil(MultivaluedMap<String, String> inboundRequest) {
        this.inboundRequest = inboundRequest;
        this.outboundRequest = new GetAccountDetailsRequestType();
    }

    /**
     * 
     * Create Oubound(GetAccountDetailsRequestType) request.
     * 
     * @return
     * @throws Exception
     */
    public GetAccountDetailsRequestType createOutboundRequest() throws SILException {
        SILLogger.debug(getPensionDetailsServiceLogger, className, "Entering createOutboundRequest()");
        this.outboundRequest.setCallerDetails(SILUtil.createCallerDetails());
        AccountDetails accountDetails = new AccountDetails();
        accountDetails.setAccount(constructAccountIdentifierType());
        outboundRequest.getAccountDetails().add(accountDetails);
        constructAccountDetailsIncludeParamsFirst();
        constructAccountDetailsIncludeParamsSecond();
        return this.outboundRequest;
    }

    /**
     * 
     * Creates AccountIdentifierType accountNumber and product name.
     * 
     * @return
     * @throws SILException
     */
    private AccountIdentifierType constructAccountIdentifierType() throws SILException {
        SILLogger.debug(getPensionDetailsServiceLogger, className, "Entering in constructAccountIdentifierType method.");
        AccountIdentifierType accountIdentifierType = new AccountIdentifierType();
        AccountNumber accountNumber = new AccountNumber();
        if (inboundRequest.containsKey("accountNumber") && inboundRequest.get("accountNumber").get(0) != null) {
            accountNumber.setAccountNo(inboundRequest.get("accountNumber").get(0));
        } else {
            throw new SILException(AccountServiceConstants.INVALID_ACCOUNTNUMBER_MESSAGE);
        }
        if (inboundRequest.containsKey("productName") && inboundRequest.get("productName").get(0) != null) {
            accountNumber.setProductName(inboundRequest.get("productName").get(0));
        }
        accountIdentifierType.setAccountNumber(accountNumber);
        constructAccountIdName(accountIdentifierType);
        return accountIdentifierType;
    }

    /**
     * 
     * Sets AccountId and account name in AccountIdentifierType.
     * 
     * @param accountIdentifierType
     */

    private void constructAccountIdName(AccountIdentifierType accountIdentifierType) throws SILException {
        SILLogger.debug(getPensionDetailsServiceLogger, className, "Entering in constructAccountIdName method.");
        if (inboundRequest.containsKey("accountId") && inboundRequest.get("accountId").get(0) != null) {
            accountIdentifierType.setId(Long.valueOf(inboundRequest.get("accountId").get(0)));
        }
        if (inboundRequest.containsKey("accountName") && inboundRequest.get("accountName").get(0) != null) {
            accountIdentifierType.setName(inboundRequest.get("accountName").get(0));
        }
        if (inboundRequest.containsKey("includeSchemeLocationHistory") && inboundRequest.get("includeSchemeLocationHistory").get(0) != null) {
            outboundRequest.setIncludeSchemeLocationHistory(Boolean.valueOf(inboundRequest.get("includeSchemeLocationHistory").get(0)));
        }
    }

    /**
     * 
     * Sets include parameters in GetAccountDetailsRequestType from request query params received
     * 
     * @throws SILException
     */
    private void constructAccountDetailsIncludeParamsFirst() throws SILException {
        SILLogger.debug(getPensionDetailsServiceLogger, className, "Entering in constructAccountDetailsIncludeParamsFirst method.");
        if (inboundRequest.containsKey("includeAccountTaxDetail") && inboundRequest.get("includeAccountTaxDetail").get(0) != null) {
            outboundRequest.setIncludeAccountTaxDetail(Boolean.valueOf(inboundRequest.get("includeAccountTaxDetail").get(0)));
        }
        if (inboundRequest.containsKey("includePensionPaymentAmountDetail") && inboundRequest.get("includePensionPaymentAmountDetail")
                .get(0) != null) {
            outboundRequest.setIncludePensionPaymentAmountDetail(Boolean.valueOf(inboundRequest.get("includePensionPaymentAmountDetail").get(0)));
        }
        if (inboundRequest.containsKey("includePensionPaymentInstruction") && inboundRequest.get("includePensionPaymentInstruction").get(0) != null) {
            outboundRequest.setIncludePensionPaymentInstruction(Boolean.valueOf(inboundRequest.get("includePensionPaymentInstruction").get(0)));
        }
    }

    /**
     * 
     * Sets include parameters in GetAccountDetailsRequestType from request query params received
     * 
     * @throws SILException
     */
    private void constructAccountDetailsIncludeParamsSecond() throws SILException {
        SILLogger.debug(getPensionDetailsServiceLogger, className, "Entering in constructAccountDetailsIncludeParamsSecond method.");
        if (inboundRequest.containsKey("includePensionPaymentSplit") && inboundRequest.get("includePensionPaymentSplit").get(0) != null) {
            outboundRequest.setIncludePensionPaymentSplit(Boolean.valueOf(inboundRequest.get("includePensionPaymentSplit").get(0)));
        }
        if (inboundRequest.containsKey("includeDrawdownDetail") && inboundRequest.get("includeDrawdownDetail").get(0) != null) {
            outboundRequest.setIncludeDrawdownDetail(Boolean.valueOf(inboundRequest.get("includeDrawdownDetail").get(0)));
        }
        if (inboundRequest.containsKey("includePensionProtection") && inboundRequest.get("includePensionProtection").get(0) != null) {
            outboundRequest.setIncludePensionProtection(Boolean.valueOf(inboundRequest.get("includePensionProtection").get(0)));
        }
    }
}
