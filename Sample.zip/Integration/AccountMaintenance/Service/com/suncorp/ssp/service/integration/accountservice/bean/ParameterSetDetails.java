////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code ParameterSetDetails} does this.
 * 
 * @author u387938
 * @since 08/02/2016
 * @version 1.0
 */
public class ParameterSetDetails {
    private String custom;
    private CodeIdentifier calculationBook;
    private String name;

    /**
     * Accessor for property custom.
     * 
     * @return custom of type String
     */
    public String getCustom() {
        return custom;
    }

    /**
     * Mutator for property custom.
     * 
     * @param custom of type String
     */
    @XmlElement(name = "custom")
    public void setCustom(String custom) {
        this.custom = custom != null ? custom : "";
    }

    /**
     * Accessor for property calculationBook.
     * 
     * @return calculationBook of type CodeIdentifier
     */
    public CodeIdentifier getCalculationBook() {
        return calculationBook;
    }

    /**
     * Mutator for property calculationBook.
     * 
     * @param calculationBook of type CodeIdentifier
     */
    @XmlElement(name = "calculationBook")
    public void setCalculationBook(CodeIdentifier calculationBook) {
        this.calculationBook = calculationBook;
    }

    /**
     * Accessor for property name.
     * 
     * @return name of type String
     */
    public String getName() {
        return name;
    }

    /**
     * Mutator for property name.
     * 
     * @param name of type String
     */
    @XmlElement(name = "name")
    public void setName(String name) {
        this.name = name != null ? name : "";
    }
}
