////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bo;

import java.util.List;

import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.dao.daoimpl.AccountServiceDAOImpl;
import com.suncorp.ssp.common.dao.datasource.OdsDO;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.FamilyLinkingDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.GetFamilyLinkingDetailsResponse;

/**
 * The class {@code GetFamilyLinkingDetailsRequestBO} is a Utility class with all the properties related to GetFamilyLinkingDetails Business Object.
 * 
 * @author U385424
 * @since 15/11/2016
 * @version 1.0
 */
public class GetFamilyLinkingDetailsRequestBO {
    private final String className = "GetFamilyLinkingDetailsRequestBO";

    /**
     * Extracts values from all client details from respective objects and set the values to external service's request object.
     * 
     * @param inputParams
     * 
     * @param inputParams
     * 
     * @param saveClientRequestType
     * @throws SILException
     */
    public GetFamilyLinkingDetailsResponse getFamilyLinkingDetailsDaoCall(List<String> inputParams, String url, String user, String password)
            throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_FAMILY_LINKING_DETAILS_LOGGING_FORMAT, className, "getFamilyLinkingDetailsDaoCall()");
        GetFamilyLinkingDetailsResponse outputResponseList = new GetFamilyLinkingDetailsResponse();
        AccountServiceDAOImpl accountServiceDAOImpl = new AccountServiceDAOImpl();
        List<OdsDO> odsDOs = accountServiceDAOImpl.getDetails(inputParams, url, user, password);
        if (odsDOs != null && odsDOs.size() > 0) {
            for (OdsDO inputResponse : odsDOs) {
                setOutputResponseParams(outputResponseList, inputResponse);
            }
        } else {
            throw new SILException(AccountServiceConstants.NO_RECORD_FOUND);
        }
        return outputResponseList;
    }

    /**
     * Set Output Response Params.
     * 
     * @param outputResponseList
     * @param inputResponse
     */
    private void setOutputResponseParams(GetFamilyLinkingDetailsResponse outputResponseList, OdsDO inputResponse) {
        SILLogger.debug(AccountServiceConstants.GET_FAMILY_LINKING_DETAILS_LOGGING_FORMAT, className, "Entering setOutputResponseParams.");
        FamilyLinkingDetails outputResponse = new FamilyLinkingDetails();
        outputResponse.setAccountNumber(retrieveStringValue(inputResponse.getMemberAccountNumber()));
        outputResponse.setDateOfBirth(retrieveStringValue(inputResponse.getMemberDateOfBirth()));
        outputResponse.setFirstName(retrieveStringValue(inputResponse.getMemberFirstName()));
        outputResponse.setLastName(retrieveStringValue(inputResponse.getMemberLastName()));
        outputResponseList.getFamilyLinkingDetails().add(outputResponse);
    }

    /**
     * This method is used to check String value.
     * 
     * @return String
     */
    public String retrieveStringValue(String value) {
        SILLogger.debug(AccountServiceConstants.GET_FAMILY_LINKING_DETAILS_LOGGING_FORMAT, className, "Entering in retrieveStringValue method");
        if (value != null) {
            return value;
        } else {
            return CommonConstants.EMPTY_STRING_VALUE;
        }
    }
}
