////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;
/**
 * The class {@code AccountDetailBean} does this.
 * 
 * @author U387938
 * @since 02/02/2016
 * @version 1.0
 */
public class InvestmentRequesterBean {

    private AdvisorDetails advisor;
    private ClientBean client;
    /**
     * Accessor for property advisor.
     *
     * @return advisor of type AdvisorDetails
     */
    public AdvisorDetails getAdvisor() {
        return advisor;
    }
    /**
     * Mutator for property advisor.
     *
     * @param advisor of type AdvisorDetails
     */
    @XmlElement(name = "advisor")
    public void setAdvisor(AdvisorDetails advisor) {
        this.advisor = advisor;
    }
    /**
     * Accessor for property client.
     *
     * @return client of type ClientBean
     */
    public ClientBean getClient() {
        return client;
    }
    /**
     * Mutator for property client.
     *
     * @param client of type ClientBean
     */
    @XmlElement(name = "client")
    public void setClient(ClientBean client) {
        this.client = client;
    }
    
    
}
