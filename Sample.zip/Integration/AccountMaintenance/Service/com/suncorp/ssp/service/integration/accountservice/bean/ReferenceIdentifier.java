////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code ReferenceIdentifier} does this.
 * 
 * @author U383754
 * @since 02/02/2016
 * @version 1.0
 */
public class ReferenceIdentifier {
    private String reference;
    private String referenceCode;

    /**
     * Accessor for property reference.
     * 
     * @return reference of type String
     */
    public String getReference() {
        return reference;
    }

    /**
     * Mutator for property reference.
     * 
     * @return reference of type String
     */
    @XmlElement(name = "reference")
    public void setReference(String reference) {
        this.reference = reference != null ? reference : "";
    }

    /**
     * Accessor for property referenceCode.
     * 
     * @return referenceCode of type String
     */
    public String getReferenceCode() {
        return referenceCode;
    }

    /**
     * Mutator for property referenceCode.
     * 
     * @return referenceCode of type String
     */
    @XmlElement(name = "referenceCode")
    public void setReferenceCode(String referenceCode) {
        this.referenceCode = referenceCode != null ? referenceCode : "";
    }
}
