////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * The class {@code SaveInvestmentProfileRequest} does this.
 *
 * @author u387938
 * @since 20/07/2016
 * @version 1.0
 */

@XmlRootElement(name = "SaveInvestmentProfileRequest")
public class SaveInvestmentProfileRequest {

    private AccountIdentifierDetails account;
    private List<InvestmentProfileDetails> investmentProfiles;
    /**
     * Accessor for property account.
     *
     * @return account of type AccountIdentifierDetails
     */
    public AccountIdentifierDetails getAccount() {
        return account;
    }
    /**
     * Mutator for property account.
     *
     * @param account of type AccountIdentifierDetails
     */
    @XmlElement(name = "account")
    public void setAccount(AccountIdentifierDetails account) {
        this.account = account;
    }
    /**
     * Accessor for property investmentProfiles.
     *
     * @return investmentProfiles of type List<InvestmentProfileDetails>
     */
    public List<InvestmentProfileDetails> getInvestmentProfiles() {
        return investmentProfiles;
    }
    /**
     * Mutator for property investmentProfiles.
     *
     * @param investmentProfiles of type List<InvestmentProfileDetails>
     */
    @XmlElement(name = "investmentProfiles")
    public void setInvestmentProfiles(List<InvestmentProfileDetails> investmentProfiles) {
        this.investmentProfiles = investmentProfiles;
    }
    
    
   
}
