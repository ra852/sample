////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;
/**
 * The class {@code CategoryBean} does this.
 * 
 * @author U387938
 * @since 02/02/2016
 * @version 1.0
 */
public class CategoryBean {

    private String id;
    private String shortName;
    private String longName;
    private SchemeIdentifier categoryScheme;
    private String startDate;
    private String endDate;
    private CodeIdentifier status;
    private String retirementAge;
    private String earlyRetirementAge;
    /**
     * Accessor for property id.
     *
     * @return id of type String
     */
    public String getId() {
        return id;
    }
    /**
     * Mutator for property id.
     *
     * @param id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id != null ? id : "";
    }
    /**
     * Accessor for property shortName.
     *
     * @return shortName of type String
     */
    public String getShortName() {
        return shortName;
    }
    /**
     * Mutator for property shortName.
     *
     * @param shortName of type String
     */
    @XmlElement(name = "shortName")
    public void setShortName(String shortName) {
        this.shortName = shortName != null ? shortName : "";
    }
    /**
     * Accessor for property longName.
     *
     * @return longName of type String
     */
    public String getLongName() {
        return longName;
    }
    /**
     * Mutator for property longName.
     *
     * @param longName of type String
     */
    @XmlElement(name = "longName")
    public void setLongName(String longName) {
        this.longName = longName != null ? longName : "";
    }
    
    /**
     * Accessor for property startDate.
     *
     * @return startDate of type String
     */
    public String getStartDate() {
        return startDate;
    }
    /**
     * Mutator for property startDate.
     *
     * @param startDate of type String
     */
    @XmlElement(name = "startDate")
    public void setStartDate(String startDate) {
        this.startDate = startDate != null ? startDate : "";
    }
    /**
     * Accessor for property endDate.
     *
     * @return endDate of type String
     */
    public String getEndDate() {
        return endDate;
    }
    /**
     * Mutator for property endDate.
     *
     * @param endDate of type String
     */
    @XmlElement(name = "endDate")
    public void setEndDate(String endDate) {
        this.endDate = endDate != null ? endDate : "";
    }
    /**
     * Accessor for property status.
     *
     * @return status of type CodeIdentifier
     */
    public CodeIdentifier getStatus() {
        return status;
    }
    /**
     * Mutator for property status.
     *
     * @param status of type CodeIdentifier
     */
    @XmlElement(name = "status")
    public void setStatus(CodeIdentifier status) {
        this.status = status;
    }
    /**
     * Accessor for property retirementAge.
     *
     * @return retirementAge of type String
     */
    public String getRetirementAge() {
        return retirementAge;
    }
    /**
     * Mutator for property retirementAge.
     *
     * @param retirementAge of type String
     */
    @XmlElement(name = "retirementAge")
    public void setRetirementAge(String retirementAge) {
        this.retirementAge = retirementAge != null ? retirementAge : "";
    }
    /**
     * Accessor for property earlyRetirementAge.
     *
     * @return earlyRetirementAge of type String
     */
    public String getEarlyRetirementAge() {
        return earlyRetirementAge;
    }
    /**
     * Mutator for property earlyRetirementAge.
     *
     * @param earlyRetirementAge of type String
     */
    @XmlElement(name = "earlyRetirementAge")
    public void setEarlyRetirementAge(String earlyRetirementAge) {
        this.earlyRetirementAge = earlyRetirementAge != null ? earlyRetirementAge : "";
    }
    /**
     * Accessor for property categoryScheme.
     *
     * @return categoryScheme of type SchemeIdentifier
     */
    public SchemeIdentifier getCategoryScheme() {
        return categoryScheme;
    }
    /**
     * Mutator for property categoryScheme.
     *
     * @param categoryScheme of type SchemeIdentifier
     */
    @XmlElement(name = "categoryScheme")
    public void setCategoryScheme(SchemeIdentifier categoryScheme) {
        this.categoryScheme = categoryScheme;
    }
    
    
}
