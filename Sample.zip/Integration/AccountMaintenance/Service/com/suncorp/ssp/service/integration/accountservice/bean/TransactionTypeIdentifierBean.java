////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code TransactionTypeIdentifierBean} does this.
 * 
 * @author U387938
 * @since 02/03/2016
 * @version 1.0
 */
public class TransactionTypeIdentifierBean {
    private String code;
    private CodeIdentifier category;
    /**
     * Accessor for property code.
     *
     * @return code of type String
     */
    public String getCode() {
        return code;
    }
    /**
     * Mutator for property code.
     *
     * @param code of type String
     */
    @XmlElement(name = "code")
    public void setCode(String code) {
        this.code = code;
    }
    /**
     * Accessor for property category.
     *
     * @return category of type CodeIdentifier
     */
    public CodeIdentifier getCategory() {
        return category;
    }
    /**
     * Mutator for property category.
     *
     * @param category of type CodeIdentifier
     */
    @XmlElement(name = "category")
    public void setCategory(CodeIdentifier category) {
        this.category = category;
    }
    
    

}
