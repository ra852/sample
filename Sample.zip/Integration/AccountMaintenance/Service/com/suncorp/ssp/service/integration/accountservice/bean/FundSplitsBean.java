////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;
/**
 * The class {@code AccountDetailBean} does this.
 * 
 * @author U387938
 * @since 02/02/2016
 * @version 1.0
 */
public class FundSplitsBean {

    private FundIdentifierDetails fund;
    private String percentage;
    private String amount;
    private CurrencyIdentifierBean amountCurrencyCode;
    /**
     * Accessor for property fund.
     *
     * @return fund of type FundIdentifierDetails
     */
    public FundIdentifierDetails getFund() {
        return fund;
    }
    /**
     * Mutator for property fund.
     *
     * @param fund of type FundIdentifierDetails
     */
    @XmlElement(name = "fund")
    public void setFund(FundIdentifierDetails fund) {
        this.fund = fund;
    }
    /**
     * Accessor for property percentage.
     *
     * @return percentage of type String
     */
    public String getPercentage() {
        return percentage;
    }
    /**
     * Mutator for property percentage.
     *
     * @param percentage of type String
     */
    @XmlElement(name = "percentage")
    public void setPercentage(String percentage) {
        this.percentage = percentage != null ? percentage : "";
    }
    /**
     * Accessor for property amount.
     *
     * @return amount of type String
     */
    public String getAmount() {
        return amount;
    }
    /**
     * Mutator for property amount.
     *
     * @param amount of type String
     */
    @XmlElement(name = "amount")
    public void setAmount(String amount) {
        this.amount = amount != null ? amount : "";
    }
    /**
     * Accessor for property amountCurrencyCode.
     *
     * @return amountCurrencyCode of type CurrencyIdentifierBean
     */
    public CurrencyIdentifierBean getAmountCurrencyCode() {
        return amountCurrencyCode;
    }
    /**
     * Mutator for property amountCurrencyCode.
     *
     * @param amountCurrencyCode of type CurrencyIdentifierBean
     */
    @XmlElement(name = "amountCurrencyCode")
    public void setAmountCurrencyCode(CurrencyIdentifierBean amountCurrencyCode) {
        this.amountCurrencyCode = amountCurrencyCode;
    } 
    
    
}
