////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import java.util.List;

import javax.ws.rs.core.MultivaluedMap;
import javax.xml.datatype.XMLGregorianCalendar;

import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.AdvisorIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.ClientIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CodeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.PagingRangeType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.RelationshipTypeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.product.productgrouptype.ProductIdentifierType;
import com.sonatacentral.service.v30.wrap.account.SearchAccountRequestType;
import com.sonatacentral.service.v30.wrap.account.SearchAccountRequestType.SearchCriteria;
import com.sonatacentral.service.v30.wrap.account.SearchAccountRequestType.SearchCriteria.Client;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;

/**
 * The class {@code SearchAccountRequestUtil} is a Util class used for creating the outbound request for search account service.
 * 
 * @author U385424
 * @since 08/06/2017
 * @version 1.0
 */
public class SearchAccountRequestUtil {
    private final String className = "SearchAccountRequestUtil";
    private MultivaluedMap<String, String> inboundRequest;
    private SearchAccountRequestType outboundrequest;

    /**
     * This is a parameterized constructor.
     * 
     * @param inboundRequest
     */
    public SearchAccountRequestUtil(MultivaluedMap<String, String> inboundRequest) {
        this.inboundRequest = inboundRequest;
        this.outboundrequest = new SearchAccountRequestType();
    }

    /**
     * This method is used to create outbound request.
     * 
     * @return outboundrequest
     * @throws SILException
     */
    public SearchAccountRequestType createOutboundRequest() throws SILException {
        SILLogger.debug(AccountServiceConstants.SRCH_ACCNT_LOGGING_FORMAT, className, "Entering in constructSearchCriteria method");
        outboundrequest.setCallerDetails(SILUtil.createCallerDetails());
        outboundrequest.setSearchCriteria(constructSearchCriteria());
        outboundrequest.setPagingRange(constructPagingRangeType());
        outboundrequest.setIncludeClientAcctRelationships(true);
        return outboundrequest;
    }

    /**
     * Constructs a new instance of {@code SearchCriteria}, and sets its properties with details received from the end-client.
     * 
     * @return searchCriteria of type SearchCriteria
     * @throws SILException
     */
    private SearchCriteria constructSearchCriteria() throws SILException {
        SILLogger.debug(AccountServiceConstants.SRCH_ACCNT_LOGGING_FORMAT, className, "Entering in constructSearchCriteria method");
        SearchCriteria searchCriteria = new SearchCriteria();
        if (checkAdvisorQueryParams()) {
            searchCriteria.setAdvisor(constructAdvisorDetails());
        }
        if (checkClientQueryParams() || checkClientDateOfBirthParam()) {
            searchCriteria.setClient(constructClient());
        }
        if (checkProductParams()) {
            searchCriteria.getProducts().add(constructProduct());
        }
        checkAndConstructStatusParams(searchCriteria);
        return searchCriteria;
    }

    /**
     * Check for status parameters.
     * 
     * @param searchCriteria
     * @return
     */
    private void checkAndConstructStatusParams(SearchCriteria searchCriteria) {
        SILLogger.debug(AccountServiceConstants.SRCH_ACCNT_LOGGING_FORMAT, className, "Entering in checkAndConstructStatusParams method");
        List<CodeIdentifierType> status = searchCriteria.getStatuses();
        if (inboundRequest.containsKey(AccountServiceConstants.SEARCH_ACCOUNT_ACTIVE_STATUS_CODE_FLAG) &&
                inboundRequest.get(AccountServiceConstants.SEARCH_ACCOUNT_ACTIVE_STATUS_CODE_FLAG).get(0) != null &&
                inboundRequest.get(AccountServiceConstants.SEARCH_ACCOUNT_ACTIVE_STATUS_CODE_FLAG).get(0).equalsIgnoreCase("true")) {
            CodeIdentifierType codeIdentifierType = new CodeIdentifierType();
            codeIdentifierType.setCode("ACTV");
            codeIdentifierType.setCodeType("ASTA");
            status.add(codeIdentifierType);
        }
        if (inboundRequest.containsKey(AccountServiceConstants.SEARCH_ACCOUNT_PENDING_STATUS_CODE_FLAG) &&
                inboundRequest.get(AccountServiceConstants.SEARCH_ACCOUNT_PENDING_STATUS_CODE_FLAG).get(0) != null &&
                inboundRequest.get(AccountServiceConstants.SEARCH_ACCOUNT_PENDING_STATUS_CODE_FLAG).get(0).equalsIgnoreCase("true")) {
            CodeIdentifierType codeIdentifierType = new CodeIdentifierType();
            codeIdentifierType.setCode("PEND");
            codeIdentifierType.setCodeType("ASTA");
            status.add(codeIdentifierType);
        }
        SILLogger.debug(AccountServiceConstants.SRCH_ACCNT_LOGGING_FORMAT, className, "Exiting in checkAndConstructStatusParams method");
    }

    /**
     * Construct advisor object for search account
     * 
     * @param searchCriteria
     * @param inboundRequest
     * @return
     */
    private AdvisorIdentifierType constructAdvisorDetails() {
        SILLogger.debug(AccountServiceConstants.SRCH_ACCNT_LOGGING_FORMAT, className, "Entering in constructAdvisorDetails method");
        AdvisorIdentifierType advisorIdentifierType = new AdvisorIdentifierType();
        if (inboundRequest.containsKey(AccountServiceConstants.SEARCH_ACCOUNT_ADVISOR_CLIENT_ID) &&
                inboundRequest.get(AccountServiceConstants.SEARCH_ACCOUNT_ADVISOR_CLIENT_ID).get(0) != null) {
            advisorIdentifierType.setClientId(Long.parseLong(inboundRequest.get(AccountServiceConstants.SEARCH_ACCOUNT_ADVISOR_CLIENT_ID).get(0)));
        }
        if (inboundRequest.containsKey(AccountServiceConstants.SEARCH_ACCOUNT_ADVISOR_FORENAME) &&
                inboundRequest.get(AccountServiceConstants.SEARCH_ACCOUNT_ADVISOR_FORENAME).get(0) != null) {
            advisorIdentifierType.setClientForename(inboundRequest.get(AccountServiceConstants.SEARCH_ACCOUNT_ADVISOR_FORENAME).get(0) +
                    AccountServiceConstants.SEARCH_ACCOUNT_PERCENT_SYMBOL);
        }
        if (inboundRequest.containsKey(AccountServiceConstants.SEARCH_ACCOUNT_ADVISOR_SURNAME) &&
                inboundRequest.get(AccountServiceConstants.SEARCH_ACCOUNT_ADVISOR_SURNAME).get(0) != null) {
            advisorIdentifierType.setClientSurname(inboundRequest.get(AccountServiceConstants.SEARCH_ACCOUNT_ADVISOR_SURNAME).get(0) +
                    AccountServiceConstants.SEARCH_ACCOUNT_PERCENT_SYMBOL);
        }
        return advisorIdentifierType;
    }

    /**
     * 
     * Construct client object for search account request.
     * 
     * @param exchange
     * @param inboundRequest
     * @return client
     * @throws SILException @
     */
    private Client constructClient() throws SILException {
        SILLogger.debug(AccountServiceConstants.SRCH_ACCNT_LOGGING_FORMAT, className, "Entering in constructClient method");
        Client client = new Client();
        if (checkClientQueryParams()) {
            client.setClientId(constructClientIdentifier());
        }
        if (checkClientDateOfBirthParam()) {
            client.setDateOfBirth(createDateOfBirthQueryString());
        }
        if (inboundRequest.containsKey(AccountServiceConstants.SEARCH_ACCOUNT_OWNER_RLSHP_FLAG) &&
                CommonConstants.FLAG_TRUE.equalsIgnoreCase(inboundRequest.get(AccountServiceConstants.SEARCH_ACCOUNT_OWNER_RLSHP_FLAG).get(0))) {
            client.setRelationshipType(setRelationshipTypeDetails());
        }
        return client;
    }

    /**
     * This method is used to set relationship type details.
     * 
     * @return relationshipTypeIdentifierType
     */
    private RelationshipTypeIdentifierType setRelationshipTypeDetails() {
        SILLogger.debug(AccountServiceConstants.SRCH_ACCNT_LOGGING_FORMAT, className, "Entering in setRelationshipTypeDetails method");
        RelationshipTypeIdentifierType relationshipTypeIdentifierType = new RelationshipTypeIdentifierType();
        relationshipTypeIdentifierType.setId(1L);
        relationshipTypeIdentifierType.setCode(AccountServiceConstants.SEARCH_ACCOUNT_OWNER_CODE);
        relationshipTypeIdentifierType.setName("Owner");
        return relationshipTypeIdentifierType;
    }

    /**
     * 
     * COnstruct client identifier object for search account request.
     * 
     * @param exchange
     * @return @
     */
    private ClientIdentifierType constructClientIdentifier() {
        SILLogger.debug(AccountServiceConstants.SRCH_ACCNT_LOGGING_FORMAT, className, "Entering in constructClientIdentifier method");
        ClientIdentifierType clientIdentifierType = new ClientIdentifierType();
        if (inboundRequest.containsKey(AccountServiceConstants.SEARCH_ACCOUNT_MEMBER_CLIENT_ID) &&
                inboundRequest.get(AccountServiceConstants.SEARCH_ACCOUNT_MEMBER_CLIENT_ID).get(0) != null) {
            clientIdentifierType.setId(Long.parseLong(inboundRequest.get(AccountServiceConstants.SEARCH_ACCOUNT_MEMBER_CLIENT_ID).get(0)));
        }
        if (inboundRequest.containsKey(AccountServiceConstants.SEARCH_ACCOUNT_MEMBER_FORENAME) &&
                inboundRequest.get(AccountServiceConstants.SEARCH_ACCOUNT_MEMBER_FORENAME).get(0) != null) {
            clientIdentifierType.setClientForename(inboundRequest.get(AccountServiceConstants.SEARCH_ACCOUNT_MEMBER_FORENAME).get(0) +
                    AccountServiceConstants.SEARCH_ACCOUNT_PERCENT_SYMBOL);
        }
        if (inboundRequest.containsKey(AccountServiceConstants.SEARCH_ACCOUNT_MEMBER_SURNAME) &&
                inboundRequest.get(AccountServiceConstants.SEARCH_ACCOUNT_MEMBER_SURNAME).get(0) != null) {
            clientIdentifierType.setClientSurname(inboundRequest.get(AccountServiceConstants.SEARCH_ACCOUNT_MEMBER_SURNAME).get(0) +
                    AccountServiceConstants.SEARCH_ACCOUNT_PERCENT_SYMBOL);
        }
        return clientIdentifierType;
    }

    /**
     * Set member date of birth for search Account request.
     * 
     * @param exchange
     * @param searchCriteria
     * @throws SILException @
     */
    private XMLGregorianCalendar createDateOfBirthQueryString() throws SILException {
        SILLogger.debug(AccountServiceConstants.SRCH_ACCNT_LOGGING_FORMAT, className, "Entering in createDateOfBirthQueryString method");
        XMLGregorianCalendar dateOfBirthSoap = null;
        if (inboundRequest.containsKey(AccountServiceConstants.SEARCH_ACCOUNT_MEMBER_DATE_OF_BIRTH) &&
                inboundRequest.get(AccountServiceConstants.SEARCH_ACCOUNT_MEMBER_DATE_OF_BIRTH).get(0) != null) {
            SILLogger.debug(AccountServiceConstants.SRCH_ACCNT_LOGGING_FORMAT, className, "Creating createDateOfBirthQueryString Query String");
            dateOfBirthSoap = createDateOfBirth(inboundRequest.get(AccountServiceConstants.SEARCH_ACCOUNT_MEMBER_DATE_OF_BIRTH).get(0));
        }
        return dateOfBirthSoap;
    }

    /**
     * 
     * Set member date of birth for search Account request.
     * 
     * @param dateOfBirth
     * @return dateOfBirthSoap
     * @throws SILException @
     */
    public XMLGregorianCalendar createDateOfBirth(String dateOfBirth) throws SILException {
        SILLogger.debug(AccountServiceConstants.SRCH_ACCNT_LOGGING_FORMAT, className, "Entering in createDateOfBirth method");
        SILLogger.debug(AccountServiceConstants.SRCH_ACCNT_LOGGING_FORMAT, className, "Entering createDateOfBirth");
        XMLGregorianCalendar dateOfBirthSoap = null;
        if (dateOfBirth != null) {
            dateOfBirthSoap = SILUtil.convertStringToXMLGregorianCalendar(dateOfBirth, CommonConstants.DATE_FORMAT);
        }
        return dateOfBirthSoap;
    }

    /**
     * 
     * Construct product object for search Account request.
     * 
     * @param exchange
     * @return productIdentifierType @
     */
    private ProductIdentifierType constructProduct() {
        SILLogger.debug(AccountServiceConstants.SRCH_ACCNT_LOGGING_FORMAT, className, "Entering in constructProduct method");
        ProductIdentifierType productIdentifierType = new ProductIdentifierType();
        if (inboundRequest.containsKey(AccountServiceConstants.SEARCH_ACCOUNT_PRODUCT_ID) &&
                inboundRequest.get(AccountServiceConstants.SEARCH_ACCOUNT_PRODUCT_ID).get(0) != null) {
            productIdentifierType.setId(Long.parseLong(inboundRequest.get(AccountServiceConstants.SEARCH_ACCOUNT_PRODUCT_ID).get(0)));
        }
        if (inboundRequest.containsKey(AccountServiceConstants.SEARCH_ACCOUNT_PRODUCT_NAME) &&
                inboundRequest.get(AccountServiceConstants.SEARCH_ACCOUNT_PRODUCT_NAME).get(0) != null) {
            productIdentifierType.setName(inboundRequest.get(AccountServiceConstants.SEARCH_ACCOUNT_PRODUCT_NAME).get(0));
        }
        return productIdentifierType;
    }

    /**
     * 
     * Checks Advisor details for in coming search account request.
     * 
     * @param exchange
     * @return isAdvisorDetails @
     */
    private Boolean checkAdvisorQueryParams() {
        SILLogger.debug(AccountServiceConstants.SRCH_ACCNT_LOGGING_FORMAT, className, "Entering in checkAdvisorQueryParams method");
        Boolean isAdvisorDetails = false;
        if (inboundRequest.containsKey(AccountServiceConstants.SEARCH_ACCOUNT_ADVISOR_CLIENT_ID) &&
                inboundRequest.get(AccountServiceConstants.SEARCH_ACCOUNT_ADVISOR_CLIENT_ID).get(0) != null ||
                inboundRequest.containsKey(AccountServiceConstants.SEARCH_ACCOUNT_ADVISOR_FORENAME) &&
                inboundRequest.get(AccountServiceConstants.SEARCH_ACCOUNT_ADVISOR_FORENAME).get(0) != null ||
                inboundRequest.containsKey(AccountServiceConstants.SEARCH_ACCOUNT_ADVISOR_SURNAME) &&
                inboundRequest.get(AccountServiceConstants.SEARCH_ACCOUNT_ADVISOR_SURNAME).get(0) != null) {
            isAdvisorDetails = true;
        }
        return isAdvisorDetails;
    }

    /**
     * 
     * Checks member details for in coming search account request.
     * 
     * @return isMemberDetails @
     */
    private Boolean checkClientQueryParams() {
        SILLogger.debug(AccountServiceConstants.SRCH_ACCNT_LOGGING_FORMAT, className, "Entering in checkClientQueryParams method");
        Boolean isMemberDetails = false;
        if (inboundRequest.containsKey(AccountServiceConstants.SEARCH_ACCOUNT_MEMBER_CLIENT_ID) &&
                inboundRequest.get(AccountServiceConstants.SEARCH_ACCOUNT_MEMBER_CLIENT_ID).get(0) != null ||
                inboundRequest.containsKey(AccountServiceConstants.SEARCH_ACCOUNT_MEMBER_FORENAME) &&
                inboundRequest.get(AccountServiceConstants.SEARCH_ACCOUNT_MEMBER_FORENAME).get(0) != null ||
                inboundRequest.containsKey(AccountServiceConstants.SEARCH_ACCOUNT_MEMBER_SURNAME) &&
                inboundRequest.get(AccountServiceConstants.SEARCH_ACCOUNT_MEMBER_SURNAME).get(0) != null) {
            isMemberDetails = true;
        }
        return isMemberDetails;
    }

    /**
     * 
     * Checks member date of birth for in coming search account request.
     * 
     * @return isMemberDOB @
     */
    private Boolean checkClientDateOfBirthParam() {
        SILLogger.debug(AccountServiceConstants.SRCH_ACCNT_LOGGING_FORMAT, className, "Entering in checkClientDateOfBirthParam method");
        Boolean isMemberDOB = false;
        if (inboundRequest.containsKey(AccountServiceConstants.SEARCH_ACCOUNT_MEMBER_DATE_OF_BIRTH) &&
                inboundRequest.get(AccountServiceConstants.SEARCH_ACCOUNT_MEMBER_DATE_OF_BIRTH).get(0) != null) {
            isMemberDOB = true;
        }
        return isMemberDOB;
    }

    /**
     * 
     * Checks product type parameters for in coming search account request.
     * 
     * @return isProductParams @
     */
    private Boolean checkProductParams() {
        SILLogger.debug(AccountServiceConstants.SRCH_ACCNT_LOGGING_FORMAT, className, "Entering in checkProductParams method");
        Boolean isProductParams = false;
        if (inboundRequest.containsKey(AccountServiceConstants.SEARCH_ACCOUNT_PRODUCT_ID) &&
                inboundRequest.get(AccountServiceConstants.SEARCH_ACCOUNT_PRODUCT_ID).get(0) != null ||
                inboundRequest.containsKey(AccountServiceConstants.SEARCH_ACCOUNT_PRODUCT_NAME) &&
                inboundRequest.get(AccountServiceConstants.SEARCH_ACCOUNT_PRODUCT_NAME).get(0) != null) {
            isProductParams = true;
        }
        return isProductParams;
    }

    /**
     * Construct the paging range element for searchAccount request.
     * 
     * @return pagingRangeType @
     */
    private PagingRangeType constructPagingRangeType() {
        SILLogger.debug(AccountServiceConstants.SRCH_ACCNT_LOGGING_FORMAT, className, "Entering in constructPagingRangeType method");
        PagingRangeType pagingRangeType = new PagingRangeType();
        if (inboundRequest.containsKey(AccountServiceConstants.SEARCH_ACCOUNT_FIRST_RESULT) &&
                inboundRequest.get(AccountServiceConstants.SEARCH_ACCOUNT_FIRST_RESULT).get(0) != null) {
            String firstResult = inboundRequest.get(AccountServiceConstants.SEARCH_ACCOUNT_FIRST_RESULT).get(0);
            pagingRangeType.setFirstResult(Integer.parseInt(firstResult));
            if (inboundRequest.containsKey(AccountServiceConstants.SEARCH_ACCOUNT_RESULTS_PER_PAGE) &&
                    inboundRequest.get(AccountServiceConstants.SEARCH_ACCOUNT_RESULTS_PER_PAGE).get(0) != null) {
                String resultsPerPage = inboundRequest.get(AccountServiceConstants.SEARCH_ACCOUNT_RESULTS_PER_PAGE).get(0);
                pagingRangeType.setResultsPerPage(Integer.parseInt(resultsPerPage));
            }
        }
        return pagingRangeType;
    }

}
