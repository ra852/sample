////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import java.util.List;

import javax.xml.datatype.XMLGregorianCalendar;

import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.FrequencyIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.ProfileFunctionIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountDetailType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountEntityType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.InvestmentProfileType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.InvestmentProfileType.AccountProfileLink;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.FrequencyIdentifierBean;
import com.suncorp.ssp.service.integration.accountservice.bean.IncludeInRebalancingBean;
import com.suncorp.ssp.service.integration.accountservice.bean.InvestmentProfileDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.SaveAccountDetails;

/**
 * The class {@code SaveAccountRebalanceRequestUtil} does this.
 * 
 * @author U383847
 * @since 29/03/2016
 * @version 1.0
 */
public class SaveAccountRebalanceRequestUtil {
    private final String className = "SaveAccountRebalanceRequestUtil";

    /**
     * Setting Account Rebalance Details.
     * 
     * @param saveAccountDetails
     * @param saveAccountRequestType
     * @throws SILException
     */
    public void setAccountRebalanceDetails(SaveAccountDetails saveAccountDetails, AccountEntityType accountEntityType) throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_LOGGING_FORMAT, className, "Setting Account Rebalance Details");
        this.setAccountNumberDetails(saveAccountDetails, accountEntityType);
        this.setInvestmentProfileDetails(saveAccountDetails, accountEntityType);
        this.setRebalanceDetails(saveAccountDetails, accountEntityType);
    }

    /**
     * Set Account Number Details.
     * 
     * @param saveAccountDetails
     * @param accountEntityType
     */
    private void setAccountNumberDetails(SaveAccountDetails saveAccountDetails, AccountEntityType accountEntityType) {
        if (saveAccountDetails.getAccountNumber() != null && saveAccountDetails.getAccountNumber().getAccountNo() != null) {
            SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_LOGGING_FORMAT, className, "Setting Account Number Details");
            AccountIdentifierType accountIdentifierType = new AccountIdentifierType();
            AccountIdentifierType.AccountNumber accountNumber = new AccountIdentifierType.AccountNumber();
            accountNumber.setAccountNo(saveAccountDetails.getAccountNumber().getAccountNo());
            accountIdentifierType.setAccountNumber(accountNumber);
            accountEntityType.setAccount(accountIdentifierType);
        }
    }

    /**
     * Set Investment Profile Details.
     * 
     * @param saveAccountDetails
     * @param accountEntityType
     * @throws SILException 
     */
    private void setInvestmentProfileDetails(SaveAccountDetails saveAccountDetails, AccountEntityType accountEntityType) throws SILException {
        if (saveAccountDetails.getInvestmentProfiles() != null && saveAccountDetails.getInvestmentProfiles().size() > 0) {
            SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_LOGGING_FORMAT, className, "Setting Investment Profile Details");
            List<InvestmentProfileDetails> investmentProfileDetailsList = saveAccountDetails.getInvestmentProfiles();
            List<InvestmentProfileType> investmentProfileList = accountEntityType.getInvestmentProfile();
            for (InvestmentProfileDetails investmentProfileDetails : investmentProfileDetailsList) {
                InvestmentProfileType investmentProfileType = new InvestmentProfileType();
                this.setRebalanceDeleteFlag(investmentProfileType, investmentProfileDetails);
                AccountProfileLink accountProfileLink = new AccountProfileLink();
                this.setSameAsDefaultInvestmentProfile(accountProfileLink, investmentProfileDetails);
                this.setEffectiveDate(accountProfileLink, investmentProfileDetails);
                ProfileFunctionIdentifierType profileFunctionIdentifierType = new ProfileFunctionIdentifierType();
                profileFunctionIdentifierType.setCode(investmentProfileDetails.getProfileFunctionDetails().getCode());
                accountProfileLink.setProfileFunctionIdentifier(profileFunctionIdentifierType);
                investmentProfileType.setAccountProfileLink(accountProfileLink);
                investmentProfileList.add(investmentProfileType);
            }
        }
    }

    /**
     * Set Rebalance Details.
     * 
     * @param saveAccountDetails
     * @param accountEntityType
     * @throws SILException
     */
    private void setRebalanceDetails(SaveAccountDetails saveAccountDetails, AccountEntityType accountEntityType) throws SILException {
        if (saveAccountDetails.getAccountDetail() != null && saveAccountDetails.getAccountDetail().getIncludeInRebalancing() != null) {
            SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_LOGGING_FORMAT, className, "Setting Rebalance Details");
            IncludeInRebalancingBean includeRebalanceBean = saveAccountDetails.getAccountDetail().getIncludeInRebalancing();
            AccountDetailType.IncludeInRebalancing includeInRebalancing = new AccountDetailType.IncludeInRebalancing();

            if (includeRebalanceBean.getRebalancingFrequency() != null) {
                this.checkNextRebalanceDate(includeRebalanceBean, includeInRebalancing);
            }
            includeInRebalancing.setRebalanceImmediately(Boolean.parseBoolean(includeRebalanceBean.getRebalanceImmediately()));
            includeInRebalancing.setIncludeInRebalance(Boolean.parseBoolean(includeRebalanceBean.getIncludeInRebalance()));
            AccountEntityType.AccountDetail accountDetail = new AccountEntityType.AccountDetail();
            accountDetail.setIncludeInRebalancing(includeInRebalancing);
            accountEntityType.setAccountDetail(accountDetail);
        }
    }

    /**
     * Check Next Rebalance Date.
     * 
     * @param includeRebalanceBean
     * @param nextRebalanceDate
     * @param includeInRebalancing
     * @throws SILException
     */
    private void checkNextRebalanceDate(IncludeInRebalancingBean includeRebalanceBean, AccountDetailType.IncludeInRebalancing includeInRebalancing)
            throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_LOGGING_FORMAT, className, "Checking Next Rebalance Date");
        XMLGregorianCalendar nextRebalanceDate = null;
        FrequencyIdentifierBean frequencyIdentifierBean = includeRebalanceBean.getRebalancingFrequency();
        nextRebalanceDate = SILUtil.calculateNextRebalanceDate(frequencyIdentifierBean.getName());
        this.setRebalancingFrequencyDetails(frequencyIdentifierBean, includeInRebalancing);
        if (nextRebalanceDate != null) {
            includeInRebalancing.setNextRebalanceDate(nextRebalanceDate);
        }
    }

    /**
     * Set Rebalance Frequency Details.
     * 
     * @param frequencyIdentifierBean
     * @param includeInRebalancing
     */
    private void setRebalancingFrequencyDetails(FrequencyIdentifierBean frequencyIdentifierBean,
            AccountDetailType.IncludeInRebalancing includeInRebalancing) {
        SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_LOGGING_FORMAT, className, "Setting Rebalance Frequency Details");
        FrequencyIdentifierType frequencyIdentifierType = new FrequencyIdentifierType();
        frequencyIdentifierType.setName(frequencyIdentifierBean.getName());
        frequencyIdentifierType.setFreqSetCode(frequencyIdentifierBean.getFreqSetCode());
        includeInRebalancing.setRebalancingFrequency(frequencyIdentifierType);
    }

    /**
     * Set Rebalance Delete Flag.
     * 
     * @param investmentProfileType
     * @param investmentProfileDetails
     */
    private void setRebalanceDeleteFlag(InvestmentProfileType investmentProfileType, InvestmentProfileDetails investmentProfileDetails) {
        if (investmentProfileDetails.getDeleteFlag() != null) {
            SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_LOGGING_FORMAT, className, "Setting Rebalance Delete Flag");
            investmentProfileType.setDelete(Boolean.parseBoolean(investmentProfileDetails.getDeleteFlag()));
        }
    }

    /**
     * Set Same As Default Investment Profile.
     * 
     * @param accountProfileLink
     * @param investmentProfileDetails
     */
    private void setSameAsDefaultInvestmentProfile(AccountProfileLink accountProfileLink, InvestmentProfileDetails investmentProfileDetails) {
        if (investmentProfileDetails.getSameAsDefaultInvestmentProfile() != null) {
            SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_LOGGING_FORMAT, className, "Setting Same As Default Investment Profile");
            accountProfileLink.setSameAsDefaultInvestmentProfile(Boolean.parseBoolean(investmentProfileDetails.getSameAsDefaultInvestmentProfile()));
        }
    }
    
    /**
     * 
     * Set Effective Date.
     * 
     * @param accountProfileLink
     * @param investmentProfileDetails
     * @throws SILException
     */
    private void setEffectiveDate(AccountProfileLink accountProfileLink, InvestmentProfileDetails investmentProfileDetails) throws SILException {
        if (investmentProfileDetails.getAccountProfileLinkDetails() != null &&
                investmentProfileDetails.getAccountProfileLinkDetails().getEffectiveDate() != null) {
            SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_LOGGING_FORMAT, className, "Setting EffectiveDate");
            accountProfileLink.setEffectiveDate(SILUtil.convertStringToXMLGregorianCalendar(investmentProfileDetails.getAccountProfileLinkDetails()
                    .getEffectiveDate(), CommonConstants.DATE_TIME_FORMAT));
        }
    }
}
