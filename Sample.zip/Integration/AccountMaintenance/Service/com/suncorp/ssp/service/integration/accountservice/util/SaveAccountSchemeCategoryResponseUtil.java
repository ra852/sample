////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import com.sonatacentral.service.v30.wrap.account.SaveAccountSchemeCategoryResponseType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.SaveAccountSchemeCategoryResponse;

/**
 * The class {@code SaveAccountSchemeCategoryResponseUtil} is a util class used to retrieve response.
 * 
 * @author u385424
 * @since 20/09/2016
 * @version 1.0
 */
public class SaveAccountSchemeCategoryResponseUtil {
    private final String className = "SaveAccountSchemeCategoryResponseUtil";
    private SaveAccountSchemeCategoryResponseType inboundResponse;

    /**
     * This is a parameterized constructor.
     * 
     * @param inboundResponse
     */
    public SaveAccountSchemeCategoryResponseUtil(SaveAccountSchemeCategoryResponseType inboundResponse) {
        this.inboundResponse = inboundResponse;
    }

    /**
     * This method constructs SaveAccountSchemeCategoryResponse object from response.
     * 
     * @param outboundResponse
     */
    public void setOutboundResponse(SaveAccountSchemeCategoryResponse outboundResponse) throws SILException {
        if (inboundResponse != null) {
            SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_SCHEME_CATEGORY_LOGGING_FORMAT, className, "Entering transform()");
            if (inboundResponse.getAccount() != null && inboundResponse.getAccount().getAccountNumber() != null &&
                    inboundResponse.getAccount().getAccountNumber().getAccountNo() != null && inboundResponse.getSchemeCategory() != null &&
                    inboundResponse.getSchemeCategory().getId() != null) {
                outboundResponse.setResponse(AccountServiceConstants.SAVE_ACCOUNT_SCHEME_CATEGORY_SUCCESS_MSG);
            }
        } else {
            throw new SILException(AccountServiceConstants.INVALID_RESPONSE_FROM_SONATA);
        }

    }

}
