////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import java.util.ArrayList;
import java.util.List;

import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.AdvisorGroupType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.AccountExpenseGroupOverrideType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CategoryType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.ExpenseGroupIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.ExternalRefType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.GenericVariableType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.GenericVariableType.Value;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.NoteCategoryIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.NoteTemplateIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.NoteType;
import com.sonatacentral.service.v30.globaltypes.common.marketing.marketinggrouptype.MarketingCampaignIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.scheme.schemegrouptype.SchemeCategoryIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.scheme.schemegrouptype.SchemeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.scheme.schemegrouptype.SchemeLocationIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountDetailType.DollarCostAveraging;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountDetailType.IncludeInRebalancing;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountRestrictionType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.BeneficiaryType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.ClientAccountRelationshipType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.FamilyGroupIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.FamilyGroupType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.InvestmentProfileType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.RegularPlanType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.SchemeLocationHistoryType;
import com.sonatacentral.service.v30.globaltypes.wrap.product.productgrouptype.ProductIdentifierType;
import com.sonatacentral.service.v30.wrap.account.GetAccountDetailsResponseType;
import com.sonatacentral.service.v30.wrap.account.GetAccountDetailsResponseType.AccountDetails;
import com.sonatacentral.service.v30.wrap.account.GetAccountDetailsResponseType.AccountDetails.AccountDetail;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.AccountDetailBean;
import com.suncorp.ssp.service.integration.accountservice.bean.AccountDetailsList;
import com.suncorp.ssp.service.integration.accountservice.bean.AdvisorGroupBean;
import com.suncorp.ssp.service.integration.accountservice.bean.BeneficiaryDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.CategoryBean;
import com.suncorp.ssp.service.integration.accountservice.bean.ClientAccountRelationshipBean;
import com.suncorp.ssp.service.integration.accountservice.bean.CurrentAccountExpenseGroupBean;
import com.suncorp.ssp.service.integration.accountservice.bean.DollarCostAveragingBean;
import com.suncorp.ssp.service.integration.accountservice.bean.ExternalReference;
import com.suncorp.ssp.service.integration.accountservice.bean.FamilyGroupDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.FamilyGroupIdentifier;
import com.suncorp.ssp.service.integration.accountservice.bean.GenericVariableBean;
import com.suncorp.ssp.service.integration.accountservice.bean.GetAccountDetailsResponse;
import com.suncorp.ssp.service.integration.accountservice.bean.IdentityIdentifier;
import com.suncorp.ssp.service.integration.accountservice.bean.IncludeInRebalancingBean;
import com.suncorp.ssp.service.integration.accountservice.bean.InvestmentProfileDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.MarketingCampaignDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.NoteBean;
import com.suncorp.ssp.service.integration.accountservice.bean.NoteCategoryBean;
import com.suncorp.ssp.service.integration.accountservice.bean.NoteTemplateBean;
import com.suncorp.ssp.service.integration.accountservice.bean.ProductDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.RegularPlanBean;
import com.suncorp.ssp.service.integration.accountservice.bean.RestrictionBean;
import com.suncorp.ssp.service.integration.accountservice.bean.SchemeCategoryBean;
import com.suncorp.ssp.service.integration.accountservice.bean.SchemeIdentifier;
import com.suncorp.ssp.service.integration.accountservice.bean.SchemeLocationHistoryBean;
import com.suncorp.ssp.service.integration.accountservice.bean.SchemeLocationIdentifier;
import com.suncorp.ssp.service.integration.accountservice.bean.ValueBean;

/**
 * The class {@code GetAccountDetailsListResponseUtil} is used as a util class for preparing GetAccountDetailsList request.
 * 
 * @author u387938
 * @since 23/12/2015
 * @version 1.0
 */
public class GetAccountDetailsListResponseUtil {
    private final String className = "GetAccountDetailsListResponseUtil";
    private GetAccountDetailsResponseType getAccountDetailsResponseType;

    public GetAccountDetailsListResponseUtil(GetAccountDetailsResponseType getAccountDetailsResponseType) {
        this.getAccountDetailsResponseType = getAccountDetailsResponseType;
    }

    /**
     * This method constructs the GetAccountDetailsResponse object from response.
     * 
     * @param getAccountDetailsResponse
     * @throws SILException
     */
    public void setAccountDetailsListResponse(GetAccountDetailsResponse getAccountDetailsResponse) throws SILException {
        if (this.getAccountDetailsResponseType != null) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className, "Entering in setAccountDetailsListResponse");
            List<AccountDetails> accountDetailsListType = getAccountDetailsResponseType.getAccountDetails();
            List<AccountDetailsList> accountDetailsLists = new ArrayList<AccountDetailsList>();
            AccountServiceUtil accountServiceCommonUtil = new AccountServiceUtil();
            if (accountDetailsListType != null && accountDetailsListType.size() > 0) {
                for (AccountDetails accountDetailsType : accountDetailsListType) {
                    setAccountDetails(accountDetailsLists, accountServiceCommonUtil, accountDetailsType);
                }
                getAccountDetailsResponse.setAccountDetailsList(accountDetailsLists);
            }

        } else {
            throw new SILException(AccountServiceConstants.INVALID_RESPONSE_FROM_SONATA);
        }
    }

    /**
     * 
     * This method set response child blocks in GetAccountDetailsResponse object from response.
     * 
     * @param accountDetailsLists
     * @param accountServiceCommonUtil
     * @param accountDetailsType
     * @throws SILException
     */
    private void setAccountDetails(List<AccountDetailsList> accountDetailsLists, AccountServiceUtil accountServiceCommonUtil,
            AccountDetails accountDetailsType) throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className, "Entering in setAAccountDetails");
        AccountDetailsList accountDetailsList = new AccountDetailsList();
        if (accountDetailsType != null) {
            accountDetailsList.setAccount(retrieveAccount(accountDetailsType.getAccount()));
            if (accountDetailsType.getAccountDetail() != null) {
                accountDetailsList.setAccountDetail(retrieveAccountDetail(accountDetailsType.getAccountDetail()));
            }
            if (accountDetailsType.getProduct() != null) {
                accountDetailsList.setProduct(retrieveProductDetails(accountDetailsType.getProduct()));
            }
            if (accountDetailsType.getScheme() != null) {
                accountDetailsList.setScheme(retrieveSchemeDetails(accountDetailsType.getScheme()));
            }
            if (accountDetailsType.getSchemeCategory() != null) {
                accountDetailsList.setSchemeCategory(retrieveSchemeCategoryDetails(accountDetailsType.getSchemeCategory()));
            }
            setOtherAttributes(accountDetailsType, accountDetailsList);
            setAccountDetailsparam(accountServiceCommonUtil, accountDetailsType, accountDetailsList);
            setAccountDetailsparamFirst(accountDetailsType, accountDetailsList);
            accountDetailsLists.add(accountDetailsList);
        }
    }

    /**
     * Set Other Attributes value for the AccountDetailsList
     * 
     * @param accountDetailsType
     * @param accountDetailsList
     * @throws SILException
     */
    private void setOtherAttributes(AccountDetails accountDetailsType, AccountDetailsList accountDetailsList) throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className, "Entering in setOtherAttributes");
        if (accountDetailsType.getMarketingCampaign() != null) {
            accountDetailsList.setMarketingCampaign(retrieveMarketingCampaignDetails(accountDetailsType.getMarketingCampaign()));
        }
        if (accountDetailsType.getFamilyGroupDetail() != null) {
            accountDetailsList.setFamilyGroupDetail(retrieveFamilyGroupDetails(accountDetailsType.getFamilyGroupDetail()));
        }
        accountDetailsList.setRestriction(retrieveRestrictionDetailsList(accountDetailsType.getRestriction()));
        SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className, "Exiting from setOtherAttributes");
    }

    /**
     * Populate Family Group Details.
     * 
     * @param familyGroupDetail
     * @return
     * @throws SILException
     */
    private List<FamilyGroupDetails> retrieveFamilyGroupDetails(List<FamilyGroupType> familyGroupDetail) throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className, "Entering in retrieveFamilyGroupDetails");
        List<FamilyGroupDetails> FamilyGroupDetailsList = new ArrayList<FamilyGroupDetails>();
        String loggerType = AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT;
        AccountServiceUtil accountServiceCommonUtil = new AccountServiceUtil();
        for (FamilyGroupType familyGroupType : familyGroupDetail) {
            FamilyGroupDetails familyGroupDetails = new FamilyGroupDetails();
            familyGroupDetails.setFamilyGroupIdentifier(retrieveFamilyGroupIdentifierDetails(familyGroupType.getFamilyGroupIdentifier()));
            familyGroupDetails.setFamilyGroupName(familyGroupType.getFamilyGroupName());
            familyGroupDetails.setGroupType(accountServiceCommonUtil.retrieveCode(familyGroupType.getGroupType(), loggerType));
            familyGroupDetails.setStatus(accountServiceCommonUtil.retrieveCode(familyGroupType.getStatus(), loggerType));
            FamilyGroupDetailsList.add(familyGroupDetails);
        }
        SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className, "Exiting from retrieveFamilyGroupDetails");
        return FamilyGroupDetailsList;
    }

    /**
     * Populate Family Group Identifier.
     * 
     * @param familyGroupIdentifier
     * @return
     */
    private FamilyGroupIdentifier retrieveFamilyGroupIdentifierDetails(FamilyGroupIdentifierType familyGroupIdentifierType) {
        SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className, "Entering in FamilyGroupIdentifier");
        FamilyGroupIdentifier familyGroupIdentifier = new FamilyGroupIdentifier();
        if (familyGroupIdentifierType != null) {
            familyGroupIdentifier.setId(String.valueOf(familyGroupIdentifierType.getId()));
            familyGroupIdentifier.setName(familyGroupIdentifierType.getName());
        } else {
            familyGroupIdentifier.setId(AccountServiceConstants.EMPTY_VALUE);
            familyGroupIdentifier.setName(AccountServiceConstants.EMPTY_VALUE);
        }
        SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className, "Exiting from FamilyGroupIdentifier");
        return familyGroupIdentifier;
    }

    /**
     * Retrieve Account Details parameters.
     * 
     * @param accountServiceCommonUtil
     * @param accountDetailsType
     * @param accountDetailsList
     * @throws SILException
     */
    private void setAccountDetailsparam(AccountServiceUtil accountServiceCommonUtil, AccountDetails accountDetailsType,
            AccountDetailsList accountDetailsList) throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className, "Entering in setAccountDetailsparam");
        if (accountDetailsType.getCurrentExpenseGroup() != null) {
            accountDetailsList.setCurrentExpenseGroup(retrieveExpenseGroup(accountDetailsType.getCurrentExpenseGroup()));
        }
        accountDetailsList.setClientAccountRelationships(retrieveClientAccountRelationshipDetailsLst(accountDetailsType
                .getClientAccountRelationship()));
        if (accountDetailsType.getSchemeLocation() != null) {
            accountDetailsList.setSchemeLocation(retrieveSchemeLocationDetails(accountDetailsType.getSchemeLocation()));
        }
        accountDetailsList.setInvestmentProfiles(retrieveInvestmentProfileDetailsLst(accountDetailsType.getInvestmentProfile()));
        accountDetailsList.setAdvisorGroups(retrieveAdvisorGroupDetailsLst(accountDetailsType.getAdvisorGroup()));
        accountDetailsList.setBeneficiaries(retrieveBeneficiariesDetailsLst(accountDetailsType.getBeneficiary()));
        if (accountDetailsType.getAccountBalance() != null) {
            accountDetailsList.setAccountBalance(accountServiceCommonUtil.retrieveBigDecimalValue(accountDetailsType.getAccountBalance(),
                    AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
        }
        if (accountDetailsType.getGenericVariable() != null) {
            accountDetailsList.setGenericVariables(retrieveGenericVariablesList(accountDetailsType.getGenericVariable()));
        }
        accountDetailsList.setSchemeLocationHistories(retrieveSchemeLocationHistoryDetailsLst(accountDetailsType.getSchemeLocationHistory()));
        accountDetailsList.setNotes(retrieveNotesLst(accountDetailsType.getNote()));
        accountDetailsList.setRegularContributionPlans(retrieveRegularContributionPlansDetailsList(accountDetailsType.getRegularContributionPlan()));
    }

    /**
     * Retrieve Account Details parameters.
     * 
     * @param accountServiceCommonUtil
     * @param accountDetailsType
     * @param accountDetailsList
     * @throws SILException
     */
    private void setAccountDetailsparamFirst(AccountDetails accountDetailsType, AccountDetailsList accountDetailsList) throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className, "Entering in setAccountDetailsparamFirst()");
        if (accountDetailsType.getCurrentAccountExpenseGroup() != null) {
            accountDetailsList.setCurrentAccountExpenseGroup(retrieveCurrentAccountExpenseGroup(accountDetailsType.getCurrentAccountExpenseGroup()));
        }
        if (accountDetailsType.getExternalReference() != null && accountDetailsType.getExternalReference().size() > 0) {
            accountDetailsList.setExternalReferences(retrieveExternalReferences(accountDetailsType.getExternalReference()));
        }
        if (accountDetailsType.getInsurance() != null && accountDetailsType.getInsurance().size() > 0) {
            accountDetailsList.setInsurances(new AccountInsuranceUtil().retrieveInsuranceDetails(accountDetailsType.getInsurance()));
        }
    }

    /**
     * Does this.
     * 
     * @param externalReference
     * @return
     */
    private List<ExternalReference> retrieveExternalReferences(List<ExternalRefType> externalReferenceTypeList) {
        List<ExternalReference> externalReferenceList = new ArrayList<ExternalReference>();
        for (ExternalRefType externalRefType : externalReferenceTypeList) {
            if (externalRefType != null) {
                ExternalReference externalReference = new ExternalReference();
                externalReference.setReference(externalRefType.getReference());
                externalReference.setReferenceCode(externalRefType.getReferenceCode());
                externalReferenceList.add(externalReference);
            }
        }
        return externalReferenceList;
    }

    /**
     * This method constructs the Account object from response.
     * 
     * @param accountIdentifierType
     * @return accountDetails
     * @throws SILException
     */
    private com.suncorp.ssp.service.integration.accountservice.bean.AccountDetails retrieveAccount(AccountIdentifierType accountIdentifierType)
            throws SILException {
        com.suncorp.ssp.service.integration.accountservice.bean.AccountDetails accountDetails =
                new com.suncorp.ssp.service.integration.accountservice.bean.AccountDetails();
        String loggerType = AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT;
        if (accountIdentifierType != null) {
            AccountServiceUtil accountServiceCommonUtil = new AccountServiceUtil();
            SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className, "Entering in retrieveAccount method");
            accountDetails.setId(accountServiceCommonUtil.retrieveLongValue(accountIdentifierType.getId(), loggerType));
            accountDetails.setName(accountIdentifierType.getName());
            accountDetails.setAccountNumber(accountServiceCommonUtil.retrieveAccountNumberDetails(accountIdentifierType.getAccountNumber(),
                    loggerType));
            accountDetails.setAccountExternalRef(accountServiceCommonUtil.retrieveExternalRef(accountIdentifierType.getAccountExternalRef(),
                    loggerType));
            accountDetails.setStatusCode(accountServiceCommonUtil.retrieveCode(accountIdentifierType.getStatusCode(), loggerType));
            accountDetails.setAudit(accountServiceCommonUtil.retrieveAudit(accountIdentifierType.getAudit(), loggerType));
            accountDetails.setAccountPointer(accountServiceCommonUtil.retrieveAccountPointerDetails(accountIdentifierType.getAccountPointer(),
                    loggerType));
            accountDetails.setMasterScheme(accountServiceCommonUtil.retrieveMasterSchemeDetails(accountIdentifierType.getMasterScheme(), loggerType));
        } else {
            accountDetails = retrieveEmptyAccount();
        }
        return accountDetails;
    }

    /**
     * This method constructs Empty Account object.
     * 
     * @return accountDetails
     */
    private com.suncorp.ssp.service.integration.accountservice.bean.AccountDetails retrieveEmptyAccount() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className, "Entering in retrieveEmptyAccount method");
        AccountServiceUtil accountServiceCommonUtil = new AccountServiceUtil();
        com.suncorp.ssp.service.integration.accountservice.bean.AccountDetails accountDetails =
                new com.suncorp.ssp.service.integration.accountservice.bean.AccountDetails();
        accountDetails.setId(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        accountDetails.setName(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        accountDetails.setAccountNumber(accountServiceCommonUtil
                .retrieveEmptyAccountNumberDetails(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
        accountDetails.setAccountExternalRef(accountServiceCommonUtil
                .retrieveEmptyExternalRef(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
        accountDetails.setStatusCode(accountServiceCommonUtil.retrieveEmptyCode(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
        accountDetails.setAudit(accountServiceCommonUtil.retrieveEmptyAudit(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
        accountDetails.setAccountPointer(accountServiceCommonUtil
                .retrieveEmptyAccountPointer(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
        accountDetails.setMasterScheme(accountServiceCommonUtil
                .retrieveEmptyMasterSchemeDetails(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
        SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className, "Exiting in retrieveEmptyAccount method");
        return accountDetails;
    }

    /**
     * 
     * This method constructs AccountDetails list object.
     * 
     * @param accountDetail
     * @return accountDetailBean
     * @throws SILException
     */
    private AccountDetailBean retrieveAccountDetail(AccountDetail accountDetail) throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className, "Entering in retrieveAccountDetail method");
        AccountDetailBean accountDetailBean = new AccountDetailBean();
        String loggerType = AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT;
        if (accountDetail != null) {
            AccountServiceUtil accountServiceCommonUtil = new AccountServiceUtil();
            SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className, "Entering in retrieveAccountDetail method");
            accountDetailBean.setCommencementDate(accountServiceCommonUtil.retrieveDateValue(accountDetail.getCommencementDate(), loggerType));
            accountDetailBean.setAccountDesignation(accountDetail.getAccountDesignation());
            accountDetailBean.setDateJoinedParticipant(accountServiceCommonUtil.retrieveDateValue(accountDetail.getDateJoinedParticipant(),
                    loggerType));
            accountDetailBean.setEligibleServiceDate(accountServiceCommonUtil.retrieveDateValue(accountDetail.getEligibleServiceDate(), loggerType));
            accountDetailBean.setPreventWithdrawal(accountServiceCommonUtil.retrieveBooleanValue(accountDetail.isPreventWithdrawal(), loggerType));
            accountDetailBean.setStaff(accountServiceCommonUtil.retrieveBooleanValue(accountDetail.isStaff(), loggerType));
            accountDetailBean.setAllOwnersToSign(accountServiceCommonUtil.retrieveBooleanValue(accountDetail.isAllOwnersToSign(), loggerType));
            accountDetailBean.setIncludeInRebalancing(retrieveIncludeInRebalancingDetails(accountDetail.getIncludeInRebalancing()));
            accountDetailBean.setDollarCostAveraging(retrieveDollarCostAveragingDetails(accountDetail.getDollarCostAveraging()));
            accountDetailBean.setStatusCode(accountServiceCommonUtil.retrieveCode(accountDetail.getStatusCode(), loggerType));
            accountDetailBean.setAdaStatusCode(accountServiceCommonUtil.retrieveCode(accountDetail.getAdaStatusCode(), loggerType));
            accountDetailBean.setOpenReason(accountServiceCommonUtil.retrieveCode(accountDetail.getOpenReason(), loggerType));
        }
        return accountDetailBean;
    }

    /**
     * 
     * This method constructs IncludeInRebalancing object from repsonse.
     * 
     * @param includeInRebalancingType
     * @return includeInRebalancingBean
     * @throws SILException
     */
    private IncludeInRebalancingBean retrieveIncludeInRebalancingDetails(IncludeInRebalancing includeInRebalancingType) throws SILException {
        IncludeInRebalancingBean includeInRebalancingBean = new IncludeInRebalancingBean();
        if (includeInRebalancingType != null) {
            AccountServiceUtil accountServiceCommonUtil = new AccountServiceUtil();
            SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className,
                    "Entering in retrieveIncludeInRebalancingDetails method");
            includeInRebalancingBean.setRebalancingFrequency(accountServiceCommonUtil.retrieveFrequencyIdentifier(
                    includeInRebalancingType.getRebalancingFrequency(), AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
            includeInRebalancingBean.setNextRebalanceDate(accountServiceCommonUtil.retrieveDateValue(includeInRebalancingType.getNextRebalanceDate(),
                    AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
            includeInRebalancingBean.setRebalanceImmediately(accountServiceCommonUtil.retrieveBooleanValue(
                    includeInRebalancingType.isRebalanceImmediately(), AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
            includeInRebalancingBean.setIncludeInRebalance(accountServiceCommonUtil.retrieveBooleanValue(
                    includeInRebalancingType.isIncludeInRebalance(), AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
            includeInRebalancingBean.setInstructorCategoryCode(accountServiceCommonUtil.retrieveCode(
                    includeInRebalancingType.getInstructorCategoryCode(), AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));

        } else {
            includeInRebalancingBean = retrieveEmptyIncludeInRebalancingDetails();
        }
        return includeInRebalancingBean;

    }

    /**
     * 
     * This method constructs empty IncludeInRebalancing object.
     * 
     * @return includeInRebalancingBean
     * @throws SILException
     */
    private IncludeInRebalancingBean retrieveEmptyIncludeInRebalancingDetails() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className,
                "Entering in retrieveEmptyIncludeInRebalancingDetails method");
        IncludeInRebalancingBean includeInRebalancingBean = new IncludeInRebalancingBean();
        AccountServiceUtil accountServiceCommonUtil = new AccountServiceUtil();
        includeInRebalancingBean.setRebalancingFrequency(accountServiceCommonUtil
                .retrieveEmptyFrequencyIdentifier(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
        includeInRebalancingBean.setNextRebalanceDate(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        includeInRebalancingBean.setRebalanceImmediately(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        includeInRebalancingBean.setIncludeInRebalance(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        includeInRebalancingBean.setInstructorCategoryCode(accountServiceCommonUtil
                .retrieveEmptyCode(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));

        return includeInRebalancingBean;

    }

    /**
     * 
     * This method constructs DollarCostAveraging object from response.
     * 
     * @param dollarCostAveragingType
     * @return dollarCostAveragingBean
     * @throws SILException
     */
    private DollarCostAveragingBean retrieveDollarCostAveragingDetails(DollarCostAveraging dollarCostAveragingType) throws SILException {
        DollarCostAveragingBean dollarCostAveragingBean = new DollarCostAveragingBean();
        if (dollarCostAveragingType != null) {
            AccountServiceUtil accountServiceCommonUtil = new AccountServiceUtil();
            SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className,
                    "Entering in retrieveDollarCostAveragingDetails method");
            dollarCostAveragingBean.setFrequency(accountServiceCommonUtil.retrieveFrequencyIdentifier(dollarCostAveragingType.getFrequency(),
                    AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
            dollarCostAveragingBean.setNextDueDate(accountServiceCommonUtil.retrieveDateValue(dollarCostAveragingType.getNextDueDate(),
                    AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
            dollarCostAveragingBean.setSwitchAmount(accountServiceCommonUtil.retrieveBigDecimalValue(dollarCostAveragingType.getSwitchAmount(),
                    AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
            dollarCostAveragingBean.setInstructorCategoryCode(accountServiceCommonUtil.retrieveCode(
                    dollarCostAveragingType.getInstructorCategoryCode(), AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
            dollarCostAveragingBean.setSourceFund(accountServiceCommonUtil.retrieveFundIdentifier(dollarCostAveragingType.getSourceFund(),
                    AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));

        } else {
            dollarCostAveragingBean = retrieveEmptyDollarCostAveragingDetails();
        }
        return dollarCostAveragingBean;

    }

    /**
     * 
     * This method constructs empty DollarCostAveraging object.
     * 
     * @return dollarCostAveragingBean
     * @throws SILException
     */
    private DollarCostAveragingBean retrieveEmptyDollarCostAveragingDetails() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className,
                "Entering in retrieveEmptyDollarCostAveragingDetails method");
        DollarCostAveragingBean dollarCostAveragingBean = new DollarCostAveragingBean();
        AccountServiceUtil accountServiceCommonUtil = new AccountServiceUtil();
        dollarCostAveragingBean.setFrequency(accountServiceCommonUtil
                .retrieveEmptyFrequencyIdentifier(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
        dollarCostAveragingBean.setNextDueDate(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        dollarCostAveragingBean.setSwitchAmount(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        dollarCostAveragingBean.setInstructorCategoryCode(accountServiceCommonUtil
                .retrieveEmptyCode(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
        dollarCostAveragingBean.setSourceFund(accountServiceCommonUtil
                .retrieveEmptyFundIdentifier(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));

        return dollarCostAveragingBean;

    }

    /**
     * 
     * This method constructs ClientAccountRelationship Details List object from response.
     * 
     * @param clientAccountRelationshipTypeLst
     * @return accountRelationshipBeansLst
     * @throws SILException
     */
    public List<ClientAccountRelationshipBean> retrieveClientAccountRelationshipDetailsLst(
            List<ClientAccountRelationshipType> clientAccountRelationshipTypeLst) throws SILException {
        List<ClientAccountRelationshipBean> accountRelationshipBeansLst = new ArrayList<ClientAccountRelationshipBean>();
        AccountServiceUtil commonUtil = new AccountServiceUtil();
        if (clientAccountRelationshipTypeLst != null && clientAccountRelationshipTypeLst.size() > 0) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className,
                    "Entering in retrieveClientAccountRelationshipDetailsLst method");
            for (ClientAccountRelationshipType clientAccountRelationshipType : clientAccountRelationshipTypeLst) {
                if (clientAccountRelationshipType != null) {
                    accountRelationshipBeansLst.add(commonUtil.retrieveClientAccountRelationshipDetails(clientAccountRelationshipType,
                            AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
                }
            }
        }
        return accountRelationshipBeansLst;
    }

    /**
     * 
     * This method constructs InvestmentProfile Details List object from response.
     * 
     * @param investmentProfileTypeLst
     * @return investmentProfileDetailsLst
     * @throws SILException
     */
    public List<InvestmentProfileDetails> retrieveInvestmentProfileDetailsLst(List<InvestmentProfileType> investmentProfileTypeLst)
            throws SILException {
        List<InvestmentProfileDetails> investmentProfileDetailsLst = new ArrayList<InvestmentProfileDetails>();
        AccountServiceUtil commonUtil = new AccountServiceUtil();
        if (investmentProfileTypeLst != null && investmentProfileTypeLst.size() > 0) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className,
                    "Entering in retrieveInvestmentProfileDetailsLst method");
            for (InvestmentProfileType investmentProfileType : investmentProfileTypeLst) {
                if (investmentProfileType != null) {
                    investmentProfileDetailsLst.add(commonUtil.retrieveInvestmentProfileDetails(investmentProfileType,
                            AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
                }
            }
        }
        return investmentProfileDetailsLst;
    }

    /**
     * 
     * This method constructs AdvisorGroup Details List object from response.
     * 
     * @param advisorGroupTypesLst
     * @return advisorGroupBeansLst
     * @throws SILException
     */
    public List<AdvisorGroupBean> retrieveAdvisorGroupDetailsLst(List<AdvisorGroupType> advisorGroupTypesLst) throws SILException {
        List<AdvisorGroupBean> advisorGroupBeansLst = new ArrayList<AdvisorGroupBean>();
        AccountServiceUtil commonUtil = new AccountServiceUtil();
        if (advisorGroupTypesLst != null && advisorGroupTypesLst.size() > 0) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className,
                    "Entering in retrieveAdvisorGroupDetailsLst method");
            for (AdvisorGroupType advisorGroupType : advisorGroupTypesLst) {
                if (advisorGroupType != null) {
                    advisorGroupBeansLst.add(commonUtil.retrieveAdvisorGroupDetails(advisorGroupType,
                            AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
                }
            }
        }
        return advisorGroupBeansLst;
    }

    /**
     * 
     * This method constructs Beneficiaries Details List object from response.
     * 
     * @param beneficiaryTypesLst
     * @return beneficiaryDetailsLst
     * @throws SILException
     */
    public List<BeneficiaryDetails> retrieveBeneficiariesDetailsLst(List<BeneficiaryType> beneficiaryTypesLst) throws SILException {
        List<BeneficiaryDetails> beneficiaryDetailsLst = new ArrayList<BeneficiaryDetails>();
        if (beneficiaryTypesLst != null && beneficiaryTypesLst.size() > 0) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className,
                    "Entering in retrieveBeneficiariesDetailsLst method");
            for (BeneficiaryType beneficiaryType : beneficiaryTypesLst) {
                if (beneficiaryType != null) {
                    beneficiaryDetailsLst.add(retrieveBeneficiariesDetails(beneficiaryType));
                }
            }
        }
        return beneficiaryDetailsLst;
    }

    /**
     * 
     * This method constructs Beneficiaries Details object from response.
     * 
     * @param beneficiaryType
     * @return beneficiaryDetails
     * @throws SILException
     */
    public BeneficiaryDetails retrieveBeneficiariesDetails(BeneficiaryType beneficiaryType) throws SILException {
        BeneficiaryDetails beneficiaryDetails = new BeneficiaryDetails();
        AccountServiceUtil commonUtil = new AccountServiceUtil();
        if (beneficiaryType != null) {
            SILLogger
                    .debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className, "Entering in retrieveBeneficiariesDetails method");
            beneficiaryDetails.setClientAccountRelationship(commonUtil.retrieveClientAccountRelationshipidentifier(
                    beneficiaryType.getClientAccountRelationship(), AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
            if (beneficiaryType.getClientAccountRelationship() != null) {
                beneficiaryDetails.setId(commonUtil.retrieveLongValue(beneficiaryType.getClientAccountRelationship().getId(),
                        AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
            }
            beneficiaryDetails.setCategory(commonUtil.retrieveCode(beneficiaryType.getCategory(),
                    AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
            beneficiaryDetails
                    .setType(commonUtil.retrieveCode(beneficiaryType.getType(), AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
            beneficiaryDetails.setRelationship(commonUtil.retrieveCode(beneficiaryType.getRelationship(),
                    AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
            beneficiaryDetails.setAdviceReceived(commonUtil.retrieveBooleanValue(beneficiaryType.isAdviceReceived(),
                    AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
            beneficiaryDetails.setDistributionOutlet(commonUtil.retrieveAdvisorDetails(beneficiaryType.getDistributionOutlet(),
                    AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
        }
        return beneficiaryDetails;
    }

    /**
     * 
     * This method constructs SchemeLocationHistory Details List object from response.
     * 
     * @param schemeLocationHistoryTypeLst
     * @return schemeLocationHistoryBeanLst
     * @throws SILException
     */
    public List<SchemeLocationHistoryBean> retrieveSchemeLocationHistoryDetailsLst(List<SchemeLocationHistoryType> schemeLocationHistoryTypeLst)
            throws SILException {
        List<SchemeLocationHistoryBean> schemeLocationHistoryBeanLst = new ArrayList<SchemeLocationHistoryBean>();
        if (schemeLocationHistoryTypeLst != null && schemeLocationHistoryTypeLst.size() > 0) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className,
                    "Entering in retrieveSchemeLocationHistoryDetailsLst method");
            for (SchemeLocationHistoryType schemeLocationHistoryType : schemeLocationHistoryTypeLst) {
                if (schemeLocationHistoryType != null) {
                    schemeLocationHistoryBeanLst.add(retrieveSchemeLocationHistoryDetails(schemeLocationHistoryType));
                }
            }
        }
        return schemeLocationHistoryBeanLst;
    }

    /**
     * 
     * This method constructs SchemeLocationHistory Details object from response.
     * 
     * @param schemeLocationHistoryType
     * @return schemeLocationHistoryBean
     * @throws SILException
     */
    public SchemeLocationHistoryBean retrieveSchemeLocationHistoryDetails(SchemeLocationHistoryType schemeLocationHistoryType) throws SILException {
        SchemeLocationHistoryBean schemeLocationHistoryBean = new SchemeLocationHistoryBean();
        AccountServiceUtil commonUtil = new AccountServiceUtil();
        if (schemeLocationHistoryType != null) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className,
                    "Entering in retrieveSchemeLocationHistoryDetails method");
            schemeLocationHistoryBean.setId(commonUtil.retrieveLongValue(schemeLocationHistoryType.getId(),
                    AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
            schemeLocationHistoryBean.setEffectiveDate(commonUtil.retrieveDateValue(schemeLocationHistoryType.getEffectiveDate(),
                    AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
            schemeLocationHistoryBean.setCategory(retrieveCategoryDetails(schemeLocationHistoryType.getCategory()));
            schemeLocationHistoryBean.setSchemeLocation(retrieveSchemeLocationDetails(schemeLocationHistoryType.getSchemeLocation()));
        }
        return schemeLocationHistoryBean;
    }

    /**
     * 
     * This method constructs Category Details object from response.
     * 
     * @param categoryType
     * @return categoryBean
     * @throws SILException
     */
    public CategoryBean retrieveCategoryDetails(CategoryType categoryType) throws SILException {
        CategoryBean categoryBean = new CategoryBean();
        AccountServiceUtil commonUtil = new AccountServiceUtil();
        if (categoryType != null) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className, "Entering in retrieveCategoryDetails method");
            categoryBean.setId(commonUtil.retrieveLongValue(categoryType.getId(), AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
            categoryBean.setShortName(categoryType.getShortName());
            categoryBean.setLongName(categoryType.getLongName());
            categoryBean.setCategoryScheme(retrieveSchemeDetails(categoryType.getCategoryScheme()));
            categoryBean.setStartDate(commonUtil.retrieveDateValue(categoryType.getStartDate(),
                    AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
            categoryBean.setEndDate(commonUtil.retrieveDateValue(categoryType.getEndDate(),
                    AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
            categoryBean.setStatus(commonUtil.retrieveCode(categoryType.getStatus(), AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
            categoryBean.setRetirementAge(commonUtil.retrieveBigIntegerValue(categoryType.getRetirementAge(),
                    AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
            categoryBean.setEarlyRetirementAge(categoryType.getEarlyRetirementAge());
        } else {
            categoryBean = retrieveEmptyCategoryDetails();
        }
        return categoryBean;
    }

    /**
     * 
     * This method constructs empty Category Details object from response.
     * 
     * @return categoryBean
     * @throws SILException
     */
    public CategoryBean retrieveEmptyCategoryDetails() throws SILException {
        CategoryBean categoryBean = new CategoryBean();
        AccountServiceUtil commonUtil = new AccountServiceUtil();
        SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className, "Entering in retrieveEmptyCategoryDetails method");
        categoryBean.setId(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        categoryBean.setShortName(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        categoryBean.setLongName(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        categoryBean.setCategoryScheme(retrieveEmptySchemeDetails());
        categoryBean.setStartDate(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        categoryBean.setEndDate(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        categoryBean.setStatus(commonUtil.retrieveEmptyCode(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
        categoryBean.setRetirementAge(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        categoryBean.setEarlyRetirementAge(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        return categoryBean;
    }

    /**
     * This method constructs the MarketingCampaign object from response.
     * 
     * @param campaignIdentifierType
     * @return marketingCampaignDetails
     * @throws SILException
     */
    public MarketingCampaignDetails retrieveMarketingCampaignDetails(MarketingCampaignIdentifierType campaignIdentifierType) throws SILException {
        MarketingCampaignDetails marketingCampaignDetails = new MarketingCampaignDetails();
        AccountServiceUtil commonUtil = new AccountServiceUtil();
        if (campaignIdentifierType != null) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className,
                    "Entering in retrieveMarketingCampaignDetails method");
            marketingCampaignDetails.setId(commonUtil.retrieveLongValue(campaignIdentifierType.getId(),
                    AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
            marketingCampaignDetails.setName(campaignIdentifierType.getName());
            marketingCampaignDetails.setCode(campaignIdentifierType.getCode());
            marketingCampaignDetails.setDescription(campaignIdentifierType.getDescription());
            marketingCampaignDetails.setAudit(commonUtil.retrieveAudit(campaignIdentifierType.getAudit(),
                    AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
        }
        SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className, "Exiting in retrieveMarketingCampaignDetails()");
        return marketingCampaignDetails;
    }

    /**
     * This method constructs the MarketingCampaign object from response.
     * 
     * @param campaignIdentifierType
     * @return marketingCampaignDetails
     * @throws SILException
     */
    /**
     * This method constructs the GenericVariables object from response.
     * 
     * @param genericVariableTypeList of type GenericVariableType
     * @return genericVariableBeanList of type List&lt;GenericVariableBean&gt;
     * @throws SILException
     */
    public List<GenericVariableBean> retrieveGenericVariablesList(List<GenericVariableType> genericVariableTypeList) throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className, "Entering retrieveGenericVariablesList()");
        List<GenericVariableBean> genericVariableBeanList = new ArrayList<GenericVariableBean>();
        for (GenericVariableType genericVariableType : genericVariableTypeList) {
            if (genericVariableType != null) {
                GenericVariableBean genericVariableBean = new GenericVariableBean();
                genericVariableBean.setId(String.valueOf(genericVariableType.getId()));
                genericVariableBean.setCode(genericVariableType.getCode());
                genericVariableBean.setLabel(genericVariableType.getLabel());
                genericVariableBean.setDescription(genericVariableType.getLabel());
                if (genericVariableType.getValue() != null) {
                    genericVariableBean.setValue(retrieveValueBean(genericVariableType.getValue(), className));
                }
                genericVariableBeanList.add(genericVariableBean);
            }
        }
        SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className, "Exiting retrieveGenericVariablesList()");
        return genericVariableBeanList;
    }

    /**
     * Fetches a new ValueBean with necessary values set.
     * 
     * @return valueBean of type ValueBean
     */
    public ValueBean retrieveValueBean(Value value, String loggerType) throws SILException {
        SILLogger.debug(loggerType, className, "Entering retrieveValueBean()");
        AccountServiceUtil commonUtil = new AccountServiceUtil();
        ValueBean valueBean = new ValueBean();
        if (value != null) {
            if (value.getCode() != null) {
                valueBean.setCode(commonUtil.retrieveCode(value.getCode(), loggerType));
            }
            valueBean.setDecimal(commonUtil.retrieveBigDecimalValue(value.getDecimal(), loggerType));
            valueBean.setInteger(commonUtil.retrieveIntegerValue(value.getInteger(), loggerType));
            valueBean.setDatetime(commonUtil.retrieveDateValue(value.getDatetime(), loggerType));
            if (value.getChecked() != null) {
                valueBean.setChecked(value.getChecked());
            } else {
                valueBean.setChecked("");
            }
            if (value.getString() != null) {
                valueBean.setString(value.getString());
            } else {
                valueBean.setString(value.getString());
            }
        }
        SILLogger.debug(loggerType, className, "Exiting retrieveValueBean()");
        return valueBean;
    }

    /**
     * This method constructs the Product object from response.
     * 
     * @param productIdentifierType
     * @return productDetails
     * @throws SILException
     */
    public ProductDetails retrieveProductDetails(ProductIdentifierType productIdentifierType) throws SILException {
        ProductDetails productDetails = new ProductDetails();
        AccountServiceUtil commonUtil = new AccountServiceUtil();
        if (productIdentifierType != null) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className, "Entering in retrieveProductDetails method");
            productDetails.setId(commonUtil.retrieveLongValue(productIdentifierType.getId(),
                    AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
            productDetails.setName(productIdentifierType.getName());
            productDetails.setShortName(productIdentifierType.getShortName());
            productDetails.setProductRef(commonUtil.retrieveExternalRef(productIdentifierType.getProductExternalRef(),
                    AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
            productDetails.setAudit(commonUtil.retrieveAudit(productIdentifierType.getAudit(),
                    AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
            productDetails.setProductType(commonUtil.retrieveLongValue(productIdentifierType.getId(),
                    AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
            productDetails.setSourceSystem(AccountServiceConstants.SOURCE_SYSTEM_SNT);
            productDetails.setProductGroup(commonUtil.retrieveLongValue(productIdentifierType.getId(),
                    AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT).substring(0, 6));
        }
        SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className, "Exiting in retrieveProductDetails()");
        return productDetails;
    }

    /**
     * This method constructs the SchemeLocation object from response.
     * 
     * @param schemeLocationIdentifierType
     * @return schemeLocationIdentifier
     * @throws SILException
     */
    public SchemeLocationIdentifier retrieveSchemeLocationDetails(SchemeLocationIdentifierType schemeLocationIdentifierType) throws SILException {
        SchemeLocationIdentifier schemeLocationIdentifier = new SchemeLocationIdentifier();
        AccountServiceUtil commonUtil = new AccountServiceUtil();
        if (schemeLocationIdentifierType != null) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className, "Exiting in retrieveEmptyProductDetails method");
            schemeLocationIdentifier.setId(commonUtil.retrieveLongValue(schemeLocationIdentifierType.getId(),
                    AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
            schemeLocationIdentifier.setName(schemeLocationIdentifierType.getName());
            schemeLocationIdentifier.setNumber(schemeLocationIdentifierType.getNumber());
            schemeLocationIdentifier.setShortName(schemeLocationIdentifierType.getShortName());
            schemeLocationIdentifier.setTypecode(commonUtil.retrieveCode(schemeLocationIdentifierType.getTypeCode(),
                    AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
            schemeLocationIdentifier.setParentLocationIdentifier(commonUtil.retrieveOutlet(
                    schemeLocationIdentifierType.getParentLocationIdentifier(), AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
        } else {
            schemeLocationIdentifier = retrieveEmptySchemeLocationDetails();
        }
        return schemeLocationIdentifier;
    }

    /**
     * This method constructs the empty SchemeLocation object from response.
     * 
     * @return schemeLocationIdentifier
     * @throws SILException
     */
    public SchemeLocationIdentifier retrieveEmptySchemeLocationDetails() throws SILException {
        SchemeLocationIdentifier schemeLocationIdentifier = new SchemeLocationIdentifier();
        AccountServiceUtil commonUtil = new AccountServiceUtil();
        schemeLocationIdentifier.setId(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        schemeLocationIdentifier.setName(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        schemeLocationIdentifier.setNumber(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        schemeLocationIdentifier.setShortName(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        schemeLocationIdentifier.setTypecode(commonUtil.retrieveEmptyCode(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
        schemeLocationIdentifier.setParentLocationIdentifier(commonUtil
                .retrieveEmptyOutlet(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
        return schemeLocationIdentifier;
    }

    /**
     * This method constructs the Product object from response.
     * 
     * @param productIdentifierType
     * @return schemeIdentifier
     * @throws SILException
     */
    public SchemeIdentifier retrieveSchemeDetails(SchemeIdentifierType schemeIdentifierType) throws SILException {
        SchemeIdentifier schemeIdentifier = new SchemeIdentifier();
        AccountServiceUtil commonUtil = new AccountServiceUtil();
        if (schemeIdentifierType != null) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className, "Entering in retrieveProductDetails method");
            schemeIdentifier.setId(commonUtil.retrieveLongValue(schemeIdentifierType.getId(),
                    AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
            schemeIdentifier.setName(schemeIdentifierType.getName());
            schemeIdentifier.setSchemeNumber(schemeIdentifierType.getSchemeNumber());
            schemeIdentifier.setMasterScheme(schemeIdentifierType.getMasterScheme());
            schemeIdentifier.setSchemeRef(commonUtil.retrieveExternalRef(schemeIdentifierType.getSchemeExternalRef(),
                    AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
            schemeIdentifier.setAudit(commonUtil.retrieveAudit(schemeIdentifierType.getAudit(),
                    AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
        } else {
            schemeIdentifier = retrieveEmptySchemeDetails();
        }
        return schemeIdentifier;
    }

    /**
     * This method constructs default Product object.
     * 
     * @return schemeIdentifier
     */
    public SchemeIdentifier retrieveEmptySchemeDetails() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className, "Entering in retrieveEmptyProductDetails method");
        SchemeIdentifier schemeIdentifier = new SchemeIdentifier();
        AccountServiceUtil commonUtil = new AccountServiceUtil();
        schemeIdentifier.setId(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        schemeIdentifier.setName(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        schemeIdentifier.setSchemeNumber(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        schemeIdentifier.setMasterScheme(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        schemeIdentifier.setSchemeRef(commonUtil.retrieveEmptyExternalRef(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
        schemeIdentifier.setAudit(commonUtil.retrieveEmptyAudit(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
        return schemeIdentifier;
    }

    /**
     * This method constructs the Product object from response.
     * 
     * @param productIdentifierType
     * @return schemeCategoryBean
     * @throws SILException
     */
    public SchemeCategoryBean retrieveSchemeCategoryDetails(SchemeCategoryIdentifierType schemeCategoryIdentifierType) throws SILException {
        SchemeCategoryBean schemeCategoryBean = new SchemeCategoryBean();
        AccountServiceUtil commonUtil = new AccountServiceUtil();
        if (schemeCategoryIdentifierType != null) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className, "Entering in retrieveProductDetails method");
            schemeCategoryBean.setId(commonUtil.retrieveLongValue(schemeCategoryIdentifierType.getId(),
                    AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
            schemeCategoryBean.setName(schemeCategoryIdentifierType.getName());
            schemeCategoryBean.setScheme(retrieveSchemeDetails(schemeCategoryIdentifierType.getScheme()));
            schemeCategoryBean.setLongName(schemeCategoryIdentifierType.getLongName());
            schemeCategoryBean.setAudit(commonUtil.retrieveAudit(schemeCategoryIdentifierType.getAudit(),
                    AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
        }

        return schemeCategoryBean;
    }

    /**
     * This method constructs the ExpenseGroup object from response.
     * 
     * @param expenseGroupIdentifierType
     * @return identityIdentifier
     * @throws SILException
     */
    public IdentityIdentifier retrieveExpenseGroup(ExpenseGroupIdentifierType expenseGroupIdentifierType) throws SILException {
        IdentityIdentifier identityIdentifier = new IdentityIdentifier();
        AccountServiceUtil commonUtil = new AccountServiceUtil();
        if (expenseGroupIdentifierType != null) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className, "Entering in retrieveExpenseGroup method");
            identityIdentifier.setId(commonUtil.retrieveLongValue(expenseGroupIdentifierType.getId(),
                    AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
            identityIdentifier.setName(expenseGroupIdentifierType.getName());
            identityIdentifier.setAudit(commonUtil.retrieveAudit(expenseGroupIdentifierType.getAudit(),
                    AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
        }
        return identityIdentifier;
    }

    /**
     * This method constructs the CurrentAccountExpenseGroup object from response.
     * 
     * @param expenseGroupIdentifierType
     * @return identityIdentifier
     * @throws SILException
     */
    public CurrentAccountExpenseGroupBean retrieveCurrentAccountExpenseGroup(AccountExpenseGroupOverrideType expenseGroupOverrideType)
            throws SILException {
        CurrentAccountExpenseGroupBean currentAccountExpenseGroupBean = new CurrentAccountExpenseGroupBean();
        AccountServiceUtil commonUtil = new AccountServiceUtil();
        if (expenseGroupOverrideType != null) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className,
                    "Entering in retrieveCurrentAccountExpenseGroup method");
            currentAccountExpenseGroupBean.setAccountExpenseId(String.valueOf(expenseGroupOverrideType.getAccountExpenseId()));
            currentAccountExpenseGroupBean.setEffectiveDate(commonUtil.retrieveDateValue(expenseGroupOverrideType.getEffectiveDate(),
                    AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
            currentAccountExpenseGroupBean.setExpenseGroupId(String.valueOf(expenseGroupOverrideType.getExpenseGroupId()));
        }
        return currentAccountExpenseGroupBean;
    }

    /**
     * 
     * This method constructs InvestmentProfile Details List object from response.
     * 
     * @param investmentProfileTypeLst
     * @return investmentProfileDetailsLst
     * @throws SILException
     */
    public List<NoteBean> retrieveNotesLst(List<NoteType> noteTypes) throws SILException {
        List<NoteBean> notes = new ArrayList<NoteBean>();
        if (noteTypes != null && noteTypes.size() > 0) {
            SILLogger.debug(AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT, className,
                    "Entering in retrieveInvestmentProfileDetailsLst method");
            for (NoteType noteType : noteTypes) {
                if (noteType != null) {
                    notes.add(retrieveNotesDetails(noteType, AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT));
                }
            }
        }
        return notes;
    }

    /**
     * This method is used to retrieve notes details.
     * 
     * @param noteType
     * @param getAccDetailsListLoggingFormat
     * @return
     * @throws SILException
     */
    public NoteBean retrieveNotesDetails(NoteType noteType, String loggerType) throws SILException {
        SILLogger.debug(loggerType, className, "Entering retrieveNotesDetails()");
        NoteBean noteBean = new NoteBean();
        if (noteType != null) {
            noteBean.setId(String.valueOf(noteType.getId()));
            noteBean.setNote(noteType.getNote());
            noteBean.setEffectiveDate(new AccountServiceUtil().retrieveDateValue(noteType.getEffectiveDate(), loggerType));
            noteBean.setNoteTemplate(retrieveNoteTemplate(noteType.getNoteTemplate(), loggerType));
        } else {
            noteBean = retrieveEmptyNotesDetails(loggerType);
        }
        return noteBean;
    }

    /**
     * This method is used to retrieve notes details.
     * 
     * @param loggerType
     * @return
     * @throws SILException
     */
    private NoteBean retrieveEmptyNotesDetails(String loggerType) throws SILException {
        SILLogger.debug(loggerType, className, "Entering retrieveEmptyNotesDetails()");
        NoteBean noteBean = new NoteBean();
        noteBean.setId("");
        noteBean.setNote("");
        noteBean.setEffectiveDate("");
        noteBean.setNoteTemplate(retrieveEmptyNoteTemplate(loggerType));
        return null;
    }

    /**
     * This method is used to retrieve Empty Template.
     * 
     * @param loggerType
     * @return
     * @throws SILException
     */
    private NoteTemplateBean retrieveEmptyNoteTemplate(String loggerType) throws SILException {
        SILLogger.debug(loggerType, className, "Entering retrieveNoteTemplate()");
        NoteTemplateBean noteTemplateBean = new NoteTemplateBean();
        noteTemplateBean.setId(String.valueOf(""));
        noteTemplateBean.setName("");
        noteTemplateBean.setCode("");
        noteTemplateBean.setWarning("");
        noteTemplateBean.setNoteCategory(retriveEmptyCategoryDetails(loggerType));
        noteTemplateBean.setAudit(new AccountServiceUtil().retrieveAudit(null, loggerType));
        return noteTemplateBean;
    }

    /**
     * This method is used to retrieve Empty category details.
     * 
     * @param loggerType
     * @return
     * @throws SILException
     */
    private NoteCategoryBean retriveEmptyCategoryDetails(String loggerType) throws SILException {
        SILLogger.debug(loggerType, className, "Entering retriveCategoryDetails()");
        NoteCategoryBean noteCategoryBean = new NoteCategoryBean();
        noteCategoryBean.setId("");
        noteCategoryBean.setName("");
        noteCategoryBean.setCode("");
        noteCategoryBean.setAudit(new AccountServiceUtil().retrieveAudit(null, loggerType));
        return noteCategoryBean;
    }

    /**
     * This method is used to get Notes template.
     * 
     * @param noteTemplate
     * @return
     * @throws SILException
     */
    private NoteTemplateBean retrieveNoteTemplate(NoteTemplateIdentifierType noteTemplate, String loggerType) throws SILException {
        SILLogger.debug(loggerType, className, "Entering retrieveNoteTemplate()");
        NoteTemplateBean noteTemplateBean = new NoteTemplateBean();
        noteTemplateBean.setId(String.valueOf(noteTemplate.getId()));
        noteTemplateBean.setName(noteTemplate.getName());
        noteTemplateBean.setCode(noteTemplate.getCode());
        noteTemplateBean.setWarning(String.valueOf(noteTemplate.isWarning()));
        noteTemplateBean.setNoteCategory(retriveCategoryDetails(noteTemplate.getNoteCategory(), loggerType));
        noteTemplateBean.setAudit(new AccountServiceUtil().retrieveAudit(noteTemplate.getAudit(), loggerType));
        return noteTemplateBean;
    }

    /**
     * This method is used to get category details.
     * 
     * @param noteCategory
     * @param loggerType
     * @return
     * @throws SILException
     */
    private NoteCategoryBean retriveCategoryDetails(NoteCategoryIdentifierType noteCategory, String loggerType) throws SILException {
        SILLogger.debug(loggerType, className, "Entering retriveCategoryDetails()");
        NoteCategoryBean noteCategoryBean = new NoteCategoryBean();
        noteCategoryBean.setId(String.valueOf(noteCategory.getId()));
        noteCategoryBean.setName(noteCategory.getName());
        noteCategoryBean.setCode(noteCategory.getCode());
        noteCategoryBean.setAudit(new AccountServiceUtil().retrieveAudit(noteCategory.getAudit(), loggerType));
        return noteCategoryBean;
    }

    /**
     * This method is used to get regular contribution plan details list.
     * 
     * @param regularContributionPlansTypeList
     * @return
     * @throws SILException
     */
    private List<RegularPlanBean> retrieveRegularContributionPlansDetailsList(List<RegularPlanType> regularContributionPlansTypeList)
            throws SILException {
        String loggerType = AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT;
        SILLogger.debug(loggerType, className, "Entering retrieveRegularContributionPlansDetails()");
        List<RegularPlanBean> regularContributionPlansList = new ArrayList<RegularPlanBean>();
        if (regularContributionPlansTypeList != null && regularContributionPlansTypeList.size() > 0) {
            for (RegularPlanType regularPlanType : regularContributionPlansTypeList) {
                regularContributionPlansList.add(retrieveRegularContributionPlanDetails(regularPlanType, loggerType));
            }
        }
        return regularContributionPlansList;
    }

    /**
     * This method is used to get regular contribution plan Details.
     * 
     * @param regularPlanType
     * @return
     * @throws SILException
     */
    private RegularPlanBean retrieveRegularContributionPlanDetails(RegularPlanType regularPlanType, String loggerType) throws SILException {
        SILLogger.debug(loggerType, className, "Entering retrieveRegularContributionPlansDetails()");
        return new RegularPlanDetailsResponseUtil().getRegularContributionPlanDetails(regularPlanType);
    }

    /**
     * 
     * This method is used to retrieve list of restrictions applicable for the account.
     * 
     * @param restrictionListTypes
     * @return
     * @throws SILException
     */
    private List<RestrictionBean> retrieveRestrictionDetailsList(List<AccountRestrictionType> restrictionListTypes) throws SILException {
        String loggerType = AccountServiceConstants.GET_ACC_DETAILS_LIST_LOGGING_FORMAT;
        SILLogger.debug(loggerType, className, "Entering retrieveRestrictionDetailsList()");
        List<RestrictionBean> restrictionBeansList = new ArrayList<RestrictionBean>();
        if (restrictionListTypes != null && restrictionListTypes.size() > 0) {
            AccountServiceUtil accountServiceCommonUtil = new AccountServiceUtil();
            for (AccountRestrictionType accountRestrictionType : restrictionListTypes) {
                RestrictionBean restrictionBean = new RestrictionBean();
                restrictionBean.setId(accountServiceCommonUtil.retrieveLongValue(accountRestrictionType.getId(), loggerType));
                restrictionBean.setCode(accountServiceCommonUtil.retrieveCode(accountRestrictionType.getCode(), loggerType));
                restrictionBean.setEffectiveDate(accountServiceCommonUtil.retrieveDateValue(accountRestrictionType.getEffectiveDate(), loggerType));
                restrictionBeansList.add(restrictionBean);
            }
        }
        return restrictionBeansList;
    }
}
