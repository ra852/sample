////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code PensionProtectionDetails} does this.
 * 
 * @author U387938
 * @since 02/02/2016
 * @version 1.0
 */
public class PensionProtectionDetails {

    private ClientBean client;
    private IdNameIdentifier protectionType;
    private String pltaValue;
    private String pltaFactor;
    private String ppclValueAmount;
    private String ppclValuePercent;
    private String certificationNumber;
    private String effectiveDate;
    private String endDate;
    private CodeIdentifier statusCode;

    /**
     * Accessor for property client.
     * 
     * @return client of type ClientBean
     */
    public ClientBean getClient() {
        return client;
    }

    /**
     * Mutator for property client.
     * 
     * @param client of type ClientBean
     */
    @XmlElement(name = "client")
    public void setClient(ClientBean client) {
        this.client = client;
    }

    /**
     * Accessor for property protectionType.
     * 
     * @return protectionType of type IdNameIdentifier
     */
    public IdNameIdentifier getProtectionType() {
        return protectionType;
    }

    /**
     * Mutator for property protectionType.
     * 
     * @param protectionType of type IdNameIdentifier
     */
    @XmlElement(name = "protectionType")
    public void setProtectionType(IdNameIdentifier protectionType) {
        this.protectionType = protectionType;
    }

    /**
     * Accessor for property pltaValue.
     * 
     * @return pltaValue of type String
     */
    public String getPltaValue() {
        return pltaValue;
    }

    /**
     * Mutator for property pltaValue.
     * 
     * @param pltaValue of type String
     */
    @XmlElement(name = "pltaValue")
    public void setPltaValue(String pltaValue) {
        this.pltaValue = pltaValue != null ? pltaValue : "";
    }

    /**
     * Accessor for property pltaFactor.
     * 
     * @return pltaFactor of type String
     */
    public String getPltaFactor() {
        return pltaFactor;
    }

    /**
     * Mutator for property pltaFactor.
     * 
     * @param pltaFactor of type String
     */
    @XmlElement(name = "pltaFactor")
    public void setPltaFactor(String pltaFactor) {
        this.pltaFactor = pltaFactor != null ? pltaFactor : "";
    }

    /**
     * Accessor for property ppclValueAmount.
     * 
     * @return ppclValueAmount of type String
     */
    public String getPpclValueAmount() {
        return ppclValueAmount;
    }

    /**
     * Mutator for property ppclValueAmount.
     * 
     * @param ppclValueAmount of type String
     */
    @XmlElement(name = "ppclValueAmount")
    public void setPpclValueAmount(String ppclValueAmount) {
        this.ppclValueAmount = ppclValueAmount != null ? ppclValueAmount : "";
    }

    /**
     * Accessor for property ppclValuePercent.
     * 
     * @return ppclValuePercent of type String
     */
    public String getPpclValuePercent() {
        return ppclValuePercent;
    }

    /**
     * Mutator for property ppclValuePercent.
     * 
     * @param ppclValuePercent of type String
     */
    @XmlElement(name = "ppclValuePercent")
    public void setPpclValuePercent(String ppclValuePercent) {
        this.ppclValuePercent = ppclValuePercent != null ? ppclValuePercent : "";
    }

    /**
     * Accessor for property certificationNumber.
     * 
     * @return certificationNumber of type String
     */
    public String getCertificationNumber() {
        return certificationNumber;
    }

    /**
     * Mutator for property certificationNumber.
     * 
     * @param certificationNumber of type String
     */
    @XmlElement(name = "certificationNumber")
    public void setCertificationNumber(String certificationNumber) {
        this.certificationNumber = certificationNumber != null ? certificationNumber : "";
    }

    /**
     * Accessor for property effectiveDate.
     * 
     * @return effectiveDate of type String
     */
    public String getEffectiveDate() {
        return effectiveDate;
    }

    /**
     * Mutator for property effectiveDate.
     * 
     * @param effectiveDate of type String
     */
    @XmlElement(name = "effectiveDate")
    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate != null ? effectiveDate : "";
    }

    /**
     * Accessor for property endDate.
     * 
     * @return endDate of type String
     */
    public String getEndDate() {
        return endDate;
    }

    /**
     * Mutator for property endDate.
     * 
     * @param endDate of type String
     */
    @XmlElement(name = "endDate")
    public void setEndDate(String endDate) {
        this.endDate = endDate != null ? endDate : "";
    }

    /**
     * Accessor for property statusCode.
     * 
     * @return statusCode of type CodeIdentifier
     */
    public CodeIdentifier getStatusCode() {
        return statusCode;
    }

    /**
     * Mutator for property statusCode.
     * 
     * @param statusCode of type CodeIdentifier
     */
    @XmlElement(name = "statusCode")
    public void setStatusCode(CodeIdentifier statusCode) {
        this.statusCode = statusCode;
    }
}
