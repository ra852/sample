////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code LastUpdatedDetail} is a pure java bean consisting of properties related to LastUpdatedDetail.
 * 
 * @author U385424
 * @since 16/12/2016
 * @version 1.0
 */
public class LastUpdatedDetail {

    private String lastUpdatedBy;
    private String lastUpdated;

    /**
     * Accessor for property lastUpdatedBy.
     * 
     * @return lastUpdatedBy of type String
     */
    public String getLastUpdatedBy() {
        return lastUpdatedBy;
    }

    /**
     * Mutator for property lastUpdatedBy.
     * 
     * @param lastUpdatedBy of type String
     */
    @XmlElement(name = "lastUpdatedBy")
    public void setLastUpdatedBy(String lastUpdatedBy) {
        this.lastUpdatedBy = lastUpdatedBy != null ? lastUpdatedBy : "";
    }

    /**
     * Accessor for property lastUpdated.
     * 
     * @return lastUpdated of type String
     */
    public String getLastUpdated() {
        return lastUpdated;
    }

    /**
     * Mutator for property lastUpdated.
     * 
     * @param lastUpdated of type String
     */
    @XmlElement(name = "lastUpdated")
    public void setLastUpdated(String lastUpdated) {
        this.lastUpdated = lastUpdated != null ? lastUpdated : "";
    }
}
