////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code EmploymentDetails} does this.
 * 
 * @author U383847
 * @since 12/05/2016
 * @version 1.0
 */
public class EmploymentDetails {
    private String id;
    private String startDate;
    private String endDate;
    private CodeIdentifier employmentType;
    private CodeIdentifier employmentRecordType;
    private String participating;
    private String primaryEmployer;
    private List<HistoryDetailsBean> history;
    private List<SalaryDetails> salaries;
    private String payrollId;
    private EmployerDetailsBean employer;

    /**
     * Accessor for property startDate.
     * 
     * @return startDate of type String
     */
    public String getStartDate() {
        return startDate;
    }

    /**
     * Mutator for property startDate.
     * 
     * @param startDate of type String
     */
    @XmlElement(name = "startDate")
    public void setStartDate(String startDate) {
        this.startDate = startDate != null ? startDate : "";
    }

    /**
     * Accessor for property primaryEmployer.
     * 
     * @return primaryEmployer of type String
     */
    public String getPrimaryEmployer() {
        return primaryEmployer;
    }

    /**
     * Mutator for property primaryEmployer.
     * 
     * @param primaryEmployer of type String
     */
    @XmlElement(name = "primaryEmployer")
    public void setPrimaryEmployer(String primaryEmployer) {
        this.primaryEmployer = primaryEmployer != null ? primaryEmployer : "";
    }

    /**
     * Accessor for property employmentType.
     * 
     * @return employmentType of type CodeIdentifier
     */
    public CodeIdentifier getEmploymentType() {
        return employmentType;
    }

    /**
     * Mutator for property employmentType.
     * 
     * @param employmentType of type CodeIdentifier
     */
    @XmlElement(name = "employmentType")
    public void setEmploymentType(CodeIdentifier employmentType) {
        this.employmentType = employmentType;
    }


    /**
     * Accessor for property id.
     *
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     *
     * @param id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id != null ? id : "";
    }

    /**
     * Accessor for property employmentRecordType.
     *
     * @return employmentRecordType of type CodeIdentifier
     */
    public CodeIdentifier getEmploymentRecordType() {
        return employmentRecordType;
    }

    /**
     * Mutator for property employmentRecordType.
     *
     * @param employmentRecordType of type CodeIdentifier
     */
    @XmlElement(name = "employmentRecordType")
    public void setEmploymentRecordType(CodeIdentifier employmentRecordType) {
        this.employmentRecordType = employmentRecordType;
    }

    /**
     * Accessor for property participating.
     *
     * @return participating of type String
     */
    public String getParticipating() {
        return participating;
    }

    /**
     * Mutator for property participating.
     *
     * @param participating of type String
     */
    @XmlElement(name = "participating")
    public void setParticipating(String participating) {
        this.participating = participating != null ? participating : "";
    }

   

    /**
     * Accessor for property salaries.
     *
     * @return salaries of type List<SalaryDetails>
     */
    public List<SalaryDetails> getSalaries() {
        return salaries;
    }

    /**
     * Mutator for property salaries.
     *
     * @param salaries of type List<SalaryDetails>
     */
    @XmlElement(name = "salaries")
    public void setSalaries(List<SalaryDetails> salaries) {
        this.salaries = salaries;
    }

    /**
     * Accessor for property history.
     *
     * @return history of type List<HistoryDetailsBean>
     */
    public List<HistoryDetailsBean> getHistory() {
        return history;
    }

    /**
     * Mutator for property history.
     *
     * @param history of type List<HistoryDetailsBean>
     */
    @XmlElement(name = "history")
    public void setHistory(List<HistoryDetailsBean> history) {
        this.history = history;
    }

    /**
     * Accessor for property endDate.
     *
     * @return endDate of type String
     */
    public String getEndDate() {
        return endDate;
    }

    /**
     * Mutator for property endDate.
     *
     * @param endDate of type String
     */
    @XmlElement(name = "endDate")
    public void setEndDate(String endDate) {
        this.endDate = endDate != null ? endDate : "";
    }

    /**
     * Accessor for property payrollId.
     *
     * @return payrollId of type String
     */
    public String getPayrollId() {
        return payrollId;
    }

    /**
     * Mutator for property payrollId.
     *
     * @param payrollId of type String
     */
    @XmlElement(name = "payrollId")
    public void setPayrollId(String payrollId) {
        this.payrollId = payrollId != null ? payrollId : "";
    }

    /**
     * Accessor for property employer.
     *
     * @return employer of type EmployerDetailsBean
     */
    public EmployerDetailsBean getEmployer() {
        return employer;
    }

    /**
     * Mutator for property employer.
     *
     * @param employer of type EmployerDetailsBean
     */
    @XmlElement(name = "employer")
    public void setEmployer(EmployerDetailsBean employer) {
        this.employer = employer;
    }

}
