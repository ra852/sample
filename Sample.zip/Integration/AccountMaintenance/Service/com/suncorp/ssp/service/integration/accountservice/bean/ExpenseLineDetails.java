////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code ExpenseLineDetails} does this.
 * 
 * @author U383754
 * @since 02/02/2016
 * @version 1.0
 */
public class ExpenseLineDetails {
    private String id;
    private String name;
    private TransactionDetails transactionDetails;
    private CodeIdentifier processName;
    private ExpenseDetails expenseDetails;
    private FundRider fundRider;
    private String overrideAllowed;
    private String overridden;
    private CodeIdentifier overrideType;
    private ParameterSetDetails parameterSetDetails;
    private List<ParameterDetails> parameterDetailsLst; 
    private CalculationBasisDetails calculationBasisDetails;
    private CodeIdentifier contributionType;    
    private String maxConsentAmount;
    private String maxConsentPercentage;
    private List<CodeIdentifier> excludedAssetClass;    
    private CodeIdentifier chargeBasis; 
    private AccountIdentifierDetails feeAccount;
    
    private String override;
    private ExpCalcBasisIdentifierBean expCalcBasis;
    private List<ExcludedAssetClassBean> excludedAssetClasses;
    /**
     * Accessor for property id.
     *
     * @return id of type String
     */
    public String getId() {
        return id;
    }
    /**
     * Mutator for property id.
     *
     * @param id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id != null ? id : "";
    }
    /**
     * Accessor for property name.
     *
     * @return name of type String
     */
    public String getName() {
        return name;
    }
    /**
     * Mutator for property name.
     *
     * @param name of type String
     */
    @XmlElement(name = "name")
    public void setName(String name) {
        this.name = name != null ? name : "";
    }
    /**
     * Accessor for property transactionDetails.
     *
     * @return transactionDetails of type TransactionDetails
     */
    public TransactionDetails getTransactionDetails() {
        return transactionDetails;
    }
    /**
     * Mutator for property transactionDetails.
     *
     * @param transactionDetails of type TransactionDetails
     */
    @XmlElement(name = "transactionType")
    public void setTransactionDetails(TransactionDetails transactionDetails) {
        this.transactionDetails = transactionDetails;
    }
    /**
     * Accessor for property processName.
     *
     * @return processName of type CodeIdentifier
     */
    public CodeIdentifier getProcessName() {
        return processName;
    }
    /**
     * Mutator for property processName.
     *
     * @param processName of type CodeIdentifier
     */
    @XmlElement(name = "processName")
    public void setProcessName(CodeIdentifier processName) {
        this.processName = processName;
    }
    /**
     * Accessor for property expenseDetails.
     *
     * @return expenseDetails of type ExpenseDetails
     */
    public ExpenseDetails getExpenseDetails() {
        return expenseDetails;
    }
    /**
     * Mutator for property expenseDetails.
     *
     * @param expenseDetails of type ExpenseDetails
     */
    @XmlElement(name = "expenseType")
    public void setExpenseDetails(ExpenseDetails expenseDetails) {
        this.expenseDetails = expenseDetails;
    }
    /**
     * Accessor for property fundRider.
     *
     * @return fundRider of type FundRider
     */
    public FundRider getFundRider() {
        return fundRider;
    }
    /**
     * Mutator for property fundRider.
     *
     * @param fundRider of type FundRider
     */
    @XmlElement(name = "fundRider")
    public void setFundRider(FundRider fundRider) {
        this.fundRider = fundRider;
    }
    /**
     * Accessor for property overrideAllowed.
     *
     * @return overrideAllowed of type String
     */
    public String getOverrideAllowed() {
        return overrideAllowed;
    }
    /**
     * Mutator for property overrideAllowed.
     *
     * @param overrideAllowed of type String
     */
    @XmlElement(name = "overrideAllowed")
    public void setOverrideAllowed(String overrideAllowed) {
        this.overrideAllowed = overrideAllowed != null ? overrideAllowed : "";
    }
    /**
     * Accessor for property overridden.
     *
     * @return overridden of type String
     */
    public String getOverridden() {
        return overridden;
    }
    /**
     * Mutator for property overridden.
     *
     * @param overridden of type String
     */
    @XmlElement(name = "overridden")
    public void setOverridden(String overridden) {
        this.overridden = overridden != null ? overridden : "";
    }
    /**
     * Accessor for property overrideType.
     *
     * @return overrideType of type CodeIdentifier
     */
    public CodeIdentifier getOverrideType() {
        return overrideType;
    }
    /**
     * Mutator for property overrideType.
     *
     * @param overrideType of type CodeIdentifier
     */
    @XmlElement(name = "overrideType")
    public void setOverrideType(CodeIdentifier overrideType) {
        this.overrideType = overrideType;
    }
    /**
     * Accessor for property parameterSetDetails.
     *
     * @return parameterSetDetails of type ParameterSetDetails
     */
    public ParameterSetDetails getParameterSetDetails() {
        return parameterSetDetails;
    }
    /**
     * Mutator for property parameterSetDetails.
     *
     * @param parameterSetDetails of type ParameterSetDetails
     */
    @XmlElement(name = "parameterSet")
    public void setParameterSetDetails(ParameterSetDetails parameterSetDetails) {
        this.parameterSetDetails = parameterSetDetails;
    }
    /**
     * Accessor for property parameterDetailsLst.
     *
     * @return parameterDetailsLst of type List<ParameterDetails>
     */
    public List<ParameterDetails> getParameterDetailsLst() {
        return parameterDetailsLst;
    }
    /**
     * Mutator for property parameterDetailsLst.
     *
     * @param parameterDetailsLst of type List<ParameterDetails>
     */
    @XmlElement(name = "parameters")
    public void setParameterDetailsLst(List<ParameterDetails> parameterDetailsLst) {
        this.parameterDetailsLst = parameterDetailsLst;
    }
    /**
     * Accessor for property calculationBasisDetails.
     *
     * @return calculationBasisDetails of type CalculationBasisDetails
     */
    public CalculationBasisDetails getCalculationBasisDetails() {
        return calculationBasisDetails;
    }
    /**
     * Mutator for property calculationBasisDetails.
     *
     * @param calculationBasisDetails of type CalculationBasisDetails
     */
    @XmlElement(name = "calculationBasis")
    public void setCalculationBasisDetails(CalculationBasisDetails calculationBasisDetails) {
        this.calculationBasisDetails = calculationBasisDetails;
    }
    /**
     * Accessor for property contributionType.
     *
     * @return contributionType of type CodeIdentifier
     */
    public CodeIdentifier getContributionType() {
        return contributionType;
    }
    /**
     * Mutator for property contributionType.
     *
     * @param contributionType of type CodeIdentifier
     */
    @XmlElement(name = "contributionType")
    public void setContributionType(CodeIdentifier contributionType) {
        this.contributionType = contributionType;
    }
    /**
     * Accessor for property maxConsentAmount.
     *
     * @return maxConsentAmount of type String
     */
    public String getMaxConsentAmount() {
        return maxConsentAmount;
    }
    /**
     * Mutator for property maxConsentAmount.
     *
     * @param maxConsentAmount of type String
     */
    @XmlElement(name = "maxConsentAmount")
    public void setMaxConsentAmount(String maxConsentAmount) {
        this.maxConsentAmount = maxConsentAmount != null ? maxConsentAmount : "";
    }
    /**
     * Accessor for property maxConsentPercentage.
     *
     * @return maxConsentPercentage of type String
     */
    public String getMaxConsentPercentage() {
        return maxConsentPercentage;
    }
    /**
     * Mutator for property maxConsentPercentage.
     *
     * @param maxConsentPercentage of type String
     */
    @XmlElement(name = "maxConsentPercentage")
    public void setMaxConsentPercentage(String maxConsentPercentage) {
        this.maxConsentPercentage = maxConsentPercentage != null ? maxConsentPercentage : "";
    }
    /**
     * Accessor for property excludedAssetClass.
     *
     * @return excludedAssetClass of type List<CodeIdentifier>
     */
    public List<CodeIdentifier> getExcludedAssetClass() {
        return excludedAssetClass;
    }
    /**
     * Mutator for property excludedAssetClass.
     *
     * @param excludedAssetClass of type List<CodeIdentifier>
     */
    @XmlElement(name = "excludedAssetClasses")
    public void setExcludedAssetClass(List<CodeIdentifier> excludedAssetClass) {
        this.excludedAssetClass = excludedAssetClass;
    }
    /**
     * Accessor for property chargeBasis.
     *
     * @return chargeBasis of type CodeIdentifier
     */
    public CodeIdentifier getChargeBasis() {
        return chargeBasis;
    }
    /**
     * Mutator for property chargeBasis.
     *
     * @param chargeBasis of type CodeIdentifier
     */
    @XmlElement(name = "chargeBasis")
    public void setChargeBasis(CodeIdentifier chargeBasis) {
        this.chargeBasis = chargeBasis;
    }
    /**
     * Accessor for property feeAccount.
     *
     * @return feeAccount of type AccountIdentifierDetails
     */
    public AccountIdentifierDetails getFeeAccount() {
        return feeAccount;
    }
    /**
     * Mutator for property feeAccount.
     *
     * @param feeAccount of type AccountIdentifierDetails
     */
    @XmlElement(name = "feeAccount")
    public void setFeeAccount(AccountIdentifierDetails feeAccount) {
        this.feeAccount = feeAccount;
    }
    
   
    /**
     * Accessor for property override.
     *
     * @return override of type String
     */
    public String getOverride() {
        return override;
    }
    /**
     * Mutator for property override.
     *
     * @param override of type String
     */
    @XmlElement(name = "override")
    public void setOverride(String override) {
        this.override = override != null ? override : "";
    }
    /**
     * Accessor for property expCalcBasis.
     *
     * @return expCalcBasis of type ExpCalcBasisIdentifierBean
     */
    public ExpCalcBasisIdentifierBean getExpCalcBasis() {
        return expCalcBasis;
    }
    /**
     * Mutator for property expCalcBasis.
     *
     * @param expCalcBasis of type ExpCalcBasisIdentifierBean
     */
    @XmlElement(name = "expCalcBasis")
    public void setExpCalcBasis(ExpCalcBasisIdentifierBean expCalcBasis) {
        this.expCalcBasis = expCalcBasis;
    }
    /**
     * Accessor for property excludedAssetClasses.
     *
     * @return excludedAssetClasses of type List<ExcludedAssetClassBean>
     */
    public List<ExcludedAssetClassBean> getExcludedAssetClasses() {
        return excludedAssetClasses;
    }
    /**
     * Mutator for property excludedAssetClasses.
     *
     * @param excludedAssetClasses of type List<ExcludedAssetClassBean>
     */
    @XmlElement(name = "excludedAssetClasses")
    public void setExcludedAssetClasses(List<ExcludedAssetClassBean> excludedAssetClasses) {
        this.excludedAssetClasses = excludedAssetClasses;
    }
    
    
    
    
}
