////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.suncorp.ssp.common.bean.SILErrorMessage;

/**
 * The class {@code SaveInvestmentRestuctureResponse} construct's SOAP response for external service.
 * 
 * @author U387938
 * @since 20/03/2016
 * @version 1.0
 */
@XmlRootElement(name = "SaveInvestmentRestuctureResponse")
public class SaveInvestmentRestuctureResponse extends SILErrorMessage {

    private String transactionEventId;
    private String status;

    /**
     * Accessor for property transactionEventId.
     * 
     * @return transactionEventId of type String
     */
    public String getTransactionEventId() {
        return transactionEventId;
    }

    /**
     * Mutator for property transactionEventId.
     * 
     * @param transactionEventId of type String
     */
    @XmlElement(name = "transactionEventId")
    public void setTransactionEventId(String transactionEventId) {
        this.transactionEventId = transactionEventId != null ? transactionEventId : "";
    }

    /**
     * Accessor for property status.
     *
     * @return status of type String
     */
    public String getStatus() {
        return status;
    }

    /**
     * Mutator for property status.
     *
     * @param status of type String
     */
    @XmlElement(name = "status")
    public void setStatus(String status) {
        this.status = status;
    }
    
    

}
