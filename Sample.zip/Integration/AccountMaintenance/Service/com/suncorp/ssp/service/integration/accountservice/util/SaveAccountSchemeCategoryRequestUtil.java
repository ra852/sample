////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import com.sonatacentral.service.v30.globaltypes.common.scheme.schemegrouptype.SchemeCategoryIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType.AccountNumber;
import com.sonatacentral.service.v30.wrap.account.SaveAccountSchemeCategoryRequestType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.SaveAccountSchemeCategoryRequest;

/**
 * The class {@code SaveAccountSchemeCategoryRequestUtil} construct's SOAP request for external service.
 * 
 * @author u385424
 * @since 20/09/2016
 * @version 1.0
 */
public class SaveAccountSchemeCategoryRequestUtil {
    private SaveAccountSchemeCategoryRequest inboundRequest;
    private final String className = "SaveAccountSchemeCategoryRequestUtil";

    /**
     * Does this.
     * 
     * @param inboundRequest
     */
    public SaveAccountSchemeCategoryRequestUtil(SaveAccountSchemeCategoryRequest inboundRequest) {
        this.inboundRequest = inboundRequest;
    }

    /**
     * Does this.
     * 
     * @param outboundRequest2
     * 
     * @return
     */
    public SaveAccountSchemeCategoryRequestType createOutboundRequest(SaveAccountSchemeCategoryRequestType outboundRequest) throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_SCHEME_CATEGORY_LOGGING_FORMAT, className, "Entering in createOutboundRequest method.");
        if (inboundRequest != null) {
            if (inboundRequest.getAccount() != null && inboundRequest.getAccount().getAccountNumber() != null) {
                outboundRequest.setAccount(retrieveAccountIdentifier());
            }
            if (inboundRequest.getSchemeCategory() != null) {
                outboundRequest.setSchemeCategory(retrieveSchemeCategory());
            }
        }
        return outboundRequest;
    }

    /**
     * creates Account Identifier object.
     * 
     * @return accountIdentifierType
     */
    private AccountIdentifierType retrieveAccountIdentifier() {
        SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_SCHEME_CATEGORY_LOGGING_FORMAT, className, "Entering retrieveAccountIdentifier method.");
        AccountIdentifierType accountIdentifierType = new AccountIdentifierType();
        AccountNumber accountNumber = new AccountNumber();
        if (inboundRequest.getAccount().getAccountNumber().getAccountNo() != null) {
            accountNumber.setAccountNo(inboundRequest.getAccount().getAccountNumber().getAccountNo());
            accountIdentifierType.setAccountNumber(accountNumber);
        }
        return accountIdentifierType;
    }

    /**
     * Creates SchemeCategoryIdentifierType object.
     * 
     * @return schemeCategoryIdentifierType
     */
    private SchemeCategoryIdentifierType retrieveSchemeCategory() {
        SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_SCHEME_CATEGORY_LOGGING_FORMAT, className, "Entering retrieveSchemeCategory method.");
        SchemeCategoryIdentifierType schemeCategoryIdentifierType = new SchemeCategoryIdentifierType();
        if (inboundRequest.getSchemeCategory().getName() != null) {
            schemeCategoryIdentifierType.setName(inboundRequest.getSchemeCategory().getName());
        }
        if (inboundRequest.getSchemeCategory().getId() != null) {
            schemeCategoryIdentifierType.setId(Long.valueOf(inboundRequest.getSchemeCategory().getId()));
        }
        return schemeCategoryIdentifierType;
    }
}
