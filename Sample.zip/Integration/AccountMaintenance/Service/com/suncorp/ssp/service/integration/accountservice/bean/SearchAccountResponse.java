////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.suncorp.ssp.common.bean.SILErrorMessage;

/**
 * The class {@code SearchAccountResponse} is a java bean consisting of all the properties related to searchAccount functionality, to be used for
 * constructing response for end-client.
 * 
 * @author U384381
 * @since 03/11/2015
 * @version 1.0
 */
@XmlRootElement(name = "SearchAccountResponse")
public class SearchAccountResponse extends SILErrorMessage {
    private List<AccountType> accounts;
    private PagingRange pagingRange;

    /**
     * Accessor for property accounts.
     * 
     * @return accounts of type List&lt;AccountType&gt;
     */
    public List<AccountType> getAccounts() {
        return accounts;
    }

    /**
     * Mutator for property accounts.
     * 
     * @return accounts of type List&lt;AccountType&gt;
     */
    @XmlElement(name = "accounts")
    public void setAccounts(List<AccountType> accounts) {
        this.accounts = accounts;
    }

    /**
     * Accessor for property pagingRange.
     *
     * @return pagingRange of type PagingRange
     */
    public PagingRange getPagingRange() {
        return pagingRange;
    }

    /**
     * Mutator for property pagingRange.
     *
     * @param pagingRange of type PagingRange
     */
    @XmlElement(name = "pagingRange")
    public void setPagingRange(PagingRange pagingRange) {
        this.pagingRange = pagingRange;
    }
    
}
