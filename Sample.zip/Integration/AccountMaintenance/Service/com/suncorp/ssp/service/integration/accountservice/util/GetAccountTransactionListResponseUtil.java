////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.LastUpdated;
import com.sonatacentral.service.v30.globaltypes.common.fund.fundgrouptype.FundShortType;
import com.sonatacentral.service.v30.globaltypes.wrap.transaction.transactiongrouptype.ContributionType;
import com.sonatacentral.service.v30.globaltypes.wrap.transaction.transactiongrouptype.FundLvlExpType;
import com.sonatacentral.service.v30.globaltypes.wrap.transaction.transactiongrouptype.TransEvtAccTransType;
import com.sonatacentral.service.v30.globaltypes.wrap.transaction.transactiongrouptype.TransEvtAccTransType.Account;
import com.sonatacentral.service.v30.globaltypes.wrap.transaction.transactiongrouptype.TransEvtDetailType;
import com.sonatacentral.service.v30.globaltypes.wrap.transaction.transactiongrouptype.TransEvtInvTransType;
import com.sonatacentral.service.v30.globaltypes.wrap.transaction.transactiongrouptype.TransEvtLvlExpType;
import com.sonatacentral.service.v30.globaltypes.wrap.transaction.transactiongrouptype.TransEvtLvlExpType.BenefitType;
import com.sonatacentral.service.v30.globaltypes.wrap.transaction.transactiongrouptype.TransactionType;
import com.sonatacentral.service.v30.service.ValidationMessage;
import com.sonatacentral.service.v30.wrap.account.GetAccountTransactionListResponseType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.constants.modelportfolioservice.ModelPortfolioServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.BenefitDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.ContributionTypeSplitsBean;
import com.suncorp.ssp.service.integration.accountservice.bean.FundLevelExpenseDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.FundShortTypeDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.GetAccountTransactionListResponseBean;
import com.suncorp.ssp.service.integration.accountservice.bean.LastUpdatedDetail;
import com.suncorp.ssp.service.integration.accountservice.bean.PagingRange;
import com.suncorp.ssp.service.integration.accountservice.bean.TransEvent;
import com.suncorp.ssp.service.integration.accountservice.bean.TransEventAccount;
import com.suncorp.ssp.service.integration.accountservice.bean.TransEventAccountTransaction;
import com.suncorp.ssp.service.integration.accountservice.bean.TransEventDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.TransType;
import com.suncorp.ssp.service.integration.accountservice.bean.TransactionEventInvestmentTransDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.TransactionEventLevelExpenseDetails;

/**
 * The class {@code GetAccountTransactionListResponseUtil} is used as a util class for preparing GetAccountTransactionList response.
 * 
 * @author u386868
 * @since 23/12/2015
 * @version 1.0
 */
public class GetAccountTransactionListResponseUtil {
    private final String className = "GetAccountTransactionListResponseUtil";
    private GetAccountTransactionListResponseType inboundResponse;
    private GetAccountTransactionListResponseBean outboundResponse;
    private TransEvtDetailType transEvtDetailType;
    private AccountServiceUtil commonUtil = new AccountServiceUtil();
    private String loggerType = AccountServiceConstants.GET_ACCOUNT_TRANS_LIST_LOGGING_FORMAT;

    /**
     * Initializes class properties,viz., inbound and outbound response types.
     * 
     * @param inboundResponse
     */
    public GetAccountTransactionListResponseUtil(GetAccountTransactionListResponseType inboundResponse) {
        this.inboundResponse = inboundResponse;
        this.outboundResponse = new GetAccountTransactionListResponseBean();
    }

    /**
     * create the outbound response.
     * 
     * @return outboundResponse of type GetAccountTransactionListResponseBean
     * @throws SILException
     */
    public GetAccountTransactionListResponseBean createOutboundResponse() throws SILException {
        SILLogger.debug(loggerType, className, "Entering createOutboundResponse()");
        List<TransEventDetails> transEvtDetailsList = new ArrayList<TransEventDetails>();
        PagingRange pagingRange = new PagingRange();
        if (this.inboundResponse != null && this.inboundResponse.getTransEvtDetail() != null && this.inboundResponse.getTransEvtDetail().size() > 0) {
            addTransEventDetailsToList(transEvtDetailsList);
        } else if (this.inboundResponse.getValidationMessage() != null && this.inboundResponse.getValidationMessage().size() > 0) {
            this.sendValidationMessages(this.inboundResponse.getValidationMessage(), loggerType);
        } else {
            throw new SILException(AccountServiceConstants.GETACC_TRANS_LIST_RECORD_NOT_EXIST);
        }
        if (this.inboundResponse.getTransEvtDetailsPaging() != null) {
            pagingRange = addTransEvtDetailsPaging();
        } else {
            pagingRange = getDefaultTransEvtDetailsPaging();
        }
        outboundResponse.setTransEvtDetail(transEvtDetailsList);
        outboundResponse.setPagingRange(pagingRange);
        SILLogger.debug(loggerType, className, "Exiting createOutboundResponseOfTransEventDetails()");
        return this.outboundResponse;
    }

    /**
     * Preparation of TransEventDetails List, with necessary parameters values.
     * 
     * @throws SILException
     * 
     */
    private void addTransEventDetailsToList(List<TransEventDetails> transEvtDetailsList) throws SILException {
        SILLogger.debug(loggerType, className, "Entering addTransEventDetailsToList()");
        List<TransEvtDetailType> transEvtDetailTypeList = this.inboundResponse.getTransEvtDetail();
        for (TransEvtDetailType trans : transEvtDetailTypeList) {
            this.transEvtDetailType = trans;
            if (this.transEvtDetailType != null) {
                TransEventDetails transEvtdetails = new TransEventDetails();
                if (this.transEvtDetailType.getTransEvt() != null) {
                    retrieveTransactionEventDetails(transEvtdetails);
                }
                retrieveAccountTransactionDetailList(transEvtdetails);
                transEvtDetailsList.add(transEvtdetails);
            }
        }
    }

    /**
     * Retrieve TransactionEventDetails.
     * 
     * @param transEvtDetailsList
     * @param transEvtdetails
     * @throws SILException
     */
    private void retrieveTransactionEventDetails(TransEventDetails transEvtdetails) throws SILException {
        SILLogger.debug(loggerType, className, "Entering retrieveTransactionEventDetails()");
        TransEvent transEvent = new TransEvent();
        transEvent.setId(getId());
        transEvent.setReasonCode(getReasonCode());
        transEvent.setAmount(calculateAmount());
        transEvent.setReference(getReference());
        transEvent.setTransStatus(getTransStatus());
        transEvent.setTransType(getTransType(this.transEvtDetailType.getTransEvt().getTransType()));
        transEvent.setPricedDate(getPricedDate());
        transEvent.setProcessedDate(getProcessedDate());
        transEvent.setEffectiveDate(getEffectiveDate());
        transEvent.setLastUpdated(getlastUpdatedDetails(this.transEvtDetailType.getTransEvt().getLastUpdated()));
        transEvtdetails.setTransEvent(transEvent);
    }

    /**
     * Get a new instance of TransType, with necessary values set.
     * 
     * @param transactionType
     * 
     * @return transType of type TransType
     */
    private TransType getTransType(TransactionType transactionType) {
        SILLogger.debug(loggerType, className, "Entering getTransType()");
        TransType transType = new TransType();

        if (transactionType.getCode() != null) {
            transType.setCode(transactionType.getCode());
        }
        if (transactionType.getDesc() != null) {
            transType.setDesc(transactionType.getDesc());
        }
        if (transactionType.getId() != null) {
            transType.setId(String.valueOf(transactionType.getId()));
        }
        if (transactionType.getShortDesc() != null) {
            transType.setShortDesc(transactionType.getShortDesc());
        }
        if (transactionType.getBalEffect() != null) {
            transType.setBalEffect(String.valueOf(transactionType.getBalEffect()));
        }
        return transType;
    }

    /**
     * Retrieve Transaction AccountTransactionDetailList.
     * 
     * @param transEvtdetails
     * @throws SILException
     */
    private void retrieveAccountTransactionDetailList(TransEventDetails transEvtdetails) throws SILException {
        SILLogger.debug(loggerType, className, "Entering retrieveAccountTransactionDetailList()");
        List<TransEvtAccTransType> accTransList = this.transEvtDetailType.getAccTrans();
        List<TransEventAccountTransaction> accountTransactionsList = new ArrayList<TransEventAccountTransaction>();
        if (accTransList != null && accTransList.size() > 0) {
            for (TransEvtAccTransType transEvtAccTransType : accTransList) {
                if (transEvtAccTransType != null) {
                    TransEventAccountTransaction transEventAccountTransaction = new TransEventAccountTransaction();
                    retrieveTransactionEventDetailValues(transEventAccountTransaction, transEvtAccTransType);
                    accountTransactionsList.add(transEventAccountTransaction);
                }
            }
        }
        transEvtdetails.setAccountTransactions(accountTransactionsList);
    }

    /**
     * Retrieve TransactionEventDetail Values.
     * 
     * @param transEventAccountTransaction
     * @param transEvtAccTransType
     * @throws SILException
     */
    private void retrieveTransactionEventDetailValues(TransEventAccountTransaction transEventAccountTransaction,
            TransEvtAccTransType transEvtAccTransType) throws SILException {
        SILLogger.debug(loggerType, className, "Entering retrieveTransactionEventDetailValues()");
        transEventAccountTransaction.setGrossAmount(commonUtil.retrieveBigDecimalValue(transEvtAccTransType.getGrossAmount(), loggerType));
        transEventAccountTransaction.setExpenseGroup(transEvtAccTransType.getExpenseGroup());
        transEventAccountTransaction.setAccount(retrieveTransactionAccountDetails(transEvtAccTransType.getAccount()));
        transEventAccountTransaction.setPriceCode(transEvtAccTransType.getPriceCode());
        if (transEvtAccTransType.getTransType() != null) {
            transEventAccountTransaction.setTransType(getTransType(transEvtAccTransType.getTransType()));
        }
        retrieveTransactionEventOthervalues(transEventAccountTransaction, transEvtAccTransType);
    }

    /**
     * Retrieve TransactionEventOthervalues.
     * 
     * @param transEventAccountTransaction
     * @param transEvtAccTransType
     * @throws SILException
     */
    private void retrieveTransactionEventOthervalues(TransEventAccountTransaction transEventAccountTransaction,
            TransEvtAccTransType transEvtAccTransType) throws SILException {
        SILLogger.debug(loggerType, className, "Entering retrieveTransactionEventOthervalues()");
        if (transEvtAccTransType.getContDetail() != null && transEvtAccTransType.getContDetail().size() > 0) {
            retrieveContributionDetails(transEventAccountTransaction, transEvtAccTransType.getContDetail());
        }
        if (transEvtAccTransType.getInvestTrans() != null && transEvtAccTransType.getInvestTrans().size() > 0) {
            retrieveInvestmentTransactionDetail(transEventAccountTransaction, transEvtAccTransType.getInvestTrans());
        }
        if (transEvtAccTransType.getTransLevelExp() != null && transEvtAccTransType.getTransLevelExp().size() > 0) {
            retrieveTransEventLevelExpDetails(transEventAccountTransaction, transEvtAccTransType.getTransLevelExp());
        }
    }

    /**
     * Retrieve TransEventLevelExpDetails.
     * 
     * @param transEventAccountTransaction
     * @param transLevelExp
     * @throws SILException
     */
    private void retrieveTransEventLevelExpDetails(TransEventAccountTransaction transEventAccountTransaction,
            List<TransEvtLvlExpType> transLevelExpTypeList) throws SILException {
        SILLogger.debug(loggerType, className, "Entering retrieveTransEventLevelExpDetails()");
        List<TransactionEventLevelExpenseDetails> transLevelEventList = new ArrayList<TransactionEventLevelExpenseDetails>();
        for (TransEvtLvlExpType transEvtLvlExpType : transLevelExpTypeList) {
            if (transEvtLvlExpType != null) {
                TransactionEventLevelExpenseDetails eventLevelExpenseDetails = new TransactionEventLevelExpenseDetails();
                retrieveAccountTransValues(transEvtLvlExpType, eventLevelExpenseDetails);
                transLevelEventList.add(eventLevelExpenseDetails);
            }
        }
        transEventAccountTransaction.setTransLevelEvent(transLevelEventList);
    }

    /**
     * Retrieve AccountTransValues.
     * 
     * @param transEvtLvlExpType
     * @param eventLevelExpenseDetails
     * @throws SILException
     */
    private void retrieveAccountTransValues(TransEvtLvlExpType transEvtLvlExpType, TransactionEventLevelExpenseDetails eventLevelExpenseDetails)
            throws SILException {
        SILLogger.debug(loggerType, className, "Entering retrieveAccountTransValues()");
        eventLevelExpenseDetails.setBalanceEffect(commonUtil.retrieveBigIntegerValue(transEvtLvlExpType.getBalanceEffect(), loggerType));
        eventLevelExpenseDetails.setBenefitType(retrieveBenefitTypeDetails(transEvtLvlExpType.getBenefitType()));
        eventLevelExpenseDetails.setContType(commonUtil.retrieveCode(transEvtLvlExpType.getContType(), loggerType));
        eventLevelExpenseDetails.setDeductionAmount(commonUtil.retrieveBigDecimalValue(transEvtLvlExpType.getDeductionAmount(), loggerType));
        eventLevelExpenseDetails.setExpenseType(transEvtLvlExpType.getExpenseType());
        eventLevelExpenseDetails.setExpTypeDesc(transEvtLvlExpType.getExpTypeDesc());
        eventLevelExpenseDetails.setFeeEffect(commonUtil.retrieveBigIntegerValue(transEvtLvlExpType.getFeeEffect(), loggerType));
        eventLevelExpenseDetails.setFund(commonUtil.retrieveFundIdentifier(transEvtLvlExpType.getFund(), loggerType));
        eventLevelExpenseDetails.setOriginalAmount(commonUtil.retrieveBigDecimalValue(transEvtLvlExpType.getOriginalAmount(), loggerType));
        eventLevelExpenseDetails.setPercentage(commonUtil.retrieveBigDecimalValue(transEvtLvlExpType.getPercentage(), loggerType));
    }

    /**
     * Retrieve BenefitTypeDetails
     * 
     * @param benefitType
     * @return
     * @throws SILException
     */
    private BenefitDetails retrieveBenefitTypeDetails(BenefitType benefitType) throws SILException {
        BenefitDetails benefitDetails = new BenefitDetails();
        if (benefitType != null) {
            SILLogger.debug(loggerType, className, "Entering retrieveBenefitTypeDetails()");
            benefitDetails.setId(commonUtil.retrieveLongValue(benefitType.getId(), loggerType));
            benefitDetails.setName(benefitType.getName());
            benefitDetails.setRiderName(benefitType.getRiderName());
        } else {
            benefitDetails = retrieveEmptybenefitDetails();
            SILLogger.debug(loggerType, className, "Exiting retrieveBenefitTypeDetails()");
        }
        return benefitDetails;
    }

    /**
     * Retrieve EmptybenefitDetails.
     * 
     * @param benefitDetails
     */
    private BenefitDetails retrieveEmptybenefitDetails() {
        SILLogger.debug(loggerType, className, "Entering retrieveEmptybenefitDetails()");
        BenefitDetails benefitDetails = new BenefitDetails();
        benefitDetails.setId("");
        benefitDetails.setName("");
        benefitDetails.setRiderName("");
        return benefitDetails;
    }

    /**
     * Retrieve InvestmentTransactionDetail.
     * 
     * @param accountTransaction
     * 
     * @param list
     * @throws SILException
     */
    private void retrieveInvestmentTransactionDetail(TransEventAccountTransaction accountTransaction, List<TransEvtInvTransType> invTransTypeList)
            throws SILException {
        SILLogger.debug(loggerType, className, "Entering retrieveInvestmentTransactionDetail()");
        List<TransactionEventInvestmentTransDetails> investmentTransList = new ArrayList<TransactionEventInvestmentTransDetails>();
        for (TransEvtInvTransType invTransType : invTransTypeList) {
            if (invTransType != null) {
                TransactionEventInvestmentTransDetails investmentTransDetails = new TransactionEventInvestmentTransDetails();
                retrieveInvestmentTransactionValues(investmentTransDetails, invTransType);
                investmentTransList.add(investmentTransDetails);
            }
        }
        accountTransaction.setInvestmenttrans(investmentTransList);
    }

    /**
     * Retrieve InvestmentTransactionValues.
     * 
     * @param investmentTransDetails2
     * @param invTransType
     * @throws SILException
     */
    private void retrieveInvestmentTransactionValues(TransactionEventInvestmentTransDetails investmentTransDetails, TransEvtInvTransType invTransType)
            throws SILException {
        SILLogger.debug(loggerType, className, "Entering retrieveInvestmentTransactionValues()");
        investmentTransDetails.setAmountMaster(invTransType.getAmountMaster());
        investmentTransDetails.setAscValue(commonUtil.retrieveBigDecimalValue(invTransType.getAscValue(), loggerType));
        investmentTransDetails.setBalanceId(commonUtil.retrieveLongValue(invTransType.getBalanceId(), loggerType));
        investmentTransDetails.setBalanceType(invTransType.getBalanceType());
        investmentTransDetails.setEffectiveAmount(commonUtil.retrieveBigDecimalValue(invTransType.getEffectiveAmount(), loggerType));
        investmentTransDetails.setEffectiveDate(commonUtil.retrieveObjectValue(invTransType.getEffectiveDate(), loggerType));
        investmentTransDetails.setEffectiveDeduction(commonUtil.retrieveBigDecimalValue(invTransType.getEffectiveDeduction(), loggerType));
        investmentTransDetails.setEffectiveUnits(commonUtil.retrieveBigDecimalValue(invTransType.getEffectiveUnits(), loggerType));
        retrieveFundLevelExpenseDetails(investmentTransDetails, invTransType.getFundLvlExp());
        investmentTransDetails.setFundName(retrieveFundShortTypeDetails(invTransType.getFundName()));
        investmentTransDetails.setGrossInterest(commonUtil.retrieveBigDecimalValue(invTransType.getGrossInterest(), loggerType));
        retrieveInvestmentTransId(investmentTransDetails, invTransType);
        investmentTransDetails.setLastUpdated(getlastUpdatedDetails(invTransType.getLastUpdated()));
        investmentTransDetails.setPartialFill(commonUtil.retrieveBooleanValue(invTransType.isPartialFill(), loggerType));
        investmentTransDetails.setPercentage(commonUtil.retrieveBigDecimalValue(invTransType.getPercentage(), loggerType));
        investmentTransDetails.setPriceAdjRate(commonUtil.retrieveBigDecimalValue(invTransType.getPriceAdjRate(), loggerType));
        investmentTransDetails.setPriceApplied(commonUtil.retrieveBigDecimalValue(invTransType.getPriceApplied(), loggerType));
        investmentTransDetails.setPricedDate(commonUtil.retrieveDateValue(invTransType.getPricedDate(), loggerType));
        investmentTransDetails.setPriceType(invTransType.getPriceType());
        investmentTransDetails.setSmpName(retrieveFundShortTypeDetails(invTransType.getSmpName()));
    }

    /**
     * Retrieve InvestmentTransId.
     * 
     * @param investmentTransDetails
     * @param invTransType
     */
    private void retrieveInvestmentTransId(TransactionEventInvestmentTransDetails investmentTransDetails, TransEvtInvTransType invTransType) {
        if (SILUtil.isNotANullOrEmptyString(String.valueOf(invTransType.getId()))) {
            SILLogger.debug(loggerType, className, "Entering retrieveInvestmentTransId()");
            investmentTransDetails.setId(String.valueOf(invTransType.getId()));
        }
    }

    /**
     * Retrieve FundShortTypeDetails.
     * 
     * @param fundName
     * @return
     * @throws SILException
     */
    private FundShortTypeDetails retrieveFundShortTypeDetails(FundShortType fundName) throws SILException {
        FundShortTypeDetails fundShortTypeDetails = new FundShortTypeDetails();
        if (fundName != null) {
            SILLogger.debug(loggerType, className, "Entering retrieveFundShortTypeDetails()");
            fundShortTypeDetails.setFundCorroName(fundName.getFundCorroName());
            fundShortTypeDetails.setFundFullName(fundName.getFundFullName());
            fundShortTypeDetails.setId(commonUtil.retrieveLongValue(fundName.getId(), loggerType));
            fundShortTypeDetails.setName(fundName.getName());
        } else {
            fundShortTypeDetails = retrieveEmptyFundShortDetails();
        }
        SILLogger.debug(loggerType, className, "Exiting retrieveFundShortTypeDetails()");
        return fundShortTypeDetails;
    }

    /**
     * Retrieve EmptyFundShortDetails.
     * 
     * @param fundShortTypeDetails
     * 
     * @return
     */
    private FundShortTypeDetails retrieveEmptyFundShortDetails() {
        SILLogger.debug(loggerType, className, "Entering retrieveEmptyFundShortDetails()");
        FundShortTypeDetails fundShortTypeDetails = new FundShortTypeDetails();
        fundShortTypeDetails.setFundCorroName("");
        fundShortTypeDetails.setFundFullName("");
        fundShortTypeDetails.setId("");
        fundShortTypeDetails.setName("");
        return fundShortTypeDetails;
    }

    /**
     * Retrieve FundLevelExpenseDetails.
     * 
     * @param investmentTransDetails
     * @param fundLvlExp
     * @throws SILException
     */
    private void retrieveFundLevelExpenseDetails(TransactionEventInvestmentTransDetails investmentTransDetails,
            List<FundLvlExpType> fundLvlExpTypeList) throws SILException {
        SILLogger.debug(loggerType, className, "Entering retrieveFundLevelExpenseDetails()");
        List<FundLevelExpenseDetails> fundLevelExpenseList = new ArrayList<FundLevelExpenseDetails>();
        if (fundLvlExpTypeList != null) {
            for (FundLvlExpType fundLvlExpType : fundLvlExpTypeList) {
                if (fundLvlExpType != null) {
                    FundLevelExpenseDetails fundLevelExpenseDetails = new FundLevelExpenseDetails();
                    retrieveFundLevelExpenseValues(fundLvlExpType, fundLevelExpenseDetails);
                    fundLevelExpenseList.add(fundLevelExpenseDetails);
                }
            }
        } else {
            fundLevelExpenseList = retrieveEmptyFundLevelExpDetails();
        }
        investmentTransDetails.setFundLevelExpense(fundLevelExpenseList);
    }

    /**
     * Retrieve FundLevelExpenseValues.
     * 
     * @param fundLvlExpType
     * @param fundLevelExpenseDetails
     * @throws SILException
     */
    private void retrieveFundLevelExpenseValues(FundLvlExpType fundLvlExpType, FundLevelExpenseDetails fundLevelExpenseDetails) throws SILException {
        SILLogger.debug(loggerType, className, "Entering retrieveFundLevelExpenseValues()");
        fundLevelExpenseDetails.setBalanceEffect(commonUtil.retrieveBigIntegerValue(fundLvlExpType.getBalanceEffect(), loggerType));
        fundLevelExpenseDetails.setContType(commonUtil.retrieveCode(fundLvlExpType.getContType(), loggerType));
        fundLevelExpenseDetails.setDeductionAmount(commonUtil.retrieveBigDecimalValue(fundLvlExpType.getDeductionAmount(), loggerType));
        fundLevelExpenseDetails.setExpenseType(fundLvlExpType.getExpenseType());
        fundLevelExpenseDetails.setExpTypeDesc(fundLvlExpType.getExpTypeDesc());
        fundLevelExpenseDetails.setFeeEffect(commonUtil.retrieveBigIntegerValue(fundLvlExpType.getFeeEffect(), loggerType));
        fundLevelExpenseDetails.setFund(commonUtil.retrieveFundIdentifier(fundLvlExpType.getFund(), loggerType));
        fundLevelExpenseDetails.setOriginalAmount(commonUtil.retrieveBigDecimalValue(fundLvlExpType.getOriginalAmount(), loggerType));
        fundLevelExpenseDetails.setPercentage(commonUtil.retrieveBigDecimalValue(fundLvlExpType.getPercentage(), loggerType));
    }

    /**
     * Retrieve EmptyFundLevelExpDetails.
     * 
     * @param fundLevelExpenseDetails
     * @throws SILException
     */
    private List<FundLevelExpenseDetails> retrieveEmptyFundLevelExpDetails() throws SILException {
        SILLogger.debug(loggerType, className, "Entering retrieveEmptyFundLevelExpDetails()");
        List<FundLevelExpenseDetails> fundLevelExpenseList = new ArrayList<FundLevelExpenseDetails>();
        FundLevelExpenseDetails fundLevelExpenseDetails = new FundLevelExpenseDetails();
        fundLevelExpenseDetails.setBalanceEffect("");
        fundLevelExpenseDetails.setContType(commonUtil.retrieveEmptyCode(loggerType));
        fundLevelExpenseDetails.setDeductionAmount("");
        fundLevelExpenseDetails.setExpenseType("");
        fundLevelExpenseDetails.setExpTypeDesc("");
        fundLevelExpenseDetails.setFeeEffect("");
        fundLevelExpenseDetails.setFund(commonUtil.retrieveEmptyFundIdentifier(loggerType));
        fundLevelExpenseDetails.setOriginalAmount("");
        fundLevelExpenseDetails.setPercentage("");
        fundLevelExpenseList.add(fundLevelExpenseDetails);
        return fundLevelExpenseList;

    }

    /**
     * Retrieve ContributionDetails.
     * 
     * @param accountTransaction
     * @param contDetail
     * @throws SILException
     */
    private void retrieveContributionDetails(TransEventAccountTransaction accountTransaction, List<ContributionType> contDetailTypeList)
            throws SILException {
        SILLogger.debug(loggerType, className, "Entering retrieveContributionDetails()");
        List<ContributionTypeSplitsBean> contributionDetailList = new ArrayList<ContributionTypeSplitsBean>();
        for (ContributionType contributionType : contDetailTypeList) {
            if (contributionType != null) {
                ContributionTypeSplitsBean contributionTypeSplitsBean = new ContributionTypeSplitsBean();
                contributionTypeSplitsBean.setAmount(commonUtil.retrieveBigDecimalValue(contributionType.getAmount(), loggerType));
                contributionTypeSplitsBean.setPercentage(commonUtil.retrieveBigDecimalValue(contributionType.getPercentage(), loggerType));
                contributionTypeSplitsBean.setContributionTypeCode(commonUtil.retrieveCode(contributionType.getContributionType(), loggerType));
                contributionDetailList.add(contributionTypeSplitsBean);
            }
        }
        accountTransaction.setContributionDetail(contributionDetailList);
    }

    /**
     * Retrieve TransactionAccountDetails.
     * 
     * @param account
     * 
     * @return
     * @throws SILException
     */
    private TransEventAccount retrieveTransactionAccountDetails(Account account) throws SILException {
        TransEventAccount transEventAccount = new TransEventAccount();
        if (account != null) {
            SILLogger.debug(loggerType, className, "Entering retrieveTransactionAccountDetails()");
            transEventAccount.setAccountNo(account.getAccountNo());
            transEventAccount.setMailingName(account.getMailingName());
        } else {
            transEventAccount = retrieveEmptyTransAccountDetails();
            SILLogger.debug(loggerType, className, "Exiting retrieveTransactionAccountDetails()");
        }
        return transEventAccount;
    }

    /**
     * Retrieve EmptyTransAccountDetails.
     * 
     * @return
     */
    private TransEventAccount retrieveEmptyTransAccountDetails() {
        SILLogger.debug(loggerType, className, "Entering retrieveEmptyTransAccountDetails()");
        TransEventAccount transEventAccount = new TransEventAccount();
        transEventAccount.setAccountNo("");
        transEventAccount.setMailingName("");
        return transEventAccount;
    }

    /**
     * Retrieve the values of last Updated.
     * 
     * @param lastUpdated
     * 
     * @return lastUpdatedDetail
     */
    private LastUpdatedDetail getlastUpdatedDetails(LastUpdated lastUpdated) {
        SILLogger.debug(loggerType, className, "Entering getEffectiveDate()");
        LastUpdatedDetail lastUpdatedDetail = new LastUpdatedDetail();
        if (lastUpdated != null && lastUpdated.getLastUpdated() != null) {
            lastUpdatedDetail.setLastUpdatedBy(lastUpdated.getLastUpdatedBy());
            lastUpdatedDetail.setLastUpdated(SILUtil.convertXMLGregorianCalendartoString(lastUpdated.getLastUpdated(),
                    CommonConstants.DATE_TIME_FORMAT));
        } else {
            lastUpdatedDetail = getDefaultLastUpdated();
        }
        return lastUpdatedDetail;
    }

    /**
     * Set default values for lastUpdated.
     * 
     * @param lastUpdatedDetail
     */
    private LastUpdatedDetail getDefaultLastUpdated() {
        SILLogger.debug(loggerType, className, "Entering getDefaultLastUpdated()");
        LastUpdatedDetail lastUpdatedDetail = new LastUpdatedDetail();
        lastUpdatedDetail.setLastUpdated("");
        lastUpdatedDetail.setLastUpdatedBy("");
        return lastUpdatedDetail;
    }

    /**
     * Get a new instance of EffectiveDate, with necessary values set.
     * 
     * @return effectiveDate of type String
     */
    private String getEffectiveDate() {
        SILLogger.debug(loggerType, className, "Entering getEffectiveDate()");
        if (this.transEvtDetailType.getTransEvt().getEffectiveDate() != null) {
            return this.transEvtDetailType.getTransEvt().getEffectiveDate().toString();
        }
        return "";
    }

    /**
     * Get a new instance of ProcessedDate, with necessary values set.
     * 
     * @return processedDate of type String
     */
    private String getProcessedDate() {
        SILLogger.debug(loggerType, className, "Entering getProcessedDate()");
        if (this.transEvtDetailType.getTransEvt().getProcessedDate() != null) {
            return this.transEvtDetailType.getTransEvt().getProcessedDate().toString();
        }
        return "";
    }

    /**
     * Get a new instance of PricedDate, with necessary values set.
     * 
     * @return pricedDate of type String
     */
    private String getPricedDate() {
        SILLogger.debug(loggerType, className, "Entering getPricedDate()");
        if (this.transEvtDetailType.getTransEvt().getPricedDate() != null) {
            return this.transEvtDetailType.getTransEvt().getPricedDate().toString();
        }
        return "";
    }

    /**
     * Get a new instance of TransStatus, with necessary values set.
     * 
     * @return transStatus of type String
     */
    private String getTransStatus() {
        SILLogger.debug(loggerType, className, "Entering getTransStatus()");
        if (this.transEvtDetailType.getTransEvt().getTransStatus() != null) {
            return this.transEvtDetailType.getTransEvt().getTransStatus().getCode();
        }
        return "";
    }

    /**
     * Get a new instance of Reference, with necessary values set.
     * 
     * @return reference of type String
     */
    private String getReference() {
        SILLogger.debug(loggerType, className, "Entering getReference()");
        if (this.transEvtDetailType.getTransEvt().getReference() != null) {
            return this.transEvtDetailType.getTransEvt().getReference();
        }
        return "";
    }

    /**
     * This method is used to calculate amount by using grossAmount & balEffect params .
     * 
     * @return amount of type BigDecimal
     * @throws SILException
     */
    private BigDecimal calculateAmount() throws SILException {
        SILLogger.debug(loggerType, className, "Entering calculateAmount()");
        if (!SILUtil.isEmpty(this.transEvtDetailType.getAccTrans())) {
            List<TransEvtAccTransType> inboundList = this.transEvtDetailType.getAccTrans();
            List<BigDecimal> grossAmount = new ArrayList<BigDecimal>();
            List<BigInteger> balEffect = new ArrayList<BigInteger>();
            List<BigDecimal> amount = new ArrayList<BigDecimal>();
            BigDecimal totalAmount = BigDecimal.ZERO;
            for (int i = 0; i < inboundList.size(); i++) {
                if (this.transEvtDetailType.getAccTrans().get(i).getGrossAmount() != null &&
                        this.transEvtDetailType.getAccTrans().get(0).getTransType().getBalEffect() != null) {
                    grossAmount.add(this.transEvtDetailType.getAccTrans().get(i).getGrossAmount());
                    balEffect.add(this.transEvtDetailType.getAccTrans().get(i).getTransType().getBalEffect());
                } else {
                    SILLogger.debug(loggerType, className, "BalEffect and grossAmount can't be null");
                    throw new SILException(AccountServiceConstants.GET_ACC_TRANS_LIST_RES_NOT_PROCESSED);
                }
                amount.add(grossAmount.get(i).multiply(new BigDecimal(balEffect.get(i))));
                totalAmount = totalAmount.add(amount.get(i));
            }
            return totalAmount;
        }
        return BigDecimal.ZERO;
    }

    /**
     * Get a new instance of ReasonCode, with necessary values set.
     * 
     * @return reasonCode of type String
     */
    private String getReasonCode() {
        SILLogger.debug(loggerType, className, "Entering getReasonCode()");
        if (this.transEvtDetailType.getTransEvt().getReason() != null) {
            return this.transEvtDetailType.getTransEvt().getReason().getCode();
        }
        return "";
    }

    /**
     * Get a new instance of Trans Event Id, with necessary values set.
     * 
     * @return trans Event Id of type String
     */
    private String getId() {
        SILLogger.debug(loggerType, className, "Entering getId()");
        if (this.transEvtDetailType.getTransEvt().getId() != null) {
            return this.transEvtDetailType.getTransEvt().getId();
        }
        return "";
    }

    /**
     * This method is used to send validation message to the consumer.
     * 
     * @param list of type List<ValidationMessage>
     * @param loggerType
     * @throws SILException
     */
    public void sendValidationMessages(List<ValidationMessage> list, String loggerType) throws SILException {
        SILLogger.debug(loggerType, className, "Entering in sendValidationMessages");
        List<ValidationMessage> validationMessageList = list;
        for (ValidationMessage validationMessage : validationMessageList) {
            if (validationMessage.getSeverity() != null) {
                if (validationMessage.getSeverity().equalsIgnoreCase(ModelPortfolioServiceConstants.SEVERITY_ERROR) ||
                        validationMessage.getSeverity().equalsIgnoreCase(ModelPortfolioServiceConstants.SEVERITY_DEBUG) ||
                        validationMessage.getSeverity().equalsIgnoreCase(ModelPortfolioServiceConstants.SEVERITY_FATAL)) {
                    throw new SILException(validationMessage.getMessage());
                } else if (validationMessage.getSeverity().equalsIgnoreCase(ModelPortfolioServiceConstants.SEVERITY_INFO)) {
                    throw new SILException(ModelPortfolioServiceConstants.INVALID_RESPONSE_FROM_SONATA);
                }
            }
        }
        SILLogger.debug(loggerType, className, "Exiting from sendValidationMessages");
    }

    /**
     * Get a new instance of PagingRange, with necessary values set.
     * 
     * @return pagingRange of type PagingRange
     */
    private PagingRange addTransEvtDetailsPaging() {
        SILLogger.debug(loggerType, className, "Entering addTransEvtDetailsPaging()");
        PagingRange pagingRange = new PagingRange();
        if (Integer.toString(this.inboundResponse.getTransEvtDetailsPaging().getFirstResult()) != null) {
            pagingRange.setFirstResult(this.inboundResponse.getTransEvtDetailsPaging().getFirstResult());
        }
        if (Integer.toString(this.inboundResponse.getTransEvtDetailsPaging().getResultsPerPage()) != null) {
            pagingRange.setResultsPerPage(this.inboundResponse.getTransEvtDetailsPaging().getResultsPerPage());
        }
        if (Integer.toString(this.inboundResponse.getTransEvtDetailsPaging().getTotalResults()) != null) {
            pagingRange.setTotalResults(this.inboundResponse.getTransEvtDetailsPaging().getTotalResults());
        }
        return pagingRange;
    }

    /**
     * Get a new instance of PagingRange, with default values set of PagingRange.
     * 
     * @return pagingRange of type PagingRange
     */
    private PagingRange getDefaultTransEvtDetailsPaging() {
        SILLogger.debug(loggerType, className, "Entering getDefaultTransEvtDetailsPaging()");
        PagingRange pagingRange = new PagingRange();
        pagingRange.setFirstResult(0);
        pagingRange.setResultsPerPage(0);
        pagingRange.setTotalResults(0);
        return pagingRange;
    }
}
