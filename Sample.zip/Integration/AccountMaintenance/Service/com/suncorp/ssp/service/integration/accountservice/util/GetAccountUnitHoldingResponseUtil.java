////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import java.util.ArrayList;
import java.util.List;

import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType;
import com.sonatacentral.service.v30.wrap.account.GetAccountUnitHoldingDetailResponseType;
import com.sonatacentral.service.v30.wrap.account.GetAccountUnitHoldingDetailResponseType.FundBalance;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.AccountDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.AccountNumberInfo;
import com.suncorp.ssp.service.integration.accountservice.bean.FundBalanceDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.GetAccountUnitHoldingsResponse;

/**
 * The class {@code GetAccountUnitHoldingResponseUtil} is a util class for retrieving response and creating response for GetAccountUnitHoldings.
 * 
 * @author U385424
 * @since 26/10/2016
 * @version 1.0
 */
public class GetAccountUnitHoldingResponseUtil {
    private final String className = "GetAccountUnitHoldingResponseUtil";
    private GetAccountUnitHoldingDetailResponseType inboundResponse;
    private GetAccountUnitHoldingsResponse outboundResponse;

    /**
     * This is a parameterized constructor.
     * 
     * @param inboundResponse
     */
    public GetAccountUnitHoldingResponseUtil(GetAccountUnitHoldingDetailResponseType inboundResponse) {
        this.inboundResponse = inboundResponse;
        this.outboundResponse = new GetAccountUnitHoldingsResponse();
    }

    /**
     * This method is used to create outbound response.
     * 
     * @return outboundResponse
     */
    public GetAccountUnitHoldingsResponse createOutboundResponse() throws SILException {
        SILLogger.debug(AccountServiceConstants.ACCOUNT_HOLDINGS_LOGGING_FORMAT, className, "Entering createOutboundResponse()");
        if (this.inboundResponse != null && this.inboundResponse.getAccount() != null) {
            AccountServiceUtil commonUtil = new AccountServiceUtil();
            outboundResponse.setAccount(retrieveAccountDetails(this.inboundResponse.getAccount()));
            if (this.inboundResponse.getFundBalance() != null && this.inboundResponse.getFundBalance().size() > 0) {
                outboundResponse.setFundBalance(retrieveFundBalance(this.inboundResponse.getFundBalance(), commonUtil));
            } else {
                outboundResponse.setFundBalance(retrieveEmptyFundBalance(commonUtil));
            }
        } else {
            throw new SILException(AccountServiceConstants.INVALID_RESPONSE_FROM_SONATA);
        }
        return this.outboundResponse;
    }

    /**
     * This method is use to retrieve Account details..
     * 
     * @param account
     * @return
     */
    private AccountDetails retrieveAccountDetails(AccountIdentifierType accountIdentifierType) {
        SILLogger.debug(AccountServiceConstants.ACCOUNT_HOLDINGS_LOGGING_FORMAT, className, "Entering retrieveAccountDetails()");
        AccountDetails accountDetails = new AccountDetails();
        if (accountIdentifierType != null && accountIdentifierType.getAccountNumber() != null &&
                accountIdentifierType.getAccountNumber().getAccountNo() != null) {
            AccountNumberInfo accountNumber = new AccountNumberInfo();
            accountNumber.setAccountNo(retrieveStringValue(accountIdentifierType.getAccountNumber().getAccountNo()));
            accountNumber.setProductName(retrieveStringValue(accountIdentifierType.getAccountNumber().getProductName()));
            accountDetails.setAccountNumber(accountNumber);
        }
        SILLogger.debug(AccountServiceConstants.ACCOUNT_HOLDINGS_LOGGING_FORMAT, className, "Exiting retrieveAccountDetails()");
        return accountDetails;
    }

    /**
     * This method is use to retrieve fund balance list.
     * 
     * @param fundBalanceInboundList
     * @param commonUtil
     * @return
     * @throws SILException
     */
    private List<FundBalanceDetails> retrieveFundBalance(List<FundBalance> fundBalanceInboundList, AccountServiceUtil commonUtil) throws SILException 
    {
        List<FundBalanceDetails> fundBalanceList = new ArrayList<FundBalanceDetails>();
        for (FundBalance balanceType : fundBalanceInboundList) {
            if (balanceType != null) {
                FundBalanceDetails balanceDetails = new FundBalanceDetails();
                retrieveFundBalanceDetails(balanceDetails, balanceType, commonUtil);
                fundBalanceList.add(balanceDetails);
            }
        }
        return fundBalanceList;
    }

    /**
     * this method is use to retrieve fund balance list.
     * 
     * @param balanceDetails
     * @param balanceType
     * @param commonUtil
     * @throws SILException
     */
    private void retrieveFundBalanceDetails(FundBalanceDetails balanceDetails, FundBalance balanceType, AccountServiceUtil commonUtil)
            throws SILException {
        balanceDetails.setWithholdingTax(commonUtil.retrieveBigDecimalValue(balanceType.getWithholdingTax(),
                AccountServiceConstants.ACCOUNT_HOLDINGS_LOGGING_FORMAT));
        balanceDetails.setId(commonUtil.retrieveLongValue(balanceType.getId(), AccountServiceConstants.ACCOUNT_HOLDINGS_LOGGING_FORMAT));
        balanceDetails.setValue(commonUtil.retrieveBigDecimalValue(balanceType.getValue(), AccountServiceConstants.ACCOUNT_HOLDINGS_LOGGING_FORMAT));
        balanceDetails.setUnits(commonUtil.retrieveBigDecimalValue(balanceType.getUnits(), AccountServiceConstants.ACCOUNT_HOLDINGS_LOGGING_FORMAT));
        balanceDetails
                .setPriceDate(commonUtil.retrieveDateValue(balanceType.getPriceDate(), AccountServiceConstants.ACCOUNT_HOLDINGS_LOGGING_FORMAT));
        balanceDetails.setPrice(commonUtil.retrieveBigDecimalValue(balanceType.getPrice(), AccountServiceConstants.ACCOUNT_HOLDINGS_LOGGING_FORMAT));
        balanceDetails.setNextMvaFreeDate(commonUtil.retrieveDateValue(balanceType.getNextMvaFreeDate(),
                AccountServiceConstants.ACCOUNT_HOLDINGS_LOGGING_FORMAT));
        balanceDetails.setNetInterest(commonUtil.retrieveBigDecimalValue(balanceType.getNetInterest(),
                AccountServiceConstants.ACCOUNT_HOLDINGS_LOGGING_FORMAT));
        balanceDetails.setGrossInterest(commonUtil.retrieveBigDecimalValue(balanceType.getGrossInterest(),
                AccountServiceConstants.ACCOUNT_HOLDINGS_LOGGING_FORMAT));
        balanceDetails.setExcludeFromRebalance(commonUtil.retrieveBooleanValue(balanceType.isExcludeFromRebalance(),
                AccountServiceConstants.ACCOUNT_HOLDINGS_LOGGING_FORMAT));
        balanceDetails.setFund(commonUtil.retrieveFundIdentifier(balanceType.getFund(), AccountServiceConstants.ACCOUNT_HOLDINGS_LOGGING_FORMAT));
        balanceDetails.setBalanceType(commonUtil.retrieveCode(balanceType.getBalanceType(), AccountServiceConstants.ACCOUNT_HOLDINGS_LOGGING_FORMAT));
    }

    /**
     * this method is use to set default result for fundBalance list.
     * 
     * @param commonUtil
     * 
     * @return
     * @throws SILException
     */
    private List<FundBalanceDetails> retrieveEmptyFundBalance(AccountServiceUtil commonUtil) throws SILException {
        SILLogger.debug(AccountServiceConstants.ACCOUNT_HOLDINGS_LOGGING_FORMAT, className, "Entering retrieveEmptyFundBalance()");
        List<FundBalanceDetails> emptylist = new ArrayList<FundBalanceDetails>();
        FundBalanceDetails balanceDetails = new FundBalanceDetails();
        balanceDetails.setWithholdingTax("");
        balanceDetails.setId("");
        balanceDetails.setValue("");
        balanceDetails.setUnits("");
        balanceDetails.setPriceDate("");
        balanceDetails.setPrice("");
        balanceDetails.setNextMvaFreeDate("");
        balanceDetails.setNetInterest("");
        balanceDetails.setGrossInterest("");
        balanceDetails.setExcludeFromRebalance("");
        balanceDetails.setFund(commonUtil.retrieveEmptyFundIdentifier(AccountServiceConstants.ACCOUNT_HOLDINGS_LOGGING_FORMAT));
        emptylist.add(balanceDetails);
        SILLogger.debug(AccountServiceConstants.ACCOUNT_HOLDINGS_LOGGING_FORMAT, className, "Exiting retrieveEmptyFundBalance()");
        return emptylist;
    }

    /**
     * This method check the null value for String.
     * 
     * @return String
     */
    public String retrieveStringValue(String value) {
        SILLogger.debug(AccountServiceConstants.ACCOUNT_HOLDINGS_LOGGING_FORMAT, className, "Entering in retrieveStringValue method");
        if (value != null) {
            return value;
        } else {
            return "";
        }
    }
}
