////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.suncorp.ssp.common.bean.SILErrorMessage;

/**
 * The class {@code SaveAccountBeneficiaryResponse} is a java bean consisting of all the properties related to saveAccountBeneficiary functionality,
 * to be used for constructing response for end-client.
 * 
 * @author U384381
 * @since 11/12/2015
 * @version 1.0
 */
@XmlRootElement(name = "SaveAccountBeneficiaryResponse")
public class SaveAccountBeneficiaryResponse extends SILErrorMessage {
    private String status;

    /**
     * Accessor for property status.
     * 
     * @return status of type String
     */
    public String getStatus() {
        return status;
    }

    /**
     * Mutator for property status.
     * 
     * @return status of type String
     */
    @XmlElement(name = "status")
    public void setStatus(String status) {
        this.status = status;
    }
}
