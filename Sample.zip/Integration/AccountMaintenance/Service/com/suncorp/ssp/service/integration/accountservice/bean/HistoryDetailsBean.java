////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code HistoryDetailsBean} does this.
 *
 * @author U387938
 * @since 12/09/2016
 * @version 1.0
 */
public class HistoryDetailsBean {

    private String id;
    private CodeIdentifier employmentStatus;
    private String startDate;
    private String notificationDate;
    private String endDate;
    private CodeIdentifier suspenseReason;
    
    /**
     * Accessor for property id.
     *
     * @return id of type String
     */
    public String getId() {
        return id;
    }
    /**
     * Mutator for property id.
     *
     * @param id of type String
     */
   @XmlElement(name = "id")
    public void setId(String id) {
       this.id = id != null ? id : "";
    }
    /**
     * Accessor for property employmentStatus.
     *
     * @return employmentStatus of type CodeIdentifier
     */
    public CodeIdentifier getEmploymentStatus() {
        return employmentStatus;
    }
    /**
     * Mutator for property employmentStatus.
     *
     * @param employmentStatus of type CodeIdentifier
     */
   @XmlElement(name = "employmentStatus")
    public void setEmploymentStatus(CodeIdentifier employmentStatus) {
        this.employmentStatus = employmentStatus;
    }
    /**
     * Accessor for property startDate.
     *
     * @return startDate of type String
     */
    public String getStartDate() {
        return startDate;
    }
    /**
     * Mutator for property startDate.
     *
     * @param startDate of type String
     */
   @XmlElement(name = "startDate")
    public void setStartDate(String startDate) {
       this.startDate = startDate != null ? startDate : "";
    }
    
   /**
    * Accessor for property notificationDate.
    *
    * @return notificationDate of type String
    */
   public String getNotificationDate() {
       return notificationDate;
   }
   /**
    * Mutator for property notificationDate.
    *
    * @param notificationDate of type String
    */
   @XmlElement(name = "notificationDate")
   public void setNotificationDate(String notificationDate) {
       this.notificationDate = notificationDate;
   }
   /**
    * Accessor for property endDate.
    *
    * @return endDate of type String
    */
   public String getEndDate() {
       return endDate;
   }
   /**
    * Mutator for property endDate.
    *
    * @param endDate of type String
    */
   @XmlElement(name = "endDate")
   public void setEndDate(String endDate) {
       this.endDate = endDate;
   }
   /**
    * Accessor for property suspenseReason.
    *
    * @return suspenseReason of type CodeIdentifier
    */
   public CodeIdentifier getSuspenseReason() {
       return suspenseReason;
   }
   /**
    * Mutator for property suspenseReason.
    *
    * @param suspenseReason of type CodeIdentifier
    */
   @XmlElement(name = "suspenseReason")
   public void setSuspenseReason(CodeIdentifier suspenseReason) {
       this.suspenseReason = suspenseReason;
   }
}
