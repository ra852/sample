////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code CurrentAccountExpenseGroupBean} does this.
 *
 * @author U387938
 * @since 04/08/2016
 * @version 1.0
 */
public class CurrentAccountExpenseGroupBean {
    
    private String accountExpenseId;
    private String expenseGroupId;
    private String effectiveDate;
    /**
     * Accessor for property accountExpenseId.
     *
     * @return accountExpenseId of type String
     */
    public String getAccountExpenseId() {
        return accountExpenseId;
    }
    /**
     * Mutator for property accountExpenseId.
     *
     * @param accountExpenseId of type String
     */
    @XmlElement(name = "accountExpenseId")
    public void setAccountExpenseId(String accountExpenseId) {
        this.accountExpenseId = accountExpenseId != null ? accountExpenseId : "";
    }
    /**
     * Accessor for property expenseGroupId.
     *
     * @return expenseGroupId of type String
     */
    public String getExpenseGroupId() {
        return expenseGroupId;
    }
    /**
     * Mutator for property expenseGroupId.
     *
     * @param expenseGroupId of type String
     */
    @XmlElement(name = "expenseGroupId")
    public void setExpenseGroupId(String expenseGroupId) {
        this.expenseGroupId = expenseGroupId != null ? expenseGroupId : "";
    }
    /**
     * Accessor for property effectiveDate.
     *
     * @return effectiveDate of type String
     */
    public String getEffectiveDate() {
        return effectiveDate;
    }
    /**
     * Mutator for property effectiveDate.
     *
     * @param effectiveDate of type String
     */
    @XmlElement(name = "effectiveDate")
    public void setEffectiveDate(String effectiveDate) {
        this.effectiveDate = effectiveDate != null ? effectiveDate : "";
    }
    
    

}
