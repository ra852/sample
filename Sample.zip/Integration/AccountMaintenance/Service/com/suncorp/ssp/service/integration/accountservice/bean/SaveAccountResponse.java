////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.suncorp.ssp.common.bean.SILErrorMessage;

/**
 * The class {@code SaveAccountResponse} does this.
 * 
 * @author U383847
 * @since 29/03/2016
 * @version 1.0
 */
@XmlRootElement(name = "SaveAccountResponse")
public class SaveAccountResponse extends SILErrorMessage {
    private AccountIdentifierDetails account;

    /**
     * Accessor for property account.
     * 
     * @return account of type AccountIdentifierDetails
     */
    public AccountIdentifierDetails getAccount() {
        return account;
    }

    /**
     * Mutator for property account.
     * 
     * @param account of type AccountIdentifierDetails
     */
    @XmlElement(name = "account")
    public void setAccount(AccountIdentifierDetails account) {
        this.account = account;
    }
}
