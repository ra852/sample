////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code CalculationBasisDetails} does this.
 * 
 * @author U383754
 * @since 02/02/2016
 * @version 1.0
 */
public class CalculationBasisDetails {
    private String id;
    private CodeIdentifier calculationBook;
    private DecimalRangeIdentifier amount;
    private DecimalRangeIdentifier percentage;

    /**
     * Accessor for property id.
     * 
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     * 
     * @return id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id != null ? id : "";
    }

    /**
     * Accessor for property calculationBook.
     * 
     * @return calculationBook of type CodeIdentifier
     */
    public CodeIdentifier getCalculationBook() {
        return calculationBook;
    }

    /**
     * Mutator for property calculationBook.
     * 
     * @return calculationBook of type CodeIdentifier
     */
    @XmlElement(name = "calculationBook")
    public void setCalculationBook(CodeIdentifier calculationBook) {
        this.calculationBook = calculationBook;
    }

    /**
     * Accessor for property amount.
     *
     * @return amount of type DeciamlRangeIdentifier
     */
    public DecimalRangeIdentifier getAmount() {
        return amount;
    }

    /**
     * Mutator for property amount.
     *
     * @param amount of type DeciamlRangeIdentifier
     */
    @XmlElement(name = "amount")
    public void setAmount(DecimalRangeIdentifier amount) {
        this.amount = amount;
    }

    /**
     * Accessor for property percentage.
     *
     * @return percentage of type DeciamlRangeIdentifier
     */
    public DecimalRangeIdentifier getPercentage() {
        return percentage;
    }

    /**
     * Mutator for property percentage.
     *
     * @param percentage of type DeciamlRangeIdentifier
     */
    @XmlElement(name = "percentage")
    public void setPercentage(DecimalRangeIdentifier percentage) {
        this.percentage = percentage;
    }

    
}
