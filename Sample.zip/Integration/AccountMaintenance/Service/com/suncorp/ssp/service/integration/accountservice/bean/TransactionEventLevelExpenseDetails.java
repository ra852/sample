////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code TransactionEventLevelExpenseDetails} is a pure java bean consisting of properties related to TransactionEventLevelExpenseDetails.
 * 
 * @author U385424
 * @since 23/01/2017
 * @version 1.0
 */
public class TransactionEventLevelExpenseDetails {
    private String expenseType;
    private String expTypeDesc;
    private String balanceEffect;
    private String feeEffect;
    private String deductionAmount;
    private String originalAmount;
    private String percentage;
    private CodeIdentifier contType;
    private BenefitDetails benefitType;
    private FundIdentifierDetails fund;

    /**
     * Accessor for property expenseType.
     * 
     * @return expenseType of type String
     */
    public String getExpenseType() {
        return expenseType;
    }

    /**
     * Mutator for property expenseType.
     * 
     * @param expenseType of type String
     */
    @XmlElement(name = "expenseType")
    public void setExpenseType(String expenseType) {
        this.expenseType = expenseType != null ? expenseType : "";
    }

    /**
     * Accessor for property expTypeDesc.
     * 
     * @return expTypeDesc of type String
     */
    public String getExpTypeDesc() {
        return expTypeDesc;
    }

    /**
     * Mutator for property expTypeDesc.
     * 
     * @param expTypeDesc of type String
     */
    @XmlElement(name = "expTypeDesc")
    public void setExpTypeDesc(String expTypeDesc) {
        this.expTypeDesc = expTypeDesc != null ? expTypeDesc : "";
    }

    /**
     * Accessor for property balanceEffect.
     * 
     * @return balanceEffect of type String
     */
    public String getBalanceEffect() {
        return balanceEffect;
    }

    /**
     * Mutator for property balanceEffect.
     * 
     * @param balanceEffect of type String
     */
    @XmlElement(name = "balanceEffect")
    public void setBalanceEffect(String balanceEffect) {
        this.balanceEffect = balanceEffect != null ? balanceEffect : "";
    }

    /**
     * Accessor for property feeEffect.
     * 
     * @return feeEffect of type String
     */
    public String getFeeEffect() {
        return feeEffect;
    }

    /**
     * Mutator for property feeEffect.
     * 
     * @param feeEffect of type String
     */
    @XmlElement(name = "feeEffect")
    public void setFeeEffect(String feeEffect) {
        this.feeEffect = feeEffect != null ? feeEffect : "";
    }

    /**
     * Accessor for property deductionAmount.
     * 
     * @return deductionAmount of type String
     */
    public String getDeductionAmount() {
        return deductionAmount;
    }

    /**
     * Mutator for property deductionAmount.
     * 
     * @param deductionAmount of type String
     */
    @XmlElement(name = "deductionAmount")
    public void setDeductionAmount(String deductionAmount) {
        this.deductionAmount = deductionAmount != null ? deductionAmount : "";
    }

    /**
     * Accessor for property originalAmount.
     * 
     * @return originalAmount of type String
     */
    public String getOriginalAmount() {
        return originalAmount;
    }

    /**
     * Mutator for property originalAmount.
     * 
     * @param originalAmount of type String
     */
    @XmlElement(name = "originalAmount")
    public void setOriginalAmount(String originalAmount) {
        this.originalAmount = originalAmount != null ? originalAmount : "";
    }

    /**
     * Accessor for property percentage.
     * 
     * @return percentage of type String
     */
    public String getPercentage() {
        return percentage;
    }

    /**
     * Mutator for property percentage.
     * 
     * @param percentage of type String
     */
    @XmlElement(name = "percentage")
    public void setPercentage(String percentage) {
        this.percentage = percentage != null ? percentage : "";
    }

    /**
     * Accessor for property contType.
     * 
     * @return contType of type CodeIdentifier
     */
    public CodeIdentifier getContType() {
        return contType;
    }

    /**
     * Mutator for property contType.
     * 
     * @param contType of type CodeIdentifier
     */
    @XmlElement(name = "contType")
    public void setContType(CodeIdentifier contType) {
        this.contType = contType;
    }

    /**
     * Accessor for property benefitType.
     * 
     * @return benefitType of type BenefitDetails
     */
    public BenefitDetails getBenefitType() {
        return benefitType;
    }

    /**
     * Mutator for property benefitType.
     * 
     * @param benefitType of type BenefitDetails
     */
    @XmlElement(name = "benefitType")
    public void setBenefitType(BenefitDetails benefitType) {
        this.benefitType = benefitType;
    }

    /**
     * Accessor for property fund.
     * 
     * @return fund of type FundIdentifierDetails
     */
    public FundIdentifierDetails getFund() {
        return fund;
    }

    /**
     * Mutator for property fund.
     * 
     * @param fund of type FundIdentifierDetails
     */
    @XmlElement(name = "fund")
    public void setFund(FundIdentifierDetails fund) {
        this.fund = fund;
    }
}
