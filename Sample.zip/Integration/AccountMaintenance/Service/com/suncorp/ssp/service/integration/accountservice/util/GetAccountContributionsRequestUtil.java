////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import java.util.List;

import javax.ws.rs.core.MultivaluedMap;

import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.DateRangeType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType.AccountNumber;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.ContributionSelectCriteria;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.RetrievalDateIndicator;
import com.sonatacentral.service.v30.wrap.account.GetAccountContributionsRequestType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;

/**
 * The class {@code GetAccountContributionsRequestUtil} is used as a util class for preparing GetAccountContributions request.
 * 
 * @author U201468
 * @since 19/09/2017
 * @version 1.0
 */
public class GetAccountContributionsRequestUtil {
    private final String className = "GetAccountContributionsRequestUtil";
    private GetAccountContributionsRequestType outboundRequest;
    private MultivaluedMap<String, String> inboundRequest;

    /**
     * Initializes class properties,viz., inbound and outbound request types.
     * 
     * @param inboundRequest of type MultivaluedMap
     */
    public GetAccountContributionsRequestUtil(MultivaluedMap<String, String> inboundRequest) {
        this.inboundRequest = inboundRequest;
        this.outboundRequest = new GetAccountContributionsRequestType();
    }

    /**
     * Create Outbound request.
     * 
     * @return outboundRequest of type GetAccountContributionsRequestType
     * @throws SILException
     */
    public GetAccountContributionsRequestType createOutboundRequest() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACCOUNT_CONTRIBUTIONS_LOGGING_FORMAT, className, "Entering createOutboundRequest()");
        this.outboundRequest.setCallerDetails(SILUtil.createCallerDetails());
        if (this.inboundRequest.containsKey(AccountServiceConstants.ACCOUNT_NO)) {
            retrieveAccountNumber();
        } else {
            throw new SILException(AccountServiceConstants.INVALID_REQUEST_MESSAGE);
        }
        this.outboundRequest.setContributionSelectCriteria(retrieveContributionSelectCriteria());
        if (this.inboundRequest.containsKey(AccountServiceConstants.INCLUDE_ALL_CONTRIBUTIONS_FLAG)) {
            this.outboundRequest.setIncludeAllContributions(Boolean.valueOf(this.inboundRequest.get(
                    AccountServiceConstants.INCLUDE_ALL_CONTRIBUTIONS_FLAG).get(0)));
        }
        return this.outboundRequest;
    }

    /**
     * Create a new instance of ContributionSelectCriteria, with necessary values set.
     * 
     * @return contributionSelectCriteria
     * @throws SILException
     */
    private ContributionSelectCriteria retrieveContributionSelectCriteria() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACCOUNT_CONTRIBUTIONS_LOGGING_FORMAT, className, "Entering retrieveContributionSelectCriteria()");
        ContributionSelectCriteria contributionSelectCriteria = new ContributionSelectCriteria();
        contributionSelectCriteria.setRetrievalDateIndicator(RetrievalDateIndicator.TREV_EFFECTIVE_DATE);
        contributionSelectCriteria.setContributionPeriod(retrieveContributionPeriod());
        return contributionSelectCriteria;
    }

    /**
     * Create a new instance of DateRangeType, with necessary values set.
     * 
     * @return dateRangeType
     * @throws SILException
     */
    private DateRangeType retrieveContributionPeriod() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACCOUNT_CONTRIBUTIONS_LOGGING_FORMAT, className, "Entering retrieveContributionPeriod()");
        DateRangeType dateRangeType = new DateRangeType();
        if (this.inboundRequest.containsKey(AccountServiceConstants.CONTRIBUTION_PERIOD_FROM)) {
            dateRangeType.setFrom(SILUtil.convertStringToXMLGregorianCalendar(
                    this.inboundRequest.get(AccountServiceConstants.CONTRIBUTION_PERIOD_FROM).get(0), CommonConstants.DATE_FORMAT));
        }
        if (this.inboundRequest.containsKey(AccountServiceConstants.CONTRIBUTION_PERIOD_TO)) {
            String datetime = this.inboundRequest.get(AccountServiceConstants.CONTRIBUTION_PERIOD_TO).get(0) + " 23:59:59";
            dateRangeType.setTo(SILUtil.convertStringToXMLGregorianCalendar(datetime, CommonConstants.DATETIME_FORMAT));
        }
        return dateRangeType;
    }

    /**
     * Create a new instance of retrieveAccountNumber, with necessary values set.
     * 
     */
    private void retrieveAccountNumber() {
        SILLogger.debug(AccountServiceConstants.GET_ACCOUNT_CONTRIBUTIONS_LOGGING_FORMAT, className, "Entering retrieveAccountNumber()");
        List<GetAccountContributionsRequestType.AccountDetails> accountDetailTypeList = outboundRequest.getAccountDetails();
        GetAccountContributionsRequestType.AccountDetails accountDetails = new GetAccountContributionsRequestType.AccountDetails();
        AccountIdentifierType accountIdentifierType = new AccountIdentifierType();
        AccountNumber accountNumber = new AccountNumber();
        accountNumber.setAccountNo(this.inboundRequest.get(AccountServiceConstants.ACCOUNT_NO).get(0));
        accountIdentifierType.setAccountNumber(accountNumber);
        accountDetails.setAccount(accountIdentifierType);
        accountDetailTypeList.add(accountDetails);
    }

}
