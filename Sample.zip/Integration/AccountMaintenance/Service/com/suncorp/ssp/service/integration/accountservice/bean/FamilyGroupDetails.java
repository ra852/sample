////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code FamilyGroupDetails} does this.
 * 
 * @author U384380
 * @since 11/11/2016
 * @version 1.0
 */
public class FamilyGroupDetails {
    private FamilyGroupIdentifier familyGroupIdentifier;
    private String familyGroupName;
    private CodeIdentifier groupType;
    private CodeIdentifier status;

    /**
     * Accessor for property familyGroupIdentifier.
     * 
     * @return familyGroupIdentifier of type FamilyGroupIdentifier
     */
    public FamilyGroupIdentifier getFamilyGroupIdentifier() {
        return familyGroupIdentifier;
    }

    /**
     * Mutator for property familyGroupIdentifier.
     * 
     * @return familyGroupIdentifier of type FamilyGroupIdentifier
     */
    @XmlElement(name = "familyGroupIdentifier")
    public void setFamilyGroupIdentifier(FamilyGroupIdentifier familyGroupIdentifier) {
        this.familyGroupIdentifier = familyGroupIdentifier;
    }

    /**
     * Accessor for property familyGroupName.
     * 
     * @return familyGroupName of type String
     */
    public String getFamilyGroupName() {
        return familyGroupName;
    }

    /**
     * Mutator for property familyGroupName.
     * 
     * @return familyGroupName of type String
     */
    @XmlElement(name = "familyGroupName")
    public void setFamilyGroupName(String familyGroupName) {
        this.familyGroupName = familyGroupName != null ? familyGroupName : "";
    }

    /**
     * Accessor for property groupType.
     * 
     * @return groupType of type CodeIdentifier
     */
    public CodeIdentifier getGroupType() {
        return groupType;
    }

    /**
     * Mutator for property groupType.
     * 
     * @return groupType of type CodeIdentifier
     */
    @XmlElement(name = "groupType")
    public void setGroupType(CodeIdentifier groupType) {
        this.groupType = groupType;
    }

    /**
     * Accessor for property status.
     * 
     * @return status of type CodeIdentifier
     */
    public CodeIdentifier getStatus() {
        return status;
    }

    /**
     * Mutator for property status.
     * 
     * @return status of type CodeIdentifier
     */
    @XmlElement(name = "status")
    public void setStatus(CodeIdentifier status) {
        this.status = status;
    }

}
