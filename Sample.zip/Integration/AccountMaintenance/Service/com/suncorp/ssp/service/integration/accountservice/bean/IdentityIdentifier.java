////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code CommonIdentifier} does this.
 * 
 * @author U383754
 * @since 01/02/2016
 * @version 1.0
 */
public class IdentityIdentifier {
    private String id;
    private String name;
    private AuditIdentifier audit;

    /**
     * Accessor for property id.
     * 
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     * 
     * @return id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id != null ? id : "";
    }

    /**
     * Accessor for property name.
     * 
     * @return name of type String
     */
    public String getName() {
        return name;
    }

    /**
     * Mutator for property name.
     * 
     * @return name of type String
     */
    @XmlElement(name = "name")
    public void setName(String name) {
        this.name = name != null ? name : "";
    }

    /**
     * @return the audit
     */
    public AuditIdentifier getAudit() {
        return audit;
    }

    /**
     * @param audit the audit to set
     */
    @XmlElement(name = "audit")
    public void setAudit(AuditIdentifier audit) {
        this.audit = audit;
    }

}
