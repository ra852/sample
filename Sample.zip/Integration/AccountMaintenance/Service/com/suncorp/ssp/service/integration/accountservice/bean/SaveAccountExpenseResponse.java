////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.suncorp.ssp.common.bean.SILErrorMessage;

/**
 * The class {@code SaveAccountExpenseResponse} does this.
 * 
 * @author U387938
 * @since 05/08/2016
 * @version 1.0
 */
@XmlRootElement(name = "SaveAccountExpenseResponse")
public class SaveAccountExpenseResponse extends SILErrorMessage {

    private String response;

    /**
     * Accessor for property response.
     * 
     * @return response of type String
     */
    public String getResponse() {
        return response;
    }

    /**
     * Mutator for property response.
     * 
     * @param response of type String
     */
    @XmlElement(name = "response")
    public void setResponse(String response) {
        this.response = response;
    }

}
