////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.sonatacentral.service.v30.globaltypes.wrap.transaction.transactiongrouptype.TransSummaryDetailType;
import com.sonatacentral.service.v30.globaltypes.wrap.transaction.transactiongrouptype.TransSummaryItemType;
import com.sonatacentral.service.v30.wrap.account.GetAccountTransactionSummaryResponseType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.GetAccountTransactionSummaryResponse;
import com.suncorp.ssp.service.integration.accountservice.bean.TransSummaryItemTypeList;

/**
 * The class {@code GetAccountTransactionSummaryResponseUtil} is a Utility class with all the properties related to
 * GetAccountTransactionSummaryResponse to construct response for end client.
 * 
 * @author u385424
 * @since 15/12/2015
 * @version 1.0
 */
public class GetAccountTransactionSummaryResponseUtil {
    private final String className = "GetAccountTransactionSummaryResponse";
    private GetAccountTransactionSummaryResponseType inboundResponse;
    private GetAccountTransactionSummaryResponse outboundResponse;
    private List<TransSummaryDetailType> inboundTransSummDetList;
    private BigDecimal totalOpeningBalanceAmount = BigDecimal.ZERO;
    private BigDecimal totalClosingBalanceAmount = BigDecimal.ZERO;
    private BigDecimal totalInvestmentEarningsAmount = BigDecimal.ZERO;
    private List<TransSummaryItemType> inboundTransSummItemList;
    private Map<String, TransSummaryItemTypeList> descAmtMap;

    /**
     * Parameterized constructor for creating Out bound response Object.
     * 
     * @param inboundResponse
     */

    public GetAccountTransactionSummaryResponseUtil(GetAccountTransactionSummaryResponseType inboundResponse) {
        this.inboundResponse = inboundResponse;
        this.outboundResponse = new GetAccountTransactionSummaryResponse();
    }

    /**
     * this method populates the outbound response Object from Inbound response .
     * 
     * @return outboundResponse
     * @throws SILException
     */
    public GetAccountTransactionSummaryResponse createOutboundResponse() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_TRANS_SUMM_LOGGING_FORMAT, className, "Entering in Response Util.");
        List<TransSummaryItemTypeList> tempOutboundTransSummItemList = new ArrayList<TransSummaryItemTypeList>();
        if (this.inboundResponse != null && this.inboundResponse.getTransSummDetail() != null) {
            this.inboundTransSummDetList = this.inboundResponse.getTransSummDetail();
            this.descAmtMap = new HashMap<String, TransSummaryItemTypeList>();
            for (TransSummaryDetailType transSummDetail : this.inboundTransSummDetList) {
                accumulateBalanceAmount(transSummDetail);
                inboundTransSummItemList = transSummDetail.getTransactionSummaryItem();
                accumulateItems(this.inboundTransSummItemList);
            }
            setTempOutboundTransSummItemList(tempOutboundTransSummItemList);
            this.outboundResponse.setClosingBalanceAmount(this.totalClosingBalanceAmount);
            this.outboundResponse.setOpeningBalanceAmount(this.totalOpeningBalanceAmount);
            this.outboundResponse.setInvestmentEarningsAmount(this.totalInvestmentEarningsAmount);
            if (tempOutboundTransSummItemList != null && tempOutboundTransSummItemList.size() > 0) {
                this.outboundResponse.setTransSummaryItemType(tempOutboundTransSummItemList);
            } else {
                this.outboundResponse.setTransSummaryItemType(getDefaultItemList(new TransSummaryItemTypeList(), tempOutboundTransSummItemList));
            }
        } else {
            this.outboundResponse = getDefaultResponse(new TransSummaryItemTypeList(), tempOutboundTransSummItemList);
        }
        return outboundResponse;
    }

    /**
     * this method accumulates the Balance Amount at fund level.
     * 
     * @param transSummDetail
     */
    private void accumulateBalanceAmount(TransSummaryDetailType transSummDetail) {
        SILLogger.debug(AccountServiceConstants.GET_ACC_TRANS_SUMM_LOGGING_FORMAT, className, "Entering accumulateBalanceAmount in Response Util.");
        totalOpeningBalanceAmount = totalOpeningBalanceAmount.add(transSummDetail.getOpeningBalanceAmount());
        totalClosingBalanceAmount = totalClosingBalanceAmount.add(transSummDetail.getClosingBalanceAmount());
        totalInvestmentEarningsAmount = totalInvestmentEarningsAmount.add(transSummDetail.getInvestmentEarningsAmount());
    }

    /**
     * this method populates the map descAmtMap for all the Transaction items .
     * 
     * @param inboundTransSummItemList
     */
    private void accumulateItems(List<TransSummaryItemType> inboundTransSummItemList) {
        SILLogger.debug(AccountServiceConstants.GET_ACC_TRANS_SUMM_LOGGING_FORMAT, className, "Entering accumulateItems in Response Util.");
        String descKey = null;
        TransSummaryItemTypeList transSummaryItemTypeList = null;
        for (TransSummaryItemType transSummaryItemType : inboundTransSummItemList) {

            descKey = transSummaryItemType.getDescription();
            if (descAmtMap.containsKey(descKey)) {
                transSummaryItemTypeList = descAmtMap.get(descKey);
                transSummaryItemTypeList.setTotalAmount(transSummaryItemTypeList.getTotalAmount().add(transSummaryItemType.getTotalAmount()));
                descAmtMap.put(descKey, transSummaryItemTypeList);
            } else {
                transSummaryItemTypeList = new TransSummaryItemTypeList();
                transSummaryItemTypeList.setTotalAmount(transSummaryItemType.getTotalAmount());
                transSummaryItemTypeList.setDisplayOrder(transSummaryItemType.getDisplayOrder());
                descAmtMap.put(descKey, transSummaryItemTypeList);
            }
        }
    }

    /**
     * this method populates the Temporary Outbound array list containing the sum total of items across the funds.
     * 
     * @param tempOutboundTransSummItemList
     */
    private void setTempOutboundTransSummItemList(List<TransSummaryItemTypeList> tempOutboundTransSummItemList) {
        SILLogger.debug(AccountServiceConstants.GET_ACC_TRANS_SUMM_LOGGING_FORMAT, className,
                "Entering setTempOutboundTransSummItemList ResponseUtil.");
        for (Map.Entry<String, TransSummaryItemTypeList> transactionSummaryItem : descAmtMap.entrySet()) {
            TransSummaryItemTypeList transSummaryItemType = new TransSummaryItemTypeList();
            transSummaryItemType.setDescription(transactionSummaryItem.getKey());
            transSummaryItemType.setTotalAmount(transactionSummaryItem.getValue().getTotalAmount());
            transSummaryItemType.setDisplayOrder(transactionSummaryItem.getValue().getDisplayOrder());
            tempOutboundTransSummItemList.add(transSummaryItemType);
        }
    }

    /**
     * this method populates the default zeros for Balance amount @ fund level and default array list for items .
     * 
     * @param transSummaryItemType
     * @param tempOutboundTransSummItemList
     * @return outboundResponse
     */
    private GetAccountTransactionSummaryResponse getDefaultResponse(TransSummaryItemTypeList transSummaryItemType,
            List<TransSummaryItemTypeList> tempOutboundTransSummItemList) {
        SILLogger.debug(AccountServiceConstants.GET_ACC_TRANS_SUMM_LOGGING_FORMAT, className, "GetAccountTransactionSummaryResponse ResponseUtil.");
        outboundResponse.setClosingBalanceAmount(BigDecimal.ZERO);
        outboundResponse.setOpeningBalanceAmount(BigDecimal.ZERO);
        outboundResponse.setInvestmentEarningsAmount(BigDecimal.ZERO);
        outboundResponse.setTransSummaryItemType(getDefaultItemList(transSummaryItemType, tempOutboundTransSummItemList));
        return outboundResponse;
    }

    /**
     * this method populates the default array list for items.
     * 
     * @param transSummaryItemType
     * @param tempOutboundTransSummItemList
     * @return tempOutboundTransSummItemList
     */
    private List<TransSummaryItemTypeList> getDefaultItemList(TransSummaryItemTypeList transSummaryItemType,
            List<TransSummaryItemTypeList> tempOutboundTransSummItemList) {
        SILLogger.debug(AccountServiceConstants.GET_ACC_TRANS_SUMM_LOGGING_FORMAT, className, "Entering getDefaultItemList in  Response Util.");
        transSummaryItemType.setDescription("");
        transSummaryItemType.setTotalAmount(BigDecimal.ZERO);
        transSummaryItemType.setDisplayOrder(0L);
        tempOutboundTransSummItemList.add(transSummaryItemType);
        return tempOutboundTransSummItemList;
    }
}
