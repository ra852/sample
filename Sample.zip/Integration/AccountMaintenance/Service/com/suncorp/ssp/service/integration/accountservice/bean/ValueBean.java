////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code ValueBean} is simple POJO for generic variable.
 * 
 * @author U384381
 * @since 06/05/2016
 * @version 1.0
 */
public class ValueBean {
    private CodeIdentifier code;
    private String decimal;
    private String integer;
    private String datetime;
    private String checked;
    private String string;

    /**
     * Accessor for property code.
     * 
     * @return code of type CodeIdentifier
     */
    public CodeIdentifier getCode() {
        return code;
    }

    /**
     * Mutator for property code.
     * 
     * @param code of type CodeIdentifier
     */
    @XmlElement(name = "code")
    public void setCode(CodeIdentifier code) {
        this.code = code;
    }

    /**
     * Accessor for property decimal.
     *
     * @return decimal of type String
     */
    public String getDecimal() {
        return decimal;
    }

    /**
     * Mutator for property decimal.
     *
     * @param decimal of type String
     */
    @XmlElement(name = "decimal")
    public void setDecimal(String decimal) {
        this.decimal = decimal;
    }

    /**
     * Accessor for property integer.
     *
     * @return integer of type String
     */
    public String getInteger() {
        return integer;
    }

    /**
     * Mutator for property integer.
     *
     * @param integer of type String
     */
    @XmlElement(name = "integer")
    public void setInteger(String integer) {
        this.integer = integer;
    }

    /**
     * Accessor for property datetime.
     *
     * @return datetime of type String
     */
    public String getDatetime() {
        return datetime;
    }

    /**
     * Mutator for property datetime.
     *
     * @param datetime of type String
     */
    @XmlElement(name = "datetime")
    public void setDatetime(String datetime) {
        this.datetime = datetime;
    }

    /**
     * Accessor for property checked.
     *
     * @return checked of type String
     */
    public String getChecked() {
        return checked;
    }

    /**
     * Mutator for property checked.
     *
     * @param checked of type String
     */
    @XmlElement(name = "checked")
    public void setChecked(String checked) {
        this.checked = checked;
    }

    /**
     * Accessor for property string.
     *
     * @return string of type String
     */
    public String getString() {
        return string;
    }

    /**
     * Mutator for property string.
     *
     * @param string of type String
     */
    @XmlElement(name = "string")
    public void setString(String string) {
        this.string = string;
    }
    
}
