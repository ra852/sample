////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import com.sonatacentral.service.v30.globaltypes.wrap.transaction.transactiongrouptype.TransEvtAccTransType;
import com.sonatacentral.service.v30.globaltypes.wrap.transaction.transactiongrouptype.TransEvtDetailType;
import com.sonatacentral.service.v30.service.ValidationMessage;
import com.sonatacentral.service.v30.wrap.account.GetAccountTransactionListResponseType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.GetSwitchStatusResponseBean;
import com.suncorp.ssp.service.integration.accountservice.bean.PagingRange;
import com.suncorp.ssp.service.integration.accountservice.bean.TransEvent;
import com.suncorp.ssp.service.integration.accountservice.bean.TransEventDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.TransType;

/**
 * The class {@code GetSwitchStatusResponseUtil} is used as a util class for preparing GetSwitchStatus response.
 * 
 * @author u385424
 * @since 29/07/2016
 * @version 1.0
 */
public class GetSwitchStatusResponseUtil {
    private final String className = "GetSwitchStatusResponseUtil";
    private GetAccountTransactionListResponseType inboundResponse;
    private GetSwitchStatusResponseBean outboundResponse;
    private TransEvtDetailType transEvtDetailType;

    /**
     * Initializes class properties,viz., inbound and outbound response types.
     * 
     * @param inboundResponse
     */
    public GetSwitchStatusResponseUtil(GetAccountTransactionListResponseType inboundResponse) {
        this.inboundResponse = inboundResponse;
        this.outboundResponse = new GetSwitchStatusResponseBean();
    }

    /**
     * create the outbound response.
     * 
     * @return outboundResponse of type GetSwitchStatusResponseBean
     * @throws SILException
     */
    public GetSwitchStatusResponseBean createOutboundResponse() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_SWITCH_STATUS_LOGGING_FORMAT, className, "Entering createOutboundResponse()");
        List<TransEventDetails> transEvtDetailsList = new ArrayList<TransEventDetails>();
        PagingRange pagingRange = new PagingRange();
        if (this.inboundResponse != null && this.inboundResponse.getTransEvtDetail() != null && this.inboundResponse.getTransEvtDetail().size() > 0) {
            addTransEventDetailsToList(transEvtDetailsList);
        } else if (this.inboundResponse.getValidationMessage() != null && this.inboundResponse.getValidationMessage().size() > 0) {
            this.sendValidationMessages(this.inboundResponse.getValidationMessage(), AccountServiceConstants.GET_SWITCH_STATUS_LOGGING_FORMAT);
        } else {
            throw new SILException(AccountServiceConstants.GETACC_TRANS_LIST_RECORD_NOT_EXIST);
        }
        if (this.inboundResponse.getTransEvtDetailsPaging() != null) {
            pagingRange = addTransEvtDetailsPaging();
        } else {
            pagingRange = getDefaultTransEvtDetailsPaging();
        }
        outboundResponse.setTransEvtDetail(transEvtDetailsList);
        outboundResponse.setPagingRange(pagingRange);
        SILLogger.debug(AccountServiceConstants.GET_SWITCH_STATUS_LOGGING_FORMAT, className, "Exiting createOutboundResponse()");
        return this.outboundResponse;
    }

    /**
     * This method is used to send validation message to the consumer.
     * 
     * @param list of type List<ValidationMessage>
     * @param loggerType
     * @throws SILException
     */
    public void sendValidationMessages(List<ValidationMessage> list, String loggerType) throws SILException {
        SILLogger.debug(loggerType, className, "Entering in sendValidationMessages");
        List<ValidationMessage> validationMessageList = list;
        for (ValidationMessage validationMessage : validationMessageList) {
            if (validationMessage.getSeverity() != null) {
                if (validationMessage.getSeverity().equalsIgnoreCase(AccountServiceConstants.SEVERITY_ERROR) ||
                        validationMessage.getSeverity().equalsIgnoreCase(AccountServiceConstants.SEVERITY_DEBUG) ||
                        validationMessage.getSeverity().equalsIgnoreCase(AccountServiceConstants.SEVERITY_FATAL)) {
                    throw new SILException(validationMessage.getMessage());
                } else if (validationMessage.getSeverity().equalsIgnoreCase(AccountServiceConstants.SEVERITY_INFO)) {
                    throw new SILException(AccountServiceConstants.INVALID_RESPONSE_FROM_SONATA);
                }
            }
        }
        SILLogger.debug(loggerType, className, "Exiting from sendValidationMessages");
    }

    /**
     * Get a new instance of PagingRange, with necessary values set.
     * 
     * @return pagingRange of type PagingRange
     */
    private PagingRange addTransEvtDetailsPaging() {
        SILLogger.debug(AccountServiceConstants.GET_SWITCH_STATUS_LOGGING_FORMAT, className, "Entering addTransEvtDetailsPaging()");
        PagingRange pagingRange = new PagingRange();
        if (Integer.toString(this.inboundResponse.getTransEvtDetailsPaging().getFirstResult()) != null) {
            pagingRange.setFirstResult(this.inboundResponse.getTransEvtDetailsPaging().getFirstResult());
        }
        if (Integer.toString(this.inboundResponse.getTransEvtDetailsPaging().getResultsPerPage()) != null) {
            pagingRange.setResultsPerPage(this.inboundResponse.getTransEvtDetailsPaging().getResultsPerPage());
        }
        if (Integer.toString(this.inboundResponse.getTransEvtDetailsPaging().getTotalResults()) != null) {
            pagingRange.setTotalResults(this.inboundResponse.getTransEvtDetailsPaging().getTotalResults());
        }
        return pagingRange;
    }

    /**
     * Get a new instance of PagingRange, with default values set of PagingRange.
     * 
     * @return pagingRange of type PagingRange
     */
    private PagingRange getDefaultTransEvtDetailsPaging() {
        SILLogger.debug(AccountServiceConstants.GET_SWITCH_STATUS_LOGGING_FORMAT, className, "Entering getDefaultTransEvtDetailsPaging()");
        PagingRange pagingRange = new PagingRange();
        pagingRange.setFirstResult(0);
        pagingRange.setResultsPerPage(0);
        pagingRange.setTotalResults(0);
        return pagingRange;
    }

    /**
     * Get a new instance of TransType, with default values set of TransType.
     * 
     * @return transType of type TransType
     */
    private TransType getDefaultTransType() {
        SILLogger.debug(AccountServiceConstants.GET_SWITCH_STATUS_LOGGING_FORMAT, className, "Entering getDefaultTransType()");
        TransType transType = new TransType();
        transType.setCode("");
        transType.setDesc("");
        return transType;
    }

    /**
     * Preparation of TransEventDetails List, with necessary parameters values.
     * 
     * @throws SILException
     * 
     */
    private void addTransEventDetailsToList(List<TransEventDetails> transEvtDetailsList) throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_SWITCH_STATUS_LOGGING_FORMAT, className, "Entering addTransEventDetailsToList()");
        List<TransEvtDetailType> transEvtDetailTypeList = this.inboundResponse.getTransEvtDetail();
        for (TransEvtDetailType trans : transEvtDetailTypeList) {
            this.transEvtDetailType = trans;
            TransEventDetails transEvtdetails = new TransEventDetails();
            TransEvent transEvent = new TransEvent();
            if (this.transEvtDetailType != null && this.transEvtDetailType.getTransEvt() != null) {
                transEvent.setId(getId());
                transEvent.setReasonCode(getReasonCode());
                transEvent.setAmount(calculateAmount());
                transEvent.setReference(getReference());
                transEvent.setTransStatus(getTransStatus());
                transEvent.setTransType(getTransType());
                transEvent.setPricedDate(getPricedDate());
                transEvent.setProcessedDate(getProcessedDate());
                transEvent.setEffectiveDate(getEffectiveDate());
                transEvtdetails.setTransEvent(transEvent);
                transEvtDetailsList.add(transEvtdetails);
            }
        }
    }

    /**
     * Get a new instance of EffectiveDate, with necessary values set.
     * 
     * @return effectiveDate of type String
     */
    private String getEffectiveDate() {
        SILLogger.debug(AccountServiceConstants.GET_SWITCH_STATUS_LOGGING_FORMAT, className, "Entering getEffectiveDate()");
        if (this.transEvtDetailType.getTransEvt().getEffectiveDate() != null) {
            return this.transEvtDetailType.getTransEvt().getEffectiveDate().toString();
        }
        return "";
    }

    /**
     * Get a new instance of ProcessedDate, with necessary values set.
     * 
     * @return processedDate of type String
     */
    private String getProcessedDate() {
        SILLogger.debug(AccountServiceConstants.GET_SWITCH_STATUS_LOGGING_FORMAT, className, "Entering getProcessedDate()");
        if (this.transEvtDetailType.getTransEvt().getProcessedDate() != null) {
            return this.transEvtDetailType.getTransEvt().getProcessedDate().toString();
        }
        return "";
    }

    /**
     * Get a new instance of PricedDate, with necessary values set.
     * 
     * @return pricedDate of type String
     */
    private String getPricedDate() {
        SILLogger.debug(AccountServiceConstants.GET_SWITCH_STATUS_LOGGING_FORMAT, className, "Entering getPricedDate()");
        if (this.transEvtDetailType.getTransEvt().getPricedDate() != null) {
            return this.transEvtDetailType.getTransEvt().getPricedDate().toString();
        }
        return "";
    }

    /**
     * Get a new instance of TransType, with necessary values set.
     * 
     * @return transType of type TransType
     */
    private TransType getTransType() {
        SILLogger.debug(AccountServiceConstants.GET_SWITCH_STATUS_LOGGING_FORMAT, className, "Entering getTransType()");
        TransType transType = new TransType();
        if (this.transEvtDetailType.getTransEvt().getTransType() != null) {
            if (this.transEvtDetailType.getTransEvt().getTransType().getCode() != null) {
                transType.setCode(this.transEvtDetailType.getTransEvt().getTransType().getCode());
            }
            if (this.transEvtDetailType.getTransEvt().getTransType().getDesc() != null) {
                transType.setDesc(this.transEvtDetailType.getTransEvt().getTransType().getDesc());
            }
            return transType;
        }
        return getDefaultTransType();
    }

    /**
     * Get a new instance of TransStatus, with necessary values set.
     * 
     * @return transStatus of type String
     */
    private String getTransStatus() {
        SILLogger.debug(AccountServiceConstants.GET_SWITCH_STATUS_LOGGING_FORMAT, className, "Entering getTransStatus()");
        if (this.transEvtDetailType.getTransEvt().getTransStatus() != null) {
            return this.transEvtDetailType.getTransEvt().getTransStatus().getCode();
        }
        return "";
    }

    /**
     * Get a new instance of Reference, with necessary values set.
     * 
     * @return reference of type String
     */
    private String getReference() {
        SILLogger.debug(AccountServiceConstants.GET_SWITCH_STATUS_LOGGING_FORMAT, className, "Entering getReference()");
        if (this.transEvtDetailType.getTransEvt().getReference() != null) {
            return this.transEvtDetailType.getTransEvt().getReference();
        }
        return "";
    }

    /**
     * This method is used to calculate amount by using grossAmount & balEffect params .
     * 
     * @return amount of type BigDecimal
     * @throws SILException
     */
    private BigDecimal calculateAmount() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_SWITCH_STATUS_LOGGING_FORMAT, className, "Entering calculateAmount()");
        if (!SILUtil.isEmpty(this.transEvtDetailType.getAccTrans())) {
            List<TransEvtAccTransType> inboundList = this.transEvtDetailType.getAccTrans();
            List<BigDecimal> grossAmount = new ArrayList<BigDecimal>();
            List<BigInteger> balEffect = new ArrayList<BigInteger>();
            List<BigDecimal> amount = new ArrayList<BigDecimal>();
            BigDecimal totalAmount = BigDecimal.ZERO;
            for (int i = 0; i < inboundList.size(); i++) {
                if (this.transEvtDetailType.getAccTrans().get(i).getGrossAmount() != null &&
                        this.transEvtDetailType.getAccTrans().get(0).getTransType().getBalEffect() != null) {
                    grossAmount.add(this.transEvtDetailType.getAccTrans().get(i).getGrossAmount());
                    balEffect.add(this.transEvtDetailType.getAccTrans().get(i).getTransType().getBalEffect());
                } else {
                    SILLogger.debug(AccountServiceConstants.GET_SWITCH_STATUS_LOGGING_FORMAT, className, "BalEffect and grossAmount can't be null");
                    throw new SILException(AccountServiceConstants.GET_ACC_TRANS_LIST_RES_NOT_PROCESSED);
                }
                amount.add(grossAmount.get(i).multiply(new BigDecimal(balEffect.get(i))));
                totalAmount = totalAmount.add(amount.get(i));
            }
            return totalAmount;
        }
        return BigDecimal.ZERO;
    }

    /**
     * Get a new instance of ReasonCode, with necessary values set.
     * 
     * @return reasonCode of type String
     */
    private String getReasonCode() {
        SILLogger.debug(AccountServiceConstants.GET_SWITCH_STATUS_LOGGING_FORMAT, className, "Entering getReasonCode()");
        if (this.transEvtDetailType.getTransEvt().getReason() != null) {
            return this.transEvtDetailType.getTransEvt().getReason().getCode();
        }
        return "";
    }

    /**
     * Get a new instance of Trans Event Id, with necessary values set.
     * 
     * @return trans Event Id of type String
     */
    private String getId() {
        SILLogger.debug(AccountServiceConstants.GET_SWITCH_STATUS_LOGGING_FORMAT, className, "Entering getId()");
        if (this.transEvtDetailType.getTransEvt().getId() != null) {
            return this.transEvtDetailType.getTransEvt().getId();
        }
        return "";
    }
}
