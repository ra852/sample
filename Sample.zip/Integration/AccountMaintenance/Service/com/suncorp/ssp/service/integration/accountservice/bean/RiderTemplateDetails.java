////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code RiderTemplateDetails} does this.
 * 
 * @author U385424
 * @since 17/02/2018
 * @version 1.0
 */
public class RiderTemplateDetails {

    private CodeIdentifier riderType;

    /**
     * Accessor for property riderType.
     * 
     * @return riderType of type CodeIdentifier
     */
    public CodeIdentifier getRiderType() {
        return riderType;
    }

    /**
     * Mutator for property riderType.
     * 
     * @return riderType of type CodeIdentifier
     */
    @XmlElement(name = "riderType")
    public void setRiderType(CodeIdentifier riderType) {
        this.riderType = riderType;
    }
}
