////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import javax.ws.rs.core.MultivaluedMap;
import javax.xml.datatype.XMLGregorianCalendar;

import com.sonatacentral.service.v30.callerdetails.CallerDetails;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.ExternalRefType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType.AccountNumber;
import com.sonatacentral.service.v30.wrap.account.GetAccountTransactionSummaryRequestType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;

/**
 * The class {@code GetAccountTransactionRequestUtil} sets the various parameters to request object of sonata service.
 * 
 * @author u385424
 * @since 15/12/2015
 * @version 1.0
 */
public class GetAccountTransactionSummaryRequestUtil {
    private final String className = "GetAccountTransactionSummaryRequestUtil";
    private GetAccountTransactionSummaryRequestType outboundRequest;
    private MultivaluedMap<String, String> inboundRequest;

    /**
     * This Method is used to Parameterized constructor for properties initialization.
     * 
     * @param inboundRequest
     */
    public GetAccountTransactionSummaryRequestUtil(MultivaluedMap<String, String> inboundRequest) {
        SILLogger.debug(AccountServiceConstants.GET_ACC_TRANS_SUMM_LOGGING_FORMAT, className, "Entering GetAccountTransactionSummaryRequestUtil");
        this.inboundRequest = inboundRequest;
        this.outboundRequest = new GetAccountTransactionSummaryRequestType();
    }

    /**
     * This method checks the presence of parameter includePricedOnly. defaults to false, in case of not present and to actual value if present
     * 
     * @return includePricedOnly
     * @throws SILException
     */
    public boolean createIncludePricedOnly() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_TRANS_SUMM_LOGGING_FORMAT, className, "Entering createIncludePricedOnly");
        boolean includePricedOnly = false;
        if (this.inboundRequest.containsKey(AccountServiceConstants.INCLUDE_PRICED_ONLY) &&
                this.inboundRequest.get(AccountServiceConstants.INCLUDE_PRICED_ONLY).get(0) != null) {
            includePricedOnly = Boolean.parseBoolean(this.inboundRequest.get(AccountServiceConstants.INCLUDE_PRICED_ONLY).get(0));
        }
        return includePricedOnly;
    }

    /**
     * This method checks the presence of parameter skipTransactionFundGrouping defaults to false, in case of not present and to actual value if
     * present.
     * 
     * @return skipTransactionFundGrouping
     * @throws SILException
     */
    public boolean createSkipTransactionFundGrouping() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_TRANS_SUMM_LOGGING_FORMAT, className, "Entering createSkipTransactionFundGrouping");
        boolean skipTransactionFundGrouping = false;
        if (this.inboundRequest.containsKey(AccountServiceConstants.SKIP_TRANSACTION_FUND_GROUPING) &&
                this.inboundRequest.get(AccountServiceConstants.SKIP_TRANSACTION_FUND_GROUPING).get(0) != null) {
            skipTransactionFundGrouping =
                    Boolean.parseBoolean(this.inboundRequest.get(AccountServiceConstants.SKIP_TRANSACTION_FUND_GROUPING).get(0));
        }
        return skipTransactionFundGrouping;
    }

    /**
     * This method checks the presence of parameter startDate and converts into XMLGregorianCalendar type.
     * 
     * @return startDate
     * @throws SILException
     */
    public XMLGregorianCalendar createStartDate() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_TRANS_SUMM_LOGGING_FORMAT, className, "Entering createStartDate");
        XMLGregorianCalendar startDate = null;
        if (this.inboundRequest.containsKey(AccountServiceConstants.START_DATE) &&
                this.inboundRequest.get(AccountServiceConstants.START_DATE).get(0) != null) {
            startDate =
                    SILUtil.convertStringToXMLGregorianCalendar(this.inboundRequest.get(AccountServiceConstants.START_DATE).get(0),
                            CommonConstants.DATE_FORMAT);
        }
        return startDate;
    }

    /**
     * This method checks the presence of parameter endDate and converts into XMLGregorianCalendar type.
     * 
     * @return endDate
     * @throws SILException
     */
    public XMLGregorianCalendar creatEndDate() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_TRANS_SUMM_LOGGING_FORMAT, className, "Entering creatEndDate");
        XMLGregorianCalendar endDate = null;
        if (this.inboundRequest.containsKey(AccountServiceConstants.END_DATE) &&
                this.inboundRequest.get(AccountServiceConstants.END_DATE).get(0) != null) {
            endDate =
                    SILUtil.convertStringToXMLGregorianCalendar(this.inboundRequest.get(AccountServiceConstants.END_DATE).get(0),
                            CommonConstants.DATE_FORMAT);
        }
        return endDate;
    }

    /**
     * This method checks the presence of parameters accountNumber, externalReference, externalReferenceCode and accountName.
     * 
     * @return accountIdentifierType
     * @throws SILException
     */
    public AccountIdentifierType createAccountIdentifierType() throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_TRANS_SUMM_LOGGING_FORMAT, className, "Entering createAccountIdentifierType");
        AccountIdentifierType accountIdentifierType = new AccountIdentifierType();
        checkAccountNumber(accountIdentifierType);
        ExternalRefType externalRefType = new ExternalRefType();

        if (this.inboundRequest.containsKey(AccountServiceConstants.EXTERNAL_REFERENCE) &&
                this.inboundRequest.get(AccountServiceConstants.EXTERNAL_REFERENCE).get(0) != null) {
            externalRefType.setReference(this.inboundRequest.get(AccountServiceConstants.EXTERNAL_REFERENCE).get(0));
        }
        if (this.inboundRequest.containsKey(AccountServiceConstants.EXTERNAL_REFERENCE_CODE) &&
                this.inboundRequest.get(AccountServiceConstants.EXTERNAL_REFERENCE_CODE).get(0) != null) {
            externalRefType.setReferenceCode(this.inboundRequest.get(AccountServiceConstants.EXTERNAL_REFERENCE_CODE).get(0));
        }
        if (this.inboundRequest.containsKey(AccountServiceConstants.ACCOUNT_NAME) &&
                this.inboundRequest.get(AccountServiceConstants.ACCOUNT_NAME).get(0) != null) {
            accountIdentifierType.setName(this.inboundRequest.get(AccountServiceConstants.ACCOUNT_NAME).get(0));
        }
        accountIdentifierType.setAccountExternalRef(externalRefType);
        return accountIdentifierType;
    }

    /**
     * This method checks the presence of parameters accountNumbe.
     * 
     * @return accountIdentifierType
     * @throws SILException
     */
    private void checkAccountNumber(AccountIdentifierType accountIdentifierType) throws SILException {
        SILLogger.debug(AccountServiceConstants.GET_ACC_TRANS_SUMM_LOGGING_FORMAT, className, "Entering checkAccountNumber");
        AccountNumber accountNumber = new AccountNumber();
        if (this.inboundRequest.containsKey(AccountServiceConstants.ACCOUNT_NO) &&
                this.inboundRequest.get(AccountServiceConstants.ACCOUNT_NO).get(0) != null) {
            accountNumber.setAccountNo(this.inboundRequest.get(AccountServiceConstants.ACCOUNT_NO).get(0));
        } else {
            throw new SILException(AccountServiceConstants.INVALID_REQUEST_MESSAGE);
        }
        accountIdentifierType.setAccountNumber(accountNumber);
    }

    /**
     * This method sets the data in sonata service request object.
     * 
     * @param callerDetails
     * @param includePricedOnly
     * @param skipTransactionFundGrouping
     * @param accountIdentifierType
     * @param startDate
     * @param endDate
     * @return outboundRequest
     */
    public GetAccountTransactionSummaryRequestType createOutboundRequest(CallerDetails callerDetails, boolean includePricedOnly,
            boolean skipTransactionFundGrouping, AccountIdentifierType accountIdentifierType, XMLGregorianCalendar startDate,
            XMLGregorianCalendar endDate) {
        SILLogger.debug(AccountServiceConstants.GET_ACC_TRANS_SUMM_LOGGING_FORMAT, className, "Entering createOutboundRequest");
        this.outboundRequest.setCallerDetails(callerDetails);
        if (this.inboundRequest.containsKey(AccountServiceConstants.INCLUDE_PRICED_ONLY)) {
            this.outboundRequest.setIncludePricedOnly(includePricedOnly);
        }

        if (this.inboundRequest.containsKey(AccountServiceConstants.SKIP_TRANSACTION_FUND_GROUPING)) {
            this.outboundRequest.setSkipTransactionFundGrouping(skipTransactionFundGrouping);
        }

        this.outboundRequest.setAccountIdentifier(accountIdentifierType);
        this.outboundRequest.setStartDateTime(startDate);
        this.outboundRequest.setEndDateTime(endDate);
        return this.outboundRequest;
    }
}
