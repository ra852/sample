////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.suncorp.ssp.common.bean.SILErrorMessage;

/**
 * The class {@code GetAccountDetailsResponse} does this.
 * 
 * @author u386898
 * @since 15/12/2015
 * @version 1.0
 */
@XmlRootElement(name = "GetAccountDetailsResponse")
public class GetAccountDetailsResponse extends SILErrorMessage {

    private String accountNumber;
    private String externalReference;
    private String externalReferenceCode;
    private List<AccountDetailsList> accountDetailsList;

    /**
     * Accessor for property accountNumber.
     * 
     * @return accountNumber of type String
     */
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * Mutator for property accountNumber.
     * 
     * @return accountNumber of type String
     */
    @XmlElement(name = "accountNumber")
    public void setAccountNumber(String accountNumber) {
        this.accountNumber = accountNumber;
    }

    /**
     * Accessor for property externalReference.
     * 
     * @return externalReference of type String
     */
    public String getExternalReference() {
        return externalReference;
    }

    /**
     * Mutator for property externalReference.
     * 
     * @return externalReference of type String
     */
    @XmlElement(name = "externalReference")
    public void setExternalReference(String externalReference) {
        this.externalReference = externalReference;
    }

    /**
     * Accessor for property externalReferenceCode.
     * 
     * @return externalReferenceCode of type String
     */

    public String getExternalReferenceCode() {
        return externalReferenceCode;
    }

    /**
     * Mutator for property externalReferenceCode.
     * 
     * @return externalReferenceCode of type String
     */
    @XmlElement(name = "externalReferenceCode")
    public void setExternalReferenceCode(String externalReferenceCode) {
        this.externalReferenceCode = externalReferenceCode;
    }

    /**
     * Accessor for property accountDetailsList.
     *
     * @return accountDetailsList of type List<AccountDetailsList>
     */
    public List<AccountDetailsList> getAccountDetailsList() {
        return accountDetailsList;
    }

    /**
     * Mutator for property accountDetailsList.
     *
     * @param accountDetailsList of type List<AccountDetailsList>
     */
    @XmlElement(name = "accountDetails")
    public void setAccountDetailsList(List<AccountDetailsList> accountDetailsList) {
        this.accountDetailsList = accountDetailsList;
    }
}
