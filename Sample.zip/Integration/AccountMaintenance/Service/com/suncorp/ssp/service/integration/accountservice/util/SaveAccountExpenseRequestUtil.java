////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import java.util.ArrayList;
import java.util.List;

import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.AccountExpenseGroupOverrideType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType.AccountNumber;
import com.sonatacentral.service.v30.wrap.account.SaveAccountExpenseRequestType;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.AccountIdentifierDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.ExpenseGroupDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.SaveAccountExpenseRequest;

public class SaveAccountExpenseRequestUtil {

    private final String className = "SaveAccountExpenseRequestUtil";
    private SaveAccountExpenseRequestType outboundRequest;
    private SaveAccountExpenseRequest inboundRequest;

    public SaveAccountExpenseRequestUtil(SaveAccountExpenseRequest inboundRequest) {
        this.inboundRequest = inboundRequest;
        outboundRequest = new SaveAccountExpenseRequestType();
    }

    /**
     * 
     * Create Oubound(SaveAccountExpenseRequestType) request.
     * 
     * @return outboundRequest
     * @throws Exception
     */
    public SaveAccountExpenseRequestType createOutboundRequest() throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_EXPENSE_LOGGING_FORMAT, className, "Entering createOutboundRequest()");
        this.outboundRequest.setCallerDetails(SILUtil.createCallerDetails());

        constructAccountIdentifierType(inboundRequest.getAccount());
        if (inboundRequest.getTransferOverrides() != null) {
            outboundRequest.setTransferOverrides(Boolean.valueOf(inboundRequest.getTransferOverrides()));
        }

        return this.outboundRequest;
    }

    /**
     * 
     * Creates AccountIdentifierType accountNumber name.
     * 
     * @param accountIdentifierDetails
     * @throws SILException
     */
    private void constructAccountIdentifierType(AccountIdentifierDetails accountIdentifierDetails) throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_EXPENSE_LOGGING_FORMAT, className, "Entering in constructAccountIdentifierType method.");

        if (accountIdentifierDetails != null && accountIdentifierDetails.getAccountNumber() != null &&
                accountIdentifierDetails.getAccountNumber().getAccountNo() != null) {
            AccountIdentifierType accountIdentifierType = new AccountIdentifierType();
            AccountNumber accountNumber = new AccountNumber();
            accountNumber.setAccountNo(accountIdentifierDetails.getAccountNumber().getAccountNo());
            accountIdentifierType.setAccountNumber(accountNumber);
            this.outboundRequest.setAccount(accountIdentifierType);
            constructExpenseGroupMethod();

        }

    }

    /**
     * 
     * constructExpenseGroup.
     * 
     * @return
     * @throws SILException
     */
    private void constructExpenseGroupMethod() throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_EXPENSE_LOGGING_FORMAT, className, "Entering in constructExpenseGroupMethod method.");
        if (inboundRequest.getExpenseGroupDetailsList() != null && inboundRequest.getExpenseGroupDetailsList().size() > 0) {
            List<AccountExpenseGroupOverrideType> expenseGroupList = new ArrayList<AccountExpenseGroupOverrideType>();
            AccountServiceUtil serviceUtil = new AccountServiceUtil();
            String logger = AccountServiceConstants.SAVE_ACCOUNT_EXPENSE_LOGGING_FORMAT;
            for (ExpenseGroupDetails expenseGroupDetail : inboundRequest.getExpenseGroupDetailsList()) {
                AccountExpenseGroupOverrideType groupOverrideType = new AccountExpenseGroupOverrideType();
                if (expenseGroupDetail != null) {
                    setExpenseGroupParams(serviceUtil, logger, expenseGroupDetail, groupOverrideType);
                    expenseGroupList.add(groupOverrideType);
                }
            }
            this.outboundRequest.getExpenseGroup().addAll(expenseGroupList);
        }
    }

    /**
     * Set expense group Parameters.
     *
     * @param serviceUtil
     * @param logger
     * @param expenseGroupDetail
     * @param groupOverrideType
     * @throws SILException
     */
    private void setExpenseGroupParams(AccountServiceUtil serviceUtil, String logger, ExpenseGroupDetails expenseGroupDetail,
            AccountExpenseGroupOverrideType groupOverrideType) throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_EXPENSE_LOGGING_FORMAT, className, "Entering in setExpenseGroupParams method.");
        if (expenseGroupDetail.getExpenseGroup() != null && expenseGroupDetail.getExpenseGroup().getId() != null) {
            groupOverrideType.setExpenseGroupId(Long.valueOf(expenseGroupDetail.getExpenseGroup().getId()));
        }
        if (expenseGroupDetail.getEffectiveDate() != null) {
            groupOverrideType.setEffectiveDate(SILUtil.convertStringToXMLGregorianCalendar(expenseGroupDetail.getEffectiveDate(),
                    CommonConstants.DATE_TIME_FORMAT));
        }
        if (expenseGroupDetail.getConsentDate() != null) {
            groupOverrideType.setConsentDate(serviceUtil.retrieveDateValueFromString(expenseGroupDetail.getConsentDate(), logger));
        }
        if (expenseGroupDetail.getOutlet() != null && expenseGroupDetail.getOutlet().getId() != null) {
            groupOverrideType.setOutletId(Long.valueOf(expenseGroupDetail.getOutlet().getId()));
        }
    }
}
