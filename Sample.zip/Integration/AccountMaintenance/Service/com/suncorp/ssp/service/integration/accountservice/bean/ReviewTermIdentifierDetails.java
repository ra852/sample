////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code ReviewTermIdentifierDetails} does this.
 * 
 * @author U385424
 * @since 17/02/2018
 * @version 1.0
 */
public class ReviewTermIdentifierDetails {
    private ReviewTermDetails termToTime;
    private ReviewTermDetails termToAge;
    private String id;

    /**
     * Accessor for property termToTime.
     * 
     * @return termToTime of type ReviewTermDetails
     */
    public ReviewTermDetails getTermToTime() {
        return termToTime;
    }

    /**
     * Mutator for property termToTime.
     * 
     * @return termToTime of type ReviewTermDetails
     */
    @XmlElement(name = "termToTime")
    public void setTermToTime(ReviewTermDetails termToTime) {
        this.termToTime = termToTime;
    }

    /**
     * Accessor for property termToAge.
     * 
     * @return termToAge of type ReviewTermDetails
     */
    public ReviewTermDetails getTermToAge() {
        return termToAge;
    }

    /**
     * Mutator for property termToAge.
     * 
     * @return termToAge of type ReviewTermDetails
     */
    @XmlElement(name = "termToAge")
    public void setTermToAge(ReviewTermDetails termToAge) {
        this.termToAge = termToAge;
    }

    /**
     * Accessor for property id.
     * 
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     * 
     * @param id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id;
    }
}
