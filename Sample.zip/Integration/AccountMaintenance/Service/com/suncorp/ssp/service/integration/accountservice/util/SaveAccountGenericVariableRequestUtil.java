////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import java.math.BigDecimal;
import java.util.List;

import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CodeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.GenericVariableType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.GenericVariableType.Value;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountEntityType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.GenericVariableBean;
import com.suncorp.ssp.service.integration.accountservice.bean.ValueBean;

/**
 * The class {@code SaveAccountGenericVariableRequestUtil} does this.
 * 
 * @author U386868
 * @since 07/05/2016
 * @version 1.0
 */
public class SaveAccountGenericVariableRequestUtil {
    private final String className = "SaveAccountGenericVariableRequestUtil";

    /**
     * This method is used to set Account Generic Variable Details.
     * 
     * @param genericVariable
     * @param accountEntityType
     * @throws SILException
     */
    public void setAccountGenericVariableDetails(List<GenericVariableBean> genericVariables, AccountEntityType accountEntityType) 
            throws SILException {
        if (genericVariables.size() > 0) {
            SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_LOGGING_FORMAT, className, "Setting Account Generic Variable Details");
            List<GenericVariableBean> genericVariableList = genericVariables;
            List<GenericVariableType> genericVariableTypeList = accountEntityType.getGenericVariable();
            for (GenericVariableBean genericVariable : genericVariableList) {
                if (genericVariable != null) {
                    GenericVariableType genericVariableType = new GenericVariableType();
                    genericVariableType.setCode(nullCheck(genericVariable.getCode()));
                    genericVariableType.setValue(this.setGenericVariableValues(genericVariable.getValue()));
                    genericVariableTypeList.add(genericVariableType);
                }
            }
        }
    }

    /**
     * This method is used to set Generic Variable Values.
     * 
     * @param value
     * @return
     * @throws SILException
     */
    private Value setGenericVariableValues(ValueBean value) throws SILException {
        String loggerType = AccountServiceConstants.SAVE_ACCOUNT_LOGGING_FORMAT;
        Value valueType = new Value();
        AccountServiceUtil accountServiceUtil = new AccountServiceUtil();
        if (value != null) {
            if (value.getCode() != null) {
                CodeIdentifierType codeIdentifierType = new CodeIdentifierType();
                codeIdentifierType.setCode(nullCheck(value.getCode().getCode()));
                codeIdentifierType.setCodeType(nullCheck(value.getCode().getCodeType()));
                valueType.setCode(codeIdentifierType);
            }
            if (value.getDecimal() != null) {
                valueType.setDecimal(new BigDecimal(value.getDecimal()));
            }
            if (value.getInteger() != null) {
                valueType.setInteger(new Integer(value.getInteger()));
            }
            valueType.setDatetime(accountServiceUtil.retrieveDateValueFromString(value.getDatetime(), loggerType));
            valueType.setChecked(nullCheck(value.getChecked()));
            valueType.setString(nullCheck(value.getString()));
        }
        return valueType;
    }

    /**
     * This method is used for null check of field.
     * 
     * @param val
     * @return
     */
    private String nullCheck(String val) {
        SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_LOGGING_FORMAT, className, "Null Check");
        if (val != null) {
            return val;
        }
        return null;
    }
}
