////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import java.math.BigDecimal;

import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CodeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.ExpenseGroupIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.fund.fundgrouptype.FundIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType.AccountNumber;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AssetSplitType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AssetSplitType.AssetSplit;
import com.sonatacentral.service.v30.globaltypes.wrap.transaction.transactiongrouptype.TransactionTypeIdentifierType;
import com.sonatacentral.service.v30.wrap.account.SaveInvestmentRestructureRequestType;
import com.sonatacentral.service.v30.wrap.account.SaveInvestmentRestructureRequestType.TransactionDetails;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.AccountIdentifierDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.AssetSplitsBean;
import com.suncorp.ssp.service.integration.accountservice.bean.CodeIdentifier;
import com.suncorp.ssp.service.integration.accountservice.bean.SaveInvestmentRestructureRequest;
import com.suncorp.ssp.service.integration.accountservice.bean.TransactionTypeIdentifierBean;

public class SaveInvestmentRestructureRequestUtil {

    private final String className = "SaveInvestmentRestructureRequestUtil";
    private SaveInvestmentRestructureRequestType outboundRequest;
    private SaveInvestmentRestructureRequest inboundRequest;

    public SaveInvestmentRestructureRequestUtil(SaveInvestmentRestructureRequest inboundRequest) {
        this.inboundRequest = inboundRequest;
        outboundRequest = new SaveInvestmentRestructureRequestType();
    }

    /**
     * 
     * Create Oubound(SaveInvestmentRestructureRequestType) request.
     * 
     * @return outboundRequest
     * @throws Exception
     */
    public SaveInvestmentRestructureRequestType createOutboundRequest() throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_RESTRUCTURE_LOGGING_FORMAT, className, "Entering createOutboundRequest()");
        this.outboundRequest.setCallerDetails(SILUtil.createCallerDetails());

        constructAccountIdentifierType(inboundRequest.getAccount());
        constructRestructureFlags();
        constructProfileMethodIdFlags();
        constructTransactionDetails();
        constructProfileAssetSplitMethod();
        constructBalanceAssetSplitMethod();

        return this.outboundRequest;
    }

    /**
     * 
     * Creates AccountIdentifierType accountNumber name.
     * 
     * @param accountIdentifierDetails
     * @throws SILException
     */
    private void constructAccountIdentifierType(AccountIdentifierDetails accountIdentifierDetails) throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_RESTRUCTURE_LOGGING_FORMAT, className,
                "Entering in constructAccountIdentifierType method.");

        if (accountIdentifierDetails != null && accountIdentifierDetails.getAccountNumber() != null &&
                accountIdentifierDetails.getAccountNumber().getAccountNo() != null) {
            AccountIdentifierType accountIdentifierType = new AccountIdentifierType();
            AccountNumber accountNumber = new AccountNumber();
            accountNumber.setAccountNo(accountIdentifierDetails.getAccountNumber().getAccountNo());
            accountIdentifierType.setAccountNumber(accountNumber);
            this.outboundRequest.setAccount(accountIdentifierType);
        }

    }

    /**
     * 
     * Constructs constructRestructureFlags.
     * 
     * @return
     * @throws SILException
     */
    private void constructRestructureFlags() throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_RESTRUCTURE_LOGGING_FORMAT, className,
                "Entering in constructRestructureFlags method.");

        if (inboundRequest.getDoBalanceRestructure() != null) {
            this.outboundRequest.setDoBalanceRestructure(inboundRequest.getDoBalanceRestructure());
        }

        if (inboundRequest.getDoProfileRestructure() != null) {
            this.outboundRequest.setDoProfileRestructure(inboundRequest.getDoProfileRestructure());
        }
        if (inboundRequest.getUseSeparateAssetSplits() != null) {
            this.outboundRequest.setUseSeparateAssetSplits(inboundRequest.getUseSeparateAssetSplits());
        }

    }

    /**
     * 
     * Creates ProfileMethodIdFlags.
     * 
     * @return
     * @throws SILException
     */
    private void constructProfileMethodIdFlags() throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_RESTRUCTURE_LOGGING_FORMAT, className,
                "Entering in constructProfileMethodIdFlags method.");
        CodeIdentifier codeIdentifier = inboundRequest.getProfileMethodId();
        if (codeIdentifier != null) {
            this.outboundRequest.setProfileMethodId(constructCodeType(codeIdentifier));
        }

    }

    /**
     * 
     * Constructs ProfileAssetSplit.
     * 
     * @return
     * @throws SILException
     */
    private void constructProfileAssetSplitMethod() throws SILException {

        SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_RESTRUCTURE_LOGGING_FORMAT, className,
                "Entering in constructProfileAssetSplitMethod method.");
        if (inboundRequest.getProfileAssetSplit() != null && inboundRequest.getProfileAssetSplit().size() > 0) {
            AssetSplitType assetype = new AssetSplitType();
            for (AssetSplitsBean assetSplitsBean : inboundRequest.getProfileAssetSplit()) {
                if (assetSplitsBean != null) {
                    AssetSplit assetSplit = constructAssetSplit(assetSplitsBean);
                    assetype.getAssetSplit().add(assetSplit);
                }
            }

            this.outboundRequest.setProfileAssetSplit(assetype);
        }

    }

    /**
     * 
     * Constructs BalanceAssetSplit.
     * 
     * @return
     * @throws SILException
     */
    private void constructBalanceAssetSplitMethod() throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_RESTRUCTURE_LOGGING_FORMAT, className,
                "Entering in constructBalanceAssetSplitMethod method.");
        if (inboundRequest.getBalanceAssetSplit() != null && inboundRequest.getBalanceAssetSplit().size() > 0) {
            AssetSplitType assetype = new AssetSplitType();
            for (AssetSplitsBean assetSplitsBean : inboundRequest.getBalanceAssetSplit()) {
                if (assetSplitsBean != null) {
                    AssetSplit assetSplit = constructAssetSplit(assetSplitsBean);
                    assetype.getAssetSplit().add(assetSplit);
                }
            }
            this.outboundRequest.setBalanceAssetSplit(assetype);
        }
    }

    /**
     * Constructs AssetSplit.
     * 
     * @param assetSplitsBean
     * @return
     */
    private AssetSplit constructAssetSplit(AssetSplitsBean assetSplitsBean) {
        AssetSplit assetSplit = new AssetSplit();
        if (assetSplitsBean.getFund() != null) {
            SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_RESTRUCTURE_LOGGING_FORMAT, className, "Entering in constructAssetSplit method.");
            FundIdentifierType fundIdentifierType = new FundIdentifierType();
            if (assetSplitsBean.getFund() != null && assetSplitsBean.getFund().getId() != null) {
                fundIdentifierType.setId(Long.valueOf(assetSplitsBean.getFund().getId()));
            }
            if (assetSplitsBean.getFund() != null && assetSplitsBean.getFund().getName() != null) {
                fundIdentifierType.setName(assetSplitsBean.getFund().getName());
            }
            assetSplit.setFund(fundIdentifierType);
        }
        if (assetSplitsBean.getPercentage() != null) {
            BigDecimal percent = new BigDecimal(assetSplitsBean.getPercentage());
            assetSplit.setPercent(percent);
        }
        return assetSplit;
    }

    /**
     * 
     * Constructs TransactionDetails.
     * 
     * @return
     * @throws SILException
     */
    private void constructTransactionDetails() throws SILException {
        String logger = AccountServiceConstants.SAVE_INVESTMENT_RESTRUCTURE_LOGGING_FORMAT;
        SILLogger.debug(logger, className, "Entering in constructTransactionDetails method.");
        com.suncorp.ssp.service.integration.accountservice.bean.TransactionDetails transactionDetailsBean = inboundRequest.getTransactionDetails();

        AccountServiceUtil accountServiceUtil = new AccountServiceUtil();
        if (inboundRequest.getEffectiveDate() != null) {
            this.outboundRequest.setEffectiveDate(accountServiceUtil.retrieveDateValueFromString(inboundRequest.getEffectiveDate(), logger));
        }
        if (transactionDetailsBean != null) {
            TransactionDetails transactionDetails = new TransactionDetails();
            if (transactionDetailsBean.getReceivedDate() != null) {
                transactionDetails.setReceivedDate(accountServiceUtil.retrieveDateValueFromString(transactionDetailsBean.getReceivedDate(), logger));
            }
            if (transactionDetailsBean.getSwitchReason() != null) {
                transactionDetails.setSwitchReason(constructCodeType(transactionDetailsBean.getSwitchReason()));
            }
            if (transactionDetailsBean.getExpenseGroup() != null) {
                constructExpenseGroup(transactionDetailsBean, transactionDetails);
            }
            constructTransactionType(transactionDetailsBean.getTransactionType(), transactionDetails);
            this.outboundRequest.setTransactionDetails(transactionDetails);
        }
    }

    /**
     * This method constructs Expense group.
     *
     * @param transactionDetailsBean
     * @param transactionDetails
     */
    private void constructExpenseGroup(com.suncorp.ssp.service.integration.accountservice.bean.TransactionDetails transactionDetailsBean,
            TransactionDetails transactionDetails) {
        SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_RESTRUCTURE_LOGGING_FORMAT, className,
                "Entering in constructTransactionDetails method.");
        ExpenseGroupIdentifierType groupIdentifierType = new ExpenseGroupIdentifierType();
        groupIdentifierType.setId(Long.valueOf(transactionDetailsBean.getExpenseGroup().getId()));
        transactionDetails.setExpenseGroup(groupIdentifierType);
    }

    /**
     * 
     * Constructs TransactionType.
     * 
     * @param transactionTypeIdentifierBean
     * @param transactionDetails
     * @throws SILException
     */
    private void constructTransactionType(TransactionTypeIdentifierBean transactionTypeIdentifierBean, TransactionDetails transactionDetails)
            throws SILException {
        if (transactionTypeIdentifierBean != null) {
            SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_RESTRUCTURE_LOGGING_FORMAT, className,
                    "Entering in constructTransactionType method.");
            TransactionTypeIdentifierType transactionTypeIdentifierType = new TransactionTypeIdentifierType();
            transactionTypeIdentifierType.setCode(transactionTypeIdentifierBean.getCode());
            if (transactionTypeIdentifierBean.getCategory() != null) {
                transactionTypeIdentifierType.setCategory(constructCodeType(transactionTypeIdentifierBean.getCategory()));
            }
            transactionDetails.setTransactionType(transactionTypeIdentifierType);
        }
    }

    /**
     * 
     * Constructs CodeType.
     * 
     * @param codeIdentifier
     * @return
     * @throws SILException
     */
    private CodeIdentifierType constructCodeType(CodeIdentifier codeIdentifier) throws SILException {
        CodeIdentifierType codeIdentifierType = new CodeIdentifierType();
        if (codeIdentifier != null) {
            SILLogger.debug(AccountServiceConstants.SAVE_INVESTMENT_RESTRUCTURE_LOGGING_FORMAT, className, "Entering in constructCodeType method.");
            if (codeIdentifier.getCode() != null) {
                codeIdentifierType.setCode(codeIdentifier.getCode());
            }
            if (codeIdentifier.getCodeType() != null) {
                codeIdentifierType.setCodeType(codeIdentifier.getCodeType());
            }
        }
        return codeIdentifierType;
    }

}
