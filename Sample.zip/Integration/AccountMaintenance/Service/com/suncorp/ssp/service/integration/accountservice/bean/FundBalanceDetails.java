////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code FundBalanceDetails} is a java bean consisting of fund balance details.
 * 
 * @author U385424
 * @since 26/10/2016
 * @version 1.0
 */
public class FundBalanceDetails {

    private FundIdentifierDetails fund;
    private String id;
    private String price;
    private String units;
    private String value;
    private String priceDate;
    private String netInterest;
    private String withholdingTax;
    private String grossInterest;
    private String excludeFromRebalance;
    private String nextMvaFreeDate;
    private CodeIdentifier balanceType;

    /**
     * Accessor for property fund.
     * 
     * @return fund of type FundIdentifierDetails
     */
    public FundIdentifierDetails getFund() {
        return fund;
    }

    /**
     * Mutator for property fund.
     * 
     * @param fund of type FundIdentifierDetails
     */
    @XmlElement(name = "fund")
    public void setFund(FundIdentifierDetails fund) {
        this.fund = fund;
    }

    /**
     * Accessor for property id.
     * 
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     * 
     * @param id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id;
    }

    /**
     * Accessor for property price.
     * 
     * @return price of type String
     */
    public String getPrice() {
        return price;
    }

    /**
     * Mutator for property price.
     * 
     * @param price of type String
     */
    @XmlElement(name = "price")
    public void setPrice(String price) {
        this.price = price;
    }

    /**
     * Accessor for property units.
     * 
     * @return units of type String
     */
    public String getUnits() {
        return units;
    }

    /**
     * Mutator for property units.
     * 
     * @param units of type String
     */
    @XmlElement(name = "units")
    public void setUnits(String units) {
        this.units = units;
    }

    /**
     * Accessor for property value.
     * 
     * @return value of type String
     */
    public String getValue() {
        return value;
    }

    /**
     * Mutator for property value.
     * 
     * @param value of type String
     */
    @XmlElement(name = "value")
    public void setValue(String value) {
        this.value = value;
    }

    /**
     * Accessor for property priceDate.
     * 
     * @return priceDate of type String
     */
    public String getPriceDate() {
        return priceDate;
    }

    /**
     * Mutator for property priceDate.
     * 
     * @param priceDate of type String
     */
    @XmlElement(name = "priceDate")
    public void setPriceDate(String priceDate) {
        this.priceDate = priceDate;
    }

    /**
     * Accessor for property netInterest.
     * 
     * @return netInterest of type String
     */
    public String getNetInterest() {
        return netInterest;
    }

    /**
     * Mutator for property netInterest.
     * 
     * @param netInterest of type String
     */
    @XmlElement(name = "netInterest")
    public void setNetInterest(String netInterest) {
        this.netInterest = netInterest;
    }

    /**
     * Accessor for property withholdingTax.
     * 
     * @return withholdingTax of type String
     */
    public String getWithholdingTax() {
        return withholdingTax;
    }

    /**
     * Mutator for property withholdingTax.
     * 
     * @param withholdingTax of type String
     */
    @XmlElement(name = "withholdingTax")
    public void setWithholdingTax(String withholdingTax) {
        this.withholdingTax = withholdingTax;
    }

    /**
     * Accessor for property grossInterest.
     * 
     * @return grossInterest of type String
     */
    public String getGrossInterest() {
        return grossInterest;
    }

    /**
     * Mutator for property grossInterest.
     * 
     * @param grossInterest of type String
     */
    @XmlElement(name = "grossInterest")
    public void setGrossInterest(String grossInterest) {
        this.grossInterest = grossInterest;
    }

    /**
     * Accessor for property excludeFromRebalance.
     * 
     * @return excludeFromRebalance of type String
     */
    public String getExcludeFromRebalance() {
        return excludeFromRebalance;
    }

    /**
     * Mutator for property excludeFromRebalance.
     * 
     * @param excludeFromRebalance of type String
     */
    @XmlElement(name = "excludeFromRebalance")
    public void setExcludeFromRebalance(String excludeFromRebalance) {
        this.excludeFromRebalance = excludeFromRebalance;
    }

    /**
     * Accessor for property nextMvaFreeDate.
     * 
     * @return nextMvaFreeDate of type String
     */
    public String getNextMvaFreeDate() {
        return nextMvaFreeDate;
    }

    /**
     * Mutator for property nextMvaFreeDate.
     * 
     * @param nextMvaFreeDate of type String
     */
    @XmlElement(name = "nextMvaFreeDate")
    public void setNextMvaFreeDate(String nextMvaFreeDate) {
        this.nextMvaFreeDate = nextMvaFreeDate;
    }

    /**
     * Accessor for property balanceType.
     * 
     * @return balanceType of type CodeIdentifier
     */
    public CodeIdentifier getBalanceType() {
        return balanceType;
    }

    /**
     * Mutator for property balanceType.
     * 
     * @param balanceType of type CodeIdentifier
     */
    @XmlElement(name = "balanceType")
    public void setBalanceType(CodeIdentifier balanceType) {
        this.balanceType = balanceType;
    }
}
