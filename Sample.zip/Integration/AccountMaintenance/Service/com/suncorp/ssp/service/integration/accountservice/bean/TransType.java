////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code TransType} is a pure java bean consisting of properties related to GetAccountTransactionList response.
 * 
 * @author u386868
 * @since 23/12/2015
 * @version 1.0
 */
public class TransType {

    private String code;
    private String desc;
    private String id;
    private String shortDesc;
    private String balEffect;

    /**
     * Accessor for property code.
     * 
     * @return code of type String
     */
    public String getCode() {
        return code;
    }

    /**
     * Mutator for property code.
     * 
     * @return code of type String
     */
    @XmlElement(name = "code")
    public void setCode(String code) {
        this.code = code != null ? code : "";
    }

    /**
     * Accessor for property desc.
     * 
     * @return desc of type String
     */
    public String getDesc() {
        return desc;
    }

    /**
     * Mutator for property desc.
     * 
     * @return desc of type String
     */
    @XmlElement(name = "desc")
    public void setDesc(String desc) {
        this.desc = desc != null ? desc : "";
    }

    /**
     * Accessor for property id.
     * 
     * @return id of type String
     */
    public String getId() {
        return id;
    }

    /**
     * Mutator for property id.
     * 
     * @param id of type String
     */
    @XmlElement(name = "id")
    public void setId(String id) {
        this.id = id != null ? id : "";
    }

    /**
     * Accessor for property shortDesc.
     * 
     * @return shortDesc of type String
     */
    public String getShortDesc() {
        return shortDesc;
    }

    /**
     * Mutator for property shortDesc.
     * 
     * @param shortDesc of type String
     */
    @XmlElement(name = "shortDesc")
    public void setShortDesc(String shortDesc) {
        this.shortDesc = shortDesc != null ? shortDesc : "";
    }

    /**
     * Accessor for property balEffect.
     * 
     * @return balEffect of type String
     */
    public String getBalEffect() {
        return balEffect;
    }

    /**
     * Mutator for property balEffect.
     * 
     * @param balEffect of type String
     */
    @XmlElement(name = "balEffect")
    public void setBalEffect(String balEffect) {
        this.balEffect = balEffect != null ? balEffect : "";
    }
}
