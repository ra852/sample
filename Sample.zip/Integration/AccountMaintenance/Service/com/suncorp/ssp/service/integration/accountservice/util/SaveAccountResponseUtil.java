////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import com.sonatacentral.service.v30.wrap.account.SaveAccountResponseType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.SaveAccountResponse;

/**
 * The class {@code SaveAccountResponseUtil} does this.
 *
 * @author U383847
 * @since 30/03/2016
 * @version 1.0
 */
public class SaveAccountResponseUtil {
    private final String className = "SaveAccountResponseUtil";
    private SaveAccountResponseType saveAccountResponseType = null;
    
    /**
     * Parameterized constructor for properties initialization.
     *
     * @param saveAccountResponseType of type SaveAccountResponseType
     */
    public SaveAccountResponseUtil(SaveAccountResponseType saveAccountResponseType) {
        this.saveAccountResponseType = saveAccountResponseType;
    }
    
    /**
     * Save Account Response Details.
     *
     * @param saveAccountResponse
     * @throws SILException
     */
    public void saveAccountResponseDetails(SaveAccountResponse saveAccountResponse) throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_LOGGING_FORMAT, className, "Saving Account Response Details");
        if (saveAccountResponseType.getAccount() != null) {
            this.getAccountIdentifier(saveAccountResponse);
        }
    }
    
    /**
     * Get Account Identifier.
     *
     * @param saveAccountResponse
     * @throws SILException
     */
    private void getAccountIdentifier(SaveAccountResponse saveAccountResponse) throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_LOGGING_FORMAT, className, "Getting Account Identifier");
        AccountIdentifierResponseUtil accountIdentifierResponseUtil = new AccountIdentifierResponseUtil();
        accountIdentifierResponseUtil.getAccountIdentifierDetails(saveAccountResponseType.getAccount(), saveAccountResponse);    
    }
}
