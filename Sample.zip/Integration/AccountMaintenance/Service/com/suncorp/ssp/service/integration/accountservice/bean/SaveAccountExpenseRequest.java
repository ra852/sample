////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * The class {@code SaveAccountExpenseRequest} does this.
 *
 * @author U387938
 * @since 05/08/2016
 * @version 1.0
 */
@XmlRootElement(name = "SaveAccountExpenseRequest")
public class SaveAccountExpenseRequest {

    private AccountIdentifierDetails account;
    private List<ExpenseGroupDetails>  expenseGroupDetailsList;
    private String transferOverrides;
    /**
     * Accessor for property account.
     *
     * @return account of type AccountIdentifierDetails
     */
    public AccountIdentifierDetails getAccount() {
        return account;
    }
    /**
     * Mutator for property account.
     *
     * @param account of type AccountIdentifierDetails
     */
    @XmlElement(name = "account")
    public void setAccount(AccountIdentifierDetails account) {
        this.account = account;
    }
    /**
     * Accessor for property expenseGroupDetailsList.
     *
     * @return expenseGroupDetailsList of type List<ExpenseGroupDetails>
     */
    public List<ExpenseGroupDetails> getExpenseGroupDetailsList() {
        return expenseGroupDetailsList;
    }
    /**
     * Mutator for property expenseGroupDetailsList.
     *
     * @param expenseGroupDetailsList of type List<ExpenseGroupDetails>
     */
    @XmlElement(name = "expenseGroupDetailsList")
    public void setExpenseGroupDetailsList(List<ExpenseGroupDetails> expenseGroupDetailsList) {
        this.expenseGroupDetailsList = expenseGroupDetailsList;
    }
    /**
     * Accessor for property transferOverrides.
     *
     * @return transferOverrides of type String
     */
    public String getTransferOverrides() {
        return transferOverrides;
    }
    /**
     * Mutator for property transferOverrides.
     *
     * @param transferOverrides of type String
     */
    @XmlElement(name = "transferOverrides")
    public void setTransferOverrides(String transferOverrides) {
        this.transferOverrides = transferOverrides;
    }
    
    
    
}
