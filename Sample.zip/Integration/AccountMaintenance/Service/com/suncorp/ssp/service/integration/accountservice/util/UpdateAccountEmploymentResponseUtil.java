////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import com.sonatacentral.service.v30.wrap.account.SaveAccountEmploymentResponseType;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.UpdateAccountEmploymentResponse;

/**
 * The class {@code UpdateAccountEmploymentResponseUtil} construct's SOAP request for external service.
 * 
 * @author U387938
 * @since 10/09/2016
 * @version 1.0
 */
public class UpdateAccountEmploymentResponseUtil {
    private final String className = "UpdateAccountEmploymentResponseUtil";
    private SaveAccountEmploymentResponseType saveAccountEmploymentResponseType;

    public UpdateAccountEmploymentResponseUtil(SaveAccountEmploymentResponseType saveAccountEmploymentResponseType) {
        this.saveAccountEmploymentResponseType = saveAccountEmploymentResponseType;
    }

    /**
     * 
     * This method constructs UpdateAccountEmploymentResponse object from response.
     *
     * @param updateAccountEmploymentResponse
     * @throws SILException
     */
    public void setUpdateAccountEmploymentResponse(UpdateAccountEmploymentResponse updateAccountEmploymentResponse) throws SILException {
        SILLogger.debug(AccountServiceConstants.SAVE_ACCOUNT_EXPENSE_LOGGING_FORMAT, className, "Entering setUpdateAccountEmploymentResponse");
        if (saveAccountEmploymentResponseType != null) {
            if (saveAccountEmploymentResponseType.getAccount() != null && saveAccountEmploymentResponseType.getAccount().getAccountNumber() != null &&
                    saveAccountEmploymentResponseType.getAccount().getAccountNumber().getAccountNo() != null) {
                updateAccountEmploymentResponse.setResponse(AccountServiceConstants.UPDATE_ACCOUNT_EMP_SUCCESS_MSG);
            }
        } else {
            throw new SILException(AccountServiceConstants.INVALID_RESPONSE_FROM_SONATA);
        }
    }

}
