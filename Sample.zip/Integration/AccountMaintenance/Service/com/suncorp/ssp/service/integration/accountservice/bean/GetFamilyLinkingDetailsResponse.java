////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import com.suncorp.ssp.common.bean.SILErrorMessage;

/**
 * The class {@code GetFamilyLinkingDetailsResponse} does this.
 * 
 * @author U385424
 * @since 15/11/2016
 * @version 1.0
 */
@XmlRootElement(name = "GetFamilyLinkingDetailsResponse")
public class GetFamilyLinkingDetailsResponse extends SILErrorMessage {
    private List<FamilyLinkingDetails> familyLinkingDetails;

    /**
     * Accessor for property familyLinkingDetails.
     * 
     * @return familyLinkingDetails of type List<FamilyLinkingDetails>
     */
    public List<FamilyLinkingDetails> getFamilyLinkingDetails() {
        if (familyLinkingDetails == null) {
            familyLinkingDetails = new ArrayList<FamilyLinkingDetails>();
        }
        return familyLinkingDetails;
    }

    /**
     * Mutator for property familyLinkingDetails.
     * 
     * @param familyLinkingDetails of type List<FamilyLinkingDetails>
     */
    @XmlElement(name = "familyLinkingDetails")
    public void setFamilyLinkingDetails(List<FamilyLinkingDetails> familyLinkingDetails) {
        this.familyLinkingDetails = familyLinkingDetails;
    }
}
