////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code TransEventAccount} is a pure java bean consisting of properties related to GetAccountTransactionList response.
 * 
 * @author U385424
 * @since 23/01/2017
 * @version 1.0
 */
public class TransEventAccount {
    private String accountNo;
    private String mailingName;

    /**
     * Accessor for property accountNo.
     * 
     * @return accountNo of type String
     */
    public String getAccountNo() {
        return accountNo;
    }

    /**
     * Mutator for property accountNo.
     * 
     * @param accountNo of type String
     */
    @XmlElement(name = "accountNo")
    public void setAccountNo(String accountNo) {
        this.accountNo = accountNo != null ? accountNo : "";
    }

    /**
     * Accessor for property mailingName.
     * 
     * @return mailingName of type String
     */
    public String getMailingName() {
        return mailingName;
    }

    /**
     * Mutator for property mailingName.
     * 
     * @param mailingName of type String
     */
    @XmlElement(name = "mailingName")
    public void setMailingName(String mailingName) {
        this.mailingName = mailingName != null ? mailingName : "";
    }
}
