////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import java.math.BigDecimal;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code TransSummaryItemTypeList} does this.
 * 
 * @author u385424
 * @since 15/12/2015
 * @version 1.0
 */
public class TransSummaryItemTypeList {

    private String description;
    private BigDecimal totalAmount;
    private Long displayOrder;

    /**
     * Accessor for property description.
     * 
     * @return description of type String
     */
    public String getDescription() {
        return description;
    }

    /**
     * Mutator for property description.
     * 
     * @return description of type String
     */
    @XmlElement(name = "description")
    public void setDescription(String description) {
        this.description = description != null ? description : "";
    }

    /**
     * Accessor for property totalAmount.
     * 
     * @return totalAmount of type String
     */
    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    /**
     * Mutator for property totalAmount.
     * 
     * @return totalAmount of type String
     */
    @XmlElement(name = "totalAmount")
    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount != null ? totalAmount : BigDecimal.ZERO;
    }

    public Long getDisplayOrder() {
        return displayOrder;
    }

    @XmlElement(name = "displayOrder")
    public void setDisplayOrder(Long displayOrder) {
        this.displayOrder = displayOrder != null ? displayOrder : 0L;
    }
}
