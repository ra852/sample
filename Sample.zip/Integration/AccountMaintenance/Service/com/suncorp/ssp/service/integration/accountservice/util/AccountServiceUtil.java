////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.util;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

import javax.xml.datatype.XMLGregorianCalendar;

import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.AdvisorGroupType;
import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.AdvisorIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.AdvisorSplitType;
import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.AdvisorSplitType.Advisor;
import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.BankAccountIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.client.clientgrouptype.ClientIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CodeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.CurrencyIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.ExternalRefType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.FrequencyIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.GenericReference;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.MasterSchemeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.PatternTemplateIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.ProfileFunctionIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.data.datagrouptype.RelationshipTypeIdentifierType;
import com.sonatacentral.service.v30.globaltypes.common.fund.fundgrouptype.FundIdentifierType;
import com.sonatacentral.service.v30.globaltypes.identifiertype.IdentifierAuditType;
import com.sonatacentral.service.v30.globaltypes.identifiertype.IdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.AccountIdentifierType.AccountNumber;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.ClientAccountRelationshipIdentifierType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.ClientAccountRelationshipType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.DirectDebitAuthorityType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.InvestmentProfileType;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.InvestmentProfileType.AccountProfileLink;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.InvestmentProfileType.AccountProfileLink.Fund;
import com.sonatacentral.service.v30.globaltypes.wrap.account.accountgrouptype.InvestmentProfileType.AccountProfileLink.Profile;
import com.suncorp.ssp.common.constants.CommonConstants;
import com.suncorp.ssp.common.exception.SILException;
import com.suncorp.ssp.common.util.SILLogger;
import com.suncorp.ssp.common.util.SILUtil;
import com.suncorp.ssp.service.constants.accountservice.AccountServiceConstants;
import com.suncorp.ssp.service.integration.accountservice.bean.AccountNumberInfo;
import com.suncorp.ssp.service.integration.accountservice.bean.AccountPointer;
import com.suncorp.ssp.service.integration.accountservice.bean.AccountProfileLinkDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.AdvisorBean;
import com.suncorp.ssp.service.integration.accountservice.bean.AdvisorDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.AdvisorGroupBean;
import com.suncorp.ssp.service.integration.accountservice.bean.AdvisorSplitsBean;
import com.suncorp.ssp.service.integration.accountservice.bean.AuditIdentifier;
import com.suncorp.ssp.service.integration.accountservice.bean.BankAccountIdentifierBean;
import com.suncorp.ssp.service.integration.accountservice.bean.ClientAccountRelationshipBean;
import com.suncorp.ssp.service.integration.accountservice.bean.ClientAccountRelationshipIdentifierBean;
import com.suncorp.ssp.service.integration.accountservice.bean.ClientBean;
import com.suncorp.ssp.service.integration.accountservice.bean.CodeIdentifier;
import com.suncorp.ssp.service.integration.accountservice.bean.CurrencyIdentifierBean;
import com.suncorp.ssp.service.integration.accountservice.bean.DirectDebitAuthorityBean;
import com.suncorp.ssp.service.integration.accountservice.bean.FrequencyIdentifierBean;
import com.suncorp.ssp.service.integration.accountservice.bean.FundDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.FundIdentifierDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.IdNameIdentifier;
import com.suncorp.ssp.service.integration.accountservice.bean.InvestmentProfileDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.MasterSchemeIdentifier;
import com.suncorp.ssp.service.integration.accountservice.bean.PatternTemplateDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.ProfileDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.ProfileFunctionDetails;
import com.suncorp.ssp.service.integration.accountservice.bean.ReferenceIdentifier;
import com.suncorp.ssp.service.integration.accountservice.bean.RelationshipIdentifierBean;

/**
 * The class {@code AccountServiceUtil} is used as a util class for preparing GetAccountDetailsList request.
 * 
 * @author u387938
 * @since 23/12/2015
 * @version 1.0
 */

public class AccountServiceUtil {

    private final String className = "AccountServiceUtil";

    /**
     * This method constructs the AccountNumber object from response.
     * @param accountNumber
     * @return accountNumberInfo
     * @throws SILException
     */
    public AccountNumberInfo retrieveAccountNumberDetails(AccountNumber accountNumber, String loggerType) throws SILException {
        AccountNumberInfo accountNumberInfo = new AccountNumberInfo();
        if (accountNumber != null) {
            SILLogger.debug(loggerType, className, "Entering in retrieveAccountNumberDetails method");
            accountNumberInfo.setAccountNo(accountNumber.getAccountNo());
            accountNumberInfo.setProductName(accountNumber.getProductName());
        } else {
            accountNumberInfo = retrieveEmptyAccountNumberDetails(loggerType);
        }
        SILLogger.debug(loggerType, className, "Exiting in retrieveAccountNumberDetails method");
        return accountNumberInfo;
    }

    /**
     * This method constructs the Empty AccountNumber object from response.
     * @return accountNumberInfo
     * @throws SILException
     */
    public AccountNumberInfo retrieveEmptyAccountNumberDetails(String loggerType) throws SILException {
        SILLogger
                .debug(loggerType, className, "Entering in retrieveEmptyAccountNumberDetails method");
        AccountNumberInfo accountNumberInfo = new AccountNumberInfo();
        accountNumberInfo.setAccountNo(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        accountNumberInfo.setProductName(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        SILLogger.debug(loggerType, className, "Exiting in retrieveEmptyAccountNumberDetails method");
        return accountNumberInfo;
    }

    /**
     * This method constructs ExternalRefinfo object from the response.
     * @param ExternalRef
     * @return externalrefinfo
     * @throws SILException
     */
    public ReferenceIdentifier retrieveExternalRef(ExternalRefType ExternalRef, String loggerType) throws SILException {
        ReferenceIdentifier externalrefinfo = new ReferenceIdentifier();
        if (ExternalRef != null) {
            SILLogger.debug(loggerType, className, "Entering in retrieveExternalRef()");
            externalrefinfo.setReferenceCode(ExternalRef.getReferenceCode());
            externalrefinfo.setReference(ExternalRef.getReference());
        } else {
            externalrefinfo = retrieveEmptyExternalRef(loggerType);
        }
        SILLogger.debug(loggerType, className, "Exiting in retrieveExternalRef()");
        return externalrefinfo;
    }

    /**
     * This method constructs empty ExternalRefinfo object .
     * @param externalrefinfo,loggerType
     * @throws SILException
     */
    public ReferenceIdentifier retrieveEmptyExternalRef(String loggerType) throws SILException {
        SILLogger.debug(loggerType, className, "Entering in retrieveEmptyExternalRef()");
        ReferenceIdentifier externalrefinfo = new ReferenceIdentifier();
        externalrefinfo.setReferenceCode(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        externalrefinfo.setReference(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        SILLogger.debug(loggerType, className, "Exiting in retrieveEmptyExternalRef()");
        return externalrefinfo;
    }

    /**
     * This method constructs codeInfo object from the response.
     * @param codedetails,loggerType
     * @return codeInfo throws SILException
     */
    public CodeIdentifier retrieveCode(CodeIdentifierType codedetails, String loggerType) throws SILException {
        CodeIdentifier codeInfo = new CodeIdentifier();
        if (codedetails != null) {
            SILLogger.debug(loggerType, className, "Entering in retrieveCode method");
            codeInfo.setId(retrieveLongValue(codedetails.getId(), loggerType));
            codeInfo.setCode(codedetails.getCode());
            codeInfo.setCodeType(codedetails.getCodeType());
            codeInfo.setCodeShortDescription(codedetails.getCodeShortDescription());
            codeInfo.setCodeDescription(codedetails.getCodeDescription());
        } else {
            codeInfo = retrieveEmptyCode(loggerType);
        }
        return codeInfo;
    }

   /**
    * This method constructs default codeInfo object.
    * @param loggerType
    * @return codeInfo
    * @throws SILException
    */
    public CodeIdentifier retrieveEmptyCode(String loggerType) throws SILException {
        SILLogger.debug(loggerType, className, "Entering in retrieveEmptyCode method");
        CodeIdentifier codeInfo = new CodeIdentifier();
        codeInfo.setId(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        codeInfo.setCode(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        codeInfo.setCodeType(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        codeInfo.setCodeShortDescription(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        codeInfo.setCodeDescription(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        return codeInfo;
    }

    /**
     * This method constructs FrequencyIdentifier object from the response.
     * @param codedetails,loggerType
     * @return codeInfo throws SILException
     */
    public FrequencyIdentifierBean retrieveFrequencyIdentifier(FrequencyIdentifierType frequencyIdentifierType, String loggerType)
            throws SILException {
        FrequencyIdentifierBean frequencyIdentifierBean = new FrequencyIdentifierBean();
        if (frequencyIdentifierType != null) {
            SILLogger.debug(loggerType, className, "Entering in retrieveFrequencyIdentifier method");
            frequencyIdentifierBean.setId(retrieveLongValue(frequencyIdentifierType.getId(), loggerType));
            frequencyIdentifierBean.setName(frequencyIdentifierType.getName());
            frequencyIdentifierBean.setFistId(retrieveLongValue(frequencyIdentifierType.getFistId(), loggerType));
            frequencyIdentifierBean.setFreqSetCode(frequencyIdentifierType.getFreqSetCode());
            frequencyIdentifierBean.setFreqCode(frequencyIdentifierType.getFreqCode());
        } else {
            frequencyIdentifierBean = retrieveEmptyFrequencyIdentifier(loggerType);
        }
        return frequencyIdentifierBean;
    }

    /**
     * This method constructs default FrequencyIdentifier object.
     * @param loggerType
     * @return frequencyIdentifierBean
     * @throws SILException
     */
    public FrequencyIdentifierBean retrieveEmptyFrequencyIdentifier(String loggerType) throws SILException {
        SILLogger.debug(loggerType, className, "Entering in retrieveEmptyFrequencyIdentifier method");
        FrequencyIdentifierBean frequencyIdentifierBean = new FrequencyIdentifierBean();
        frequencyIdentifierBean.setId(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        frequencyIdentifierBean.setName(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        frequencyIdentifierBean.setFistId(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        frequencyIdentifierBean.setFreqSetCode(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        frequencyIdentifierBean.setFreqCode(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        return frequencyIdentifierBean;
    }

    /**
     * This method constructs the auditinfo object from response.
     * @param audit,loggerType
     * @return auditIdentifier
     * @throws SILException
     */
    public AuditIdentifier retrieveAudit(IdentifierAuditType audit, String loggerType) throws SILException {
        AuditIdentifier auditIdentifier = new AuditIdentifier();
        if (audit != null) {
            SILLogger.debug(loggerType, className, "Entering in retrieveAudit method");
            auditIdentifier.setLastUpdated(retrieveDateValue(audit.getLastUpdated(), loggerType));
            auditIdentifier.setLastUpdatedBy(audit.getLastUpdatedBy());
            auditIdentifier.setDataVersion(retrieveLongValue(audit.getDataVersion(), loggerType));
        } else {
            auditIdentifier = retrieveEmptyAudit(loggerType);
        }
        return auditIdentifier;
    }

    /**
     * This method constructs default Audit object.
     * @param loggerType
     * @return auditIdentifier
     * @throws SILException
     */
    public AuditIdentifier retrieveEmptyAudit(String loggerType) throws SILException {
        SILLogger.debug(loggerType, className, "Entering in retrieveEmptyAudit method");
        AuditIdentifier auditIdentifier = new AuditIdentifier();
        auditIdentifier.setLastUpdated(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        auditIdentifier.setLastUpdatedBy(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        auditIdentifier.setDataVersion(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        return auditIdentifier;
    }

    /**
     * This method constructs the AccountPointer object from response.
     * @param genericReference
     * @param loggerType
     * @return accountPointer
     * @throws SILException
     */
    public AccountPointer retrieveAccountPointerDetails(GenericReference genericReference, String loggerType) throws SILException {
        AccountPointer accountPointer = new AccountPointer();
        if (genericReference != null) {
            SILLogger
                    .debug(loggerType, className, "Entering in retrieveAccountPointerDetails method");
            accountPointer.setId(genericReference.getId());
            accountPointer.setReference(retrieveObjectValue(genericReference.getRef(), AccountServiceConstants.GET_ACC_SERVICE_UTIL_LOGGING_FORMAT));
        } else {
            accountPointer = retrieveEmptyAccountPointer(loggerType);
        }
        return accountPointer;
    }

    /**
     * This method constructs the Empty AccountPointer object.
     * @param loggerType
     * @return accountPointer
     */
    public AccountPointer retrieveEmptyAccountPointer(String loggerType) {
        SILLogger.debug(loggerType, className, "Entering in retrieveEmptyAccountPointer method");
        AccountPointer accountPointer = new AccountPointer();
        accountPointer.setId(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        accountPointer.setReference(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        return accountPointer;
    }

    /**
     * This method constructs MasterSchema object from the response.
     * @param masterSchemeIdentifier
     * @return masterSchemeIdentifier
     * @throws SILException
     */
    public MasterSchemeIdentifier retrieveMasterSchemeDetails(MasterSchemeIdentifierType masterSchemeIdentifierType, String loggerType)
            throws SILException {
        MasterSchemeIdentifier masterSchemeIdentifier = new MasterSchemeIdentifier();
        if (masterSchemeIdentifierType != null) {
            SILLogger.debug(loggerType, className, "Entering in retrieveMasterSchemeDetails()");
            masterSchemeIdentifier.setDisplayName(masterSchemeIdentifierType.getDisplayName());
            masterSchemeIdentifier.setLongName(masterSchemeIdentifierType.getLongName());
        } else {
            masterSchemeIdentifier = retrieveEmptyMasterSchemeDetails(loggerType);
        }
        return masterSchemeIdentifier;
    }

    /**
     * This method constructs Empty MasterSchemeDetails object.
     * 
     * @return masterSchemeIdentifier
     * @throws SILException
     */
    public MasterSchemeIdentifier retrieveEmptyMasterSchemeDetails(String loggerType) throws SILException {
        SILLogger.debug(loggerType, className, "Entering in retrieveEmptyMasterSchemeDetails()");
        MasterSchemeIdentifier masterSchemeIdentifier = new MasterSchemeIdentifier();
        masterSchemeIdentifier.setDisplayName(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        masterSchemeIdentifier.setLongName(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        return masterSchemeIdentifier;
    }

    /**
     * This method constructs InvestmentProfile object from response.
     * 
     * @param investmentProfileType,loggerType
     * @return investmentProfileDetails
     * @throws SILException
     */
    public InvestmentProfileDetails retrieveInvestmentProfileDetails(InvestmentProfileType investmentProfileType, String loggerType)
            throws SILException {
        InvestmentProfileDetails investmentProfileDetails = new InvestmentProfileDetails();
        if (investmentProfileType != null) {
            SILLogger.debug(loggerType, className, "Entering in retrieveInvestmentProfileDetails()");
            investmentProfileDetails.setAccountProfileLinkDetails(retrieveAccountProfileLinkDetails(investmentProfileType.getAccountProfileLink(),
                    loggerType));
            if (investmentProfileType.getAccountProfileLink() != null) {
                investmentProfileDetails.setProfileFunctionDetails(retrieveProfileFunctionDetails(investmentProfileType.getAccountProfileLink()
                        .getProfileFunctionIdentifier(), loggerType));
                investmentProfileDetails.setProfileDetails(retrieveProfileDetails(investmentProfileType.getAccountProfileLink().getProfile(),
                        loggerType));
                investmentProfileDetails.setSameAsDefaultInvestmentProfile(retrieveBooleanValue(investmentProfileType.getAccountProfileLink()
                        .isSameAsDefaultInvestmentProfile(), loggerType));
                investmentProfileDetails.setPatternMethod(retrieveCode(investmentProfileType.getAccountProfileLink().getPatternMethodCode(),
                        loggerType));
                investmentProfileDetails.setOverrideCode(retrieveCode(investmentProfileType.getAccountProfileLink().getOverrideCode(), loggerType));
                investmentProfileDetails.setTotalAmount(retrieveBigDecimalValue(investmentProfileType.getAccountProfileLink().getTotalAmount(),
                        loggerType));
                investmentProfileDetails.setClearAllFunds(retrieveBooleanValue(investmentProfileType.getAccountProfileLink().isClearAllFunds(),
                        loggerType));
                investmentProfileDetails.setFundDetails(retrieveFundDetailsLst(investmentProfileType.getAccountProfileLink().getFund(), loggerType));
            }
        }
        return investmentProfileDetails;
    }

    /**
     * This method constructs AccountProfileLink object from response.
     * 
     * @param accountProfileLinkType
     * @return accountProfileLinkDetails,loggerType
     * @throws SILException
     */
    public AccountProfileLinkDetails retrieveAccountProfileLinkDetails(AccountProfileLink accountProfileLinkType, String loggerType)
            throws SILException {
        AccountProfileLinkDetails accountProfileLinkDetails = new AccountProfileLinkDetails();
        if (accountProfileLinkType != null) {
            SILLogger.debug(loggerType, className, "Entering in retrieveAccountProfileLinkDetails()");
            accountProfileLinkDetails.setEffectiveDate(retrieveDateValue(accountProfileLinkType.getEffectiveDate(), loggerType));
        } else {
            accountProfileLinkDetails = retrieveEmptyAccountProfileLinkDetails(loggerType);
        }
        return accountProfileLinkDetails;
    }

    /**
     * This method constructs Empty AccountProfileLink object.
     * 
     * @return accountProfileLinkDetails
     * @throws SILException
     */
    public AccountProfileLinkDetails retrieveEmptyAccountProfileLinkDetails(String loggerType) throws SILException {
        AccountProfileLinkDetails accountProfileLinkDetails = new AccountProfileLinkDetails();
        SILLogger.debug(loggerType, className, "Entering in retrieveEmptyAccountProfileLinkDetails()");
        accountProfileLinkDetails.setEffectiveDate(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        return accountProfileLinkDetails;
    }

    /**
     * This method constructs Profile Function object from response.
     * 
     * @param profileFunctionIdentifierType
     * @return profileFunctionDetails
     * @throws SILException
     */
    public ProfileFunctionDetails retrieveProfileFunctionDetails(ProfileFunctionIdentifierType profileFunctionIdentifierType, String loggerType)
            throws SILException {
        ProfileFunctionDetails profileFunctionDetails = new ProfileFunctionDetails();
        if (profileFunctionIdentifierType != null) {
            SILLogger.debug(loggerType, className, "Entering in retrieveProfileFunctionDetails()");
            profileFunctionDetails.setId(retrieveLongValue(profileFunctionIdentifierType.getId(), loggerType));
            profileFunctionDetails.setName(profileFunctionIdentifierType.getName());
            profileFunctionDetails.setCode(profileFunctionIdentifierType.getCode());
            profileFunctionDetails.setAuditDetails(retrieveAudit(profileFunctionIdentifierType.getAudit(), loggerType));
        } else {
            profileFunctionDetails = retrieveEmptyProfileFunctionDetails(loggerType);
        }
        return profileFunctionDetails;
    }

    /**
     * This method constructs empty Profile Function object.
     * @param loggerType
     * @return profileFunctionDetails
     * @throws SILException
     */
    public ProfileFunctionDetails retrieveEmptyProfileFunctionDetails(String loggerType) throws SILException {
        ProfileFunctionDetails profileFunctionDetails = new ProfileFunctionDetails();
        SILLogger.debug(loggerType, className, "Entering in retrieveEmptyProfileFunctionDetails()");
        profileFunctionDetails.setId(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        profileFunctionDetails.setName(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        profileFunctionDetails.setCode(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        profileFunctionDetails.setAuditDetails(retrieveEmptyAudit(loggerType));
        return profileFunctionDetails;
    }

    /**
     * This method constructs Profile object from response.
     * @param profile
     * @return profileDetails
     * @throws SILException
     */
    public ProfileDetails retrieveProfileDetails(Profile profile, String loggerType) throws SILException {
        ProfileDetails profileDetails = new ProfileDetails();
        if (profile != null) {
            SILLogger.debug(loggerType, className, "Entering in retrieveProfileDetails()");
            profileDetails.setBeSpokeNew(retrieveBooleanValue(profile.isBespokeNew(), loggerType));
            profileDetails.setPatternTemplateDetails(retrievePatternTemplateDetails(profile.getPatternTemplate(), loggerType));
        } else {
            profileDetails = retrieveEmptyProfileDetails(loggerType);
        }
        return profileDetails;
    }

    /**
     * This method constructs empty Profile object.
     * @param loggerType
     * @return profileDetails
     * @throws SILException
     */
    public ProfileDetails retrieveEmptyProfileDetails(String loggerType) throws SILException {
        ProfileDetails profileDetails = new ProfileDetails();
        SILLogger.debug(loggerType, className, "Entering in retrieveEmptyProfileDetails()");
        profileDetails.setBeSpokeNew(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        profileDetails.setPatternTemplateDetails(retrieveEmptyPatternTemplateDetails(loggerType));
        return profileDetails;
    }

    /**
     * This method constructs patternTemplate object from response.
     * @param patternIdentifierType,loggerType
     * @return patternTemplateDetails
     * @throws SILException
     */
    public PatternTemplateDetails retrievePatternTemplateDetails(PatternTemplateIdentifierType patternIdentifierType, String loggerType)
            throws SILException {
        PatternTemplateDetails patternTemplateDetails = new PatternTemplateDetails();
        if (patternIdentifierType != null) {
            SILLogger.debug(loggerType, className, "Entering in retrievePatternTemplateDetails()");
            patternTemplateDetails
                    .setId(retrieveLongValue(patternIdentifierType.getId(), loggerType));
            patternTemplateDetails.setName(patternIdentifierType.getName());
            patternTemplateDetails.setPatternHeaderId(retrieveLongValue(patternIdentifierType.getPatternHeaderId(), loggerType));
            patternTemplateDetails.setReference(patternIdentifierType.getReference());
            patternTemplateDetails.setEffectiveDate(retrieveDateValue(patternIdentifierType.getEffectiveDate(), loggerType));
            patternTemplateDetails.setAudit(retrieveAudit(patternIdentifierType.getAudit(), loggerType));
        } else {
            patternTemplateDetails = retrieveEmptyPatternTemplateDetails(loggerType);
        }
        return patternTemplateDetails;
    }

    /**
     * This method constructs empty patternTemplate object.
     * @param loggerType
     * @return patternTemplateDetails
     * @throws SILException
     */
    public PatternTemplateDetails retrieveEmptyPatternTemplateDetails(String loggerType) throws SILException {
        PatternTemplateDetails patternTemplateDetails = new PatternTemplateDetails();
        SILLogger.debug(loggerType, className, "Entering in retrieveEmptyPatternTemplateDetails()");
        patternTemplateDetails.setId(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        patternTemplateDetails.setName(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        patternTemplateDetails.setPatternHeaderId(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        patternTemplateDetails.setReference(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        patternTemplateDetails.setEffectiveDate(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        patternTemplateDetails.setAudit(retrieveEmptyAudit(loggerType));
        return patternTemplateDetails;
    }

    /**
     * This method constructs Account Relationship object from response.
     * 
     * @param clientAccountRelationshipType
     * @return accountRelationshipBean
     * @throws SILException
     */
    public ClientAccountRelationshipBean retrieveClientAccountRelationshipDetails(ClientAccountRelationshipType clientAccountRelationshipType,
            String loggerType) throws SILException {
        ClientAccountRelationshipBean accountRelationshipBean = new ClientAccountRelationshipBean();
        if (clientAccountRelationshipType != null) {
            SILLogger.debug(loggerType, className, "Entering in retrieveClientAccountRelationshipDetails()");
            accountRelationshipBean.setClientAccountRelationship(retrieveClientAccountRelationshipidentifier(
                    clientAccountRelationshipType.getClientAccountRelationship(), loggerType));
            accountRelationshipBean.setIsPrimary(retrieveBooleanValue(clientAccountRelationshipType.isIsPrimary(), loggerType));
            accountRelationshipBean.setDateJoined(retrieveDateValue(clientAccountRelationshipType.getDateJoined(), loggerType));
            accountRelationshipBean.setEndDate(retrieveDateValue(clientAccountRelationshipType.getEndDate(), loggerType));
            accountRelationshipBean.setBankaccount(retrieveBankAccountDetails(clientAccountRelationshipType.getBankaccount(), loggerType));
            accountRelationshipBean.setDirectDebitAuthorities(retrieveDirectDebitAuthoritiesLst(
                    clientAccountRelationshipType.getDirectDebitAuthority(), loggerType));
        } else {
            accountRelationshipBean = retrieveEmptyClientAccountRelationshipDetails(loggerType);
        }
        return accountRelationshipBean;
    }

    /**
     * This method constructs empty Account Relationship object.
     * @param loggerType
     * @return accountRelationshipBean
     * @throws SILException
     */
    public ClientAccountRelationshipBean retrieveEmptyClientAccountRelationshipDetails(String loggerType) throws SILException {
        ClientAccountRelationshipBean accountRelationshipBean = new ClientAccountRelationshipBean();
        SILLogger.debug(loggerType, className, "Entering in retrieveEmptyClientAccountRelationshipDetails()");
        accountRelationshipBean.setClientAccountRelationship(retrieveEmptyClientAccountRelationshipidentifier(loggerType));
        accountRelationshipBean.setIsPrimary(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        accountRelationshipBean.setDateJoined(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        accountRelationshipBean.setEndDate(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        accountRelationshipBean.setDirectDebitAuthorities(retrieveEmptyDirectDebitAuthoritiesLst(loggerType));
        return accountRelationshipBean;
    }

    /**
     * This method constructs DirectDebitAuthorities List object from response.
     * @param directAuthorityTypesLst
     * @return debitAuthorityBeans
     * @throws SILException
     */
    public List<DirectDebitAuthorityBean> retrieveDirectDebitAuthoritiesLst(List<DirectDebitAuthorityType> directAuthorityTypesLst, String loggerType)
            throws SILException {
        List<DirectDebitAuthorityBean> debitAuthorityBeans = new ArrayList<DirectDebitAuthorityBean>();
        if (directAuthorityTypesLst != null && directAuthorityTypesLst.size() > 0) {
            for (DirectDebitAuthorityType debitAuthorityType : directAuthorityTypesLst) {
                if (debitAuthorityType != null) {
                    SILLogger.debug(loggerType, className, "Entering in retrieveDirectDebitAuthoritiesLst()");
                    DirectDebitAuthorityBean directDebitAuthorityBean = new DirectDebitAuthorityBean();
                    directDebitAuthorityBean.setId(retrieveLongValue(debitAuthorityType.getId(), loggerType));
                    directDebitAuthorityBean.setEffectiveDate(retrieveDateValue(debitAuthorityType.getEffectiveDate(), loggerType));
                    directDebitAuthorityBean.setStatusCode(retrieveCode(debitAuthorityType.getStatusCode(), loggerType));
                    directDebitAuthorityBean.setReasonCode(retrieveCode(debitAuthorityType.getReasonCode(), loggerType));
                    directDebitAuthorityBean.setDateSent(retrieveDateValue(debitAuthorityType.getDateSent(), loggerType));
                    debitAuthorityBeans.add(directDebitAuthorityBean);
                }
            }
        } else {
            debitAuthorityBeans.add(retrieveEmptyDirectDebitAuthorities(loggerType));
        }
        return debitAuthorityBeans;
    }

    /**
     * This method constructs empty DirectDebitAuthorities List object.
     * @param loggerType
     * @return debitAuthorityBeans
     * @throws SILException
     */
    public List<DirectDebitAuthorityBean> retrieveEmptyDirectDebitAuthoritiesLst(String loggerType) throws SILException {
        List<DirectDebitAuthorityBean> debitAuthorityBeans = new ArrayList<DirectDebitAuthorityBean>();
        SILLogger.debug(loggerType, className, "Entering in retrieveEmptyDirectDebitAuthoritiesLst()");
        debitAuthorityBeans.add(retrieveEmptyDirectDebitAuthorities(loggerType));
        return debitAuthorityBeans;
    }

    /**
     * This method constructs empty DirectDebitAuthorities object.
     * @return directDebitAuthorityBean
     */
    public DirectDebitAuthorityBean retrieveEmptyDirectDebitAuthorities(String loggerType) throws SILException {
        DirectDebitAuthorityBean directDebitAuthorityBean = new DirectDebitAuthorityBean();
        SILLogger.debug(loggerType, className, "Entering in retrieveEmptyDirectDebitAuthorities()");
        directDebitAuthorityBean.setId(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        directDebitAuthorityBean.setEffectiveDate(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        directDebitAuthorityBean.setStatusCode(retrieveEmptyCode(loggerType));
        directDebitAuthorityBean.setReasonCode(retrieveEmptyCode(loggerType));
        directDebitAuthorityBean.setDateSent(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        return directDebitAuthorityBean;
    }

    /**
     *This method constructs empty DirectDebitAuthorities object.
     * @param clientAccountRelationshipIdentifierType
     * @return accountRelationshipIdentifierBean
     * @throws SILException
     */
    public ClientAccountRelationshipIdentifierBean retrieveClientAccountRelationshipidentifier(
            ClientAccountRelationshipIdentifierType clientAccountRelationshipIdentifierType, String loggerType) throws SILException {
        ClientAccountRelationshipIdentifierBean accountRelationshipIdentifierBean = new ClientAccountRelationshipIdentifierBean();
        if (clientAccountRelationshipIdentifierType != null) {
            SILLogger.debug(loggerType, className, "Entering in retrieveClientAccountRelationshipidentifier()");
            accountRelationshipIdentifierBean.setClient(retrieveClientDetails(clientAccountRelationshipIdentifierType.getClient(), loggerType));
            accountRelationshipIdentifierBean.setId(retrieveLongValue(clientAccountRelationshipIdentifierType.getId(), loggerType));
            accountRelationshipIdentifierBean.setPrimary(retrieveBooleanValue(clientAccountRelationshipIdentifierType.isPrimary(), loggerType));
            accountRelationshipIdentifierBean.setRelationshipType(retrieveRelationshipIdentifierDetails(
                    clientAccountRelationshipIdentifierType.getRelationshipType(), loggerType));
        } else {
            accountRelationshipIdentifierBean =
                    retrieveEmptyClientAccountRelationshipidentifier(loggerType);
        }
        return accountRelationshipIdentifierBean;
    }

    /**
     * This method constructs empty ClientAccountRelationshipidentifier object from response.
     * @return accountRelationshipIdentifierBean
     * @throws SILException
     */
    public ClientAccountRelationshipIdentifierBean retrieveEmptyClientAccountRelationshipidentifier(String loggerType) throws SILException {

        ClientAccountRelationshipIdentifierBean accountRelationshipIdentifierBean = new ClientAccountRelationshipIdentifierBean();
        SILLogger.debug(loggerType, className, "Entering in retrieveEmptyClientAccountRelationshipidentifier()");
        accountRelationshipIdentifierBean.setClient(retrieveEmptyClientDetails(loggerType));
        accountRelationshipIdentifierBean.setId(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        accountRelationshipIdentifierBean.setPrimary(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        accountRelationshipIdentifierBean
                .setRelationshipType(retrieveEmptyRelationshipIdentifierDetails(loggerType));

        return accountRelationshipIdentifierBean;
    }

    /**
     * This method constructs Clientdetails object from response from response.
     * @param clientIdentifierType
     * @return clientBean
     * @throws SILException
     */
    public ClientBean retrieveClientDetails(ClientIdentifierType clientIdentifierType, String loggerType) throws SILException {
        ClientBean clientBean = new ClientBean();
        if (clientIdentifierType != null) {
            SILLogger.debug(loggerType, className, "Entering in retrieveClientDetails()");
            clientBean.setId(retrieveLongValue(clientIdentifierType.getId(), loggerType));
            clientBean.setName(clientIdentifierType.getName());
            clientBean.setMasterScheme(retrieveMasterSchemeDetails(clientIdentifierType.getMasterScheme(), loggerType));
            clientBean.setClientPointer(retrieveAccountPointerDetails(clientIdentifierType.getClientPointer(), loggerType));
            clientBean.setClientExternalRef(retrieveExternalRef(clientIdentifierType.getClientExternalRef(), loggerType));
            clientBean.setClientSurname(clientIdentifierType.getClientSurname());
            clientBean.setClientForename(clientIdentifierType.getClientForename());
            clientBean.setClientForename2(clientIdentifierType.getClientForename2());
            clientBean.setClientTFN(clientIdentifierType.getClientTFN());
            clientBean.setAudit(retrieveAudit(clientIdentifierType.getAudit(), loggerType));
            clientBean.setGlobalIntermediaryIDNumber(clientIdentifierType.getGlobalIntermediaryIDNumber());
        } else {
            clientBean = retrieveEmptyClientDetails(loggerType);
        }
        return clientBean;
    }

    /**
     * This method constructs empty Clientdetails object from response.
     * @param loggerType
     * @return clientBean
     * @throws SILException
     */
    public ClientBean retrieveEmptyClientDetails(String loggerType) throws SILException {
        ClientBean clientBean = new ClientBean();
        SILLogger.debug(loggerType, className, "Entering in retrieveEmptyClientDetails()");
        clientBean.setId(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        clientBean.setName(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        clientBean.setMasterScheme(retrieveEmptyMasterSchemeDetails(loggerType));
        clientBean.setClientPointer(retrieveEmptyAccountPointer(loggerType));
        clientBean.setClientExternalRef(retrieveEmptyExternalRef(loggerType));
        clientBean.setClientSurname(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        clientBean.setClientForename(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        clientBean.setClientForename2(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        clientBean.setClientTFN(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        clientBean.setAudit(retrieveEmptyAudit(loggerType));
        clientBean.setGlobalIntermediaryIDNumber(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        return clientBean;
    }

    /**
     * This method constructs RelationshipIdentifier object from response.
     * @param typeIdentifierType
     * @return accountRelationshipIdentifierBean
     * @throws SILException
     */
    public RelationshipIdentifierBean retrieveRelationshipIdentifierDetails(RelationshipTypeIdentifierType typeIdentifierType, String loggerType)
            throws SILException {
        RelationshipIdentifierBean accountRelationshipIdentifierBean = new RelationshipIdentifierBean();
        if (typeIdentifierType != null) {
            SILLogger.debug(loggerType, className, "Entering in retrieveRelationshipIdentifierDetails()");
            accountRelationshipIdentifierBean.setCode(typeIdentifierType.getCode());
            accountRelationshipIdentifierBean.setId(retrieveLongValue(typeIdentifierType.getId(), loggerType));
            accountRelationshipIdentifierBean.setName(typeIdentifierType.getName());
        } else {
            accountRelationshipIdentifierBean = retrieveEmptyRelationshipIdentifierDetails(loggerType);
        }
        return accountRelationshipIdentifierBean;
    }

    /**
     * This method constructs empty RelationshipIdentifier object.
     * @param loggerType
     * @return accountRelationshipIdentifierBean
     * @throws SILException
     */
    public RelationshipIdentifierBean retrieveEmptyRelationshipIdentifierDetails(String loggerType) throws SILException {
        RelationshipIdentifierBean accountRelationshipIdentifierBean = new RelationshipIdentifierBean();
        SILLogger.debug(loggerType, className, "Entering in retrieveEmptyRelationshipIdentifierDetails()");
        accountRelationshipIdentifierBean.setCode(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        accountRelationshipIdentifierBean.setId(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        accountRelationshipIdentifierBean.setName(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        return accountRelationshipIdentifierBean;
    }

    /**
     * This method constructs CurrencyIdentifier object from response.
     * @param currencyIdentifierType
     * @return currencyIdentifierBean
     * @throws SILException
     */
    public CurrencyIdentifierBean retrieveCurrencyIdentifierDetails(CurrencyIdentifierType currencyIdentifierType, String loggerType)
            throws SILException {
        CurrencyIdentifierBean currencyIdentifierBean = new CurrencyIdentifierBean();
        if (currencyIdentifierType != null) {
            SILLogger.debug(loggerType, className, "Entering in retrieveCurrencyIdentifierDetails()");
            currencyIdentifierBean.setCode(currencyIdentifierType.getCode());
            currencyIdentifierBean.setId(retrieveLongValue(currencyIdentifierType.getId(), loggerType));
            currencyIdentifierBean.setName(currencyIdentifierType.getName());
        } else {
            currencyIdentifierBean = retrieveEmptyCurrencyIdentifierDetails(loggerType);
        }
        return currencyIdentifierBean;
    }

    /**
     * This method constructs empty CurrencyIdentifier object.
     * @param loggerType
     * @return currencyIdentifierBean
     * @throws SILException
     */
    public CurrencyIdentifierBean retrieveEmptyCurrencyIdentifierDetails(String loggerType) throws SILException {
        CurrencyIdentifierBean currencyIdentifierBean = new CurrencyIdentifierBean();
        SILLogger.debug(loggerType, className, "Entering in retrieveEmptyCurrencyIdentifierDetails()");
        currencyIdentifierBean.setCode(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        currencyIdentifierBean.setId(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        currencyIdentifierBean.setName(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        return currencyIdentifierBean;
    }

    /**
     * This method constructs BankAccount object from response.
     * @param bankAccountIdentifierType
     * @return bankAccountIdentifierBean
     * @throws SILException
     */
    public BankAccountIdentifierBean retrieveBankAccountDetails(BankAccountIdentifierType bankAccountIdentifierType, String loggerType)
            throws SILException {
        BankAccountIdentifierBean bankAccountIdentifierBean = new BankAccountIdentifierBean();
        if (bankAccountIdentifierType != null) {
            SILLogger.debug(loggerType, className, "Entering in retrieveBankAccountDetails()");
            bankAccountIdentifierBean.setBankAccountNumber(bankAccountIdentifierType.getBankAccountNumber());
            bankAccountIdentifierBean.setBankAccountTypeCode(bankAccountIdentifierType.getBankAccountTypeCode());
            bankAccountIdentifierBean.setAudit(retrieveAudit(bankAccountIdentifierType.getAudit(), loggerType));
            bankAccountIdentifierBean.setBankAccountCurrencyCode(retrieveCurrencyIdentifierDetails(
                    bankAccountIdentifierType.getBankAccountCurrencyCode(), loggerType));
        } else {
            bankAccountIdentifierBean = retrieveEmptyBankAccountDetails(loggerType);
        }
        return bankAccountIdentifierBean;
    }

    /**
     * This method constructs empty BankAccount object.
     * @param loggerType
     * @return bankAccountIdentifierBean
     * @throws SILException
     */
    public BankAccountIdentifierBean retrieveEmptyBankAccountDetails(String loggerType) throws SILException {
        BankAccountIdentifierBean bankAccountIdentifierBean = new BankAccountIdentifierBean();
        SILLogger.debug(loggerType, className, "Entering in retrieveEmptyBankAccountDetails()");
        bankAccountIdentifierBean.setBankAccountNumber(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        bankAccountIdentifierBean.setBankAccountTypeCode(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        bankAccountIdentifierBean.setAudit(retrieveEmptyAudit(loggerType));
        bankAccountIdentifierBean
                .setBankAccountCurrencyCode(retrieveEmptyCurrencyIdentifierDetails(loggerType));
        return bankAccountIdentifierBean;
    }

    /**
     * This method constructs the Outlet object from response.
     * @param identifierType
     * @return idNameIdentifier
     * @throws SILException
     */
    public IdNameIdentifier retrieveOutlet(IdentifierType identifierType, String loggerType) throws SILException {
        IdNameIdentifier idNameIdentifier = new IdNameIdentifier();
        if (identifierType != null) {
            SILLogger.debug(loggerType, className, "Entering in retrieveOutlet method");
            idNameIdentifier.setId(retrieveLongValue(identifierType.getId(), loggerType));
            idNameIdentifier.setName(identifierType.getName());
        } else {
            idNameIdentifier = retrieveEmptyOutlet(loggerType);
        }
        return idNameIdentifier;
    }

    /**
     * This method constructs empty Outlet object.
     * @return idNameIdentifier
     * @throws SILException
     */
    public IdNameIdentifier retrieveEmptyOutlet(String loggerType) throws SILException {
        IdNameIdentifier idNameIdentifier = new IdNameIdentifier();
        SILLogger.debug(loggerType, className, "Entering in retrieveEmptyOutlet method");
        idNameIdentifier.setId(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        idNameIdentifier.setName(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        return idNameIdentifier;
    }

    /**
     * This method constructs FundDetails list object from response.
     * @param fundTypeLst
     * @return fundDetailsLst
     * @throws SILException
     */
    public List<FundDetails> retrieveFundDetailsLst(List<Fund> fundTypeLst, String loggerType) throws SILException {
        List<FundDetails> fundDetailsLst = new ArrayList<FundDetails>();
        if (fundTypeLst != null && fundTypeLst.size() > 0) {
            for (Fund fund : fundTypeLst) {
                if (fund != null) {
                    SILLogger.debug(loggerType, className, "Entering in retrieveFundDetailsLst method");
                    retrieveFundDetails(fundDetailsLst, fund, loggerType);
                }
            }
        } else {
            retrieveEmptyFundDetails(fundDetailsLst, loggerType);
        }
        return fundDetailsLst;
    }

    /**
     * This method constructs empty FundDetails list object.
     * @param fundDetailsLst,loggerType
     * @throws SILException
     */
    private void retrieveEmptyFundDetails(List<FundDetails> fundDetailsLst, String loggerType) throws SILException {
        FundDetails fundDetails = new FundDetails();
        SILLogger.debug(loggerType, className, "Entering in retrieveEmptyFundDetails method");
        fundDetails.setFundIdentifier(retrieveEmptyFundIdentifier(loggerType));
        fundDetails.setAmount(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        fundDetails.setSplitPercent(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        fundDetails.setSequence(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        fundDetails.setAlternateFundIdentifier(retrieveEmptyFundIdentifier(loggerType));
        fundDetailsLst.add(fundDetails);
    }

    /**
     * This method constructs FundDetails object from response.
     * @param fundDetailsLst
     * @param fund,loggerType
     * @throws SILException
     */
    private void retrieveFundDetails(List<FundDetails> fundDetailsLst, Fund fund, String loggerType) throws SILException {
        FundDetails fundDetails = new FundDetails();
        SILLogger.debug(loggerType, className, "Entering in retrieveFundDetails method");
        fundDetails.setFundIdentifier(retrieveFundIdentifier(fund.getFundIdentifier(), loggerType));
        fundDetails.setAmount(retrieveBigDecimalValue(fund.getAmount(), loggerType));
        fundDetails.setSplitPercent(retrieveBigDecimalValue(fund.getSplitPercent(), loggerType));
        fundDetails.setSequence(retrieveBigDecimalValue(fund.getSequence(), loggerType));
        fundDetails.setAlternateFundIdentifier(retrieveFundIdentifier(fund.getAlternateFundIdentifier(), loggerType));
        fundDetailsLst.add(fundDetails);
    }

    /**
     * This method constructs FundIdentifier object from response.
     * @param fundIdentifierType
     * @return FundIdentifierDetails
     * @throws SILException
     */
    public FundIdentifierDetails retrieveFundIdentifier(FundIdentifierType fundIdentifierType, String loggerType) throws SILException {
        FundIdentifierDetails fundIdentifierBean = new FundIdentifierDetails();
        if (fundIdentifierType != null) {
            SILLogger.debug(loggerType, className, "Entering in retrieveFundIdentifier method");
            fundIdentifierBean.setId(retrieveLongValue(fundIdentifierType.getId(), loggerType));
            fundIdentifierBean.setName(fundIdentifierType.getName());
            fundIdentifierBean.setFundExternalRef(retrieveExternalRef(fundIdentifierType.getFundExternalRef(), loggerType));
            fundIdentifierBean.setFundFullName(fundIdentifierType.getFundFullName());
            fundIdentifierBean.setFundCorrespondenceName(fundIdentifierType.getFundCorrespondenceName());
            fundIdentifierBean.setAudit(retrieveAudit(fundIdentifierType.getAudit(), loggerType));
            fundIdentifierBean.setFundType(retrieveCode(fundIdentifierType.getFundType(), loggerType));
        } else {
            fundIdentifierBean = retrieveEmptyFundIdentifier(loggerType);
        }
        return fundIdentifierBean;
    }

    /**
     *  This method constructs empty FundIdentifier object.
     * @return fundIdentifierBean
     * @throws SILException
     */
    public FundIdentifierDetails retrieveEmptyFundIdentifier(String loggerType) throws SILException {
        FundIdentifierDetails fundIdentifierBean = new FundIdentifierDetails();
        SILLogger.debug(loggerType, className, "Entering in retrieveEmptyFundIdentifier method");
        fundIdentifierBean.setId(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        fundIdentifierBean.setName(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        fundIdentifierBean.setFundExternalRef(retrieveEmptyExternalRef(AccountServiceConstants.GET_ACC_SERVICE_UTIL_LOGGING_FORMAT));
        fundIdentifierBean.setFundFullName(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        fundIdentifierBean.setFundCorrespondenceName(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        fundIdentifierBean.setAudit(retrieveEmptyAudit(loggerType));
        fundIdentifierBean.setFundType(retrieveEmptyCode(loggerType));
        return fundIdentifierBean;
    }

    /**
     *  This method constructs AdvisorGroup object from response.
     * @param advisorGroupType
     * @return advisorGroupBean
     * @throws SILException
     */
    public AdvisorGroupBean retrieveAdvisorGroupDetails(AdvisorGroupType advisorGroupType, String loggerType) throws SILException {
        AdvisorGroupBean advisorGroupBean = new AdvisorGroupBean();
        if (advisorGroupType != null) {
            SILLogger.debug(loggerType, className, "Entering in retrieveAdvisorGroupDetails method");
            advisorGroupBean.setId(retrieveLongValue(advisorGroupType.getId(), loggerType));
            advisorGroupBean.setEffectiveDate(retrieveDateValue(advisorGroupType.getEffectiveDate(), loggerType));
            advisorGroupBean.setRelationshipType(retrieveRelationshipIdentifierDetails(advisorGroupType.getRelationshipType(), loggerType));
            advisorGroupBean.setAdvisorSplits(retrieveAdvisorSplitsDetailsLst(advisorGroupType.getAdvisorSplit(), loggerType));

        }
        return advisorGroupBean;
    }

    /**
     * This method constructs AdvisorSplitsDetails List object from response.
     * @param advisorSplitTypesLst
     * @return advisorSplitsBeansLst
     * @throws SILException
     */
    public List<AdvisorSplitsBean> retrieveAdvisorSplitsDetailsLst(List<AdvisorSplitType> advisorSplitTypesLst, String loggerType)
            throws SILException {
        List<AdvisorSplitsBean> advisorSplitsBeansLst = new ArrayList<AdvisorSplitsBean>();
        if (advisorSplitTypesLst != null && advisorSplitTypesLst.size() > 0) {
            SILLogger.debug(loggerType, className, "Entering in retrieveAdvisorSplitsDetailsLst method");
            for (AdvisorSplitType advisorSplitType : advisorSplitTypesLst) {
                if (advisorSplitType != null) {
                    advisorSplitsBeansLst.add(retrieveAdvisorSplitsDetails(advisorSplitType, loggerType));
                }
            }
        } else {
            advisorSplitsBeansLst.add(retrieveEmptyAdvisorSplitsDetails(loggerType));
        }
        return advisorSplitsBeansLst;
    }

    /**
     * This method constructs AdvisorSplitsDetails object from response.
     * @param advisorSplitType
     * @return advisorSplitsBean
     * @throws SILException
     */
    public AdvisorSplitsBean retrieveAdvisorSplitsDetails(AdvisorSplitType advisorSplitType, String loggerType) throws SILException {
        AdvisorSplitsBean advisorSplitsBean = new AdvisorSplitsBean();
        if (advisorSplitType != null) {
            SILLogger.debug(loggerType, className, "Entering in retrieveAdvisorSplitsDetails method");
            advisorSplitsBean.setId(retrieveLongValue(advisorSplitType.getId(), loggerType));
            advisorSplitsBean.setPercentageSplit(retrieveBigDecimalValue(advisorSplitType.getPercentageSplit(), loggerType));
            advisorSplitsBean.setPrimary(retrieveBooleanValue(advisorSplitType.isPrimary(), loggerType));
            advisorSplitsBean.setReference(advisorSplitType.getReference());
            advisorSplitsBean.setAdvisor(retrieveAdvisorBeanDetails(advisorSplitType.getAdvisor(), loggerType));
        } else {
            advisorSplitsBean = retrieveEmptyAdvisorSplitsDetails(loggerType);
        }
        return advisorSplitsBean;
    }

    /**
     * This method constructs empty AdvisorSplitsDetails object.
     * @param loggerType
     * @return advisorSplitsBean
     * @throws SILException
     */
    public AdvisorSplitsBean retrieveEmptyAdvisorSplitsDetails(String loggerType) throws SILException {
        AdvisorSplitsBean advisorSplitsBean = new AdvisorSplitsBean();
        SILLogger.debug(loggerType, className, "Entering in retrieveEmptyAdvisorSplitsDetails method");
        advisorSplitsBean.setId(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        advisorSplitsBean.setPercentageSplit(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        advisorSplitsBean.setPrimary(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        advisorSplitsBean.setReference(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        advisorSplitsBean.setAdvisor(retrieveEmptyAdvisorBeanDetails(loggerType));
        return advisorSplitsBean;
    }

    /**
     * This method constructs Advisor object from response.
     * @param advisorType
     * @return advisorBean
     * @throws SILException
     */
    public AdvisorBean retrieveAdvisorBeanDetails(Advisor advisorType, String loggerType) throws SILException {
        AdvisorBean advisorBean = new AdvisorBean();
        if (advisorType != null) {
            SILLogger.debug(loggerType, className, "Entering in retrieveAdvisorBeanDetails method");
            advisorBean.setStatus(retrieveCode(advisorType.getStatus(), loggerType));
            advisorBean.setOutletType(retrieveCode(advisorType.getOutletType(), loggerType));
            advisorBean.setIs(retrieveAdvisorDetails(advisorType, loggerType));

        } else {
            advisorBean = retrieveEmptyAdvisorBeanDetails(loggerType);
        }
        return advisorBean;
    }

    /**
     * This method constructs empty Advisor object.
     * @param loggerType
     * @return advisorBean
     * @throws SILException
     */
    public AdvisorBean retrieveEmptyAdvisorBeanDetails(String loggerType) throws SILException {
        AdvisorBean advisorBean = new AdvisorBean();
        SILLogger.debug(loggerType, className, "Entering in retrieveEmptyAdvisorBeanDetails method");
        advisorBean.setStatus(retrieveEmptyCode(loggerType));
        advisorBean.setOutletType(retrieveEmptyCode(loggerType));
        advisorBean.setIs(retrieveEmptyAdvisor(loggerType));
        return advisorBean;
    }

    /**
     * This method constructs the Advisor object from response.
     * @param advisorIdentifierType
     * @return advisorDetails
     * @throws SILException
     */
    public AdvisorDetails retrieveAdvisorDetails(AdvisorIdentifierType advisorIdentifierType, String loggerType) throws SILException {
        AdvisorDetails advisorDetails = new AdvisorDetails();
        if (advisorIdentifierType != null) {
            SILLogger.debug(loggerType, className, "Entering in retrieveAdvisorDetails method");
            advisorDetails.setId(retrieveLongValue(advisorIdentifierType.getId(), loggerType));
            advisorDetails.setName(advisorIdentifierType.getName());
            advisorDetails.setAdvisorNumber(advisorIdentifierType.getAdvisorNumber());
            advisorDetails.setClientId(retrieveLongValue(advisorIdentifierType.getClientId(), loggerType));
            advisorDetails.setClientExternalRef(retrieveExternalRef(advisorIdentifierType.getClientExternalRef(), loggerType));
            advisorDetails.setClientForename(advisorIdentifierType.getClientForename());
            advisorDetails.setClientSurname(advisorIdentifierType.getClientSurname());
            advisorDetails.setMasterScheme(retrieveMasterSchemeDetails(advisorIdentifierType.getMasterScheme(), loggerType));
            advisorDetails.setUsername(advisorIdentifierType.getUsername());
            advisorDetails.setAudit(retrieveAudit(advisorIdentifierType.getAudit(), loggerType));
        } else {
            advisorDetails = retrieveEmptyAdvisor(loggerType);
        }
        return advisorDetails;
    }

    /**
     * This method constructs default Advisor object.
     * @return advisorDetails
     * @throws SILException
     */
    public AdvisorDetails retrieveEmptyAdvisor(String loggerType) throws SILException {
        SILLogger.debug(loggerType, className, "Entering in retrieveEmptyAdvisor method");
        AdvisorDetails advisorDetails = new AdvisorDetails();
        advisorDetails.setId(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        advisorDetails.setName(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        advisorDetails.setAdvisorNumber(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        advisorDetails.setClientId(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        advisorDetails.setClientExternalRef(retrieveEmptyExternalRef(loggerType));
        advisorDetails.setClientForename(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        advisorDetails.setClientSurname(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        advisorDetails.setMasterScheme(retrieveEmptyMasterSchemeDetails(loggerType));
        advisorDetails.setUsername(AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING);
        advisorDetails.setAudit(retrieveEmptyAudit(loggerType));
        return advisorDetails;
    }

    /**
     * This method convert Big decimal value to String object.
     * @return String
     */
    public String retrieveLongValue(Long value, String loggerType) throws SILException {
        SILLogger.debug(loggerType, className, "Entering in retrieveLongValue method");
        if (value != null) {
            return String.valueOf(value);
        } else {
            return AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING;
        }
    }

    /**
     * This method convert XMLGregorianCalendar to String.
     * @return String
     */
    public String retrieveDateValue(XMLGregorianCalendar gregorianCalendar, String loggerType) throws SILException {
        SILLogger.debug(loggerType, className, "Entering in retrieveDateValue method");
        if (gregorianCalendar != null) {
            return SILUtil.convertXMLGregorianCalendartoString(gregorianCalendar, CommonConstants.DATE_TIME_FORMAT);
        } else {
            return AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING;
        }
    }

    /**
     * This method convert Object value to String object.
     * @return String
     */
    public String retrieveObjectValue(Object value, String loggerType) throws SILException {
        SILLogger.debug(loggerType, className, "Entering in retrieveObjectValue method");
        if (value != null) {
            return String.valueOf(value);
        } else {
            return AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING;
        }
    }

    /**
     * This method convert Boolean value to String object.
     * @return String
     */
    public String retrieveBooleanValue(Boolean value, String loggerType) throws SILException {
        SILLogger.debug(loggerType, className, "Entering in retrieveBooleanValue method");
        if (value != null) {
            return String.valueOf(value);
        } else {
            return AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING;
        }
    }

    /**
     * This method convert Big decimal value to String object.
     * @return String
     */
    public String retrieveBigDecimalValue(BigDecimal value, String loggerType) throws SILException {
        SILLogger.debug(loggerType, className, "Entering in retrieveBigDecimalValue method");
        if (value != null) {
            return value.toString();
        } else {
            return AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING;
        }
    }

    /**
     * This method convert Integer value to String object.
     * @return String
     */
    public String retrieveIntegerValue(Integer value, String loggerType) throws SILException {
        SILLogger.debug(loggerType, className, "Entering in retrieveIntegerValue method");
        if (value != null) {
            return String.valueOf(value);
        } else {
            return AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING;
        }
    }

    /**
     * This method convert Big Integer value to String object.
     * @return String
     */
    public String retrieveBigIntegerValue(BigInteger value, String loggerType) throws SILException {
        SILLogger.debug(loggerType, className, "Entering in retrieveBigIntegerValue method");
        if (value != null) {
            return value.toString();
        } else {
            return AccountServiceConstants.GET_ACC_EXPENSE_EMPTY_STRING;
        }
    }
    
    /**
     * This method convert String to XMLGregorianCalendar.
     * @return String
     */
    public XMLGregorianCalendar retrieveDateValueFromString(String gregorianCalendar, String loggerType) throws SILException {
        SILLogger.debug(loggerType, className, "Entering in retrieveDateValue method");
        if (gregorianCalendar != null) {
            return SILUtil.convertStringToXMLGregorianCalendar(gregorianCalendar, CommonConstants.DATE_FORMAT);
        } else {
            return null;
        }
    }    
}
