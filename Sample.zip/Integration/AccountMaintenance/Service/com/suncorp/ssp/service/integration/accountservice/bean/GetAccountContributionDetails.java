////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code GetAccountContributionDetails} does this.
 * 
 * @author U385424
 * @since 30/09/2017
 * @version 1.0
 */
public class GetAccountContributionDetails {

    private List<AccountDetails> accountDetails;
    private List<Contributions> contributions;

    /**
     * Accessor for property accountDetails.
     * 
     * @return accountDetails of type AccountDetails
     */
    public List<AccountDetails> getAccountDetails() {
        return accountDetails;
    }

    /**
     * Mutator for property accountDetails.
     * 
     * @param accountDetails of type AccountDetails
     */
    @XmlElement(name = "accountDetails")
    public void setAccountDetails(List<AccountDetails> accountDetails) {
        this.accountDetails = accountDetails;
    }

    /**
     * Accessor for property contributions.
     * 
     * @return contributions of type Contributions
     */
    public List<Contributions> getContributions() {
        return contributions;
    }

    /**
     * Mutator for property contributions.
     * 
     * @param contributions of type Contributions
     */
    @XmlElement(name = "contributions")
    public void setContributions(List<Contributions> contributions) {
        this.contributions = contributions;
    }

}
