////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2015, Suncorp Metway Limited. All rights reserved.
//
// This is unpublished proprietary source code of Suncorp Metway Limited.
// The copyright notice above does not evidence any actual or intended
// publication of such source code.
//
////////////////////////////////////////////////////////////////////////////////
package com.suncorp.ssp.service.integration.accountservice.bean;

import javax.xml.bind.annotation.XmlElement;

/**
 * The class {@code PensionDrawdownDetail} does this.
 * 
 * @author U387938
 * @since 02/02/2016
 * @version 1.0
 */
public class PensionDrawdownDetail {
    private String accountLTA;
    private String totalLTA;

    /**
     * Accessor for property accountLTA.
     * 
     * @return accountLTA of type String
     */
    public String getAccountLTA() {
        return accountLTA;
    }

    /**
     * Mutator for property accountLTA.
     * 
     * @param accountLTA of type String
     */
    @XmlElement(name = "accountLTA")
    public void setAccountLTA(String accountLTA) {
        this.accountLTA = accountLTA != null ? accountLTA : "";
    }

    /**
     * Accessor for property totalLTA.
     * 
     * @return totalLTA of type String
     */
    public String getTotalLTA() {
        return totalLTA;
    }

    /**
     * Mutator for property totalLTA.
     * 
     * @param totalLTA of type String
     */
    @XmlElement(name = "totalLTA")
    public void setTotalLTA(String totalLTA) {
        this.totalLTA = totalLTA != null ? totalLTA : "";
    }
}
